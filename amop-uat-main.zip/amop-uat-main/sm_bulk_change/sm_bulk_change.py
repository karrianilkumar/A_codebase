"""
@Author1 : Burhan
@Author2 : Phaneendra.Y
Created Date: 21-06-24
"""

import os
import time
import json
import uuid
import boto3
import datetime
import requests
import pytds
import threading
import pandas as pd
import xml.etree.ElementTree as ET
from sqlalchemy import create_engine, text
from concurrent.futures import ThreadPoolExecutor, as_completed
# from datetime import datetime, timedelta  # Merged both datetime imports

from kore_apis import activate_provisioning_request, send_provisioning_request, send_core_request, send_revio_request, base64_encode, base64_decode
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging

logging = Logging(name="sm_bulk_change")

sqs = boto3.client("sqs", region_name="us-east-1")
lambda_client = boto3.client("lambda", region_name="us-east-1")


##to fetch the service providers ids for each tenants separately used to get the serviceprovider ids in generic way
def load_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_serviceproviders.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"### load_json Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### load_json Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### load_json Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs

##helper function to remove the hardcodes using the
def get_provider_ids(json_data, tenant_name, provider_names):
    """
    Fetches only the IDs of specified providers for a given tenant.
    
    Args:
        json_data (dict): JSON data containing provider information
        tenant_name (str): Name of the tenant
        provider_names (list): List of provider names to fetch IDs for
        
    Returns:
        list: List of provider IDs that match the specified provider names
    """
    return [
        details["id"]
        for provider_name, details in json_data.get(tenant_name, {}).items()
        if provider_name in provider_names
    ]


def funtion_caller(data,path,access_token):
    """
    Routes incoming authentication and user management requests to the appropriate handler function.

    This function initializes the database configuration using environment variables and user-specific access filters.
    It then selects the correct handler based on the provided API path and executes it with the given data.

    Args:
        path (str): The API endpoint path (e.g., "/login_using_database", "/reset_password_email").
        data (dict): The request payload containing necessary parameters for the selected handler.

    Returns:
        dict: The response from the called handler function. If the path is invalid, returns:
              {"flag": False, "error": "Invalid path or method"}
    """

    global db_config

    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

    user=data.get('username')
    if not user:
        user=data.get('user_name')
    tenant_database=data.get('db_name')

    ROUTES = {
        "/update_edit_cost_center": update_edit_cost_center,
        "/update_device_status": update_device_status,
        "/update_assign_customer": update_assign_customer,
        "/update_customer_rate_plan": update_customer_rate_plan,
        "/create_rev_io_service": create_rev_io_service,
        "/update_archive_status": update_archive_status,
        "/bulk_update_customer_rate_plan_bp": bulk_update_customer_rate_plan_bp,
        "/bulk_update_assign_customer_bp": bulk_update_assign_customer_bp,
        "/webbing_update_device_status": webbing_update_device_status,
        "/update_webbing_carrier_rate_plan_name": update_webbing_carrier_rate_plan_name,
        "/update_webbing_user_name": update_webbing_user_name,
        "/bulk_update_change_phone_number": bulk_update_change_phone_number,
        "/telegence_bc_update_device_status_restore_cancelled": telegence_bc_update_device_status_restore_cancelled,
        "/start_sync": start_sync,
    }

    handler = ROUTES.get(path)
    if handler:
        return handler(data)
    return {"error": "Invalid path or method"}


def  get_user_acess_filters(username):
    """
    Retrieves user access filters for customers and service providers from the database.
    
    Args:
        username (str): The username to query access filters for
        
    Returns:
        tuple: A tuple containing two elements:
            - customer (tuple or None): List of customer IDs the user has access to
            - service_provider (tuple or None): List of service provider IDs the user has access to
            
    Raises:
        No exceptions are raised as they are caught and logged internally
    """
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

    filters=common_utils_database.get_data('users',{'username':username},['customers','service_provider'])
    try:
        customer=tuple(json.loads(filters['customers'].to_list()[0]))
    except Exception as e:
        logging.info(f"### get_user_acess_filters customer exception : {e}")
        customer=None
    try:
        service_provider=tuple(json.loads(filters['service_provider'].to_list()[0]))
    except Exception as e:
        logging.info(f"### get_user_acess_filters service_provider exception : {e}")
        service_provider=None

    return customer,service_provider


def sync_data_bulk_change():
    """
    Synchronizes data between systems by making API calls for three different Altaworx data types.
    
    This function makes three sequential API calls to synchronize device data, device tenant data,
    and device history data for Altaworx. Each call is made to the same endpoint but with different
    job names. The function handles exceptions for each call separately to ensure that a failure in
    one call doesn't prevent the others from executing.
    
    Returns:
        bool: True indicating the function completed execution, regardless of API call success
    """
    try:
        sync_url = os.environ["SYNC_API_URL"]
        # sync_url = "https://8x5f1gkyk7.execute-api.us-east-1.amazonaws.com/uat/migration_management_uat"
        sync_payload = {
                    "path": "/main_migration_func",
                    "job_name": "device_altaworx"
                    }
        sync_response = requests.post(sync_url, json=sync_payload)
        logging.info(f"Sync API response: {sync_response.json()}")
        if sync_response.status_code == 200:
            current_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            logging.info(f"### sync_data_bulk_change device_altaworx API call successful. Data sync completed at {current_timestamp}")
        else:
            logging.error(f"### sync_data_bulk_change device_altaworx API sync call failed with status code: {sync_response.status_code}")
    except Exception as sync_exception:
        logging.error(f"### sync_data_bulk_change device_altaworx Error occurred while calling the sync API: {sync_exception}")

    try:
        sync_url = os.environ["SYNC_API_URL"]
        # sync_url = "https://8x5f1gkyk7.execute-api.us-east-1.amazonaws.com/uat/migration_management_uat"
        sync_payload = {
                    "path": "/main_migration_func",
                    "job_name": "device_tenant_altaworx"
                    }
        sync_response = requests.post(sync_url, json=sync_payload)
        logging.info(f"Sync API response: {sync_response.json()}")
        if sync_response.status_code == 200:
            current_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            logging.info(f"### sync_data_bulk_change device_tenant_altaworx API call successful. Data sync completed at {current_timestamp}")
        else:
            logging.error(f"### sync_data_bulk_change device_tenant_altaworx API sync call failed with status code: {sync_response.status_code}")
    except Exception as sync_exception:
        logging.error(f"### sync_data_bulk_change device_tenant_altaworx Error occurred while calling the sync API: {sync_exception}")

    try:
        sync_url = os.environ["SYNC_API_URL"]
        # sync_url = "https://8x5f1gkyk7.execute-api.us-east-1.amazonaws.com/uat/migration_management_uat"
        sync_payload = {
                    "path": "/main_migration_func",
                    "job_name": "device_history_altaworx"
                    }
        sync_response = requests.post(sync_url, json=sync_payload)
        logging.info(f"Sync API response: {sync_response.json()}")
        if sync_response.status_code == 200:
            current_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            logging.info(f"### sync_data_bulk_change device_history_altaworx API call successful. Data sync completed at {current_timestamp}")
        else:
            logging.error(f"### sync_data_bulk_change device_history_altaworx API sync call failed with status code: {sync_response.status_code}")
    except Exception as sync_exception:
        logging.error(f"### sync_data_bulk_change device_history_altaworx Error occurred while calling the sync API: {sync_exception}")

    return True

def sync_data_bulk_change_tables(data):
    """
    Synchronizes bulk change data tables by making an API call to run a database script.
    
    This function takes input data, adds a path parameter for the database script endpoint,
    and sends the data to the sync API. It logs the response and any errors that occur during
    the process.
    
    Args:
        data (dict): The data to be synchronized, which will be modified to include the path parameter
        
    Returns:
        bool: True indicating the function completed execution, regardless of API call success
    """
    data["path"] = '/run_db_script'
    try:
        sync_url = os.environ["KORE_10_BULKCHANGE_SYNC"]
        # sync_url = 'https://demo-api.amop.services/sim_management_uat'
        api_payload = {"data":data}
        logging.info(f"### sync_data_bulk_change_tables API payload: {api_payload}")
        sync_response = requests.post(sync_url, json=api_payload)
        logging.info(f"Sync API response: {sync_response.json()}")
        if sync_response.status_code == 200:
            current_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            logging.info(f"### sync_data_bulk_change_tables run_db_script API call successful. Data sync completed at {current_timestamp}")
        else:
            logging.error(f"### sync_data_bulk_change_tables run_db_script API sync call failed with status code: {sync_response.status_code}")
    except Exception as sync_exception:
        logging.error(f"### sync_data_bulk_change_tables run_db_script Error occurred while calling the sync API: {sync_exception}")
    return True

def insert_history_data(db_config, tenant_database, iccid, service_provider):
    """
    Inserts a record into the device history table for the specified ICCID.
    
    This function creates a database connection and calls the stored procedure
    'usp_insert_into_history' to record history data for a device identified by its ICCID.
    Any exceptions during the process are caught and logged, but the function will
    always return True regardless of success or failure.
    
    Args:
        db_config (dict): Database configuration containing user, password, host, and port
        tenant_database (str): Name of the tenant database to connect to
        iccid (str): The ICCID of the device to record history for
        service_provider (str): The name of the service provider
        
    Returns:
        bool: True indicating the function completed execution, regardless of success
    """
    logging.info("### insert_history_data Entered to store device history")
    try:
        #hit the stored proc to insert into device history
        db_url = f"postgresql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{tenant_database}"
        engine = create_engine(db_url)

        with engine.connect() as connection:
            try:
                stored_proc_params = {
                    "inp_iccid": iccid,
                    "inp_service_provider_name": service_provider
                }
                connection.execute(
                    text(
                        "CALL usp_insert_into_history(:inp_iccid, :inp_service_provider_name)"
                    ),
                    stored_proc_params,
                )
                connection.commit()
            except Exception as e:
                logging.exception(
                    f"Error creating Rev.io service Line: {e}"
                )

            logging.info("### insert_history_data insert completed")
    except Exception as e:
        logging.exception(f"### insert_history_data Device History Insertion Exception is {e}")
    return True




def insert_customer_rate_plan_history_data(db_config, tenant_database, bulk_change_id, customer_rate_plan_id, customer_rate_pool_id, effective_date, customer_data_allocation_mb):
    """
    Updates devices with customer rate plan changes and records the history.
    
    This function calls the stored procedure 'usp_device_bulk_change_customer_rate_plan_change_update_devices'
    to update devices associated with a bulk change request with new customer rate plan information.
    The function handles database connection, executes the stored procedure, and logs any errors.
    
    Args:
        db_config (dict): Database configuration containing user, password, host, and port
        tenant_database (str): Name of the tenant database to connect to
        bulk_change_id (int): ID of the bulk change request
        customer_rate_plan_id (int): ID of the customer rate plan to apply
        customer_rate_pool_id (int): ID of the customer rate pool to apply
        effective_date (str): Date when the rate plan change becomes effective
        customer_data_allocation_mb (int): Data allocation in megabytes for the customer
        
    Returns:
        bool: True indicating the function completed execution, regardless of success
    """
    logging.info(f"### insert_customer_rate_plan_history_data bulkchange_id : {bulk_change_id}")
    try:
        #hit the stored proc to insert into device history
        db_url = f"postgresql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{tenant_database}"
        engine = create_engine(db_url)

        with engine.connect() as connection:
            try:
                stored_proc_params = {
                    "p_bulk_change_id": bulk_change_id,
                    "p_customer_rate_plan_id": (customer_rate_plan_id),
                    "p_customer_rate_pool_id":(customer_rate_pool_id),
                    "p_effective_date":effective_date,
                    "p_customer_data_allocation_mb": customer_data_allocation_mb,
                    "p_need_to_mark_processed": False
                }
                logging.info(f"### insert_customer_rate_plan_history_data stored_proc_params: {stored_proc_params}")
                connection.execute(
                    text(
                        "SELECT * FROM usp_device_bulk_change_customer_rate_plan_change_update_devices("
                        ":p_bulk_change_id, :p_customer_rate_plan_id, :p_customer_rate_pool_id, "
                        ":p_effective_date, :p_customer_data_allocation_mb, :p_need_to_mark_processed)"
                    ),
                    stored_proc_params,
                )
                connection.commit()
            except Exception as e:
                logging.exception(
                    f"Error usp_device_bulk_change_customer_rate_plan_change_update_devices: {e}"
                )
    except Exception as e:
        logging.exception(f"### insert_customer_rate_plan_history_data Exception is {e}")
    return True





def check_iccids_exist(db_connection, iccids,service_provider):
    """
    Checks if all provided ICCIDs exist in the sim_management_inventory table and are active.
    
    Args:
        db_connection: Database connection object
        iccids (list): List of ICCIDs to check
        service_provider (str): Name of the service provider to filter by
        
    Returns:
        list or None: List of missing ICCIDs if any are not found, empty list if all exist,
                     or None if an error occurs during the check
    """
    try:
        # Query the 'sim_management_inventory' table to check if all ICCIDs are present and active
        existing_iccids = db_connection.get_data(
            'sim_management_inventory',
            {'iccid':iccids, 'is_active': True,'service_provider_display_name':service_provider},
            ['iccid']
        )

        # Check if the response is a DataFrame
        if not isinstance(existing_iccids, pd.DataFrame):
            logging.warning(f"### check_iccids_exist Unexpected response format: {existing_iccids}")
            return None

        # Extract the ICCIDs that are found in the database (convert DataFrame column to a list)
        existing_iccid_list = set(existing_iccids['iccid'].tolist())

        # Check if all provided ICCIDs are found in the database
        missing_iccids = [iccid for iccid in iccids if iccid not in existing_iccid_list]

        return missing_iccids  # Return the list of missing ICCIDs (empty if all are present)

    except Exception as e:
        logging.exception(f"### check_iccids_exist Error during ICCID check: {e}")
        return None




def update_customer_rate_plan(data):
    """
    Updates the customer rate plan and associated data for a list of ICCIDs in bulk.
    The function checks the validity of the provided ICCIDs, performs the necessary updates for each ICCID,
    and logs the results. It also tracks the success and failure counts, updating the respective bulk change record
    with the final status. Logs detailed information on each change request, including success and failure details.

    Args:
        data (dict): A dictionary containing the input data for the update, including:
            - 'db_name' (str): The name of the tenant database.
            - 'iccids' (list): A list of ICCIDs to be updated.
            - 'updated_data' (dict): The updated customer rate plan data.
            - 'service_provider' (str): The name of the service provider.
            - 'bulk_change_id' (str): The ID of the bulk change request.
            - 'username' (str): The username initiating the update.
            - 'request_received_at' (str): Timestamp when the request was received.
            - 'ui_session_id' (str): UI session ID for tracking the session.

    Returns:
        dict: A dictionary indicating the success or failure of the operation with a message:
            - 'flag' (bool): True if the update is successful, False if an error occurred.
            - 'message' (str): A descriptive message about the outcome.
            - 'response_api' (int): The status code of the external API sync request (if applicable).
    """

    logging.info(f"### update_customer_rate_plan Request Data Received : {data}")
    # Start time  and date calculation
    start_time = time.time()
    request_received_at = data.get('request_received_at', '')
    ui_session_id = data.get('sessionID', '')
    tenant_name = data.get('tenant_name', '')
    bulk_change_id = data.get('bulk_change_id', '')
    change_type = data.get("change_type", "")
    username = data.get('username', '')
    
    # Initialize log_entries at the beginning of the function
    log_entries = []
    
    # Database connection
    tenant_database = data.get("db_name", "")
    access_token = data.get("access_token", "")
    try:
        spectrotel_database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    
    service_provider = data.get('service_provider')

    # Extract ICCIDs from the input data
    iccids = data.get('iccids', [])
    try:
        if not iccids:
            logging.info("No ICCIDs provided.")
            return {"flag": False, "message": "No ICCIDs provided in the request."}

        # Use the new function to check for missing ICCIDs
        missing_iccids = check_iccids_exist(spectrotel_database, iccids, service_provider)

        if missing_iccids is None:
            return {"flag": False, "message": "An error occurred during the ICCID check."}

        if missing_iccids:
            bulk_change_validation_update(data)
            # If any ICCID is missing, return a message
            logging.info(f"The following ICCIDs are not associated with the {service_provider}: {', '.join(missing_iccids)}")

        updated_data = data.get('updated_data', {})
        customer_rate_plan_update_data = updated_data.get('CustomerRatePlanUpdate', {})
        changed_data = data.get('changed_data', {})
        customer_rate_plan_changed_data = changed_data.get('CustomerRatePlanUpdate', {})

        logging.info(f"customer_rate_plan_update_data: {customer_rate_plan_update_data}")

        # Extract values from changed_data to check for -1 or null
        customer_rate_plan_id_intent = customer_rate_plan_changed_data.get('CustomerRatePlanId')
        customer_rate_pool_id_intent = customer_rate_plan_changed_data.get('CustomerRatePoolId')
        
        # Determine if we need to update customer_rate_plan_id
        customer_rate_plan_id = None
        customer_rate_plan_name = None
        
        if customer_rate_plan_id_intent == -1:
            # Skip updating customer_rate_plan_id and customer_rate_plan_name
            logging.info("Skipping customer rate plan update (CustomerRatePlanId = -1)")
        elif customer_rate_plan_id_intent is None:
            # Set to None in the database
            logging.info("Setting customer rate plan to NULL (CustomerRatePlanId = null)")
        else:
            # Look up the customer_rate_plan_id as before
            raw_customer_rate_plan_name = customer_rate_plan_update_data.get('customer_rate_plan_name', '')
            customer_rate_plan_name = raw_customer_rate_plan_name.rsplit(" -- ", 1)[0] if raw_customer_rate_plan_name else ''
            
            if customer_rate_plan_name:
                # Define parameterized query
                customer_rate_plan_query = '''
                    SELECT id
                    FROM public.customerrateplan
                    WHERE rate_plan_name = %s
                    AND service_provider_name LIKE %s
                    AND is_active = True
                '''

                # Set query parameters
                params = [customer_rate_plan_name, f"%{service_provider}%"]

                # Execute the query
                df = spectrotel_database.execute_query(customer_rate_plan_query, params=params)

                # Handle results
                if df is not None and not df.empty:
                    customer_rate_plan_id = int(df['id'].iloc[0])  # Get first ID from results
                    logging.info(f"Found customer rate plan ID: {customer_rate_plan_id} for name: {customer_rate_plan_name}")
                else:
                    customer_rate_plan_id = None
                    logging.warning(f"No active customer rate plan found for name: {customer_rate_plan_name} and provider: {service_provider}")
            else:
                customer_rate_plan_id = None
                logging.warning("No customer rate plan name provided")

        # Determine if we need to update customer_rate_pool_id
        customer_rate_pool_id = None
        customer_rate_pool_name = None
        
        if customer_rate_pool_id_intent == -1:
            # Skip updating customer_rate_pool_id and customer_rate_pool_name
            logging.info("Skipping customer rate pool update (CustomerRatePoolId = -1)")
        elif customer_rate_pool_id_intent is None:
            # Set to None in the database
            logging.info("Setting customer rate pool to NULL (CustomerRatePoolId = null)")
        else:
            # Look up the customer_rate_pool_id as before
            customer_rate_pool_name = customer_rate_plan_update_data.get('customer_rate_pool_name', '')
            if customer_rate_pool_name:
                customer_rate_pool_name = customer_rate_pool_name.rsplit(" -- ", 1)[0]
                # Define parameterized query
                customer_rate_pool_query = '''
                    SELECT id
                    FROM public.customer_rate_pool
                    WHERE name = %s
                    AND service_provider_name LIKE %s
                    AND is_active = True
                '''

                # Set query parameters
                params = [customer_rate_pool_name, f"%{service_provider}%"]

                # Execute the query
                df = spectrotel_database.execute_query(customer_rate_pool_query, True, params=params)

                # Handle results
                if df is not None and not df.empty:
                    customer_rate_pool_id = int(df['id'].iloc[0])  # Get first ID from results
                    logging.info(f"Found customer rate pool ID: {customer_rate_pool_id} for name: {customer_rate_pool_name}")
                else:
                    customer_rate_pool_id = None
                    logging.warning(f"No active customer rate pool found for name: {customer_rate_pool_name} and provider: {service_provider}")
            else:
                customer_rate_pool_id = None
                logging.warning("No customer rate pool name provided")

        effective_date = customer_rate_plan_update_data.get('effective_date', None)

        # Prepare update_data only for fields that are not -1
        update_data = {}
        if customer_rate_plan_id_intent != -1:
            
            update_data["customer_rate_plan_id"] = customer_rate_plan_id
            update_data["customer_rate_plan_name"] = customer_rate_plan_name if customer_rate_plan_name else None
            
        if customer_rate_pool_id_intent != -1:
            update_data["customer_rate_pool_id"] = customer_rate_pool_id
            update_data["customer_rate_pool_name"] = customer_rate_pool_name if customer_rate_pool_name else None
            
        if effective_date:
            update_data["effective_date"] = effective_date

        # Only proceed with update if there is something to update
        if update_data:
            logging.info(f"Updating inventory with data: {update_data}")
            result = bulk_update_dict(spectrotel_database, update_data, iccids)
            failed_count = result['failed_count']
            updated_count = result['updated_count']
            successful_iccids = result['successful_iccids']
            failed_iccids = result['failed_iccids']
        else:
            # If nothing to update, consider all ICCIDs as successful
            logging.info("No fields to update, marking all ICCIDs as successful")
            updated_count = len(iccids)
            failed_count = 0
            successful_iccids = iccids
            failed_iccids = []
            
        if failed_count != 0:
            ##update the bulk change table for the success and failed count
            spectrotel_database.update_dict('sim_management_bulk_change', {
                "success": updated_count,
                "errors": failed_count,
                "status": "ERROR",
                "processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }, {'id': bulk_change_id})
        else:
            spectrotel_database.update_dict('sim_management_bulk_change', {
                "success": updated_count,
                "errors": failed_count,
                "status": "PROCESSED",
                "processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }, {'id': bulk_change_id})
            
        # Define the 'in_conditions' as a dictionary for the ICCID values
        ##update the success count in bulk change request
        changed_data_json = json.dumps(changed_data)
        
        bulk_change_request_ids = spectrotel_database.get_data(
            'sim_management_bulk_change_request',
            {'iccid': iccids, "bulk_change_id": bulk_change_id},
            ['id', 'iccid']
        ).to_dict(orient='records')
        iccid_to_request_id = {entry['iccid']: entry['id'] for entry in bulk_change_request_ids}

        if successful_iccids:
            update_success_values = {
                "status": "PROCESSED",
                "change_request": changed_data_json,
                "is_processed": True,
                "has_errors": False,
                "processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            in_conditions = {'iccid': successful_iccids}

            # Call update_dict function to update both fields for all active ICCIDs
            update_success = spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values=update_success_values,
                in_conditions=in_conditions  # Pass ICCID conditions using 'in_conditions'
            )

            # call insert_device_history_records to insert records into device_history tables
            thread = threading.Thread(target=insert_device_history_records, 
                                     args=(tenant_name, username, successful_iccids, service_provider, tenant_database),
                                     kwargs={"access_token": access_token, "effective_date": effective_date})
            thread.start()
            
            processd_flag = True
            for iccid in successful_iccids:
                bulk_change_request_id = iccid_to_request_id.get(iccid)
                # Log entry for each ICCID
                log_entry = {
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": bulk_change_request_id,
                    "log_entry_description": f"Processing ICCID: {iccid}",
                    "request_text": changed_data_json,
                    "has_errors": False,
                    "response_status": "PROCESSED" if processd_flag else "ERROR",
                    "response_text": "OK",
                    "error_text": "",
                    "processed_date": datetime.datetime.now(),
                    "processed_by": username,
                    "created_by": username,
                    "created_date": datetime.datetime.now(),
                    "is_deleted": False,
                    "is_active": True
                }
                log_entry['processed_date'] = log_entry['processed_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entry['created_date'] = log_entry['created_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entries.append(log_entry)
            spectrotel_database.insert_data(log_entries, "sim_management_bulk_change_log")

        if failed_iccids:
            update_failed_values = {
                "status": "ERRORS",
                "change_request": changed_data_json,
                "is_processed": False,
                "has_errors": True,
                "processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            in_conditions = {'iccid': failed_iccids}

            # Call update_dict function to update both fields for all active ICCIDs
            update_success = spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values=update_failed_values,
                in_conditions=in_conditions  # Pass ICCID conditions using 'in_conditions'
            )
            processd_flag = False
            # Fix: Should iterate over failed_iccids, not successful_iccids
            for iccid in failed_iccids:
                bulk_change_request_id = iccid_to_request_id.get(iccid)
                # Log entry for each ICCID
                log_entry = {
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": bulk_change_request_id,
                    "log_entry_description": f"Processing ICCID: {iccid}",
                    "request_text": changed_data_json,
                    "has_errors": True,  # Fix: This should be True for failed entries
                    "response_status": "ERROR" if not processd_flag else "SUCCESS",  # Fix: Logic was reversed
                    "response_text": "OK",
                    "error_text": "Failed to Update Customer Rate Plan",
                    "processed_date": datetime.datetime.now(),
                    "processed_by": username,
                    "created_by": username,
                    "created_date": datetime.datetime.now(),
                    "is_deleted": False,
                    "is_active": True
                }
                log_entry['processed_date'] = log_entry['processed_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entry['created_date'] = log_entry['created_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entries.append(log_entry)
            spectrotel_database.insert_data(log_entries, "sim_management_bulk_change_log")

        if iccids:
            customer_data_allocation_mb = None
            insert_customer_rate_plan_history_data(
                db_config,
                tenant_database,
                bulk_change_id or None,  # Convert empty string to None
                customer_rate_plan_id or None,
                customer_rate_pool_id or None,
                effective_date or None,
                customer_data_allocation_mb or None
            )

        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "sm bulk change",
                "created_date": request_received_at,
                "created_by": username,
                "status": "True",  # Fix: This should reference the actual response flag
                "time_consumed_secs": time_consumed,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": 'Update Customer Rate Plan for BULK ICCIDS has been called successfully',
                "module_name": "Bulk Change Lambda",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
        
        # If update is successful
        response = {"flag": True, "message": " customer rate plan updated sucessfully "}
        return response

    except Exception as e:
        # Handle any errors that occur during the process
        logging.exception(f"Error updating customer rate plan: {e}")
        error_type = str(type(e).__name__)
        message = f"An error occurred while updating the customer rate plan{e}"
        # Error logging
        error_data = {
            "service_name": "sm bulk change",
            "created_date": request_received_at,
            "error_message": message,
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Bulk Change",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "An error occurred while updating the customer rate plan."}
    
    


import re
_COLUMN_NAME_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')

def bulk_update_dict(db_connection, update_data, iccids, table_name='sim_management_inventory'):
    """
    Bulk updates records in the specified table for the provided ICCIDs using a batch update for speed.
    Tracks how many updates are successful and how many failed, and returns lists of successful and failed ICCIDs.

    Args:
        db_connection: Database connection object
        update_data: Dictionary containing the fields to be updated
        iccids: List of ICCIDs to be updated
        table_name: The table where the updates will happen (default: 'sim_management_inventory')

    Returns:
        dict: A dictionary with the counts of successful and failed updates, and lists of successful and failed ICCIDs
    """
    updated_count = 0
    failed_count = 0
    successful_iccids = []
    failed_iccids = []

    try:
        if not isinstance(iccids, list):
            raise ValueError("iccids must be a list of ICCID values.")
        if not all(isinstance(iccid, str) for iccid in iccids):
            raise ValueError("All ICCIDs should be strings.")
        if not update_data:
            # Nothing to update
            return {
                "updated_count": 0,
                "failed_count": 0,
                "successful_iccids": [],
                "failed_iccids": iccids
            }

        # Validate column names to avoid SQL injection
        for col in update_data.keys():
            if not _COLUMN_NAME_RE.match(col):
                raise ValueError(f"Invalid column name detected: {col}")

        # Build SET clauses and params (use %s placeholders so None -> NULL)
        set_clauses = []
        params = []
        for col, val in update_data.items():
            set_clauses.append(f"{col} = %s")
            params.append(val)   # None stays None -> becomes SQL NULL

        # Build IN-clause placeholders and extend params with iccids
        iccid_placeholders = ", ".join(["%s"] * len(iccids))
        params.extend(iccids)

        sql = f"""
        UPDATE {table_name}
        SET {', '.join(set_clauses)}
        WHERE iccid IN ({iccid_placeholders})
        RETURNING iccid
        """

        # Debug: log template and params (params may contain None)
        logging.debug("bulk_update_dict SQL template: %s", sql)
        logging.debug("bulk_update_dict params: %r", params)

        start_time = time.time()
        # Use named arg params; your DB wrapper earlier accepted execute_query(sql, params=params)
        result = db_connection.execute_query(sql, params=params)

        # Handle result - DB wrapper might return a pandas DataFrame
        if isinstance(result, pd.DataFrame) and not result.empty:
            updated_iccids = result['iccid'].tolist()
        elif isinstance(result, list):
            # in case execute_query returns list of tuples
            updated_iccids = [r[0] for r in result]
        else:
            updated_iccids = []

        updated_iccids = list(dict.fromkeys(updated_iccids))  # preserve order, unique
        updated_count = len(updated_iccids)
        failed_count = len(iccids) - updated_count
        successful_iccids = updated_iccids
        failed_iccids = [iccid for iccid in iccids if iccid not in updated_iccids]

        end_time = time.time()
        logging.info(f"bulk_update_dict: Updated {updated_count} ICCIDs, failed {failed_count}. Time: {end_time - start_time:.6f}s")

    except Exception as e:
        logging.exception("Error during bulk_update_dict: %s", e)
        # mark all as failed on exception
        failed_count = len(iccids)
        failed_iccids = iccids
        updated_count = 0
        successful_iccids = []

    return {
        "updated_count": updated_count,
        "failed_count": failed_count,
        "successful_iccids": successful_iccids,
        "failed_iccids": failed_iccids
    }






def update_edit_cost_center(data):
    """
        Updates the cost center for a given set of ICCIDs in a bulk change request.
        It validates ICCIDs, processes them using external API calls, logs the results,
        and updates the database with the new cost center for successful ICCIDs.

        Args:
            data (dict): A dictionary containing various parameters, including:
                - 'request_received_at': Timestamp of when the request was received
                - 'sessionID': Session ID for tracking the user session
                - 'tenant_name': Tenant name for multi-tenant database support
                - 'username': User who is initiating the request
                - 'changed_data': Contains the fields to be updated (e.g., 'CostCenter1')
                - 'iccids': List of ICCIDs to be processed
                - 'service_provider': The name of the service provider
                - 'carrier_api_status': Flag indicating whether to raise an error if carrier API fails
                - 'bulk_change_id': The ID of the bulk change request

        Returns:
            dict: A dictionary with the following keys:
                - 'flag': True if all ICCIDs were successfully updated, False if any failed
                - 'message': A message indicating success or failure with details about failed ICCIDs
                - 'response_api': The status code of the API response for further tracking

        Raises:
            Exception: If any unexpected errors occur during processing, an exception is raised and logged.

        The function performs the following tasks:
            - Validates the input data and connects to the relevant databases.
            - Verifies the existence of the provided ICCIDs and ensures they are associated with the service provider.
            - Retrieves authentication details for external services.
            - Processes each ICCID by sending requests to external systems (core and RevIO requests).
            - Logs the results for each ICCID and updates the database for successful/failed ICCIDs.
            - Tracks the time taken for the process and updates an audit log for monitoring.
    """
    logging.info(f"### update_edit_cost_center Request Data Received : {data}")
    # Start time  and date calculation
    start_time = time.time()
    request_received_at = data.get('request_received_at', '')
    ui_session_id = data.get('sessionID', '')
    tenant_name = data.get('tenant_name', '')
    username = data.get('username', '')
    # change_type= data.get('change_type', '')
    changed_data = data.get("changed_data", {})
    carrier_api_status=data.get('carrier_api_status',False)
    bulk_change_id = data.get('bulk_change_id')

    # Database connection
    tenant_database = data.get("db_name", "")
    try:
        spectrotel_database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}

    service_provider = data.get('service_provider')
    iccids = data.get('iccids', [])

    serviceprovider_data = spectrotel_database.get_data(
                        "serviceprovider",
                        {"service_provider_name": service_provider},
                        ["integration_id", "id"],
                    )
    # integration_id = serviceprovider_data["integration_id"].to_list()[0]
    service_provider_id = serviceprovider_data["id"].to_list()[0]

    try:
        if not iccids:
            logging.warning("No ICCIDs provided.")
            return {"flag": False, "message": "No ICCIDs provided in the request."}

        # Check if ICCIDs exist
        missing_iccids = check_iccids_exist(spectrotel_database, iccids, service_provider)

        if missing_iccids is None:
            return {"flag": False, "message": "An error occurred during the ICCID check."}

        if missing_iccids:
            bulk_change_validation_update(data)
            logging.info(f"The following ICCIDs are not associated with the {service_provider}: {', '.join(missing_iccids)}")


        for iccid in iccids:
            insert_history_data(db_config, tenant_database, iccid, service_provider)

        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        tenant_id=common_utils_database.get_data('tenant',{"tenant_name":tenant_name},['id'])['id'].to_list()[0]
        try:
            json_data = load_json()
            koreids=get_provider_ids(json_data, tenant_name, ["Koremain"])
        except Exception as e:
            logging.info(f"### update_edit_cost_center Exception while getting the service provider id : {e}")
            # kore_ids=[]
        kore_id = koreids[0] if koreids else None
        kore_integration_id = get_integration_id_by_unique_name(json_data, tenant_name, "Koremain")

        account_id, access_token = get_account_id_(data,tenant_id,kore_id,kore_integration_id)
        cost_center_pk = changed_data.get("CostCenter1").split(
                                    "--", 1
                                )[1].strip()
        cost_center_name = changed_data.get("CostCenter1").split(
                                    "--", 1
                                )[0].strip()
        contact_name = changed_data.get("ContactName")

        if contact_name is None and cost_center_pk is None:
            return {"flag": False, "message": "Username or Cosr center is missing ."}
        #Fetch the authenticaion details
        autentication_details = common_utils_database.get_data(
                            "integration_authentication",
                            {"authentication_type": 13, "integration_id": 3},
                        ).to_dict(orient="records")[0]

        if not autentication_details:
            logging.error("Authentication details not found.")
            return {"flag": False, "message": "Authentication details missing."}

        username_api = autentication_details["username"]
        password = autentication_details["password"]
        # client_id = autentication_details["oauth2_client_id"]
        # client_secret = autentication_details["oauth2_client_secret"]
        token = autentication_details["token_value"]

        # Track success and failure
        successful_iccids = []
        failed_iccids = []
        # log_entries = []  # List to store log entries for bulk insert
        bulk_change_request_ids = spectrotel_database.get_data(
            'sim_management_bulk_change_request',
            {'iccid': iccids,"bulk_change_id":bulk_change_id},
            ['id', 'iccid']
        ).to_dict(orient='records')
        iccid_to_request_id = {entry['iccid']: entry['id'] for entry in bulk_change_request_ids}
        # Process each ICCID separately
        for iccid in iccids:
            bulk_change_request_id = iccid_to_request_id.get(iccid)
            processd_flag = False  # Reset processed flag for each ICCID

            subscription_id = changed_data.get("subscription_id", None)
            if subscription_id is None:
                query = f"select subscription_id from sim_management_inventory where iccid='{iccid}'"
                subscription_id = spectrotel_database.execute_query(query,True)
                subscription_id = subscription_id["subscription_id"].to_list()[0]

            # Send core request first
            response_api_lambda = send_core_request(cost_center_pk, subscription_id, account_id, access_token)
            logging.info(f"Response from Kore API Update Cost Center: {response_api_lambda}")

            if response_api_lambda["flag"]:
                processd_flag = True

            # Fetch device/service details for ICCID

            query = f"""
                SELECT smi.device_id, smi.mobility_device_id,
                    dt.rev_service_id AS m_rev_service_id,
                    mdt.rev_service_id AS d_rev_service_id
                FROM sim_management_inventory smi
                LEFT JOIN device_tenant dt ON dt.device_id = smi.device_id
                LEFT JOIN mobility_device_tenant mdt ON mdt.mobility_device_id = smi.mobility_device_id
                WHERE iccid = '{iccid}'
            """
            service_id_data = spectrotel_database.execute_query(query, True)
            m_rev_service_id = service_id_data["m_rev_service_id"].to_list()[0]
            d_rev_service_id = service_id_data["d_rev_service_id"].to_list()[0]

            main_url = spectrotel_database.get_data(
                "inventory_actions_urls",
                {"service_provider_id": str(service_provider_id), "action": "Edit Cost Center"},
                ["main_url"],
            )["main_url"].to_list()[0]

            if response_api_lambda["flag"]:
                processd_flag = True  # Core request succeeded

            # Send RevIO requests if service IDs exist
            if m_rev_service_id:
                if contact_name:
                    response_revio_m = send_revio_request_username(
                        m_rev_service_id, username_api, password, token, main_url, contact_name
                    )
                else:
                    response_revio_m = send_revio_request(
                        m_rev_service_id, username_api, password, token, main_url, cost_center_pk
                    )

                if response_revio_m["flag"]:
                    processd_flag = True

            if d_rev_service_id:
                if contact_name:
                    response_revio_d = send_revio_request_username(
                        d_rev_service_id, username_api, password, token, main_url, contact_name
                    )
                else:
                    response_revio_d = send_revio_request(
                        d_rev_service_id, username_api, password, token, main_url, cost_center_pk
                    )

                if response_revio_d["flag"]:
                    processd_flag = True

            # Prepare the update data
            if not processd_flag and carrier_api_status:
                if 'message' in response_api_lambda:
                    raise ValueError(f"{response_api_lambda['message']}")
                else:
                    logging.exception(f"### update_edit_cost_center carrier_api_status is {carrier_api_status}  so raising an exception here")
                    raise ValueError("""Request was not processed!""")

            # Log entry for each ICCID
            log_entry = {
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": bulk_change_request_id,
                "log_entry_description": f"Processing ICCID: {iccid}",
                "request_text": json.dumps(changed_data),
                "has_errors": not processd_flag,
                "response_status": "SUCCESS" if processd_flag else "ERROR",
                "response_text": json.dumps(response_api_lambda),
                "error_text": response_api_lambda.get("error", "") if not processd_flag else "",
                "processed_date": datetime.datetime.now(),
                "processed_by": username,
                "created_by": username,
                "created_date": datetime.datetime.now(),
                "is_deleted": False,
                "is_active": True
            }
            spectrotel_database.insert_data(log_entry, "sim_management_bulk_change_log")

            if processd_flag:
                successful_iccids.append(iccid)
            else:
                failed_iccids.append(iccid)

        # Update data for bulk update
        update_data = {}

        if cost_center_name:
            update_data["cost_center"] = cost_center_name

        if contact_name:
            update_data["username"] = contact_name


        result = bulk_update_dict(spectrotel_database, update_data, successful_iccids)
        logging.info(f"Result of bulk update: {result}")

        # Get update results
        failed_count = result['failed_count']
        updated_count = result['updated_count']

        # Update `sim_management_bulk_change` table
        bulk_change_id = data.get('bulk_change_id')  # Ensure bulk_change_id is included in the request
        if failed_count != 0:
            spectrotel_database.update_dict(
                'sim_management_bulk_change',
                {"success": updated_count, "errors": failed_count, "status": "ERROR"},
                {'id': bulk_change_id}
            )
        else:
            spectrotel_database.update_dict(
                'sim_management_bulk_change',
                {"success": updated_count, "errors": failed_count, "status": "PROCESSED"},
                {'id': bulk_change_id}
            )

        # Update `sim_management_bulk_change_request` for successful and failed ICCIDs
        if successful_iccids:
            spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values={
                    "status": "PROCESSED",
                    #"change_request": json.dumps(changed_data['change_request']),
                    "is_processed": True,
                    "has_errors": False
                },
                in_conditions={'iccid': successful_iccids}
            )

            # call insert_device_history_records to insert records into device_history tables
            thread = threading.Thread(target=insert_device_history_records,args=(tenant_name,username,successful_iccids,service_provider,tenant_database))
            thread.start()

        if failed_iccids:
            spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values={
                    "status": "ERRORS",
                    #"change_request": json.dumps(changed_data['change_request']),
                    "is_processed": False,
                    "has_errors": True
                },
                in_conditions={'iccid': failed_iccids}
            )

        # Async sync between 1.0 and 2.0
        # def start_sync():
        #     data["bulk_chnage_id_20"] = bulk_change_id
        #     bulk_change_id_ = spectrotel_database.get_data(
        #         "sim_management_bulk_change",
        #                 {"id": bulk_change_id},  # Filter condition
        #                 [
        #                     "change_request_type",
        #                     "change_request_type_id",
        #                     "created_by",
        #                     "is_active",
        #                     "is_deleted",
        #                     "modified_by",
        #                     "processed_by",
        #                     "service_provider_id",
        #                     "service_provider",
        #                     "status",
        #                     "tenant_id",
        #                     "uploaded",
        #                 ],  # Fields to retrieve
        #             ).to_dict("records")

        #     data["data"]["sim_management_bulk_change"] = bulk_change_id_

        #     try:
        #         sync_call = sync_data_bulk_change()
        #         sync_data_bulk_change_tables(data)
        #         if sync_call:
        #             logging.info("Sync call completed")
        #             spectrotel_database.update_dict(
        #                 "sim_management_bulk_change",
        #                 {"progress": "Sync Completed"},
        #                 {"id": bulk_change_id},
        #             )
        #     except Exception as e:
        #         logging.exception(f"Failed to sync in update_assign_customer: {e}")

        # threading.Thread(target=start_sync).start()

        if iccids:
            customer_data_allocation_mb = None
            customer_rate_plan_id = None
            customer_rate_pool_id = None
            effective_date = None
            insert_customer_rate_plan_history_data(
                db_config,
                tenant_database,
                bulk_change_id or None,  # Convert empty string to None
                customer_rate_plan_id or None,
                customer_rate_pool_id or None,
                effective_date or None,
                customer_data_allocation_mb or None
            )


        # End time calculation
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))

        # Log audit data
        try:
            audit_data_user_actions = {
                "service_name": "update_edit_cost_center",
                "created_date": request_received_at,
                "created_by": username,
                "status": "PROCESSED" if failed_count == 0 else "ERROR",
                "time_consumed_secs": time_consumed,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": 'Update Cost Center and Username Lambda has been called successfully',
                "module_name": "sm bulk change",
                "request_received_at": request_received_at,
                "trace_id": json.dumps(response_api_lambda)
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit log exception: {e}")

        # Final response
        return {
            "flag": True if failed_count == 0 else False,
            "message": "Cost Center update successful for all ICCIDs." if failed_count == 0 else
            f"Cost Center update failed for {failed_count} ICCIDs."
        }

    except Exception as e:
        error_type = str(type(e).__name__)
        message = f"An error occurred while updating the Cost Center: {e}"

        # Log error
        error_data = {
            "service_name": "update_edit_cost_center",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "sm bulk change",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": f"An error occurred while updating the Cost Center.{e}"}


def update_assign_customer(data):
    """
    Updates customer details for a bulk change request involving ICCIDs. The function handles
    validation, database updates, external API interactions, and logging. It processes each ICCID
    individually, updates relevant customer information, and syncs with an external service (RevIO).

    Args:
        data (dict): A dictionary containing various parameters, including:
            - 'request_received_at': Timestamp of when the request was received
            - 'sessionID': Session ID for tracking the user session
            - 'tenant_name': Tenant name for multi-tenant database support
            - 'username': User who is initiating the request
            - 'bulk_change_id': ID for the bulk change request
            - 'iccids': List of ICCIDs to be processed
            - 'service_provider': The name of the service provider
            - 'db_name': Name of the tenant database

    Returns:
        dict: A dictionary with the following keys:
            - 'flag': True if all ICCIDs were successfully updated, False if any failed
            - 'message': A message indicating success or failure with details about failed ICCIDs
            - 'response_api': The status code of the external API response

    The function performs the following tasks:
        - Establishes database connections to tenant and common utils databases.
        - Validates ICCIDs to ensure they are associated with the correct service provider.
        - Fetches the bulk change request from the database and processes each ICCID.
        - Updates customer-related fields (e.g., rate plans, pools) in the database.
        - Logs actions and updates the status for each ICCID, marking them as processed or failed.
        - Interacts with the RevIO API to update external customer information.
        - Tracks processing time, and syncs the data with external services.
        - Handles exceptions by logging errors and updating the status accordingly.

    Raises:
        Exception: If any unexpected errors occur during processing, the function will log the error
        and return a failure message.
    """
    logging.info(f"### update_assign_customer Request Data Received : {data}")
    # Start time  and date calculation
    start_time = time.time()
    request_received_at = data.get("request_received_at", "")
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    bulk_change_id = data.get("bulk_change_id", None)
    customer_rate_plan = data.get("customer_rate_plan", None)
    # customer_rate_pool = data.get("customer_rate_pool", None)
    effective_date = data.get("effective_date", None)
    # change_type = data.get("change_type", "")
    status = "NEW"
    response_text = ""
    # Database connection
    tenant_database = data.get("db_name", "")
    try:
        spectrotel_database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    service_provider = data.get("service_provider")

    # Extract ICCIDs from the input data
    iccids = data.get("iccids", [])
    try:
        if not iccids:
            logging.info("No ICCIDs provided.")
            return {"flag": False, "message": "No ICCIDs provided in the request."}

        # Use the new function to check for missing ICCIDs
        missing_iccids = check_iccids_exist(
            spectrotel_database, iccids, service_provider
        )

        if missing_iccids is None:
            return {
                "flag": False,
                "message": "An error occurred during the ICCID check.",
            }

        if missing_iccids:
            bulk_change_validation_update(data)
            # If any ICCID is missing, return a message
            logging.info(f"The following ICCIDs are not associated with the {service_provider}: {', '.join(missing_iccids)}")


        for iccid in iccids:
            insert_history_data(db_config, tenant_database, iccid, service_provider)

        # If all ICCIDs are found, proceed to the next steps
        if bulk_change_id is None:
            logging.error("Bulk Change ID is missing.")
            return {"flag": False, "message": "Bulk Change ID is missing."}

        request_data = f"select * from sim_management_bulk_change_request where bulk_change_id = {bulk_change_id}"
        bulk_change_df = spectrotel_database.execute_query(request_data, True)
        # change_request = json.loads(result.to_dict(orient="records")[0]['change_request'])
        iccid_processing_status = {}
        # Track results
        successful_iccids = []
        failed_iccids = []
        # log_entries = []
        if tenant_name == "Altaworx Test":
            tenant_id = 1
        else:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
        logging.info(f"### update_assign_customer tenant_id: {tenant_id}")

        for _, row in bulk_change_df.iterrows():
            iccid = str(
                row["iccid"]
            )  # Ensure ICCID is string to avoid scientific notation
            change_request = json.loads(row["change_request"])
            bulk_change_request_id = row["id"]
            bc_log_action = {}
            rev_customer_name = change_request.get("RevCustomerName")
            rev_customer_id = change_request.get("RevCustomerId")
            # customer_id_query = f"select * from customers where customer_name = '{rev_customer_name} ({rev_customer_id})' and tenant_id='{tenant_id}'"
            # customer_id_data = spectrotel_database.execute_query(
            #     customer_id_query, True
            # )
            # customer_id_data = customer_id_data["id"][0]

            update_params = {
                "account_number": str(change_request.get("RevCustomerId")),
                "customer_name": f"{rev_customer_name} ({rev_customer_id})",
                "customer_id": int(change_request.get("SiteId")),
                "customer_rate_plan_id": change_request.get("CustomerRatePlan"),
                "customer_rate_plan_name": change_request.get("CustomerRatePlanName"),
                "customer_rate_plan_code": change_request.get("CustomerRatePlanCode"),
                "customer_rate_pool_id": change_request.get("CustomerRatePool"),
                "customer_rate_pool_name": change_request.get("CustomerRatePoolName"),
            }
            # Remove any key-value pairs where the value is "No options"
            update_params = {
                key: value
                for key, value in update_params.items()
                if value != "No options"
            }
            update_status_params = {
                "is_processed": True,
                "processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            try:
                spectrotel_database.update_dict(
                    "sim_management_inventory", update_params, {"iccid": iccid}
                )
                status = "PROCESSED"
                iccid_processing_status[iccid] = "PROCESSED"
                response_text = "OK"
                update_status_params["has_errors"] = False
            except Exception as e:
                logging.error(f"### update_assign_customer Error updating ICCID {iccid}: {e}")
                status = "Error"
                iccid_processing_status[iccid] = "ERROR"
                response_text = "ERROR"
                bc_log_action["error_text"] = e
                update_status_params["has_errors"] = True
            update_status_params["status"] = status


            bc_log_action["bulk_change_id"] = bulk_change_id
            bc_log_action["bulk_change_request_id"] = bulk_change_request_id
            bc_log_action["log_entry_description"] = "Assign Customer Details"
            bc_log_action["request_text"] = json.dumps(update_params)
            bc_log_action["response_text"] = response_text
            bc_log_action["has_errors"] = update_status_params["has_errors"]
            bc_log_action["response_status"] = update_status_params["status"]
            bc_log_action["processed_date"] = datetime.datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            )
            bc_log_action["processed_by"] = username
            bc_log_action["created_by"] = username
            bc_log_action["created_date"] = datetime.datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            )
            bc_log_action["is_deleted"] = False
            bc_log_action["is_active"] = True

            spectrotel_database.insert_data(
                bc_log_action, "sim_management_bulk_change_log"
            )


            # Update the bulk change request status here, after initial inventory update
            spectrotel_database.update_dict(
                "sim_management_bulk_change_request",
                update_status_params,
                {"iccid": iccid, "bulk_change_id": bulk_change_id},
            )




            service_type_id = change_request.get("ServiceTypeId", None)
            rev_product_id_list = change_request.get("RevProductIdList", None)
            if rev_product_id_list and service_type_id:
                logging.info(f"### update_assign_customer BC-Assign Customer: Updating RevIO for ICCID: {iccid}")
                try:
                    spectrotel_database = DB(tenant_database, **db_config)
                    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

                    # Create SQLAlchemy engine for stored procedures
                    db_url = f"postgresql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{tenant_database}"
                    engine = create_engine(db_url)
                except Exception as db_exception:
                    logging.error(
                        f"### update_assign_customer Failed to connect to the database: {str(db_exception)}"
                    )
                    return {
                        "error": "Database connection failed.",
                        "details": str(db_exception),
                    }

                # API Credentials
                # base_url = "https://api.revioapi.com/v1"
                base_url = os.getenv("REVIOAPI", " ")
                service_endpoint = f"{base_url}/Services"
                service_product_endpoint = f"{base_url}/ServiceProduct"
                # headers = {
                #     "Content-Type": "application/json",
                #     "Ocp-Apim-Subscription-Key": "0fc3f44bc0814510ba38c7fa27a151a7",
                #     "Authorization": "Basic QU1PUFRvUmV2aW9AYWx0YXdvcnhfc2FuZGJveDpHZW9sb2d5N0BTaG93aW5nQFN0YW5r",
                # }
                if tenant_name == "Altaworx Test" or  tenant_name == "Altaworx":
                    headers = {
                    "Ocp-Apim-Subscription-Key": os.getenv("REVIO_Subscription_Key_ALTAWOX", " "),
                    "Authorization": f"Basic {os.getenv('ALTAWOX_REVIO_acess_token', '')}",
                    "Accept": "application/json",
                    }
                else:
                    headers = {
                    "Ocp-Apim-Subscription-Key": os.getenv("REVIO_Subscription_Key_Go_Tech", " "),
                    "Authorization": f"Basic {os.getenv('Go_Tech_REVIO_acess_token', '')}",
                    "Accept": "application/json",
                    }

                try:
                    # Extract API parameters from change_request
                    change_request["RevPackageId"] = 0 if change_request.get("RevPackageId", 0) == "" else change_request.get("RevPackageId", 0)
                    service_params = {
                        "customer_id": change_request.get("RevCustomerId", ""),
                        "provider_id": change_request.get("ProviderId", ""),
                        "service_type_id": change_request.get("ServiceTypeId", ""),
                        "number": change_request.get("Number", ""),  # MSISDN
                        "effective_date": change_request.get("ActivatedDate", ""),
                        "activated_date": change_request.get("ActivatedDate", ""),
                        "number2": change_request.get("ICCID", iccid),  # Default to ICCID
                        "package_id": change_request.get("RevPackageId", 0),
                    }
                    usage_plan_group_id = change_request.get("UsagePlanGroupId", None)
                    if usage_plan_group_id is not None and usage_plan_group_id != "":
                        service_params["usage_plan_group_id"] = usage_plan_group_id

                    # API call
                    logging.info(f"### update_assign_customer BC-Assign Customer: Request data for creating RevIO Service: {service_params}")
                    response = requests.post(
                        service_endpoint, headers=headers, json=service_params
                    )
                    service_response_data = response.json()
                    logging.info(
                        f"### update_assign_customer Response data of Service Line: Status code - {response.status_code}, Response: {service_response_data}"
                    )
                    api_has_errors = response.status_code in (500, 504, 404, 400)

                    # Log API transaction
                    log_entry = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": bulk_change_request_id,
                            "processed_by": "SM_Bulk_Change",
                            "processed_date": datetime.datetime.utcnow().strftime(
                                "%Y-%m-%d %H:%M:%S"
                            ),
                            "log_entry_description": "Create Rev.io Service: Rev.io API",
                            "request_text": json.dumps(service_params, indent=2),
                            "response_text": json.dumps(
                                service_response_data, indent=2
                            ),
                            "response_status": (
                                "ERROR" if api_has_errors else "PROCESSED"
                            ),
                            "has_errors": True if api_has_errors else False,
                            "error_text": (
                                json.dumps(service_response_data)
                                if api_has_errors
                                else None
                            ),
                        }

                    spectrotel_database.insert_data(log_entry, "sim_management_bulk_change_log")

                    if api_has_errors:
                        failed_iccids.append(iccid)
                        # if log_entries:
                        #     for entry in log_entries:
                        #         spectrotel_database.insert_data(
                        #             "sim_management_bulk_change_log", entry
                        #         )
                        #     log_entries = []
                        update_status_params["status"] = "ERROR"
                        update_status_params["has_errors"] = True
                        spectrotel_database.update_dict(
                                "sim_management_bulk_change_request",
                                update_status_params,
                                {"iccid": iccid, "bulk_change_id": bulk_change_id},
                            )
                        continue

                    # If no errors, save to DB using stored procedure
                    if not api_has_errors:
                        service_stored_proc_params = {
                            "revcustomerid": str(service_params["customer_id"]),
                            "number": service_params["number"],
                            "revserviceid": int(service_response_data.get("id", 0)),
                            "revservicetypeid": int(service_params["service_type_id"]),
                            "revactivateddate": service_params["activated_date"],
                            "revproviderid": int(service_params.get("provider_id", 0)),
                            "revusageplangroupid": int(
                                service_params.get("usage_plan_group_id", 0)
                            ),
                            "deviceid": (
                                int(change_request.get("DeviceId", 0))
                                if change_request.get("DeviceId") is not None
                                else None
                            ),
                            "integrationauthenticationid": (
                                int(change_request.get("IntegrationAuthenticationId", 0))
                                if change_request.get("IntegrationAuthenticationId")
                                is not None
                                else None
                            ),
                        }
                        # Call stored procedure for service creation
                        with engine.connect() as connection:
                            try:
                                connection.execute(
                                    text(
                                        "CALL usp_revservice_create_service(:revcustomerid, :number, :revserviceid, "
                                        ":revservicetypeid, :revactivateddate, :revproviderid, :revusageplangroupid, "
                                        ":deviceid, :integrationauthenticationid)"
                                    ),
                                    service_stored_proc_params,
                                )
                                connection.commit()
                                service_db_has_errors = False
                                service_db_result = {"status": True}
                            except Exception as e:
                                service_db_has_errors = True
                                logging.exception(
                                    f"Error creating Rev.io service Line: {e}"
                                )
                                update_status_params["status"] = "ERROR"
                                update_status_params["has_errors"] = True
                                spectrotel_database.update_dict(
                                        "sim_management_bulk_change_request",
                                        update_status_params,
                                        {"iccid": iccid, "bulk_change_id": bulk_change_id},
                                    )
                                service_db_result = {"status": False, "message": str(e)}
                        service_db_result_status = service_db_result.get("status")

                        # Log Database transaction for service creation
                        log_entry = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": bulk_change_request_id,
                                "processed_by": username,
                                "processed_date": datetime.datetime.now().strftime(
                                    "%Y-%m-%d %H:%M:%S"
                                ),
                                "log_entry_description": "Create Rev.io Service: Update AMOP",
                                "request_text": json.dumps(
                                    service_stored_proc_params, indent=2
                                ),
                                "response_text": json.dumps(service_db_result, indent=2),
                                "response_status": (
                                    "ERROR" if service_db_has_errors else "PROCESSED"
                                ),
                                "has_errors": service_db_has_errors,
                                "error_text": (
                                    json.dumps(service_db_result)
                                    if not service_db_result_status
                                    else None
                                ),
                            }

                        spectrotel_database.insert_data(log_entry, "sim_management_bulk_change_log")
                        successful_iccids.append(iccid)
                        update_status_params["status"] = "PROCESSED"
                        update_status_params["has_errors"] = False
                        spectrotel_database.update_dict(
                                "sim_management_bulk_change_request",
                                update_status_params,
                                {"iccid": iccid, "bulk_change_id": bulk_change_id},
                            )

                    # If RevPackageId is null, create Rev.io service product
                    if not change_request.get("RevPackageId"):

                        service_product_params = {
                            "service_id": service_response_data.get("id", 0),
                            "product_id": change_request.get("RevProductIdList", [""])[0],
                            "rate": float(change_request.get("RateList", [0])[0]),
                            "prorate": change_request.get("Prorate", True),
                            "customer_id": service_params["customer_id"],
                            "quantity": 1,
                            "effective_date": service_params["effective_date"],
                            "activated_date": service_params["activated_date"],
                        }

                        # Create Service Product API call
                        product_response = requests.post(
                            service_product_endpoint,
                            headers=headers,
                            json=service_product_params,
                        )
                        product_response_data = product_response.json()
                        product_api_has_errors = product_response.status_code in (
                            500,
                            504,
                            404,
                            400,
                        )
                        logging.info(
                        f"Response data of Product: Status code - {product_response.status_code}, Response: {product_response_data}"
                        )
                        # Log Service Product API transaction
                        log_entry = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": bulk_change_request_id,
                                "processed_by": username,
                                "processed_date": datetime.datetime.now(),
                                "log_entry_description": "Create Rev.io Service Product: Rev.io API",
                                "request_text": json.dumps(
                                    service_product_params, indent=2
                                ),
                                "response_text": json.dumps(
                                    product_response_data, indent=2
                                ),
                                "response_status": (
                                    "ERROR" if product_api_has_errors else "PROCESSED"
                                ),
                                "has_errors": product_api_has_errors,
                                "error_text": (
                                    json.dumps(product_response_data)
                                    if product_api_has_errors
                                    else None
                                ),
                            }

                        spectrotel_database.insert_data(log_entry, "sim_management_bulk_change_log")

                        if product_api_has_errors:
                            failed_iccids.append(iccid)
                            # if log_entries:
                            #     for entry in log_entries:
                            #         spectrotel_database.insert_data(
                            #             "sim_management_bulk_change_log", entry
                            #         )
                            #     log_entries = []
                            update_status_params["status"] = "ERROR"
                            update_status_params["has_errors"] = True
                            spectrotel_database.update_dict(
                                    "sim_management_bulk_change_request",
                                    update_status_params,
                                    {"iccid": iccid, "bulk_change_id": bulk_change_id},
                                )
                            continue

                        if not product_api_has_errors:
                            # Call stored procedure for service product creation
                            with engine.connect() as connection:
                                product_stored_proc_params = {
                                    "rev_customer_id": str(service_params["customer_id"]),
                                    "rev_service_product_id": int(
                                        product_response_data.get("id", 0)
                                    ),
                                    "rev_product_id": int(
                                        service_product_params.get("product_id", 0)
                                    ),
                                    "rev_service_id": int(
                                        service_response_data.get("id", 0)
                                    ),
                                    "rate": float(service_product_params.get("rate")),
                                    "description": str(
                                        change_request.get("Description")
                                    ),
                                    "integration_authentication_id": int(
                                        change_request.get(
                                            "IntegrationAuthenticationId", None
                                        )
                                    ),
                                    "status": "Active",
                                    "package_id": int(
                                        change_request.get("RevPackageId", 0)
                                    ),
                                }

                                try:
                                    connection.execute(
                                        text(
                                            "CALL usp_revservice_create_serviceproduct(:rev_customer_id, :rev_service_product_id, "
                                            ":rev_product_id, :rev_service_id, :rate, :description, "
                                            ":integration_authentication_id, :status, :package_id)"
                                        ),
                                        product_stored_proc_params,
                                    )
                                    connection.commit()
                                    product_db_has_errors = False
                                    product_db_result = {"status": True}
                                except Exception as e:
                                    product_db_has_errors = True
                                    logging.exception(
                                        f"Error creating Rev.io service Line: {e}"
                                    )
                                    update_status_params["status"] = "ERROR"
                                    update_status_params["has_errors"] = True
                                    spectrotel_database.update_dict(
                                            "sim_management_bulk_change_request",
                                            update_status_params,
                                            {"iccid": iccid, "bulk_change_id": bulk_change_id},
                                        )
                                    product_db_result = {
                                        "status": False,
                                        "message": str(e),
                                    }
                            product_db_result_status = product_db_result.get("status")

                            # Log Database transaction for service product creation
                            log_entry = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": bulk_change_request_id,
                                    "processed_by": username,
                                    "processed_date": datetime.datetime.now().strftime(
                                        "%Y-%m-%d %H:%M:%S"
                                    ),
                                    "log_entry_description": "Create Rev.io Service Product: Update AMOP",
                                    "request_text": json.dumps(
                                        product_stored_proc_params, indent=2
                                    ),
                                    "response_text": json.dumps(
                                        product_db_result, indent=2
                                    ),
                                    "response_status": (
                                        "PROCESSED"
                                        if product_db_result_status
                                        else "ERROR"
                                    ),
                                    "has_errors": product_db_has_errors,
                                    "error_text": (
                                        json.dumps(product_db_result)
                                        if not product_db_result_status
                                        else None
                                    ),
                                }

                            spectrotel_database.insert_data(log_entry, "sim_management_bulk_change_log")

                            successful_iccids.append(iccid)
                            update_status_params["status"] = "PROCESSED"
                            update_status_params["has_errors"] = False
                            spectrotel_database.update_dict(
                                    "sim_management_bulk_change_request",
                                    update_status_params,
                                    {"iccid": iccid, "bulk_change_id": bulk_change_id},
                                )
                            logging.info(f"### create_rev_io_service successful_iccids: {successful_iccids}")
                except Exception as e:
                    failed_iccids.append(iccid)
                    logging.error(f"Error processing ICCID {iccid}: {str(e)}")

                # Bulk insert log entries
                # if log_entries:
                #     for entry in log_entries:
                #         spectrotel_database.insert_data(
                #             "sim_management_bulk_change_log", entry
                #         )

        # Determine final_status
        # final_status = (
        #     "ERROR" if "ERROR" in iccid_processing_status.values() else "PROCESSED"
        # )
        failed_count = len(failed_iccids)
        updated_count = len(successful_iccids)
        logging.info(
            f"### update_assign_customer Failed ICCIDs {failed_count}: {set(failed_iccids)}, Processed ICCIDs {updated_count}: {set(successful_iccids)}"
        )
        if failed_count != 0:
            final_status = "ERROR"
        else:
            final_status = "PROCESSED"
        spectrotel_database.update_dict(
            "sim_management_bulk_change",
            {"status": final_status},
            {"id": bulk_change_id},
        )

        # call insert_device_history_records to insert records into device_history tables
        thread = threading.Thread(target=insert_device_history_records,args=(tenant_name,username,successful_iccids,service_provider,tenant_database),
                                  kwargs={"effective_date": effective_date}
                                  )
        thread.start()

        # Async sync between 1.0 and 2.0
        # def start_sync():
        #     data["bulk_chnage_id_20"] = bulk_change_id
        #     bulk_change_id_ = spectrotel_database.get_data(
        #         "sim_management_bulk_change",
        #                 {"id": bulk_change_id},  # Filter condition
        #                 [
        #                     "change_request_type",
        #                     "change_request_type_id",
        #                     "created_by",
        #                     "is_active",
        #                     "is_deleted",
        #                     "modified_by",
        #                     "processed_by",
        #                     "service_provider_id",
        #                     "service_provider",
        #                     "status",
        #                     "tenant_id",
        #                     "uploaded",
        #                 ],  # Fields to retrieve
        #             ).to_dict("records")

        #     data["data"]["sim_management_bulk_change"] = bulk_change_id_
        #     try:
        #         sync_call = sync_data_bulk_change()
        #         sync_data_bulk_change_tables(data)
        #         if sync_call:
        #             logging.info("Sync call completed")
        #             spectrotel_database.update_dict(
        #                 "sim_management_bulk_change",
        #                 {"progress": "Sync Completed"},
        #                 {"id": bulk_change_id},
        #             )
        #     except Exception as e:
        #         logging.exception(f"Failed to sync in update_assign_customer: {e}")

        # threading.Thread(target=start_sync).start()

        customer_rate_pool_name = data.get("customer_rate_pool", None)
        if customer_rate_pool_name:
            customer_rate_pool_name = customer_rate_pool_name.rsplit(" -- ", 1)[0]
            # Define parameterized query
            customer_rate_pool_query = '''
                SELECT id
                FROM public.customer_rate_pool
                WHERE name = %s
                AND service_provider_name LIKE %s
                AND is_active = True
            '''

            # Set query parameters
            params = [customer_rate_pool_name, service_provider]

            # Execute the query
            df = spectrotel_database.execute_query(customer_rate_pool_query, True, params=params)

            # Handle results
            if df is not None and not df.empty:
                customer_rate_pool_id = df['id'].iloc[0]  # Get first ID from results
            else:
                customer_rate_pool_id = None
                logging.warning(f"No active customer rate pool found for name: {customer_rate_pool_name} and provider: {service_provider}")
            # customer_rate_pool_id=spectrotel_database.get_data('customer_rate_pool',{"name":customer_rate_pool_name,"is_active":True,"service_provider_name":service_provider},['id'])['id'].to_list()[0]

        customer_rate_plan = data.get("customer_rate_plan", None)
        if customer_rate_plan:
            customer_rate_plan.rsplit(" -- ", 1)[0]
            # Define parameterized query
            customer_rate_plan_query = '''
                SELECT id
                FROM public.customerrateplan
                WHERE rate_plan_name = %s
                AND service_provider_name LIKE %s
                AND is_active = True
            '''

            # Set query parameters
            params = [customer_rate_plan, f"%{service_provider}%"]

            # Execute the query
            df = spectrotel_database.execute_query(customer_rate_plan_query, params=params)

            # Handle results
            if df is not None and not df.empty:
                customer_rate_plan_id = df['id'].iloc[0]  # Get first ID from results
            else:
                customer_rate_plan_id = None
                logging.warning(f"No active customer rate plan found for name: {customer_rate_plan} and provider: {service_provider}")
            # customer_rate_plan_id=spectrotel_database.get_data('customerrateplan',{"rate_plan_name":customer_rate_plan,"is_active":True,"service_provider_name":service_provider},['id'])['id'].to_list()[0]

        if iccids:
            customer_data_allocation_mb = None
            insert_customer_rate_plan_history_data(
                db_config,
                tenant_database,
                bulk_change_id or None,  # Convert empty string to None
                customer_rate_plan_id or None,
                customer_rate_pool_id or None,
                effective_date or None,
                customer_data_allocation_mb or None
            )

        response = {"flag": True, "message": "Assign Customer update successful."}
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "update_assign_customer",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": f"Assigning Customer Bulk change {bulk_change_id} customer rate paln: {customer_rate_plan} for iccids: {iccids}",
                "module_name": "sm bulk change",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"Exception is {e}")
        # If update is successful
        return response

    except Exception as e:
        # Handle any errors that occur during the process
        logging.exception(f"Error updating Assign Customer: {e}")
        error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "update_assign_customer",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Assigning Customer Failed Bulk change {bulk_change_id} customer rate paln: {customer_rate_plan} for iccids: {iccids}",
            "module_name": "sm bulk change",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {
            "flag": False,
            "message": "An error occurred while updating the Assign Customer.",
        }

def create_rev_io_service(data):
    """
    Creates Rev.io service records for devices in a bulk change request.
    
    This function processes a bulk change request to create Rev.io service records for devices,
    makes API calls to the Rev.io service, and updates the database records. It handles both
    service creation and service product creation, tracks successful and failed operations,
    and updates the bulk change status accordingly.
    
    Args:
        data (dict): A dictionary containing request data, including:
            - 'request_received_at': Timestamp when the request was received
            - 'sessionID': Session ID for tracking
            - 'tenant_name': Name of the tenant
            - 'username': Username of the person initiating the request
            - 'service_provider': Name of the service provider
            - 'db_name': Name of the tenant database
            - 'bulk_chnage_id_20': ID of the bulk change request
    
    Returns:
        dict: A dictionary with status information:
            - 'flag' (bool): True if successful, False otherwise
            - 'message' (str): Description of the result or error
    """
    logging.info(f"### create_rev_io_service Request Data Received : {data}")
    # Start time  and date calculation
    start_time = time.time()
    request_received_at = data.get("request_received_at", "")
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    # change_type = data.get("change_type", "")
    service_provider = data.get("service_provider", None)
    iccids = data.get('iccids', [])

    # Database connection
    tenant_database = data.get("db_name", "")
    try:
        spectrotel_database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        # Create SQLAlchemy engine for stored procedures
        db_url = f"postgresql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{tenant_database}"
        engine = create_engine(db_url)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}

    bulk_change_id = data.get("bulk_chnage_id_20")

    try:

        if not bulk_change_id:
            logging.error("Bulk Change ID is missing.")
            return {"flag": False, "message": "Bulk Change ID is missing."}
        for iccid in iccids:
            insert_history_data(db_config, tenant_database, iccid, service_provider)


        # Fetch bulk change requests for the given bulk_change_id
        query = f"SELECT * FROM sim_management_bulk_change_request WHERE bulk_change_id = {bulk_change_id}"
        bulk_change_df = spectrotel_database.execute_query(query, True)

        # Track results
        successful_iccids = []
        failed_iccids = []
        # log_entries = []

        # API Credentials and endpoints
        # base_url = "https://api.revioapi.com/v1"
        base_url = os.getenv("REVIOAPI", " ")
        service_endpoint = f"{base_url}/Services"
        service_product_endpoint = f"{base_url}/ServiceProduct"

        # headers = {
        #     "Content-Type": "application/json",
        #     "Ocp-Apim-Subscription-Key": "0fc3f44bc0814510ba38c7fa27a151a7",
        #     "Authorization": "Basic QU1PUFRvUmV2aW9AYWx0YXdvcnhfc2FuZGJveDpHZW9sb2d5N0BTaG93aW5nQFN0YW5r",
        # }
        if tenant_name == "Altaworx Test" or  tenant_name == "Altaworx":
                headers = {
                "Ocp-Apim-Subscription-Key": os.getenv("REVIO_Subscription_Key_ALTAWOX", " "),
                "Authorization": f"Basic {os.getenv('ALTAWOX_REVIO_acess_token', '')}",
                "Accept": "application/json",
                }
        else:
            headers = {
            "Ocp-Apim-Subscription-Key": os.getenv("REVIO_Subscription_Key_Go_Tech", " "),
            "Authorization": f"Basic {os.getenv('Go_Tech_REVIO_acess_token', '')}",
            "Accept": "application/json",
            }

        # Process each ICCID
        iccids = []
        for _, row in bulk_change_df.iterrows():
            iccid = str(row["iccid"])
            iccids.append(iccid)
            bulk_change_request_id = row["id"]
            log_entries = []

            try:
                # Extract API parameters from change_request
                change_request = json.loads(row["change_request"])

                # Service creation parameters
                change_request["RevPackageId"] = 0 if change_request.get("RevPackageId", 0) == "" else change_request.get("RevPackageId", 0)
                service_params = {
                    "customer_id": change_request.get("RevCustomerId", ''),
                    "provider_id": change_request.get("ProviderId", ''),
                    "service_type_id": change_request.get("ServiceTypeId", ''),
                    "number": change_request.get("Number", ""),  # MSISDN
                    "effective_date": change_request.get("ActivatedDate", ""),
                    "activated_date": change_request.get("ActivatedDate", ""),
                    "number2": change_request.get("ICCID", iccid),  # ICCID
                    "package_id": change_request.get("RevPackageId", 0),
                }
                usage_plan_group_id = change_request.get("UsagePlanGroupId", None)
                if usage_plan_group_id is not None and usage_plan_group_id != "":
                    service_params["usage_plan_group_id"] = usage_plan_group_id

                # Create Service API call
                logging.info(f"BC-Assign Customer: Request data for creating RevIO Service: {service_params}")
                service_response = requests.post(service_endpoint, headers=headers, json=service_params)
                service_response_data = service_response.json()
                logging.info(
                        f"Response data of Service Line: Status code - {service_response.status_code}, Response: {service_response_data}"
                    )
                service_api_has_errors = service_response.status_code in (500, 504, 404, 400)

                # Log Service API transaction
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": bulk_change_request_id,
                    "processed_by": username,
                    "processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "log_entry_description": "Create Rev.io Service: Rev.io API",
                    "request_text": json.dumps(service_params, indent=2),
                    "response_text": json.dumps(service_response_data, indent=2),
                    "response_status": "ERROR" if service_api_has_errors else "PROCESSED",
                    "has_errors": service_api_has_errors,
                    "error_text": json.dumps(service_response_data) if service_api_has_errors else None,
                })

                if service_api_has_errors:

                    failed_iccids.append(iccid)
                    if log_entries:
                        spectrotel_database.insert_data(
                            "sim_management_bulk_change_log", log_entries
                        )
                        log_entries = []
                    continue

                service_stored_proc_params = {
                    "revcustomerid": str(service_params["customer_id"]),
                    "number": service_params["number"],
                    "revserviceid": int(service_response_data.get("id", 0)),
                    "revservicetypeid": int(service_params["service_type_id"]),
                    "revactivateddate": service_params["activated_date"],
                    "revproviderid": int(service_params.get("provider_id", 0)),
                    "revusageplangroupid": int(service_params.get("usage_plan_group_id", 0)),
                    "deviceid": int(change_request.get("DeviceId", 0)) if change_request.get("DeviceId") != "" else None,
                    "integrationauthenticationid": int(change_request.get("IntegrationAuthenticationId", 0)) if change_request.get("IntegrationAuthenticationId") != "" else None,
                }


                # Call stored procedure for service creation
                with engine.connect() as connection:
                    try:
                        # service_stored_proc_params = {
                        #     "revcustomerid": service_params["customer_id"],
                        #     "number": service_params["number"],
                        #     "revserviceid": int(service_response_data.get("service_id")),
                        #     "revservicetypeid": int(service_params["service_type_id"]),
                        #     "revactivateddate": service_params["activated_date"],
                        #     "revproviderid": int(service_params.get("provider_id", None)),
                        #     "revusageplangroupid": int(service_params.get("usage_plan_group_id", None)),
                        #     "deviceid": int(change_request.get("DeviceId", None)),
                        #     "integrationauthenticationid": int(change_request.get("IntegrationAuthenticationId", None)),
                        # }

                        connection.execute(
                            text("CALL usp_revservice_create_service(:revcustomerid, :number, :revserviceid, "
                                ":revservicetypeid, :revactivateddate, :revproviderid, :revusageplangroupid, "
                                ":deviceid, :integrationauthenticationid)"),
                            service_stored_proc_params
                        )
                        connection.commit()
                        service_db_has_errors = False
                        service_db_result = {"status": "success"}
                    except Exception as e:
                        service_db_has_errors = True
                        logging.exception(f"Error creating Rev.io service Line: {e}")
                        service_db_result = {"status": "error", "message": str(e)}

                # Log Database transaction for service creation
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": bulk_change_request_id,
                    "processed_by": username,
                    "processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "log_entry_description": "Create Rev.io Service: Update AMOP",
                    "request_text": json.dumps(service_stored_proc_params, indent=2),
                    "response_text": json.dumps(service_db_result, indent=2),
                    "response_status": "ERROR" if service_db_has_errors else "PROCESSED",
                    "has_errors": service_db_has_errors,
                    "error_text": json.dumps(service_db_result) if service_db_has_errors else None,
                })
                logging.info(f"### create_rev_io_service service_db_has_errors: {service_db_has_errors}")

                # If RevPackageId is null, create Rev.io service product
                if not change_request.get("RevPackageId"):
                    RevProductIdList = change_request.get("RevProductIdList")
                    RateList = change_request.get("RateList")
                    if len(RevProductIdList) == len(RateList):
                        for i in range(len(RevProductIdList)):
                            service_product_params = {
                                "service_id": service_response_data.get("id",0),
                                "product_id": RevProductIdList[i],
                                "rate": float(RateList[i]),
                                "prorate": change_request.get("Prorate", True),
                                "customer_id": service_params["customer_id"],
                                "quantity": 1,
                                "effective_date": service_params["effective_date"],
                                "activated_date": service_params["activated_date"],
                            }

                            # Create Service Product API call
                            product_response = requests.post(service_product_endpoint, headers=headers, json=service_product_params)
                            product_response_data = product_response.json()
                            product_api_has_errors = product_response.status_code in (500, 504, 404, 400)
                            logging.info(f"### create_rev_io_service product_api_has_errors: {product_api_has_errors}")
                            # Log Service Product API transaction
                            log_entries.append({
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": bulk_change_request_id,
                                "processed_by": username,
                                "processed_date": datetime.datetime.now(),
                                "log_entry_description": "Create Rev.io Service Product: Rev.io API",
                                "request_text": json.dumps(service_product_params, indent=2),
                                "response_text": json.dumps(product_response_data, indent=2),
                                "response_status": "ERROR" if product_api_has_errors else "PROCESSED",
                                "has_errors": product_api_has_errors,
                                "error_text": json.dumps(product_response_data) if product_api_has_errors else None,
                            })
                    else:
                        product_api_has_errors = True
                        product_response_data = {"flag": False, "message": "RevProductIdList and RateList are not of the same length."}
                        log_entries.append({
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": bulk_change_request_id,
                                "processed_by": username,
                                "processed_date": datetime.datetime.now(),
                                "log_entry_description": "Create Rev.io Service Product: Rev.io API",
                                "request_text": json.dumps(service_product_params, indent=2),
                                "response_text": json.dumps(product_response_data, indent=2),
                                "response_status": "ERROR" if product_api_has_errors else "PROCESSED",
                                "has_errors": product_api_has_errors,
                                "error_text": json.dumps(product_response_data) if product_api_has_errors else None,
                            })

                    if not product_api_has_errors:
                        # Call stored procedure for service product creation
                        with engine.connect() as connection:
                            product_stored_proc_params = {
                                    "rev_customer_id": str(service_params["customer_id"]),
                                    "rev_service_product_id": int(product_response_data.get("id", 0)),
                                    "rev_product_id": int(service_product_params.get("product_id", 0)),
                                    "rev_service_id": int(service_response_data.get("service_id", 0)),
                                    "rate": float(service_product_params.get("rate")),
                                    "description": str(change_request.get("Description")),
                                    "integration_authentication_id": int(change_request.get("IntegrationAuthenticationId", None)),
                                    "status": "Active",
                                    "package_id": int(change_request.get("RevPackageId", 0))
                                }

                            try:
                                connection.execute(
                                    text("CALL usp_revservice_create_serviceproduct(:rev_customer_id, :rev_service_product_id, "
                                        ":rev_product_id, :rev_service_id, :rate, :description, "
                                        ":integration_authentication_id, :status, :package_id)"),
                                    product_stored_proc_params
                                )
                                connection.commit()
                                product_db_has_errors = False
                                product_db_result = {"status": "success"}
                            except Exception as e:
                                product_db_has_errors = True
                                logging.exception(f"Error creating Rev.io service Line: {e}")
                                product_db_result = {"status": "error", "message": str(e)}


                        # Log Database transaction for service product creation
                        log_entries.append({
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": bulk_change_request_id,
                            "processed_by": username,
                            "processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "log_entry_description": "Create Rev.io Service Product: Update AMOP",
                            "request_text": json.dumps(product_stored_proc_params, indent=2),
                            "response_text": json.dumps(product_db_result, indent=2),
                            "response_status": "ERROR" if product_db_has_errors else "PROCESSED",
                            "has_errors": product_db_has_errors,
                            "error_text": json.dumps(product_db_result) if product_db_has_errors else None,
                        })

                        successful_iccids.append(iccid)
                        logging.info(f"successful_iccids: {successful_iccids}")
                    else:
                        logging.info("### create_rev_io_service goes here in this way")
                        failed_iccids.append(iccid)
                else:
                    successful_iccids.append(iccid)

            except Exception as e:
                logging.error(f"Error processing ICCID {iccid}: {str(e)}")
                failed_iccids.append(iccid)

        # Bulk insert log entries
        if log_entries:
            spectrotel_database.insert_data(log_entries, "sim_management_bulk_change_log")

        failed_count=len(failed_iccids)
        # updated_count=len(successful_iccids)
        logging.info(f"### create_rev_io_service failed_count: {failed_count}")
        logging.info(f"successful_iccids: {successful_iccids}")
        if failed_count!=0:
                ##update the bulk change table for the success and failed count
            spectrotel_database.update_dict('sim_management_bulk_change',{"status":"ERROR","processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")},{'id':bulk_change_id})
        else:
            spectrotel_database.update_dict('sim_management_bulk_change',{"status":"PROCESSED","processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")},{'id':bulk_change_id})
        # Define the 'in_conditions' as a dictionary for the ICCID values

        # Update `sim_management_bulk_change_request`
        if successful_iccids:
            logging.info(f"### create_rev_io_service successful_iccids: {successful_iccids}")
            for iccid in successful_iccids:
                spectrotel_database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "PROCESSED", "is_processed": True, "has_errors": False},
                    {"iccid": iccid}
                )
        if failed_iccids:
            for iccid in failed_iccids:
                spectrotel_database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR", "is_processed": False, "has_errors": True},
                    {"iccid": iccid}
                )

        # Handling for variance purpose
        # Fetch all relevant ICCIDs from both tables in a single query each
        iccids_str = ", ".join(f"'{iccid}'" for iccid in iccids)

        # Fetch matching records from sim_management_inventory
        find_query_inventory = f"""
            SELECT iccid FROM sim_management_inventory
            WHERE iccid IN ({iccids_str}) AND bulk_change_id = {bulk_change_id}
        """
        existing_inventory = spectrotel_database.execute_query(find_query_inventory, True)

        # Fetch matching records from rev_service
        find_query_service = f"""
            SELECT number FROM rev_service
            WHERE number IN ({iccids_str}) AND bulk_change_id = {bulk_change_id}
        """
        existing_service = spectrotel_database.execute_query(find_query_service, True)

        # Update records only if they exist
        if not existing_inventory.empty:
            spectrotel_database.update_dict(
                "sim_management_inventory",
                {"rev_line_status": "Completed"},
                {"iccid": list(existing_inventory["iccid"]), "bulk_change_id": bulk_change_id}
            )

        if not existing_service.empty:
            spectrotel_database.update_dict(
                "rev_service",
                {"rev_service_line_status": "Completed"},
                {"number": list(existing_service["number"]), "bulk_change_id": bulk_change_id}
            )

        response={"flag": True, "message": "Create revio  Customer update successful."}

        # End time calculation
        time_consumed = round(time.time() - start_time, 4)

        # Audit logging
        try:
            audit_data_user_actions = {
                "service_name": "create_rev_io_service",
                "created_date": request_received_at,
                "created_by": username,
                "status": "PROCESSED" if not failed_iccids else "ERROR",
                "time_consumed_secs": time_consumed,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "module_name": "sm bulk change",
                "comments": f"Creating Rev.io Service Bulk change {bulk_change_id}",
                "request_received_at": request_received_at,
            }

            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
        # Async sync between 1.0 and 2.0
        # def start_sync():
        #     data["bulk_chnage_id_20"] = bulk_change_id
        #     bulk_change_id_ = spectrotel_database.get_data(
        #         "sim_management_bulk_change",
        #                 {"id": bulk_change_id},  # Filter condition
        #                 [
        #                     "change_request_type",
        #                     "change_request_type_id",
        #                     "created_by",
        #                     "is_active",
        #                     "is_deleted",
        #                     "modified_by",
        #                     "processed_by",
        #                     "service_provider_id",
        #                     "service_provider",
        #                     "status",
        #                     "tenant_id",
        #                     "uploaded",
        #                 ],  # Fields to retrieve
        #             ).to_dict("records")

        #     data["data"]["sim_management_bulk_change"] = bulk_change_id_
        #     try:
        #         sync_call = sync_data_bulk_change()
        #         sync_data_bulk_change_tables(data)
        #         if sync_call:
        #             logging.info("Sync call completed")
        #             spectrotel_database.update_dict(
        #                 "sim_management_bulk_change",
        #                 {"progress": "Sync Completed"},
        #                 {"id": bulk_change_id},
        #             )
        #     except Exception as e:
        #         logging.exception(f"Failed to sync in update_assign_customer: {e}")

        # threading.Thread(target=start_sync).start()
        return response

    except Exception as e:
        # Handle any errors that occur during the process
        logging.info(f"Error updating Assign Customer: {e}")
        error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "create_rev_io_service",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Creating Rev.io Service Failed Bulk change {bulk_change_id}",
            "module_name": "sm bulk change",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "An error occurred while updating the Rev service."}

def get_integration_id_by_unique_name(json_data, tenant_name, unique_name):
    """
    Fetches the integration ID of a provider based on its unique name.
    
    Args:
        json_data (dict): JSON data containing provider information
        tenant_name (str): Name of the tenant
        unique_name (str): Unique name of the provider
        
    Returns:
        int or None: The integration ID if found, None otherwise
    """
    return json_data.get(tenant_name, {}).get(unique_name, {}).get("integration_id", None)


# Function to suspend the service device
def suspend_service_device(iccid):
    """
    Suspends a service device in the Webbing system using SOAP API.
    
    This function constructs a SOAP request to suspend a device identified by its ICCID,
    sends the request to the Webbing API, and parses the XML response to determine
    if the operation was successful.
    
    Args:
        iccid (str): The ICCID of the device to suspend
        
    Returns:
        dict: A dictionary containing:
            - flag (bool): True if suspension was successful, False otherwise
            - response_code (str): The response code from the API
            - response_description (str): Description of the response
            - error (str): Error message if an exception occurred (only present on error)
    """
    # API Endpoint
    url = "https://wws.iamwebbing.com/devices/Devices.asmx"

    # Retrieve credentials from environment variables
    webbing_username = os.getenv('WEBBING_API_USERNAME', 'spectrotel_api')
    webbing_password = os.getenv('WEBBING_API_PASSWORD', '4AcO#Fo2HZyn')
    webbing_ws_key = os.getenv('WEBBING_WS_KEY', 'cx0kJtwRwlFaKY5WoyuHxjN1gtM=')

    try:
        # SOAP Request Body
        soap_request = f"""<?xml version="1.0" encoding="utf-8"?>
        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
        <soap:Header>
        <Credentials xmlns="http://wws.iamwebbing.com/">
        <Username>{webbing_username}</Username>
        <Password>{webbing_password}</Password>
        <WSKey>{webbing_ws_key}</WSKey>
        </Credentials>
        </soap:Header>
        <soap:Body>
        <SuspendServiceDevice xmlns="http://wws.iamwebbing.com/">
        <SuspendServiceDeviceRequest>
        <ServiceDeviceIdentifier>
        <ICCID>{iccid}</ICCID>
        </ServiceDeviceIdentifier>
        </SuspendServiceDeviceRequest>
        </SuspendServiceDevice>
        </soap:Body>
        </soap:Envelope>"""

        # Headers
        headers = {
            "Content-Type": "text/xml; charset=utf-8",
            "SOAPAction": "http://wws.iamwebbing.com/SuspendServiceDevice"
        }

        # Send POST request
        response = requests.post(url, data=soap_request, headers=headers)

        # Parse XML response using ElementTree
        root = ET.fromstring(response.text)
        ns = {"soap": "http://schemas.xmlsoap.org/soap/envelope/", "ns": "http://wws.iamwebbing.com/"}

        success = root.find(".//ns:Success", ns)
        response_code = root.find(".//ns:ResponseCode", ns)
        response_description = root.find(".//ns:ResponseDescription", ns)

        flag = success.text.strip().lower() == "true" if success is not None else False
        response_data = {
            "flag": flag,
            "response_code": response_code.text if response_code is not None else "N/A",
            "response_description": response_description.text if response_description is not None else "No description"
        }

        return response_data

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        return {"flag": False, "error": str(e)}

# webbing activate status
def get_activate(iccid,db,ssid=None,eid=None):
    """
    Activates a service device using the Webbing API.
    
    Args:
        iccid (str): The ICCID of the device to activate
        db: Database connection object to fetch device details
        ssid (str, optional): SSID of the device
        eid (str, optional): EID of the device
        
    Returns:
        dict: A dictionary containing activation response details:
            - flag (bool): True if activation was successful, False otherwise
            - response_code (str): The response code from the API
            - response_description (str): Description of the response
            - error (str): Error message if an exception occurred (only present on error)
    """
    webbing_details_query=f'''
    select imei,service_device_id from webbing_devices_staging where iccid='{iccid}'
    '''
    webbing_details = db.execute_query(webbing_details_query, True)
    # Check if the query returned any data
    if not webbing_details.empty:
        imei = webbing_details.iloc[0]['imei']  # Extract IMEI from the first row
        service_device_id = webbing_details.iloc[0]['service_device_id']  # Extract Service Device ID from the first row
    else:
        imei = None  # Handle case when no data is found
        service_device_id = None  # Handle case when no data is found
    logging.info(f"### get_activate Service Device ID: {service_device_id}, imei: {imei}")
    # service_device_id=14638943
    # imei=''
    # API Endpoint
    url = "https://wws.iamwebbing.com/devices/Devices.asmx"

    # Credentials from environment variables
    webbing_username = os.getenv("WEBBING_API_USERNAME", "spectrotel_api")
    webbing_password = os.getenv("WEBBING_API_PASSWORD", "4AcO#Fo2HZyn")
    webbing_ws_key = os.getenv("WEBBING_WS_KEY", "cx0kJtwRwlFaKY5WoyuHxjN1gtM=")

    try:
        # SOAP 1.2 Request Body
        soap_request = f"""<?xml version="1.0" encoding="utf-8"?>
        <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                         xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                         xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
            <soap12:Header>
                <Credentials xmlns="http://wws.iamwebbing.com/">
                    <Username>{webbing_username}</Username>
                    <Password>{webbing_password}</Password>
                    <WSKey>{webbing_ws_key}</WSKey>
                </Credentials>
            </soap12:Header>
            <soap12:Body>
                <ActivateServiceDevice xmlns="http://wws.iamwebbing.com/">
                    <ActivateServiceDeviceRequest>
                        <ServiceDeviceIdentifier>
                            {f"<ServiceDeviceID>{service_device_id}</ServiceDeviceID>" if service_device_id else ""}
                            {f"<IMEI>{imei}</IMEI>" if imei else ""}
                            {f"<SSID>{ssid}</SSID>" if ssid else ""}
                            <ICCID>{iccid}</ICCID>
                            {f"<EID>{eid}</EID>" if eid else ""}
                        </ServiceDeviceIdentifier>
                    </ActivateServiceDeviceRequest>
                </ActivateServiceDevice>
            </soap12:Body>
        </soap12:Envelope>"""

        # Headers for SOAP 1.2
        headers = {
            "Content-Type": "application/soap+xml; charset=utf-8",
            "SOAPAction": "http://wws.iamwebbing.com/ActivateServiceDevice"
        }

        # Send POST request
        response = requests.post(url, data=soap_request, headers=headers)

        # Parse XML response using ElementTree
        root = ET.fromstring(response.text)
        ns = {"soap12": "http://www.w3.org/2003/05/soap-envelope", "ns": "http://wws.iamwebbing.com/"}

        success = root.find(".//ns:Success", ns)
        response_code = root.find(".//ns:ResponseCode", ns)
        response_description = root.find(".//ns:ResponseDescription", ns)

        flag = success.text.strip().lower() == "true" if success is not None else False
        response_data = {
            "flag": flag,
            "response_code": response_code.text if response_code is not None else "N/A",
            "response_description": response_description.text if response_description is not None else "No description"
        }

        return response_data

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        return {"flag": False, "error": str(e)}


def send_msg_to_opt_sync_queue(self, message_body):
    """
    Sends a message to the SQS queue for asynchronous processing.
    
    This function initializes an SQS client, adds a flag to the message body,
    and sends the message to a FIFO (First-In-First-Out) SQS queue. It generates
    unique IDs for message grouping and deduplication.
    
    Args:
        self: The instance of the class containing this method
        message_body (dict): The message content to be sent to the queue
        
    Returns:
        str: The MessageId of the sent message if successful
        
    Raises:
        Exception: If there's an error sending the message to the queue
    """
    try:
        # Initialize the SQS client
        logging.info("### send_msg_to_opt_sync_queue calling SQS QUEUE")
        sqs_client = boto3.client("sqs", region_name="us-east-1")
        message_body["sqs_flag"] = True
        queue_url = "https://sqs.us-east-1.amazonaws.com/008971638399/sm_bulk_change_uat.fifo"
        # Send the message to the SQS queue
        message_group_id = str(uuid.uuid4())
        response = sqs_client.send_message(
            QueueUrl=queue_url,
            MessageBody=json.dumps(message_body),
            MessageGroupId=message_group_id,
            MessageDeduplicationId=str(uuid.uuid4()),
        )

        logging.info(
            f"### send_msg_to_opt_sync_queue Message sent to SQS queue {queue_url}. Message ID: {response['MessageId']}"
        )
        return response["MessageId"]
    except Exception as e:
        logging.error(f"### send_msg_to_opt_sync_queue Error sending message to SQS queue: {e}")
        raise


def webbing_update_device_status(data):
    """
        Updates the device status for a bulk change request involving ICCIDs. The function processes
        each ICCID individually, validates the input data, and updates device statuses accordingly. It interacts
        with multiple databases, performs actions based on the 'Activate' or other status changes, logs the progress,
        and syncs with an external service.

        Args:
            data (dict): A dictionary containing various parameters, including:
                - 'request_received_at': Timestamp of when the request was received
                - 'sessionID': Session ID for tracking the user session
                - 'tenant_name': Tenant name for multi-tenant database support
                - 'username': User who is initiating the request
                - 'bulk_change_id': ID for the bulk change request
                - 'iccids': List of ICCIDs to be processed
                - 'service_provider': The name of the service provider
                - 'db_name': Name of the tenant database
                - 'updated_status': The status to update the devices (e.g., "Activate")
                - 'changed_data': Additional data related to the change request (optional)

        Returns:
            dict: A dictionary with the following keys:
                - 'flag': True if all ICCIDs were successfully updated, False if any failed
                - 'message': A message indicating success or failure, including details about failed ICCIDs
                - 'response_sync': Status code of the response from the external service sync API

        The function performs the following tasks:
            - Establishes database connections for tenant and common utils databases.
            - Validates the ICCIDs to check if they exist for the given service provider.
            - If ICCIDs are missing or invalid, returns a failure message.
            - Depending on the updated status ('Activate' or other), interacts with external APIs to update provisioning.
            - Updates the device status for each ICCID in the database.
            - Logs actions and updates the status for each ICCID, marking them as processed or failed.
            - Syncs the results with an external service by making an API request to trigger further processing.
            - Tracks the processing time and logs detailed audit information.
            - Updates the bulk change request table to reflect the final counts for success and failure.

        Raises:
            Exception: If any unexpected errors occur during processing, the function will log the error
                    and return an error response with details about the failure.

        Example:
            response = update_device_status(data)
            if response['flag']:
                logging.info("Device status update successful")
            else:
                logging.info(f"Failed to update device status: {response['message']}")
    """
    logging.info(f"### webbing_update_device_status Request Data Received: {data}")
    # Start time  and date calculation
    start_time = time.time()
    request_received_at=data.get('request_received_at','')
    ui_session_id=data.get('sessionID','')
    tenant_name=data.get('tenant_name','')
    change_type = data.get("change_type", "")
    bulk_change_id=data.get('bulk_change_id','')
    username=data.get('username','')
    # Database connection
    tenant_database = data.get("db_name", "")
    tenant_name=data.get('tenant_name','Altaworx')
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    try:
        spectrotel_database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    service_provider=data.get('service_provider')

    # tenant_id=common_utils_database.get_data('tenant',{"tenant_name":tenant_name},['id'])['id'].to_list()[0]

    # Extract ICCIDs from the input data
    iccids = data.get('iccids', [])
    # imeis = data.get('imeids', [])
    update_data = {}
    carrier_response_data = {}
    for iccid in iccids:
        insert_history_data(db_config, tenant_database, iccid, service_provider)
    #iccid_to_subscription_id = {entry['iccid']: entry['subscription_id'] for entry in inventory_iccids}
    try:
        json_data = load_json()
        webbing_ids = get_provider_ids(json_data, tenant_name, ["Webbing"])
    except Exception as e:
        logging.info(f"### webbing_update_device_status Exception while getting the service provider id : {e} ")
        webbing_ids = []
    webbing_id = webbing_ids[0] if webbing_ids else None
    # webbing_integration_id = get_integration_id_by_unique_name(json_data, tenant_name, "Webbing")

    try:
        if not iccids:
            logging.info("No ICCIDs provided.")
            return {"flag": False, "message": "No ICCIDs provided in the request."}

        # Use the new function to check for missing ICCIDs
        missing_iccids = check_iccids_exist(spectrotel_database, iccids,service_provider)

        if missing_iccids is None:
            return {"flag": False, "message": "An error occurred during the ICCID check."}

        if missing_iccids:
            bulk_change_validation_update(data)
            # If any ICCID is missing, return a message
            logging.info(f"The following ICCIDs are not associated with the {service_provider}: {', '.join(missing_iccids)}")


        updated_status=data.get('changed_data').get('UpdateStatus',{})

        # Initialize lists to store successful and failed ICCIDs
        successful_iccids = []
        failed_iccids = []
        # inventory_iccids = spectrotel_database.get_data(
        #         'sim_management_inventory',
        #         {'iccid': iccids,"is_active":True},
        #         ['subscription_id', 'iccid', 'imei']
        #     )

        # Handle Webbing service provider
        BATCH_SIZE = 20
        for i in range(0, len(iccids), BATCH_SIZE):
            # batch_start_time = time.time()
            current_batch = iccids[i:i + BATCH_SIZE]
            remaining_iccids = iccids[i + BATCH_SIZE:]

            for iccid in current_batch:
                try:
                    message_data = data.copy()
                    message_data["iccids"] = [iccid]

                    if updated_status == "Active":
                        response = get_activate(iccid, spectrotel_database)
                    else:
                        response = suspend_service_device(iccid)


                    if response.get('flag', True):
                        successful_iccids.append(iccid)
                    elif response.get('flag', False):
                        failed_iccids.append(iccid)
                    carrier_response_data["iccid"] = response

                except Exception as e:
                    logging.exception(f"Exception processing ICCID {iccid}: {str(e)}")
                    failed_iccids.append(iccid)
                    carrier_response_data[iccid] = {"error": str(e)}

            # Send message only if there are remaining ICCIDs
            if remaining_iccids:
                message_data["iccids"] = remaining_iccids[:BATCH_SIZE]  # Only next batch-size ICCIDs
                try:
                    logging.info("Calling SQS")
                    send_msg_to_opt_sync_queue(message_data)
                    logging.info("SQS Message sent successfully for Comm_group")
                except Exception as e:
                    logging.error(f"Message sending failed for comm_group: {e}")

        update_data = {"sim_status": updated_status}
        bulk_update_dict(spectrotel_database, update_data, successful_iccids)
        # failed_update_count=result['failed_count']
        # updated__updates_count=result['updated_count']
        # successfully_updated_iccids=result['successful_iccids']
        # failed_updated_iccids=result['failed_iccids']
        ##directly checking from API Hits
        failed_count=len(failed_iccids)
        updated_count=len(successful_iccids)
        if failed_count!=0:
            ##update the bulk change table for the success and failed count
            spectrotel_database.update_dict('sim_management_bulk_change',{"success":updated_count,"errors":failed_count,"status":"ERROR","processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")},{'id':bulk_change_id})
        else:
            spectrotel_database.update_dict('sim_management_bulk_change',{"success":updated_count,"errors":failed_count,"status":"PROCESSED","processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")},{'id':bulk_change_id})
        # Define the 'in_conditions' as a dictionary for the ICCID values
        ##update the success count in bulk change request
        changed_data=data.get('changed_data',{})
        changed_data = json.dumps(changed_data)
        log_entries = []
        bulk_change_request_ids = spectrotel_database.get_data(
            'sim_management_bulk_change_request',
            {'iccid': iccids,"bulk_change_id":bulk_change_id},
            ['id', 'iccid']
        ).to_dict(orient='records')
        iccid_to_request_id = {entry['iccid']: entry['id'] for entry in bulk_change_request_ids}
        if successful_iccids:
            update_success_values={"status":"PROCESSED","change_request":changed_data,"is_processed":True,"has_errors":False,"processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            in_conditions = {'iccid': successful_iccids}

            # Call update_dict function to update both fields for all active ICCIDs
            spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values=update_success_values,
                in_conditions=in_conditions  # Pass ICCID conditions using 'in_conditions'
            )
            # call insert_device_history_records to insert records into device_history tables
            thread = threading.Thread(target=insert_device_history_records,args=(tenant_name,username,successful_iccids,service_provider,tenant_database))
            thread.start()
            processd_flag=True
            for iccid in successful_iccids:
                bulk_change_request_id = iccid_to_request_id.get(iccid)
                # Log entry for each ICCID
                log_entry = {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": bulk_change_request_id,
                        "log_entry_description": f"Processing ICCID: {iccid}",
                        "request_text": changed_data,
                        "has_errors": False,
                        "response_status": "PROCESSED" if processd_flag else "ERROR",
                        "response_text": json.dumps(carrier_response_data["iccid"]),
                        "error_text": "",
                        "processed_date": datetime.datetime.now(),  # Now it should work correctly
                        "processed_by": username,
                        "created_by": username,
                        "created_date": datetime.datetime.now(),  # Now it should work correctly
                        "is_deleted": False,
                        "is_active": True
                    }
                log_entry['processed_date'] = log_entry['processed_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entry['created_date'] = log_entry['created_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entries.append(log_entry)
            spectrotel_database.insert_data(log_entries, "sim_management_bulk_change_log")
        if failed_iccids:
            update_failed_values={"status":"API FAILED","change_request":changed_data,"is_processed":False,"has_errors":True,"processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            in_conditions = {'iccid': failed_iccids}

            # Call update_dict function to update both fields for all active ICCIDs
            spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values=update_failed_values,
                in_conditions=in_conditions  # Pass ICCID conditions using 'in_conditions'
            )
            processd_flag=False
            for iccid in failed_iccids:
                bulk_change_request_id = iccid_to_request_id.get(iccid)
                # Log entry for each ICCID
                log_entry = {
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": bulk_change_request_id,
                    "log_entry_description": f"Processing ICCID: {iccid}",
                    "request_text": changed_data,
                    "has_errors": True,
                    "response_status": "SUCCESS" if processd_flag else "ERROR",
                    "response_text":json.dumps(carrier_response_data["iccid"]),
                    "error_text": "Failed to Update the Device Status",
                    "processed_date": datetime.datetime.now(),
                    "processed_by": username,
                    "created_by": username,
                    "created_date": datetime.datetime.now(),
                    "is_deleted": False,
                    "is_active": True
                }
                log_entry['processed_date'] = log_entry['processed_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entry['created_date'] = log_entry['created_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entries.append(log_entry)
            spectrotel_database.insert_data(log_entries, "sim_management_bulk_change_log")



        response = {
            "flag": True,
            "message": f"Device Status update successful in Bulk Change. {updated_count} ICCIDs were updated."
        }


        try:
            # Retrieve inventory data for the given ICCIDs and bulk_change_id.
            # Note: Added "iccid" to the SELECT list so we can match each record.
            inventory_data = spectrotel_database.get_data(
                'sim_management_inventory',
                {'iccid': iccids},
                [
                    "iccid",
                    "msisdn",
                    "id",  # Ensure comma separation
                    "device_id",
                    "sim_status",
                    "customer_name",
                    "account_number",
                    "customer_rate_plan_name",
                    "customer_rate_pool_name",
                    "tenant_id"
                ]
            ).to_dict(orient='records')

            # Loop over each ICCID and retrieve its corresponding record from inventory_data.
            for iccid in iccids:
                # Find the matching record by ICCID.
                record = next((item for item in inventory_data if item.get("iccid") == iccid), {})
                try:
                    json_data = load_json()
                    webbing_ids = get_provider_ids(json_data, tenant_name, ["Webbing"])
                except Exception as e:
                    logging.info(f"Exception while getting the service provider id : {e} ")
                    webbing_ids = []
                webbing_id = webbing_id[0] if webbing_ids else None
                device_status_history_actions = {
                    "iccid": iccid,
                    "sim_management_inventory_id": record.get("id", ""),
                    "msisdn": record.get("msisdn", ""),
                    "username": username,
                    "previous_status": record.get("sim_status", ""),
                    "current_status": data.get("updated_status", {}),
                    "bulk_change_id": bulk_change_id,
                    "change_event_type": change_type,
                    "date_of_change": request_received_at,
                    "changed_by": username,
                    "is_deleted": False,
                    "service_provider_id": webbing_id,
                    "device_id": record.get("device_id", ""),
                    "customer_name": record.get("customer_name", ""),
                    "customer_account_number": record.get("account_number", ""),
                    "customer_rate_plan": record.get("customer_rate_plan_name", ""),
                    "customer_rate_pool": record.get("customer_rate_pool_name", ""),
                    "tenant_id": record.get("tenant_id", ""),
                    "service_provider_display_name": service_provider,
                }
                spectrotel_database.insert_data(device_status_history_actions, "device_status_history")
        except Exception as e:
            logging.exception(f"An error occurred while inserting data in device_status_history: {e}")



        if iccids:
            customer_data_allocation_mb = None
            customer_rate_plan_id = None
            customer_rate_pool_id = None
            effective_date = None
            insert_customer_rate_plan_history_data(
                db_config,
                tenant_database,
                bulk_change_id or None,  # Convert empty string to None
                customer_rate_plan_id or None,
                customer_rate_pool_id or None,
                effective_date or None,
                customer_data_allocation_mb or None
            )

        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "webbing_update_device_status",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": f'Update Webbing Device Status For bulk change {bulk_change_id} has been called successfully',
                "module_name": "sm bulk change",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return response

    except Exception as e:
        # Handle any errors that occur during the process
        logging.warning(f"Error updating Device Status: {e}")
        error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "webbing_update_device_status",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Updating Device Status Failed in Bulk change {bulk_change_id}",
            "module_name": "sm bulk change",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "An error occurred while updating the Device Status."}

def update_device_status(data):
    """
        Updates the device status for a bulk change request involving ICCIDs. The function processes
        each ICCID individually, validates the input data, and updates device statuses accordingly. It interacts
        with multiple databases, performs actions based on the 'Activate' or other status changes, logs the progress,
        and syncs with an external service.

        Args:
            data (dict): A dictionary containing various parameters, including:
                - 'request_received_at': Timestamp of when the request was received
                - 'sessionID': Session ID for tracking the user session
                - 'tenant_name': Tenant name for multi-tenant database support
                - 'username': User who is initiating the request
                - 'bulk_change_id': ID for the bulk change request
                - 'iccids': List of ICCIDs to be processed
                - 'service_provider': The name of the service provider
                - 'db_name': Name of the tenant database
                - 'updated_status': The status to update the devices (e.g., "Activate")
                - 'changed_data': Additional data related to the change request (optional)

        Returns:
            dict: A dictionary with the following keys:
                - 'flag': True if all ICCIDs were successfully updated, False if any failed
                - 'message': A message indicating success or failure, including details about failed ICCIDs
                - 'response_sync': Status code of the response from the external service sync API

        The function performs the following tasks:
            - Establishes database connections for tenant and common utils databases.
            - Validates the ICCIDs to check if they exist for the given service provider.
            - If ICCIDs are missing or invalid, returns a failure message.
            - Depending on the updated status ('Activate' or other), interacts with external APIs to update provisioning.
            - Updates the device status for each ICCID in the database.
            - Logs actions and updates the status for each ICCID, marking them as processed or failed.
            - Syncs the results with an external service by making an API request to trigger further processing.
            - Tracks the processing time and logs detailed audit information.
            - Updates the bulk change request table to reflect the final counts for success and failure.

        Raises:
            Exception: If any unexpected errors occur during processing, the function will log the error
                    and return an error response with details about the failure.

        Example:
            response = update_device_status(data)
            if response['flag']:
                logging.info("Device status update successful")
            else:
                logging.info(f"Failed to update device status: {response['message']}")
    """
    logging.info(f"### update_device_status Request Data Received: {data}")
    # Start time  and date calculation
    start_time = time.time()
    request_received_at=data.get('request_received_at','')
    ui_session_id=data.get('sessionID','')
    tenant_name=data.get('tenant_name','')
    change_type = data.get("change_type", "")
    bulk_change_id=data.get('bulk_change_id','')
    username=data.get('username','')
    # Database connection
    tenant_database = data.get("db_name", "")
    tenant_name=data.get('tenant_name','Altaworx')
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    try:
        spectrotel_database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    service_provider=data.get('service_provider')

    tenant_id=common_utils_database.get_data('tenant',{"tenant_name":tenant_name},['id'])['id'].to_list()[0]

    # Extract ICCIDs from the input data
    iccids = data.get('iccids', [])
    imeis = data.get('imeids', [])
    update_data = {}
    carrier_response_data = {}
    for iccid in iccids:
        insert_history_data(db_config, tenant_database, iccid, service_provider)
    #iccid_to_subscription_id = {entry['iccid']: entry['subscription_id'] for entry in inventory_iccids}
    try:
        json_data = load_json()
        koreids=get_provider_ids(json_data, tenant_name, ["Koremain"])
        webbing_ids = get_provider_ids(json_data, tenant_name, ["Webbing"])
    except Exception as e:
        logging.info(f"Exception while getting the service provider id : {e} ")
        koreids=[]
        webbing_ids = []
    kore_id = koreids[0] if koreids else None
    webbing_id = webbing_ids[0] if webbing_ids else None
    kore_integration_id = get_integration_id_by_unique_name(json_data, tenant_name, "Koremain")
    # webbing_integration_id = get_integration_id_by_unique_name(json_data, tenant_name, "Webbing")

    try:
        if not iccids:
            logging.info("No ICCIDs provided.")
            return {"flag": False, "message": "No ICCIDs provided in the request."}

        # Use the new function to check for missing ICCIDs
        missing_iccids = check_iccids_exist(spectrotel_database, iccids,service_provider)

        if missing_iccids is None:
            return {"flag": False, "message": "An error occurred during the ICCID check."}

        if missing_iccids:
            bulk_change_validation_update(data)
            # If any ICCID is missing, return a message
            logging.info(f"The following ICCIDs are not associated with the {service_provider}: {', '.join(missing_iccids)}")


        updated_status=data.get('changed_data').get('UpdateStatus',{})

        # Initialize lists to store successful and failed ICCIDs
        successful_iccids = []
        failed_iccids = []
        inventory_iccids = spectrotel_database.get_data(
                'sim_management_inventory',
                {'iccid': iccids,"is_active":True},
                ['subscription_id', 'iccid', 'imei']
            )





        account_id, access_token = get_account_id_(data,tenant_id,kore_id,kore_integration_id)
        # mail_to = 'gopiteja.b@algonox.com'
        mail_to = os.environ["KORE_MAIL_TO"]

        base_url = common_utils_database.get_data("integration", {"name": "Kore"})['website'].to_list()[0]

        details = common_utils_database.get_data(
                "integration_authentication", {"integration_id": kore_integration_id, "tenant_id": tenant_id, "service_provider_id":kore_id}, ["token_value"]
            )
        api_key = details["token_value"].to_list()[0]
        if updated_status in ('Activate','Active'):
            activation_profile = data.get('changed_data').get("activation_profile","")
            activation_profile_name = activation_profile.split("--",1)[0].strip()
            carrier_rate_plan = activation_profile.split("--",1)[1].strip()
            carrier_rate_plan_id = spectrotel_database.get_data("carrier_rate_plan",{"rate_plan_short_name":carrier_rate_plan},["id"])['id'].to_list()[0]
            kore_activation_profiles_query = f"select * from kore_activation_profiles where activation_profile_name='{activation_profile_name}' and carrier_rate_plan_data='{carrier_rate_plan}'"
            kore_activation_profiles_data = spectrotel_database.execute_query(kore_activation_profiles_query,True)
            activation_profile_id = kore_activation_profiles_data['activation_profile_id'].to_list()[0]
            update_data['sim_status'] = 'Active'
            update_data['carrier_rate_plan_name'] = carrier_rate_plan
            update_data['carrier_rate_plan_id'] = carrier_rate_plan_id

            # Initialize lists to store successful and failed ICCIDs
            if len(iccids) != len(imeis):
                return {"flag": False, "message": "IMEI count does not match ICCID count."}
            for iccid, imei in zip(iccids, imeis):
                match = inventory_iccids[inventory_iccids["iccid"] == iccid]
                if not match.empty:
                    subscription_id = match["subscription_id"].values[0]  # Extract subscription_id
                    imei = imei    # Extract IMEI
                else:
                    subscription_id = None
                    imei = imei    # Extract IMEI
                    failed_iccids.append(iccid)
                    continue
                # Call the activate provisioning request function
                response_api_lambda = activate_provisioning_request(base_url, account_id, subscription_id, iccid, imei, activation_profile_id, mail_to, access_token, api_key)
                logging.info(f"### update_device_status SM Bulk Change Activation response_api_lambda: {response_api_lambda}")

                if response_api_lambda["flag"]:
                    successful_iccids.append(iccid)  # Add ICCID to successful list if the flag is True
                else:
                    failed_iccids.append(iccid)  # Add ICCID to failed list if the flag is False
                carrier_response_data['iccid'] = response_api_lambda['response_json']
            logging.info(f"### update_device_status Activation successful_iccids: {successful_iccids}, failed_iccids: {failed_iccids}")
        else:
            action=updated_status
            update_data['sim_status'] = updated_status
            for iccid in iccids:
                match = inventory_iccids[inventory_iccids["iccid"] == iccid]
                if not match.empty:
                    subscription_id = match["subscription_id"].values[0]  # Extract subscription_id

                else:
                    subscription_id = None

                # Call the activate provisioning request function
                response_api_lambda = send_provisioning_request(base_url, account_id, action, iccid, subscription_id, mail_to,access_token,api_key)
                if response_api_lambda["flag"]:
                    successful_iccids.append(iccid)  # Add ICCID to successful list if the flag is True
                else:
                    failed_iccids.append(iccid)  # Add ICCID to failed list if the flag is False
                carrier_response_data['iccid'] = response_api_lambda['response_json']
            logging.info(f"### update_device_status Activation successful_iccids: {successful_iccids}, failed_iccids: {failed_iccids}")


        update_data = {"sim_status": updated_status}
        if successful_iccids:
            bulk_update_dict(spectrotel_database, update_data, successful_iccids)
        # failed_update_count=result['failed_count']
        # updated__updates_count=result['updated_count']
        # successfully_updated_iccids=result['successful_iccids']
        # failed_updated_iccids=result['failed_iccids']
        ##directly checking from API Hits
        failed_count=len(failed_iccids)
        updated_count=len(successful_iccids)
        if failed_count!=0:
            ##update the bulk change table for the success and failed count
            spectrotel_database.update_dict('sim_management_bulk_change',{"success":updated_count,"errors":failed_count,"status":"ERROR","processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")},{'id':bulk_change_id})
        else:
            spectrotel_database.update_dict('sim_management_bulk_change',{"success":updated_count,"errors":failed_count,"status":"PROCESSED","processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")},{'id':bulk_change_id})
        # Define the 'in_conditions' as a dictionary for the ICCID values
        ##update the success count in bulk change request
        changed_data=data.get('changed_data',{})
        changed_data = json.dumps(changed_data)
        log_entries = []
        bulk_change_request_ids = spectrotel_database.get_data(
            'sim_management_bulk_change_request',
            {'iccid': iccids,"bulk_change_id":bulk_change_id},
            ['id', 'iccid']
        ).to_dict(orient='records')
        iccid_to_request_id = {entry['iccid']: entry['id'] for entry in bulk_change_request_ids}
        if successful_iccids:
            update_success_values={"status":"PROCESSED","change_request":changed_data,"is_processed":True,"has_errors":False,"processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            in_conditions = {'iccid': successful_iccids}

            # Call update_dict function to update both fields for all active ICCIDs
            spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values=update_success_values,
                in_conditions=in_conditions  # Pass ICCID conditions using 'in_conditions'
            )

            # call insert_device_history_records to insert records into device_history tables
            thread = threading.Thread(target=insert_device_history_records, args=(tenant_name, username, successful_iccids, service_provider, tenant_database))
            thread.start()
            processd_flag=True
            for iccid in successful_iccids:
                bulk_change_request_id = iccid_to_request_id.get(iccid)
                # Log entry for each ICCID
                log_entry = {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": bulk_change_request_id,
                        "log_entry_description": f"Processing ICCID: {iccid}",
                        "request_text": changed_data,
                        "has_errors": False,
                        "response_status": "PROCESSED" if processd_flag else "ERROR",
                        "response_text": json.dumps(carrier_response_data['iccid']),
                        "error_text": "",
                        "processed_date": datetime.datetime.now(),  # Now it should work correctly
                        "processed_by": username,
                        "created_by": username,
                        "created_date": datetime.datetime.now(),  # Now it should work correctly
                        "is_deleted": False,
                        "is_active": True
                    }
                log_entry['processed_date'] = log_entry['processed_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entry['created_date'] = log_entry['created_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entries.append(log_entry)
            spectrotel_database.insert_data(log_entries, "sim_management_bulk_change_log")
        if failed_iccids:
            update_failed_values={"status":"API FAILED","change_request":changed_data,"is_processed":False,"has_errors":True,"processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            in_conditions = {'iccid': failed_iccids}

            # Call update_dict function to update both fields for all active ICCIDs
            spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values=update_failed_values,
                in_conditions=in_conditions  # Pass ICCID conditions using 'in_conditions'
            )
            processd_flag=False
            for iccid in failed_iccids:
                bulk_change_request_id = iccid_to_request_id.get(iccid)
                # Log entry for each ICCID
                log_entry = {
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": bulk_change_request_id,
                    "log_entry_description": f"Processing ICCID: {iccid}",
                    "request_text": changed_data,
                    "has_errors": True,
                    "response_status": "SUCCESS" if processd_flag else "ERROR",
                    "response_text":json.dumps(carrier_response_data['iccid']),
                    "error_text": "Failed to Update the Device Status",
                    "processed_date": datetime.datetime.now(),
                    "processed_by": username,
                    "created_by": username,
                    "created_date": datetime.datetime.now(),
                    "is_deleted": False,
                    "is_active": True
                }
                log_entry['processed_date'] = log_entry['processed_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entry['created_date'] = log_entry['created_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entries.append(log_entry)
            spectrotel_database.insert_data(log_entries, "sim_management_bulk_change_log")



        response = {
            "flag": True,
            "message": f"Device Status update successful in Bulk Change. {updated_count} ICCIDs were updated."
        }


        try:
            # Retrieve inventory data for the given ICCIDs and bulk_change_id.
            # Note: Added "iccid" to the SELECT list so we can match each record.
            inventory_data = spectrotel_database.get_data(
                'sim_management_inventory',
                {'iccid': iccids},
                [
                    "iccid",
                    "msisdn",
                    "id",  # Ensure comma separation
                    "device_id",
                    "sim_status",
                    "customer_name",
                    "account_number",
                    "customer_rate_plan_name",
                    "customer_rate_pool_name",
                    "tenant_id"
                ]
            ).to_dict(orient='records')

            # Loop over each ICCID and retrieve its corresponding record from inventory_data.
            for iccid in iccids:
                # Find the matching record by ICCID.
                record = next((item for item in inventory_data if item.get("iccid") == iccid), {})
                try:
                    json_data = load_json()
                    koreids=get_provider_ids(json_data, tenant_name, ["Koremain"])
                    webbing_ids = get_provider_ids(json_data, tenant_name, ["Webbing"])
                except Exception as e:
                    logging.info(f"Exception while getting the service provider id : {e} ")
                    koreids=[]
                    webbing_ids = []
                kore_id = koreids[0] if koreids else None
                webbing_id = webbing_id[0] if koreids else None
                device_status_history_actions = {
                    "iccid": iccid,
                    "sim_management_inventory_id": record.get("id", ""),
                    "msisdn": record.get("msisdn", ""),
                    "username": username,
                    "previous_status": record.get("sim_status", ""),
                    "current_status": data.get("updated_status", {}),
                    "bulk_change_id": bulk_change_id,
                    "change_event_type": change_type,
                    "date_of_change": request_received_at,
                    "changed_by": username,
                    "is_deleted": False,
                    "service_provider_id": webbing_id if service_provider != "kore" else kore_id,
                    "device_id": record.get("device_id", ""),
                    "customer_name": record.get("customer_name", ""),
                    "customer_account_number": record.get("account_number", ""),
                    "customer_rate_plan": record.get("customer_rate_plan_name", ""),
                    "customer_rate_pool": record.get("customer_rate_pool_name", ""),
                    "tenant_id": record.get("tenant_id", ""),
                    "service_provider_display_name": service_provider,
                }
                spectrotel_database.insert_data(device_status_history_actions, "device_status_history")
        except Exception as e:
            logging.exception(f"An error occurred while inserting data in device_status_history: {e}")



        if iccids:
            customer_data_allocation_mb = None
            customer_rate_plan_id = None
            customer_rate_pool_id = None
            effective_date = None
            insert_customer_rate_plan_history_data(
                db_config,
                tenant_database,
                bulk_change_id or None,  # Convert empty string to None
                customer_rate_plan_id or None,
                customer_rate_pool_id or None,
                effective_date or None,
                customer_data_allocation_mb or None
            )

        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "update_device_status",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": f'Update Device Status For bulk iccids bulk_change_id : {bulk_change_id}',
                "module_name": "sm bulk change",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return response

    except Exception as e:
        # Handle any errors that occur during the process
        logging.warning(f"Error updating Device Status: {e}")
        error_type = str(type(e).__name__)
        message = f"An error occurred while updating the Device Status{e}"
        # Error logging
        error_data = {
            "service_name": "update_device_status",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "sm bulk change",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "An error occurred while updating the Device Status."}


def update_archive_status(data):
    """
        Updates the Archive status for a bulk change request involving ICCIDs. The function processes
        each ICCID individually, validates the input data, and updates Archive statuses accordingly. It interacts
        with multiple databases, performs actions based on the 'Activate' or other status changes, logs the progress,
        and syncs with an external service.

        Args:
            data (dict): A dictionary containing various parameters, including:
                - 'request_received_at': Timestamp of when the request was received
                - 'sessionID': Session ID for tracking the user session
                - 'tenant_name': Tenant name for multi-tenant database support
                - 'username': User who is initiating the request
                - 'bulk_change_id': ID for the bulk change request
                - 'iccids': List of ICCIDs to be processed
                - 'service_provider': The name of the service provider
                - 'db_name': Name of the tenant database
                - 'updated_status': The status to update the devices (e.g., "Activate")
                - 'changed_data': Additional data related to the change request (optional)

        Returns:
            dict: A dictionary with the following keys:
                - 'flag': True if all ICCIDs were successfully updated, False if any failed
                - 'message': A message indicating success or failure, including details about failed ICCIDs
                - 'response_sync': Status code of the response from the external service sync API

        The function performs the following tasks:
            - Establishes database connections for tenant and common utils databases.
            - Validates the ICCIDs to check if they exist for the given service provider.
            - If ICCIDs are missing or invalid, returns a failure message.
            - Depending on the updated status ('Activate' or other), interacts with external APIs to update provisioning.
            - Updates the device status for each ICCID in the database.
            - Logs actions and updates the status for each ICCID, marking them as processed or failed.
            - Syncs the results with an external service by making an API request to trigger further processing.
            - Tracks the processing time and logs detailed audit information.
            - Updates the bulk change request table to reflect the final counts for success and failure.

        Raises:
            Exception: If any unexpected errors occur during processing, the function will log the error
                    and return an error response with details about the failure.

        Example:
            response = update_archive_status(data)
            if response['flag']:
                logging.info("Device status update successful")
            else:
                logging.info(f"Failed to update device status: {response['message']}")
    """

    logging.info(f"### update_archive_status Data Received : {data}")
    # Start time  and date calculation
    start_time = time.time()
    request_received_at=data.get('request_received_at','')
    ui_session_id=data.get('sessionID','')
    tenant_name=data.get('tenant_name','')
    bulk_change_id=data.get('bulk_change_id','')
    username=data.get('username','')
    # Database connection
    tenant_database = data.get("db_name", "")
    try:
        spectrotel_database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    service_provider=data.get('service_provider')

    # Extract ICCIDs from the input data
    iccids = data.get('iccids', [])
    try:
        if not iccids:
            logging.info("No ICCIDs provided.")
            return {"flag": False, "message": "No ICCIDs provided in the request."}

        # Use the new function to check for missing ICCIDs
        missing_iccids = check_iccids_exist(spectrotel_database, iccids,service_provider)

        if missing_iccids is None:
            return {"flag": False, "message": "An error occurred during the ICCID check."}

        if missing_iccids:
            bulk_change_validation_update(data)
            # If any ICCID is missing, return a message
            logging.info(f"The following ICCIDs are not associated with the {service_provider}: {', '.join(missing_iccids)}")



        for iccid in iccids:
            insert_history_data(db_config, tenant_database, iccid, service_provider)

        update_data = {"is_active": False}
        result = bulk_update_dict(spectrotel_database, update_data, iccids)
        failed_count=result['failed_count']
        updated_count=result['updated_count']
        successful_iccids=result['successful_iccids']
        failed_iccids=result['failed_iccids']
        if failed_count!=0:
            ##update the bulk change table for the success and failed count
            spectrotel_database.update_dict('sim_management_bulk_change',{"success":updated_count,"errors":failed_count,"status":"ERROR","processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")},{'id':bulk_change_id})
        else:
            spectrotel_database.update_dict('sim_management_bulk_change',{"success":updated_count,"errors":failed_count,"status":"PROCESSED","processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")},{'id':bulk_change_id})
        # Define the 'in_conditions' as a dictionary for the ICCID values
        ##update the success count in bulk change request
        changed_data=data.get('changed_data',{})
        changed_data = json.dumps(changed_data)
        log_entries = []
        bulk_change_request_ids = spectrotel_database.get_data(
            'sim_management_bulk_change_request',
            {'iccid': iccids,"bulk_change_id":bulk_change_id},
            ['id', 'iccid']
        ).to_dict(orient='records')
        iccid_to_request_id = {entry['iccid']: entry['id'] for entry in bulk_change_request_ids}
        if successful_iccids:
            update_success_values={"status":"PROCESSED","change_request":changed_data,"is_processed":True,"has_errors":False,"processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            in_conditions = {'iccid': successful_iccids}

            # Call update_dict function to update both fields for all active ICCIDs
            spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values=update_success_values,
                in_conditions=in_conditions  # Pass ICCID conditions using 'in_conditions'
            )

            # call insert_device_history_records to insert records into device_history tables
            thread = threading.Thread(target=insert_device_history_records, args=(tenant_name,username,successful_iccids,service_provider,tenant_database))
            thread.start()
            processd_flag=True
            for iccid in successful_iccids:
                bulk_change_request_id = iccid_to_request_id.get(iccid)
                # Log entry for each ICCID
                log_entry = {
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": bulk_change_request_id,
                    "log_entry_description": f"Archiving ICCID: {iccid}",
                    "request_text": changed_data,
                    "has_errors": False,
                    "response_status": "PROCESSED" if processd_flag else "ERROR",
                    "response_text":"OK",
                    "error_text": "",
                    "processed_date": datetime.datetime.now(),
                    "processed_by": username,
                    "created_by": username,
                    "created_date": datetime.datetime.now(),
                    "is_deleted": False,
                    "is_active": True
                }
                log_entry['processed_date'] = log_entry['processed_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entry['created_date'] = log_entry['created_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entries.append(log_entry)
            spectrotel_database.insert_data(log_entries, "sim_management_bulk_change_log")
        if failed_iccids:
            update_failed_values={"status":"ERROR","change_request":changed_data,"is_processed":False,"has_errors":True,"processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            in_conditions = {'iccid': failed_iccids}

            # Call update_dict function to update both fields for all active ICCIDs
            spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values=update_failed_values,
                in_conditions=in_conditions  # Pass ICCID conditions using 'in_conditions'
            )
            processd_flag=False
            for iccid in successful_iccids:
                bulk_change_request_id = iccid_to_request_id.get(iccid)
                # Log entry for each ICCID
                log_entry = {
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": bulk_change_request_id,
                    "log_entry_description": f"Archiving ICCID: {iccid}",
                    "request_text": changed_data,
                    "has_errors": False,
                    "response_status": "PROCESSED" if processd_flag else "ERROR",
                    "response_text":"OK",
                    "error_text": "Failed to Archive the ICCID",
                    "processed_date": datetime.datetime.now(),
                    "processed_by": username,
                    "created_by": username,
                    "created_date": datetime.datetime.now(),
                    "is_deleted": False,
                    "is_active": True
                }
                log_entry['processed_date'] = log_entry['processed_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entry['created_date'] = log_entry['created_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entries.append(log_entry)
            spectrotel_database.insert_data(log_entries, "sim_management_bulk_change_log")

        # Async sync between 1.0 and 2.0
        # def start_sync():
        #     data["bulk_chnage_id_20"] = bulk_change_id
        #     bulk_change_id_ = spectrotel_database.get_data(
        #         "sim_management_bulk_change",
        #                 {"id": bulk_change_id},  # Filter condition
        #                 [
        #                     "change_request_type",
        #                     "change_request_type_id",
        #                     "created_by",
        #                     "is_active",
        #                     "is_deleted",
        #                     "modified_by",
        #                     "processed_by",
        #                     "service_provider_id",
        #                     "service_provider",
        #                     "status",
        #                     "tenant_id",
        #                     "uploaded",
        #                 ],  # Fields to retrieve
        #             ).to_dict("records")

        #     data["data"]["sim_management_bulk_change"] = bulk_change_id_
        #     try:
        #         sync_call = sync_data_bulk_change()
        #         sync_data_bulk_change_tables(data)
        #         if sync_call:
        #             logging.info("Sync call completed")
        #             spectrotel_database.update_dict(
        #                 "sim_management_bulk_change",
        #                 {"progress": "Sync Completed"},
        #                 {"id": bulk_change_id},
        #             )
        #     except Exception as e:
        #         logging.exception(f"Failed to sync in update_assign_customer: {e}")

        # threading.Thread(target=start_sync).start()

        if iccids:
            customer_data_allocation_mb = None
            customer_rate_plan_id = None
            customer_rate_pool_id = None
            effective_date = None
            insert_customer_rate_plan_history_data(
                db_config,
                tenant_database,
                bulk_change_id or None,  # Convert empty string to None
                customer_rate_plan_id or None,
                customer_rate_pool_id or None,
                effective_date or None,
                customer_data_allocation_mb or None
            )

        response = {
            "flag": True,
            "message": f"Archive was successful in Bulk Change. {updated_count} ICCIDs were updated."
        }
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "update_archive_status",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": f"Archive Status For bulk iccids bulk_change_id : {bulk_change_id}",
                "module_name": "sm bulk change",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
        # If update is successful
        return response

    except Exception as e:
        # Handle any errors that occur during the process
        logging.exception(f"Error updating Archieve: {e}")
        error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "update_archive_status",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Error in updating Archive Status for bulk_change_id: {bulk_change_id}",
            "module_name": "sm bulk change",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "An error occurred while updating the Archieve Status."}


def start_sync(data):
    """
    Initiates data synchronization for a bulk change request.
    
    This function retrieves bulk change data from the database, calls the sync functions
    to synchronize data between systems, and updates the progress status in the database.
    It handles database connections and any exceptions that occur during the process.
    
    Args:
        data (dict): A dictionary containing request data, including:
            - 'bulk_change_id': ID of the bulk change request to synchronize
            - 'db_name': Name of the tenant database to connect to
            
    Returns:
        dict or None: Returns an error dictionary if database connection fails,
                     otherwise returns None after completing the sync process
    """
    bulk_change_id=data.get('bulk_change_id','')
    # Database connection
    tenant_database = data.get("db_name", "")
    try:
        spectrotel_database = DB(tenant_database, **db_config)
        # common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    data["bulk_chnage_id_20"] = bulk_change_id
    bulk_change_id_ = spectrotel_database.get_data(
        "sim_management_bulk_change",
                {"id": bulk_change_id},  # Filter condition
                [
                    "change_request_type",
                    "change_request_type_id",
                    "created_by",
                    "is_active",
                    "is_deleted",
                    "modified_by",
                    "processed_by",
                    "service_provider_id",
                    "service_provider",
                    "status",
                    "tenant_id",
                    "uploaded",
                ],  # Fields to retrieve
            ).to_dict("records")

    data["data"]["sim_management_bulk_change"] = bulk_change_id_
    try:
        sync_call = sync_data_bulk_change()
        sync_data_bulk_change_tables(data)
        if sync_call:
            logging.info("Sync call completed")
            spectrotel_database.update_dict(
                "sim_management_bulk_change",
                {"progress": "Sync Completed"},
                {"id": bulk_change_id},
            )

    except Exception as e:
        logging.exception(f"Failed to sync in update_assign_customer: {e}")




def get_access_token_(client_id, client_secret):
    """
    Obtains an OAuth access token using client credentials.
    
    This function makes a POST request to the Kore API token endpoint with client credentials
    to obtain an access token for API authentication. It handles the response and any errors
    that may occur during the token acquisition process.
    
    Args:
        client_id (str): The OAuth client ID for authentication
        client_secret (str): The OAuth client secret for authentication
        
    Returns:
        str or None: The access token if successful, None if an error occurs or token is not found
    """
    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
    }
    # token_url = "https://api.korewireless.com/Api/api/token"
    token_url = os.environ["KORE_API"]
    try:
        response = requests.post(token_url, data=payload)
        response.raise_for_status()
        token_data = response.json()
        access_token = token_data.get("access_token")
        if access_token:
            logging.info(f"### get_access_token_ Access Token: {access_token}")  # Debugging: Print the token
            return access_token
        else:
            logging.info(f"### get_access_token_ token_data: {token_data}")
            return None
    except requests.exceptions.RequestException as e:
        logging.info(f"### get_access_token_ Error fetching access token: {e}")
        return None


def get_account_id_(data,tenant_id,kore_id,kore_integration_id,api_key=None):
    """
    Retrieves the account ID and access token for Kore API interactions.
    
    This function fetches authentication details from the database, obtains an access token,
    and then makes an API call to retrieve the account ID associated with a specific email.
    It handles the API response and any errors that may occur during the process.
    
    Args:
        data (dict): Request data containing context information
        tenant_id (int): ID of the tenant
        kore_id (int): ID of the Kore service provider
        kore_integration_id (int): ID of the Kore integration
        api_key (str, optional): API key for authentication, if not provided will be fetched from database
        
    Returns:
        tuple or None: A tuple containing (account_id, access_token) if successful, None if an error occurs
    """
    email = os.environ['KORE_EMAIL']
    # email = "czambrano@spectrotel.com"
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    base_url = database.get_data("integration", {"name": "Kore"})["website"].to_list()[
        0
    ]
    url = f"{base_url}v1/accounts?email={email}"

    # tenant_name = os.getenv("KORE_TENANT_NAME", "Spectrotel")
    # try:
    #     tenant_id = database.get_data("tenant", {"tenant_name": tenant_name}, ["id"])[
    #         "id"
    #     ].to_list()[0]
    # except Exception as e:
    #     logging.exception(f"An error occurred: {e}")
    details = database.get_data(
        "integration_authentication",
        {"integration_id": kore_integration_id, "tenant_id": tenant_id, "service_provider_id": kore_id},
        ["oauth2_client_id", "oauth2_client_secret", "token_value"],
    )
    client_id = details["oauth2_client_id"].to_list()[0]
    client_secret = details["oauth2_client_secret"].to_list()[0]
    api_key = details["token_value"].to_list()[0]
    access_token = get_access_token_(client_id, client_secret)
    headers = {"Accept": "application/json", "Authorization": f"Bearer {access_token}"}
    if api_key:
        headers["x-api-key"] = api_key  # Include API Key if required
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        account_data = response.json()

        # Extract account-id from the list inside 'account'
        accounts = account_data.get("account", [])
        if accounts and isinstance(accounts, list):
            account_id = accounts[0].get(
                "account-id"
            )  # Get the first account's account-id
            logging.info("Account Details:")
            logging.info(account_data)
            return account_id, access_token
        else:
            logging.info("Error: No accounts found or invalid response structure.")
            return None
    except requests.exceptions.RequestException as e:
        logging.info(f"Error fetching account ID: {e}")
        logging.info(f"Response: {response.text}")  # Debugging: Log the raw response
        return None







def change_service_device_product(iccid, product_id):
    """
    Changes the product associated with a service device in the Webbing system.
    
    This function constructs a SOAP request to change the product for a device identified by its ICCID,
    sends the request to the Webbing API, and parses the XML response to determine
    if the operation was successful.
    
    Args:
        iccid (str): The ICCID of the device to modify
        product_id (str or int): The ID of the product to assign to the device
        
    Returns:
        dict: A dictionary containing:
            - flag (bool): True if product change was successful, False otherwise
            - response_code (str): The response code from the API
            - response_description (str): Description of the response
            - error (str): Error message if an exception occurred (only present on error)
    """
    product_id=str(product_id)
    url = "https://wws.iamwebbing.com/devices/Devices.asmx?op=ChangeServiceDeviceProduct"
    headers = {
        "Content-Type": "text/xml; charset=utf-8",
        "SOAPAction": "http://wws.iamwebbing.com/ChangeServiceDeviceProduct"
    }
    soap_request = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xmlns:xsd="http://www.w3.org/2001/XMLSchema"
   xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <soap:Header>
    <Credentials xmlns="http://wws.iamwebbing.com/">
    <Username>spectrotel_api</Username>
    <Password>4AcO#Fo2HZyn</Password>
    <WSKey>cx0kJtwRwlFaKY5WoyuHxjN1gtM=</WSKey>
    </Credentials>
    </soap:Header>
    <soap:Body>
    <ChangeServiceDeviceProduct xmlns="http://wws.iamwebbing.com/">
    <ChangeServiceDeviceProductRequest>
    <ServiceDeviceIdentifier>
    <ICCID>{iccid}</ICCID>
    </ServiceDeviceIdentifier>
    <ProductID>{product_id}</ProductID>
    </ChangeServiceDeviceProductRequest>
    </ChangeServiceDeviceProduct>
    </soap:Body>
    </soap:Envelope>"""
    try:
        response = requests.post(url, data=soap_request, headers=headers)
        # Parse XML response
        root = ET.fromstring(response.text)
        ns = {"soap": "http://schemas.xmlsoap.org/soap/envelope/", "ns": "http://wws.iamwebbing.com/"}
        success = root.find(".//ns:Success", ns)
        response_code = root.find(".//ns:ResponseCode", ns)
        response_description = root.find(".//ns:ResponseDescription", ns)
        flag = success.text.strip().lower() == "true" if success is not None else False
        response_data = {
            "flag": flag,
            "response_code": response_code.text if response_code is not None else "N/A",
            "response_description": response_description.text if response_description is not None else "No description"
        }
        return response_data
    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        return {"flag": False, "error": str(e)}


def bulk_change_validation_update(data):
    """
    Updates the status of a bulk change request to ERROR when validation fails.
    
    This function is called when validation of ICCIDs or other data fails during a bulk change operation.
    It updates the status of the bulk change and all associated requests to ERROR, and logs the action
    in the audit table.
    
    Args:
        data (dict): A dictionary containing request data, including:
            - 'bulk_change_id': ID of the bulk change request
            - 'db_name': Name of the tenant database
            - 'username': Username of the person who initiated the request
            - 'sessionID': Session ID for tracking
            - 'Partner': Tenant name
            
    Returns:
        dict: A dictionary with flag and message indicating success or failure of the update
    """
    logging.info(f"### bulk_change_validation_update Data recieved  {data}")
    bulkchange_id = data.get("bulk_change_id", "")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    # if tenant_database =='altaworx_test':
    #     tenant_name = 'altaworx'
    # else:
    #     tenant_name = tenant_database.lower()
    database = DB(tenant_database, **db_config)
    common_utils_database= DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        database.update_dict(
                    "sim_management_bulk_change",
                    {
                        "status": "ERROR",
                        "progress": "ERROR"
                    },
                    {"id": bulkchange_id},
                )

        database.update_dict(
                    "sim_management_bulk_change_request",
                    {
                        "status": "ERROR"
                    },
                    {"bulk_change_id": bulkchange_id},
                )

        response = {"flag": True, "message": "Data updated successfully"}

        try:
            # End time calculation

            audit_data_user_actions = {
                "service_name": "Sim Management",
                "created_by": username,
                "status": str(response["flag"]),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": "bulk_change_validation_update",
                "module_name": "readme",
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"Exception in audit logging: {e}")

        return response
    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        message = "Unable to fetch the list of devices"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)

        try:
            error_data = {
                "service_name": "Sim Management",
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": "bulk_change_validation_update error",
                "module_name": "Readme",
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception in error logging: {e}")

        return response

def update_webbing_carrier_rate_plan_name(data):
    """
    Updates the carrier rate plan and associated data for a list of ICCIDs in bulk.
    The function checks the validity of the provided ICCIDs, performs the necessary updates for each ICCID,
    and logs the results. It also tracks the success and failure counts, updating the respective bulk change record
    with the final status. Logs detailed information on each change request, including success and failure details.

    Args:
        data (dict): A dictionary containing the input data for the update, including:
            - 'db_name' (str): The name of the tenant database.
            - 'iccids' (list): A list of ICCIDs to be updated.
            - 'updated_data' (dict): The updated customer rate plan data.
            - 'service_provider' (str): The name of the service provider.
            - 'bulk_change_id' (str): The ID of the bulk change request.
            - 'username' (str): The username initiating the update.
            - 'request_received_at' (str): Timestamp when the request was received.
            - 'ui_session_id' (str): UI session ID for tracking the session.

    Returns:
        dict: A dictionary indicating the success or failure of the operation with a message:
            - 'flag' (bool): True if the update is successful, False if an error occurred.
            - 'message' (str): A descriptive message about the outcome.
            - 'response_api' (int): The status code of the external API sync request (if applicable).
    """

    logging.info(f"### update_webbing_carrier_rate_plan_name Request Data Received : {data}")
    # Start time  and date calculation
    start_time = time.time()
    request_received_at=data.get('request_received_at','')
    ui_session_id=data.get('sessionID','')
    tenant_name=data.get('tenant_name','')
    bulk_change_id=data.get('bulk_change_id','')
    # change_type = data.get("change_type", "")
    username=data.get('username','')
    # Database connection
    tenant_database = data.get("db_name", "")
    try:
        spectrotel_database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    service_provider=data.get('service_provider')
    effective_date = data.get('effective_date')


    # Extract ICCIDs from the input data
    iccids = data.get('iccids', [])
    try:
        if not iccids:
            logging.info("No ICCIDs provided.")
            return {"flag": False, "message": "No ICCIDs provided in the request."}

        # Use the new function to check for missing ICCIDs
        missing_iccids = check_iccids_exist(spectrotel_database, iccids,service_provider)

        if missing_iccids is None:
            return {"flag": False, "message": "An error occurred during the ICCID check."}

        if missing_iccids:
            bulk_change_validation_update(data)
            # If any ICCID is missing, return a message
            logging.info(f"The following ICCIDs are not associated with the {service_provider}: {', '.join(missing_iccids)}")



        # for iccid in iccids:
        #     insert_history_data(db_config, tenant_database, iccid, service_provider)

        changed_data = data.get("changed_data", {})
        CarrierRatePlanUpdate = changed_data.get("CarrierRatePlanUpdate",{})

        # updated_data=data.get('CarrierRatePlanUpdate',{})
        carrier_rate_plan_name=CarrierRatePlanUpdate.get('CarrierRatePlan',"")


        product_id_query=f'''select product_id from webbing_service_products_staging where product_name='{carrier_rate_plan_name}' '''
        product_id=spectrotel_database.execute_query(product_id_query,True)['product_id'].to_list()[0]

        # Initialize lists to store successful and failed ICCIDs
        successful_iccids = []
        failed_iccids = []
        # inventory_iccids = spectrotel_database.get_data(
        #         'sim_management_inventory',
        #         {'iccid': iccids,"is_active":True},
        #         ['subscription_id', 'iccid', 'imei']
        #     )

        carrier_response_data = {}
        # Handle Webbing service provider
        BATCH_SIZE = 20
        for i in range(0, len(iccids), BATCH_SIZE):
            # batch_start_time = time.time()
            current_batch = iccids[i:i + BATCH_SIZE]
            remaining_iccids = iccids[i + BATCH_SIZE:]

            for iccid in current_batch:
                try:
                    message_data = data.copy()
                    message_data["iccids"] = [iccid]


                    response = change_service_device_product(iccid, product_id)


                    carrier_response_data["iccid"] = response
                    if response.get('flag', True):
                        successful_iccids.append(iccid)
                    elif response.get('flag', False):
                        failed_iccids.append(iccid)

                except Exception as e:
                    logging.exception(f"Exception processing ICCID {iccid}: {str(e)}")
                    failed_iccids.append(iccid)
                    carrier_response_data["iccid"] = {"error": str(e)}

            # Send message only if there are remaining ICCIDs
            if remaining_iccids:
                message_data["iccids"] = remaining_iccids[:BATCH_SIZE]  # Only next batch-size ICCIDs
                try:
                    logging.info("Calling SQS")
                    send_msg_to_opt_sync_queue(message_data)
                    logging.info("SQS Message sent successfully for Comm_group")
                except Exception as e:
                    logging.error(f"Message sending failed for comm_group: {e}")


        # updated_data=data.get('CarrierRatePlanUpdate',{})
        # carrier_rate_plan_update_data=updated_data.get('CarrierRatePlan',{})
        # logging.info(carrier_rate_plan_update_data,'carrier_rate_plan_update_data')
        carrier_rate_plan_name=CarrierRatePlanUpdate.get('CarrierRatePlan',"")

        logging.info(carrier_rate_plan_name,'carrier_rate_plan_name')
        if carrier_rate_plan_name:
            carrier_rate_plan_id=spectrotel_database.get_data('carrier_rate_plan',{"rate_plan_code":carrier_rate_plan_name,"is_active":True,"service_provider":service_provider},['id'])['id'].to_list()[0]
        else:
            response={"flag":False,"message":"unable to fetch the customer rate plan"}
            return response




        update_data = {"carrier_rate_plan_id": carrier_rate_plan_id, "carrier_rate_plan_name": carrier_rate_plan_name}


        if successful_iccids:
            bulk_update_dict(spectrotel_database, update_data, successful_iccids)
        # failed_update_count=result['failed_count']
        # updated__updates_count=result['updated_count']
        # successfully_updated_iccids=result['successful_iccids']
        # failed_updated_iccids=result['failed_iccids']
        ##directly checking from API Hits
        failed_count=len(failed_iccids)
        updated_count=len(successful_iccids)
        if failed_count!=0:
            ##update the bulk change table for the success and failed count
            spectrotel_database.update_dict('sim_management_bulk_change',{"success":updated_count,"errors":failed_count,"status":"ERROR","processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")},{'id':bulk_change_id})
        else:
            spectrotel_database.update_dict('sim_management_bulk_change',{"success":updated_count,"errors":failed_count,"status":"PROCESSED","processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")},{'id':bulk_change_id})
        # Define the 'in_conditions' as a dictionary for the ICCID values
        ##update the success count in bulk change request
        changed_data=data.get('changed_data',{})
        changed_data = json.dumps(changed_data)
        log_entries = []
        bulk_change_request_ids = spectrotel_database.get_data(
            'sim_management_bulk_change_request',
            {'iccid': iccids,"bulk_change_id":bulk_change_id},
            ['id', 'iccid']
        ).to_dict(orient='records')
        iccid_to_request_id = {entry['iccid']: entry['id'] for entry in bulk_change_request_ids}

        if successful_iccids:
            update_success_values={"status":"PROCESSED","change_request":changed_data,"is_processed":True,"has_errors":False,"processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            in_conditions = {'iccid': successful_iccids}

            # Call update_dict function to update both fields for all active ICCIDs
            spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values=update_success_values,
                in_conditions=in_conditions  # Pass ICCID conditions using 'in_conditions'
            )

            # call insert_device_history_records to insert records into device_history tables
            thread = threading.Thread(target=insert_device_history_records, args=(tenant_name, username, successful_iccids, service_provider, tenant_database),
                                      kwargs={"effective_date": effective_date}
                                      )
            thread.start()
            processd_flag=True
            for iccid in successful_iccids:
                bulk_change_request_id = iccid_to_request_id.get(iccid)
                # Log entry for each ICCID
                log_entry = {
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": bulk_change_request_id,
                    "log_entry_description": f"Processing ICCID: {iccid}",
                    "request_text": changed_data,
                    "has_errors": False,
                    "response_status": "PROCESSED" if processd_flag else "ERROR",
                    "response_text":json.dumps(carrier_response_data["iccid"]),
                    "error_text": "",
                    "processed_date": datetime.datetime.now(),
                    "processed_by": username,
                    "created_by": username,
                    "created_date": datetime.datetime.now(),
                    "is_deleted": False,
                    "is_active": True
                }
                log_entry['processed_date'] = log_entry['processed_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entry['created_date'] = log_entry['created_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entries.append(log_entry)
            spectrotel_database.insert_data(log_entries, "sim_management_bulk_change_log")

        if failed_iccids:
            update_failed_values={"status":"ERRORS","change_request":changed_data,"is_processed":False,"has_errors":True,"processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            in_conditions = {'iccid': failed_iccids}

            # Call update_dict function to update both fields for all active ICCIDs
            spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values=update_failed_values,
                in_conditions=in_conditions  # Pass ICCID conditions using 'in_conditions'
            )
            processd_flag=False
            for iccid in successful_iccids:
                bulk_change_request_id = iccid_to_request_id.get(iccid)
                # Log entry for each ICCID
                log_entry = {
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": bulk_change_request_id,
                    "log_entry_description": f"Processing ICCID: {iccid}",
                    "request_text": changed_data,
                    "has_errors": False,
                    "response_status": "SUCCESS" if processd_flag else "ERROR",
                    "response_text": json.dumps(carrier_response_data["iccid"]),
                    "error_text": "Failed to Update Customer Rate Plan",
                    "processed_date": datetime.datetime.now(),
                    "processed_by": username,
                    "created_by": username,
                    "created_date": datetime.datetime.now(),
                    "is_deleted": False,
                    "is_active": True
                }
                log_entry['processed_date'] = log_entry['processed_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entry['created_date'] = log_entry['created_date'].strftime('%Y-%m-%d %H:%M:%S')
                log_entries.append(log_entry)
            spectrotel_database.insert_data(log_entries, "sim_management_bulk_change_log")

        # Async sync between 1.0 and 2.0
        # def start_sync():
        #     data["bulk_chnage_id_20"] = bulk_change_id
        #     bulk_change_id_ = spectrotel_database.get_data(
        #         "sim_management_bulk_change",
        #                 {"id": bulk_change_id},  # Filter condition
        #                 [
        #                     "change_request_type",
        #                     "change_request_type_id",
        #                     "created_by",
        #                     "is_active",
        #                     "is_deleted",
        #                     "modified_by",
        #                     "processed_by",
        #                     "service_provider_id",
        #                     "service_provider",
        #                     "status",
        #                     "tenant_id",
        #                     "uploaded",
        #                 ],  # Fields to retrieve
        #             ).to_dict("records")

        #     data["data"]["sim_management_bulk_change"] = bulk_change_id_
        #     try:
        #         sync_call = sync_data_bulk_change()
        #         sync_data_bulk_change_tables(data)
        #         if sync_call:
        #             logging.info("Sync call completed")
        #             spectrotel_database.update_dict(
        #                 "sim_management_bulk_change",
        #                 {"progress": "Sync Completed"},
        #                 {"id": bulk_change_id},
        #             )
        #     except Exception as e:
        #         logging.exception(f"Failed to sync in update_assign_customer: {e}")

        # threading.Thread(target=start_sync).start()

        for iccid in iccids:
            insert_history_data(db_config, tenant_database, iccid, service_provider)

        if iccids:
            customer_data_allocation_mb = None
            customer_rate_plan_id = None
            customer_rate_pool_id = None
            effective_date = None
            insert_customer_rate_plan_history_data(
                db_config,
                tenant_database,
                bulk_change_id or None,  # Convert empty string to None
                customer_rate_plan_id or None,
                customer_rate_pool_id or None,
                effective_date or None,
                customer_data_allocation_mb or None
            )

        response = {
            "flag": True,
            "message": f"Carrier Rate Plan update successful in Bulk Change. {updated_count} ICCIDs were updated."
        }

        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "update_webbing_carrier_rate_plan_name",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": f'Update Customer Rate Plan for bulk change {bulk_change_id} has been called successfully',
                "module_name": "sm bulk change",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
        # If update is successful
        return response


    except Exception as e:
        # Handle any errors that occur during the process
        logging.exception(f"Error updating customer rate plan: {e}")
        error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "update_webbing_carrier_rate_plan_name",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Error in updating Carrier Rate Plan for bulk_change_id: {bulk_change_id}",
            "module_name": "sm bulk change",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "An error occurred while updating the customer rate plan."}



def get_rev_field_index(fields, target_label):
    """Returns index of field with label matching target_label."""
    for idx, field in enumerate(fields):
        if field.get("label", "").strip().lower() == target_label.strip().lower():
            return field.get("field_id")
    return -1


def send_revio_request_username(service_id, username, password, token, main_url, contact_name):
    """
    Sends a GET request to the Revio API for a specific service ID.
    If 'record_count' > 0, it updates a field using a PATCH request.
    """
    try:
        # Prepare authentication and headers
        auth_token = base64_encode(f"{username}:{base64_decode(password)}")
        subscription_key = base64_decode(token)


        url = f"{main_url}?search.service_id={service_id}"
        headers = {
            "Authorization": f"Basic {auth_token}",
            "Ocp-Apim-Subscription-Key": subscription_key,
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

        # Send the GET request
        response = requests.get(url, headers=headers)

        # Check if response is valid JSON
        try:
            response_json = response.json()
        except Exception:
            return {"flag": False, "message": "Invalid JSON response from API"}

        fields = response_json.get("records", [{}])[0].get("fields", [])
        index = get_rev_field_index(fields, "User Name")

        if index == -1:
            return {"flag": True, "message": "Update the User Name to Database directly as field not found"}

        if response.status_code == 200 and response_json.get("record_count", 0) > 0:
            update_data = [{
                "value": contact_name,
                "path": f"/fields/{index}/value",
                "op": "replace"
            }]

            patch_url = f"{main_url}/{service_id}"
            headers_patch = {
                "Authorization": f"Basic {auth_token}",
                "Ocp-Apim-Subscription-Key": subscription_key,
                "Accept": "application/json",
                "Content-Type": "application/json-patch+json"
            }

            responses = requests.patch(patch_url, headers=headers_patch, json=update_data)

            if responses.status_code in [200, 202]:
                return {"flag": True}
            else:
                try:
                    error_message = responses.json()[0].get("message", "Unknown error")
                except Exception:
                    error_message = responses.text
                return {"flag": True, "message": error_message}

        print("Unable to find the record count")
        return {"flag": False, "message": "Unable to find the record count for this service"}

    except Exception as e:
        return {"flag": False, "message": f"Failed due to: {str(e)}"}



def update_webbing_user_name(data):
    """
        Updates the username for a given set of ICCIDs in a bulk change request.
        It validates ICCIDs, processes them using external API calls, logs the results,
        and updates the database with the new username for successful ICCIDs.

        Args:
            data (dict): A dictionary containing various parameters, including:
                - 'request_received_at': Timestamp of when the request was received
                - 'sessionID': Session ID for tracking the user session
                - 'tenant_name': Tenant name for multi-tenant database support
                - 'username': User who is initiating the request
                - 'changed_data': Contains the fields to be updated (e.g., 'CostCenter1')
                - 'iccids': List of ICCIDs to be processed
                - 'service_provider': The name of the service provider
                - 'carrier_api_status': Flag indicating whether to raise an error if carrier API fails
                - 'bulk_change_id': The ID of the bulk change request

        Returns:
            dict: A dictionary with the following keys:
                - 'flag': True if all ICCIDs were successfully updated, False if any failed
                - 'message': A message indicating success or failure with details about failed ICCIDs
                - 'response_api': The status code of the API response for further tracking

        Raises:
            Exception: If any unexpected errors occur during processing, an exception is raised and logged.

        The function performs the following tasks:
            - Validates the input data and connects to the relevant databases.
            - Verifies the existence of the provided ICCIDs and ensures they are associated with the service provider.
            - Retrieves authentication details for external services.
            - Processes each ICCID by sending requests to external systems (core and RevIO requests).
            - Logs the results for each ICCID and updates the database for successful/failed ICCIDs.
            - Tracks the time taken for the process and updates an audit log for monitoring.
    """
    logging.info(f"### update_webbing_user_name Request Data Received : {data}")
    # Start time  and date calculation
    start_time = time.time()
    request_received_at = data.get('request_received_at', '')
    ui_session_id = data.get('sessionID', '')
    tenant_name = data.get('tenant_name', '')
    username = data.get('username', '')
    # change_type= data.get('change_type', '')
    changed_data = data.get("changed_data", {})
    carrier_api_status=data.get('carrier_api_status',False)
    bulk_change_id = data.get('bulk_change_id')

    # Database connection
    tenant_database = data.get("db_name", "")
    try:
        spectrotel_database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}

    service_provider = data.get('service_provider')
    iccids = data.get('iccids', [])

    serviceprovider_data = spectrotel_database.get_data(
                        "serviceprovider",
                        {"service_provider_name": service_provider},
                        ["integration_id", "id"],
                    )
    # integration_id = serviceprovider_data["integration_id"].to_list()[0]
    service_provider_id = serviceprovider_data["id"].to_list()[0]

    try:
        if not iccids:
            logging.warning("No ICCIDs provided.")
            return {"flag": False, "message": "No ICCIDs provided in the request."}

        # Check if ICCIDs exist
        missing_iccids = check_iccids_exist(spectrotel_database, iccids, service_provider)

        if missing_iccids is None:
            return {"flag": False, "message": "An error occurred during the ICCID check."}

        if missing_iccids:
            bulk_change_validation_update(data)
            logging.info(f"The following ICCIDs are not associated with the {service_provider}: {', '.join(missing_iccids)}")


        for iccid in iccids:
            insert_history_data(db_config, tenant_database, iccid, service_provider)

        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        tenant_id=common_utils_database.get_data('tenant',{"tenant_name":tenant_name},['id'])['id'].to_list()[0]



        contact_name = changed_data.get("ContactName")

        if contact_name is None:
            return {"flag": False, "message": "Username is missing ."}
        #Fetch the authenticaion details
        autentication_details = common_utils_database.get_data(
                            "integration_authentication",
                            {"authentication_type": 13, "integration_id": 3},
                        ).to_dict(orient="records")[0]

        if not autentication_details:
            logging.error("Authentication details not found.")
            return {"flag": False, "message": "Authentication details missing."}

        username_api = autentication_details["username"]
        password = autentication_details["password"]
        # client_id = autentication_details["oauth2_client_id"]
        # client_secret = autentication_details["oauth2_client_secret"]
        token = autentication_details["token_value"]

        # Track success and failure
        successful_iccids = []
        failed_iccids = []
        # log_entries = []  # List to store log entries for bulk insert
        bulk_change_request_ids = spectrotel_database.get_data(
            'sim_management_bulk_change_request',
            {'iccid': iccids,"bulk_change_id":bulk_change_id},
            ['id', 'iccid']
        ).to_dict(orient='records')
        iccid_to_request_id = {entry['iccid']: entry['id'] for entry in bulk_change_request_ids}
        # Process each ICCID separately
        for iccid in iccids:
            bulk_change_request_id = iccid_to_request_id.get(iccid)
            processd_flag = False  # Reset processed flag for each ICCID



            # Fetch device/service details for ICCID

            query = f"""
                SELECT smi.device_id, smi.mobility_device_id,
                    rs.rev_service_id AS d_rev_service_id,
                    rs.rev_service_id AS m_rev_service_id
                FROM sim_management_inventory smi
				left join rev_service rs on rs.number=smi.msisdn and integration_authentication_id=4
                WHERE iccid = '{iccid}' and smi.tenant_id={tenant_id}
            """
            service_id_data = spectrotel_database.execute_query(query, True)
            # Convert columns to lists
            m_rev_service_ids = service_id_data["m_rev_service_id"].dropna().tolist()
            d_rev_service_ids = service_id_data["d_rev_service_id"].dropna().tolist()

            # Select the first available value
            m_rev_service_id = m_rev_service_ids[0] if m_rev_service_ids else None
            d_rev_service_id = d_rev_service_ids[0] if d_rev_service_ids else None
            m_rev_service_id = int(m_rev_service_id) if m_rev_service_id is not None else None
            d_rev_service_id = int(d_rev_service_id) if d_rev_service_id is not None else None

            main_url = common_utils_database.get_data(
                "inventory_actions_urls",
                {"service_provider_id": str(service_provider_id), "action": "Edit Update Username"},
                ["main_url"],
            )["main_url"].to_list()[0]

            response_revio_m = []
            response_revio_d = []


            # Send RevIO requests if service IDs exist
            # RevIO requests with or without contact name
            if m_rev_service_id:
                response_revio_m = send_revio_request_username(
                    m_rev_service_id, username_api, password, token, main_url, contact_name
                )

                if response_revio_m["flag"]:
                    processd_flag = True

            if d_rev_service_id:
                if contact_name:
                    response_revio_d = send_revio_request_username(
                        d_rev_service_id, username_api, password, token, main_url, contact_name
                    )


                if response_revio_d["flag"]:
                    processd_flag = True

            # Trigger exception only if both service IDs have values and carrier_api_status is True
            if (m_rev_service_id or d_rev_service_id) and carrier_api_status:
                # Check if both responses failed
                if (not response_revio_m.get("flag") and not response_revio_d.get("flag")):
                    if 'message' in response_revio_m or 'message' in response_revio_d:
                        raise ValueError(f"{response_revio_d.get('message', '') or response_revio_m.get('message', '')}")
                    else:
                        logging.exception(f"Carrier API status is {carrier_api_status} and both RevIO requests failed. Raising exception.")
                        raise ValueError("Request was not processed!")

            # Set log description based on the presence of RevIO service IDs
            if m_rev_service_id or d_rev_service_id:
                log_description = f"Processing ICCID: {iccid}"
            else:
                log_description = f"No RevIO service ID for ICCID {iccid}. username update only inn inventory table."


            # Log entry for each ICCID
            log_entry = {
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": bulk_change_request_id,
                "log_entry_description": log_description,
                "request_text": json.dumps(changed_data),
                "has_errors": not processd_flag,
                "response_status": "SUCCESS" if processd_flag else "ERROR",
                "response_text": json.dumps(response_revio_d if d_rev_service_id else response_revio_m),
                "error_text": (response_revio_d if d_rev_service_id else response_revio_m)
                                if not processd_flag else "",
                "processed_date": datetime.datetime.now(),
                "processed_by": username,
                "created_by": username,
                "created_date": datetime.datetime.now(),
                "is_deleted": False,
                "is_active": True
            }
            spectrotel_database.insert_data(log_entry, "sim_management_bulk_change_log")

            if processd_flag:
                successful_iccids.append(iccid)
            else:
                failed_iccids.append(iccid)


            if (m_rev_service_id is None or d_rev_service_id is None) and not processd_flag:
                successful_iccids.append(iccid)

        # Update data for bulk update
        update_data = {}


        if contact_name:
            update_data["username"] = contact_name


        result = bulk_update_dict(spectrotel_database, update_data, successful_iccids)
        logging.info(f"Result of bulk update: {result}")


        failed_count = result['failed_count']
        updated_count = result['updated_count']

        # Update `sim_management_bulk_change` table
        bulk_change_id = data.get('bulk_change_id')  # Ensure bulk_change_id is included in the request
        if failed_count != 0:
            spectrotel_database.update_dict(
                'sim_management_bulk_change',
                {"success": updated_count, "errors": failed_count, "status": "ERROR"},
                {'id': bulk_change_id}
            )
        else:
            spectrotel_database.update_dict(
                'sim_management_bulk_change',
                {"success": updated_count, "errors": failed_count, "status": "PROCESSED"},
                {'id': bulk_change_id}
            )

        # Update `sim_management_bulk_change_request` for successful and failed ICCIDs
        if successful_iccids:
            spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values={
                    "status": "PROCESSED",
                    "change_request": json.dumps(changed_data),
                    "is_processed": True,
                    "has_errors": False
                },
                in_conditions={'iccid': successful_iccids}
            )

            # call insert_device_history_records to insert records into device_history tables
            thread = threading.Thread(target=insert_device_history_records, args=(tenant_name, username, successful_iccids, service_provider, tenant_database))
            thread.start()

        if failed_iccids:
            spectrotel_database.update_dict(
                table_name="sim_management_bulk_change_request",
                values={
                    "status": "ERRORS",
                    "change_request": json.dumps(changed_data),
                    "is_processed": False,
                    "has_errors": True
                },
                in_conditions={'iccid': failed_iccids}
            )

        # Async sync between 1.0 and 2.0
        # def start_sync():
        #     data["bulk_chnage_id_20"] = bulk_change_id
        #     bulk_change_id_ = spectrotel_database.get_data(
        #         "sim_management_bulk_change",
        #                 {"id": bulk_change_id},  # Filter condition
        #                 [
        #                     "change_request_type",
        #                     "change_request_type_id",
        #                     "created_by",
        #                     "is_active",
        #                     "is_deleted",
        #                     "modified_by",
        #                     "processed_by",
        #                     "service_provider_id",
        #                     "service_provider",
        #                     "status",
        #                     "tenant_id",
        #                     "uploaded",
        #                 ],  # Fields to retrieve
        #             ).to_dict("records")

        #     data["data"]["sim_management_bulk_change"] = bulk_change_id_

        #     try:
        #         sync_call = sync_data_bulk_change()
        #         sync_data_bulk_change_tables(data)
        #         if sync_call:
        #             logging.info("Sync call completed")
        #             spectrotel_database.update_dict(
        #                 "sim_management_bulk_change",
        #                 {"progress": "Sync Completed"},
        #                 {"id": bulk_change_id},
        #             )
        #     except Exception as e:
        #         logging.exception(f"Failed to sync in update_assign_customer: {e}")

        # threading.Thread(target=start_sync).start()


        if iccids:
            customer_data_allocation_mb = None
            customer_rate_plan_id = None
            customer_rate_pool_id = None
            effective_date = None
            insert_customer_rate_plan_history_data(
                db_config,
                tenant_database,
                bulk_change_id or None,  # Convert empty string to None
                customer_rate_plan_id or None,
                customer_rate_pool_id or None,
                effective_date or None,
                customer_data_allocation_mb or None
            )


        # End time calculation
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))

        # Log audit data
        try:
            audit_data_user_actions = {
                "service_name": "update_webbing_user_name",
                "created_date": request_received_at,
                "created_by": username,
                "status": "PROCESSED" if failed_count == 0 else "ERROR",
                "time_consumed_secs": time_consumed,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": f'Update webbing Username for bulk change {bulk_change_id} has been called successfully',
                "module_name": "sm bulk change",
                "request_received_at": request_received_at,
                "trace_id": json.dumps(response_revio_d)
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit log exception: {e}")

        # Final response
        return {
            "flag": True if failed_count == 0 else False,
            "message": "Cost Center update successful for all ICCIDs." if failed_count == 0 else
            f"Cost Center update failed for {failed_count} ICCIDs."
        }

    except Exception as e:
        error_type = str(type(e).__name__)

        # Log error
        error_data = {
            "service_name": "update_webbing_user_name",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Error in updating webbing user name for bulk_change_id: {bulk_change_id}",
            "module_name": "sm bulk change",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": f"An error occurred while updating the Cost Center.{e}"}


def bulk_update_change_phone_number(data):
    """
    Updates phone numbers (MSISDNs) for a list of devices in a bulk change request.
    
    This function processes a bulk change request to update phone numbers, validates the input data,
    makes API calls to update the numbers in external systems, and updates the database records.
    It tracks successful and failed updates, logs the results, and updates the bulk change status.
    
    Args:
        data (dict): A dictionary containing request data, including:
            - 'request_received_at': Timestamp when the request was received
            - 'sessionID': Session ID for tracking
            - 'tenant_name': Name of the tenant
            - 'bulk_change_id': ID of the bulk change request
            - 'username': Username of the person initiating the request
            - 'db_name': Name of the tenant database
            - 'changed_data': Contains old and new MSISDNs to be updated
    
    Returns:
        dict: A dictionary with status information:
            - 'flag' (bool): True if successful, False otherwise
            - 'message' (str): Description of the result or error
    """
    logging.info(f"Request Data Received: {data}")
    start_time = time.time()
    request_received_at = data.get('request_received_at', '')
    ui_session_id = data.get('sessionID', '')
    tenant_name = data.get('tenant_name', '')
    # change_type = data.get("change_type", "")
    bulk_change_id = data.get('bulk_change_id', '')
    username = data.get('username', '')
    tenant_database = data.get("db_name", "")
    tenant_name = data.get('tenant_name', '')
    if tenant_name == 'Altaworx Test':
        tenant_name = 'Altaworx'

    try:
        spectrotel_database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}

    # service_provider = data.get('service_provider')
    tenant_id = common_utils_database.get_data('tenant', {"tenant_name": tenant_name}, ['id'])['id'].to_list()[0]

    changed_data = data.get("changed_data", {})
    old_msisdn = changed_data.get('old_msisdn', [])
    new_msisdns = changed_data.get('new_msisdn', [])
    # effective_date = changed_data.get('effective_date', None)

    if len(old_msisdn) != len(new_msisdns):
        logging.error("Mismatch in old and new MSISDN counts.")
        return {"flag": False, "message": "The number of old and new MSISDNs must be the same."}

    msisdn_mapping = dict(zip(old_msisdn, new_msisdns))
    # update_data = {}
    # carrier_response_data = {}

    try:
        # Query inventory by old MSISDN and retrieve IDs
        inventory_dic = spectrotel_database.get_data(
            'sim_management_inventory',
            {'msisdn': old_msisdn, "is_active": True, "tenant_id": tenant_id},
            ['id', 'msisdn', 'billing_account_number', 'service_zip_code']
        )
        if inventory_dic.empty:
            logging.info("No records found for the provided MSISDNs.")
            return {"flag": False, "message": "No records found for the provided MSISDNs."}

        # inventory_ids = inventory_dic['id'].to_list()
        # old_msisdns_in_inventory = inventory_dic['msisdn'].to_list()

        successful_ids = []
        failed_ids = []
        successful_updates = []
        response_texts = {}

        url = "https://apsapi.att.com:8082/api/mobility/numberchange/v2/change/zipcode"
        headers = {
            "app-id": "17fac23b77124a399cd87184f79ec608",
            "app-secret": "d0Da41D483884cE3A6Aa45b1B79DE9E0",
            "Content-Type": "application/json"
        }

        inventory_records = inventory_dic.to_dict(orient='records')
        id_payload_map = {}

        batch_size = 10
        # total_start_time = time.time()
        for i in range(0, len(inventory_records), batch_size):
            # batch_start_time = time.time()
            batch_records = inventory_records[i:i+batch_size]
            batch_tasks = []

            for record in batch_records:
                inventory_id = record['id']
                old_number = record['msisdn']
                new_number = msisdn_mapping.get(old_number)

                if new_number is None:
                    failed_ids.append(inventory_id)
                    response_texts[inventory_id] = "No new MSISDN mapped"
                    continue

                payload = {
                    "billingAccountNumber": record['billing_account_number'],
                    "subscriberNumber": new_number,
                    "serviceZipCode": record['service_zip_code']
                }

                id_payload_map[inventory_id] = payload
                batch_tasks.append({
                    "inventory_id": inventory_id,
                    "old_number": old_number,
                    "new_number": new_number,
                    "payload": payload
                })

            for task in batch_tasks:
                try:
                    # request_start_time = time.time()
                    response = requests.post(url, headers=headers, json=task['payload'], timeout=30)
                    # request_duration = time.time() - request_start_time
                    response_text = response.text

                    if response.status_code == 200:
                        response_json = response.json()
                        if response_json.get("numberChangeInfo", {}).get("status") == "SUCCESS":
                            api_new_number = response_json.get("numberChangeInfo", {}).get("newSubscriberNumber")
                            if api_new_number and api_new_number != task['new_number']:
                                logging.info(f"API returned different new number: {api_new_number}")
                                task['new_number'] = api_new_number


                            successful_ids.append(task['inventory_id'])
                            successful_updates.append((task['inventory_id'], task['new_number']))
                            response_texts[task['inventory_id']] = response_text
                        else:
                            failed_ids.append(task['inventory_id'])
                            response_texts[task['inventory_id']] = response_text
                    else:
                        failed_ids.append(task['inventory_id'])
                        response_texts[task['inventory_id']] = response_text
                except Exception as api_error:
                    error_message = str(api_error)
                    failed_ids.append(task['inventory_id'])
                    response_texts[task['inventory_id']] = f"API Error: {error_message}"

            # batch_duration = time.time() - batch_start_time

        # total_duration = time.time() - total_start_time

        # Update database with successful changes
        updated_count = 0
        for inventory_id, new_msisdn in successful_updates:
            update_success = spectrotel_database.update_dict(
                'sim_management_inventory',
                {'msisdn': new_msisdn},
                {'id': inventory_id, "tenant_id": tenant_id}
            )
            if update_success:
                updated_count += 1
            else:
                if inventory_id in successful_ids:
                    successful_ids.remove(inventory_id)
                    failed_ids.append(inventory_id)

        failed_count = len(failed_ids)
        updated_count = len(successful_ids)


        # Update bulk change status
        status = "PROCESSED" if failed_count == 0 else "ERROR"
        spectrotel_database.update_dict(
            'sim_management_bulk_change',
            {
                "success": updated_count,
                "errors": failed_count,
                "status": status,
                "processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            {'id': bulk_change_id}
        )

        # Fetch bulk change requests and create mapping
        bulk_change_requests = spectrotel_database.get_data(
            'sim_management_bulk_change_request',
            {'subscriber_number': old_msisdn, "bulk_change_id": bulk_change_id},
            ['id', 'subscriber_number']
        ).to_dict(orient='records')

        msisdn_to_request_id = {req['subscriber_number']: req['id'] for req in bulk_change_requests}

        # Update bulk change requests with payloads and correct status
        msisdn_payload_map = {}
        for record in inventory_records:
            old_number = record['msisdn']
            msisdn_payload_map[old_number] = {
                "billingAccountNumber": record['billing_account_number'],
                "subscriberNumber": msisdn_mapping.get(old_number),
                "serviceZipCode": record['service_zip_code']
            }

        # Create mapping from old MSISDN to inventory ID
        msisdn_to_inventory_id = {record['msisdn']: record['id'] for record in inventory_records}

        for request in bulk_change_requests:
            msisdn = request['subscriber_number']
            payload = msisdn_payload_map.get(msisdn)
            inventory_id = msisdn_to_inventory_id.get(msisdn)
            
            # Determine status based on inventory ID presence in successful_ids
            if inventory_id and inventory_id in successful_ids:
                status = "PROCESSED"
                has_errors = False
            else:
                status = "ERROR"
                has_errors = True
            
            if payload:
                spectrotel_database.update_dict(
                    'sim_management_bulk_change_request',
                    {
                        'change_request': json.dumps(payload),
                        "status_details": response_texts.get(inventory_id, ""),
                        "has_errors": has_errors,
                        "status": status
                    },
                    {'id': request['id']}
                )

        # Prepare log entries with correct request IDs
        log_entries = []
        for inventory_id in successful_ids + failed_ids:
            inventory_record = inventory_dic[inventory_dic['id'] == inventory_id]
            request_id = None
            if not inventory_record.empty:
                old_msisdn = inventory_record['msisdn'].iloc[0]
                request_id = msisdn_to_request_id.get(old_msisdn)

            payload = id_payload_map.get(inventory_id, {})
            log_entry = {
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Processing msisdn ID: {old_msisdn}",
                "request_text": json.dumps(payload),
                "has_errors": inventory_id in failed_ids,
                "response_status": "PROCESSED" if inventory_id in successful_ids else "ERROR",
                "response_text": response_texts.get(inventory_id, ""),
                "error_text": response_texts.get(inventory_id, "") if inventory_id in failed_ids else "",
                "processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "processed_by": username,
                "created_by": username,
                "created_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "is_deleted": False,
                "is_active": True
            }
            log_entries.append(log_entry)

        if log_entries:
            spectrotel_database.insert_data(log_entries, "sim_management_bulk_change_log")

        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        try:
            audit_data = {
                "service_name": "bulk_update_change_phone_number",
                "created_date": request_received_at,
                "created_by": username,
                "status": "PROCESSED" if failed_count == 0 else "ERROR",
                "time_consumed_secs": int(float(time_consumed)),
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": f'Bulk phone number change for {bulk_change_id} has been processed successfully.',
                "module_name": "sm bulk change",
                "request_received_at": request_received_at,
            }
            common_utils_database.insert_data([audit_data], "audit_user_actions")
        except Exception as audit_error:
            logging.exception(f"Failed to log audit data: {audit_error}")

        return {
            "flag": True,
            "message": f"Bulk phone number update completed. Success: {updated_count}, Failed: {failed_count}"
        }

    except Exception as e:
        error_type = type(e).__name__
        error_data = {
            "service_name": "bulk_update_change_phone_number",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Error in bulk phone number change for bulk_change_id: {bulk_change_id}",
            "module_name": "sm bulk change",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": f"An error occurred during processing: {str(e)}"}





    

def get_carrier_api_details(service_provider,change_type,common_utils_database):
    '''
    Function to get the Carrier API URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The Carreir API URL,app_id,app_secret if found, otherwise None.'''
    # Initialize variables
    carrier_api_url=None
    app_id=None
    app_secret=None
    carrier_limit=None

    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    carrier_details= common_utils_database.get_data(
    "bulk_change_carrier_limits", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["carrier_api_url","app_id","app_secret","carrier_limit"]
    )
    if not carrier_details.empty:
        carrier_api_url=carrier_details.iloc[0]['carrier_api_url']
        app_id=carrier_details.iloc[0]['app_id']
        app_secret=carrier_details.iloc[0]['app_secret']
        carrier_limit=carrier_details.iloc[0]['carrier_limit']
        return carrier_api_url,carrier_limit,app_id,app_secret
    else:
        return carrier_api_url,carrier_limit,app_id,app_secret
    
def validating_sims(data,database,common_utils_database):
    """
    Validates SIMs (ICCID or MSISDN) based on availability and active status.

    Args:
        data (dict): Request data containing 'iccids' or 'msisdns'.

    Returns:
        dict: Updated data with only validated SIMs.
    """
    logging.info(f"### validating_sims Received data : {data}")
    # Validate required fields
    iccids = data.get("iccids", [])
    msisdns = data.get("msisdns", [])
    tenant_id = data.get("tenant_id", None)
    bulk_change_id = data.get("bulk_change_id", None)
    try:
        # Determine which key to use for validation
        filter_key = "iccid" if iccids else "msisdn"
        values = iccids if iccids else msisdns

        if not values:
            return {"error": "No ICCIDs or MSISDNs provided for validation."}

        # Query only active SIMs matching the ICCIDs or MSISDNs
        filter_conditions = {"is_active": True, filter_key: values,"tenant_id":tenant_id}
        df = database.get_data("sim_management_inventory", filter_conditions,['iccid','msisdn'])

        # Extract validated values
        validated = df[filter_key].tolist() if not df.empty else []
        invalid = list(set(values) - set(validated))
        if invalid:
             # Use update_dict with in_conditions to match multiple entries
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "INVALID"},
                and_conditions={"bulk_change_id": bulk_change_id},  # optional pre-filter
                in_conditions={filter_key: invalid}
            )
        ##updating the counts
        database.update_dict(
                'sim_management_bulk_change',
                {
                    "errors": len(invalid),
                    "processed_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                },
                {'id': bulk_change_id}
            )
        # Replace original list in data
        data[filter_key + "s"] = validated
        if iccids:
            data["invalid_iccids"] = invalid
        else:
            data["invalid_msisdns"] = invalid
            invalid_ids_query = """
                SELECT id 
                FROM sim_management_bulk_change_request  
                WHERE bulk_change_id = %s 
                AND (subscriber_number IS NULL OR TRIM(subscriber_number) = '')
            """
            params = [bulk_change_id]

            # Execute the query
            invalid_ids_df = database.execute_query(invalid_ids_query, params=params)

            # Add to data if any invalid records are found
            if not invalid_ids_df.empty:
                data["invalid_ids"] = invalid_ids_df["id"].to_list()
        return data
    except Exception as e:
        logging.error("Error during SIM validation: %s", str(e))
        return data
    
    
def worker_for_update_device_status(msisdn,data,database, 
                                     msisdn_to_changerequest,
                                       msisdn_to_request_id, carrier_api_url, 
                                       headers,now):  
    '''
    Worker function to update device status using the Telegence API.
    This function is designed to be run in parallel for each MSISDN in the list.
    Args:
        msisdn (str): The MSISDN to process.
        database (DB): Database connection object.
        changed_data (dict): Data to be sent to the Telegence API.
        bulk_change_id (str): ID of the bulk change request.
        tenant_id (str): ID of the tenant.
        created_by (str): User who initiated the request.   
        msisdn_to_changerequest (dict): Mapping of MSISDNs to change requests.
        msisdn_to_request_id (dict): Mapping of MSISDNs to request IDs
        carrier_api_url (str): URL of the Telegence API to call.
        headers (dict): Headers to include in the API request.
    Returns:
        tuple: A tuple containing the MSISDN and a log entry dictionary.
    '''
    # tenant_id = data.get("tenant_id", "")
    bulk_change_id = data.get("bulk_change_id", "")
    created_by = data.get("created_by", "")
    sim_status=data.get('sim_status','Restore Cancelled')
    integration_id=data.get('integration_id','6')
    device_status_id=None
    ##step 1 fetching the payload from the msisdn_to_changerequest
    logging.info("Processing MSISDN: %s", msisdn)
    payload_str = msisdn_to_changerequest.get(msisdn)
    # Step 2: Convert JSON string to dict
    payload_dict = json.loads(payload_str)
    # Step 3: Extract the 'Request' part
    request_payload = payload_dict.get("Request")
    url = f"{carrier_api_url}/{msisdn}"
    MAX_RETRIES = 3
    RETRY_DELAY = 5  # seconds
    success = False
    status = "API_FAILED"
    result = ""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            logging.info("Attempt %d - url: %s, payload: %s, headers: %s", attempt, url, request_payload, headers)
            resp = requests.patch(url, json=request_payload, headers=headers, timeout=60)
            logging.info("Response Code: %s", resp.status_code)
            logging.info("Response Text: %s", resp.text)

            success = 200 <= resp.status_code < 300
            status = "PROCESSED" if success else "API_FAILED"
            result = resp.text

            if success:
                break  # exit retry loop on success
        except Exception as e:
            result = str(e)
            logging.warning("Attempt %d failed with exception: %s", attempt, result)

    if not success and attempt < MAX_RETRIES:
        logging.info("Retrying in %d seconds...", RETRY_DELAY)
        time.sleep(RETRY_DELAY)
    if success:
        update_data = {
        "status": status,
        "has_errors": False,
        "is_processed": True
        }
    else:
        update_data = {
            "status": status,
            "has_errors": True,
            "is_processed": True
        }
    # Always update the request status
    database.update_dict(
        "sim_management_bulk_change_request",
        update_data,
        and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id},
    )
    ##fecth the device status id
    device_status_data = database.get_data(
        "device_status",
        {"description": sim_status, "integration_id": integration_id},
        ["id"]
    )
    if not device_status_data.empty:
        device_status_id = device_status_data["id"].to_list()[0]
        if device_status_id:
            device_status_id=int(device_status_id)
    else:
        device_status_id = None
    # If device_status_id is None, set a default value or handle the error
    # Only update inventory if API succeeded
    if success:
        database.update_dict(
            "sim_management_inventory",
            {"sim_status": sim_status, "device_status_id": device_status_id},
            and_conditions={"msisdn": msisdn, "is_active": True}
        )
    log = {
        "bulk_change_id": bulk_change_id,
        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
        "log_entry_description": "Update Telegence Subscriber: Telegence API",
        "request_text": json.dumps(request_payload),
        "has_errors": status == "API_FAILED",
        "response_status": "PROCESSED" if success else "API_Failed",
        "response_text": result,
        "error_text": "" if status == "PROCESSED" else result,
        "processed_date": now,
        "processed_by": created_by,
        "created_by": created_by,
        "created_date": now,
        "is_deleted": False,
        "is_active": True
    }
    return msisdn, log
    
    


def telegence_bc_update_device_status_restore_cancelled(data):
    '''
    Update the device status using the Telegence API.
    This function processes a list of MSISDNs and updates their status in the Telegence system.
    It handles bulk requests, updates the database, and logs the results.
    Args:
        data (dict): Input data containing the following keys:
            - msisdns (list): List of MSISDNs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Telegence API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
        context (dict): Lambda context object containing execution details.
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    '''
    logging.info(f"### telegence_bc_update_device_status_restore_cancelled Received data {data}")
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    changed_data = data.get("changed_data")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    
    # SQS setup
    TIMEOUT_LIMIT_SECONDS = 600  # 10 minutes
    # Initialize for log entries
    log_entries = []
    ## current time
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # Basic validation
    logging.info(f"bulk_change_id: {bulk_change_id}")
    if not bulk_change_id:
        logging.error("Missing required fields: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    
    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    
    try:
        # Validate SIMs using validating_sims function
        logging.info("Validating MSISDNs before processing...")
        validated_data = validating_sims(data, database, common_utils_database)
        
        # Check if validation returned an error
        if "error" in validated_data:
            logging.error(f"SIM validation failed: {validated_data['error']}")
            return {"flag": False, "message": validated_data["error"]}
        
        # Extract validated MSISDNs and invalid ones
        msisdns = validated_data.get("msisdns", [])
        invalid_msisdns = validated_data.get("invalid_msisdns", [])
        invalid_ids = validated_data.get("invalid_ids", [])
        
        logging.info(f"Validation results - Valid MSISDNs: {len(msisdns)}, Invalid MSISDNs: {len(invalid_msisdns)}, Invalid IDs: {len(invalid_ids)}")
        
        # # If no valid MSISDNs remain, return early
        # if not msisdns:
        #     logging.warning("No valid MSISDNs found after validation")
        #     return {
        #         "flag": False, 
        #         "message": "No valid MSISDNs found for processing",
        #         "invalid_msisdns": invalid_msisdns,
        #         "invalid_ids": invalid_ids,
        #         "bulk_change_id": bulk_change_id
        #     }
        
        # Carrier API details
        try:
            carrier_api_url, carrier_limits, app_id, app_secret = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        msisdn_to_changerequest = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.change_request))
        
        ## Prepare headers for API call
        headers = {
            "app-id": app_id,
            "app-secret": app_secret,
            "Content-Type": "application/json"
        }
        
        # Validate MSISDNs
        remaining = msisdns.copy()
        logs = []
        
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"Invalid carrier_limits JSON: {carrier_limits}")
                raise e
        
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        interval = carrier_limits["interval_minutes"] * 60
        
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(msisdns), batch_size):
                batch = msisdns[i:i+batch_size]
                futures = {
            executor.submit(
                worker_for_update_device_status,
                        msisdn,
                        data,
                        database,
                        msisdn_to_changerequest,
                        msisdn_to_request_id,
                        carrier_api_url,
                        headers,
                        now
                    ): msisdn 
                    for msisdn in batch
                }
                for fut in as_completed(futures):
                    msisdn, log = fut.result()
                    logs.append(log)
                    remaining.remove(msisdn)

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")
        
        # ✅ Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        
        logging.info("Processed %d MSISDNs, %d remaining", len(msisdns) - len(remaining), len(remaining))
        
        if invalid_msisdns:
            # Log invalid MSISDNs
            for msisdn in invalid_msisdns:
                request_id = msisdn_to_request_id.get(msisdn)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Update Telegence Subscriber: Telegence API",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid MSISDN",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        
        if invalid_ids:
            logging.info(f"### Invalid IDs found: {invalid_ids}")
            # Log invalid IDs
            for request_id in invalid_ids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Update Device Status",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid MSISDN - subscriber_number is null or empty",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
            
            # Update invalid IDs status in bulk_change_request table
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "PROCESSED","is_processed":True,"has_errors":True},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"id": invalid_ids},
            )
        
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        
        logging.info(f"### Inserted %d log entries for bulk change request {len(log_entries)}")
        logging.info("Bulk Change Completed in %.1fs", time.time() - start_time)
        
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "invalid_ids": invalid_ids, "bulk_change_id": bulk_change_id}
        
        # find valid msisdns
        valid_msisdns = [msisdn for msisdn in msisdns if msisdn not in invalid_msisdns and msisdn not in invalid_ids]
        # call insert_device_history_records to insert records into device_history tables
        thread = threading.Thread(
            target=insert_device_history_records,
            args=(tenant_name, username, [], service_provider, tenant_database),
            kwargs={"msisdns": valid_msisdns}
        )
        thread.start()
        
        # Attempt to audit the action
        try:
            audit_data_user_actions = {
                "service_name": "telegence_bc_update_device_status_restore_cancelled",
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "sm bulk change",
                "comments": f"Successfully processed bulk change request for Restore Cancelled status for devices.{msisdns}",
                "request_received_at": data.get("request_received_at") or datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging failed: {e}")
        
        return response
        
    except Exception as e:
        # Main exception block
        logging.exception(f"### Error during bulk change processing: {e}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns if 'invalid_msisdns' in locals() else [],
            "invalid_ids": invalid_ids if 'invalid_ids' in locals() else [],
            "bulk_change_id": bulk_change_id
        }
 
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "telegence_bc_update_device_status_restore_cancelled",
                "created_date": data.get("request_received_at") or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for: {bulk_change_id}",
                "module_name": "sm bulk change",
                "request_received_at": data.get("request_received_at") or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
 
        return response
    


def bulk_update_customer_rate_plan_bp(data):
    """
    This function get trigger only when the bulk change request is created with the type of Assign Customer, to update the customer rate plans.
    And when billing platform is enabled for the tenant.
    """
    logging.info(f"### Received request data for bulk_update_customer_rate_plan_bp: {data}")
    
    # Required inputs
    bulk_change_id = data.get("bulk_change_id", None)
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    session_id = data.get("session_id", "")
    customer_rate_plan_name = data.get("customer_rate_plan", None)
    service_provider_name = data.get("service_provider", None)
    msisdns_list = data.get("msisdns", [])
    if not msisdns_list:
        msisdns_list = data.get("iccids", [])
        logging.info(f"### Using {len(msisdns_list)} iccids from input iccids are {msisdns_list}")
    try:
        # DB setup
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        # Fetch required fields
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        json_data = load_json()
        telegenceids = get_provider_ids(json_data, tenant_name, ["Telegence"])

        
        tenant_id=common_utils_database.get_data('tenant',{"tenant_name":tenant_name},['id'])['id'].to_list()[0]
        service_provider_id_query = f"select id from serviceprovider where tenant_id = '{tenant_id}' and is_active = true and service_provider_name = '{service_provider_name}'"
        service_provider_id = database.execute_query(service_provider_id_query, True)
        if not service_provider_id.empty:
            service_provider_id = int(service_provider_id.iloc[0]['id'])
        else:
            logging.error(f"Service provider '{service_provider_name}' not found")
            return {"flag": False, "message": f"Service provider '{service_provider_name}' not found"}
        
        if int(service_provider_id) in telegenceids:
            table_name_1 = "MobilityDevice"
            table_name_2 = "MobilityDevice_Tenant"
            column_update = "MobilityDeviceId"
            primary_column = "msisdn"
        else:
            table_name_1 = "Device"
            table_name_2 = "Device_Tenant"
            column_update = "DeviceId"
            primary_column = "iccid"

        # customer_rate_plan_query = f"select id from customerrateplan where tenant_id = '{tenant_id}' and service_provider_id = '{service_provider_id}' and rate_plan_name = '{customer_rate_plan_name}'" 
        customer_rate_plan_query=f"SELECT id FROM customerrateplan WHERE tenant_id = '{tenant_id}'   AND rate_plan_name = '{customer_rate_plan_name}'  AND ( service_provider_id = '{service_provider_id}' OR (serviceproviderids IS NOT NULL and {service_provider_id} = ANY (string_to_array(serviceproviderids, ',')::int[])))"
        customer_rate_plan_id = database.execute_query(customer_rate_plan_query, True)
        if not customer_rate_plan_id.empty:
            customer_rate_plan_id = int(customer_rate_plan_id.iloc[0]['id'])
            logging.info(f"customer_rate_plan_id is {customer_rate_plan_id}")
        else:
            logging.error(f"Customer rate plan '{customer_rate_plan_name}' not found for service provider '{service_provider_name}'")
            return {"flag": False, "message": f"Customer rate plan '{customer_rate_plan_name}' not found for service provider '{service_provider_name}'"}
        
        # Update the data in 2.0 tables
        if len(msisdns_list) == 0:
            logging.error("No iccids provided for bulk update")
            return {"flag": False, "message": "No iccids provided for bulk update"}
        elif len(msisdns_list) == 1:
            msisdn = msisdns_list[0]
            logging.info(f"here 1 msisdn is {msisdn}")
            database.update_dict(
                "sim_management_inventory",
                {"customer_rate_plan_name": customer_rate_plan_name,"customer_rate_plan_id":customer_rate_plan_id},
                {"tenant_id": tenant_id,"is_active":'true','service_provider_id':service_provider_id,'iccid':msisdn}
            )
        else:
            msisdn_tuple = tuple(msisdns_list)
            logging.info(f"here 2 msisdn is {msisdn_tuple}")
            database.update_dict(
                "sim_management_inventory",
                {"customer_rate_plan_name": customer_rate_plan_name,"customer_rate_plan_id":customer_rate_plan_id},
                and_conditions={"tenant_id": tenant_id,"is_active":'true','service_provider_id':service_provider_id},
                in_conditions={'iccid': msisdn_tuple}
            )

        # Trigger to Sync the data for 1.0 Tables
        try:
            
            vone_server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
            vone_database_name = os.environ["ONEPOINTODATABASE"]
            vone_username = os.environ["ONEPOINTOUSERNAME"]
            vone_password = os.environ["ONEPOINTOPASSWORD"]
            with pytds.connect(
                server=vone_server, database=vone_database_name, user=vone_username, password=vone_password
            ) as conn:
                with conn.cursor() as cursor:
                    # fetch the device ids of msisdns
                    if len(msisdns_list) == 1:
                        msisdn = msisdns_list[0]
                        query = f"select md.id from {table_name_1} md left join {table_name_2} mdt on md.id=mdt.{column_update} where md.iccid ='{msisdn}' and mdt.TenantId ={tenant_id} and md.ServiceProviderId={service_provider_id} and md.IsActive=1"
                        cursor.execute(query)
                        # Fetch all rows and convert to list
                        id_list = [row[0] for row in cursor.fetchall()]
                        # Define the UPDATE statement
                        update_query = f"""
                            UPDATE {table_name_2}
                            SET customerrateplanid = {customer_rate_plan_id}
                            WHERE {column_update} = {id_list[0]}
                        """
                        # Execute the query with parameters
                        try:
                            cursor.execute(update_query)
                            conn.commit()
                        except Exception as e:
                            logging.info(f"### Error occured while updating data to 1.0 bulk_update_assign_customer_bp: {e}")
                            conn.rollback()
                    else:
                        msisdn_tuple = tuple(msisdns_list)
                        query = f"select md.id from {table_name_1} md left join {table_name_2} mdt on md.id=mdt.{column_update} where md.iccid in {msisdn_tuple} and mdt.TenantId ={tenant_id} and md.ServiceProviderId={service_provider_id} and md.IsActive=1"
                        cursor.execute(query)
                        # Fetch all rows and convert to list
                        id_list = [row[0] for row in cursor.fetchall()]
                        if len(id_list)>1:
                            id_tuple = tuple(id_list)
                            # Define the UPDATE statement
                            update_query = f"""
                                UPDATE {table_name_2}
                                SET customerrateplanid = {customer_rate_plan_id}
                                WHERE {column_update} in {id_tuple}
                            """
                            # Execute the query with parameters
                            try:
                                cursor.execute(update_query)
                                conn.commit()
                            except Exception as e:
                                logging.info(f"### Error occured while updating data to 1.0 bulk_update_assign_customer_bp: {e}")
                                conn.rollback()
        except Exception as e:
            logging.exception(f"### Error occured while updating data to 1.0 bulk_update_customer_rate_plan_bp: {e}")
        finally:
            conn.close()

        # Update the auditing
        try:
            audit_data = {'customer_rate_plan_name': customer_rate_plan_name, 'bulk_change_id': bulk_change_id,
                          'customer_rate_plan_id': customer_rate_plan_id,'msisdns': msisdns_list}
            audit_data_user_actions = {
                "service_name": "bulk_update_customer_rate_plan_bp",
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "sm bulk change",
                "comments": json.dumps(audit_data),
                "session_id": session_id,
                "request_received_at": data.get("request_received_at", None) or datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging failed: {e}")
        return {
            "flag": True,
            "message": f"Bulk update customer rate plan completed successfully for {len(msisdns_list)} ICCIDs."}
    except Exception as e:
        logging.exception(f"### Error during bulk update customer rate plan: {e}")
        error_message = f"Error during bulk update customer rate plan"
        error_type = str(type(e).__name__)
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "bulk_update_customer_rate_plan_bp",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for: {bulk_change_id}",
                "module_name": "sm bulk change",
                "request_received_at": data.get("request_received_at", None) or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
        return {"flag": False, "message": error_message}



def bulk_update_assign_customer_bp(data):
    """
    This function get trigger only when the bulk change request is created with the type of Change Customer Rate Plan, to update the Customer details.
    And when billing platform is enabled for the tenant.
    """
    logging.info(f"### Received request data for bulk_update_assign_customer_bp: {data}")
    
    # Required inputs
    bulk_change_id = data.get("bulk_change_id", None)
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    session_id = data.get("session_id", "")
    customer_name = data.get("customer_name", None)
    service_provider_name = data.get("service_provider", None)
    iccids_list = data.get("iccids", [])

    try:
        # DB setup
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        # Fetch required fields
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        json_data = load_json()
        telegenceids = get_provider_ids(json_data, tenant_name, ["Telegence"])

        
        tenant_id=common_utils_database.get_data('tenant',{"tenant_name":tenant_name},['id'])['id'].to_list()[0]
        service_provider_id_query = f"select id from serviceprovider where tenant_id = '{tenant_id}' and is_active = true and service_provider_name = '{service_provider_name}'"
        service_provider_id = database.execute_query(service_provider_id_query, True)
        if not service_provider_id.empty:
            service_provider_id = int(service_provider_id.iloc[0]['id'])
        else:
            logging.error(f"Service provider '{service_provider_name}' not found")
            return {"flag": False, "message": f"Service provider '{service_provider_name}' not found"}
        
        if int(service_provider_id) in telegenceids:
            table_name_1 = "MobilityDevice"
            table_name_2 = "MobilityDevice_Tenant"
            column_update = "MobilityDeviceId"
            primary_column = "msisdn"
        else:
            table_name_1 = "Device"
            table_name_2 = "Device_Tenant"
            column_update = "DeviceId"
            primary_column = "iccid"
        
        customer_name_query = f"select id from customers where tenant_id = '{tenant_id}' and customer_name = '{customer_name}'" 
        customer_id = database.execute_query(customer_name_query, True)
        if not customer_id.empty:
            customer_id = int(customer_id.iloc[0]['id'])
        else:
            logging.error(f"Customer Name '{customer_name}' not found for service provider '{service_provider_name}'")
            return {"flag": False, "message": f"Customer Name '{customer_name}' not found for service provider '{service_provider_name}'"}
        
        # Update the data in 2.0 tables
        if len(iccids_list) == 0:
            logging.error("No iccids provided for bulk update")
            return {"flag": False, "message": "No iccids provided for bulk update"}
        elif len(iccids_list) == 1:
            iccid = iccids_list[0]
            database.update_dict(
                "sim_management_inventory",
                {"customer_name": customer_name,"customer_id":customer_id},
                {"tenant_id": tenant_id,"is_active":'true','service_provider_id':service_provider_id,primary_column:iccid}
            )
        else:
            iccid_tuple = tuple(iccids_list)
            database.update_dict(
                "sim_management_inventory",
                {"customer_name": customer_name,"customer_id":customer_id},
                and_conditions={"tenant_id": tenant_id,"is_active":'true','service_provider_id':service_provider_id},
                in_conditions={primary_column: iccid_tuple}
            )

        # Trigger to Sync the data for 1.0 Tables
        try:
            
            vone_server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
            vone_database_name = os.environ["ONEPOINTODATABASE"]
            vone_username = os.environ["ONEPOINTOUSERNAME"]
            vone_password = os.environ["ONEPOINTOPASSWORD"]
            with pytds.connect(
                server=vone_server, database=vone_database_name, user=vone_username, password=vone_password
            ) as conn:
                with conn.cursor() as cursor:
                    # fetch the device ids of msisdns
                    if len(iccid_tuple) == 1:
                        msisdn = iccid_tuple[0]
                        query = f"select md.id from {table_name_1} md left join {table_name_2} mdt on md.id=mdt.{column_update} where md.{primary_column} ='{msisdn}' and mdt.TenantId ={tenant_id} and md.ServiceProviderId={service_provider_id} and md.IsActive=1"
                        cursor.execute(query)
                        # Fetch all rows and convert to list
                        id_list = [row[0] for row in cursor.fetchall()]
                        # Define the UPDATE statement
                        update_query = f"""
                            UPDATE {table_name_2}
                            SET siteid = {customer_id}
                            WHERE {column_update} = {id_list[0]}
                        """
                        # Execute the query with parameters
                        try:
                            cursor.execute(update_query)
                            conn.commit()
                        except Exception as e:
                            logging.info(f"### Error occured while updating data to 1.0 bulk_update_assign_customer_bp: {e}")
                            conn.rollback()
                    else:
                        msisdn_tuple = tuple(iccid_tuple)
                        query = f"select md.id from {table_name_1} md left join {table_name_2} mdt on md.id=mdt.{column_update} where md.{primary_column} in {msisdn_tuple} and mdt.TenantId ={tenant_id} and md.ServiceProviderId={service_provider_id} and md.IsActive=1"
                        cursor.execute(query)
                        # Fetch all rows and convert to list
                        id_list = [row[0] for row in cursor.fetchall()]
                        if len(id_list)>1:
                            id_tuple = tuple(id_list)
                            # Define the UPDATE statement
                            update_query = f"""
                                UPDATE {table_name_2}
                                SET siteid = {customer_id}
                                WHERE {column_update} in {id_tuple}
                            """
                            # Execute the query with parameters
                            try:
                                cursor.execute(update_query)
                                conn.commit()
                            except Exception as e:
                                logging.info(f"### Error occured while updating data to 1.0 bulk_update_assign_customer_bp: {e}")
                                conn.rollback()

        except Exception as e:
            logging.exception(f"### Error occured while updating data to 1.0 bulk_update_assign_customer_bp: {e}")
        finally:
            conn.close()

        # Update the auditing
        try:
            audit_data = {'customer_id': customer_id, 'bulk_change_id': bulk_change_id,
                          'customer_name': customer_name,'iccids': iccids_list}
            audit_data_user_actions = {
                "service_name": "bulk_update_assign_customer_bp",
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "sm bulk change",
                "comments": json.dumps(audit_data),
                "session_id": session_id,
                "request_received_at": data.get("request_received_at", None) or datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging failed: {e}")
        return {
            "flag": True,
            "message": f"Bulk update assign customer completed successfully for {len(iccids_list)} ICCIDs."}
    except Exception as e:
        logging.exception(f"### Error during bulk update assign customer: {e}")
        error_message = f"Error during bulk update assign customer"
        error_type = str(type(e).__name__)
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "bulk_update_assign_customer_bp",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for: {bulk_change_id}",
                "module_name": "sm bulk change",
                "request_received_at": data.get("request_received_at", None) or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
        return {"flag": False, "message": error_message}

def insert_device_history_records(tenant_name, username, iccids, service_provider, db_name,msisdns=[],effective_date=None):
    """
    Invokes Lambda function to update device history tables.
    
    Args:
        tenant_name (str): Name of the tenant
        username (str): Username performing the operation
        iccids (list): List of ICCID values to update
        service_provider (str): Service provider name
        db_name (str): Database name
    
    Returns:
        dict: False response if Lambda invocation fails, True otherwise
    """
    try:
        logging.info(f"### Invoking insert_device_history_records Lambda iccids : {iccids} , msisdns : {msisdns}, effective_date : {effective_date}")
        env = os.environ.get("ENV", "UAT").upper()
        lambda_name = "module_management_uat" if env == "UAT" else "module_management"
        lambda_payload = {
            "data": {
                "data": {
                    "tenant_name": tenant_name,
                    "username": username,
                    "path": "/update_device_history_tables",
                    "iccids": iccids,
                    "service_provider":service_provider,
                    "db_name": db_name,
                    "msisdns":msisdns,
                    "effective_date":effective_date
                }
            }
        }
        lambda_client = boto3.client('lambda')
        invoke_response = lambda_client.invoke(
            FunctionName = lambda_name,
            InvocationType = 'Event',
            Payload = json.dumps(lambda_payload),
        )
        logging.info(f"### insert_device_history_records Lambda invoked :{invoke_response}")
        return True
    except Exception as e:
        logging.exception(f"### Error during insert_device_history_records: {e}")
        return False