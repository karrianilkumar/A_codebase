"""
@Author1 : Phaneendra.Y
@Author2 : Burhan
Created Date: 21-06-24
"""

# Importing the necessary Libraries
import ast
import boto3
import requests
import os
import pandas as pd
from common_utils.email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import *
import datetime
from datetime import time
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import time
from io import BytesIO

# from common_utils.data_transfer_main import DataTransfer
import json
import base64
import re
import pytds
from pytz import timezone
from pandas import Timestamp
import numpy as np
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
from common_utils.kore import *

logging = Logging(name="kore_apis")


def send_core_request(cost_center_pk, subscription_id, account_id, access_token):
    try:
        url = f"https://api.korewireless.com/connectivity/v1/accounts/{account_id}/subscription-requests/cost-center"

        payload = json.dumps(
            [{"cost-center-pk": cost_center_pk, "subscription-id": subscription_id}]
        )
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "x-api-key": "FwEO4B4Fqq28VPsaetYh59xZ75wsUpow98XCbUFC",
            "Authorization": f"Bearer {access_token}",
        }

        response = requests.request("POST", url, headers=headers, data=payload)
        return {"flag": True, "response": response.text}
        # logging.info(response.text, "222222")
        # logging.info(response.status_code, "3333333")
    except Exception as e:
        logging.info(f"Exception is {e}")
        message = (
            "Something went wrong fetching sessionid and sessiontoken using  Zitadel"
        )
        response = {"flag": False, "message": message}
        return response


def send_provisioning_request(base_url, account_id, action, iccid, subscription_id, mail_to, access_token, api_key):
    try:
        url = f"{base_url}/v1/accounts/{account_id}/provisioning-requests/{action.lower()}"
        
        # Construct subscriptions list
        subscriptions = [{
            "subscription-id": subscription_id,
            "iccid": iccid
        }]
        
        # Construct correct payload
        payload = {
            action.lower(): {   
                "subscriptions": subscriptions,
                "mail-to": mail_to
            }
        }

        # Headers
        final_headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "x-api-key": api_key
        }

        # Send the request
        logging.info(f"### sm_bulk_change send_provisioning_request data payload: {payload}, headers: {final_headers}, url: {url}")
        response = requests.post(url, headers=final_headers, json=payload)
        logging.info("### sm_bulk_change send_provisioning_request response",response.text)
        # Return the response text (or you could return the JSON response)
        if response.status_code in (200, 201):
            response_data = {
                "flag": True,
                "response": response.text,
                "status_code": response.status_code,
                "response_json": response.json(),
            }
        else:
            response_data = {
                "flag": False,
                "response": response.text,
                "status_code": response.status_code,
                "response_json": response.json(),
            }
        return response_data
    except Exception as e:
        logging.info(f"Exception in send_provisioning_request {e}")
        message = f"Something went wrong fetching update status in korewireless {e}"
        response = {"flag": False, "message": message}
        return response
    
def activate_provisioning_request(
    base_url,
    account_id,
    subscription_id,
    iccid,
    imei,
    activation_profile_id,
    mail_to,
    access_token,
    api_key,
):
    """
    Activate provisioning request for a given account and subscription.
    :param base_url: The base URL of the API
    :param headers: The headers to include in the request (including Content-Type and Accept)
    :param account_id: The account ID for the provisioning request
    :param activation_state: The activation state (e.g., 'ACTIVATED', 'DEACTIVATED')
    :param subscription_id: The subscription ID to be activated
    :param iccid: The ICCID associated with the subscription
    :param imei: The IMEI associated with the subscription
    :param mail_to: The email address to send activation information to
    :param activation_profile_id: The activation profile ID
    :param sku: The SKU associated with the activation
    :return: JSON response or an error message
    """
    url = f"{base_url}/v1/accounts/{account_id}/provisioning-requests/activate"

    # Construct the payload
    payload = {
        "activate": {
            "activation-state": "active",
            "subscriptions": [
                {"subscription-id": subscription_id, "iccid": iccid, "imei": imei}
            ],
            # "mail-to": mail_to,
            "activation-profile-id": activation_profile_id,
        }
    }
    final_headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
        "x-api-key": api_key,
    }
    try:
        # Make the POST request
        logging.info(f"### sm_bulk_change activate_provisioning_request data payload: {payload}, headers: {final_headers}, url: {url}")
        response = requests.post(url, headers=final_headers, json=payload)
        logging.info("### sm_bulk_change activate_provisioning_request response",response.text)
        if response.status_code in (200,201):
            logging.info(f"Kore Device Status-Activation, Carrier request response {response.status_code} - {response.text}")
            # Return the JSON response
            response_data = {
                "flag": True,
                "response": response.text,
                "status_code": response.status_code,
                "response_json": response.json(),
            }
            return response_data
        else:
            logging.info(f"Kore Device Status-Activation, Carrier request response Error: {response.status_code} - {response.text}")
            response_data = {
                "flag": False,
                "response": response.text,
                "status_code": response.status_code,
                "response_json": response.json(),
            }
            return response_data
    except requests.exceptions.RequestException as e:
        logging.exception(
            f"Kore Device Status-Activation, Carrier request an error occurred: {e}"
        )
        response_data = {"flag": False, "response": e}
        return response_data


def base64_encode(plain_text):
    # Convert the plain text to bytes, then encode it in Base64
    plain_text_bytes = plain_text.encode("utf-8")
    base64_encoded = base64.b64encode(plain_text_bytes).decode("utf-8")
    return base64_encoded


def base64_decode(base64_encoded_data):
    # Decode the Base64 string to bytes
    base64_encoded_bytes = base64.b64decode(base64_encoded_data)
    # Convert the bytes back to a UTF-8 string
    decoded_string = base64_encoded_bytes.decode("utf-8")
    return decoded_string


def send_revio_request(service_id, username, password, token, main_url, cost_center):
    """
    Sends a GET request to the Revio API for a specific service ID.
    """
    # Prepare authentication and headers
    auth_token = base64_encode(f"{username}:{base64_decode(password)}")
    subscription_key = base64_decode(token)
    logging.info(auth_token, subscription_key)

    url = f"{main_url}/{service_id}"
    headers = {
        "Authorization": f"Basic {auth_token}",
        "Ocp-Apim-Subscription-Key": subscription_key,
        "Accept": "application/json",
    }

    # Send the request and handle the response
    try:
        response = requests.get(url, headers=headers)

        if response.status_code == 200:

            logging.info("Request successful:", response.json())

            if "CostCenter1" in response.json():
                # Define the request payload
                data = {"CostCenter1": cost_center}

                # Send the request and handle the response
                response = requests.put(url, headers=headers, json=data)

                if response.status_code in [200, 202]:  # Success responses
                    logging.info(
                        f"CostCenter1 for ICCID {service_id} updated successfully."
                    )
                    return {"flag": True}
                else:
                    logging.info(
                        f"Failed to update CostCenter1 for ICCID {service_id}: {response.status_code} - {response.text}"
                    )
                    return {
                        "flag": False,
                        "message": f" Failed to update CostCenter1 for ICCID {service_id}: {response.status_code} - {response.text} ",
                    }

        else:
            logging.info(
                f"Failed with status code {response.status_code}: {response.text}"
            )
            return {
                "flag": False,
                "message": f"Failed with status code {response.status_code}: {response.text}",
            }
    except Exception as e:
        logging.info(f"Error during request: {str(e)}")
        return {"flag": False, "message": f" Failed to send message due to: {str(e)}"}
