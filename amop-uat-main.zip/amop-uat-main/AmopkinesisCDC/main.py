
import json
import boto3
from opensearchpy import OpenSearch, RequestsHttpConnection
from opensearchpy import helpers
import logging
import csv
from io import StringIO
import psycopg2
from datetime import datetime, timezone
import uuid
import time
from decimal import Decimal
import re


# Initialize clients
s3_client = boto3.client('s3')

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# OpenSearch client configuration
def opensearch_client():
    host = 'https://search-amopsearchuat-dzxpse4exyj37kauestkbgeady.us-east-1.es.amazonaws.com'
    auth = ('admin', 'Amopteam@123')  # Use your OpenSearch credentials

    logging.debug(f"Creating OpenSearch client with host: {host}")
    
    return OpenSearch(
        [host],
        http_auth=auth,
        use_ssl=True,
        verify_certs=True,
        timeout=60
    )

def parse_any_date(value):
    """Try to convert various date string formats to YYYY-MM-DD. Return unmodified if not a recognized date."""
    if value in (None, 'null', 'NULL', ''):
        return None

    date_formats = [
        '%Y-%m-%d',              # 2025-07-24
        '%m-%d-%Y',              # 07-24-2025
        '%m-%d-%y',              # 07-23-25
        '%Y-%m-%dT%H:%M:%S',     # 2025-07-24T13:00:00
        '%Y-%m-%dT%H:%M:%S.%f',  # 2025-07-24T13:00:00.123456
        '%Y-%m-%d %H:%M:%S',     # 2025-07-24 13:00:00
        '%d-%m-%Y',              # 24-07-2025
        '%d/%m/%Y',              # 24/07/2025
        '%m/%d/%Y',              # 07/24/2025
    ]

    if isinstance(value, str):
        for fmt in date_formats:
            try:
                dt = datetime.strptime(value, fmt)
                return dt.strftime('%Y-%m-%d')
            except Exception:
                continue
        # Try parsing ISO (fromisoformat)
        try:
            dt = datetime.fromisoformat(value)
            return dt.strftime('%Y-%m-%d')
        except Exception:
            pass
    return value

def normalize_dates(obj):
    """Recursively normalize date strings in nested dicts/lists to YYYY-MM-DD."""
    if isinstance(obj, dict):
        return {k: normalize_dates(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [normalize_dates(i) for i in obj]
    elif isinstance(obj, str):
        if is_date_string(obj):
            return parse_any_date(obj)
        else:
            return obj
    else:
        return obj

def is_date_string(value):
    if not isinstance(value, str):
        return False
    # Regex for YYYY-MM-DD, YYYY-MM-DDTHH:MM:SS, etc.
    date_patterns = [
        r'^\d{4}-\d{2}-\d{2}$',
        r'^\d{2}-\d{2}-\d{4}$',
        r'^\d{2}/\d{2}/\d{4}$',
        r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?$',
        r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$',
    ]
    for pattern in date_patterns:
        if re.match(pattern, value):
            return True
    return False

# PostgreSQL connection
def get_db_connection(db_name):
    return psycopg2.connect(
        dbname=db_name,
        user="root",
        password="AmopTeam123",
        host="amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
        port="5432"
    )

def parse_datetime(value):
    if value in (None, 'null', 'NULL', ''):
        return None
    if isinstance(value,str):
        try:
            return datetime.fromisoformat(value).isoformat()
        except ValueError:
            try:
                return datetime.strptime(value, '%Y-%m-%d %H:%M:%S.%f').isoformat()
            except ValueError:
                print(f"Warning: Unable to parse date time string: {value}\n")
                return value
    elif isinstance(value, datetime):
        return value.isoformat()
    return value

    
# def convert_value(value, data_type):
#     if value in (None, 'null', 'NULL', ''):
#         return None
#     if data_type == 'boolean':
#         return str(value).lower() in ('true', '1')
#     elif data_type == 'timestamp without time zone':
#         return parse_datetime(value)
#     elif data_type == ('character varying', 'text'):
#         return str(value)
#     elif data_type == 'integer':
#         return int(value)
#     elif data_type == 'real':
#         return float(value)
#     elif data_type == 'uuid':
#         try:
#             return str(uuid.UUID(value))
#         except ValueError:
#             print(f"Warning: Invalid UUID format: {value}\n")
#             return value
#     elif data_type == 'json':
#         if isinstance(value, list):
#             return value  # Directly return if the value is already a list
#         try:
#             return json.loads(value)
#         except json.JSONDecodeError:
#             print(f"Warning: Invalid JSON format: {value}\n")
#             return value
#     # elif data_type == 'json':
#     #     # print(f"Instance type: {type(value).__name__} -> {value}")
#     #     if isinstance(value, list):
#     #         return json.loads(value)
#     #     else:  # Directly return if the value is already a list
#     #         try:
#     #             return json.loads(value) if isinstance(value, str) else value
#     #         except json.JSONDecodeError:
#     #             print(f"Warning: Invalid JSON format: {value}\n")
#     #             return value
#     return value
def clean_numeric_in_json(obj):
    if isinstance(obj, dict):
        return {k: clean_numeric_in_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [clean_numeric_in_json(i) for i in obj]
    elif isinstance(obj, str):
        cleaned = obj.strip().replace('(', '').replace(')', '')
        try:
            # Try converting to a number
            return float(Decimal(cleaned))
        except Exception:
            return obj
    else:
        return obj

def convert_value(value, data_type,column_name):
    if value in (None, 'null', 'NULL', ''):
        return None
    try:
        if isinstance(value, Decimal) and (value.is_nan()):
            return None  # Replace NaN with None (null in JSON)
        elif isinstance(value, str) and value.strip().lower() == 'nan':
            return None  # Convert 'NaN' string to None
        elif data_type == 'boolean':
            return str(value).lower() in ('true', '1')
        elif data_type == 'timestamp without time zone':
            return parse_datetime(value)
        elif data_type == ('character varying', 'text'):
            return str(value)
        elif data_type == 'integer':
            return int(value)
        elif data_type == 'real':
            return float(value)
        elif data_type == 'uuid':
            try:
                return str(uuid.UUID(value))
            except ValueError:
                print(f"Warning: Invalid UUID format: {value}\n")
                return value
        elif data_type == 'jsonb':
            try:
                if isinstance(value,str):
                    parsed_json = json.loads(value)
                else:
                    parsed_json = value

                cleaned_json = clean_numeric_in_json(parsed_json)
                return cleaned_json
            except json.JSONDecodeError:
                print(f"Warning: Invalid JSON format: {value}\n")
                return value
        elif column_name in ['bill_details','deposit_data']:
            return json.loads(value)
        else:
            return value
    except Exception as e:
        print(f"Error converting value '{value}' to type '{data_type}': {e}")
        return None




# Function to get table schema
def get_table_schema(conn, table_name):
    query = """
        SELECT column_name,data_type
        FROM information_schema.columns
        WHERE table_name = %s
        ORDER BY ordinal_position
    """
    with conn.cursor() as cur:
        cur.execute(query, (table_name,))
        columns = cur.fetchall()
    
    return {column[0]: column[1] for column in columns}

# Lambda handler
def lambda_handler(event, context):

    start_time = time.time()  # Initialize start_time

    print(f"Received event: {json.dumps(event)}")
    es = opensearch_client()
     # Create a database connection
    
    # Process each record in the event
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        print(f"Derived index name from key: {bucket}")
        # Log the received event details
        logging.debug(f"Processing file: {key} from bucket: {bucket}")
        print(f"Processing file: {key} from bucket: {bucket}")
        if bucket == "altaworxtestdms":
            db_name = "altaworx_test"
        elif bucket == "commonutilsuat":
            db_name = "common_utils"
        elif bucket == "billing-platform-uat":
            db_name = "billing_platform"
        elif bucket == "apitesttenant-uat":
            db_name = "APITestTenant"
        else:
            db_name = "altaworx_central"
        conn = get_db_connection(db_name) 

        try:
            # Get the object from S3
            response = s3_client.get_object(Bucket=bucket, Key=key)
            data = response['Body'].read().decode('utf-8')  # Read the CSV file content
            print(f"Successfully fetched object {key} from bucket {bucket}.")
            
        except Exception as e:
            logging.error(f"Error fetching object {key} from bucket {bucket}: {str(e)}")
            continue
    

        try:
            csv_reader = csv.reader(StringIO(data))  # Read the CSV as a list
            csv_data = list(csv.reader(StringIO(data)))
            csv_data_list = list(csv_reader) 
            # print("*************",csv_data_list)
            key_parts = key.split('/')  # Split the key, e.g., 'DMS/public/amop_apis/20241011-095606472.csv'
    
            # Extract the part that represents the index name (3rd part in this example)
            if key.startswith("public/"):
                index_name = key_parts[1]  # Take the second part if the key starts with "public/"
            else:
                index_name = key_parts[2] if len(key_parts) > 2 else '' # Fetch 'amop_apis'
            table_name=index_name

            if db_name == "altaworx_central":
                index_name = f"{index_name}"
            elif db_name == "common_utils":
                index_name = f"{index_name}"
            else:
                index_name = f"{index_name}_{db_name}".lower()
            
            print(f"Derived index name from key: {index_name}")



            schema = get_table_schema(conn, table_name)

            # print("*******************",schema)
            total_rows = len(csv_data)
            # actions = []
            actions = []
            batch_size = 0  # Set batch size for bulk indexing
            # print("-------",csv_reader)
            for row_count, row in enumerate(csv_data, start=1):
                if not row:
                    continue

                operation = row[0]  # First column indicates the operation (Insert/Update/Delete)
                date = datetime.now(timezone.utc).isoformat()
                json_data = {col: convert_value(value, schema[col],col) for col, value in zip(schema.keys(), row[1:])}
                # json_data["_doc_modified_date"] = date
                json_data = normalize_dates(json_data) 
                doc_id = row[1]  # Assuming the second column is the ID

                action = {"_index": index_name, "_id": doc_id}
                

                if operation == 'I':
                    action.update({"_op_type": "index", "_source": json_data})
                    actions.append(action)
                elif operation == 'U':
                    action.update({"_op_type": "update", "doc": json_data, "doc_as_upsert": True})
                    actions.append(action)
                elif operation == 'D':
                    action.update({"_op_type": "delete"})
                    actions.append(action)
                else:
                    logging.warning(f"Unknown operation '{operation}' for row: {row}")

            # all_actions = actions['I'] + actions['U'] + actions['D']
            # print("@@@@@@@@@@@@",actions) 
            try:
                # Perform bulk indexing for all actions at once
                if actions:
                    response = helpers.bulk(es, actions)
                    print(f"Successfully indexed {response[0]} documents to {index_name}")
                    print(f"index name: {index_name}")
                else:
                    logging.warning(f"No actions to index for {index_name}")
            except Exception as e:
                logging.error(f"Error indexing documents to {index_name}: {e}")

                # if len(actions['I']) >= batch_size or len(actions['U']) >= batch_size or len(actions['D']) >= batch_size:
                #     for op_type, action_list in actions.items():
                #         print("55555555")
                #         if action_list:
                #             try:
                #                 response = helpers.bulk(es, action_list)
                #                 logging.info(f"Successfully indexed {response[0]} {op_type} operations into {index_name}")
                #                 action_list.clear()
                #             except Exception as e:
                #                 logging.error(f"Error indexing {op_type} actions: {e}")

        except Exception as e:
            print(f"Error processing CSV data from S3 object {key}: {str(e)}")
        finally:
            # Clean up database connection
            conn.close()
            end_time = time.time()  # Ensure end_time is set
            execution_time = end_time - start_time
            print(f"Total execution time: {execution_time:.2f} seconds")


    return {
        'statusCode': 200,
        'body': json.dumps('Successfully processed S3 event')
    }
