"""
@Author1 : Srikanth R
Created Date: 27-12-2024
"""

# Importing the necessary Libraries
import ast
import boto3
import requests
import os
import pandas as pd
from common_utils.email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import datetime
from datetime import time
from datetime import datetime, timedelta
import time
from io import BytesIO
from common_utils.data_transfer_main import DataTransfer
import json
import base64
import re
import pytds
from pytz import timezone
import numpy as np
from collections import defaultdict
#download template dependencies
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
#authorize.net dependencies
import xml.etree.ElementTree as ET
# from authorizenet import apicontractsv1
# from authorizenet.apicontrollers import createCustomerProfileController
# from flask import request


# import apicontractsv1
# import createCustomerProfileController
from io import StringIO
# from lxml import etree
import xml.etree.ElementTree as ET
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
import csv
from openpyxl import load_workbook
from openpyxl import Workbook
from pytz import UnknownTimeZoneError, timezone
import pandas as pd



# Dictionary to store database configuration settings retrieved from environment variables.
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema":False
}
logging = Logging(name="sim_management")
authentication_name='2J3vSx5dBSG'
transactionKey='8kL8NkuGT8736R9P'

def get_token(data):
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    amount_from_invoice = data.get('item_amount','')
    account_id=data.get('account_number','')
    # email=data.get('email','srikanth.rekkala@algonox.com')
    invoice_id=data.get('bill_id','')
    modified_by=data.get('username','')
    modified_date=data.get('request_received_at','')
    logging.info('####data',data)
    if not account_id:
            response = {
                "flag": False,
                "message": "Account Number is empty"
            }
            return response
    if not invoice_id:
        response = {
            "flag": False,
            "message": "Invoice Id is empty"
        }
        return response
    email_query_df=killbill_database.get_data("customer_profiles",{"account_number":account_id},["email"])
    if email_query_df is not None and not email_query_df.empty:
            logging.info(f'###Email exist')
            email = str(email_query_df['email'].tolist()[0])
    if not email:
        response = {
            "flag": False,
            "message": "Email is empty"
        }
        return response
    payment_profile_id=''
    if account_id:
        # query to get id form product types table based on description
        query_df=killbill_database.get_data("customer_payment_profiles",{"account_number":account_id},["payment_profile_id"])
        # If a result is found, fetch the provider_id
        if query_df is not None and not query_df.empty:
            logging.info('###Already Payment Profile existed')
            payment_profile_id = str(query_df['payment_profile_id'].tolist()[0])
        else:
            logging.info('###Creating new Payment Profile')
            payment_profile_id = get_or_create_customer_profile(account_id, email, authentication_name, transactionKey)
        # if not query_df.empty:
        #     logging.info('###Already Payment Profile existed')
        #     payment_profile_id = str(query_df['id'].tolist()[0])
        # else:
        #     logging.info('###creating new Payment Profile')
        #     payment_profile_id=get_or_create_customer_profile(account_id,email,authentication_name,transactionKey)
            profile_data={}
            profile_data['account_number']=account_id
            profile_data['email']=email
            profile_data['payment_profile_id']=payment_profile_id
            profile_data['modified_by']=modified_by
            profile_data['modified_date']=modified_date
            profile_data['created_date']=modified_date
            status=killbill_database.insert_dict(profile_data, 'customer_payment_profiles')
            if not status:
                response = {
                        "flag": False,
                        "message": "Failed to create Payment Profile"
                    }
    # url=get_host_url()
    try:
        root = ET.Element('getHostedPaymentPageRequest', xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd")
        # Merchant Authentication
        merchant_authentication = ET.SubElement(root, 'merchantAuthentication')
        ET.SubElement(merchant_authentication, 'name').text = authentication_name
        ET.SubElement(merchant_authentication, 'transactionKey').text = transactionKey
        # Transaction Request
        transaction_request = ET.SubElement(root, 'transactionRequest')
        ET.SubElement(transaction_request, 'transactionType').text = 'authCaptureTransaction'
        ET.SubElement(transaction_request, 'amount').text = amount_from_invoice
        profile = ET.SubElement(transaction_request, 'profile')
        ET.SubElement(profile, 'customerProfileId').text = payment_profile_id
        # Add order information with invoice ID
        order = ET.SubElement(transaction_request, 'order')
        ET.SubElement(order, 'invoiceNumber').text = str(invoice_id)  # Sending invoice number
        customer = ET.SubElement(transaction_request, 'customer')
        # ET.SubElement(customer, 'email').text = 'ellen@mail.com'
        ET.SubElement(customer, 'email').text = email
        bill_to = ET.SubElement(transaction_request, 'billTo')
        ET.SubElement(bill_to, 'firstName').text = ''
        ET.SubElement(bill_to, 'lastName').text = ''
        ET.SubElement(bill_to, 'company').text = ''
        ET.SubElement(bill_to, 'address').text = ''
        ET.SubElement(bill_to, 'city').text = ''
        ET.SubElement(bill_to, 'state').text = ''
        ET.SubElement(bill_to, 'zip').text = ''
        ET.SubElement(bill_to, 'country').text = ''

        # Hosted Payment Settings
        hosted_payment_settings = ET.SubElement(root, 'hostedPaymentSettings')

        # Hosted Payment Return Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentReturnOptions'
        # ET.SubElement(setting, 'settingValue').text = '{"showReceipt": true, "url": "https://mysite.com/receipt", "urlText": "Continue", "cancelUrl": "https://mysite.com/cancel", "cancelUrlText": "Cancel"}'
    #     ET.SubElement(setting, 'settingValue').text = (
    # '{"showReceipt": true, '
    # f'"url": "https://localhost:3000/billing_platform/customer_profiles/payment_history", '
    # '"urlText": "Continue", '
    # f'"cancelUrl": "https://localhost:3000/billing_platform/customer_profiles", '
    # '"cancelUrlText": "Cancel"}')
        ET.SubElement(setting, 'settingValue').text = (
        '{"showReceipt": true, '
        f'"url": "https://qa.amop.services/billing_platform/customer_profiles/payment_history", '
        '"urlText": "Continue", '
        f'"cancelUrl": "https://qa.amop.services/billing_platform/customer_profiles/bills", '
        '"cancelUrlText": "Cancel"}')
        # Hosted Payment Button Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentButtonOptions'
        ET.SubElement(setting, 'settingValue').text = '{"text": "Pay"}'

        # Hosted Payment Style Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentStyleOptions'
        ET.SubElement(setting, 'settingValue').text = '{"bgColor": "blue"}'

        # Hosted Payment Payment Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentPaymentOptions'
        ET.SubElement(setting, 'settingValue').text = '{"cardCodeRequired": false, "showCreditCard": true, "showBankAccount": true}'

        # Hosted Payment Security Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentSecurityOptions'
        ET.SubElement(setting, 'settingValue').text = '{"captcha": false}'

        # Hosted Payment Shipping Address Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentShippingAddressOptions'
        ET.SubElement(setting, 'settingValue').text = '{"show": false, "required": false}'

        # Hosted Payment Billing Address Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentBillingAddressOptions'
        ET.SubElement(setting, 'settingValue').text = '{"show": true, "required": false}'

        # Hosted Payment Customer Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentCustomerOptions'
        ET.SubElement(setting, 'settingValue').text = '{"showEmail": false, "requiredEmail": false, "addPaymentProfile": true}'

        # Hosted Payment Order Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentOrderOptions'
        ET.SubElement(setting, 'settingValue').text = '{"show": true, "merchantName": "Altaworx"}'

        # Hosted Payment IFrame Communicator Url
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentIFrameCommunicatorUrl'
        ET.SubElement(setting, 'settingValue').text = '{"url": "https://qa-billing.amop.services/kb/iframecommunicator.html"}'

        # Convert the tree to a string
        tree = ET.ElementTree(root)
        output = StringIO()
        tree.write(output, encoding="unicode", xml_declaration=True)
        # xml_string = output.getvalue().decode('utf-8')
        logging.info(f'###output.getvalue()--------{output.getvalue()}')
        # return output.getvalue()
        url = 'https://apitest.authorize.net/xml/v1/request.api'  # Replace with actual URL of the API
        headers = {'Content-Type': 'application/xml'}
        
        xml_data = output.getvalue() # Assuming the get_token function creates the XML as described earlier

        # Send the request to the payment gateway
        response = requests.post(url, headers=headers, data=xml_data)
        logging.info(f'####response----------{response}')
        logging.info('###response.text-----------{response.text}')
    
        if response.status_code == 200:
            try:
                root = ET.fromstring(response.text)
                namespaces = {
    'ns': 'AnetApi/xml/v1/schema/AnetApiSchema.xsd'  # Replace with the actual namespace
}
                token_element = root.find('.//ns:token', namespaces)
                if token_element is not None:
                    token = token_element.text
                    logging.info(f"Token: {token}")
                    message='Token generated successfully'
                    response = {
                                "flag": True,
                                "message": "Token generated successfully",
                                "token":token
                                }
                    logging.info(response)
                    return response
                else:
                    logging.info("Token element not found in the response")
                    return 'token not found'
                for elem in root.iter():
                    logging.info(f"Element: {elem.tag}, Text: {elem.text}")
            except Exception as e:
                return f"Error parsing response: {str(e)}"
        else:
            return f"Error: Received {response.status_code} from API"
        
    except Exception as e:
        # Handle any exceptions and return an error message
        return f"An error occurred: {str(e)}"


def get_headers_mapping(tenant_database, module_list, role, user, tenant_id, sub_parent_module, parent_module, data,):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.

    This function:
    - Connects to the database.
    - Fetches field mappings and categorizes them into pop-ups, general fields, and table fields.
    - Retrieves and processes module features based on user roles.
    - Returns a structured dictionary containing headers and features for each module.

    Parameters:
        tenant_database (str): The database name of the tenant.
        module_list (list): List of module names to fetch field mappings for.
        role (str): The role of the user (e.g., 'Super Admin').
        user (str): The username of the user.
        tenant_id (int): The ID of the tenant.
        sub_parent_module (str): The name of the sub-parent module.
        parent_module (str): The name of the parent module.
        data (dict): Additional input data, which may contain:
            - feature_module_name (str): The feature module name.
            - username/user_name/user (str): The username.
            - tenant_name/tenant (str): The tenant name.

    Returns:
        dict: A dictionary where each module name maps to its corresponding headers and features.
    """
    # Establish database connections
    database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    billing_platform_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    
    # Extract relevant details from the input data dictionary
    main_module_name=data.get("main_module_name", "Customer Profiles")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")
    parent_module_name = data.get("parent_module", "Billing Platform")
    try:
        logging.info("tenant_name is",tenant_name)
        # Retrieve tenant ID based on tenant name
        tenant_id = database.get_data(
            "tenant", {"tenant_name": tenant_name},["id"]
        )["id"].to_list()[0]
    except Exception as e:
        logging.warning(f"Getting exception at fetching tenant id {e}")
    
    ret_out = {}
    
    # Iterate over each module name in the provided module list
    for module_name in module_list:
        out = billing_platform_database.get_data(
            "field_column_mapping", {"module_name": module_name}
        ).to_dict(orient="records")
        pop_up = []
        general_fields = []
        table_fileds = {}
        # Categorize the fetched data based on field types
        for data in out:
            if data["pop_col"]:
                pop_up.append(data)
            elif data["table_col"]:
                table_fileds.update(
                    {
                        data["db_column_name"]: [
                            data["display_name"],
                            data["table_header_order"],
                        ]
                    }
                )
            else:
                general_fields.append(data)
        # Create a dictionary to store categorized fields
        headers = {}
        headers["general_fields"] = general_fields
        pop_up = sorted(pop_up, key=lambda x: x['id'])
        headers["pop_up"] = pop_up
        headers["header_map"] = table_fileds
        try:
            final_features = []

            # Fetch all features for the 'super admin' role
            if role.lower() == "super admin":
                all_features = database.get_data(
                    "module_features", {"module": main_module_name}, ["features"]
                )["features"].to_list()
                if all_features:
                    final_features = json.loads(all_features[0])
            else:
                final_features = get_features_by_feature_name(
                    user_name, tenant_id, main_module_name, database, parent_module_name, role
                )

        except Exception as e:
            logging.exception(f"there is some error {e}")
            pass
        # Add the final features to the headers dictionary
        headers["module_features"] = final_features
        if module_name in ["Customer Services Carrier","Customer Services Customer"]:
            module_name = "Customer Services"
        ret_out[module_name] = headers

    return ret_out



def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name, role
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        logging.debug("Raw user features fetched: %s", user_features_raw)

        if not user_features_raw or user_features_raw[0] is None:
            query=f'''select module_features from role_module where role='{role}'
            '''
            user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
        
        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  
        
        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        print(
            "Retrieved features: %s", features_list
        )  

    except Exception as e:
        # Catch any exceptions and log a warning
        logging.warning("There was an error while fetching features: %s", e)

    return features_list  # Return the list of retrieved features

def data_update_db(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        logging.info(f'INchanged_data---------{changed_data}---{unique_id}------{table_name}')

        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            logging.info("***update_data",update_data)
            # Perform the update operation
            db.update_dict(table_name, update_data, {"id": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def convert_timestamp(df_dict, tenant_time_zone):
    """Convert timestamp columns in the provided dictionary list to the tenant's timezone."""
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y %H:%M:%S')  # Ensure it's a string
    return df_dict

def data_update_db_account_number(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            logging.info("***update_data",update_data)
            # Perform the update operation
            db.update_dict(table_name, update_data, {"account_number": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def serialize_data(data):
    """Recursively convert pandas objects in the data structure to serializable types."""
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        return data.strftime('%m-%d-%Y %H:%M:%S')  # Convert to string
    else:
        return data  # Return as is if not a pandas object

def update_billing_actions_data(data):
    """
    Updates module data for a specified module by checking user and tenant to get the features,
    constructing and executing a SQL query to fetch data from the appropriate view, handles errors,
    and logs relevant information.

    Parameters:
        data (dict): A dictionary containing the data to be updated, including:
            - 'Partner' (str): The partner name.
            - 'request_received_at' (str): The timestamp when the request was received.
            - 'session_id' (str): The session ID associated with the request.
            - 'username' (str): The username of the person making the request.
            - 'module' (str): The module name (e.g., 'Feature Codes', 'Optimization Group').
            - 'changed_data' (dict): A dictionary containing the existing data that has been changed.
            - 'new_data' (dict): A dictionary containing the new data to be added or updated.
            - 'table_name' (str): The name of the database table to update.
            - 'action' (str): The action to perform, either 'create' or 'update'.
            - 'db_name' (str): The name of the tenant database.

    Returns:
        dict: A response dictionary indicating the success or failure of the operation, with:
            - 'flag' (bool): True if the operation was successful, False otherwise.
            - 'message' (str): A message indicating the outcome of the operation.
    """

    logging.info(f"Request Data Recieved")
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    module_name = data.get("module_name", "")
    logging.debug(module_name, "module_name")
    changed_data = data.get("changed_data", {})
    #changed_data_new = data.get("changed_data", {})
    logging.info(f'changed_data----------------{changed_data}')
    active_status = changed_data.get("is_active", '')
    logging.info(f'active_status-----------{active_status}')
    changed_data['modified_by']=username
    action = data.get("action", "")
    if module_name == 'Billing Services' and action == 'update':
        display_name_ = changed_data.get('display_name', '')
        logging.info(f'display_name_-------------{display_name_}')
    elif module_name == 'Packages' and action == 'update':
        display_name = changed_data.get('display_name', '')
        logging.info(f'display_name-------------{display_name}')
    else:
        logging.info('###changed_data',changed_data)
        pop_data=changed_data.pop('display_name',None)
        logging.info('###pop_data',pop_data)
        logging.info('###changed_data',changed_data)
        logging.info('####type of pop_up data',type(pop_data))
    new_data = data.get("changed_data", {})
    new_data = {k: v for k, v in new_data.items() if v != ""}
    # Start time  and date calculation
    start_time = time.time()
    unique_id = changed_data.get("id", None)
    logging.debug(unique_id, "unique_id")
    table_name = data.get("table_name", "")
    tenant_database = data.get("db_name", "")
    # database Connection
    db = DB(database=tenant_database, **db_config)
    dbs = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    # Start time  and date calculation
    start_time = time.time()

    try:

        if action.lower() == 'create' or action.lower()=='copy':
            if action.lower()=='copy':
                try:
                    current_timestamp = datetime.now()
                    formatted_timestamp = current_timestamp.strftime("%m-%d-%Y %H:%M:%S")
                    if data.get('changed_data') and 'created_date' in data['changed_data']:
                        data['changed_data']['created_date']=formatted_timestamp
                except Exception as e:
                    pass

            if module_name=='Billing Services':
                customFields=changed_data.get('customFields',{})
                builtInFields=changed_data.get('builtInFields',{})
                if 'customFields' in changed_data:
                    changed_data.pop('customFields')
                    changed_data['custom_field']=customFields
                if 'builtInFields' in changed_data:
                    changed_data.pop('builtInFields')
                for j in builtInFields:
                    changed_data[j]=builtInFields[j]
                return add_service_type(data)
            elif module_name=='Billing Products':
                return add_product(data)
            elif module_name=='Billing Product Types':
                return add_product_type(data)
            elif module_name=='Packages':
                return add_package(data)
            else:
                response = {
                "flag": False,
                "message": "Failed to add the data"
                }
                return response
        elif module_name=="Billing Customer Profiles" and (action=="update" or action=='delete' or action=='deactivate' or action=='activate'):
            if action == 'deactivate':
                changed_data['status']='Inactive'
            elif action == 'activate':
                changed_data['status']='Active'
            else:
                pass
            column_remove=['contract_date','account_type','btn']
            for field in column_remove:
                if changed_data.get(field,''):
                    changed_data.pop(field)
            if changed_data.get('email',''):
                changed_data['email_address']=changed_data['email']
                changed_data.pop('email')
            status=data_update_db(changed_data,unique_id,table_name,db)
        else:
            if action=='deactivate':
                changed_data['status']='Inactive'
            elif action == 'activate':
                changed_data['status']='Active'
            else:
                pass
            status=data_update_db(changed_data,unique_id,table_name,db)

        logging.info("Action Done successfully")
        message = f"{action.capitalize()}d Successfully"
        response_data = {"flag": True, "message": message}

        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "Billing Platform",
            "created_date": request_received_at,
            "created_by": username,
            "status": str(response_data["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": json.dumps(changed_data),
            "module_name": "Billing Services",
            "request_received_at": request_received_at,
        }
        dbs.update_audit(audit_data_user_actions, "audit_user_actions")
        return response_data
    except Exception as e:
        logging.info(f"An error occurred: {e}")
        message = f"Unable to save the data"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "update_superadmin_data",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": "",
                "module_name": "Billing Services",
                "request_received_at": request_received_at,
            }
            dbs.log_error_to_db(error_data, "error_log_table")
        except:
            pass
        return response


def billing_payments_bills_list_view(data):
    """
    Retrieves a list of billing and collections bills from the database, including pagination details and tenant-specific
    timezone handling. The function fetches the total count of records, applies pagination using the provided start and
    end indices, and formats the results for display. It also handles timezone conversion for timestamps and prepares
    the response with necessary data, including pagination and header information.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name, used for permissions and access control.
            - tenant_name (str): The tenant name, used for tenant-specific operations.
            - mod_pages (dict): Pagination details, including 'start' (starting index) and 'end' (ending index).

    Returns:
        dict: A dictionary containing the following:
            - flag (bool): Status of the operation (True for success, False for failure).
            - message (str): Success or failure message indicating the result of fetching the billing and collections bills.
            - data (dict): Data for the billing and collections bills, including the paginated list of records.
            - header_map (dict): Mapping for headers based on user role.
            - pages (dict): Pagination details (start, end, total).
    """
    try:
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        tenant_database=data.get('db_name','altaworx_central')
        role_name = data.get('role_name', '')
        tenant_name =data.get('tenant_name','')
        account_number=data.get("account_number",'')
        col_sort = data.get("col_sort", "")
        table_name = data.get('table_name', 'billing_list_view')
        tenant_id = data.get('tenant_id', '')
        mode=os.getenv('ENV','UAT')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        
        # Set default pagination if not provided
        start = data.get('mod_pages', {}).get('start', 0)
        end = data.get('mod_pages', {}).get('end', 100)

        limit = end - start
        offset = start

        start_date = data.get('start_date', '')
        end_date = data.get('end_date', '')
        # Get tenant's timezone
        tenant_name = data.get('tenant_name', '')
        tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

            # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
                raise ValueError("No valid timezone found for tenant.")

        tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly
        
        # total number of records
        try:
            if start_date:
                total_count_query="""SELECT id 
                                    FROM billing_list_view 
                                    where created_date between %s and %s and tenant_id = %s and is_active = 'true'"""
                params=[start_date,end_date,tenant_id]
            else:
                total_count_query="""SELECT id 
                                    FROM billing_list_view where tenant_id = %s and is_active = 'true'"""
                params=[tenant_id]
            total_count_result=killbill_database.execute_query(total_count_query, params=params)
        except Exception as e:
            total_count_result=[]
            print(f"ERROR:{e}")
        total_count=len(total_count_result['id'].to_list())
        
        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }
        
        # for sorting
        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        else:
            order_clause="ORDER BY modified_date desc"

        # fetching list view data
        if start_date:
            query = f"SELECT * FROM billing_list_view where created_date between %s and %s and tenent_id = {tenant_id} and is_active = 'true' {order_clause} LIMIT %s OFFSET %s"
            params = (start_date, end_date, limit, offset)
        else:
            query = f"SELECT * FROM billing_list_view where tenant_id = {tenant_id} and is_active = 'true' {order_clause} LIMIT %s OFFSET %s"
            params = (limit, offset)
        df_dict = killbill_database.execute_query(query, params=params).to_dict(orient="records")
        
        # converting the time based on the time_zone
        df_dict = convert_timestamp(df_dict, tenant_time_zone)
        # header maps
        header_map = get_headers_mapping(tenant_database,["Billing and Payments Billing"],role_name, '', '', '', '',data)
        data_dict_all = {"billing_and_payments_billing": serialize_data(df_dict)}
        logging.info('###data_dict_all',data_dict_all)
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        return response

    except Exception as e:
        logging.exception(f"###billing_payments_bills_list_view :Exception occurred: {e}")
        error_data = {
            "service_name": "billing_payments_bills_list_view",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Bills list",
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Payments  list",
            "data": {}  # Return empty dictionary on error
        }
        return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching email list",
            "data": {}  # Return empty dictionary on error
        }
        return response

def all_payment_history_list_view(data):
    """
    Fetches and returns the payment history for a tenant with pagination, 
    applies timezone adjustments, and structures the response with headers.

    Parameters:
        data (dict): A dictionary containing the request details, including:
            - 'db_name' (str, optional): The name of the tenant database (default: 'altaworx_central').
            - 'role_name' (str, optional): The role name of the requesting user.
            - 'tenant_name' (str): The name of the tenant requesting the data.
            - 'mod_pages' (dict, optional): Pagination parameters:
                - 'start' (int, optional): The starting index of records (default: 0).
                - 'end' (int, optional): The ending index of records (default: 100).
    """
    try:
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        tenant_database=data.get('db_name','altaworx_central')
        table_name=data.get('table_name', 'payment_history')
        role_name = data.get('role_name', '')
        tenant_name =data.get('tenant_name','')
        tenant_id = data.get('tenant_id', '')
        mode=os.getenv('ENV','UAT')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        # Set default pagination if not provided
        start = data.get('mod_pages', {}).get('start', 0)
        end = data.get('mod_pages', {}).get('end', 100)
        col_sort = data.get("col_sort", "")
        limit = end - start
        offset = start

        start_date=data.get('start_date', '')
        end_date=data.get('end_date', '')
        # Get tenant's timezone
        tenant_name = data.get('tenant_name', '')
        tenant_time_zone = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name},["time_zone"]
            )["time_zone"].to_list()[0]
        logging.info("**tenant_time_zone",tenant_time_zone)

        if tenant_time_zone is None:
                raise ValueError("No valid timezone found for tenant.")

        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

        try:
            # total_count_result = killbill_database.get_data(
            #         table_name, {'is_active':True},["id"]
            #     )["id"].to_list()
            if start_date:
                total_count_query="""SELECT id 
                                    FROM payments_list_view 
                                    where tenant_id = %s and date between %s and %s"""
                params=[tenant_id,start_date,end_date]
            else:
                total_count_query="""SELECT id 
                                    FROM payments_list_view where tenant_id = %s"""
                params=[tenant_id]
            total_count_result=killbill_database.execute_query(total_count_query, params=params)
        except Exception as e:
            total_count_result=[]

        total_count=len(total_count_result['id'].to_list())
        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }

        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        else:
            order_clause="ORDER BY date desc"

        if start_date:
            query = f'SELECT * FROM payments_list_view where tenant_id = %s and date between %s and %s {order_clause}'
            params = [tenant_id,start_date, end_date]
        else:
            query = f'SELECT * FROM payments_list_view where tenant_id = %s {order_clause}'
            params = [tenant_id]

        df_dict = killbill_database.execute_query(query, params=params).to_dict(orient="records")
        

        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        # Prepare response data
        header_map = get_headers_mapping(tenant_database,["Billing and Payments-Payment History"],role_name, '', '', '', '',data)
        data_dict_all = {"payment_history": serialize_data(df_dict)}
        logging.info('###header_map{header_map}')
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        return response

    except Exception as e:
        logging.exception(f"###all_payment_history_list_view Exception occurred: {e}")
        error_data = {
            "service_name": "all_payment_history_list_view",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Payments list",
            "module_name": "Billing Payments",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        response = {
            "flag": False,
            "message": "Something went wrong fetching email list",
            "data": {}  # Return empty dictionary on error
        }
        return response
  
def charge_by_service_list_view(data):
    """
    Retrieves a paginated list of customer services based on tenant details and filters.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str, optional): The tenant database name. Defaults to 'altaworx_central'.
            - role_name (str, optional): The user's role name for header mapping.
            - tenant_name (str, optional): The tenant name for fetching timezone and metadata.
            - mod_pages (dict, optional): Pagination details:
                - start (int, optional): Start index for records. Defaults to 0.
                - end (int, optional): End index for records. Defaults to 100.
            - col_sort (dict, optional): Sorting details in the format {column_name: "asc"/"desc"}.
            - account_number (str, optional): The customer account number.
            - bill_id (str, optional): The billing ID for fetching cycle details.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation.
            - message (str): Success or error message.
            - data (dict): Processed customer service data.
            - header_map (dict): Mapped headers for response.
            - pages (dict): Pagination details including total records.
    """

    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    tenant_database=data.get('db_name','altaworx_central')
    role_name = data.get('role_name', '')
    tenant_name =data.get('tenant_name','')
    # Set default pagination if not provided
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    col_sort = data.get("col_sort", "")
    limit = end - start
    offset = start
    account_number=data.get("account_number","")
    bill_id=data.get("bill_id","")
    
    # Fetch billing cycle end date if a bill ID is provided
    if bill_id:
        customer_bills_=killbill_database.get_data('customer_bills',{"id":bill_id},["created_date","account_number","customer_profile_id","applied_services"])
        created_date=customer_bills_["created_date"].to_list()[0]
        account_number=customer_bills_["account_number"].to_list()[0]
        customer_profile_id=customer_bills_["customer_profile_id"].to_list()[0]

        applied_services=customer_bills_["applied_services"].to_list()[0]
        if applied_services:
            applied_services=tuple(ast.literal_eval(applied_services))
        else:
            applied_services=tuple([0])

        # Retrieve customer profiles (IDs and account numbers)
        # customer_profiles_db=killbill_database.get_data("customer_profiles",None,["id","account_number"])
        # customer_profile_ids=customer_profiles_db["id"].to_list()
        # customer_profile_acc_no=customer_profiles_db["account_number"].to_list()
        # customer_ids_acc_dict=dict(zip(customer_profile_ids,customer_profile_acc_no))

        # Query to get the total number of matching records
        total_count_query="""SELECT id 
                            FROM customer_services 
                            WHERE customer_profile_id = %s 
                            AND id in %s"""
        total_count_result=killbill_database.execute_query(total_count_query, params=[customer_profile_id,applied_services])
        if not total_count_result.empty:
            total_count_result=total_count_result['id'].tolist()
            total_count=len(total_count_result)
            logging.info("**totalquery",total_count_result)
        else:
            total_count=0
        # logging.info(f"total_count_result: {type(total_count)} - {total_count}")
        
        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }   


        # Query to retrieve paginated customer service data
        query="""SELECT id,packages,customer_profile_id,charges
                FROM customer_services 
                WHERE customer_profile_id = %s 
                AND id in %s"""

        order_clause = ""
        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        query=query+order_clause

        df = killbill_database.execute_query(query,params=[customer_profile_id,applied_services])  # Get the DataFrame directly
        logging.info('###df {df}')
        df_dict = df.to_dict(orient="records")

        try:
            # Prepare response data
            header_map = get_headers_mapping(tenant_database,["Billing Charge By Service"],role_name, '', '', '', '',data)
            final_data_dict=serialize_data(df_dict)
            
            # Process retrieved data
            if final_data_dict: 
                for record in final_data_dict:
                    # if record["customer_profile_id"]:
                    #     if record["customer_profile_id"] in customer_ids_acc_dict:
                    record["account_number"]=account_number
                    # Convert package list to a comma-separated string
                    if record["packages"]:
                        packages_list=ast.literal_eval(record["packages"])
                        package_str=", ".join(packages_list)
                        record["packages"]=package_str
                    record['total']=record.pop('charges', None)
            else:
                final_data_dict=[]
                
            # Construct response dictionary           
            data_dict_all = {"billing_charge_by_service": final_data_dict}
            response = {
                "flag": True,
                "message": "Data fetched successfully",
                "data": data_dict_all,
                "header_map": header_map,
                "pages": pages_data
            }
            return response

        except Exception as e:
            logging.exception(f"Exception occurred: {e}")
            response = {
                "flag": False,
                "message": "Something went wrong fetching Charge by Service List View",
                "data": {}  # Return empty dictionary on error
            }
            return response
    else:
        response = {
                "flag": False,
                "message": "Bill ID Invalid",
                "data": {}  # Return empty dictionary on error
            }
        return response


def charge_overview_list_view_back(data):
    """
    Retrieves a paginated list of customer services based on tenant details and filters.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str, optional): The tenant database name. Defaults to 'altaworx_central'.
            - role_name (str, optional): The user's role name for header mapping.
            - tenant_name (str, optional): The tenant name for fetching timezone and metadata.
            - bill_id (str, optional): The specific billing ID to fetch charge details.
            - mod_pages (dict, optional): Pagination details:
                - start (int, optional): Start index for records. Defaults to 0.
                - end (int, optional): End index for records. Defaults to 100.
            - col_sort (dict, optional): Sorting details in the format {column_name: "asc"/"desc"}.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation.
            - message (str): Success or error message.
            - data (dict): Processed customer service data.
            - header_map (dict): Mapped headers for response.
            - pages (dict): Pagination details including total records.

    Raises:
        ValueError: If no valid timezone is found for the given tenant.
    """
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    tenant_database=data.get('db_name','altaworx_central')
    role_name = data.get('role_name', '')
    tenant_name =data.get('tenant_name','')
    bill_id=data.get("bill_id",'')
    
    # Fetch billing details if a bill_id is provided
    if bill_id:
        customers_bills=killbill_database.get_data("customer_bills",{"id":bill_id},["bill_details","usage_details", "applied_services"])
        bill_details=customers_bills["bill_details"].to_list()
        usage_details=customers_bills["usage_details"].to_list()
        applied_services=customers_bills["applied_services"].to_list()[0]
        print(f'applied_services------{applied_services}')

        if applied_services:
            applied_services=tuple(ast.literal_eval(applied_services))
            total_charges_by_services = 0
            for i in applied_services:
                customer_services=killbill_database.get_data("customer_services",{"id":i},["charges"])
                charges =customer_services["charges"].to_list()[0]
                total_charges_by_services += charges
            print(f'total_charges_by_services------{total_charges_by_services}')
        else:
            total_charges_by_services = 0
        
    final_bill_details={}
    if bill_details:
        bill_details=bill_details[0]
        if bill_details:
            bill_details[0]["Total Charges by Service"] = total_charges_by_services
            final_bill_details=bill_details[0]
            if "charge_details" in final_bill_details:
                final_bill_details["charge_details"].append({
                    "charge_type": "Charges by Service",
                    "charge_amount": total_charges_by_services
                })
                
            else:
                final_bill_details["charge_details"] = [{
                    "charge_type": "Charges by Service",
                    "charge_amount": total_charges_by_services
                }]
            final_bill_details["Total Charges"] += total_charges_by_services
            # if isinstance(bill_details,dict):
            #     for charge in bill_details.keys():
            #         if isinstance(bill_details[charge],dict):
            #             final_bill_detsils[charge]=bill_details[charge].get('charge_amount','')
            #         else:
            #             final_bill_detsils[charge]=bill_details[charge]
    if usage_details:
        usage_details=usage_details[0]
    else:
        usage_details=[]
    df_dict={
        "bill_details":final_bill_details,
        "usage_details":usage_details
    }

    try:
        # Map headers based on tenant database and role
        header_map = get_headers_mapping(tenant_database,["Billing Charge Overview"],role_name, '', '', '', '',data)
        final_data_dict=serialize_data(df_dict)
        # Structure response dictionary
        data_dict_all = {"billing_charge_overview": final_data_dict}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": {}
        }
        return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching charge overview",
            "data": {}  # Return empty dictionary on error
        }
        return response


def charge_overview_list_view(data):
    """
    Retrieves a paginated list of customer services based on tenant details and filters.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str, optional): The tenant database name. Defaults to 'altaworx_central'.
            - role_name (str, optional): The user's role name for header mapping.
            - tenant_name (str, optional): The tenant name for fetching timezone and metadata.
            - bill_id (str, optional): The specific billing ID to fetch charge details.
            - mod_pages (dict, optional): Pagination details:
                - start (int, optional): Start index for records. Defaults to 0.
                - end (int, optional): End index for records. Defaults to 100.
            - col_sort (dict, optional): Sorting details in the format {column_name: "asc"/"desc"}.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation.
            - message (str): Success or error message.
            - data (dict): Processed customer service data.
            - header_map (dict): Mapped headers for response.
            - pages (dict): Pagination details including total records.

    Raises:
        ValueError: If no valid timezone is found for the given tenant.
    """
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    tenant_database=data.get('db_name','altaworx_central')
    role_name = data.get('role_name', '')
    tenant_name =data.get('tenant_name','')
    bill_id=data.get("bill_id",'')
    
    # Fetch billing details if a bill_id is provided
    if bill_id:
        customers_bills=killbill_database.get_data("customer_bills",{"id":bill_id},["bill_details","usage_info", "applied_services","recurring_charges_audit"])
        bill_details=customers_bills["bill_details"].to_list()
        usage_info=customers_bills["usage_info"].to_list()
        applied_services=customers_bills["applied_services"].to_list()[0]
        recurring_charges_audit=customers_bills["recurring_charges_audit"].to_list()[0]
        print(f'applied_services------{applied_services}')

        # if applied_services:
        #     applied_services=tuple(ast.literal_eval(applied_services))
        #     total_charges_by_services = 0
        #     try:
        #         for i in applied_services:
        #             customer_services=killbill_database.get_data("customer_services",{"id":i},["charges"])
        #             charges =customer_services["charges"].to_list()[0]
        #             total_charges_by_services += charges
        #         print(f'total_charges_by_services------{total_charges_by_services}')
        #     except Exception as e:
        #         logging.exception(f"Exception occurred while trying to fecth charges: {e}")
        # else:
        #     total_charges_by_services = 0
        if recurring_charges_audit and recurring_charges_audit != '{}':
            if isinstance(recurring_charges_audit, str):
                try:
                    recurring_charges_audit = ast.literal_eval(recurring_charges_audit)
                except (ValueError, SyntaxError):
                    try:
                        recurring_charges_audit = json.loads(recurring_charges_audit)
                    except json.JSONDecodeError:
                        recurring_charges_audit = {}
            elif not isinstance(recurring_charges_audit, dict):
                recurring_charges_audit = {}
            if recurring_charges_audit:
                total_charges_by_services=sum(record.get('total_charge', 0) for record in recurring_charges_audit.values())
            else:
                total_charges_by_services=0
        else:
            total_charges_by_services=0
                

        
    final_bill_details={}
    if bill_details:
        bill_details=bill_details[0]
        if bill_details:
            final_bill_details=bill_details[0]
            
            # Define allowed charge types
            # Recalculate Total Charges only from allowed charges
            allowed_charge_types = ["Network Access Fee", "Cost Recovery Fee", "Late Fee"]

            if "charge_details" in final_bill_details and isinstance(final_bill_details["charge_details"], list):
                filtered_charges = [
                    charge for charge in final_bill_details["charge_details"]
                    # if charge.get("charge_type") in allowed_charge_types
                ]
                final_bill_details["charge_details"] = filtered_charges

                # Calculate total from filtered charge_details
                total_allowed_charge = sum(charge.get("charge_amount", 0) for charge in filtered_charges)

                # Update Total Charges correctly
                final_bill_details["Total Charges"] = total_allowed_charge
            else:
                # If charge_details not present, just assign service charges
                final_bill_details["charge_details"] = []
                final_bill_details["Total Charges"] = total_charges_by_services
    final_result={}
    if usage_info:
        usage_info=usage_info[0]
        if usage_info:
            try:
                usage_info=json.loads(usage_info)
                print(f"usage_info-----{usage_info}")
                final_result = {
                    "total_usage": 0,
                    "usage_info": []
                }

                for service_id, services in usage_info.items():
                    print(f"services-----{services}")
                    if "usage" in services:
                        usage_cost = services["usage"].get("total_usage", 0) or 0
                        if usage_cost:
                            serv_id=service_id.split("--")[0]
                            bill_range=service_id.split("--")[1]

                            final_result["usage_info"].append({
                                "service_id": int(float(serv_id)) if service_id else None,
                                "type": "Usage",
                                "cost": usage_cost,
                                "bill_range":bill_range
                            })
                            final_result["total_usage"] += usage_cost
                    
                    if "SMS" in services:
                        sms_cost = services["SMS"].get("total_cost", 0) or 0
                        if sms_cost:
                            serv_id=service_id.split("--")[0]
                            bill_range=service_id.split("--")[1]
                            final_result["usage_info"].append({
                                "service_id": int(float(serv_id)) if service_id else None,
                                "type": "SMS",
                                "cost": sms_cost,
                                "bill_range":bill_range
                            })
                            final_result["total_usage"] += sms_cost
            except Exception as e:
                logging.exception(f"Exception occurred while trying to fecth usage_info: {e}")
                final_result = {
                    "total_usage": 0,
                    "usage_info": []
                }
    else:
        final_result = {
                    "total_usage": 0,
                    "usage_info": []
                }
    df_dict={
        "bill_details":final_bill_details,
        "usage_details":final_result
    }

    try:
        # Map headers based on tenant database and role
        header_map = get_headers_mapping(tenant_database,["Charge Overview"],role_name, '', '', '', '',data)
        final_data_dict=serialize_data(df_dict)
        # Structure response dictionary
        data_dict_all = {"charge_overview": final_data_dict}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": {}
        }
        return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching charge overview",
            "data": {}  # Return empty dictionary on error
        }
        return response


def get_export_status(data):
    """
    The get_export_status function retrieves the export status of a specific module from a database.
    It queries the export_status table based on the given module name and returns the corresponding status data.
    """
    try:
        common_utils_database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
        module_name = data.get("module_name")
        export_status_query = (
            f"select * from export_status where module_name='{module_name}'"
        )
        export_status_data = common_utils_database.execute_query(
            export_status_query, True
        ).to_dict(orient="records")
        return {"flag": True, "export_status_data": export_status_data[0]}
    except Exception as e:
        logging.exception(f"Exception is {e}")
        error_data = {
            "service_name": "get_export_status",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Exporting PDF",
            "module_name": "Billing Payments",
            "request_received_at": data.get("request_received_at"),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "export_status_data": []}


def export_to_s3_bucket_(data):
    """
    Export combined query results for all billing periods into a single Excel file
    and upload it to an Amazon S3 bucket.

    Args:
        data (dict): Input data with necessary details.

    Returns:
        dict: Operation result containing flag, message, and optionally download_url.
    """
    S3_BUCKET_NAME = "searchexceluat"

    # Extract input parameters
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    user_name = data.get("user_name", "")
    session_id = data.get("session_id", "")
    service_provider = data.get("service_provider", "")
    billing_cycle_period = data.get("billing_cycle_period", "")
    end_date = data.get('end_date', '')
    start_date = data.get('start_date', '')
    tenant_database = data.get("db_name", "")
    data_frames = data.get("dfs", {})  # Expecting a dict {"Sheet1": df1, "Sheet2": df2}

    if module_name == 'SimManagement Inventory':
        file_name = f"exports/uat/{module_name_snake_case}/SimManagement/Inventory.xlsx"
    else:
        file_name = f"exports/uat/{module_name_snake_case}/{module_name}.xlsx"

    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

    database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)

    # Update export status to 'Waiting'
    db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name},
    )

    try:
        if not data_frames :
            db.update_dict(
                "export_status",
                {"status_flag": "No Data Found for export", "url": ""},
                {"module_name": module_name},
            )
            return {"flag": False, "message": "No data found for export."}

        excel_buffer = BytesIO()
        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
            for sheet_name, df in data_frames.items():
                if df.empty:
                    df = pd.DataFrame(columns=["No Data"])

                # Format column names
                acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "SIM"}
                special_replacements = {"Att": "AT&T", "And": "and"}

                df.columns = [
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in str(col).split("_")
                    )
                    for col in df.columns
                ]
                df.columns = [
                    " ".join([special_replacements.get(word, word) for word in col.split(" ")]) for col in df.columns
                ]

                df.to_excel(writer, index=False, sheet_name=sheet_name)

                # Apply styles
                workbook = writer.book
                sheet = workbook[sheet_name]

                header_font = Font(bold=True)
                for cell in sheet[1]:
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                    cell.font = header_font

                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        excel_buffer.seek(0)

        s3_client = boto3.client("s3")
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=excel_buffer.getvalue(),
            ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

        db.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": module_name},
        )
        return {"flag": True, "download_url": download_url}

    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name}
        )
        db.log_error_to_db(
            {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": str(e),
                "module_name": "export",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error: {str(e)}"}

def export_to_s3_bucket_charge_overview(data):
    """
    Export combined query results for all billing periods into a single Excel file
    and upload it to an Amazon S3 bucket.

    Args:
        data (dict): Input data with necessary details.

    Returns:
        dict: Operation result containing flag, message, and optionally download_url.
    """
    S3_BUCKET_NAME = "searchexceluat"

    # Extract input parameters
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    user_name = data.get("user_name", "")
    session_id = data.get("session_id", "")
    service_provider = data.get("service_provider", "")
    billing_cycle_period = data.get("billing_cycle_period", "")
    end_date = data.get('end_date', '')
    start_date = data.get('start_date', '')
    tenant_database = data.get("db_name", "")
    data_frames = data.get("dfs", {})  # Expecting a dict {"Sheet1": df1, "Sheet2": df2}

    
    file_name = f"exports/uat/{module_name_snake_case}/{module_name}.xlsx"

    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

    database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)

    # Update export status to 'Waiting'
    db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name},
    )

    try:
        if not data_frames :
            db.update_dict(
                "export_status",
                {"status_flag": "No Data Found for export", "url": ""},
                {"module_name": module_name},
            )
            return {"flag": False, "message": "No data found for export."}

        excel_buffer = BytesIO()
        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
            for sheet_name, df in data_frames.items():
                start_row = 0  # Start from the first row
                # Process each dictionary in the list
                if not df:
                    df = pd.DataFrame(columns=["No Data"])
                else:
                    for data_ in df:
                        for key, sub_dict in data_.items():  # Loop through 'credits' and 'charge'
                            # Write Section Header (e.g., "Credits" or "Charge")
                            pd.DataFrame({key.capitalize(): [""]}).to_excel(writer, sheet_name=sheet_name, 
                                                                            index=False, startrow=start_row)
                            start_row += 1  # Move to the next row
                            final_key_list=[]
                            final_value_list=[]
                            for i in sub_dict:
                                for k,v in i.items():
                                    final_key_list.append(k)
                                    final_value_list.append(v)
                            # Convert dictionary into vertical formatkjhg
                            vertical_data = {
                                "Description": [" ".join(word.capitalize() for word in key.split("_")) for key in final_key_list],  
                                "Value": final_value_list
                            }
                            vertical_df = pd.DataFrame(vertical_data)
                            vertical_df.to_excel(writer, sheet_name=sheet_name, index=False, startrow=start_row)

                            # Move start_row to avoid overlapping (add space after each block)
                            start_row += len(vertical_df) + 2  # Space for next section

                    # Get workbook and sheet for formatting
                    workbook = writer.book
                    sheet = workbook[sheet_name]

                # Apply bold formatting to section headers
                for row in range(1, start_row, len(vertical_df) + 2):  # Headers are spaced out
                    for cell in sheet[row]:
                        cell.font = Font(bold=True)

                # Auto-adjust column widths
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        excel_buffer.seek(0)

        s3_client = boto3.client("s3")
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=excel_buffer.getvalue(),
            ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

        db.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": module_name},
        )
        return {"flag": True, "download_url": download_url}

    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name}
        )
        db.log_error_to_db(
            {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": str(e),
                "module_name": "export",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error: {str(e)}"}

    


def charge_overview_export(data):
    """
    Retrieves charge overview details, including bill details and usage details, from 
    the billing database using a provided bill ID. The function processes the data 
    and exports it to an S3 bucket.

    Parameters:
    data (dict): A dictionary containing the following key:
                 - "bill_id" (str, optional): The billing ID to fetch the charge overview details.

    Returns:
    dict: The response from the export function after storing the processed data.
    """

    killbill_database =  DB('billing_platform', **db_config)
    bill_id=data.get("bill_id","")
    account_number=data.get("account_number","")
    # Fetch bill details and usage details if a bill ID is provided
    if bill_id:
        customers_bills=killbill_database.get_data("customer_bills",{"id":bill_id},["bill_details","usage_details", "applied_services"])
        # Extract bill details and usage details from the database response
        bill_details=customers_bills["bill_details"].to_list()
        usage_details=customers_bills["usage_details"].to_list()
        applied_services=customers_bills["applied_services"].to_list()[0]

    if applied_services:
            applied_services=tuple(ast.literal_eval(applied_services))
            total_charges_by_services = 0
            for i in applied_services:
                customer_services=killbill_database.get_data("customer_services",{"id":i},["charges"])
                charges =customer_services["charges"].to_list()[0]
                total_charges_by_services += charges
            print(f'total_charges_by_services------{total_charges_by_services}')
    else:
        total_charges_by_services = 0
        
    if usage_details:
        usage_details=usage_details[0]
        if not usage_details:
            usage_details=[]
    else:
        usage_details=[]

    credits = []
    charges = []
    if bill_details:
        bill_details=bill_details[0]
        if bill_details:
            bill_data = bill_details[0] if isinstance(bill_details, list) and bill_details else {}

            if isinstance(bill_data, dict):
                for key, value in bill_data.items():

                    if isinstance(value, list):
                        if key=='credit_details':
                            for item in value:
                                credits.append({item.get('charge_type'): item.get("charge_amount", "")})
                        elif key=="charge_details":
                            for item in value:
                                charges.append({item.get('charge_type'): item.get("charge_amount", "")})
                    else:
                        if key == "Total Charges":
                            charges.append({"Total Charges":value})
                        elif key == "Total Credits":
                            credits.append({"Total Credits":value})
    
    charges.append({"Charges by Service": total_charges_by_services})
    # to bring total at end
    total_creditss = [item for item in credits if "Total Credits" in item]
    total_chargess = [item for item in charges if "Total Charges" in item]

    # Filter out total entries from the original lists
    credits = [item for item in credits if "Total Credits" not in item] + total_creditss
    charges = [item for item in charges if "Total Charges" not in item] + total_chargess

    
    for charge in charges:
        if "Total Charges" in charge:
            charge["Total Charges"] += total_charges_by_services
        
    usage_details_df = [{"usage_details":usage_details}]
    bill_details_df = [{"credits": credits}, {"charges": charges}]
    # Store the processed data as DataFrames in the "dfs" dictionary
    print(f"billllllllll {bill_details_df}")
    print(f"usage_details_df {usage_details_df}")
    data["dfs"]={
            "Bill Details":bill_details_df,
            "Usage Details":usage_details_df
        }

    return export_to_s3_bucket_charge_overview(data)


def charge_by_service_export(data):
    """
    Retrieves charge-by-service details from the billing database based on a given 
    bill ID or account number. The function processes customer profile data, fetches 
    active services, formats the data, and exports the result to an S3 bucket.

    Parameters:
    data (dict): A dictionary containing request parameters such as:
                 - "bill_id" (str, optional): The billing ID to filter the data.
                 - "account_number" (str, optional): The account number to filter the data.

    Returns:
    dict: The response from the export function after storing the processed data.
    """

    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    bill_id=data.get("bill_id","")
    
    if bill_id:
        customer_bills_=killbill_database.get_data('customer_bills',{"id":bill_id},["created_date","account_number","customer_profile_id","applied_services"])
        created_date=customer_bills_["created_date"].to_list()[0]
        account_number=customer_bills_["account_number"].to_list()[0]
        customer_profile_id=customer_bills_["customer_profile_id"].to_list()[0]
        applied_services=customer_bills_["applied_services"].to_list()[0]
        if applied_services:
            applied_services = ast.literal_eval(applied_services)
            applied_services_tuple=tuple(applied_services)
        else:
            applied_services_tuple=tuple([0])



    # customer_profiles_db=killbill_database.get_data("customer_profiles",None,["id","account_number"])
    # customer_profile_ids=customer_profiles_db["id"].to_list()
    # customer_profile_acc_no=customer_profiles_db["account_number"].to_list()
    # customer_ids_acc_dict=dict(zip(customer_profile_ids,customer_profile_acc_no))

    # Retrieve customer profile details if an account number is provided
    # if account_number:
    #     customer_profiles=killbill_database.get_data('customer_profiles',{"account_number":account_number},["id","account_type","customer_name"])
    #     customer_profile_id=customer_profiles["id"].to_list()[0]
    #     account_type=customer_profiles["account_type"].to_list()[0]
    #     customer_name=customer_profiles["customer_name"].to_list()[0]

    # # Determine account IDs based on account type
    # if account_type=="Standard" or account_type =="Parent":
    #     account_ids=killbill_database.get_data("customer_profile",{"customer_name":customer_name},["id"])["id"].to_list()
    #     account_ids=tuple(account_ids)
    # else:
    #     account_ids=(customer_profile_id,)

    # Query to fetch active customer services based on customer profile ID and bill cycle date
    query="""SELECT id,packages,charges
                FROM customer_services 
                WHERE customer_profile_id = %s 
                AND id  in %s;"""
    df = killbill_database.execute_query(query,params=[customer_profile_id,applied_services_tuple])  # Get the DataFrame directly
    logging.info('###df {df}')
    df_dict = df.to_dict(orient="records")
    
    # Process each record
    for record in df_dict:
        # if record["customer_profile_id"]:
        #     if record["customer_profile_id"] in customer_ids_acc_dict:
        record["service_id"]=record.pop("id")
        # Convert package list to a comma-separated string
        if record["packages"]:
            packages_list=ast.literal_eval(record["packages"])
            package_str=", ".join(packages_list)
            record["packages"]=package_str
        record["packages"]=record.pop('packages','')
        record["taxes"]=''
        record["account_number"]=account_number

    
                
    

    logging.info("***data",df_dict)
    # Convert to DataFrame
    df = pd.DataFrame(df_dict)

    df = df.fillna('')
    data["dfs"]={
        "Charge By Service":df
    }
    # Export the processed data to an S3 bucket and return the response
    return export_to_s3_bucket_(data)

def bills_export(data):
    """
    Retrieves bill list details from the billing database based on a provided
    account number. The function processes the data and exports it to an S3 bucket.

    Parameters:
    data (dict): A dictionary containing the following key:
                 - "account_number" (str): The account number to fetch the bill list details.

    Returns:
    dict: The response from the export function after storing the processed data.
    """
    try:
        col_sort=data.get('col_sort', '')
        start_date=data.get('start_date','')
        end_date=data.get('end_date','')
        killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

        # tenant based time
        tenant_name = data.get('tenant_name', '')
        tenant_id = data.get('tenant_id', '')
        mode=os.getenv('ENV','UAT')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

            # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
                raise ValueError("No valid timezone found for tenant.")

        tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly


        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        else:
            order_clause="ORDER BY modified_date desc"

        # fetching list view data
        if start_date:
            query = f"SELECT * FROM billing_list_view where tenant_id = %s and is_active = 'true' and created_date between %s and %s {order_clause}"
            params = [tenant_id,start_date, end_date]
        else:
            query = f"SELECT * FROM billing_list_view where tenant_id = %s and is_active = 'true' {order_clause}"
            params = [tenant_id]
        df_dict = killbill_database.execute_query(query, params=params).to_dict(orient="records")

        
        # converting the time based on the time_zone
        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        df = pd.DataFrame(df_dict)

        df = df.fillna('')
        # data["dfs"]={
        #     "Bills":df
        # }
        if not df.empty:
            data["dfs"]={
                "Bills":df
            }
        else:
            data["dfs"]={}
        # Export the processed data to an S3 bucket and return the response
        return export_to_s3_bucket_(data)
    except Exception as e:
        logging.info(f"###bills_export Error in bills_export: {e}")
        error_data = {
            "service_name": "bills_export",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Bill Export",
            "module_name": "Billing Payments",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "Bill Export Failed"}



def payments_history_export(data):
    """
    Retrieves bill list details from the billing database based on a provided
    account number. The function processes the data and exports it to an S3 bucket.

    Parameters:
    data (dict): A dictionary containing the following key:
                 - "account_number" (str): The account number to fetch the bill list details.

    Returns:
    dict: The response from the export function after storing the processed data.
    """
    try:
        start_date=data.get('start_date','')
        end_date=data.get('end_date','')
        col_sort=data.get('col_sort', '')
        killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

        # tenant based time
        tenant_name = data.get('tenant_name', '')
        tenant_id = data.get('tenant_id', '')
        mode=os.getenv('ENV','UAT')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

            # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
                raise ValueError("No valid timezone found for tenant.")

        tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly


        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        else:
            order_clause="ORDER BY date desc"

        # fetching list view data
        if start_date:
            query = f'SELECT * FROM payments_list_view where tenant_id = %s and date between %s and %s {order_clause}'
            params = [tenant_id,start_date, end_date]
        else:
            query = f'SELECT * FROM payments_list_view where tenant_id = %s {order_clause}'
            params = [tenant_id]
        df_dict = killbill_database.execute_query(query, params=params).to_dict(orient="records")
        
        
        # converting the time based on the time_zone
        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        df = pd.DataFrame(df_dict)

        df = df.fillna('')
        data["dfs"]={
            "Payment History":df
        }
        # Export the processed data to an S3 bucket and return the response
        return export_to_s3_bucket_(data)
    except Exception as e:
        logging.info(f"###payments_history_export Error in payments_history_export: {e}")
        error_data = {
            "service_name": "payments_history_export",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Payment History Export",
            "module_name": "Billing Payments",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "Payment History Export Failed"}
