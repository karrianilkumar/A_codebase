"""
Lambda Router for API Gateway Requests.

This Lambda function acts as a router to invoke one of two target Lambda functions
(`sim_management` or `module_management`) based on the incoming API `path`.

Usage:
- Define the path-to-logical Lambda mapping in `PATH_TO_LAMBDA`.
- Logical Lambda names are resolved to environment-specific function names
  (`_uat` suffix for UAT, no suffix for production).

Environment Variables:
- ENV: Deployment environment (default: "UAT").
"""

import json
import os
import boto3
from common_utils.logging_utils import Logging

# Environment setup
env = os.environ.get("ENV", "UAT").upper()
logging = Logging(name="main")
lambda_client = boto3.client("lambda")

# Path → Logical Lambda mapping
PATH_TO_LAMBDA = {
    # sim_management mappings
    "/list_devices": "sim_management",
    "/get_sim_details": "sim_management",
    "/get_status_history": "sim_management",
    "/edit_cost_center": "sim_management",
    "/change_carrier_rate_plan": "sim_management",
    "/change_customer_rate_plan": "sim_management",
    "/update_username": "sim_management",
    "/update_device_status": "sim_management",
    "/assign_customer": "sim_management",
    "/carrier_rate_plan_list_view": "sim_management",
    "/create_customer_rate_plan": "sim_management",
    "/update_carrier_rate_plan": "sim_management",
    "/customer_rate_plan_list_view": "sim_management",
    "/update_customer_rate_plan": "sim_management",
    "/bulk_change_username_costcenter": "sim_management",
    "/bulk_update_device_status": "sim_management",
    "/bulk_change_activate_service": "sim_management",
    "/bulk_assign_customer": "sim_management",
    "/bulk_change_carrier_rate_plan": "sim_management",
    "/bulk_change_customer_rate_plan": "sim_management",
    "/bulk_archive": "sim_management",
    "/bulk_change_iccid_imei": "sim_management",
    "/update_bulk_change_phone_number": "sim_management",
    "/bulk_change_status": "sim_management",
    "/bulk_change_activate_service_agent": "sim_management",
    "/get_rate_plans_by_imei_and_customer_group": "sim_management",
    "/deactivate_service_product": "sim_management",
    "/add_service_line": "sim_management",
    "/add_service_product": "sim_management",
    "/assign_service_data": "sim_management",
    "/get_rev_details": "sim_management",
    "/bulk_change_activate_service_20": "sim_management",
    "/bulk_change_update_device_status_20": "sim_management",
    "/bulk_assign_customer_20": "sim_management",
    "/bulk_change_carrier_rate_plan_20": "sim_management",
    "/bulk_change_customer_rate_plan_20": "sim_management",
    "/bulk_archive_20": "sim_management",
    "/bulk_change_iccid_imei_20": "sim_management",
    "/bulk_change_phone_number_20": "sim_management",
    "/bulk_change_update_features_20": "sim_management",
    "/bulk_change_update_ppu_address_20": "sim_management",
    "/bulk_change_refresh_a_line_20": "sim_management",

    # module_management mappings
    "/customer_rate_pool_usage": "module_management",
    "/newly_activated_report": "module_management",
    "/pool_group_summary_report": "module_management",
    "/zero_usage_report": "module_management",
    "/daily_usage_report": "module_management",
    "/status_history_report": "module_management",
    "/usage_by_line_report": "module_management",
    "/export_active_lines_list": "module_management",
}

# Logical name → Environment-specific Lambda name
if env == "UAT":
    LAMBDA_FUNCTIONS = {
        "sim_management": "sim_management_uat",
        "module_management": "module_management_uat",
    }
else:
    LAMBDA_FUNCTIONS = {
        "sim_management": "sim_management",
        "module_management": "module_management",
    }


def lambda_handler(event, context):
    """
    Main AWS Lambda handler.

    Routes an API Gateway request to the appropriate Lambda function based on the path.

    Args:
        event (dict): Event payload from API Gateway, expected to contain "path".
        context (LambdaContext): AWS Lambda context object.

    Returns:
        dict | str: Response from the invoked target Lambda.
    """
    logging.info(f"### lambda_handler event: {event}")

    path = event.get("path")
    function_key = PATH_TO_LAMBDA.get(path)

    if not function_key:
        logging.error(f"### lambda_handler Unknown path: {path}")
        return {
            "statusCode": 400,
            "body": json.dumps({"error": f"Unknown path: {path}"}),
        }

    function_name = LAMBDA_FUNCTIONS[function_key]
    logging.info(f"### lambda_handler Invoking {function_name} for path {path}")

    response = lambda_client.invoke(
        FunctionName=function_name,
        InvocationType="RequestResponse",
        Payload=json.dumps(event),
    )

    payload_str = response["Payload"].read().decode("utf-8")
    try:
        payload_json = json.loads(payload_str)
    except json.JSONDecodeError:
        logging.warning("### lambda_handler Payload is not valid JSON; returning raw string")
        payload_json = payload_str

    return payload_json
