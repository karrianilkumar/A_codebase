"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil .N
Created Date: 21-06-24
"""

# Importing the necessary Libraries
import boto3
import requests
import os
from common_utils.db_utils import DB
import psycopg2
from dotenv import load_dotenv
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import *
from datetime import datetime, timedelta,time
import time
from data_transfer_main import DataTransfer
import pytds
from common_utils.kore import *

import json
import traceback
logging = Logging(name="bulk_change_sync")

db_config_withoutfilter = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

##to fetch the service providers ids for each tenants separately used to get the serviceprovider ids in generic way
def load_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_serviceproviders.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs


def load_integration_authentication_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_integration_authentication_id.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs

def get_integration_authentication_id_by_unique_name(json_data, tenant_name):
    logging.info(f"Tenant Name: {tenant_name}")
    """Fetches 'main_name' of a provider based on its unique name."""
    return json_data.get(tenant_name, {}).get("INTEGRATION_AUTHENTICATION_ID", None)

def get_integration_id_by_unique_name(json_data, tenant_name, unique_name):
    """Fetches 'main_name' of a provider based on its unique name."""
    return json_data.get(tenant_name, {}).get(unique_name, {}).get("integration_id", None)

def clean_tuple(tpl):
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        logging.info(f"Exception while converting {e}")
        return ()

def db_config_maker(user, db_config_making, tenant_database,tenant_name,role_name,readme_flag):
    if role_name in ('Super Admin','Partner Admin'):
        return db_config_making
    common_utils_database = DB('common_utils', **db_config_making)
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )

    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    if tenant_id:
        tenant_id=int(tenant_id)
    if readme_flag:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where client_id ='{user}' and tenant_id={tenant_id}"
    else:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"

    filters = common_utils_database.execute_query(query, True)

    database = DB(tenant_database, **db_config)
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except:
        customer_group = None

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
                customer_names=None

            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None


            except Exception as e:
                logging.exception("Error extracting billing_account_number:", e)
                billing_account_number=None

            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception("Error extracting feature_codes:", e)
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except:
            customer = None
    else:
        customer=customer_names
    customer=clean_tuple(customer)
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            formatted_values = "', '".join(service_provider)
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except:
        service_provider = None
        service_provider_id = None
    try:
        customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customers_df=database.execute_query(customers_query,True)
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                if isinstance(customer, str):
                    customer = customer.strip("()'")  # Clean customer from extra parentheses and quotes
                    customer = (customer,)  # Convert it into a tupl


                # Now convert tuple to list
                customer_list = list(customer)
                # Clean and fix the list by splitting the elements and ensuring they are correctly quoted
                fixed_customer_list = []

                # Split the string into items and strip any unwanted characters
                for item in customer_list[0].split("', '"):
                    fixed_customer_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info(f'customer_list before extend: { fixed_customer_list}')

                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info(f'customer_list after extend: {fixed_customer_list}')

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info(f'final customer tuple:{customer}')
                customer=clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(f"Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    try:
        customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_name = customer_rate_plan_name.strip("()'")  # Remove ( and ) and ' from start and end
                    customer_rate_plan_name = (customer_rate_plan_name,)  # Now correctly convert it to tuple

                # Now convert tuple to list
                customer_rate_plan_list = list(customer_rate_plan_name)
                fixed_customer_rate_plan_list = []

                # Split the string into items and strip any unwanted characters
                for item in customer_rate_plan_list[0].split("', '"):
                    fixed_customer_rate_plan_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info('customer_list before extend:', customer_rate_plan_list)

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info('customer_list after extend:', fixed_customer_rate_plan_list)

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info('final customer tuple:', customer_rate_plan_name)

    except Exception as e:
        logging.exception(f"Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")

    logging.info('customer at the end of customer',customer)
    db_config_making["customers"] = customer
    db_config_making["service_providers"] = service_provider
    db_config_making["service_provider_id"] = service_provider_id
    db_config_making["customer_rate_plan_name"] = customer_rate_plan_name
    db_config_making["feature_codes"] = feature_codes
    db_config_making["billing_account_number"] = billing_account_number
    return db_config_making

def funtion_caller(data, path, access_token):
    global db_config

    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

    user = data.get("username")
    sqs_call = data.get('sqs_call',False)
    logging.info(f"data recevied in function_caller is {data}")
    logging.info(f"path received is {path}")
    if not user:
        user = data.get("user_name")
    tenant_database = data.get("db_name")
    if not access_token:
        role_name = data.get("role_name", "") or data.get('role', "") or data.get('role',"") or 'Super Admin'
        tenant_name = data.get("tenant_name", "") or data.get('tenant', "") or data.get('Partner',"")
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        readme_flag=False
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making
        logging.info(f"db_config is created {path}")
    elif sqs_call:
        logging.info(f"sqs falg is true so skipped all the steps and calling the API")
        pass
    else:
        logging.info(f"db_config will be created for service accounts")
        logging.info(f"path gotten is {path}")
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        user = data.get("client_id", "")
        service_data = common_utils_database.get_data(
            "service_accounts", {"client_id": user}
        )

        if service_data.empty:
            logging.info(f"Invalid client ID: {user}")
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        role_name = service_data["role"].to_list()[0]
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}
        )
        tenant_database = tenant_data["db_name"].to_list()[0]
        readme_flag=False
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making

    if path == "/run_db_script":
        result = run_db_script(data)

    elif path == "/bulk_assign_customer":
        result = bulk_assign_customer(data)

    elif path=='/save_data_20_from_10':
        logging.info(f"IN PATH save_data_20_from_10")
        logging.info(f"DATA BEFORE CALLING {data}")
        data_transfer = DataTransfer()
        id_10=data.get("id_10",None)
        id_20=data.get("id_20",None)
        logging.info(f"IN PATH save_data_20_from_10 id_20 {id_20}")
        parent_tenant_id=data.get("parent_tenant_id", None)
        sub_tenant_id=data.get("sub_tenant_id", None)
        transfer_name=data.get("transfer_name", None)
        ver_inventory_flag=data.get("ver_inventory_flag", False)
        api_call_flag=data.get("api_call_flag",False)
        data_all=data.get("data_all", {})
        # postgres_data=data_all["data"]
        postgres_data=data.get("postgres_data", None)
        tenant_name=data.get("tenant_name",None)
        access_token=data.get("access_token",None)
        active_new_service_api_flag=data.get("active_new_service_api_flag",None)
        role_name=data.get("role_name",None)
        sync_count=data.get("sync_count",0)
        ui_tenant_name=data.get("ui_tenant_name",None)
        result = data_transfer.save_data_20_from_10(id_10,id_20,transfer_name,postgres_data, data_all, True, tenant_name,ver_inventory_flag,parent_tenant_id,sub_tenant_id,access_token,active_new_service_api_flag,role_name,api_call_flag,sync_count,ui_tenant_name)
        logging.info(f"cross provider sync caller is calling {id_20}")
        cross_provider_sync_caller(id_20,tenant_name,postgres_data,parent_tenant_id,sub_tenant_id)
    elif path == "/save_data_20_from_10_bulk_update":
        logging.info(f"IN PATH bulk_save_data_20_from_10")
        logging.info(f"DATA BEFORE CALLING {data}")
        data_transfer = DataTransfer()
        # data_transfer.rev_actions(data)
        # save_data_20_from_10(self,id_10,id_20,transfer_name,postgres_data, data_all)
        id_10=data.get("id_10",None)
        id_20=data.get("id_20",None)
        parent_tenant_id=data.get("parent_tenant_id", None)
        sub_tenant_id=data.get("sub_tenant_id", None)
        transfer_name=data.get("transfer_name", None)
        service_provider_id=data.get("service_provider_id", None)
        data_all=data.get("data_all", {})
        # postgres_data=data_all["data"]
        postgres_data=data.get("postgres_data", None)
        tenant_name=data.get("tenant_name",None)
        # result = data_transfer.save_data_20_from_10(id_10,id_20,transfer_name,postgres_data, data_all, True, tenant_name)
        result=data_transfer.save_data_20_from_10_bulk_update(
                       id_10,
                        id_20,
                        "bulk_change",
                        postgres_data,
                        data_all,
                        False,
                        tenant_name,
                        service_provider_id,
                        False,
                        parent_tenant_id,
                        sub_tenant_id
                    )
    else:
        result = {"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")

    return result

# Initialize the SNS client for sending alerts
sns_client = boto3.client("sns")

def send_sns_email(subject, message):
    """Send an email via SNS when an alert is triggered."""
    response = sns_client.publish(
        TopicArn=os.getenv('TOPICARN'),
        Message=message,
        Subject=subject,
    )
    # logging.info("SNS publish response:", response)
    return response

def bulk_change_lambda_caller(tenant_name,bulk_change_id="2833"):
    logging.info("bulk_change_lambda_caller function is called")
    # Assume the role from Account B
    sts_client = boto3.client("sts")
    mode=os.getenv('ENV','UAT')
    tenant_name=tenant_name.replace(" ", "")
    tenant_name=tenant_name.replace("-", "_")
    if mode=='PROD':
        tenant_role_arn=f"{tenant_name}_RoleArn"
        tenant_role_arn_env=os.getenv(tenant_role_arn)
    else:
        tenant_role_arn_env=os.getenv('RoleArn')
    assumed_role = sts_client.assume_role(
        RoleArn=tenant_role_arn_env,
        RoleSessionName="LambdaInvokeSession",
    )
    # Use the temporary credentials to invoke the Lambda in Account B
    credentials = assumed_role["Credentials"]
    lambda_client = boto3.client(
        "lambda",
        aws_access_key_id=credentials["AccessKeyId"],
        aws_secret_access_key=credentials["SecretAccessKey"],
        aws_session_token=credentials["SessionToken"],
        region_name="us-east-1",
    )
    sqs_client = boto3.client(
        "sqs",
        aws_access_key_id=credentials["AccessKeyId"],
        aws_secret_access_key=credentials["SecretAccessKey"],
        aws_session_token=credentials["SessionToken"],
        region_name="us-east-1",
    )
    # queue_url = "https://sqs.us-east-1.amazonaws.com/130265568833/DeviceBulkChange_TEST"

    if mode=='PROD':
        tenant_queue_url=f"{tenant_name}_queueurl"
        queue_url = os.getenv(tenant_queue_url)
    else:
        queue_url = os.getenv('DEVICEBULKCHANGE_TEST')

    action_flag = "queue"

    message_attributes = {
        "BulkChangeId": {"StringValue": bulk_change_id, "DataType": "String"},
        "AdditionBulkChangeId": {"StringValue": "0", "DataType": "String"},
    }
    message_body = "Not used"
    try:
        if action_flag == "Lambda":
            response = lambda_client.invoke(
                FunctionName=os.getenv('LAMBDACSHARP'),
                InvocationType="RequestResponse",
            )
            # Check if the response indicates a failure
            if response["StatusCode"] != 200:
                raise Exception(
                    f"Lambda invocation failed with status code: {response['StatusCode']}"
                )

            # logging.info("response---", response)
            return response["Payload"].read().decode("utf-8")

        elif action_flag == "queue":
            # Send the message to the SQS queue
            response = sqs_client.send_message(
                QueueUrl=queue_url,
                MessageBody=message_body,
                DelaySeconds=0,
                MessageAttributes=message_attributes,
            )
            logging.info("Message sent to SQS queue:", response)

            return {
                "statusCode": 200,
                "body": json.dumps(
                    {
                        "message": "Payload sent successfully to SQS queue",
                        "response": response,
                    }
                ),
            }
    except Exception as e:
        # Send alert if invocation fails
        subject = "Alert: Lambda Invocation Failed"
        message = f"An error occurred while invoking the Lambda function: {str(e)}"
        send_sns_email(subject, message)
        logging.info(f"Alert sent: {message}")

        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Invocation failed", "message": str(e)}),
        }

def get_parent_by_subtenant(subtenant_name, tenant_list):
    for tenant in tenant_list:
        for sub in tenant.get("sub_tenants", []):
            if sub.get("tenant_name") == subtenant_name:
                return tenant.get("parent_tenant_name")
    return None

def create_connection(
        db_type="",
        host="",
        db_name="",
        username="",
        password="",
        port="",
        driver="",
        max_retry=3,
    ):
    connection = None

    if db_type == "postgresql":
        try:
            logging.info(f"Creating PostgreSQL connection {host},{db_name},{username}")
            connection = psycopg2.connect(
                host=host,
                database=db_name,
                user=username,
                password=password,
                port=port,
            )
            logging.info("Connection to PostgreSQL DB successful")
        except Exception as e:
            logging.error(f"Failed to connect to PostgreSQL DB: {e}")
    elif db_type == "mssql":
        logging.info(
            f"conn : {db_type},{host},{db_name},{username},{password},{driver},{port}"
        )
        logging.info("Creating MSSQL connection")
        logging.info(f"Creating MSSQL connection using pytds")
        try:
            connection = pytds.connect(
                server=host,
                database=db_name,
                user=username,
                password=password,
                port=port,
            )
            logging.info("Connection to MSSQL successful!")
        except Exception as e:
            logging.error(f"Failed to connect to MSSQL DB: {e}")

    return connection

def function_to_check_sub_tenant_or_parent_name(postgres_conn, tenant_name):
    try:
        sub_tenant_name=None
        # SQL query to check tenant information
        query = """
            SELECT id,tenant_name, parent_tenant_id, db_name
            FROM public.tenant
            WHERE tenant_name = %s
            ORDER BY id DESC
            LIMIT 1;
        """

        # Execute the query with the tenant_id
        cursor = postgres_conn.cursor()
        cursor.execute(query, (tenant_name,))
        result = cursor.fetchone()

        # Check if the result exists
        if result:
            tenant_id, tenant_name, parent_tenant_id, db_name = result
            logging.info(f"Tenant found:{tenant_id} {tenant_name}, {parent_tenant_id}, {db_name}")

            # Determine the flags based on parent_tenant_id
            if parent_tenant_id is not None:
                parent_query = """
                SELECT tenant_name
                FROM public.tenant
                WHERE id = %s
                LIMIT 1;
                """
                cursor.execute(parent_query, (parent_tenant_id,))
                parent_result = cursor.fetchone()
                sub_tenant_name=tenant_name

                if parent_result:
                    tenant_name = parent_result[0]  # Overwrite with parent tenant name
            else:
                logging.info("assigning tentid to parent tenant id")
                parent_tenant_id=tenant_id


            logging.info(f"Flags: ,{parent_tenant_id} {tenant_id}")
            return tenant_name,parent_tenant_id,tenant_id,sub_tenant_name

        else:
            # If no result is found, raise an exception
            raise ValueError(f"No tenant found with tenant_id {tenant_name}")
    except Exception as e:
    # Handle any errors that may occur
        logging.info(f"Error occurred: {e}")
        return None, None, None  # Return None if there's an error

def tenant_load_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_sub_tenant.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"Unexpected error while reading JSON: {e}")

    return {}
def cross_provider_sync_caller(id_20, tenant_name, postgres_data, parent_tenant_id, sub_tenant_id):
    logging.info("Cross-provider sync caller started.")
    try:
        bulk_chnage_id_20=id_20
        logging.info(f"Cross-provider sync caller started for bulk change {bulk_chnage_id_20} ")
        common_utils_db = os.getenv("COMMON_UTILS_DATABASE", "common_utils")
        common_utils_db_conn = DB('common_utils', **db_config)
        hostname = os.getenv("PSQL_DB_HOST")
        port = os.getenv("PSQL_DB_PORT")
        user = os.getenv("PSQL_DB_USER")
        password = os.getenv("PSQL_DB_PASSWORD")
        db_type = os.getenv("PSQL_DB_TYPE")

        logging.info(f"Database Type: {db_type}")
        logging.info(f"Host: {hostname}")
        logging.info(f"Port: {port}")
        logging.info(f"User: {user}")
        logging.info(f"Common Utils DB: {common_utils_db}")

        # Create primary DB connection
        comm_postgres_con = create_connection(
            db_type, hostname, common_utils_db, user, password, port
        )
        logging.info("Primary DB connection established.")
        data_transfer = DataTransfer()
        # Create secondary DB connection (if needed)
        comm_postgres_con2 = data_transfer.create_connection(
            db_type, hostname, common_utils_db, user, password, port
        )
        logging.info("Secondary DB connection established.")
        if tenant_name == "Altaworx Test":
            #tenant_name = "Altaworx"
            tenant_name_lcase = "altaworx"
            db_name="altaworx_test"
        elif tenant_name == "Altaworx":
            tenant_name_lcase = "altaworx"
            db_name="altaworx_test"
        else:
            tenant_name_query = f"select db_name from tenant where tenant_name='{tenant_name}'"
            tenant_name_df = common_utils_db_conn.execute_query(tenant_name_query, True)
            tenant_name_lcase = tenant_name_df['db_name'].iloc[0].lower()
            db_name=tenant_name_lcase
        
        database = DB(db_name, **db_config)
        change_request = database.get_data("sim_management_bulk_change",{"id":bulk_chnage_id_20},["change_request_type"]).to_dict("records")
        try:
            logging.info(f"change request gotten is12345 {change_request},{bulk_chnage_id_20},{type(change_request)}")
            change_request = change_request[0].get("change_request_type")
            logging.info(f"change request gotten is {change_request}")

        except Exception as e:
            tb = traceback.format_exc()
            change_request=None
            logging.info(f"An error occurred while getting change request type is uncompatible {e} {tb}")
            pass
        
        bulk_change_id_ = database.get_data(
                "sim_management_bulk_change_request",
                {"bulk_change_id": bulk_chnage_id_20},  # Filter condition
                [
                    "iccid",
                    "subscriber_number",
                    "m2m_id",
                    "bulk_change_id",
                    "tenant_name",
                    "created_by",
                    "processed_by",
                    "status",
                    "device_id",
                    "is_active",
                    "is_deleted",
                    "change_request",
                ],  # Fields to retrieve
            ).to_dict("records")
        
        postgres_data["sim_management_bulk_change_request"] = bulk_change_id_

        logging.info(f"Data received for save_data_to_10 kore: {postgres_data}")
        

        if change_request=="Edit Username/Cost Center" or change_request=="Update Device Status":
            logging.info(f"change request gotten is {change_request}")
            data_transfer.cross_provider_sync(tenant_name,bulk_chnage_id_20,parent_tenant_id,postgres_data)
        else:
            logging.info(f"No need to call cross provider sync {change_request}")


    except Exception as e:
        logging.error(f"Error in cross-provider sync caller: {e}")
        return  # Avoid unnecessary 'pass'

def run_db_script(data_all):
    """
    This function orchestrates the execution of a series of database operations
    related to bulk change processing. It interacts with multiple systems, such as
    the database, data transfer system, and invokes AWS Lambda for further processing.

    Parameters:
        data_all (dict): Input dictionary containing data required for bulk change processing,
                          including the bulk change ID for different steps and database name.

    Returns:
        dict: A response dictionary indicating the status of the bulk change operation.
    """
    # Log that the DB script function is invoked
    logging.info("run db script is working here")
    logging.info(f"{data_all} 11111111111111111111 rundb script")
    try:
        del db_config ['tenant_ids']
    except Exception as e:
        logging.info(f"Exception is {e}")
    # Get the database name from the input data or default to 'altaworx_central'
    tenant_database = data_all.get("db_name", "altaworx_test")
    module_ = data_all.get("module_name", "")
    tenant_name=data_all.get('Partner',None)
    role_name = data_all.get('role_name', None)

    not_bulk_change = False
    if module_ == "Customer Rate Plan":
        customer_rate_plan = True
        not_bulk_change = True
    else:
        customer_rate_plan = False
    if module_ == "Provider Charge Settings":
        charge_history_settings = True
        not_bulk_change = True
    else:
        charge_history_settings = False

    if module_ == "Service Provider":
        service_provider_plan = True
        not_bulk_change = True
    else:
        service_provider_plan = False
    if module_ == "Partner Users":
        users_live_sync_plan = True
        not_bulk_change = True
    else:
        users_live_sync_plan = False
    if module_ == "Optimization Settings":
        optimization_settings = True
    else:
        optimization_settings = False
    if module_ == "Automation":
        automation_table_sync = True
    else:
        automation_table_sync = False

    data_transfer = DataTransfer()
    # Establish a database connection using the provided database name and configuration
    database = DB(tenant_database, **db_config)
    common_utils_db_conn = DB('common_utils', **db_config)

    # Extract relevant data from the input dictionary
    data_ = data_all["data"]
    access_token=data_all.get("access_token",None)
    api_call_flag=data_all.get("read_me_call",None) #for activate new service assign customers

    data_to_sent_charge_history = data_all.get("data", {})
    active_new_service_api_flag=False
    logging.info(f"this flag is to check whether serviceprovider or not {data_}"
    )
    data = data_all["data"]
    sub_tenant_name=None
    sub_tenant_id=None
    try:
        '''logging.info(f"4444444 {tenant_name}")
        sub_tenants_json=tenant_load_json()
        parent_tenant_name=get_parent_by_subtenant(tenant_name,sub_tenants_json)
        if parent_tenant_name:
            sub_tenant_name=tenant_name
            tenant_name=parent_tenant_name'''

        try:
            common_utils_db=os.getenv("COMMON_UTILS_DATABASE")
            #common_utils_db='common_utils'
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            logging.info(f"this is the db type {db_type}")
            logging.info(f"this is the hostname {hostname}")
            logging.info(f"this is the port {port}")
            logging.info(f"this is the user {user}")
            logging.info(f"this is the common_utils_bd {common_utils_db}")
            comm_postgres_con= create_connection(
                db_type, hostname,'common_utils', user, password, port
            )
            logging.info(f"this is the comm_postgres_con {comm_postgres_con}")
            comm_postgres_con2=data_transfer.create_connection(
                db_type, hostname,'common_utils', user, password, port
            )
            logging.info(f"this is the comm_postgres_con2 {comm_postgres_con2}")
        except Exception as e:
                logging.error(f"Error in getting common utils connection: {e}")
                tenant_name_lcase = None
                pass
        logging.info(f"this is the tenant name {tenant_name}")
        if tenant_name:
            logging.info(f"this is the tenant name in if  {tenant_name}")
            tenant_name,parent_tenant_id,sub_tenant_id,sub_tenant_name=function_to_check_sub_tenant_or_parent_name(comm_postgres_con2,tenant_name)
            logging.info(f"Response received from function_to_check_sub_tenant_or_parent_name: tenant_name: {tenant_name},parent_tenant_id:{parent_tenant_id},subtenant_id:{sub_tenant_id},sub_tenant_name:{sub_tenant_name}")
            logging.info(f"this is the tenant name in if  after checking parent tenan {tenant_name}")
            tenant_id=parent_tenant_id
        logging.info(f"this is the tenant name in if  after checking parent tenan {parent_tenant_id} and sub tenantid gotten is {sub_tenant_id}")

        if tenant_name == "Altaworx Test":
            #tenant_name = "Altaworx"
            tenant_name_lcase = "altaworx"
        elif tenant_name == "Altaworx":
            tenant_name_lcase = "altaworx"
        else:
            tenant_name_query = f"select db_name from tenant where tenant_name='{tenant_name}'"
            tenant_name_df = common_utils_db_conn.execute_query(tenant_name_query, True)
            tenant_name_lcase = tenant_name_df['db_name'].iloc[0].lower()
    except Exception as e:
        logging.error(f"Error in getting db name from tenant name: {e}")
        tenant_name_lcase = None
        pass

    if data.get("module_name") == "Automation" or automation_table_sync is True:
        not_bulk_change = True
        logging.info(f"Begining Automation")
        data_transfer = DataTransfer()
        logging.info(
            automation_table_sync,
            "this flag is to check whether automation_table_sync or not",
        )
        update_flag = data_all.get("update_flag", False)
        delete_flag = data_all.get("delete_flag", False)
        logging.info(f"Update flag {update_flag}, delete_flag {delete_flag}")
        transfer_name = f"automation_rule_test_{tenant_name_lcase}"
        data_to_sent = data_all.get("data", {})
        data_transfer.insert_automation_rule_table_data_with_psql_false(
            transfer_name, data_to_sent, update_flag, delete_flag
        )
        response = {
            "flag": True,
            "message": "Automation run db script called successfully",
        }
        return response
    if data.get("module_name")=="Provider Charge Settings" or charge_history_settings is True:
        not_bulk_change = True
        data_transfer = DataTransfer()
        logging.info(f"Data recieved for charge_history_settings", data)
        update_flag = data_all.get("update_flag", False)
        delete_flag = data_all.get("delete_flag", False)
        logging.info(f"Update flag {update_flag}, delete_flag {delete_flag}")
        data_to_sent = data_all.get("data", {})
        postgres_data = data_to_sent_charge_history
        transfer_name = f"service_provider_tenant_configuration_sync_{tenant_name_lcase}"
        logging.info(
            "this was the actual data to sent for charge_history_settings live sync",
            postgres_data,
        )
        data_transfer.charge_history_setting_function(
            transfer_name, postgres_data, update_flag, delete_flag
        )
        response = {
            "flag": True,
            "message": "charge_history_settings change run db script called successfully",
        }
        return response
    if (
        data.get("module_name") == "Optimization Settings"
        or optimization_settings is True
    ):
        not_bulk_change = True
        data_transfer = DataTransfer()
        logging.info(f"Data recieved for optimization_settings", data)
        update_flag = data_all.get("update_flag", False)
        delete_flag = data_all.get("delete_flag", False)
        logging.info(f"Update flag {update_flag}, delete_flag {delete_flag}")
        data_to_sent = data_all.get("data", {})
        # postgres_data=data_to_sent.get('data',{})
        postgres_data = data
        transfer_name = f"optimization_setting_{tenant_name_lcase}"
        logging.info(
            "this was the actual data to sent for optimization_settings live sync",
            postgres_data,
        )
        data_transfer.optimization_setting_function(
            transfer_name, postgres_data, update_flag, delete_flag,tenant_name,sub_tenant_name
        )
        response = {
            "flag": True,
            "message": "optimization_settings change run db script called successfully",
        }
        return response

    if data.get("module_name") == "Partner Users" or users_live_sync_plan is True:
        not_bulk_change = True
        data_transfer = DataTransfer()
        logging.info(f"Data recieved for Partner Users", data)
        update_flag = data_all.get("update_flag", False)
        delete_flag = data_all.get("delete_flag", False)
        logging.info(f"Update flag {update_flag}, delete_flag {delete_flag}")
        data_to_sent = data_all.get("data", {})
        postgres_data = data_all.get("data", {})
        transfer_name = "users_sync"
        logging.info(
            "this was the actual data to sent for users live sync", postgres_data
        )
        data_transfer.save_data_to_10_single_table_users(
            transfer_name, postgres_data, update_flag, delete_flag
        )
        response = {
            "flag": True,
            "message": "Users change run db script called successfully",
        }
        return response

    if data.get("module_name") == "Service Provider" or service_provider_plan is True:
        not_bulk_change = True
        data_transfer = DataTransfer()
        logging.info(f"Data recieved for service provider {data}")
        update_flag = data_all.get("update_flag", False)
        delete_flag = data_all.get("delete_flag", False)
        # data.get("serviceprovider", {}).get("tenant_id", 0) = int(data.get("serviceprovider", [{}])[0].get("tenant_id", 0))
        if data.get("serviceprovider") and isinstance(data["serviceprovider"], list) and len(data["serviceprovider"]) > 0:
            tenant_id_str = data["serviceprovider"][0].get("tenant_id", "0")

            # Convert to int safely
            try:
                data["serviceprovider"][0]["tenant_id"] = int(float(tenant_id_str))
            except ValueError:
                logging.info("Invalid tenant_id format. Setting to 0.")
                data["serviceprovider"][0]["tenant_id"] = 0
        logging.info(f"Data after conversion: {data}")
        logging.info(f"Update flag {update_flag}, delete_flag {delete_flag}")
        transfer_name = f"service_provider_{tenant_name_lcase}"
        data_to_sent = data_all.get("data", {})
        custom_fields = data_all.pop('custom_fields',[])
        if custom_fields:
            custom_fields = {"custom_fields":custom_fields}
            data_transfer.service_provider_setting_sync(custom_fields, transfer_name)
        # postgres_data=data_to_sent.get('data',{})
        postgres_data = data
        logging.info(
            "this was the actual data to sent for serviceprovider", postgres_data
        )
        data_transfer.save_data_to_10_single_table_db_config(
            transfer_name, postgres_data, update_flag, delete_flag
        )
        response = {
            "flag": True,
            "message": "Serviceproviders run db script called successfully",
        }
        return response

    if data.get("module_name") == "Customer Rate Plan" or customer_rate_plan is True:
        not_bulk_change = True
        # For 'Customer Rate Plan', execute this block
        logging.info(f"Data received for save_data_to_10: {data}")
        update_flag = data_all.get("update_flag", False)
        delete_flag = data_all.get("delete_flag", False)
        logging.info(f"Update flag {update_flag}, delete_flag {delete_flag}")
        customer_plan_data = data["customer_rate_plan"][0]
        get_optimization_type=customer_plan_data["optimization_type"]
        if get_optimization_type in ('Standard','Auto Change Rate Plan'):
            logging.info(f"optimization_type not in cross customer pooling {customer_plan_data}")
            customer_plan_data["auto_change_rate_plan"]=True
        else:
            customer_plan_data["auto_change_rate_plan"]=False
        columns_to_convert = [
            "plan_mb",
            "base_rate",
            "surcharge_3g",
            "min_plan_data_mb",
            "max_plan_data_mb",
            "rate_charge_amt",
            "data_per_overage_charge",
            "overage_rate_cost",
            "sms_rate",
        ]
        for col in columns_to_convert:
            value = customer_plan_data.get(col, None)
            logging.info(f"Col {col}, Val {value}")
            if value:
                if (
                    not isinstance(value, int)
                    and value is not None
                    and value.lower() != "none"
                ):
                    value = value.replace(",", "").strip()
                    customer_plan_data[col] = float(value)
                elif isinstance(value, int) and value is not None:
                    customer_plan_data[col] = float(value)
                else:
                    customer_plan_data[col] = None

        logging.info(f"Customer rate plan data receivec to save {customer_plan_data}")
        if "service_provider_id" not in customer_plan_data and "serviceproviderids" in customer_plan_data:
            serviceproviderids_str = customer_plan_data["serviceproviderids"]
            logging.info(f"serviceproviderids_str {serviceproviderids_str}")
            if serviceproviderids_str:
                try:
                    customer_plan_data["service_provider_id"] = [
                        int(spid.strip()) for spid in serviceproviderids_str.split(",") if spid.strip().isdigit()
                    ]
                    logging.info(f"serviceproviderids_str {serviceproviderids_str}")
                    logging.info(f"serviceproviderids_str  is added {customer_plan_data}")
                except Exception as e:
                    logging.error(f"Error processing serviceproviderids: {e}")
                    customer_plan_data["service_provider_id"] = []
                #customer_plan_data["service_provider_id"] = [int(id.strip()) for id in serviceproviderids_str.split(",")]
                logging.info(f"customer rate plan data after serviceproviderids is {customer_plan_data}")

        cust_rate_plan_id=customer_plan_data["id"]
        if not cust_rate_plan_id:
            tenant_id_query=f'''select tenant_id from customerrateplan where id='{cust_rate_plan_id}'
            '''
            logging.info(f"tenant_id_query {tenant_id_query}")
            cust_tenant_id=database.execute_query(tenant_id_query,True).to_dict(orient='records')
        cust_tenant_id=database.get_data(
                    "customerrateplan",
                    {"id": cust_rate_plan_id},
                    ["tenant_id"],
                ).to_dict("records")
        logging.info(f"Customer rate plan data receivec to save after getting tenant id {cust_tenant_id}")
        customer_plan_data["tenant_id"]=cust_tenant_id[0]['tenant_id']
        logging.info(f"Customer rate plan data receivec to save after adding tenant id {customer_plan_data}")
        #customer_plan_data["tenant_id"] = 1


        if customer_plan_data["optimization_type"] == "Cross Customer Pooling":
            try:
                customer_plan_data["serviceproviderids"] = ", ".join(
                    map(str, customer_plan_data["service_provider_id"])
                )
                customer_plan_data["service_provider_name"] = ", ".join(
                    customer_plan_data["service_provider_name"]
                )
            except:
                pass

        logging.info(f"type {customer_plan_data.keys()}, {customer_plan_data.keys()}")

        mode=os.getenv('ENV','UAT')
        if mode=='UAT':
            if tenant_name=='Altaworx Test':
                tenant_name='Altaworx'
        try:
            json_data = load_json()
            Telegence_ids = get_provider_ids(json_data, tenant_name, ["Telegence"])
            logging.info(f"Telegence_ids gotten is {Telegence_ids} {tenant_name}")
        except Exception as e:
            logging.error(f"Error loading JSON: {e}")
            json_data = {}  # Fallback to empty dict if JSON fails
            Telegence_ids = []  # Default to empty list

        if "service_provider_id" in customer_plan_data:
            logging.info("customer_plan_data contains service_provider_id (without cross pool check)")
            service_provider_val = customer_plan_data["service_provider_id"]
            logging.info(f"Initial service_provider_val: {service_provider_val}")
            if isinstance(service_provider_val, list):
                logging.info(f"service_provider_val is a list: {service_provider_val}")
                if not service_provider_val:
                    logging.info(f"serviceprovider list gotten empty so returning from the function {service_provider_val}")
                    raise ValueError("service_provider_val is an empty list.")

            else:
                logging.info("service_provider_val is not a list, converting to list")
                service_provider_val = [service_provider_val]
                logging.info(f"Converted service_provider_val: {service_provider_val}")
                # Check if any Telegence ID exists in service_provider_ids_copy
            matching_ids = [id_ for id_ in Telegence_ids if id_ in service_provider_val]
            logging.info(f"Matching Telegence IDs: {matching_ids}")
            #matching_ids = [id_ for id_ in Telegence_ids if id_ in service_provider_val]

            if matching_ids:
                final_val = matching_ids[0]  # Use first matching ID
            else:
                final_val = service_provider_val[0]
            logging.info("service_provider_id gotten finally is ")
            customer_plan_data["service_provider_id"] = int(final_val)
            logging.info(f"Final service_provider_id set in customer_plan_data: {customer_plan_data['service_provider_id']}")


        automation_rules = []
        soc_codes_data=[]
        logging.info(f"final_val gotten is  {final_val},{Telegence_ids} ")
        if int(final_val) in Telegence_ids:
            logging.info("final_val is in Telegence_ids")
            if ("automation_rule" in customer_plan_data and customer_plan_data["automation_rule"] == "[]"):
                customer_plan_data.pop("automation_rule")
            else:
                if not update_flag:
                    # customer_plan_data['automation_rule'] = json.dumps(customer_plan_data['automation_rule'])
                    automation_rules = json.loads(customer_plan_data["automation_rule"])
                else:
                    automation_rules = customer_plan_data["automation_rule"]
                    customer_plan_data.pop("automation_rule")
                    logging.info(
                        "#######automation_rules passing to db to get id", automation_rules
                    )
                automation_rules_final = []
                for automation_rule in automation_rules:
                    automation_rule_id = database.get_data(
                    "automation_rule",
                    {"automation_rule_name": automation_rule},
                    ["id_10"],
                    ).to_dict("records")
                    logging.info("#######automation_rule_id", automation_rule_id)
                    if automation_rule_id:
                        automation_rule_id = automation_rule_id[0]["id_10"]
                        automation_rules_final.append(automation_rule_id)
                logging.info(f"#######automation_rules_final  {automation_rules_final}")
                if automation_rules_final:
                    logging.info(f"#######automation_rules_final_cust {customer_plan_data}")
                    if not update_flag:
                        created_by = customer_plan_data.get("created_by","system")
                        created_date = customer_plan_data.get("created_date")
                        rate_plan_id=customer_plan_data.get("id", "")
                        automation_rules = [
                            {
                                "automation_rule_id": rule,
                                "created_by": created_by,
                                "created_date": created_date,
                                "customer_rate_plan_id":rate_plan_id
                                }
                                for index, rule in enumerate(automation_rules_final)
                            ]
                    else:
                        created_date = customer_plan_data.get("modified_date", "")
                        created_by = customer_plan_data.get("modified_by", "")
                        rate_plan_id=customer_plan_data.get("id", "")
                        automation_rules = [
                        {
                            "automation_rule_id": rule,
                            "created_by": created_by,
                            "created_date": created_date,
                            "customer_rate_plan_id":rate_plan_id
                        }
                        for index, rule in enumerate(automation_rules_final)
                    ]
            try:
                rate_plan_code = customer_plan_data["soc_code"].split('-')[0].strip()
                logging.info(f"rate_plan_code in run_db_script is {rate_plan_code}")
                if rate_plan_code is not None:
                    soc_code_id = database.get_data(
                        "carrier_rate_plan", {"rate_plan_code": rate_plan_code}, ["id_10"]
                    ).to_dict("records")[0]["id_10"]
                else:
                    soc_code_id = None
                if soc_code_id:
                    if not update_flag:
                        created_by = customer_plan_data.get("created_by","system")
                        created_date = customer_plan_data.get("created_date")
                        rate_plan_id=customer_plan_data.get("id", "")
                        jasper_carrier_rate_plan_id=soc_code_id
                        soc_codes_data = [
                        {
                            "jasper_carrier_rate_plan_id": jasper_carrier_rate_plan_id,
                            "created_by": created_by,
                            "created_date": created_date,
                            "customer_rate_plan_id":rate_plan_id,
                            "is_active":True
                        }]
                    else:
                        created_date = customer_plan_data.get("modified_date", "")
                        created_by = customer_plan_data.get("modified_by", "")
                        rate_plan_id=customer_plan_data.get("id", "")
                        jasper_carrier_rate_plan_id=soc_code_id
                        soc_codes_data = [
                        {
                            "jasper_carrier_rate_plan_id": jasper_carrier_rate_plan_id,
                            "created_by": created_by,
                            "created_date": created_date,
                            "customer_rate_plan_id":rate_plan_id,
                            "is_active":True
                        }]
                    logging.info(f"soc codes data gotten is {soc_codes_data}")


            except Exception as e:
                logging.info(f"while loading soc codes {e}")
        else:
            logging.info("final_val is not in Telegence_ids")
            if "automation_rule" in customer_plan_data:
                customer_plan_data.pop("automation_rule")


        data_sent={}
        transfer_name = f"customer_rate_plan_{tenant_name_lcase}"
        try:
            data_transfer = DataTransfer()
            logging.info(f"Update flag is {update_flag},{delete_flag}")
            temp_data = {}

            if int(final_val) in Telegence_ids and automation_rules:
                try:
                    logging.info("making automation rules is active false")
                    update_data = database.update_dict(
                    "automation_rule_customer_rate_plan",
                    {"is_active": False},
                    {"customer_rate_plan_id":cust_rate_plan_id },
                    )
                    temp_data["automation_rule"] = automation_rules
                    logging.info(
                        f"#######automation_rules added to data_sent  {automation_rules}, data_sent id {temp_data}" )
                except Exception as e:
                    logging.info(f"while making automation rules is active false {e}")

            if int(final_val) in Telegence_ids and soc_codes_data:
                temp_data["customer_rate_plan_jasper_carrier_rate_plan"]=soc_codes_data
                logging.info(f"#######soc codes are  added to data_sent {soc_codes_data}")
                try:
                    logging.info("inserting soc codes into customerrateplan jasper carrier rate plan table")
                    insert_data = database.insert_dict(
                         soc_codes_data[0],
                    "customer_rate_plan_jasper_carrier_rate_plan"

                    )
                except Exception as e:
                    logging.info(f"An Error occured while inserting the soc codes ")
            else:
                logging.info(f"#######automation_rules are not  added to data_sent {automation_rules}")

            # Always build customerrateplan first
            customerrateplan_value = (
                customer_plan_data if isinstance(customer_plan_data, list) else [customer_plan_data]
            )
            # Combine dictionaries with desired key order
            data_sent = {
                "customerrateplan": customerrateplan_value,
                **temp_data
            }
            logging.info(f"data before calling save_data_to_10: {data_sent}")
            if update_flag is False and delete_flag is False:
                bulk_change_id_10 = data_transfer.save_data_to_10(
                    transfer_name, data_sent, False, False, tenant_name
                )
            elif update_flag is True:
                logging.info(f"In Update")
                logging.info(
                    f"data before caling in update true-------------{data_sent}"
                )
                bulk_change_id_10 = data_transfer.save_data_to_10(
                    transfer_name, data_sent, update_flag, delete_flag=False, tenant_name = tenant_name
                )
            elif delete_flag is True:
                logging.info(f"DELETE FLAG {delete_flag}")
                logging.info(f"data before caling-------------{data_sent}")
                bulk_change_id_10 = data_transfer.save_data_to_10(
                    transfer_name, data_sent, update_flag=False, delete_flag=True, tenant_name=tenant_name
                )
            else:

                logging.info(f"data before caling in else-------------{data_sent}")
                bulk_change_id_10 = data_transfer.save_data_to_10(
                    transfer_name, data_sent, tenant_name=tenant_name
                )

            response = {
                "flag": True,
                "message": "customer rate plans called  successfully",
            }
        except Exception as e:
            # Log an exception if an error occurs during data transfer (step 1)
            logging.exception(f"Error occurred while calling Data Transfer: {e}")
            response = {"flag": False, "message": "customer rate plans lambda call failed"}
        return response

        """
        customer_rate_plan_id = data.get("customer_rate_plan")
        # logging.info(customer_rate_plan_id, "Customer Rate Plan ID")

        # Get the customer rate plan data
        customer_rate_plan_result = database.get_data(
            'customerrateplan',
            {"id": customer_rate_plan_id},  # Filter condition
            {}  # Fields to retrieve
        )

        # Add the fetched data to the 'data' dictionary
        data['customer_rate_plan'] = customer_rate_plan_result.to_dict('records')"""

    # else:
    if not_bulk_change is False:
        # Execute the block if module_name is not 'Customer Rate Plan'
        bulk_chnage_id_20 = data_all["bulk_chnage_id_20"]
        logging.info(f"bulk_chnage_id_20  is {bulk_chnage_id_20}")
        #tenant_name=data_all["tenant_name"]
        bulk_change_id = bulk_chnage_id_20
        logging.info(f"bulk_change_id  is {bulk_change_id}")
        # service_provider_id_kore = data.get("service_provider_id", None)
        service_provider_id_kore = data_all.get("service_provider_id", None)
        ver_inventory_flag=data_all.get("verizon_inventory_flag",None)
        mode=os.getenv('ENV')
        if mode=='UAT':
            if tenant_name=='Altaworx Test':
                tenant_name='Altaworx'
        json_data = load_json()
        koreids=get_provider_ids(json_data, tenant_name, ["Koremain"])
        webbingids=get_provider_ids(json_data, tenant_name, ["Webbingmain"])
        if service_provider_id_kore in koreids:
            logging.info(f"##################### Kore Service Provider")
            bulk_change_id_ = database.get_data(
                "sim_management_bulk_change_request",
                {"bulk_change_id": bulk_change_id},  # Filter condition
                [
                    "iccid",
                    "subscriber_number",
                    "m2m_id",
                    "bulk_change_id",
                    "tenant_name",
                    "created_by",
                    "processed_by",
                    "status",
                    "device_id",
                    "is_active",
                    "is_deleted",
                    "change_request",
                ],  # Fields to retrieve
            ).to_dict("records")

            # Convert the result to a dictionary if it's valid
            data["sim_management_bulk_change_request"] = bulk_change_id_

            logging.info(f"Data received for save_data_to_10 kore: {data}")

            # Get data from the database using the bulk_change_id
            bulk_change_id_ = database.get_data(
                "sim_management_bulk_change_request",
                {"bulk_change_id": bulk_change_id},  # Filter condition
                [
                    "iccid",
                    "subscriber_number",
                    "m2m_id",
                    "bulk_change_id",
                    "tenant_name",
                    "created_by",
                    "processed_by",
                    "status",
                    "device_id",
                    "is_active",
                    "is_deleted",
                    "change_request",
                ],  # Fields to retrieve
            ).to_dict("records")

            data["sim_management_bulk_change_request"] = bulk_change_id_

            logging.info(f"Data received for save_data_to_10: {data}")

            try:
                # Create an instance of DataTransfer class to handle data operations
                data_transfer = DataTransfer()
                update_data = database.update_dict(
                    "sim_management_bulk_change",
                    {"progress": 'Sync In Progress'},
                    {"id": bulk_chnage_id_20},
                )


                # Save data to 'bulk_change' table in the database (step 1)
                bulk_change_id_10 = data_transfer.save_data_to_10("bulk_change", data, tenant_name=tenant_name)
                logging.info(f"Bulk Change 1.0 got is {bulk_change_id_10}")
                logging.info(f"Updating sim_management_bulk change with above id")
                update_data = database.update_dict(
                    "sim_management_bulk_change",
                    {"bulk_change_id_10": bulk_change_id_10},
                    {"id": bulk_chnage_id_20},
                )
                logging.info(
                    f"{bulk_change_id_10} updated in sim_management_bulk_change for 2.0 is {bulk_chnage_id_20}"
                )
                response = {
                    "flag": True,
                    "message": "Bulk change called successfully for kore",
                }
                return response

            except Exception as e:
                # Log an exception if an error occurs during data transfer (step 1)
                logging.exception(f"Error occurred while calling Data Transfer: {e}")
                response = {"flag": False, "message": "Bulk change lambda call failed"}
                return response

        elif service_provider_id_kore in webbingids:
            logging.info(f"##################### Webbing Service Provider")
            bulk_change_id_ = database.get_data(
                "sim_management_bulk_change_request",
                {"bulk_change_id": bulk_change_id},  # Filter condition
                [
                    "iccid",
                    "subscriber_number",
                    "m2m_id",
                    "bulk_change_id",
                    "tenant_name",
                    "created_by",
                    "processed_by",
                    "status",
                    "device_id",
                    "is_active",
                    "is_deleted",
                    "change_request",
                ],  # Fields to retrieve
            ).to_dict("records")

            # Convert the result to a dictionary if it's valid
            data["sim_management_bulk_change_request"] = bulk_change_id_

            logging.info(f"Data received for save_data_to_10 webbing: {data}")

            # Get data from the database using the bulk_change_id
            bulk_change_id_ = database.get_data(
                "sim_management_bulk_change_request",
                {"bulk_change_id": bulk_change_id},  # Filter condition
                [
                    "iccid",
                    "subscriber_number",
                    "m2m_id",
                    "bulk_change_id",
                    "tenant_name",
                    "created_by",
                    "processed_by",
                    "status",
                    "device_id",
                    "is_active",
                    "is_deleted",
                    "change_request",
                ],  # Fields to retrieve
            ).to_dict("records")

            data["sim_management_bulk_change_request"] = bulk_change_id_

            logging.info(f"Data received for save_data_to_10 webbing: {data}")

            try:
                # Create an instance of DataTransfer class to handle data operations
                data_transfer = DataTransfer()
                update_data = database.update_dict(
                    "sim_management_bulk_change",
                    {"progress": 'Sync In Progress'},
                    {"id": bulk_chnage_id_20},
                )


                # Save data to 'bulk_change' table in the database (step 1)
                bulk_change_id_10 = data_transfer.save_data_to_10("bulk_change", data, tenant_name=tenant_name)
                logging.info(f"Bulk Change 1.0 got is {bulk_change_id_10}")
                logging.info(f"Updating sim_management_bulk change with above id")
                update_data = database.update_dict(
                    "sim_management_bulk_change",
                    {"bulk_change_id_10": bulk_change_id_10},
                    {"id": bulk_chnage_id_20},
                )
                logging.info(
                    f"{bulk_change_id_10} updated in sim_management_bulk_change for 2.0 is {bulk_chnage_id_20}"
                )
                response = {
                    "flag": True,
                    "message": "Bulk change called successfully for webbing",
                }
                return response

            except Exception as e:
                # Log an exception if an error occurs during data transfer (step 1)
                logging.exception(f"Error occurred while calling Data Transfer: {e}")
                response = {"flag": False, "message": "Bulk change lambda call failed"}
                return response

        else:
            # Get data from the database using the bulk_change_id
            logging.info(f"getting request data for {bulk_change_id}")
            bulk_change_id_ = database.get_data(
                "sim_management_bulk_change_request",
                {"bulk_change_id": bulk_change_id},  # Filter condition
                [
                    "iccid",
                    "subscriber_number",
                    "m2m_id",
                    "bulk_change_id",
                    "tenant_name",
                    "created_by",
                    "processed_by",
                    "status",
                    "device_id",
                    "is_active",
                    "is_deleted",
                    "change_request",
                    "id",
                    "device_change_request_id"
                ],  # Fields to retrieve
            ).to_dict("records")

            data["sim_management_bulk_change_request"] = bulk_change_id_
            logging.info(f"bulk_change request data gotten  is {bulk_change_id_}")

            # Convert the result to a dictionary if it's valid



            logging.info(f"Data received for save_data_to_10: {data}")

            try:
                # Create an instance of DataTransfer class to handle data operations
                data_transfer = DataTransfer()
                update_data = database.update_dict(
                    "sim_management_bulk_change",
                    {"progress": 'Sync In Progress'},
                    {"id": bulk_chnage_id_20},
                )



                # Save data to 'bulk_change' table in the database (step 1)
                # bulk_change_id_10 = data_transfer.save_data_to_10("bulk_change", data, tenant_name=tenant_name)
                if len(bulk_change_id_)>2000:
                    logging.info(f"1111 Len of requestdata is {len(bulk_change_id_)}")
                    logging.info(f"Calling bulk_save_data_to_10")
                    smi_bulk_change=data['sim_management_bulk_change'][0]
                    smi_bulk_change['id']=bulk_change_id
                    data['sim_management_bulk_change']=[smi_bulk_change]
                    logging.info(f"CHECKPOINT2")
                    logging.info(f"data modified is {data['sim_management_bulk_change'][0]}")
                    logging.info(f"ChECKPoint 3")
                    bulk_change_id_10=data_transfer.bulk_save_data_to_10("bulk_change", data, tenant_name=tenant_name)
                else:
                    bulk_change_id_10 = data_transfer.save_data_to_10("bulk_change", data, tenant_name=tenant_name)
                logging.info(f"Bulk Change 1.0 got is {bulk_change_id_10}")
                logging.info(f"Updating sim_management_bulk change with above id")
                update_data = database.update_dict(
                    "sim_management_bulk_change",
                    {"bulk_change_id_10": bulk_change_id_10},
                    {"id": bulk_chnage_id_20},
                )
                logging.info(
                    f"{bulk_change_id_10} updated in sim_management_bulk_change for 2.0 is {bulk_chnage_id_20}"
                )

            except Exception as e:
                # Log an exception if an error occurs during data transfer (step 1)
                logging.exception(f"Error occurred while calling Data Transfer: {e}")

            try:
                # Initialize an empty list for bulk change ID
                bulk_change_id = []

                # Call the Lambda function to handle further processing (step 2)
                bulk_change_id_10=str(bulk_change_id_10)
                bulk_change_lambda_caller(tenant_name,bulk_change_id_10)
            except Exception as e:
                # Log warning and return failure if the Lambda invocation fails
                logging.warning(f"An error occurred while calling Lambda: {e}")
                error_msg = f"An error occurred while calling Lambda: {e}"
                database.update_dict(
                    "sim_management_bulk_change",
                    {
                        "bulk_change_id_10": bulk_change_id_10,
                        "progress": "Error in Sync",
                        "error_msg": error_msg,
                    },
                    {"id": bulk_chnage_id_20},
                )

                return False

            try:
                # Log the successful invocation of the Lambda function
                logging.info(f"After lambda calling")

                # Save additional data from step 10 to step 20 in the database (step 3)
                # get_data_From_10 = data_transfer.save_data_20_from_10(
                #     bulk_change_id_10, bulk_chnage_id_20, "bulk_change",data
                # )
                try:
                    customer_data=database.get_data(
                                "sim_management_bulk_change",
                                {"id": bulk_chnage_id_20},
                                [
                                    "change_request_type",
                                    "customer_id",
                                    "customer_name"
                                ]
                            ).to_dict("records")
                    logging.info(f"customer data gotten is {customer_data} {bulk_chnage_id_20}")
                    if customer_data:
                        logging.info(f"customer data is {customer_data}")
                        try:
                            change_request_type=customer_data[0].get("change_request_type",None)
                            customer_id=customer_data[0].get("customer_id",None)
                            customer_name=customer_data[0].get("customer_name",None)
                            if customer_id and customer_name and change_request_type.lower()=='activate new service':
                                logging.info(f"customer_id and customer_name are not null")
                                active_new_service_api_flag=True
                        except Exception as e:
                            logging.info(f"An error occurred while getting customer data {e}")
                            active_new_service_api_flag=False

                    logging.info(f"sub tenat id passing is {sub_tenant_id} ,{parent_tenant_id}")
                    if len(bulk_change_id_)>2000:
                        get_data_From_10=data_transfer.save_data_20_from_10_bulk_update(
                            bulk_change_id_10,
                            bulk_chnage_id_20,
                            "bulk_change",
                            data,
                            data_all,
                            False,
                            tenant_name,
                            service_provider_id_kore,
                            ver_inventory_flag,
                            parent_tenant_id,
                            sub_tenant_id
                        )
                    else:
                        get_data_From_10 = data_transfer.save_data_20_from_10(
                            bulk_change_id_10,
                            bulk_chnage_id_20,
                            "bulk_change",
                            data,
                            data_all,
                            False,
                            tenant_name,
                            ver_inventory_flag,
                            parent_tenant_id,
                            sub_tenant_id,
                            access_token,
                            active_new_service_api_flag,
                            role_name,
                            api_call_flag
                        )

                    # if active_new_service_api_flag:
                    #     logging.info(f"Need to call API for active new service")
                    #     call_api=activate_new_service_caller(bulk_chnage_id_20,tenant_database,access_token)

                    '''get_data_From_10=data_transfer.save_data_20_from_10_bulk_update(
                       bulk_change_id_10,
                        bulk_chnage_id_20,
                        "bulk_change",
                        data,
                        data_all,
                        False,
                        tenant_name,
                        service_provider_id_kore

                    )'''
                    if get_data_From_10:
                        database.update_dict(
                            "sim_management_bulk_change",
                            {"progress": "Sync Complete"},
                            {"id": bulk_chnage_id_20},
                        )
                    else:
                        database.update_dict(
                            "sim_management_bulk_change",
                            {"progress": "Sync Error"},
                            {"id": bulk_chnage_id_20},
                        )
                    


                    change_request = database.get_data("sim_management_bulk_change",{"id":bulk_chnage_id_20},["change_request_type"]).to_dict("records")
                    try:
                        logging.info(f"change request gotten is {change_request},{bulk_chnage_id_20},{type(change_request)}")
                        change_request = change_request[0].get("change_request_type")
                        logging.info(f"change request gotten is {change_request}")

                    except Exception as e:
                        tb = traceback.format_exc()
                        change_request=None
                        logging.info(f"An error occurred while getting change request type is uncompatible {e} {tb}")
                        pass
                    if change_request=="Edit Username/Cost Center" or change_request=="Update Device Status":
                        logging.info(f"change request gotten is {change_request}")
                        data_transfer.cross_provider_sync(tenant_name,bulk_chnage_id_20,parent_tenant_id,postgres_data)
                    else:
                        logging.info(f"No need to call cross provider sync {change_request}")




                    if change_request == "Assign Customer" or change_request =="Create Rev Service":
                        logging.info(f"Processing Assign Customer request  {bulk_chnage_id_20}")
                        try:
                            api_url = os.getenv("OPTIMIZATIONSYNCURL", None)
                        except:
                            logging.error(f"failed to load url from env")
                            #api_url='https://8x5f1gkyk7.execute-api.us-east-1.amazonaws.com/uat/optimization_sync_lambda_uat'
                        logging.info(f"URL to hit the API is {api_url}")
                        api_payload = {
                                        "data": {
                                            "path": "/lambda_sync_jobs_",
                                            "key_name": "rev_service_line_sync",
                                            "tenant_name": tenant_name
                                                }
                                        }
                        try:
                            if api_url:
                                time.sleep(75)
                                response = requests.post(api_url, json=api_payload)
                                if response.status_code in  (200,504):
                            # Get the current timestamp
                                    #current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                            # Log the message with the timestamp
                                    logging.info(
                                        f"API call successful.rev tables  Data sync call is successfully done at {bulk_chnage_id_20}"
                                    )
                                    try:
                                        logging.info("Updating the rev_service_false table")
                                        rev_iccids=database.get_data("sim_management_bulk_change_request",{"bulk_change_id": bulk_chnage_id_20},["iccid"]).to_dict("records")
                                        iccid_list = [entry["iccid"] for entry in rev_iccids]
                                        logging.info(f"iccid gotten is {bulk_chnage_id_20}")

                                        if iccid_list:
                                            iccid_json = {"iccid": iccid_list}
                                            logging.info(f"### To delete in rev search: {iccid_json}")
                                            iccid_json_str = json.dumps(iccid_json)
                                            database.update_dict(
                                                "rev_service_false",
                                                {"rev_service_ids": iccid_json_str},
                                                {"id": 1},
                                            )
                                            logging.info(f"rev_service false table updated successfully successfully with the ICCID list.{iccid_json_str}")
                                    except Exception as e:
                                        logging.info(f"An error occurred while updating rev_service_false table: {e}")
                                        database.update_dict(
                                                "rev_service_false",
                                                {"error_msg": f"{e}"},
                                                {"id": 1},
                                            )
                            # logging.info("API call successful.Data synn call is succssefully done ")
                                else:
                                    logging.error(
                                    f"API call failed with statudafdfadsfs code: {response.status_code}"
                                    )
                        except Exception as e:
                            logging.error(f"An Error in syncing the rev details tables data for assign customer {e}")

                except Exception as e:
                    tb = traceback.format_exc()
                    logging.error(f"Error Occurred while syncing data from 1.0 {e}")
                    error_msg = f"Error Occurred while syncing data from 1.0 {e} {tb}"
                    database.update_dict(
                        "sim_management_bulk_change",
                        {"progress": "Error in Sync", "error_msg": error_msg},
                        {"id": bulk_chnage_id_20},
                    )

                """
                Updating the tables for errors and success messages
                """
                # bulk_change_status = database.get_data('sim_management_bulk_change_request', {"bulk_change_id": bulk_change_id}, ["status"])["status"].to_list()
                # Query to fetch the data
                bulk_change_status_query = f"""
                SELECT is_processed, has_errors
                FROM sim_management_bulk_change_request
                WHERE bulk_change_id = {bulk_chnage_id_20}
                """

                # Fetch the data
                bulk_change_data = database.execute_query(
                    bulk_change_status_query, True
                )

                # Initialize counters
                error_count = 0
                processed_count = 0

                # Iterate through each row to count statuses
                for row in bulk_change_data.itertuples(
                    index=False
                ):  # Use itertuples if using a pandas DataFrame
                    if row.is_processed:
                        processed_count += 1
                    if row.has_errors:
                        error_count += 1

                if error_count > 0:
                    database.update_dict(
                        "sim_management_bulk_change_request",
                        {"errors": error_count},
                        {"bulk_change_id": bulk_chnage_id_20},
                    )
                    database.update_dict(
                        "sim_management_bulk_change",
                        {"errors": error_count},
                        {"id": bulk_chnage_id_20},
                    )

                if processed_count > 0:
                    database.update_dict(
                        "sim_management_bulk_change_request",
                        {"sucess": processed_count},
                        {"bulk_change_id": bulk_chnage_id_20},
                    )
                    database.update_dict(
                        "sim_management_bulk_change",
                        {"success": processed_count},
                        {"id": bulk_chnage_id_20},
                    )

                # Return a success response indicating the bulk change process was successful
                response = {
                    "flag": True,
                    "message": "Bulk change lambda called successfully",
                }
                audit_data_user_actions = {
                    "service_name": "Sim Management",
                    "created_date": data.get("request_received_at"),
                    "created_by": data.get("username", ""),
                    "status": str(response["flag"]),
                    "session_id": data.get("session_id", ""),
                    "tenant_name": data.get("tenant_name", ""),
                    "comments": "inventory iccids and imeids",
                    "module_name": "run_db_script",
                    "request_received_at": data.get("request_received_at"),
                }
                database.update_audit(audit_data_user_actions, "audit_user_actions")
                return response
            except Exception as e:
                # Log an exception if the data transfer to step 20 fails
                logging.exception(f"Error in Data Transfer save_data_20_from_10: {e}")
                error_type = type(e).__name__
                try:
                    error_data = {
                        "service_name": "Sim Management",
                        "created_date": data.get("request_received_at"),
                        "error_message": str(e),
                        "error_type": error_type,
                        "users": data.get("username", ""),
                        "session_id": data.get("session_id", ""),
                        "tenant_name": tenant_database,
                        "comments": "",
                        "module_name": "run_db_script",
                        "request_received_at": data.get("request_received_at"),
                    }
                    database.log_error_to_db(error_data, "error_log_table")
                except Exception as logging_error:
                    logging.error(f"Failed to log error to database: {logging_error}")

                # Return a failure response indicating the bulk change process failed
                response = {"flag": False, "message": "Bulk change lambda call failed"}
                return response

def activate_new_service_caller(bulk_change_id_20,tenant_database,access_token,tenant_name,role_name,api_call_flag):
    try:
        logging.info(f"activate_new_service_caller is called with {bulk_change_id_20}")
        logging.info(f"activate_new_service_caller is called with tenant_database {tenant_database} access token {access_token}")
        database = DB(tenant_database, **db_config)
        # common_utils_db=os.getenv("COMMON_UTILS_DATABASE")
        request_data={}
        changed_data={}
        bulk_assign_request_data={}
        # db_data=database.get_data("sim_management_bulk_change",{"id":bulk_change_id_20},
        #                         ["service_provider",
        #                          "processed_date",
        #                         "customer_id",
        #                         "customer_name",
        #                             "created_by"],).to_dict("records")
        db_data_query=f'''select service_provider,processed_date,customer_id,customer_name,created_by from sim_management_bulk_change
                            where id={bulk_change_id_20}'''
        db_data=database.execute_query(db_data_query,True).to_dict("records")

        logging.info(f"{bulk_change_id_20} db data {db_data}")
        if db_data:
            service_provider=db_data[0].get("service_provider")
            effective_date=db_data[0].get("processed_date")
            customer_id=db_data[0].get("customer_id")
            request_data["service_provider"]=service_provider
            created_by=db_data[0].get("created_by")
            customer_name=db_data[0].get("customer_name")
            bulk_assign_request_data['service_provider']=service_provider
            bulk_assign_request_data['customer_id']=customer_id
            bulk_assign_request_data['customer_name']=customer_name
            bulk_assign_request_data['created_by']=created_by
            logging.info(f"bulk_assign_request_data here is {bulk_change_id_20} {bulk_assign_request_data}")

            # if effective_date is not None:
            #     if isinstance(effective_date, datetime):
            #         effective_date = effective_date.strftime('%Y-%m-%d %H:%M:%S')
            #         changed_data["EffectiveDate"] = effective_date
            changed_data["RevCustomerId"]=str(customer_id)
        db_data_request=database.get_data("sim_management_bulk_change_request",{"bulk_change_id":bulk_change_id_20},
                                        ["iccid",],).to_dict("records")
        if db_data_request:
            iccid_list=[i.get("iccid") for i in db_data_request]
            changed_data["Iccids"]=iccid_list
            bulk_assign_request_data['iccids']=iccid_list
            logging.info(f"bulk_assign_request_data here is2 {bulk_change_id_20} {bulk_assign_request_data}")
        '''
        This function is used to call the assign customer logic via a api flag if True api call will be done or else
        a function will be called
        '''
        if api_call_flag:
            ##this will call bulk assign customer API
            logging.info(f"API call flag is true {bulk_change_id_20}")
            logging.info(f"changed data got is {changed_data}")
            request_data["changed_data"] = changed_data
            request_data["z_access_token"] = access_token
            request_data["tenant_name"] = tenant_name
            request_data["role_name"] = role_name
            request_data['sync_call_activation']=True
            logging.info(f"final request data got is for bulk_change_id {bulk_change_id_20} {request_data}")
            logging.info(f"Access token for bulk_change_id is {bulk_change_id_20} {access_token}")

            # time.sleep(160)

            #call_api_fn = bulk_assign_customer(request_data)
            load_dotenv()
            api_url = os.getenv("BULK_ASSIGN_CUSTOMER_QUEUE_URL")
            sync_response = requests.post(api_url, json=request_data)
            logging.info(f"call_api_fn response is {bulk_change_id_20} {sync_response}")
        else:
            ##this will call bulk assign customer without z access token function
            logging.info(f"API call flag is false {bulk_change_id_20}")
            logging.info(f"request data sent is {bulk_change_id_20} {tenant_name} {bulk_assign_request_data}")
            fn_call=bulk_assign_customer_without_zaccesstoken(bulk_change_id_20,tenant_database,access_token,tenant_name,role_name,bulk_assign_request_data)


    except Exception as e:
        logging.error(f"Error in activate_new_service_caller:{bulk_change_id_20} {e}")
        pass


def bulk_assign_customer_without_zaccesstoken(bulk_change_id_20,tenant_database,access_token,tenant_name,
                                              role_name,bulk_assign_request_data):
    """
    This function is a placeholder for the bulk_assign_customer_without_z_accesstoken from run db script
    """
    try:
        logging.info(f"bulk_assign_customer_without_zaccesstoken is called with {bulk_change_id_20} {bulk_assign_request_data} type {type(bulk_assign_request_data)}")
        service_provider=bulk_assign_request_data.get("service_provider")
        logging.info(f"Service provider got is {bulk_change_id_20} {service_provider}")
        created_by=bulk_assign_request_data.get("created_by")
        iccid_list=bulk_assign_request_data.get("iccids")
        logging.info(f"iccid list is {iccid_list}")
        customer_name=bulk_assign_request_data.get("customer_name")
        customer_id=bulk_assign_request_data.get("customer_id")
        common_utils_db=DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        request_data={}
        changed_data={}
        logging.info(f"API call flag is false {bulk_change_id_20}")
        request_data['tenant_name']=tenant_name
        request_data["path"]="/update_bulk_change_data"
        request_data["role_name"] = role_name
        # try:
        #     request_data["request_received_at"]=datetime.datetime.now()
        # except Exception as e:
        request_data["request_received_at"]=None
        request_data["access_token"] = access_token
        request_data["db_name"]=tenant_database
        request_data["sessionID"]=None
        logging.info(f"adding service provider {service_provider}")
        request_data["service_provider"]=service_provider

        request_data["change_type"]="Assign Customer"
        request_data["created_by"]=created_by
        request_data["iccids"]=iccid_list
        changed_data["Number"]=""
        changed_data["ICCID"]=""
        changed_data["CreateRevService"]=False
        changed_data["IntegrationAuthenticationId"]=""
        changed_data["AddCarrierRatePlan"]=False
        changed_data["CarrierRatePlan"]=None
        changed_data["CommPlan"]=""
        changed_data["UseAgentAccount"]=False
        changed_data["JasperDeviceID"]=""
        changed_data["SiteId"]=None
        changed_data["AddCustomerRatePlan"]=False
        changed_data["CustomerRatePlan"]=None
        changed_data["CustomerRatePool"]=None
        changed_data["DeviceId"]=None
        changed_data["RevCustomerId"]=f'{customer_name} -- {customer_id}'
        changed_data["ProviderId"]=""
        changed_data["ServiceTypeId"]=""
        changed_data["RevProductId"]=[]
        changed_data["RevPackageId"]=""
        changed_data["RateList"]=[]
        changed_data["Prorate"]=False
        changed_data["useCarrierActivation"]=False
        changed_data["Description"]=""
        changed_data["EffectiveDate"]=None
        changed_data["ActivatedDate"]=None
        changed_data["UsagePlanGroupId"]=None
        request_data["changed_data"]=changed_data
        # request_data=json.dumps(request_data)
        logging.info(f"final request data got is {bulk_change_id_20} {request_data}")

        try:
            try:
                '''
                This code is used to call the run db script using API Call so that the sync will be called
                '''
                sync_url = os.environ["KORE_10_BULKCHANGE_SYNC"]
                api_payload = {"data": request_data}
                logging.info(f"request data here is {request_data}")
                logging.info(f"BULK Change Sync API Payload is :{api_payload}")

                sync_response = requests.post(sync_url, json=api_payload)
                sync_response_json = sync_response.json()
                # Parse the inner body string (if needed)
                body = sync_response_json.get("body")
                if isinstance(body, str):
                    sync_response_json = json.loads(body)
                else:
                    sync_response_json = body  # if it's already a dict

                logging.info(f"BULK Change Sync API response: {sync_response_json}")

                if sync_response.status_code in (200, 504):
                    current_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    logging.info(f" Update bulk Change data API call successful. Data sync completed at {current_timestamp}")
                else:
                    logging.error(f"Update bulk Change data API sync call failed with status code: {sync_response.status_code} and sync message is: {sync_response.text}")

                # Extract bulk_change_id
                bulk_change_id = sync_response_json.get("bulkchange_id", {}).get("id")
                request_data=sync_response_json.get('data')
            except Exception as sync_exception:
                logging.error(f"run_db_script Error occurred while calling the sync API: {sync_exception}")
                bulk_change_id = None  # fallback
                request_data={}
            if bulk_change_id is None:
                fn_call=True
                print("bulk_change_id not found in response.This is some issue in the update bulk change data")
            else:
                fn_call=True
                print(f"bulk_change_id: {bulk_change_id}")
            logging.info(f"update_bulk_change_data response is {bulk_change_id_20} and bulk change if for assign customer is {bulk_change_id}")
            logging.info(f"return dict is {bulk_change_id}")
        except Exception as e:
            logging.error(f"Error in update_bulk_change_data: {e}")

        # role_module_data = common_utils_db.get_data(
        #                             "role_module",
        #                             {"role": role_name},
        #                             ["sub_module"],
        #                         )
        print('role_name isssssssssssss:::',role_name)
        role_module_data_query=f'''select sub_module from role_module where role='{role_name}'
            '''
        role_module_data=common_utils_db.execute_query(role_module_data_query,True)

             # Initialize default status
        module_status = False
        logging.info(f"role_module_data {role_module_data}")

        if not role_module_data.empty:
            try:
                # Parse JSON safely with fallback
                sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')
                logging.info(f"sub_modules is {sub_modules}")

                # Strict nested check
                if "People" in sub_modules:
                    people_modules = sub_modules["People"]
                    if isinstance(people_modules, list):  # Ensure it's a list
                        module_status = "Rev.IO Customers" in people_modules

            except json.JSONDecodeError:
                logging.error(f"Invalid JSON in sub_module for role: {role_name}")
            except KeyError:
                pass  # People section not present
            except Exception as e:
                logging.error(f"Unexpected error processing modules: {str(e)}")

        logging.info(f"module_status is {bulk_change_id_20} {module_status} and fn call is {fn_call}")
        if module_status and fn_call:

            logging.info(f"Module status is true for {bulk_change_id_20} and bulk change id for assign customer is {bulk_change_id}")
            data = {
                "tenant_name": tenant_name,
                "path": "/run_db_script",
                "module_name": "Bulk Change",
                "mod_pages": {"start": 0, "end": 100},
                "access_token": access_token,
                "db_name": tenant_database,
                "Partner": tenant_name,
                "bulkchange_id": bulk_change_id,
                "data": request_data,
                "bulk_chnage_id_20": bulk_change_id,
            }
            try:
                '''
                This code is used to call the run db script using API Call so that the sync will be called
                '''
                ##sync url for rundbscript
                sync_url = os.environ["KORE_10_BULKCHANGE_SYNC"]
                api_payload = {"data":data}
                logging.info(f"API Payload is :{api_payload}")
                sync_response = requests.post(sync_url, json=api_payload)
                logging.info(f"Sync API response: {sync_response.json()}")
                if sync_response.status_code in  (200,504):
                    current_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    logging.info(f" run_db_script API call successful. Data sync completed at {current_timestamp}")
                else:
                    logging.error(f"run_db_script API sync call failed with status code: {sync_response.status_code} and sync message is:{sync_response.text} ")
            except Exception as sync_exception:
                logging.error(f"run_db_script Error occurred while calling the sync API: {sync_exception}")
            #run_db_script(data)

        elif not module_status:
            logging.info(f"Module status is false for {bulk_change_id_20},")
            try:
                logging.info(f"Calling lambda function for sync {bulk_change_id_20}")
                lambda_client = boto3.client('lambda')
                data_sync = {
                    "data": {
                        "data": {
                            "key_name": "verizon_inventory",
                            "path": "/lambda_sync_jobs_",
                            "tenant_name": tenant_name
                        }
                    }
                }

                try:
                    response_sync = lambda_client.invoke(
                        FunctionName='optimization_sync_lambda',
                        InvocationType='Event',
                        Payload=json.dumps(data_sync),
                    )
                    logging.info(f"Lambda async invoke response (delayed) :{bulk_change_id_20} {response_sync}")
                except Exception as e:
                    logging.exception(f"Error in child process calling sync lambda:{bulk_change_id_20} {e}")
                    logging.info(f"Error in child process calling sync lambda:{bulk_change_id_20} {e}")


            except Exception as e:
                    logging.info(f"Error: while calling {bulk_change_id_20} {e}")


    except Exception as e:
            logging.info(f"Error in bulk_assign_customer_without_zaccesstoken: {bulk_change_id_20} {e}")


def bulk_assign_customer(data):
    logging.info(f"postman  payload {data}")
    service_provider = data.get("service_provider", None)
    z_access_token = data.get("z_access_token", "")
    changed_data = data.get("changed_data", "")
    tenant_name = data.get("tenant_name", None)
    role_name = data.get("role_name", None)
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        tenant_name = 'Altaworx Test'
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    if service_provider not in [
        "AT&T - Cisco Jasper",
        "AT&T - POD19",
        "AT&T - Telegence - UAT ONLY",
        "AT&T - Telegence",
        "POND IoT",
        "Rogers Sandbox",
        "T-Mobile - Advantage",
        "T-Mobile Jasper",
        "Teal",
        "Verizon - ThingSpace IoT",
        "Verizon - ThingSpace PN",
    ]:
        return {
            "message": "Permission denied: This action is not enabled for the selected service provider.",
            "status_code": 400,
        }

    data["change_type"] = "Assign Customer"

    rev_customer_id = changed_data.get("RevCustomerId", "")
    if z_access_token and not tenant_name:
        client_id = data.get("client_id", "")
        if not client_id:
            return {"flag": False, "message": "Client ID is required with z_access_token"}

        # common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        service_data = common_utils_database.get_data(
            "service_accounts", {"client_id": client_id}
        )

        if service_data.empty:
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        role_name = service_data["role"].to_list()[0]
    else:
        tenant_name = tenant_name or data.get("tenant_name", None)
        role_name = role_name or data.get("role_name", None)
    logging.info(f"tenant name in bulk assign customer is {tenant_name}")
    data['tenant_name'] = tenant_name

    tenant_data = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}
    )

    if tenant_data.empty:
        return {"flag": False, "message": "Invalid tenant name"}

    db_name = tenant_data["db_name"].to_list()[0]

    tenant_database = DB(db_name, **db_config_withoutfilter)


    integration_authentication_json_data = load_integration_authentication_json()
    integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)
    if not integration_authentication_id:
        query=f'''select parent_tenant_id from tenant where tenant_name='{tenant_name}'
        '''
        parent_tenant_id=common_utils_database.execute_query(query,True)['parent_tenant_id'].to_list()[0]
        if parent_tenant_id:
            parent_tenant_query = f"SELECT tenant_name FROM tenant WHERE id = {int(parent_tenant_id)}"
            parent_tenant_name = common_utils_database.execute_query(parent_tenant_query, True)["tenant_name"].iloc[0]
            integration_authentication_id = get_integration_authentication_id_by_unique_name(
                integration_authentication_json_data, parent_tenant_name
            )

    # Determine rev_customer_id_value
    if not rev_customer_id:
        return {"flag": False, "message": "Invalid Rev Customer ID"}

    role_module_data = common_utils_database.get_data(
        "role_module", {"role": role_name}, ["sub_module"]
    )

    module_status = False
    if not role_module_data.empty:
        try:
            sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')
            module_status = "Billing Platform Customers" in sub_modules.get("People", [])
        except json.JSONDecodeError:
            logging.error(f"Invalid JSON in sub_module for role: {role_name}")
        except Exception as e:
            logging.error(f"Unexpected error processing modules: {str(e)}")

    if module_status:
        rev_customer_id_list = tenant_database.get_data(
            "revcustomer",
            {
                "is_active": True,
                "integration_authentication_id": integration_authentication_id,
                "rev_customer_id": rev_customer_id,
            },
            concat_columns=["customer_name", "rev_customer_id"]
        )["concat_column"].drop_duplicates().sort_values().tolist()
    else:
        try:
            del db_config['billing_account_number']
        except Exception as e:
            logging.error(f"bulk_assign_customer exception: {str(e)}")
        tenant_databases = DB(db_name, **db_config_withoutfilter)
        customers = tenant_databases.get_data(
            "customers",
            {"is_active": True},
            ["customer_name", "id"]
        )
        if customers.empty:
            rev_customer_id_list = []
        else:
            customers = customers.rename(columns={"id": "customer_id"})
            rev_customer_id_list = [f"{row['customer_name']} -- {row['customer_id']}" for _, row in customers.iterrows()]

    rev_customer_id_value = ", ".join(rev_customer_id_list)
    if not rev_customer_id_value:
        return {"flag": False, "message": "Invalid Rev customer ID"}

    z_access_token = data.get("z_access_token", "")
    changed_data = data.get("changed_data", "")
    if z_access_token:
        if (
            not isinstance(changed_data, dict)
            or "Iccids" not in changed_data
            or "RevCustomerId" not in changed_data
        ):
            return {"message": "Invalid details", "status_code": 400}

        # Extract iccids and transform the changed_data
        iccids = changed_data.get("Iccids", [])
        updated_changed_data = {
            "Number": "",
            "ICCID": "",  # Remains empty
            "CreateRevService": changed_data.get("CreateRevService", False),
            "IntegrationAuthenticationId": "",
            "AddCarrierRatePlan": False,
            "CarrierRatePlan": None,
            "CommPlan": "",
            "UseAgentAccount": False,
            "JasperDeviceID": "",
            "SiteId": None,
            "AddCustomerRatePlan": False,
            "CustomerRatePlan": None,
            "CustomerRatePool": None,
            "DeviceId": None,
            "RevCustomerId": rev_customer_id_value,
            "ProviderId": "",  # Hardcoded as per requirement
            "ServiceTypeId": changed_data.get("ServiceType", ""),
            "RevProductId": [],  # Hardcoded as per requirement
            "RevPackageId": "",
            "RateList": [],  # Hardcoded as per requirement
            "Prorate": True,  # Hardcoded as per requirement
            "useCarrierActivation": False,
            "Description": "",
            "EffectiveDate": changed_data.get("EffectiveDate", None),
            "ActivatedDate": changed_data.get(
                "EffectiveDate", None
            ),  # Use the same EffectiveDate
            "UsagePlanGroupId": None,
        }

        # Update the data object with the transformed values
        data["iccids"] = iccids  # Add extracted ICCIDs to the main data object
        data["changed_data"] = updated_changed_data


    return update_bulk_change_data(data)

def update_bulk_change_data(data):
    """
    Updates the bulk change data for a specified module by checking user and tenant
    details, querying the database for column mappings and view names, and constructing
    a SQL query to fetch data from the appropriate view. Handles errors, logs relevant
    information, and inserts the updated data into the database.

    Parameters:
        data (dict): Input dictionary containing the necessary data, including request details,
                     changed data, session information, and tenant-related information.

    Returns:
        dict: A response dictionary indicating the status of the bulk change request and
              providing details on the inserted data.
    """

    logging.info(f"Request Data Received for update_bulk_change_data: {data}")
    try:
        del db_config['tenant_ids']
    except Exception as e:
        logging.warning(f"Exception is {e}")
    z_access_token = data.get("z_access_token", "")
    dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    request_received_at = data.get("request_received_at", "")

    if z_access_token:
        try:
            username = data.get("client_id", "")

            changed_data = data.get("changed_data", "")
            logging.info(f"changed_data Recieved is {changed_data}")

            service_account = dbs.get_data(
                "service_accounts", {"client_id": username}
            ).to_dict(orient="records")[0]
            logging.info(f"service_account  is {service_account}")
            role = service_account["role"]
            tenant = service_account["tenant"]

            tenant_name = tenant

            tenant_database = dbs.get_data(
                "tenant", {"tenant_name": tenant}, ["db_name"]
            )["db_name"].to_list()[0]
            session_id = data.get("session_id", "client_call")
            database = DB(tenant_database, **db_config_withoutfilter)
            data["created_by"] = username
            data['tenant_name']=tenant

        except:
            return {"message": "Invalid details", "status_code": 400}
    else:
        # Extract necessary fields from the input data
        session_id = data.get("session_id", "")
        username = data.get("username", "")
        # Database connections for tenant and common utilities
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config_withoutfilter)
        role = data.get("role_name", "")

    changed_data = data.get("changed_data", {})
    use_carrier_activation = changed_data.get("useCarrierActivation", False)

    # Start time for performance tracking
    start_time = time.time()

    try:
        # Initialize response data and retrieve tenant-related details
        response_data = {}
        tenant_name = data.get("tenant_name", "Altaworx")
        tenant_names_str = os.getenv("TENANT_NAMES", "")
        # Convert the comma-separated string into a list
        tenant_names_str = re.sub(r"[^a-zA-Z0-9]", " ", tenant_names_str)
        tenant_names = tenant_names_str.split(",")
        if tenant_name in tenant_names:
            tenant_id = 1
        else:
            tenant_id = dbs.get_data("tenant", {"tenant_name": tenant_name}, ["id"])[
                "id"
            ].to_list()[0]

        # Retrieve service provider and corresponding ID
        service_provider = data.get("service_provider", None)

        # Retrieve change type and corresponding ID
        Change_type = data.get("change_type", None)
        logging.info(f"Original Change_type: {Change_type}")  # Log the original value

        # Correct assignment
        if service_provider == 'Webbing':
            if Change_type == "Edit Username":
                Change_type = "Edit Username/Cost Center"  # Assign new value
                logging.info(f"Updated Change_type: {Change_type}")  # Log after assignment

        # Check if the change is applied
        logging.info(f"Final Change_type: {Change_type}")

        Change_type_id = database.get_data(
            "sim_management_bulk_change_type", {"display_name": Change_type}, ["id"]
        )["id"].to_list()[0]
        logging.info(f"Change_type_id is: {Change_type_id}")

        # Retrieve service provider and corresponding ID
        service_provider = data.get("service_provider", None)
        service_provider_id = database.get_data(
            "serviceprovider", {"service_provider_name": service_provider}, ["id"]
        )["id"].to_list()[0]

        # User and change data fields
        upload_xlx = data.get("upload_xlx", False)
        modified_by = data.get("modified_by", None)
        created_by = data.get("created_by", "Readme")

        changed_data = data.get("changed_data", None)
        imeids = data.get("imeids", [])
        customer_name = None
        customer_id = None
        # Determine ICCIDs based on the change type
        if Change_type == "Assign Customer":
            iccids = data.get("iccids", [])
            imeids = data.get("imeids", [])
        elif Change_type == "Archive":
            iccids = data.get("iccids", [])
            imeids = data.get("imeids", [])
        elif Change_type == "Change ICCID/IMEI":
            if "Telegence" in service_provider:
                # Ensure we get lists even if input data has None
                iccids = data.get("changed_data", {}).get("Request", {}).get("OldICCID", []) or []
                new_iccids = data.get("changed_data", {}).get("Request", {}).get("NewICCID", []) or []
                imeids = data.get("changed_data", {}).get("Request", {}).get("OldIMEI", []) or []
                new_imeids = data.get("changed_data", {}).get("Request", {}).get("NewIMEI", []) or []
            else:
                iccids = data.get("changed_data", {}).get("Request", {}).get("NewICCID", []) or []
                imeids = data.get("changed_data", {}).get("Request", {}).get("NewIMEI", []) or []
        elif "Telegence" in service_provider and Change_type == "Activate New Service":
            imeids = data.get("imei", [])
            iccids = data.get("iccids", [])
            customer_name = data.get("customer_name", None)
            customer_id  = data.get("customer_id", None)
        elif Change_type == "Change Phone Number":
            old_msisdn = data.get("changed_data", {}).get("old_msisdn", [])
            # Query ICCID from sim_management_inventory using old_msisdn
            iccids = []
            for msisdn in old_msisdn:
                inventory_data = database.get_data(
                    "sim_management_inventory",
                    {"msisdn": msisdn, "is_active": True, "tenant_id":tenant_id},
                    ["msisdn"]
                )
                if not inventory_data.empty:
                    iccids.append(inventory_data["msisdn"].iloc[0])
                else:
                    logging.warning(f"No msisdn found for old MSISDN: {msisdn}")
        else:
            iccids = data.get("iccids", [])
            imeids = data.get("imeids", [])

        # Ensure imeids is a list and replace None with empty string
        imeids = ["" if imei is None else imei for imei in imeids]

        iccids = iccids if iccids is not None else []
        imeids = imeids if imeids is not None else []
        integration_authentication_json_data = load_integration_authentication_json()
        integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)
        if not integration_authentication_id:
            query=f'''select parent_tenant_id from tenant where tenant_name='{tenant_name}'
            '''
            parent_tenant_id=dbs.execute_query(query,True)['parent_tenant_id'].to_list()[0]
            if parent_tenant_id:
                parent_tenant_id=int(parent_tenant_id)
            parent_tenant_query=f'''select tenant_name from tenant where id={parent_tenant_id}
            '''
            parent_tenant_name=dbs.execute_query(parent_tenant_query,True)['tenant_name'].to_list()[0]
            integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, parent_tenant_name)
        # Handle empty ICCID list
        uploaded_imeids = len(imeids)
        if uploaded_imeids == 0:
            imeids = ["" for _ in range(len(iccids))]
        uploaded = len(iccids)
        if uploaded == 0:
            iccids = [None]

        # Prepare the dictionary to create a new bulk change record
        return_dict = {}
        create_new_bulk_change_dict = {
            "service_provider": service_provider,
            "change_request_type_id": str(Change_type_id),
            "change_request_type": Change_type,
            "service_provider_id": str(service_provider_id),
            "modified_by": modified_by,
            "status": "NEW",
            "uploaded": str(uploaded),
            "is_active": "True",
            "is_deleted": "False",
            "created_by": created_by,
            "processed_by": created_by,
            "tenant_id": str(tenant_id),
        }

        if customer_name or customer_id:
            create_new_bulk_change_dict["customer_name"] = customer_name
            create_new_bulk_change_dict["customer_id"] = customer_id

        # Insert new bulk change data into the database
        change_id = database.insert_data(
            create_new_bulk_change_dict, "sim_management_bulk_change"
        )
        return_dict["sim_management_bulk_change"] = [create_new_bulk_change_dict]

        # Fetch the inserted bulk change record
        bulkchange_df = database.get_data(
            "sim_management_bulk_change", {"id": change_id}
        )
        # bulkchange_id = bulkchange_df["id"].to_list()[0]
        bulkchange_id = change_id
        logging.info(bulkchange_id, "bulkchange_id")

        # Prepare the change request data based on the change type
        change_request = changed_data
        if Change_type == "Archive":
            change_request["ServiceProviderId"] = service_provider_id
            change_request["ChangeType"] = Change_type_id

        elif Change_type == "Change Customer Rate Plan":
            change_request["ServiceProviderId"] = service_provider_id

            change_request["ChangeType"] = Change_type_id
            change_request["ProcessChanges"] = True
            # Remove EffectiveDate if it's None
            if change_request["CustomerRatePlanUpdate"]["EffectiveDate"] is None:
                change_request["CustomerRatePlanUpdate"].pop("EffectiveDate", None)
            else:
                # If it's not None, format the EffectiveDate
                change_request["CustomerRatePlanUpdate"]["EffectiveDate"] = str(
                    change_request["CustomerRatePlanUpdate"]["EffectiveDate"]
                ).split(".")[0]
            if (
                change_request["CustomerRatePlanUpdate"]["CustomerRatePlanId"]
                and change_request["CustomerRatePlanUpdate"]["CustomerRatePlanId"] != -1
            ):
                rate_plan_id = change_request["CustomerRatePlanUpdate"]["CustomerRatePlanId"]

                # Check which delimiter exists and split accordingly
                if " -- " in rate_plan_id:
                    rate_plan_name = rate_plan_id.rsplit(" -- ", 1)[0]
                elif " - " in rate_plan_id:
                    rate_plan_name = rate_plan_id.rsplit(" - ", 1)[0]
                else:
                    rate_plan_name = rate_plan_id  # No delimiter found, keep the full string

                change_request["CustomerRatePlanUpdate"]["CustomerRatePlanId"] = (
                    database.get_data(
                        "customerrateplan",
                        {"rate_plan_name": rate_plan_name, "is_active": True},
                        ["id"],
                    )["id"].to_list()[0]
                )
            # Check if 'CustomerRatePoolId' exists and has a value
            if (
                "CustomerRatePoolId" in change_request["CustomerRatePlanUpdate"]
                and change_request["CustomerRatePlanUpdate"]["CustomerRatePoolId"]
            ):
                rate_pool_id_value = change_request["CustomerRatePlanUpdate"][
                    "CustomerRatePoolId"
                ]
                if not isinstance(rate_pool_id_value, str):
                    rate_pool_id_value = str(rate_pool_id_value)
                # If 'CustomerRatePoolId' has the expected format with '-- ' (e.g., "TestRatePool 03 -- 37")
                if "--" in rate_pool_id_value:
                    # Extract the numeric part after "-- "
                    rate_pool_id_number = rate_pool_id_value.rsplit(" -- ", 1)[-1]

                    # Convert the extracted value to an integer if it's a valid number
                    try:
                        change_request["CustomerRatePlanUpdate"][
                            "CustomerRatePoolId"
                        ] = int(rate_pool_id_number)
                        logging.info(
                            f"Updated CustomerRatePoolId to {change_request['CustomerRatePlanUpdate']['CustomerRatePoolId']}"
                        )
                    except ValueError:
                        logging.warning(
                            f"Invalid value for CustomerRatePoolId: {rate_pool_id_number}"
                        )
                else:
                    logging.warning(
                        f"Invalid format for CustomerRatePoolId: {rate_pool_id_value}"
                    )
            else:
                logging.warning(
                    "CustomerRatePoolId is missing from CustomerRatePlanUpdate"
                )
            if not change_request["CustomerRatePlanUpdate"]["CustomerRatePoolId"]:
                change_request["CustomerRatePlanUpdate"].pop("CustomerRatePoolId")

            # Change the key from "CustomerRatePoolId" to "CustomerPoolId"
            if "CustomerRatePoolId" in change_request["CustomerRatePlanUpdate"]:
                change_request["CustomerRatePlanUpdate"]["CustomerPoolId"] = (
                    change_request["CustomerRatePlanUpdate"].pop("CustomerRatePoolId")
                )
                logging.info(f"Changed key 'CustomerRatePoolId' to 'CustomerPoolId'")

        elif Change_type == "Update Device Status":
            change_request.pop("Devices")
            change_request.pop("OverrideValidation")
            change_request["UpdateStatus"] = change_request.get("UpdateStatus", "")
            change_request["IsIgnoreCurrentStatus"] = False
            status = change_request["UpdateStatus"]

            int_id = database.get_data(
                "serviceprovider", {"id": service_provider_id}, ["integration_id"]
            )["integration_id"].to_list()[0]
            if "Telegence" in service_provider:
                status_id = database.get_data(
                    "device_status",
                    {
                        "integration_id": int_id,
                        "allows_api_update": True,
                        "is_active": True,
                        "status": status,
                    },
                    ["id"],
                )["id"].to_list()[0]
            else:
                status_df = database.get_data(
                    "device_status",
                    {
                        "integration_id": int_id,
                        "allows_api_update": True,
                        "is_active": True,
                        "display_name": status,
                    },
                    ["id", "status"],
                )
                status_id = status_df["id"].to_list()[0]
                statu = status_df["status"].to_list()[0]
                change_request["UpdateStatus"] = statu

            change_request["IntegrationAuthenticationId"] = 0
            change_request["PostUpdateStatusId"] = status_id

            if (
                "Verizon" not in service_provider
                and "Telegence" not in service_provider
            ):
                change_request["Request"] = {}

        # Additional conditions for other change types
        elif Change_type == "Assign Customer":
            if (
                change_request["CustomerRatePlan"]
                and change_request["CustomerRatePlan"] != "No options"
            ):
                customer_plan = change_request["CustomerRatePlan"].rsplit(" -- ", 1)
                customer_rate_plan_id=database.get_data(
                    "customerrateplan",
                    {"rate_plan_name": customer_plan[0], "is_active": True},
                    ["id"],
                )["id"].to_list()[0]
                change_request["CustomerRatePlan"] = str(customer_rate_plan_id)
                # change_request["CustomerRatePlanName"] = customer_plan[0]
                # change_request["CustomerRatePlanCode"] = customer_plan[1]

            if change_request["RevPackageId"]:
                change_request["RevPackageId"] = int(change_request["RevPackageId"])
            if change_request["RevCustomerId"]:
                # change_request["RevCustomerName"] = change_request[
                #     "RevCustomerId"
                # ].rsplit(" -- ", 1)[0]
                change_request["RevCustomerId"] = (
                    str(change_request["RevCustomerId"].rsplit(" -- ", 1)[1])
                    if change_request["RevCustomerId"] and " -- " in change_request["RevCustomerId"]
                    else ""
                )


            if (
                change_request["CustomerRatePool"]
                and change_request["CustomerRatePool"] != "No options"
            ):
                # change_request["CustomerRatePoolName"] = change_request[
                #     "CustomerRatePool"
                # ].rsplit(" -- ", 1)[0]
                change_request["CustomerRatePool"] = (
                    str(change_request["CustomerRatePool"].rsplit(" -- ", 1)[1])
                    if pd.notna(change_request["CustomerRatePool"]) and " -- " in str(change_request["CustomerRatePool"])
                    else ""
                )

            if change_request["ServiceTypeId"]:
                change_request["ServiceTypeId"] = int(
                    change_request["ServiceTypeId"].rsplit(" -- ", 1)[1]
                )
            if change_request["RevCustomerId"]:
                # Fetch role module data with efficient query
                role_module_data = dbs.get_data(
                    "role_module",
                    {"role": role},
                    ["sub_module"],
                )

                # Initialize default status
                module_status = False

                if not role_module_data.empty:
                    try:
                        # Parse JSON safely with fallback
                        sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                        # Strict nested check
                        if "People" in sub_modules:
                            people_modules = sub_modules["People"]
                            if isinstance(people_modules, list):  # Ensure it's a list
                                module_status = "Billing Platform Customers" in people_modules

                    except json.JSONDecodeError:
                        logging.error(f"Invalid JSON in sub_module for role: {role}")
                    except KeyError:
                        pass  # People section not present
                    except Exception as e:
                        logging.error(f"Unexpected error processing modules: {str(e)}")

                if module_status == True:

                    query = f"select c.id as siteid,rc.integration_authentication_id as int_id from customers c join revcustomer rc on rc.id=c.rev_customer_id where rc.rev_customer_id ='{change_request['RevCustomerId']}' and c.is_active =true"
                    df_rev = database.execute_query(query, True)
                    change_request["SiteId"] = df_rev["siteid"].to_list()[0]
                else:
                    logging.info(f'change_request_RevID {change_request["RevCustomerId"]}')
                    change_request["SiteId"] = change_request["RevCustomerId"]
                # Fetch role module data with efficient query
                role_module_data = dbs.get_data(
                    "role_module",
                    {"role": role},
                    ["sub_module"],
                )

                # Initialize default status
                module_status = False

                if not role_module_data.empty:
                    try:
                        # Parse JSON safely with fallback
                        sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                        # Strict nested check
                        if "People" in sub_modules:
                            people_modules = sub_modules["People"]
                            if isinstance(people_modules, list):  # Ensure it's a list
                                module_status = "Billing Platform Customers" in people_modules

                    except json.JSONDecodeError:
                        logging.error(f"Invalid JSON in sub_module for role: {role}")
                    except KeyError:
                        pass  # People section not present
                    except Exception as e:
                        logging.error(f"Unexpected error processing modules: {str(e)}")

                if module_status == True:

                    query = f"select c.id as siteid,rc.integration_authentication_id as int_id from customers c join revcustomer rc on rc.id=c.rev_customer_id where rc.rev_customer_id ='{change_request['RevCustomerId']}' and c.is_active =true"
                    df_rev = database.execute_query(query, True)
                    change_request["SiteId"] = df_rev["siteid"].to_list()[0]
                else:
                    logging.info(f'change_request["RevCustomerId"] {change_request["RevCustomerId"]}')
                    change_request["SiteId"] = change_request["RevCustomerId"]
            change_request["IntegrationAuthenticationId"] = int(integration_authentication_id)
            change_request["RevProductIdList"] = change_request["RevProductId"]
            change_request.pop("RevProductId")

        elif Change_type == "Change Carrier Rate Plan":

            if service_provider in ("AT&T - Telegence - UAT ONLY", "AT&T - Telegence"):
                change_request["ServiceProviderId"] = service_provider_id

                # Get integration ID from service provider
                integration_id = database.get_data(
                    "serviceprovider", {"id": service_provider_id}, ["integration_id"]
                )["integration_id"].to_list()[0]
                change_request["IntegrationId"] = integration_id

                # Extract values from the nested CarrierRatePlanUpdate
                carrier_update = change_request["CarrierRatePlanUpdate"]

                # Add the phone number/subscriber number
                change_request["PhoneNumber"] = carrier_update.get("SubscriberNumber", "")

                # Handle the carrier rate plan
                if carrier_update.get("CarrierRatePlan"):
                    friendly_name = carrier_update["CarrierRatePlan"]
                    # Extract the rate plan code
                    plan_code = database.get_data(
                        "carrier_rate_plan",
                        {"friendly_name": friendly_name, "is_active": True},
                        ["rate_plan_code"],
                    )["rate_plan_code"].to_list()

                    if plan_code:
                        change_request["RatePlanName"] = plan_code[0]
                    else:
                        change_request["RatePlanName"] = friendly_name

                # Add the effective date
                change_request["EffectiveDate"] = carrier_update.get("EffectiveDate")

                # Add optimization group
                if carrier_update.get("OptimizationGroup") is None:
                    change_request["OptimizationGroup"] = -1
                else:
                    change_request["OptimizationGroup"] = carrier_update.get("OptimizationGroup")

                # Remove the nested structure we no longer need
                if "CarrierRatePlanUpdate" in change_request:
                    change_request.pop("CarrierRatePlanUpdate")

                # Remove unnecessary keys
                if "ChangeType" in change_request:
                    change_request.pop("ChangeType")
                if "ProcessChanges" in change_request:
                    change_request.pop("ProcessChanges")


            else:
                change_request["ServiceProviderId"] = service_provider_id
                change_request["ChangeType"] = Change_type_id
                change_request["ProcessChanges"] = True
                if change_request["CarrierRatePlanUpdate"]["CarrierRatePlan"]:
                    friendly_name = change_request["CarrierRatePlanUpdate"][
                        "CarrierRatePlan"
                    ].rsplit(" -- ", 1)

                    plan_uuid = database.get_data(
                        "carrier_rate_plan",
                        {"rate_plan_code": friendly_name, "is_active": True},
                        ["plan_uuid"],
                    )["plan_uuid"].to_list()
                    plan_uuid_ = database.get_data(
                        "carrier_rate_plan",
                        {"friendly_name": friendly_name, "is_active": True},
                        ["plan_uuid"],
                    )["plan_uuid"].to_list()

                    if plan_uuid:
                        plan_uuid = plan_uuid[0]
                    else:
                        if plan_uuid_:
                            plan_uuid = plan_uuid_[0]
                        else:
                            plan_uuid = ""

                    change_request["CarrierRatePlanUpdate"]["PlanUuid"] = plan_uuid
                change_request["CarrierRatePlanUpdate"]["RatePlanId"] = 0

        elif Change_type == "Edit Username/Cost Center" or Change_type == "Edit Username":
            change_request["ServiceProviderId"] = service_provider_id
            change_request["ChangeType"] = Change_type_id

        elif Change_type == "Change ICCID/IMEI":
            change_request["ServiceProviderId"] = service_provider_id
            change_request["ChangeType"] = Change_type_id
            if change_request.get("IntegrationAuthenticationId") is None:
                change_request["IntegrationAuthenticationId"] = 0
                request_data = change_request["Request"]

                # Convert OldICCID and NewICCID lists to strings

                # Handle Telegence case
                if "Telegence" in service_provider:
                    # Remove existing request data that's not needed for Telegence
                    change_request["Request"] = {}
                else:
                    # Existing logic for non-Telegence cases
                    request_data["OldICCID"] = request_data["OldICCID"][0] if request_data["OldICCID"] else None
                    request_data["NewICCID"] = request_data["NewICCID"][0] if request_data["NewICCID"] else None



        elif Change_type == "Activate New Service":
            change_request["ServiceProviderId"] = service_provider_id
            change_request["ChangeType"] = Change_type_id
            change_request["AddCustomerRatePlan"] = True
            change_request["CustomerRatePool"] = None
            CustomerRatePlan_id=None
            if "Telegence" in service_provider:
                if z_access_token:
                    if change_request["CustomerRatePlan"]:
                        rate_plan_code = change_request["CustomerRatePlan"].rsplit(
                            " -- ", 1
                        )[1]
                        CustomerRatePlan_id = database.get_data(
                            "customerrateplan",
                            {
                                "is_active": True,
                                "soc_code": change_request["CustomerRatePlan"].rsplit(
                                    " -- ", 1
                                ),
                            },
                            ["id"],
                        )["id"].to_list()
                    if CustomerRatePlan_id:
                        change_request["CustomerRatePlan"] = CustomerRatePlan_id[0]
                    else:
                        change_request["CustomerRatePlan"] = ""

                else:
                    if change_request["CustomerRatePlan"]:
                        if role not in ('Super Admin','Partner Admin'):
                            rate_plan_code = change_request["CustomerRatePlan"]
                        else:

                            rate_plan_code = change_request["CustomerRatePlan"].rsplit(
                                " -- ", 1
                            )[1]
                        CustomerRatePlan_id = database.get_data(
                            "customerrateplan",
                            {
                                "is_active": True,
                                "soc_code": rate_plan_code,
                            },
                            ["id"],
                        )["id"].to_list()
                        if CustomerRatePlan_id:
                            change_request["CustomerRatePlan"] = CustomerRatePlan_id[0]
                        else:
                            change_request["CustomerRatePlan"] = ""

        # Prepare bulk change request data for each ICCID
        create_new_bulk_change_request_dict = []
        service_numbers = {}
        if Change_type == "Assign Customer":

            # device_df=database.get_data('sim_management_inventory',{'iccid':iccids,'is_active':True},['msisdn','id','date_activated'])
            if len(iccids) > 1:
                iccids_tuple = tuple(iccids)
                params = [iccids_tuple]
                query = f"""select msisdn,device_id,mobility_device_id,date_activated,iccid from sim_management_inventory where iccid in %s and is_active=true and tenant_id= {tenant_id}"""
                device_df = database.execute_query(query, params=params).to_dict(
                    orient="records"
                )
            elif len(iccids) == 1:
                query = f"select msisdn,device_id,mobility_device_id,date_activated,iccid from sim_management_inventory where iccid ='{iccids[0]}' and is_active=true and  tenant_id= {tenant_id}"
                device_df = database.execute_query(query, True).to_dict(
                    orient="records"
                )
            else:
                return {
                    "flag": False,
                    "message": "No ICCID provided for Assign Customer",
                }

            device_ids = {}
            print(device_df, "111111111111111111111ssssssssssssssss")
            for ids in device_df:
                device_ids[ids["iccid"]] = ids

            for i in range(len(iccids)):
                try:
                    device_id = device_ids[iccids[i]]["mobility_device_id"]
                    if not device_id:
                        device_id = device_ids[iccids[i]]["device_id"]
                except:
                    device_id = None

                msisdn = ""
                if iccids[i] in device_ids:
                    print(device_ids[iccids[i]]["msisdn"], "aaaaaaaaaaaaaaaaaaaaaaa")
                    msisdn = device_ids[iccids[i]]["msisdn"]

                if iccids[i] in device_ids:
                    if device_ids[iccids[i]]["msisdn"]:
                        print(device_ids[iccids[i]]["msisdn"], "aaaaaaaaaaaaaaaaaaaaaaa")
                        change_request["Number"] = device_ids[iccids[i]]["msisdn"]
                        print(device_id, "lllllllllllllllll")
                    change_request["DeviceId"] = device_id
                    if "Telegence" in service_provider:
                        #change_request["iccids"] = [iccids[0]]
                        try:
                            print(iccids[i], "11111111111111111111")
                            change_request["ICCID"] = iccids[i]
                        except Exception as e:
                            logging.error(f"Error: {e}")
                    else:
                        print(iccids[i], "ddddddddddddddddddd")
                        change_request["ICCID"] = iccids[i]
                    if (
                            device_ids[iccids[i]]["date_activated"]
                            and not change_request["ActivatedDate"]
                            and use_carrier_activation
                        ):
                            change_request["ActivatedDate"] = str(
                                device_ids[iccids[i]]["date_activated"]
                            )
                            change_request["EffectiveDate"] = str(
                                device_ids[iccids[i]]["date_activated"]
                            )
                            if "Request" not in change_request:
                                change_request["Request"] = {}
                            change_request["Request"]["PublicIpRestriction"] = ""

                temp = {
                    "iccid": iccids[i],
                    "subscriber_number": msisdn,
                    "bulk_change_id": str(bulkchange_id),
                    "tenant_name": tenant_name,
                    "created_by": created_by,
                    "processed_by": created_by,
                    "status": "NEW",
                    "device_id": device_id,
                }

                temp["is_active"] = "True"
                temp["is_deleted"] = "False"
                if change_request:
                    temp["change_request"] = json.dumps(change_request)

                create_new_bulk_change_request_dict.append(temp)

                # Process CreateRevService if True
                if changed_data.get("CreateRevService") == True:
                    # Initialize service_numbers for this ICCID if it doesn't exist
                    rev_service_ids = []

                    if len(iccids) > 1:
                        iccids_tuple = tuple(iccids)
                        params = [iccids_tuple]
                        query = f"""SELECT rev_service_id, d.iccid FROM device_tenant dt
                                INNER JOIN device d ON d.id = dt.device_id
                                WHERE d.iccid in %s and tenant_id = {tenant_id}"""

                        rev_service_data = database.execute_query(query, params=params).to_dict(
                            orient="records"
                        )
                    elif len(iccids) == 1:
                        query = f"""SELECT rev_service_id, d.iccid FROM device_tenant dt
                                INNER JOIN device d ON d.id = dt.device_id
                                WHERE d.iccid = '{str(iccids[0])}' and tenant_id = {tenant_id}"""

                        rev_service_data = database.execute_query(query, True).to_dict(
                            orient="records"
                        )
                    else:
                        rev_service_data = []

                    # Create a mapping of ICCID to rev_service_id
                    rev_service_map = {}
                    for item in rev_service_data:
                        if item["iccid"] not in rev_service_map:
                            rev_service_map[item["iccid"]] = []
                        rev_service_map[item["iccid"]].append(item["rev_service_id"])

                    # Get subscriber data for current ICCID
                    if iccids[i] in rev_service_map:
                        subscriber_data_list = []
                        for rev_service_id in rev_service_map[iccids[i]]:
                            # Ensure rev_service_id is not None and is a valid integer
                            if rev_service_id is not None and rev_service_id != 'None':
                                try:
                                    subscriber_query = f"""SELECT number FROM rev_service
                                                        WHERE rev_service_id = %s"""
                                    subscriber_result = database.execute_query(subscriber_query, params=(rev_service_id,))

                                    if not subscriber_result.empty:
                                        subscriber_data_list.append(subscriber_result["number"].iloc[0])
                                except Exception as e:
                                    logging.info(f"Error fetching subscriber data: {str(e)}")

                        # Add subscriber data to temp
                        for subscriber_number in subscriber_data_list:
                            temp_copy = temp.copy()
                            temp_copy["service_number"] = subscriber_number
                            service_numbers[iccids[i]] = subscriber_number  # Store in service_numbers
                            create_new_bulk_change_request_dict.append(temp_copy)


        if Change_type not in ("Assign Customer"):

            try:
                if "Telegence" in service_provider and (Change_type == "Change Carrier Rate Plan" or Change_type == 'Change ICCID/IMEI'):
                    # Query by msisdn (phone number) for Telegence
                    device_ids_df = database.get_data(
                        "sim_management_inventory",
                        {"msisdn": iccids, "is_active": True, "tenant_id": tenant_id},
                        ["device_id", "mobility_device_id", "iccid", "msisdn", "imei"],
                    ).to_dict(orient="records")

                    # Create mappings using msisdn as the key instead of iccid
                    device_ids = {}
                    device_mssid = {}
                    for ids in device_ids_df:
                        if ids["device_id"]:
                            device_mssid[ids["msisdn"]] = ids  # Use msisdn as key
                            device_ids[ids["msisdn"]] = ids["device_id"]
                        else:
                            device_mssid[ids["msisdn"]] = ids  # Use msisdn as key
                            device_ids[ids["msisdn"]] = ids["mobility_device_id"]

                elif Change_type == "Change Phone Number":
                    # Query by msisdn (phone number) for Telegence
                    device_ids_df = database.get_data(
                        "sim_management_inventory",
                        {"msisdn": iccids, "is_active": True, "tenant_id": tenant_id},
                        ["device_id", "mobility_device_id", "iccid", "msisdn", "imei"],
                    ).to_dict(orient="records")

                    # Create mappings using msisdn as the key instead of iccid
                    device_ids = {}
                    device_mssid = {}
                    for ids in device_ids_df:
                        if ids["device_id"]:
                            device_mssid[ids["msisdn"]] = ids  # Use msisdn as key
                            device_ids[ids["msisdn"]] = ids["device_id"]
                        else:
                            device_mssid[ids["msisdn"]] = ids  # Use msisdn as key
                            device_ids[ids["msisdn"]] = ids["mobility_device_id"]
                else:
                    # Original code for non-Telegence cases
                    device_ids_df = database.get_data(
                        "sim_management_inventory",
                        {"iccid": iccids, "is_active": True, "tenant_id": 1},
                        ["device_id", "mobility_device_id", "iccid", "msisdn", "imei"],
                    ).to_dict(orient="records")

                    device_ids = {}
                    device_mssid = {}
                    for ids in device_ids_df:
                        if ids["device_id"]:
                            device_mssid[ids["iccid"]] = ids
                            device_ids[ids["iccid"]] = ids["device_id"]
                        else:
                            device_mssid[ids["iccid"]] = ids
                            device_ids[ids["iccid"]] = ids["mobility_device_id"]
            except Exception as e:
                logging.error(f"Error fetching device data: {str(e)}")
                device_ids = {}
                device_mssid = {}

            for i in range(len(iccids)):

                msisdn = ""
                if iccids[i] in device_mssid:
                    msisdn = device_mssid[iccids[i]]["msisdn"]

                if (
                    "Verizon" in service_provider
                    and Change_type == "Update Device Status"
                ):
                    if i == 0:
                        change_request["Request"].pop("MdnZipCode", None)
                        change_request["Request"]["thingSpacePPU"].pop(
                            "FirstName", None
                        )
                        change_request["Request"]["thingSpacePPU"].pop(
                            "AddressLine", None
                        )
                        change_request["Request"]["thingSpacePPU"].pop("City", None)
                        change_request["Request"]["thingSpacePPU"].pop("Country", None)
                        change_request["Request"]["thingSpacePPU"].pop("LastName", None)
                    change_request["Request"]["ICCID"] = iccids[i]
                    try:
                        change_request["Request"]["IMEI"] = imeids[i]
                    except:
                        change_request["Request"]["IMEI"] = ""
                    change_request["Request"]["PublicIpRestriction"] = ""
                if (
                    "Telegence" in service_provider
                    and Change_type == "Activate New Service"
                ):
                    if "ChangeType" in change_request:
                        change_request.pop("ChangeType")
                    if "ServiceProviderId" in change_request:
                        change_request.pop("ServiceProviderId")
                    for dict in change_request["TelegenceActivationRequest"]["service"][
                        "serviceCharacteristic"
                    ]:
                        if dict["name"] == "IMEI":
                            dict["value"] = imeids[i]
                        elif dict["name"] == "sim":
                            dict["value"] = iccids[i]
                        elif dict["name"] == "singleUserCode":
                            dict["value"] = rate_plan_code

                # Handle Telegence-specific structure for Change ICCID/IMEI
                if Change_type == "Change ICCID/IMEI" and "Telegence" in service_provider:
                    # Query inventory data for current ICCID (OldICCID)
                    inventory_data = database.get_data(
                        "sim_management_inventory",
                        {"msisdn": iccids[i], "is_active": True, "tenant_id": tenant_id},
                        ["service_zip_code", "technology_type", "imei", "iccid"]
                    ).to_dict(orient="records")

                    if inventory_data:
                        service_zip_code = inventory_data[0].get("service_zip_code", "")
                        technology_type = inventory_data[0].get("technology_type", "")
                        old_imei = inventory_data[0].get("imei", "")
                        old_iccid = inventory_data[0].get("iccid", "")
                    else:
                        service_zip_code = ""
                        technology_type = ""
                        old_imei = ""
                        old_iccid = ""

                    # Determine new values
                    new_iccid = new_iccids[i] if i < len(new_iccids) else ""
                    new_imeid = new_imeids[i] if i < len(new_imeids) else ""

                    # Set SIM and IMEI values based on input
                    sim_value = new_iccid if new_iccid else old_iccid
                    imei_value = new_imeid if new_imeid else old_imei

                    # Build service characteristics
                    service_characteristic = [
                        {"name": "reasonCode", "value": "CUST_OWN_EQU"},
                        {"name": "serviceZipCode", "value": service_zip_code},
                        {"name": "technologyType", "value": technology_type},
                        {"name": "IMEI", "value": imei_value},
                        {"name": "sim", "value": sim_value}
                    ]

                    # Update change_request for Telegence
                    change_request["Request"] = {"serviceCharacteristic": service_characteristic}
                    change_request["IntegrationAuthenticationId"] = 0
                    change_request.pop("ServiceProviderId", None)
                    change_request.pop("ChangeType", None)

                    # Determine subscriber number based on change type
                    if new_iccid:
                        subscriber_number = iccids[i]  # Use OldICCID as subscriber_number
                    elif new_imeid:
                        subscriber_number = imeids[i]  # Use OldIMEI as subscriber_number



                if (
                    "Telegence" in service_provider
                    and Change_type == "Update Device Status"
                ):
                    temp = {
                        "iccid": iccids[i],
                        "subscriber_number": msisdn,
                        "msisdn": imeids[i],
                        "bulk_change_id": str(bulkchange_id),
                        "tenant_name": tenant_name,
                        "created_by": created_by,
                        "processed_by": created_by,
                        "status": "NEW",
                        "tenant_id": tenant_id
                    }
                elif (
                    "Telegence" in service_provider
                    and Change_type == "Change ICCID/IMEI"
                ):
                    # Determine final ICCID value
                    final_iccid = new_iccid if new_iccid else iccids[i]

                    temp = {
                        "iccid": final_iccid,
                        "subscriber_number": msisdn,
                        "msisdn": imeids[i],
                        "bulk_change_id": str(bulkchange_id),
                        "tenant_name": tenant_name,
                        "created_by": created_by,
                        "processed_by": created_by,
                        "status": "NEW",
                        "tenant_id": tenant_id
                    }
                elif Change_type == "Change Phone Number":
                    # Get inventory data for this MSISDN
                    inventory_data = device_mssid.get(iccids[i], {})

                    # Get existing ICCID from inventory or empty string
                    existing_iccid = inventory_data.get('iccid', '')

                    temp = {
                        "iccid": existing_iccid,
                        "subscriber_number": msisdn,
                        "msisdn": imeids[i],
                        "bulk_change_id": str(bulkchange_id),
                        "tenant_name": tenant_name,
                        "created_by": created_by,
                        "processed_by": created_by,
                        "status": "NEW",
                        "tenant_id": tenant_id
                    }
                else:
                    temp = {
                        "iccid": iccids[i],
                        "subscriber_number": msisdn,
                        "bulk_change_id": str(bulkchange_id),
                        "tenant_name": tenant_name,
                        "created_by": created_by,
                        "processed_by": created_by,
                        "status": "NEW",
                        "tenant_id": tenant_id
                    }

                if iccids[i] in device_ids:
                    temp["device_id"] = device_ids[iccids[i]]
                else:
                    temp["device_id"] = None

                temp["is_active"] = "True"
                temp["is_deleted"] = "False"
                if change_request:
                    if "Telegence" in service_provider and Change_type == "Change Carrier Rate Plan":
                        change_request["PhoneNumber"] = iccids[i]
                        change_request["ICCID"] = device_mssid[iccids[i]]["iccid"]
                        change_request["IMEI"] = device_mssid[iccids[i]]["imei"]
                    temp["change_request"] = json.dumps(change_request).replace(': null', ':null')

                create_new_bulk_change_request_dict.append(temp)
        # Extract all ICCIDs from the input list
        iccid_list = [
            item["iccid"]
            for item in create_new_bulk_change_request_dict
            if "iccid" in item
        ]

        # Ensure ICCIDs are formatted as a string for the query
        iccid_string = ", ".join([f"'{iccid}'" for iccid in iccid_list])

        if Change_type == "Assign Customer":

            # SQL-style query
            query = f"""
            SELECT iccid, mobility_device_id, msisdn
            FROM sim_management_inventory
            WHERE is_active = True
            AND iccid IN ({iccid_string})
            AND tenant_id = {tenant_id};
            """
        else:
            # SQL-style query
            query = f"""
            SELECT iccid, mobility_device_id, msisdn
            FROM sim_management_inventory
            WHERE is_active = True
            AND msisdn IN ({iccid_string})
            AND tenant_id = {tenant_id};
            """

        try:
            # Execute the query
            dataframe = database.execute_query(query, True)

            # Ensure the DataFrame is valid
            if dataframe is None or dataframe.empty:
                logging.warning("No matching ICCIDs found in the database.")
            else:
                # Create a mapping dictionary for quick lookup
                iccid_mapping = {
                    row["msisdn"]: {
                        "new_iccid": row["iccid"],
                        "mobility_device_id": row["mobility_device_id"],
                    }
                    for _, row in dataframe.iterrows()
                }

                # Update each item in the input list
                for item in create_new_bulk_change_request_dict:
                    iccid = item.get("iccid", None)

                    if iccid and iccid in iccid_mapping:
                        mapped_data = iccid_mapping[iccid]
                        item["subscriber_number"] = (
                            iccid  # Move old iccid to subscriber_number
                        )
                        item["iccid"] = mapped_data[
                            "new_iccid"
                        ]  # Update with new_iccid
                        item["device_id"] = int(
                            mapped_data["mobility_device_id"]
                        )  # Add mobility_device_id as device_id
                    else:
                        logging.warning(f"No mapping found for ICCID: {iccid}")

                # Debugging output
                logging.info(
                    "Updated create_new_bulk_change_request_dict:",
                    create_new_bulk_change_request_dict,
                )
        except Exception as e:
            logging.exception("Error during database query:", str(e))
        # Insert bulk change request data into the database
        request_id = database.insert_data(
            create_new_bulk_change_request_dict, "sim_management_bulk_change_request"
        )

        return_dict["sim_management_bulk_change_request"] = request_id

        # Format the bulk change record for the response
        bulk_change_row = bulkchange_df.to_dict(orient="records")[0]
        bulk_change_row["modified_date"] = str(bulk_change_row["modified_date"])
        bulk_change_row["created_date"] = str(bulk_change_row["created_date"])
        bulk_change_row["processed_date"] = str(bulk_change_row["processed_date"])

        # Prepare the success response data
        response_data = {
            "flag": True,
            "message": "Successful New Bulk Change Request Has Been Inserted",
            "bulkchange_id": bulk_change_row,
        }

        # Add service_numbers to response_data if they exist
        if service_numbers:
            # Convert the dictionary of service numbers to a flat list
            flat_service_numbers = []
            for numbers_list in service_numbers.values():
                flat_service_numbers.append(numbers_list)
            response_data["service_numbers"] = flat_service_numbers

        # End time for performance tracking
        end_time = time.time()
        end_time_str = f"{time.strftime('%m-%d-%Y %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
        time_consumed = f"{end_time - start_time:.4f}"

        # Log user actions for auditing
        audit_data_user_actions = {
            "service_name": "Sim Management",
            "created_date": request_received_at,
            "created_by": username,
            "status": str(response_data["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": tenant_name,
            # "comments": json.dumps(changed_data),
            "module_name": "update_bulk_change_data",
            "request_received_at": request_received_at,
        }
        try:
            dbs.update_audit(audit_data_user_actions, "audit_user_actions")
        except:
            pass

        # Add the data to the response
        response_data["data"] = return_dict
        response_data["bulk_chnage_id_20"] = bulkchange_id
        if z_access_token:
            logging.info('entered here for calling run db script in path')
            # Fetch role module data with efficient query
            role_module_data = dbs.get_data(
                "role_module",
                {"role": role},
                ["sub_module"],
            )

            # Initialize default status
            module_status = False

            if not role_module_data.empty:
                try:
                    # Parse JSON safely with fallback
                    sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                    # Strict nested check
                    if "People" in sub_modules:
                        people_modules = sub_modules["People"]
                        if isinstance(people_modules, list):  # Ensure it's a list
                            module_status = "Billing Platform Customers" in people_modules

                except json.JSONDecodeError:
                    logging.error(f"Invalid JSON in sub_module for role: {role}")
                except KeyError:
                    pass  # People section not present
                except Exception as e:
                    logging.error(f"Unexpected error processing modules: {str(e)}")

            logging.info('entered here for calling run db script')
            data = {
                "tenant_name": tenant_name,
                "username": username,
                "path": "/run_db_script",
                "module_name": "Bulk Change",
                "mod_pages": {"start": 0, "end": 100},
                "access_token": z_access_token,
                "db_name": tenant_database,
                "sessionID": session_id,
                "request_received_at": request_received_at,
                "Partner": tenant_name,
                "bulkchange_id": bulkchange_id,
                "data": return_dict,
                "bulk_chnage_id_20": bulkchange_id,
            }

            # Create a child process to run the script asynchronously
            pid = os.fork()

            if pid == 0:
                # In child process: Run the script and exit
                try:
                    if module_status == False and  Change_type == "Assign Customer":

                        pass

                    elif module_status == False and  Change_type == "Edit Username/Cost Center":
                        pass
                    elif module_status == False and  Change_type == "Change Phone Number":
                        pass
                    else:
                        logging.info('called successfully',data)
                        run_db_script(data)
                except Exception as e:
                    logging.info(f"Error: {e}")
                finally:
                    os._exit(0)  # Ensure child process exits
            else:
                # In parent process: Continue immediately
                logging.info("DB script triggered asynchronously.")

            response_data = {}
            response_data["bulk_change_id"] = bulkchange_id
            response_data["flag"] = True
            response_data["message"] = (
                "Successful New Bulk Change Request Has Been Inserted"
            )

        if Change_type == "Assign Customer":


            # Fork to handle backdating asynchronously
            assign_customer_pid = os.fork()
            if assign_customer_pid == 0:
                try:
                    iccids_str = ", ".join(map(str, iccids))
                    backdating_id_query = f"""SELECT id FROM vw_combined_rev_service_products WHERE iccid IN ('{iccids_str}')"""
                    backdating_result = database.execute_query(backdating_id_query, True)
                    backdating_id = backdating_result['id'].tolist() if not backdating_result.empty else []

                    if backdating_id:
                        # Existing data handling
                        try:
                            result = database.get_data('rev_service_false', {"id": 1}, ["rev_service_ids"])
                            existing_data = result["rev_service_ids"].iloc[0] if not result.empty else None
                        except Exception as e:
                            logging.info(f"Data fetch error: {e}")
                            existing_data = None

                        # Data parsing
                        existing_ids = []
                        try:
                            if existing_data and not pd.isna(existing_data):
                                parsed_data = json.loads(existing_data) if isinstance(existing_data, str) else existing_data
                                if isinstance(parsed_data, dict):
                                    existing_ids = parsed_data.get("id", [])
                                elif isinstance(parsed_data, list):
                                    existing_ids = parsed_data
                                else:
                                    logging.info(f"Unexpected data format: {type(parsed_data)}")
                                    existing_ids = []
                        except Exception as e:
                            logging.info(f"Data parsing error: {e}")

                        # Merge and update
                        merged_ids = list(set(existing_ids + backdating_id))
                        try:
                            database.update_dict(
                                'rev_service_false',
                                {"rev_service_ids": json.dumps({"id": merged_ids})},
                                {"id": 1}
                            )
                            logging.info("Customer assignment backdating updated successfully!")
                        except Exception as e:
                            logging.info(f"Database update failed: {e}")
                    else:
                        logging.info("No backdating IDs found for customer assignment.")
                except Exception as e:
                    logging.info(f"Customer assignment backdating error: {e}")
                finally:
                    os._exit(0)  # Critical for child process cleanup
            else:
                logging.info("Customer assignment backdating handled asynchronously.")

        if Change_type == "Assign Customer":
            # Fetch role module data with efficient query
            role_module_data = dbs.get_data(
                "role_module",
                {"role": role},
                ["sub_module"],
            )

            # Initialize default status
            module_status = False


            if not role_module_data.empty:
                try:
                    # Parse JSON safely with fallback
                    sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                    # Strict nested check
                    if "People" in sub_modules:
                        people_modules = sub_modules["People"]
                        if isinstance(people_modules, list):  # Ensure it's a list
                            module_status = "Billing Platform Customers" in people_modules
                    # Strict nested check
                    if "People" in sub_modules:
                        people_modules = sub_modules["People"]
                        if isinstance(people_modules, list):  # Ensure it's a list
                            module_status = "Billing Platform Customers" in people_modules

                except json.JSONDecodeError:
                    logging.error(f"Invalid JSON in sub_module for role: {role}")
                except KeyError:
                    pass  # People section not present
                except Exception as e:
                    logging.error(f"Unexpected error processing modules: {str(e)}")
                except json.JSONDecodeError:
                    logging.error(f"Invalid JSON in sub_module for role: {role}")
                except KeyError:
                    pass  # People section not present
                except Exception as e:
                    logging.error(f"Unexpected error processing modules: {str(e)}")

            # module_status = dbs.get_data("module",  {"module_name": "Billing Platform Customers"},["is_active"]
            #                                         ).iloc[0, 0]

            if module_status == True:
                # Extract all device data upfront
                device_ids = []
                rev_customer_ids = []
                change_requests = []
                effective_dates = []

                for device in create_new_bulk_change_request_dict:
                    cr = json.loads(device.get('change_request', '{}'))
                    device_ids.append(cr.get('DeviceId'))
                    rev_customer_ids.append(cr.get('RevCustomerId'))
                    change_requests.append(cr)
                    effective_dates.append(cr.get('EffectiveDate'))

                # Batch check device existence
                valid_devices = set()
                if device_ids:
                    db = DB(tenant_database, **db_config)
                    table = "mobility_device" if "Telegence" in service_provider else "device"
                    query = f"SELECT id FROM {table} WHERE id IN ({','.join(map(str, device_ids))})"
                    valid_devices = set(db.execute_query(query, True)['id'].tolist())

                # Batch check customer existence
                valid_customers = set()
                if rev_customer_ids:
                    db = DB(tenant_database, **db_config)
                    # Convert to quoted strings
                    quoted_ids = [f"'{str(id)}'" for id in rev_customer_ids]
                    query = f"""
                        SELECT rev_customer_id
                        FROM revcustomer
                        WHERE rev_customer_id IN ({','.join(map(str, quoted_ids))})
                    """
                    valid_customers = set(db.execute_query(query, True)['rev_customer_id'].tolist())

                # Prepare batch operations
                device_tenant_updates = []
                log_entries = []
                error_entries = []
                now = datetime.datetime.utcnow()

                for idx, (device_id, rev_id, cr) in enumerate(zip(device_ids, rev_customer_ids, change_requests)):
                    # Validate device and customer
                    device_valid = device_id in valid_devices
                    customer_valid = rev_id in valid_customers

                    if not device_valid or not customer_valid:
                        error_text = ""
                        if not device_valid:
                            error_text = "AMOP Device not found"
                        elif not customer_valid:
                            error_text = "Customer not found"

                        error_entries.append({
                            'device_id': device_id,
                            'error': error_text
                        })

                        log_entries.append({
                            'bulk_change_id': bulkchange_id,
                            'has_errors': True,
                            'log_entry_description': 'AMOP Customer Assignment',
                            'm2m_device_change_id': device_id,
                            'processed_by': created_by,
                            'processed_date': now,
                            'response_status': 'ERROR',
                            'error_text': error_text
                        })
                        continue

                    # Prepare DeviceTenant update
                    device_tenant_updates.append({
                        'device_id': device_id,
                        'tenant_id': tenant_id,
                        'customer_id': cr.get('SiteId'),
                        'account_number': rev_id,
                        'account_number_integration_authentication_id': cr.get('IntegrationAuthenticationId'),
                        'is_active': True,
                        'id_deleted': False,
                        **({'created_by': created_by, 'created_date': now} if idx == 0 else {}),
                        'modified_by': created_by,
                        'modified_date': now
                    })

                    # Prepare success log
                    log_entries.append({
                        'bulk_change_id': bulkchange_id,
                        'has_errors': False,
                        'log_entry_description': 'AMOP Customer Assignment',
                        'm2m_device_change_id': device_id,
                        'processed_by': created_by,
                        'processed_date': now,
                        'response_status': 'PROCESSED',
                        'response_text': 'ok'
                    })

                # Batch update DeviceTenant records
                if device_tenant_updates:
                    db = DB(tenant_database, **db_config)
                    try:
                        # Using bulk update/insert with your existing methods
                        existing_records = db.get_data(
                            "device_tenant",
                            {"device_id": device_ids},
                            ["device_id", "tenant_id", "id"]
                        )

                        update_data = []
                        insert_data = []
                        for record in device_tenant_updates:
                            existing = existing_records[
                                (existing_records['device_id'] == record['device_id']) &
                                (existing_records['tenant_id'] == tenant_id)
                            ]
                            if not existing.empty:
                                update_data.append({
                                    'id': existing['id'].iloc[0],
                                    **record
                                })
                            else:
                                insert_data.append(record)

                        if update_data:
                            db.update_dict("device_tenant", update_data, "id")
                        if insert_data:
                            db.insert_data(insert_data, "device_tenant")
                    except Exception as e:
                        logging.error(f"Bulk DeviceTenant update failed: {str(e)}")

                # Batch insert logs
                if log_entries:
                    db = DB(tenant_database, **db_config)
                    db.insert_data(log_entries, "sim_management_bulk_change_log")

                # Batch stored procedure execution
                if device_tenant_updates:
                    try:
                        # Get portal ID
                        sp_data = dbs.get_data(
                            "serviceprovider",
                            {"id": service_provider_id},
                            ["integration_id"]
                        )
                        integration_id = sp_data['integration_id'].iloc[0]

                        portal_data = dbs.get_data(
                            "integration",
                            {"id": integration_id},
                            ["portal_type_id"]
                        )
                        portal_id = portal_data['portal_type_id'].iloc[0]

                        # Prepare TVP data
                        tvp_data = json.dumps([{
                            "device_id": d['device_id'],
                            "tenant_id": tenant_id,
                            "account_number": d['account_number']
                        } for d in device_tenant_updates])

                        # Execute stored procedure
                        db = DB(tenant_database, **db_config)
                        # db.execute_procedure(
                        #     "usp_device_bulk_change_insert_update_device_tenant",
                        #     [bulkchange_id, portal_id, tvp_data]
                        # )
                        try:
                            db_config["database "] = tenant_database
                            conn = psycopg2.connect(**db_config)
                            cur = conn.cursor()

                            cur.callproc('public.usp_device_bulk_change_insert_update_device_tenant', [int(bulkchange_id), int(portal_id),device_tenant_updates])
                            result = cur.fetchone()[0]  # Fetch the OUT parameter valueprint("Result:", result) cur.close() conn.close()
                        except Exception as e:
                            logging.info(
                                f"Error usp_device_bulk_change_insert_update_device_tenant: {e}"
                            )

                        # Cross-provider updates
                        rate_plan_devices = [
                            (cr['DeviceId'], effective_date)
                            for cr, effective_date in zip(change_requests, effective_dates)
                            if cr.get('CustomerRatePlanId') or cr.get('CustomerRatePoolId')
                        ]

                        for device_id, eff_date in rate_plan_devices:
                            # db.execute_procedure(
                            #     "usp_update_cross_provider_device_history",
                            #     [device_id, None, portal_id, tenant_id, service_provider_id, eff_date]
                            # )


                            try:
                                db_config["database "] = tenant_database
                                logging.info(f'db_config - {db_config}')
                                conn = psycopg2.connect(**db_config)
                                cur = conn.cursor()

                                logging.info(f' portal_id {portal_id}')

                                cur.callproc('public.usp_update_cross_provider_device_history', [int(device_id), None, int(portal_id),int(tenant_id), int(service_provider_id), eff_date ])
                                result = cur.fetchone()[0]  # Fetch the OUT parameter valueprint("Result:", result) cur.close() conn.close()
                                logging.info(result, "234")
                            except Exception as e:
                                logging.info(
                                    f"Error usp_update_cross_provider_device_history: {e}")
                    except Exception as e:
                        logging.error(f"Stored procedure error: {str(e)}")

                # Update bulk request status
                final_status = 'PROCESSED' if not error_entries else 'ERROR'
                db.update_dict(
                    'sim_management_bulk_change_request',
                    {
                        'status': final_status,
                        'modified_by': created_by,
                        'modified_date': now
                    },
                    {'bulk_change_id': bulkchange_id}
                )

            else:
                # RevCustomer Module is OFF
                # Prepare TVP data
                databases = DB(tenant_database, **db_config_withoutfilter)
                integration_id = databases.get_data(
                    "serviceprovider", {"id": service_provider_id}, ["integration_id"]
                )["integration_id"].to_list()[0]
                portal_id = databases.get_data(
                    "integration", {"id": integration_id}, ["portal_type_id"]
                )["portal_type_id"].to_list()[0]
                tvp_data = []
                for device in create_new_bulk_change_request_dict:
                    change_request = json.loads(device.get('change_request', '{}'))
                    device_id = change_request.get('DeviceId')
                    tvp_data.append((
                        change_request.get('DeviceId'),
                        tenant_id,
                        change_request.get('SiteId')
                    ))

                logging.info(db_config, "111111111111111111111")
                success_count = 0
                error_count = 0
                try:
                    db_config["database"] = tenant_database  # Fixed space in key name
                    conn = psycopg2.connect(**db_config_withoutfilter)
                    cur = conn.cursor()

                    updated_values = json.dumps(tvp_data)
                    logging.info(f'{portal_id} , {tvp_data}')
                    cur.callproc('public.usp_device_bulk_change_assign_non_rev_customer', [int(bulkchange_id), int(portal_id), updated_values])
                    result = cur.fetchone()[0]  # Assuming result is the number of successful updates
                    success_count = result
                    error_count = len(tvp_data) - success_count  # Calculate errors based on the result

                    cur.close()
                    conn.close()
                except Exception as e:
                    logging.info(f"Error usp_device_bulk_change_assign_non_rev_customer: {e}")
                    error_count = len(tvp_data)  # If exception, all devices errored
                    success_count = 0

                # Update bulk change status and counts
                databases.update_dict(
                    'sim_management_bulk_change',
                    {'status': 'PROCESSED', 'success': success_count, 'errors': error_count},
                    {'id': bulkchange_id}
                )

                # Update bulk change status and counts
                databases.update_dict(
                    'sim_management_bulk_change_request',
                    {'status': 'PROCESSED'},
                    {'bulk_change_id': bulkchange_id}
                )

                # Create success logs with error tracking
                log_entries = []
                for device in create_new_bulk_change_request_dict:
                    change_request = json.loads(device.get('change_request', '{}'))
                    device_id = change_request.get('DeviceId')
                    # Assume error if not successful; adjust based on actual error tracking
                    has_errors = False  # Placeholder - replace with actual error check per device
                    log_entry = {
                        'bulk_change_id': bulkchange_id,
                        'has_errors': has_errors,
                        'log_entry_description': 'Non-Rev Customer Assignment',
                        'm2m_device_change_id': device_id,
                        'processed_by': created_by,
                        'processed_date': datetime.datetime.utcnow(),
                        'response_status': 'PROCESSED' if not has_errors else 'ERROR',
                        'response_text': 'ok' if not has_errors else 'Error details here'
                    }
                    log_entries.append(log_entry)

                databases.insert_data(log_entries, 'sim_management_bulk_change_log')

                # Update inventory customer info based on SiteId
                site_to_customer = {}
                iccid_site_pairs = []

                for device in create_new_bulk_change_request_dict:
                    change_request = json.loads(device.get('change_request', '{}'))
                    site_id = change_request.get('SiteId')
                    iccid = change_request.get('ICCID')
                    if site_id and iccid:
                        iccid_site_pairs.append((iccid, site_id))
                        if site_id not in site_to_customer:
                            site_to_customer[site_id] = None  # Placeholder for customer data

                # Fetch customer data for all unique SiteIds
                if site_to_customer:
                    site_ids = list(site_to_customer.keys())
                    customers_data = databases.get_data(
                        "customers",
                        {"id": site_ids},
                        ["id", "customer_id", "customer_name"]
                    )

                    logging.info(f'customers_data - {customers_data}')
                    # Update the site_to_customer mapping
                    for _, row in customers_data.iterrows():
                        site_to_customer[row['id']] = {
                            'customer_id': row['id'],
                            'customer_name': row['customer_name']
                        }

                        logging.info(f'site_to_customer - {site_to_customer}')

                # Fetch all old inventory data for the ICCIDs in a single query
                if iccid_site_pairs:
                    iccid_list = [iccid for iccid, _ in iccid_site_pairs]
                    old_inventory_data = databases.get_data(
                        'sim_management_inventory',
                        {'iccid': iccid_list, "is_active": True, "tenant_id": tenant_id},
                        ['iccid', 'customer_id', 'customer_name', 'id', 'service_provider_id',
                        'mobility_device_id', 'msisdn', 'imei', 'device_status_id', 'sim_status', 'device_id','foundation_account_number',
                        'billing_account_number']
                    )
                    # Fix: Use .empty attribute instead of direct boolean evaluation
                    old_inventory_map = {row['iccid']: row for _, row in old_inventory_data.iterrows()} if not old_inventory_data.empty else {}
                else:
                    old_inventory_map = {}

                # Lists to collect history records
                action_history_records = []
                mobility_history_records = []
                logging.info(f'iccid_site_pairsiccid_site_pairsiccid_site_pairsiccid_site_pairs {iccid_site_pairs},{site_to_customer}')
                # Update inventory for each ICCID
                for iccid, site_id in iccid_site_pairs:
                    old_inventory = old_inventory_map.get(iccid)
                    if old_inventory.empty:
                        logging.info(f"No existing inventory record for ICCID {iccid}")
                        continue
                    logging.info('customersisteeee',site_to_customer)
                    site_to_customer = {str(k): v for k, v in site_to_customer.items()}
                    site_id = str(site_id)
                    logging.info('site_to_customersite_to_customersite_to_customer',site_to_customer)
                    customer_info = site_to_customer.get(site_id)
                    logging.info(customer_info, site_to_customer.get(site_id), site_id, "111111111111111111111")
                    if customer_info:
                        # Update the inventory with new customer info
                        databases.update_dict(
                            'sim_management_inventory',
                            {
                                'customer_id': customer_info['customer_id'],
                                'customer_name': customer_info['customer_name']
                            },
                            {'iccid': iccid, "is_active": True, "tenant_id": tenant_id}
                        )

                        # Prepare action history record
                        action_history_data = {
                            'sim_management_inventory_id': old_inventory['id'],
                            'bulk_change_id': bulkchange_id,
                            'iccid': iccid,
                            'previous_value':  old_inventory['customer_name'],
                            'current_value': customer_info['customer_name'],
                            'changed_field': 'customer_assignment',
                            'change_event_type': 'Assign Customer',
                            'date_of_change': datetime.datetime.utcnow(),
                            'changed_by': created_by,
                            'tenant_id': tenant_id,
                            'service_provider_id': old_inventory['service_provider_id'],
                            'm2m_device_id': old_inventory['device_id'],
                            'mobility_device_id': old_inventory['mobility_device_id'],
                            'is_active': True,
                            'is_deleted': False
                        }
                        action_history_records.append(action_history_data)

                        # Prepare mobility device history record
                        mobility_history_data = {
                            'changed_date': datetime.datetime.utcnow(),
                            'id': old_inventory['mobility_device_id'],
                            'service_provider_id': old_inventory['service_provider_id'],
                            'iccid': iccid,
                            'msisdn': old_inventory['msisdn'],
                            'imei': old_inventory['imei'],
                            'device_status_id': old_inventory['device_status_id'],
                            'status': old_inventory['sim_status'],
                            'customer_id': customer_info['customer_id'],
                            'created_by': created_by,
                            'created_date': datetime.datetime.utcnow(),
                            'tenant_id': tenant_id,
                            'is_active': True,
                            'is_deleted': False,
                            'foundation_account_number':old_inventory['foundation_account_number'],
                            'billing_account_number':old_inventory['billing_account_number'],
                            'is_pushed':False
                            # Include other fields as necessary from old_inventory
                        }
                        mobility_history_records.append(mobility_history_data)
                    else:
                        logging.info(f"No customer found for SiteId {site_id} (ICCID: {iccid})")

                # Bulk insert into action history
                if action_history_records:
                    databases.insert_data(action_history_records, 'sim_management_inventory_action_history')

                # Bulk insert into mobility device history
                if mobility_history_records:
                    databases.insert_data(mobility_history_records, 'mobility_device_history')

                if tenant_name not in ("Altaworx Test", "Altaworx", "Altaworx - Go Tech"):
                    try:
                        query=f'''select parent_tenant_id from tenant where tenant_name='{tenant_name}'
                        '''
                        parent_tenant_id=dbs.execute_query(query,True)['parent_tenant_id'].to_list()[0]
                        if parent_tenant_id:
                            parent_tenant_query = f"SELECT tenant_name FROM tenant WHERE id = {int(parent_tenant_id)}"
                            parent_tenant_name = dbs.execute_query(parent_tenant_query, True)["tenant_name"].iloc[0]
                            tenant_name = parent_tenant_name

                    except Exception as e:
                        logging.error(f"Unexpected error processing modules: {str(e)}")

                # Get bulk change data
                bulk_change = databases.get_data('sim_management_bulk_change', {"id": bulkchange_id}).to_dict(orient="records")
                logging.info(f"update_bulk_change_data bulk change is {bulk_change}")
                for dict_ in bulk_change:
                    dict_.pop("created_date", None)
                    dict_.pop("modified_date", None)
                    dict_.pop("processed_date",None)
                # Get bulk change request data
                bulk_change_request = databases.get_data(
                        "sim_management_bulk_change_request",
                        {"bulk_change_id": bulkchange_id},  # Filter condition
                        [
                            "iccid",
                            "subscriber_number",
                            "m2m_id",
                            "bulk_change_id",
                            "tenant_name",
                            "created_by",
                            "processed_by",
                            "status",
                            "device_id",
                            "is_active",
                            "is_deleted",
                            "change_request",
                        ],  # Fields to retrieve
                    ).to_dict("records")
                logging.info(f"update_bulk_change_data got request data")
                #databases.get_data('sim_management_bulk_change_request', {"bulk_change_id": bulkchange_id}).to_dict(orient="records")

                # Create the final data structure
                data = {
                    'sim_management_bulk_change': bulk_change,
                    'sim_management_bulk_change_request': bulk_change_request
                }
                logging.info(f"update_bulk_change_data data sending to save_data_10 {bulkchange_id} {data}")
                try:
                    data_transfer = DataTransfer()
                    bulk_change_id_10=data_transfer.save_data_to_10("bulk_change", data, tenant_name=tenant_name)
                    update_data = databases.update_dict(
                    "sim_management_bulk_change",
                    {"bulk_change_id_10": bulk_change_id_10,
                    "progress": 'Sync Complete'},
                    {"id": bulkchange_id},
                )
                except Exception as e:
                    logging.exception(f"Error transferring data to 10: {e}")



        # Fetch role module data with efficient query
        role_module_data = dbs.get_data(
            "role_module",
            {"role": role},
            ["sub_module"],
        )

        # Initialize default status
        module_status = False

        if not role_module_data.empty:
            try:
                # Parse JSON safely with fallback
                sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                # Strict nested check
                if "People" in sub_modules:
                    people_modules = sub_modules["People"]
                    if isinstance(people_modules, list):  # Ensure it's a list
                        module_status = "Billing Platform Customers" in people_modules

            except json.JSONDecodeError:
                logging.error(f"Invalid JSON in sub_module for role: {role}")
            except KeyError:
                pass  # People section not present
            except Exception as e:
                logging.error(f"Unexpected error processing modules: {str(e)}")


        if Change_type == "Edit Username/Cost Center" and module_status == False:
        # if Change_type == "Edit Username/Cost Center":
            databases = DB(tenant_database, **db_config)

            # Initialize variables
            iccid_updates = []
            action_history_records = []
            mobility_history_records = []
            success_count = 0
            error_count = 0
            device_success = []
            device_errors = []

            try:
                # Extract ICCIDs and their updates
                for device in create_new_bulk_change_request_dict:
                    change_request = json.loads(device.get('change_request', '{}'))
                    iccid = device.get('iccid')
                    new_username = change_request.get('ContactName')
                    new_cost_center = change_request.get('CostCenter1')
                    iccid_updates.append({
                        'iccid': iccid,
                        'new_username': new_username,
                        'new_cost_center': new_cost_center
                    })

                # Fetch existing inventory data
                if iccid_updates:
                    iccid_list = [update['iccid'] for update in iccid_updates]
                    old_inventory_data = databases.get_data(
                        'sim_management_inventory',
                        {'iccid': iccid_list, "is_active": True, "tenant_id": tenant_id},
                        ['iccid', 'username', 'cost_center', 'id', 'service_provider_id',
                        'mobility_device_id', 'msisdn', 'imei', 'device_status_id',
                        'sim_status', 'device_id', 'customer_id','foundation_account_number',
                        'billing_account_number']

                    )
                    old_inventory_map = {row['iccid']: row for _, row in old_inventory_data.iterrows()} if not old_inventory_data.empty else {}
                else:
                    old_inventory_map = {}

                # Process each ICCID update
                for update in iccid_updates:
                    iccid = update['iccid']
                    new_username = update['new_username']
                    new_cost_center = update['new_cost_center']

                    try:
                        old_inventory = old_inventory_map.get(iccid)
                        if old_inventory.empty:
                            logging.info(f"No inventory record found for ICCID {iccid}")
                            device_errors.append(iccid)
                            continue

                        update_fields = {}
                        # Check username change
                        if new_username is not None and new_username != old_inventory['username']:
                            update_fields['username'] = new_username
                        # Check cost center change
                        if new_cost_center is not None and new_cost_center != old_inventory['cost_center']:
                            update_fields['cost_center'] = new_cost_center

                        if not update_fields:
                            logging.info(f"No changes required for ICCID {iccid}")
                            device_success.append(iccid)
                            continue

                        # Update inventory
                        databases.update_dict(
                            'sim_management_inventory',
                            update_fields,
                            {'iccid': iccid, "is_active": True, "tenant_id": tenant_id}
                        )

                        # Create action history records
                        for field, value in update_fields.items():
                            action_history_records.append({
                                'sim_management_inventory_id': old_inventory['id'],
                                'bulk_change_id': bulkchange_id,
                                'iccid': iccid,
                                'previous_value': old_inventory[field],
                                'current_value': value,
                                'changed_field': field,
                                'change_event_type': "Edit Username/Cost Center",
                                'date_of_change': datetime.datetime.utcnow(),
                                'changed_by': created_by,
                                'tenant_id': tenant_id,
                                'service_provider_id': old_inventory['service_provider_id'],
                                'm2m_device_id': old_inventory['device_id'],
                                'mobility_device_id': old_inventory['mobility_device_id'],
                                'is_active': True,
                                'is_deleted': False
                            })

                        # Create mobility history record
                        mobility_history_records.append({
                            'changed_date': datetime.datetime.utcnow(),
                            'id': old_inventory['mobility_device_id'],
                            'service_provider_id': old_inventory['service_provider_id'],
                            'iccid': iccid,
                            'msisdn': old_inventory['msisdn'],
                            'imei': old_inventory['imei'],
                            'device_status_id': old_inventory['device_status_id'],
                            'status': old_inventory['sim_status'],
                            'customer_id': old_inventory['customer_id'],
                            'created_by': created_by,
                            'created_date': datetime.datetime.utcnow(),
                            'tenant_id': tenant_id,
                            'is_active': True,
                            'is_deleted': False,
                            'foundation_account_number':old_inventory['foundation_account_number'],
                            'billing_account_number':old_inventory['billing_account_number'],
                            'is_pushed':False
                        })


                        device_success.append(iccid)

                    except Exception as e:
                        logging.info(f"Error processing ICCID {iccid}: {str(e)}")
                        device_errors.append(iccid)

                # Bulk insert action history
                if action_history_records:
                    databases.insert_data(action_history_records, 'sim_management_inventory_action_history')

                # Bulk insert mobility history
                if mobility_history_records:
                    databases.insert_data(mobility_history_records, 'mobility_device_history')

                # Create log entries
                log_entries = []
                for device in create_new_bulk_change_request_dict:
                    iccid = device.get('iccid')
                    has_error = iccid in device_errors
                    log_entries.append({
                        'bulk_change_id': bulkchange_id,
                        'has_errors': has_error,
                        'log_entry_description': 'Username/Cost Center Update',
                        'm2m_device_change_id': device.get('id'),
                        'processed_by': created_by,
                        'processed_date': datetime.datetime.utcnow(),
                        'response_status': 'PROCESSED' if not has_error else 'ERROR',
                        'response_text': 'Successfully updated' if not has_error else f"Error updating ICCID {iccid}"
                    })


                if log_entries:
                    databases.insert_data(log_entries, 'sim_management_bulk_change_log')

                # Update counts
                success_count = len(device_success)
                error_count = len(device_errors)

                # Update bulk change status
                databases.update_dict(
                    'sim_management_bulk_change',
                    {
                        'status': 'PROCESSED',
                        'success': success_count,
                        'errors': error_count
                    },
                    {'id': bulkchange_id}
                )

                # Update individual change requests
                if device_success:
                    databases.update_dict(
                        'sim_management_bulk_change_request',
                        {'status': 'PROCESSED'},
                        {'bulk_change_id': bulkchange_id, 'iccid': device_success}
                    )
                if device_errors:
                    databases.update_dict(
                        'sim_management_bulk_change_request',
                        {'status': 'ERROR'},
                        {'bulk_change_id': bulkchange_id, 'iccid': device_errors}
                    )

            except Exception as e:
                logging.info(f"Bulk change processing failed: {str(e)}")
                error_count = len(create_new_bulk_change_request_dict)
                databases.update_dict(
                    'sim_management_bulk_change',
                    {'status': 'ERROR', 'success': 0, 'errors': error_count},
                    {'id': bulkchange_id}
                )
                databases.update_dict(
                    'sim_management_bulk_change_request',
                    {'status': 'ERROR'},
                    {'bulk_change_id': bulkchange_id}
                )

            # Get final data
            bulk_change = database.get_data('sim_management_bulk_change', {"id": bulkchange_id}).to_dict(orient="records")
            bulk_change_request = database.get_data('sim_management_bulk_change_request', {"bulk_change_id": bulkchange_id}).to_dict(orient="records")

            data =  {
                'sim_management_bulk_change': bulk_change,
                'sim_management_bulk_change_request': bulk_change_request
            }


            try:
                data_transfer = DataTransfer()
                bulk_change_id_10=data_transfer.save_data_to_10("bulk_change", data, tenant_name=tenant_name)
            except Exception as e:
                logging.exception(f"Error transferring data to 10: {e}")


        if z_access_token:


            try:
                if module_status == False and  Change_type == "Assign Customer":
                    print("assign ccustomer from payload came here ")

                    print("started the sync lambda")

                    print(tenant, "qaaaaaaaaaaa")

                    lambda_client = boto3.client('lambda')
                    data_sync = {
                        "data": {
                            "data": {
                                "key_name": "verizon_inventory",
                                "path": "/lambda_sync_jobs_",
                                "tenant_name": tenant
                            }
                        }
                    }

                    try:
                        response_sync = lambda_client.invoke(
                            FunctionName='optimization_sync_lambda',
                            InvocationType='Event',
                            Payload=json.dumps(data_sync),
                        )
                        logging.info(f"Lambda async invoke response (delayed): {response_sync}")
                    except Exception as e:
                        logging.exception(f"Error in child process calling sync lambda: {e}")


            except Exception as e:
                    print(f"Error: {e}")


        return response_data
    except Exception as e:
        # Log the exception and return failure response
        logging.exception(f"An error occurred: {e}")
        if z_access_token:
            response = {
                "message": "Unable to perform the bulk change action",
                "exception": str(e),
                "status_code": 500,
            }
        else:
            response = {
                "flag": False,
                "message": "Unable to perform the bulk change action",
            }

        # Capture and log the error details in the database
        error_type = str(type(e).__name__)
        try:
            error_data = {
                "service_name": "Sim Management",
                "created_date": start_time,
                "error_message": "Unable to perform the bulk change action",
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": "",
                "module_name": "update_bulk_change_data",
                "request_received_at": request_received_at,
            }
            dbs.log_error_to_db(error_data, "error_log_table")
        except:
            pass

        return response


