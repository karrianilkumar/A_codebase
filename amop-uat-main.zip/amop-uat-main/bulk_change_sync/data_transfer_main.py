# Standard library imports
import os
import re
import copy
import json
import math
import time
import traceback
import uuid
import logging
from datetime import datetime, timedelta

# Third-party library imports
import numpy as np
import pandas as pd
import requests
import boto3
import queue
import psycopg2
from psycopg2 import pool as pg_pool
from psycopg2.extras import execute_values
from sqlalchemy import create_engine, exc, text
from tenacity import retry, stop_after_attempt, wait_fixed
from dotenv import load_dotenv
import pytds

# Local application imports
from common_utils.logging_utils import Logging
logging = Logging()

class DataTransfer:
    pg_connection_pool = None
    mssql_connection_pool = None
    _mssql_max_pool_size = 15
    _pg_pools = {}
    _mssql_pools = {}

    def __init__(self):
        pass

    @classmethod
    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
    def create_connection(
        self,
        db_type="",
        host="",
        db_name="",
        username="",
        password="",
        port="",
        driver="",
        max_retry=3,
    ):
        connection = None
        key = f"{host}:{port}/{db_name}"
        logging.info(f"Creating connection for {key}")

        if db_type == "postgresql":
            logging.info(f"Creating PostgreSQL connection for {key}")
            if key not in self._pg_pools:
                logging.info(f"Creating PostgreSQL pool for {key}")
                self._pg_pools[key] = pg_pool.SimpleConnectionPool(
                    minconn=1,
                    maxconn=20,
                    host=host,
                    port=port,
                    database=db_name,
                    user=username,
                    password=password,
                )
            try:
                return self._pg_pools[key].getconn()
            except Exception as e:
                logging.error(f"Failed to get PostgreSQL connection: {e}")
                raise
        elif db_type == "postgresql__":
            try:
                logging.info(f"creating postgresql connection")

                connection = psycopg2.connect(
                    host=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port,
                )
                logging.info("Connection to PostgreSQL DB successful")
            except Exception as e:
                logging.error(f"Failed to connect to PostgreSQL DB: {e}")

        elif db_type == "mssql":
            # No native pool in pytds, so simulate pooling manually
            if key not in self._mssql_pools:
                logging.info(f"Creating MSSQL connection pool for {key}")
                self._mssql_pools[key] = []

            pool = self._mssql_pools[key]
            if pool:
                logging.info(f"Reusing MSSQL connection from pool: {key}")
                return pool.pop()
            else:
                try:
                    active_conns = len(pool)
                    if active_conns >= self._mssql_max_pool_size:
                        logging.info(f"Creating new MSSQL connection Failed, Pool Size limit reached: {key}")
                        raise Exception(f"MSSQL pool max size ({self._mssql_max_pool_size}) reached for {key}")
                    logging.info(f"Creating new MSSQL connection: {key}")
                    return pytds.connect(
                        server=host,
                        port=port,
                        database=db_name,
                        user=username,
                        password=password,
                    )
                except Exception as e:
                    logging.error(f"Failed to connect to MSSQL DB: {e}")
                    raise
        return connection

    @classmethod
    def release_connection(self, db_type, host, port, db_name, conn):
        key = f"{host}:{port}/{db_name}"

        if db_type == "postgresql" and key in self._pg_pools:
            self._pg_pools[key].putconn(conn)
            logging.info(f"Returned PostgreSQL connection to pool: {key}")

        elif db_type == "mssql":
            if key not in self._mssql_pools:
                self._mssql_pools[key] = []
            self._mssql_pools[key].append(conn)
            logging.info(f"Returned MSSQL connection to simulated pool: {key}")

    @classmethod
    def close_all_pools(self):
        for key, pool in self._pg_pools.items():
            pool.closeall()
            logging.info(f"Closed PostgreSQL pool: {key}")
        self._pg_pools.clear()

        for key, pool in self._mssql_pools.items():
            for conn in pool:
                try:
                    conn.close()
                except Exception as e:
                    logging.warning(f"Failed to close MSSQL connection in pool {key}: {e}")
            logging.info(f"Closed MSSQL simulated pool: {key}")
        self._mssql_pools.clear()

    def send_msg_sim_management_trigger_queue(self, message_body):
        try:
            print("-----------", message_body)
            # Initialize the SQS client
            print("calling SQS QUEUEEEEEEEEEEEEEE")
            sqs_client = boto3.client("sqs", region_name="us-east-1")
            message_body["sqs_flag"] = True
            load_dotenv()
            queue_url = os.getenv("BULK_CHANGE_SYNC_TRIGGER_QUEUE")
            logging.info(f"send_msg_sim_management_trigger_queue Queue URL: {queue_url}")
            # queue_url = "https://sqs.us-east-1.amazonaws.com/008971638399/sim_management_trigger_queue_uat.fifo"
            # Send the message to the SQS queue
            message_group_id = str(uuid.uuid4())
            response = sqs_client.send_message(
                QueueUrl=queue_url,
                MessageBody=json.dumps(message_body),
                MessageGroupId=message_group_id,
                MessageDeduplicationId=str(uuid.uuid4()),
            )

            logging.info(
                f"Message sent to SQS queue {queue_url}. Message ID: {response['MessageId']}"
            )
            return response["MessageId"]
        except Exception as e:
            logging.error(f"Error sending message to SQS queue: {e}")
            raise

    def execute_query(self, connection, query, params=None):

        try:
            # Check if params are provided
            start_time = time.time()
            if params:
                # Execute the query with parameters
                logging.info(f"PARAMS are execute_query {params}")
                result_df = pd.read_sql_query(query, connection, params=params)
            else:
                # Execute the query without parameters
                result_df = pd.read_sql_query(query, connection)
            elapsed_time = time.time() - start_time
            logging.info(f"Query executed in {elapsed_time:.3f} seconds")
            return result_df
        except Exception as e:
            elapsed_time = time.time() - start_time
            logging.error(f"Error executing query: {e}")
            logging.info(f"Error executing query :1 {e}")
            logging.info(f"Error executing query 2 after {elapsed_time:.3f} seconds: {e}")
            logging.info(f"Error executing query 3 {elapsed_time:.3f} seconds:{traceback.format_exc()}")
            return None

    def is_valid_table_name(self, table_name):
        pattern = r"^\[\w+\]\.\[\w+\]\.\[\w+\]$"
        return re.match(pattern, table_name) is not None

    def map_cols(self, table_mapping, col_mapping, postgres_data):
        try:
            insert_data = {}

            for table_name, records in postgres_data.items():
                # Get target table names for table_name
                target_tables = table_mapping.get(table_name, [])

                for target_table in target_tables:
                    # Get column mappings for the target table
                    mapping = col_mapping.get(target_table, {})
                    # print(f"Mapiin got for {target_table} is {mapping}")

                    temp_records = [
                        {
                            mapping[key]: value
                            for key, value in record.items()
                            if key in mapping
                        }
                        for record in records
                    ]
                    # print(f"TEmp recs are {temp_records}")
                    insert_data[target_table] = temp_records
            return insert_data
        except Exception as e:
            logging.error(f"Error while mapping columns: {e}")
            return {}

    def replace_nan_with_none(self, data):
        for key, value in data.items():
            if isinstance(
                value, list
            ):  # If the value is a list, loop through each item
                for record in value:
                    for record_key, record_value in record.items():
                        if isinstance(record_value, float) and math.isnan(record_value):
                            record[record_key] = None
            elif isinstance(
                value, dict
            ):  # If the value is a dict, recursively handle it
                self.replace_nan_with_none(value)
            elif isinstance(value, float) and math.isnan(
                value
            ):  # Handle top-level keys
                data[key] = None

    ##to fetch the service providers ids for each tenants separately used to get the serviceprovider ids in generic way
    def load_json(self):
        """
        Loads a JSON file and returns the data.

        :param file_path: Absolute path to the JSON file.
        :return: Parsed JSON data as a dictionary, or None if an error occurs.

        """
        # Define the JSON file path
        FILE_PATH = "tenant_based_serviceproviders.json"
        file_path=FILE_PATH
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                return json.load(file)
        except FileNotFoundError:
            logging.warning(f"Error: JSON file not found at {file_path}")
        except json.JSONDecodeError:
            logging.warning(f"Error: Invalid JSON format in {file_path}")
        except Exception as e:
            logging.exception(f"Unexpected error while reading JSON: {e}")

        return {}  # Return None if an error occurs


    def get_provider_ids(self,json_data, tenant_name, provider_names):
        """Fetches only the IDs of specified providers for a given tenant."""
        return [
            details["id"]
            for provider_name, details in json_data.get(tenant_name, {}).items()
            if provider_name in provider_names
        ]

    def get_transfer_name(self,json_data, tenant_name, provider_names):
        """Fetches only the IDs of specified providers for a given tenant."""
        return_data = [
                        details["transfer_name"]
                        for provider_name, details in json_data.get(tenant_name, {}).items()
                        if provider_name in provider_names
                    ]
        if len(return_data) == 0:
            return None
        return return_data[0]



    def load_env_pgsql(self):
        load_dotenv()
        hostname = os.getenv("LOCAL_DB_HOST")
        port = os.getenv("LOCAL_DB_PORT")
        user = os.getenv("LOCAL_DB_USER")
        password = os.getenv("LOCAL_DB_PASSWORD")
        db_type = os.getenv("LOCAL_DB_TYPE")
        db_name = os.getenv("LOCAL_DB_NAME")
        return hostname, port, user, password, db_type, db_name

    def load_env_mssql(self):
        from_host = os.getenv("FROM_DB_HOST")
        from_port = os.getenv("FROM_DB_PORT")
        from_db = os.getenv("FROM_DB_NAME")
        from_user = os.getenv("FROM_DB_USER")
        from_pwd = os.getenv("FROM_DB_PASSWORD")
        from_db_type = os.getenv("FROM_DB_TYPE")
        from_driver = os.getenv("FROM_DB_DRIVER")
        return (
            from_host,
            from_port,
            from_db,
            from_user,
            from_pwd,
            from_db_type,
            from_driver,
        )



    def is_valid_table_name(self, table_name):
        pattern = r"^\[\w+\]\.\[\w+\]\.\[\w+\]$"
        return re.match(pattern, table_name) is not None
    def delete_data_from_10(self, transfer_name, postgres_data, id_10, table_name_10,ssms_db_name,mssql_conn):
        try:


            if not self.is_valid_table_name(table_name_10):
                full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                print(f"full table name {full_from_table}")
            else:
                full_from_table = table_name_10
            if transfer_name.startswith("customer_rate_plan"):
                self.delete_from_10_customerrp(mssql_conn, id_10, full_from_table)
            #else:
                #dd = self.delete_from_pgsql(mssql_conn, id_10, full_from_table)
        except Exception as e:
            print(f"Error while loading env: {e}")



    def convert_dict_to_dfs(self,data):
        """Converts a dictionary with table-like structure into Pandas DataFrames, handling JSON fields."""

        dfs = {}  # Store DataFrames

        for table_name, records in data.items():
            df = pd.DataFrame(records)  # Convert to DataFrame

            # Flatten any JSON-like columns automatically
            for col in df.columns:
                try:
                    df[col] = df[col].apply(lambda x: json.loads(x) if isinstance(x, str) and x.startswith('{') else x)
                    if df[col].apply(lambda x: isinstance(x, dict)).any():  # If JSON detected, expand
                        df = df.join(pd.json_normalize(df[col])).drop(columns=[col])
                except (json.JSONDecodeError, TypeError):
                    pass  # Ignore non-JSON fields

            dfs[table_name] = df  # Store processed DataFrame

        return dfs



    def function_to_check_sub_tenant_or_parent_name(self, postgres_conn, tenant_name):
        try:
            # SQL query to check tenant information
            query = """
                SELECT id,tenant_name, parent_tenant_id, db_name
                FROM public.tenant
                WHERE tenant_name = %s
                ORDER BY id DESC
                LIMIT 1;
            """

            # Execute the query with the tenant_id
            cursor = postgres_conn.cursor()
            cursor.execute(query, (tenant_name,))
            result = cursor.fetchone()

            # Check if the result exists
            if result:
                tenant_id, tenant_name, parent_tenant_id, db_name = result

                # Determine the flags based on parent_tenant_id
                if parent_tenant_id is not None:
                    parent_query = """
                    SELECT tenant_name
                    FROM public.tenant
                    WHERE id = %s
                    LIMIT 1;
                    """
                    cursor.execute(parent_query, (parent_tenant_id,))
                    parent_result = cursor.fetchone()
                    sub_tenant_name=tenant_name

                    if parent_result:
                        tenant_name = parent_result[0]  # Overwrite with parent tenant name

                else:
                    parent_tenant_id=tenant_id
                    tenant_id=None

                # parent_tenant_flag = True if parent_tenant_id is None else False
                # sub_tenant_flag = not parent_tenant_flag
                return tenant_name,parent_tenant_id,tenant_id,sub_tenant_name

            else:
                # If no result is found, raise an exception
                raise ValueError(f"No tenant found with tenant_id {tenant_name}")
        except Exception as e:
        # Handle any errors that may occur
            logging.info(f"Error occurred: {e}")
            return None, None, None  # Return None if there's an error

    def update_table(self, conn, table_name, data_dict, condition_dict):
        """
        Update a PostgreSQL table using a dictionary.

        :param conn: psycopg2 connection object
        :param table_name: Name of the table to update
        :param data_dict: Dictionary containing column-value pairs to update
        :param condition_dict: Dictionary containing column-value pairs for the WHERE condition
        """
        try:
            # Replace NaN with None in data_dict
            data_dict = {
                k: (None if isinstance(v, float) and math.isnan(v) else v)
                for k, v in data_dict.items()
            }

            # Replace NaN with None in condition_dict
            condition_dict = {
                k: (None if isinstance(v, float) and math.isnan(v) else v)
                for k, v in condition_dict.items()
            }
            # Generate the SET part of the SQL query
            set_clause = ", ".join([f"{col} = %s" for col in data_dict.keys()])

            # Handle condition dict with lists or single values
            where_clause = []
            # print(f"in updat_table val dict is {data_dict}")
            values = list(data_dict.values())

            for col, val in condition_dict.items():
                if isinstance(val, list):
                    # Generate the WHERE clause for IN condition
                    placeholders = ", ".join(["%s"] * len(val))
                    where_clause.append(f"{col} IN ({placeholders})")
                    values.extend(val)  # Add the list values to the values list
                else:
                    # Handle single value condition
                    where_clause.append(f"{col} = %s")
                    values.append(val)

            # Combine WHERE conditions
            if where_clause:
                where_clause = " AND ".join(where_clause)
                sql_query = f"UPDATE {table_name} SET {set_clause} WHERE {where_clause}"
            else:
                sql_query = f"UPDATE {table_name} SET {set_clause}"

            # Print the SQL query and values for debugging
            logging.info(f"Conn in update is {conn}")
            logging.info(f"SQL Query: {sql_query}")
            logging.info(f"Values: {values}")

            # Execute the query
            try:
                with conn.cursor() as cursor:
                    cursor.execute(sql_query, values)
                    conn.commit()
                logging.info("Update successful")
            except Exception as e:
                conn.rollback()
                logging.error(f"Error in updating {e}")
            # finally:
            #     if conn:
            #         conn.close()

        except Exception as e:
            conn.rollback()
            logging.error(f"Error while updating table {table_name}: {e}")
        # finally:
        #     if conn:
        #         conn.close()


    def replace_tenantid_with_fstring(self,query,tenant_id):
        # Replace any instance like tenantid=1 or tenantid = 1 with tenantid={tenant_id}
        updated_query = re.sub(r"\btenantid\s*=\s*\d+", f"tenantid in {tenant_id}", query, flags=re.IGNORECASE)
        return updated_query


    def get_10_data(
        self,
        transfer_name,
        mssql_conn,
        id_10,
        details_list,
        log_status_check_flag,
        main_flag=None,
        main_result_dict=None,
        tenant_id_str=None
    ):
        # main_result_dict = main_result_dict if main_result_dict is not None else {}
        dependent_dict = {}
        where_val_list = []
        keep_trying = False

        try:
            stop_flag = False
            skip_table = False
            if main_flag:
                main_result_dict = {}
                status_results_dict = {}
                for dict_item in details_list:
                    where_col = dict_item["where_col"]
                    table_10_key = dict_item["table_10"]
                    logging.info(f"@@@@@@@@ table {table_10_key}")
                    select_query = dict_item["select_query"]
                    logging.info(f"CHCK Select query is {select_query}")
                    select_query_p = select_query.replace("?", "%s")
                    logging.info(
                        f"select query is {select_query_p} 1.0 id is {id_10}",
                    )
                    logging.info(
                        f"Processing for table {table_10_key} with id_10: {id_10}"
                    )

                    result_df = None
                    try:
                        if "?" in select_query.lower() and where_col == "id_10":
                            params = (id_10,)
                            result_df = self.execute_query(
                                mssql_conn, select_query_p, params=params
                            )
                            logging.info(f"get_10_data : Result df is {result_df}")
                            if transfer_name in [
                                "bulk_change", "bulk_change_mobility", "bulk_change_spectrotel",
                                "bulk_change_mobility_spectrotel", "bulk_change_bulk_update_mobility",
                                "bulk_change_m2m_bulk_update", "bulk_change_mobility_apitesttenant",
                                "bulk_change_apitesttenant", "bulk_change_mobility_altaworx_go_tech",
                                "bulk_change_altaworx_go_tech"
                            ]:
                                logging.info(f"get_10_data------------{id_10}")
                                if table_10_key == "DeviceBulkChange":
                                    status = result_df.get(
                                        "status", result_df.get("Status", [None])
                                    )[0] if result_df is not None else None
                                    logging.info(
                                        f"get_10_data:{id_10} table is {table_10_key} and status got is {status}"
                                    )
                                    status_results_dict[table_10_key] = [status]
                                else:
                                    statuses = result_df.get(
                                        "status", result_df.get("Status", [])
                                    ) if result_df is not None else []
                                    if not isinstance(statuses, list):
                                        statuses = statuses.tolist()
                                    logging.info(
                                        f"get_10_data:::Statuses for {id_10} are {statuses}, type is {type(statuses)}"
                                    )
                                    status_results_dict[table_10_key] = statuses

                        # Process the result
                        if result_df is not None and not result_df.empty:
                            main_result_dict[table_10_key] = result_df.to_dict(
                                orient="records"
                            )
                        else:
                            logging.info(
                                f"Query failed or returned empty for {table_10_key}"
                            )
                    except Exception as e:
                        logging.error(
                            f"Exception in get_10_data main_flag loop for table {table_10_key}: {e}\n{traceback.format_exc()}"
                        )
                        logging.info(
                            f"Exception in get_10_data main_flag loop for table {table_10_key}: {e}\n{traceback.format_exc()}"
                        )
                        main_result_dict[table_10_key] = []

                try:
                    if log_status_check_flag is True:
                        logging.info(
                            f"Need to get status from log table DeviceBulkchnage log {id_10}"
                        )
                        db_name_10 = os.getenv('FROM_DB_NAME')
                        select_query_log = f"select ResponseStatus from {db_name_10}.dbo.DeviceBulkChangeLog WITH (NOLOCK) where BulkChangeId={id_10}"
                        log_query_exec = self.execute_query(mssql_conn, select_query_log)
                        logging.info(f"Result of log Query is {log_query_exec}")
                        log_statuses = log_query_exec.get(
                            "ResponseStatus", log_query_exec.get("ResponseStatus", [])
                        ) if log_query_exec is not None else []
                        if not isinstance(log_statuses, list):
                            log_statuses = log_statuses.tolist()
                        logging.info(
                            f"get_10_data:::log_statuses for {id_10} are {log_statuses}, type is {type(log_statuses)}"
                        )
                        status_results_dict["DeviceBulkChangeLog"] = log_statuses
                except Exception as e:
                    logging.error(
                        f"Exception in get_10_data log_status_check_flag: {e}\n{traceback.format_exc()}"
                    )
                    logging.info(
                        f"Exception in get_10_data log_status_check_flag: {e}\n{traceback.format_exc()}"
                    )

                logging.info(
                    f"get_10_data:::The result statuses are {id_10} ::::{status_results_dict}"
                )
                combined_statuses = [
                    status
                    for statuses in status_results_dict.values()
                    for status in (statuses if isinstance(statuses, list) else [statuses])
                ]
                logging.info(
                    f"get_10_data:::: for id 1.0 {id_10} Total statuses are {combined_statuses}"
                )

                if (
                    "NEW" in combined_statuses
                    or "PROCESSING" in combined_statuses
                    or "PENDING" in combined_statuses
                ):
                    keep_trying = True
                else:
                    keep_trying = False

                logging.info(
                    f"Final main result dict got is and flag is {keep_trying} ---------\n:::"  # {main_result_dict}
                )
                return main_result_dict, keep_trying

            else:
                # Dependent dict logic
                for dict_item in details_list:
                    table_10_key = dict_item["table_10"]
                    logging.info(f"22  Dependent Table {table_10_key}")
                    where_col = dict_item["where_col"]
                    logging.info(f"Dependent where col {where_col}")
                    result_df = None
                    try:
                        if where_col == "id_10":
                            select_query = dict_item["select_query"]
                            logging.info(
                                f"{table_10_key}--Dependent table but where col is id_10 {id_10}"
                            )
                            select_query_id_1 = select_query.replace("?", "%s")
                            params = (id_10,)
                            result_df = self.execute_query(
                                mssql_conn, select_query_id_1, params=params
                            )
                            logging.info(f"@##$@#$@#@#@# result {result_df}")

                        else:
                            logging.info(f"In else of dependent dict")
                            select_query = dict_item["select_query"]
                            if tenant_id_str:
                                select_query = self.replace_tenantid_with_fstring(select_query, tenant_id_str)

                            logging.info(f"Before :::Select query is {select_query}")
                            where_table_name, where_col_name = where_col.split(".")
                            logging.info(f"@@@@ where {where_table_name, where_col_name}")

                            where_vals = [
                                item[where_col_name]
                                for item in main_result_dict.get(where_table_name, [])
                                if item.get(where_col_name) is not None
                            ]
                            where_val_list.extend(where_vals)
                            logging.info(f"{table_10_key}-where val list {where_val_list}")

                            if where_vals:
                                where_tuple = tuple(where_vals)
                                logging.info(f"#### where tuple {where_tuple}")
                                if len(where_tuple) == 1:
                                    where_tuple_str = str(where_tuple[0])
                                    logging.info(
                                        f"where tuple is 1 value {where_tuple_str} type is {type(where_tuple_str)} `('{where_tuple_str}')`"
                                    )
                                    select_query_p = select_query.replace(
                                        "?", f"('{where_tuple_str}')"
                                    )
                                else:
                                    select_query_p = select_query.replace(
                                        "?", str(where_tuple)
                                    )
                                    logging.info(
                                        f"In else select query is {select_query_p}"
                                    )
                                result_df = self.execute_query(mssql_conn, select_query_p)
                                logging.info(f"@##$@#$@#@#@# result {result_df}")
                            else:
                                logging.info(
                                    f"No values found for where clause: {where_col}"
                                )
                                result_df = None

                        if result_df is not None:
                            result_dict = result_df.to_dict(orient="records")
                            dependent_dict[table_10_key] = result_dict
                        else:
                            dependent_dict[table_10_key] = []
                    except Exception as e:
                        logging.error(
                            f"Exception in get_10_data dependent dict for table {table_10_key}: {e}\n{traceback.format_exc()}"
                        )
                        dependent_dict[table_10_key] = []
                logging.info(
                    f"@@@@@@@@@@@@@@@@Returning Final Dependent dict is"
                )
                return dependent_dict, where_val_list

        except Exception as e:
            logging.error(
                f"Error in Bulk Change get_10_data-Fetching data from 1.0 ---{e}\n{traceback.format_exc()}"
            )
            # Return whatever was built so far, or empty
            if main_flag:
                return main_result_dict, True
            else:
                return dependent_dict, where_val_list

    def get_10_data_bak_16_07_25(
        self,
        transfer_name,
        mssql_conn,
        id_10,
        details_list,
        log_status_check_flag,
        main_flag=None,
        main_result_dict=None,
        tenant_id_str=None
    ):
        try:
            dependent_dict = {}
            where_val_list = []
            stop_flag = False
            skip_table = False
            if main_flag:
                main_result_dict = {}
                status_results_dict = {}
                # logging.info(f"DETAILS LIST IS {details_list}")
                for dict_item in details_list:
                    where_col = dict_item["where_col"]
                    table_10_key = dict_item["table_10"]
                    logging.info(f"@@@@@@@@ table {table_10_key}")
                    select_query = dict_item["select_query"]
                    logging.info(f"CHCK Select query is {select_query}")
                    select_query_p = select_query.replace("?", "%s")
                    logging.info(
                        f"select query is {select_query_p} 1.0 id is {id_10}",
                    )
                    logging.info(
                        f"Processing for table {table_10_key} with id_10: {id_10}"
                    )

                    if "?" in select_query.lower() and where_col == "id_10":
                        params = (id_10,)
                        retries = 10  # Maximum retries
                        delay = 5
                        result_df = self.execute_query(
                            mssql_conn, select_query_p, params=params
                        )
                        logging.info(f"get_10_data : Result df is {result_df}")
                        if transfer_name in ["bulk_change", "bulk_change_mobility", "bulk_change_spectrotel","bulk_change_mobility_spectrotel","bulk_change_bulk_update_mobility","bulk_change_m2m_bulk_update","bulk_change_mobility_apitesttenant","bulk_change_apitesttenant","bulk_change_mobility_altaworx_go_tech","bulk_change_altaworx_go_tech"]:
                            logging.info(f"get_10_data------------{id_10}")
                            if table_10_key == "DeviceBulkChange":
                                status = result_df.get(
                                    "status", result_df.get("Status", [None])
                                )[
                                    0
                                ]  # Get status safely
                                logging.info(
                                    f"get_10_data:{id_10} table is {table_10_key} abd status got us {status}"
                                )
                                status_results_dict[table_10_key] = [status]
                            else:
                                statuses = result_df.get(
                                    "status", result_df.get("Status", [])
                                )
                                if not isinstance(
                                    statuses, list
                                ):  # Convert to a list if it's a pandas Series
                                    statuses = statuses.tolist()
                                logging.info(
                                    f"get_10_data:::Statuses for {id_10} are {statuses}, type is {type(statuses)}"
                                )
                                status_results_dict[table_10_key] = statuses

                        # Process the result
                        if result_df is not None and not result_df.empty:
                            main_result_dict[table_10_key] = result_df.to_dict(
                                orient="records"
                            )
                        else:
                            logging.error(
                                f"Query failed after retries for {table_10_key}"
                            )

                if log_status_check_flag is True:
                    logging.info(
                        f"Need to get status from log table DeviceBulkchnage log {id_10}"
                    )
                    db_name_10=os.getenv('FROM_DB_NAME')
                    select_query_log = f"select ResponseStatus from {db_name_10}.dbo.DeviceBulkChangeLog where BulkChangeId={id_10}"
                    log_query_exec = self.execute_query(mssql_conn, select_query_log)
                    logging.info(f"Result of log Query is {log_query_exec}")
                    log_statuses = log_query_exec.get(
                        "ResponseStatus", log_query_exec.get("ResponseStatus", [])
                    )
                    if not isinstance(
                        log_statuses, list
                    ):  # Convert to a list if it's a pandas Series
                        log_statuses = log_statuses.tolist()
                    logging.info(
                        f"get_10_data:::log_statuses for {id_10} are {log_statuses}, type is {type(log_statuses)}"
                    )
                    status_results_dict["DeviceBulkChangeLog"] = log_statuses

                logging.info(
                    f"get_10_data:::The result statuses are {id_10} ::::{status_results_dict}"
                )
                combined_statuses = [
                    status
                    for statuses in status_results_dict.values()
                    for status in statuses
                ]
                logging.info(
                    f"get_10_data:::: for id 1.0 {id_10} Total statuses are {combined_statuses}"
                )
                # if ("API_FAILED" in combined_statuses or "ERROR" in combined_statuses):
                #     keep_trying = False
                #     logging.info(
                #         f"Error response  came in combined_statuses and flag is {keep_trying} ---------\n:::{main_result_dict}"
                #     )
                #     return main_result_dict, keep_trying

                if (
                    "NEW" in combined_statuses
                    or "PROCESSING" in combined_statuses
                    or "PENDING" in combined_statuses
                ):
                    keep_trying = True
                else:
                    keep_trying = False

                logging.info(
                    f"Final main result dict got is and flag is {keep_trying} ---------\n:::"
                )#{main_result_dict}
                return main_result_dict, keep_trying

            else:
                # print(f"In dependent dict")
                logging.info(
                    f"1111################# Dependent Start Main result dict"
                )# {main_result_dict}
                dependent_dict = {}
                where_val_list = []
                result_df = None
                for dict_item in details_list:
                    table_10_key = dict_item["table_10"]
                    logging.info(f"22  Dependent Table {table_10_key}")
                    where_col = dict_item["where_col"]
                    logging.info(f"Dependent where col {where_col}")
                    if where_col == "id_10":
                        select_query = dict_item["select_query"]
                        # print(f"Before :::Select query is {select_query}")
                        logging.info(
                            f"{table_10_key}--Dependent table but where col is id_10 {id_10}"
                        )
                        select_query_id_1 = select_query.replace("?", "%s")
                        # print(f"select query is {select_query_id_1} 1.0 id is {id_10}", )
                        params = (id_10,)
                        result_df = self.execute_query(
                            mssql_conn, select_query_id_1, params=params
                        )
                        logging.info(f"@##$@#$@#@#@# result {result_df}")

                    else:
                        logging.info(f"In else of dependent dict")
                        select_query = dict_item["select_query"]
                        if tenant_id_str:
                            select_query=self.replace_tenantid_with_fstring(select_query,tenant_id_str)

                        logging.info(f"Before :::Select query is {select_query}")
                        where_table_name, where_col_name = where_col.split(".")
                        logging.info(f"@@@@ where {where_table_name,where_col_name}")
                        # where_table_name=where_split[0]
                        # where_col_name=where_split[1]

                        where_vals = [
                            item[where_col_name]
                            for item in main_result_dict.get(where_table_name, [])
                            if item.get(where_col_name) is not None
                        ]
                        where_val_list.extend(where_vals)
                        logging.info(f"{table_10_key}-where val list {where_val_list}")

                        if where_vals:
                            where_tuple = tuple(where_vals)
                            logging.info(f"#### where tuple {where_tuple}")
                            if len(where_tuple) == 1:
                                where_tuple_str = str(where_tuple[0])
                                logging.info(
                                    f"where tuple is 1 value {where_tuple_str} type is {type(where_tuple_str)} `('{where_tuple_str}')`"
                                )
                                select_query_p = select_query.replace(
                                    "?", f"('{where_tuple_str}')"
                                )

                            else:
                                # print(f"Tuple len is not 1")
                                # Parameterize query to avoid SQL injection
                                select_query_p = select_query.replace(
                                    "?", str(where_tuple)
                                )
                                logging.info(
                                    f"In else select query is {select_query_p}"
                                )
                            result_df = self.execute_query(mssql_conn, select_query_p)
                            logging.info(f"@##$@#$@#@#@# result {result_df}")

                        else:
                            logging.info(
                                f"No values found for where clause: {where_col}"
                            )

                    if result_df is not None:
                        result_dict = result_df.to_dict(orient="records")
                        dependent_dict[table_10_key] = result_dict
                    else:
                        dependent_dict[table_10_key] = []
                    logging.info(
                        f"@@@@@@@@@@@@@@@@Retruning Final Depedent dict is"
                    )

        except Exception as e:
            logging.info(
                f"Error in Bulk Change get_10_data-Fetching data from 1.0 ---{e}"
            )

        return dependent_dict, where_val_list


    def clean_data_list(self, data_list):
        """Convert NaT values to None for PostgreSQL compatibility."""
        for record in data_list:
            for key, value in record.items():
                if isinstance(value, float) and (math.isnan(value) or value is None):
                    record[key] = None
                if isinstance(
                    value, pd._libs.tslibs.nattype.NaTType
                ):  # Check for NaT type
                    record[key] = None
                if isinstance(value, pd.Timestamp):
                    if pd.isna(value):  # Check if it's NaT
                        record[key] = None
                    else:
                        record[key] = value.strftime(
                            "%Y-%m-%d %H:%M:%S"
                        )  # Convert to string format
                elif isinstance(value, str) and value in [
                    "NaT",
                    "nan",
                    "None",
                    "null",
                ]:  # Handle string cases
                    record[key] = None
        return data_list

    def update_data_history_table_bulk(
        self, postgres_conn, table_name, data_list, conflict_col
    ): # added this line
        """
        Inserts or updates data in a PostgreSQL table based on conflict.

        Parameters:
            postgres_conn: Active PostgreSQL connection
            table_name (str): Name of the target table
            record_dict (dict): Data to insert or update
            conflict_col (str): Column name to check for conflicts
        """
        if not data_list:
            print("No data provided for insertion.")
            return
        try:
            with postgres_conn.cursor() as cursor:
                # Extract column names and values
                columns = list(data_list[0].keys())
                data_list = self.clean_data_list(data_list)

                # Generate column and placeholder strings
                columns_str = ", ".join(columns)
                placeholders = ", ".join(["%s"] * len(columns))
                conflict_cols_str = ", ".join(conflict_col)
                # Generate update set statement excluding the conflict column
                update_set = ", ".join(
                    [
                        f"{col} = EXCLUDED.{col}"
                        for col in columns
                        if col != conflict_col
                    ]
                )
                # Construct the UPSERT query
                # print(columns_str)

                query = f"""
                INSERT INTO {table_name} ({columns_str})
                VALUES %s
                ON CONFLICT ({conflict_cols_str})
                DO UPDATE SET {update_set};
                """
                values = [tuple(record[col] for col in columns) for record in data_list]
                logging.info(f"query going to execute on history tables{query}")
                # print(f"Update values are {values}")

                execute_values(cursor, query, values)
                postgres_conn.commit()
                logging.info(f"Record inserted/updated successfully. {table_name}")

        except Exception as e:
            postgres_conn.rollback()
            logging.info(f"Error in update_data_history_table bulk: {e}")

    def update_data_history_table(
        self, postgres_conn, table_name, data_list, conflict_col
    ):
        """
        Inserts or updates data in a PostgreSQL table based on conflict.

        Parameters:
            postgres_conn: Active PostgreSQL connection
            table_name (str): Name of the target table
            record_dict (dict): Data to insert or update
            conflict_col (str): Column name to check for conflicts
        """
        if not data_list:
            logging.error("No data provided for insertion.")
            return
        try:
            with postgres_conn.cursor() as cursor:
                # Extract column names and values
                columns = list(data_list[0].keys())
                data_list = self.clean_data_list(data_list)

                # Generate column and placeholder strings
                columns_str = ", ".join(columns)
                placeholders = ", ".join(["%s"] * len(columns))
                conflict_cols_str = ", ".join(conflict_col)
                # Generate update set statement excluding the conflict column
                update_set = ", ".join(
                    [
                        f"{col} = EXCLUDED.{col}"
                        for col in columns
                        if col != conflict_col
                    ]
                )
                # Construct the UPSERT query
                # logging.info(columns_str)

                query = f"""
                INSERT INTO {table_name} ({columns_str})
                VALUES %s
                ON CONFLICT ({conflict_cols_str})
                DO UPDATE SET {update_set};
                """
                values = [tuple(record[col] for col in columns) for record in data_list]
                logging.info(f"query going to execute on history tables{query}")
                # logging.info(f"Update values are {values}")

                execute_values(cursor, query, values)
                postgres_conn.commit()
                logging.info(f"Record inserted/updated successfully. {table_name}")

        except Exception as e:
            postgres_conn.rollback()
            logging.error(f"Error in update_data_history_table: {e}")

    def main_save_data_t0_20(
        self,
        main_insert_data,
        main_cond_dict,
        main_multiple_col_conditions,
        id_20,
        postgres_conn,
        dependent_insert_data,
        dependent_cond_dict,
        counter=None,
        tenant_id=None
    ):
        try:
            logging.info(f"PostgresConn{postgres_conn}")
            if main_insert_data:
                subscriber_num_present = False
                for table_name_20, data_list in main_insert_data.items():
                    logging.info(
                        f"{id_20} Data to be updated in table {table_name_20}"
                    ) #{record_dict}
                    if data_list:
                        if table_name_20 in main_cond_dict.keys():
                            where_20_col = main_cond_dict[table_name_20]
                            data_list=self.clean_data_list(data_list)
                            for record_dict in data_list:
                                logging.info(f"{id_20} record_dict is") #{record_dict}
                                update = self.update_table(
                                    postgres_conn,
                                    table_name_20,
                                    record_dict,
                                    {where_20_col: id_20},
                                )

                        elif table_name_20 in main_multiple_col_conditions.keys():
                            logging.info(
                                f"{id_20} in elif condiion table_name {table_name_20}"
                            )
                            where_20_col = main_multiple_col_conditions[table_name_20]
                            split_where_cols = where_20_col.split(",")
                            where_col_0 = split_where_cols[0]
                            where_col_rest = split_where_cols[1:]
                            data_list=self.clean_data_list(data_list)
                            for record_dict in data_list:
                                # Build the where_dict using a dictionary comprehension

                                where_dict = {where_col_0: id_20}
                                where_dict.update(
                                    {
                                        col: record_dict[col]
                                        for col in where_col_rest
                                        if col in record_dict
                                    }
                                )
                                subscriber_number= record_dict.get("subscriber_number")

                                iccid_val = record_dict.get("iccid")

                                #  Hard stop if both iccid and subscriber_number are missing
                                if (iccid_val is None or iccid_val == "") and (subscriber_number is None or subscriber_number == ""):
                                    logging.error(
                                        f"{id_20} Both ICCID and Subscriber Number are NULL for record: {record_dict}. Aborting process."
                                    )
                                    logging.info(
                                        f"{id_20} Both ICCID and Subscriber Number are NULL for record: {record_dict}. Aborting process."
                                    )
                                    raise ValueError(
                                        f"Record {id_20} invalid: Both iccid and subscriber_number are NULL/empty → cannot update."
                                    )

                                # Apply fallback logic if iccid missing but subscriber_number present
                                if "iccid" in where_dict and (iccid_val is None or iccid_val == ""):
                                    if subscriber_number:
                                        where_dict.pop("iccid", None)  # remove iccid filter
                                        where_dict["subscriber_number"] = subscriber_number
                                        logging.info(
                                            f"{id_20} iccid is NULL, falling back to subscriber_number={subscriber_number}"
                                        )

                                # Track subscriber_number presence
                                subscriber_num_present = bool(subscriber_number)


                                logging.info(f"{id_20} Where dict is {where_dict}")
                                logging.info(f"{id_20} where cond dict {where_dict}")
                                logging.info(
                                    f"{id_20} record_dict passed is {record_dict}"
                                )
                                # Execute the update
                                update = self.update_table(
                                    postgres_conn,
                                    table_name_20,
                                    record_dict,
                                    where_dict,
                                )

                    else:
                        raise ValueError("No records obtained to insert in 2.0")
                return True,subscriber_num_present

            elif dependent_insert_data:
                logging.info(f"Dependent cond dict is {dependent_cond_dict}")
                for table_name_20, data_list in dependent_insert_data.items():
                    logging.info(f"{id_20} Data to be updated in table {table_name_20}")
                    if (
                        table_name_20 == "device_history"
                        or table_name_20 == "mobility_device_history"
                    ):
                        logging.info(
                            f"{id_20} updating device_history table {table_name_20}"
                        )
                        cursor = postgres_conn.cursor()
                        conflict_col = "device_history_id"
                        self.update_data_history_table(
                            postgres_conn, table_name_20, data_list, conflict_col
                        )
                    logging.info(f"{id_20} Table name 20 is {table_name_20}")
                    if not data_list:
                        logging.info(
                            f"{id_20} No Data to Insert, skipping to next iteration"
                        )
                        continue

                    where_20_col = dependent_cond_dict.get(table_name_20)
                    logging.info(f"where 20 col is {where_20_col}")
                    if not where_20_col:
                        logging.info(f"{id_20} Where condition column not found")
                        continue
                    delete_performed = False  # Flag to track delete operation
                    for record_dict in data_list:

                        if where_20_col == "bulk_change_id":
                            where_val = id_20
                            record_dict["bulk_change_id"] = where_val
                            if (
                                table_name_20 == "sim_management_bulk_change_log"
                                and counter == 1
                            ):
                                logging.info(
                                    f"{id_20} Here in sim_management_bulk_change_log record dict is ----"
                                ) #{record_dict}
                                try:
                                    ii = self.insert_data_to_postgres(
                                        table_name_20,
                                        [record_dict],
                                        postgres_conn,
                                        None,
                                    )
                                except Exception as e:
                                    logging.error(f"{id_20} Error in log is {e}")
                            elif (
                                table_name_20 == "sim_management_bulk_change_log"
                                and counter > 1
                            ):
                                logging.info(
                                    f"{delete_performed} checking daelete flag if it is already del records or not "
                                )
                                if not delete_performed:
                                    logging.info(
                                        f" Counter is to insert Log is {counter}"
                                    )
                                    del_query = f"delete from {table_name_20} where bulk_change_id={where_val}"
                                    self.execute_query(postgres_conn, del_query)
                                    delete_performed = True
                                try:
                                    ii = self.insert_data_to_postgres(
                                        table_name_20,
                                        [record_dict],
                                        postgres_conn,
                                        None,
                                    )
                                except Exception as e:
                                    logging.error(f"{id_20} Error in log is {e}")
                            # if table_name_20=='sim_management_bulk_change_log':
                            #     # print(f"Here 111 sim_management_bulk_change_log ----{record_dict}")
                            #     try:
                            #         ii=self.insert_data_to_postgres(table_name_20,[record_dict],postgres_conn,None)
                            #     except Exception as e:
                            #         print(f"Error in log is {e}")

                        else:
                            if table_name_20 == "sim_management_inventory":
                                cursor = postgres_conn.cursor()
                                iccid = record_dict["iccid"]
                                logging.info(f"{id_20} Before ICCID is {iccid}")

                                sql_query = f"select * from {table_name_20} where iccid='{iccid}' and tenant_id={tenant_id}"
                                cursor.execute(sql_query)
                                result = cursor.fetchall()
                                logging.info(f"SMI RESULT IS")  #{result}
                                logging.info(f" SMI 1111 result is ")#{result}
                                if result:
                                    logging.info(f"{id_20} RESELT FROM SMI TRUE")
                                    where_val = record_dict.get(where_20_col)

                                    logging.info(
                                        f"{id_20} where val is for smi {where_val}"
                                    )
                                    if where_val is not None:
                                        # Prepare the update where conditions
                                        where_dict = {
                                            where_20_col: where_val,
                                            "tenant_id": tenant_id,
                                        }

                                        logging.info(
                                            f"{id_20} where dict is {where_dict}"
                                        )
                                        logging.info(
                                            f"{id_20} record dict is just beforreee"
                                        ) #{record_dict}
                                        # Execute the update
                                        self.update_table(
                                            postgres_conn,
                                            table_name_20,
                                            record_dict,
                                            where_dict,
                                        )
                                else:
                                    # print(f"Here 111 sim_management_bulk_change_log ----{record_dict}")
                                    try:
                                        ii = self.insert_data_to_postgres(
                                            table_name_20,
                                            [record_dict],
                                            postgres_conn,
                                            None,
                                        )
                                    except Exception as e:
                                        logging.error(f"{id_20} Error in log is {e}")
                            else:
                                where_val = record_dict.get(where_20_col)

                                logging.info(f"{id_20} where val is {where_val}")
                                if where_val is not None:
                                    # Prepare the update where conditions
                                    where_dict = {where_20_col: where_val}
                                    logging.info(f"{id_20}-where dict is {where_dict}")
                                    logging.info(
                                        f"{id_20}-record dict is "
                                    )#{record_dict}
                                    # Execute the update
                                    self.update_table(
                                        postgres_conn,
                                        table_name_20,
                                        record_dict,
                                        where_dict,
                                    )
                return True
        except Exception as e:
            logging.info(f"{id_20} Error in main_save_data_t0_20: {e}")
            logging.info(f"{id_20} Going to execute update_query")
            # logging.info(f"Going to execute")
            error_msg = f"Error in main_save_data_t0_20: {e}"
            update_data_dict = {"progress": "Error in Sync", "error_msg": error_msg}
            ue = self.update_table(
                postgres_conn,
                "sim_management_bulk_change",
                update_data_dict,
                {"id": id_20},
            )

    def main_save_data_t0_20_bulk_update(
        self,
        main_insert_data,
        main_cond_dict,
        main_multiple_col_conditions,
        id_20,
        postgres_conn,
        dependent_insert_data,
        dependent_cond_dict,
        tenant_id=None,
        inventory_conflict_cols=None
    ):
        start_time = time.time()
        batch_size = 5000
        try:
            logging.info(f"MAIN SAVE START")
            logging.info(f"PostgresConn{postgres_conn}")
            if main_insert_data:
                logging.info(f"111111111111111111 here")
                for table_name_20, data_list in main_insert_data.items():
                    logging.info(
                        f" Data to be updated in table {id_20}-{table_name_20}"
                    )
                    if data_list:
                        if table_name_20 in main_cond_dict.keys():
                            where_20_col = main_cond_dict[table_name_20]
                            logging.info(f"222222222 Where col,where val {where_20_col},{id_20}")
                            for record_dict in data_list:
                                logging.info(f" record_dict is {id_20}")#{record_dict}
                                logging.info(f"GOING TO UPDATE TABLE")
                                update = self.update_table(
                                    postgres_conn,
                                    table_name_20,
                                    record_dict,
                                    {where_20_col: id_20},
                                )

                        elif table_name_20 in main_multiple_col_conditions.keys():
                            df = pd.DataFrame(data_list)
                            df["bulk_change_id"] = id_20
                            data_list = df.to_dict(orient="records")

                            logging.info(
                                f"44444444 @@@@@ in elif condiion table_name {id_20}-{table_name_20}"
                            )
                            logging.info(data_list)
                            conflict_col=["bulk_change_id","id"]
                            # logging.info(f"44444444 Data List is {data_list}")
                            self.update_data_history_table_bulk(
                            postgres_conn, table_name_20, data_list, conflict_col
                        )

                    else:
                        raise ValueError("No records obtained to insert in 2.0")
                return True

            elif dependent_insert_data:
                logging.info(f"Dependent cond dict is {dependent_cond_dict}")
                for table_name_20, data_list in dependent_insert_data.items():
                    logging.info(f"{id_20} Data to be updated in table {table_name_20}")
                    if not data_list:
                        logging.info(
                            f"{id_20} No Data to Insert, skipping to next iteration"
                        )
                        continue
                    if (
                        table_name_20 == "device_history"
                        or table_name_20 == "mobility_device_history"
                    ):
                        batch_size = 5000  # Define batch size

                        logging.info(f"{id_20} updating device_history table {table_name_20}")

                        cursor = postgres_conn.cursor()
                        conflict_col = ["device_history_id"]
                        # Convert list of dicts to Pandas DataFrame
                        df = pd.DataFrame(data_list)
                        # Perform batch updates if more than 5000 records exist
                        if len(df) > batch_size:
                            for i in range(0, len(df), batch_size):
                                batch_df = df.iloc[i:i + batch_size]  # Slice dataframe into batches
                                batch = batch_df.to_dict(orient="records")  # Convert batch back to list of dicts
                                logging.info(f"Processing batch {i // batch_size + 1} for {id_20}")
                                self.update_data_history_table_bulk(postgres_conn, table_name_20, batch, conflict_col)
                        else:
                            # Convert to list of dicts for single update
                            self.update_data_history_table_bulk(postgres_conn, table_name_20, df.to_dict(orient="records"), conflict_col)

                        if len(data_list) > batch_size:
                            for i in range(0, len(data_list), batch_size):
                                batch = data_list[i:i + batch_size]  # Slice data into batches
                                logging.info(f"Processing batch {i // batch_size + 1} for {id_20}")
                                self.update_data_history_table_bulk(postgres_conn, table_name_20, batch, conflict_col)
                        else:
                            # Perform a single update if data_list is within batch size
                            self.update_data_history_table_bulk(postgres_conn, table_name_20, data_list, conflict_col)
                    if table_name_20 == "sim_management_bulk_change_log":
                        #batches include fixed 5000 dfisze batches divide
                        logging.info(f"{id_20} updating bulk_change_log table {table_name_20}")
                        df = pd.DataFrame(data_list)  # Convert list of dicts to DataFrame
                        df["bulk_change_id"] = id_20  # Vectorized update
                        data_list = df.to_dict(orient="records")  # Convert back to list of dicts
                        conflict_col=["id_10","bulk_change_id"]
                        if len(df) > batch_size:
                            for i in range(0, len(df), batch_size):
                                batch_df = df.iloc[i:i + batch_size]  # Slice dataframe into batches
                                batch = batch_df.to_dict(orient="records")  # Convert batch back to list of dicts
                                logging.info(f"Processing batch {i // batch_size + 1} for {id_20}")
                                self.update_data_history_table_bulk(postgres_conn, table_name_20, batch, conflict_col)
                        else:
                            # Convert to list of dicts for single update
                            self.update_data_history_table_bulk(postgres_conn, table_name_20, df.to_dict(orient="records"), conflict_col)

                    if table_name_20=="sim_management_inventory":
                        logging.info(f"{id_20} updating inventory table {table_name_20}")
                        df = pd.DataFrame(data_list)
                        if len(df) > batch_size:
                            for i in range(0, len(df), batch_size):
                                batch_df = df.iloc[i:i + batch_size]  # Slice dataframe into batches
                                batch = batch_df.to_dict(orient="records")  # Convert batch back to list of dicts
                                print(f"Processing batch {i // batch_size + 1} for {id_20}")
                                self.update_data_history_table_bulk(postgres_conn, table_name_20, batch, inventory_conflict_cols)
                        else:
                            batch = df.to_dict(orient="records")  # Convert full dataframe to list of dicts
                            self.update_data_history_table_bulk(postgres_conn, table_name_20, batch, inventory_conflict_cols)


                end_time = time.time()
                time_consumed = f"{end_time - start_time:.4f}"
                logging.info(f"Time consumed at main_save_data_t0_20 is {time_consumed}")
                return True
        except Exception as e:
            logging.info(f"{id_20} Error in main_save_data_t0_20: {e}")
            logging.info(f"{id_20} Going to execute update_query")
            # logging.info(f"Going to execute")
            error_msg = f"Error in main_save_data_t0_20: {e}"
            update_data_dict = {"progress": "Error in Sync", "error_msg": error_msg}
            ue = self.update_table(
                postgres_conn,
                "sim_management_bulk_change",
                update_data_dict,
                {"id": id_20},
            )


    def save_data_20_from_10(
        self, id_10, id_20, transfer_name, postgres_data, data_all,sqs_falg=False,tenant_name=None,ver_inventory_flag=None
        ,parent_tenant_id=None,sub_tenant_id=None,access_token=None,active_new_service_api_flag=None,role_name=None,api_call_flag=None,sync_count=0,ui_tenant_name=None
    ):  # commenting this to implement ticket 2266 on 08-01-2025
        try:
            logging.info(f"reverse syncing data from 1.0 to 2.0 for {id_20}")
            if tenant_name=='Altaworx Test': # added this line
                tenant_name='Altaworx' # added this line
            #parent_tenant_id = None  # added this line
            tenant_id=parent_tenant_id
            tenant_id_str=None
            sqs_flag=False
            sync_count+=1
            logging.info(f"sync_count is {id_20} {id_10} {sync_count}")
            logging.info(f"Tenant details {id_20} {tenant_name} {parent_tenant_id} {sub_tenant_id} {ui_tenant_name}")


            if tenant_id:
                tenant_id_str = f"({', '.join(str(i) for i in [parent_tenant_id, sub_tenant_id] if i is not None)})"



            #parent_tenant_name=self.get_parent_by_subtenant(tenant_name,sub_tenants_json)
            #if parent_tenant_name:
                #tenant_name=parent_tenant_name

            logging.info(f"save_data_20_from_10 tenant_name {id_20} {tenant_name} tenant_id is {tenant_id}")

            logging.info(
                f"devicehistorytable postgress_data,{postgres_data},id_10 is ,{id_10}, id_20 is {id_20}, transfer name is {transfer_name}"
            )
            logging.info(f"Going to save data from 1.0 to 2.0,{postgres_data}")
            logging.info(f"Transfer name is {transfer_name}")
            logging.info(f"ID 10 is {id_10}")
            logging.info(f"ID 20 is {id_20}")


            # if transfer_name == "bulk_change":
            if transfer_name.startswith("bulk_change"):
                data_list = postgres_data["sim_management_bulk_change"]
                service_provider_id = data_list[0]["service_provider_id"]
                logging.info(f"####service_provider_id in save_data_20_from_10 is {service_provider_id}")
                json_data = self.load_json()
                telegence_ids = self.get_provider_ids(json_data, tenant_name, ["Telegence"])

                if tenant_name.lower() in ('altaworx_test','altaworx'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility"
                        inventory_conflict_cols=["mdt_id","mobility_device_id"]
                    else:
                        transfer_name = "bulk_change"
                        inventory_conflict_cols=["dt_id","device_id"]

                elif tenant_name.lower() == 'spectrotel':
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_spectrotel"
                        inventory_conflict_cols=["mdt_id","mobility_device_id"]
                    else:
                        transfer_name = "bulk_change_spectrotel"
                        inventory_conflict_cols=["dt_id","device_id"]

                elif tenant_name in ('altaworx_go_tech','Altaworx - Go Tech'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_altaworx_go_tech"
                        inventory_conflict_cols=["mdt_id","mobility_device_id"]
                    else:
                        transfer_name = "bulk_change_altaworx_go_tech"
                        inventory_conflict_cols=["dt_id","device_id"]

                elif tenant_name.lower() in ('apitesttenant'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_apitesttenant"
                        inventory_conflict_cols=["mdt_id","mobility_device_id"]
                    else:
                        transfer_name = "bulk_change_apitesttenant"
                        inventory_conflict_cols=["dt_id","device_id"]
                else:
                    logging.info("Tenant not found in save_data_20_from_10")
                    raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")


            delay_flag = False
            log_status_check_flag = False
            sqs_postgres_data={"sim_management_bulk_change":postgres_data["sim_management_bulk_change"]}


            # if transfer_name == "bulk_change_mobility":
            change_type_get = postgres_data["sim_management_bulk_change"][0][
                "change_request_type"
            ]
            logging.info(f"Change type got is {change_type_get}")
            if change_type_get == "Activate New Service":
                logging.info(f"Change type is Activate New Service {id_20}")
                ver_inventory_flag=True
                delay_flag = True
                log_status_check_flag = True
            else:
                log_status_check_flag = False
            # else:
            #     log_status_check_flag = False
            #     delay_flag = False

            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            # getting details from db
            mapping_details_query = f"select db_name_20,db_config,reverse_table_mapping,reverse_col_mapping,data_from_10,update_cond_cols,db_name_10,db_config from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn1, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            table_info_dict = mapping_details["data_from_10"]
            update_cond_20 = mapping_details["update_cond_cols"]
            mssql_config = mapping_details.get("db_config", {})  # ssms db config details
            db_name_10 = mapping_details.get("db_name_10", {})
            logging.info("mssql configurations", mssql_config)
            if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                logging.info("no mappings present for the configurations so returning the function")
                return True

            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )

            main_details_list = table_info_dict[
                "main"
            ]  # get info list from db which helps in getting data from 10

            # print(f"Main dict {main_result_dict}")

            db_name_20 = mapping_details["db_name_20"]
            logging.info(f"DB Name is {db_name_20}")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name_20, user, password, port
            )
            logging.info(f"Postgres Conn {postgres_conn}")
            main_cond_dict = update_cond_20[
                "main"
            ]  # get the dict from db whic contains condition params
            main_multiple_col_conditions = update_cond_20["main_multi_col"]
            dependent_cond_dict = update_cond_20["dependent"]

            reverse_tables = mapping_details["reverse_table_mapping"]
            reverse_col_mappings = mapping_details["reverse_col_mapping"]
            dependent_info_list = table_info_dict[
                "dependent"
            ]  # get info list from db which helps in getting data from 10

            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            try:
                if tenant_name:
                    common_utils_conn=self.create_connection(db_type,hostname,'common_utils',user,password,port)
                    tenant_name_q=f"select db_name from tenant where tenant_name='{tenant_name}' and is_active=true and is_deleted=false"
                    tenant_name_res=self.execute_query(common_utils_conn,tenant_name_q)
                    # if tenant_name_res is not None and 'db_name' in tenant_name_res and tenant_name_res['db_name']:
                    if tenant_name_res is not None and not tenant_name_res.empty and 'db_name' in tenant_name_res.columns:
                        tenant_name_ = tenant_name_res['db_name'][0]
                        db_name=tenant_name_
                    else:
                        logging.info(f"Tenant '{tenant_name}' not found or inactive.")
                        raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")
                # else:
                #     db_name='altaworx_test'
            except Exception as e:
                logging.error(f"Error in fetching tenant name:{id_20} {e}")
                logging.error(f"{id_10} id_20 {id_20} Error in fetching tenant name: {e}")
                # db_name = "altaworx_test"



            print(f"conn variables {hostname,port,user,password,db_type,db_name}")
            postgres_conn_a = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            main_result_dict, keep_trying_flag = self.get_10_data(
                transfer_name,
                mssql_conn,
                id_10,
                main_details_list,
                log_status_check_flag,
                main_flag=True,
            )
            logging.info(
                f"1.0 data obtained::: id_10 {id_10} and 2.0 id is {id_20} flag is {keep_trying_flag}"
            )
            logging.info(
                f"Data dict obtained from 1.0 for main tables:{id_20} \n {main_result_dict}"
            )

            counter = 0
            loop_start_time = time.time()
            activate_new_service_fn_call=False
            inside_ver_flag=False

            while keep_trying_flag == True and sync_count<15:
                counter = counter + 1
                logging.info(f"Counter is for id_20 {id_20} {counter}")
                logging.info(
                    f"Keep Trying flag is {keep_trying_flag} id_10 {id_10} and 2.0 id is {id_20} {sync_count}"
                )
                if counter>1 and log_status_check_flag is True and delay_flag is True:
                    logging.info(f"for id_10 & 1d_20 counter is {id_10} {id_20} - {counter} Going to sleep for 30 secs")
                    time.sleep(30)
                    logging.info(f"After sleep for 30 secs for id_10 & 1d_20 counter is {id_10} {id_20} - {counter} going to check again")

                main_insert_data = self.map_cols(
                    reverse_tables, reverse_col_mappings, main_result_dict
                )
                insert_main_dict,sub_num = self.main_save_data_t0_20(
                    main_insert_data,
                    update_cond_20["main"],
                    update_cond_20["main_multi_col"],
                    id_20,
                    postgres_conn,
                    {},
                    update_cond_20["dependent"],
                    tenant_id
                )

                main_result_dict, keep_trying_flag = self.get_10_data(
                    transfer_name,
                    mssql_conn,
                    id_10,
                    main_details_list,
                    log_status_check_flag,
                    main_flag=True,
                )
                logging.info(f"Keep trying flag is {keep_trying_flag} {counter} id_10 {id_10} and 2.0 id is {id_20}")
                loop_elapsed_time = time.time() - loop_start_time
                logging.info(f"Loop elapsed time is {loop_elapsed_time} {counter} id_10 {id_10} and 2.0 id is {id_20}")

                if log_status_check_flag is True and not inside_ver_flag:

                    logging.info(f"For this here flags are {id_20} {log_status_check_flag} {inside_ver_flag}")
                    logging.info(
                        f"for This particular type we need to keep syning dependent tables too {counter} id_10 {id_10} and 2.0 id is {id_20}"
                    )
                    dependent_dict, where_val_list = self.get_10_data(
                        transfer_name,
                        mssql_conn,
                        id_10,
                        dependent_info_list,
                        log_status_check_flag,
                        main_flag=False,
                        main_result_dict=main_result_dict,
                        tenant_id_str=tenant_id_str
                    )
                    dependent_insert_data = self.map_cols(
                        reverse_tables, reverse_col_mappings, dependent_dict
                    )
                    logging.info(f"Dependent_dict is and 2.0 id is {counter} id_10 {id_10}  {id_20} {dependent_insert_data}")
                    insert_dependent_data = self.main_save_data_t0_20_bulk_update(
                        {},
                        main_cond_dict,
                        main_multiple_col_conditions,
                        id_20,
                        postgres_conn,
                        dependent_insert_data,
                        dependent_cond_dict,
                        tenant_id,
                        inventory_conflict_cols=inventory_conflict_cols,
                    )
                    try:
                        logging.info("Checking whether assign customer can be initated or not")
                        msisdn_list = [
                                            item.get('msisdn')
                                            for item in dependent_insert_data.get('sim_management_inventory', [])
                                            if isinstance(item, dict) and 'msisdn' in item
                                        ]
                        msisdn_list = [msisdn for msisdn in msisdn_list if msisdn != '']
                        msisdn_list = list(set(msisdn_list))
                        logging.info(f"bulk change id 2.0: {id_20} msisdn_list is {msisdn_list} {id_10}")

                        try:
                            msisdn_details_query = f"select subscriber_number,iccid from sim_management_bulk_change_request where bulk_change_id ={id_20}"
                            msisdn_details_df = self.execute_query(postgres_conn_a, msisdn_details_query)
                            #print("msisdn_details",msisdn_details_df)
                            msisdn_details = msisdn_details_df['subscriber_number'].dropna().tolist()
                            msisdn_details_iccids = msisdn_details_df['iccid'].dropna().tolist()
                            #msisdn_details = [msisdn for msisdn in msisdn_details if msisdn != '']
                            msisdn_details = list(set(msisdn_details))
                        except Exception as e:
                            logging.info(f"Error in getting msisdn details {e}")
                            msisdn_details = []
                            msisdn_details_iccids = []
                            pass
                        logging.info(f"bulk change id 2.0: {id_20} msisdn_details is {msisdn_details}, msisdn_details_iccids {msisdn_details_iccids}")

                        if len(msisdn_details_iccids)>1:
                            msisdn_details_iccids = tuple(msisdn_details_iccids)
                            msisdn_list_query = f"select msisdn from sim_management_inventory where iccid in {msisdn_details_iccids}"
                        elif len(msisdn_details_iccids)==1:
                            msisdn_details_iccids = msisdn_details_iccids[0]
                            msisdn_list_query = f"select msisdn from sim_management_inventory where iccid ='{msisdn_details_iccids}'"
                        else:
                            msisdn_list_query = None
                            msisdn_list = []

                        if msisdn_list_query:
                            msisdn_list = self.execute_query(postgres_conn_a, msisdn_list_query)
                            msisdn_list = msisdn_list['msisdn'].tolist()
                            msisdn_list = [msisdn for msisdn in msisdn_list if msisdn != '']
                            msisdn_list = list(set(msisdn_list))
                        logging.info(f"length of msisdn_list - {len(msisdn_list)} length of msisdn_details - {len(msisdn_details)}")
                        logging.info(f"bulk change id 2.0: {id_20} msisdn_list is {msisdn_list}")


                        if len(msisdn_list) == len(msisdn_details) and len(msisdn_list) != 0:
                            logging.info(f"Need to call sync here once {id_20}")
                            if not inside_ver_flag:
                                try:
                                    logging.info(f"inside ver flag {id_20} {inside_ver_flag}")
                                    # time.sleep(15)
                                    logging.info(f"I1 Need to call sync to update inventory inside is {id_20}")
                                    api_url = os.environ.get("SERVICE_LINE_API_URL", "")
                                    api_payload = {
                                        "data": {
                                            "path": "/lambda_sync_jobs_",
                                            "key_name": "mobility_inventory_womd",
                                            "tenant_name": tenant_name
                                        }
                                    }
                                    response = requests.post(api_url, json=api_payload)
                                    if response.status_code in (200,504):
                                        current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                        logging.info(
                                            f"API call successful for verizon_invntory. Data sync call is successfully done inside {id_20}"
                                        )
                                        inside_ver_flag=True
                                    else:
                                        logging.info(
                                            f"API call failed for verizon inventory with status code:inside {id_20} {response.status_code}"
                                        )
                                except Exception as e:
                                    logging.info(
                                        f"Error occurred while calling the API for service_number verizon inventory inside {id_20} {e}"
                                    )

                            if active_new_service_api_flag is True:
                                # Below query and if condition is to allow Assign customer only once not more than that
                                if isinstance(msisdn_details_iccids, str):
                                    iccids_check = f"('{msisdn_details_iccids}')"
                                elif isinstance(msisdn_details_iccids, tuple):
                                    iccids_check = msisdn_details_iccids
                                msisdn_details_query = f"select smbcr.iccid as iccid from sim_management_bulk_change_request as smbcr join sim_management_bulk_change as smbc on smbcr.bulk_change_id=smbc.id where smbc.change_request_type='Assign Customer' and smbcr.iccid in {iccids_check}"
                                logging.info(f"bulk change id 2.0: {id_20} msisdn_details_query is {msisdn_details_query}")
                                msisdn_details_df = self.execute_query(postgres_conn_a, msisdn_details_query)
                                checkpoint = msisdn_details_df['iccid'].tolist()

                                logging.info(f"bulk change id 2.0: {id_20} checkpoint is {checkpoint}")

                                if len(checkpoint)==0:
                                    from run_db_script import activate_new_service_caller
                                    logging.info(f"bulk change id 2.0: {id_20} Activate new service API call {id_10}")
                                    fn_call=activate_new_service_caller(id_20,db_name,access_token,ui_tenant_name,role_name,api_call_flag)
                                    logging.info("Assign Customer calling finished in Activate New Service")
                            else:
                                logging.info(f"bulk change id 2.0: {id_20} active_new_service_api_flag: {active_new_service_api_flag} activate_new_service_fn_call:{activate_new_service_fn_call}")
                        else:
                            logging.info(f"bulk change id 2.0: {id_20} msisdn_list and msisdn_details are not equal ")
                    except Exception as e:
                        logging.info(f"Error in activate new service API call {e}")
                        pass



                if loop_elapsed_time > 720:
                    # logging.warning(f"Time exceeded 12 minutes. Breaking the loop forcefully. id_10: {id_10}, id_20: {id_20}")
                    # error_msg=f"Counter exceeded 200. Breaking the loop forcefully. id_10: {id_10}, id_20: {id_20}"\

                    #  adding sqs function to continue after 12 min
                    logging.warning(
                        f"Time exceeded 12 minutes. Sending to SQS for continued processing. id_10: {id_10}, id_20: {id_20}"
                    )
                    if transfer_name in ("bulk_change", "bulk_change_mobility", "bulk_change_spectrotel", "bulk_change_mobility_spectrotel", "bulk_change_mobility_altaworx_go_tech", "bulk_change_altaworx_go_tech", "bulk_change_mobility_apitesttenant", "bulk_change_apitesttenant"):
                        # update_query=f"update sim_management_bulk_change set progress='Error in Sync', error_msg={error_msg} where id={id_20}"
                        # logging.info(f"Going to execute update")
                        # update_data_dict={"progress":"Time limit Exceeded, Sync Stopped","error_msg":f"Time limit exceeded {loop_elapsed_time}"}
                        # ue=self.update_table(postgres_conn_a, 'sim_management_bulk_change', update_data_dict, {'id':id_20})
                        # keep_trying=False
                        # break

                        message_body = {
                            "id_10": id_10,
                            "id_20": id_20,
                            "transfer_name": transfer_name,
                            "elapsed_time": loop_elapsed_time,
                            "continuation": True,
                            "path": "/save_data_20_from_10",
                            "access_token": data_all["access_token"],
                            "data_all": {"access_token": data_all["access_token"]},
                            "postgres_data":  sqs_postgres_data,
                            'sqs_call':True,
                            'db_name': data_all.get("db_name",""),
                            'username': data_all.get("username",""),
                            'tenant_name':tenant_name,
                            'ver_inventory_flag':ver_inventory_flag,
                            'api_call_flag':api_call_flag,
                            'parent_tenant_id':parent_tenant_id,
                            'sub_tenant_id':sub_tenant_id,
                            "access_token":access_token,
                            "active_new_service_api_flag":active_new_service_api_flag,
                            "role_name":role_name,
                            'sync_count':sync_count,
                            "ui_tenant_name":ui_tenant_name
                        }

                        try:
                            logging.info(
                                f"sqs queue message sending ------- for continued processing"
                            )
                            o = self.send_msg_sim_management_trigger_queue(message_body)
                            logging.info("Successfully queued for continued processing")
                            return True
                        except Exception as e:
                            logging.info(f"Error in SQS Queue Calling {e}")
                            logging.info(f"Going to insert dependent data")
                            ###################### saving dependent data
                            dependent_dict,where_val_list=self.get_10_data(transfer_name,mssql_conn,id_10,dependent_info_list,log_status_check_flag,main_flag=False,main_result_dict=main_result_dict,tenant_id_str=tenant_id_str)
                            # print(f"Data dict obtained from 1.0 for dependent tables: \n {dependent_dict} \n {where_val_list}")
                            dependent_insert_data=self.map_cols(reverse_tables,reverse_col_mappings,dependent_dict)
                            # logging.info(f"Dependent_dict is {dependent_insert_data}")
                            insert_dependent_data=self.main_save_data_t0_20_bulk_update({},main_cond_dict,main_multiple_col_conditions,id_20,postgres_conn,dependent_insert_data,dependent_cond_dict,counter, tenant_id=tenant_id,inventory_conflict_cols=inventory_conflict_cols)
                            keep_trying=False
                            sqs_flag=True
                            update_data_dict={"progress":"sqs has error, Sync Stopped","error_msg":f"Time limit exceeded {loop_elapsed_time} and sqs queue failed"}
                            ue=self.update_table(postgres_conn_a, 'sim_management_bulk_change', update_data_dict, {'id':id_20})
                            return False

            logging.info(
                f"Keep trying flag is {keep_trying_flag} and id_10 {id_10} and 2.0 id is {id_20} doing a final update"
            )
            main_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, main_result_dict
            )
            insert_main_dict,sub_num = self.main_save_data_t0_20(
                main_insert_data,
                update_cond_20["main"],
                update_cond_20["main_multi_col"],
                id_20,
                postgres_conn,
                {},
                update_cond_20["dependent"],
                tenant_id
            )

            logging.info(
                f"Keep Trying flag {keep_trying_flag},id_10 {id_10} and 2.0 id is {id_20} Updating Dependent tables"
            )
            dependent_dict, where_val_list = self.get_10_data(
                transfer_name,
                mssql_conn,
                id_10,
                dependent_info_list,
                log_status_check_flag,
                main_flag=False,
                main_result_dict=main_result_dict,
                tenant_id_str=tenant_id_str
            )
            # print(f"Data dict obtained from 1.0 for dependent tables: \n {dependent_dict} \n {where_val_list}")
            dependent_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, dependent_dict
            )
            logging.info(f"Dependent_dict is {id_20} {dependent_insert_data}")
            insert_dependent_data = self.main_save_data_t0_20_bulk_update(
                {},
                main_cond_dict,
                main_multiple_col_conditions,
                id_20,
                postgres_conn,
                dependent_insert_data,
                dependent_cond_dict,
                tenant_id=tenant_id,
                inventory_conflict_cols=inventory_conflict_cols
            )

            if ver_inventory_flag:
                try:
                    time.sleep(15)
                    logging.info(f"I1 Need to call sync to update inventory outside loop {id_20}")
                    api_url = os.environ.get("SERVICE_LINE_API_URL", "")
                    api_payload = {
                        "data": {
                            "path": "/lambda_sync_jobs_",
                            "key_name": "verizon_inventory",
                            "tenant_name": tenant_name
                        }
                    }
                    response = requests.post(api_url, json=api_payload)
                    if response.status_code == 200:
                        current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        logging.info(
                            f"API call successful for verizon_invntory. Data sync call is successfully done outside {id_20}"
                        )
                    else:
                        logging.info(
                            f"API call failed for verizon inventory with status code:{id_20} {response.status_code}"
                        )
                except Exception as e:
                    logging.info(
                        f"Error occurred while calling the API for service_number verizon inventory {id_20} {e}"
                    )

            if transfer_name in ("bulk_change", "bulk_change_mobility", "bulk_change_spectrotel", "bulk_change_mobility_spectrotel", "bulk_change_mobility_altaworx_go_tech", "bulk_change_altaworx_go_tech", "bulk_change_mobility_apitesttenant", "bulk_change_apitesttenant"):
                update_query = f"update sim_management_bulk_change set progress='Sync Completed' where id={id_20}"
                logging.info(f"Going to execute update")
                update_data_dict = {"progress": "Sync Completed"}
                ue = self.update_table(
                    postgres_conn_a,
                    "sim_management_bulk_change",
                    update_data_dict,
                    {"id": id_20},
                )
                #mssql_conn.close()
            DataTransfer.release_connection("postgresql",hostname,port,'Migration_Test', postgres_conn1)
            DataTransfer.release_connection("postgresql",hostname,port,db_name_20, postgres_conn)
            DataTransfer.release_connection("mssql",from_host,from_port,ssms_db_name, mssql_conn)
            DataTransfer.release_connection("postgresql",hostname,port,'common_utils',common_utils_conn)
            DataTransfer.release_connection("postgresql",hostname,port,db_name,postgres_conn_a)

            return True

        except Exception as e:

            logging.error(
                f"Error while fetching data from 1.0 and saving it int 2.0 {id_20}: {e}"
            )
            error_msg = f"save_data_20_from_10 - Error while fetching data from 1.0 and saving it int 2.0 : {e}"
            if transfer_name in ("bulk_change", "bulk_change_mobility", "bulk_change_spectrotel", "bulk_change_mobility_spectrotel", "bulk_change_mobility_altaworx_go_tech", "bulk_change_altaworx_go_tech", "bulk_change_mobility_apitesttenant", "bulk_change_apitesttenant"):
                # update_query=f"update sim_management_bulk_change set progress='Error in Sync', error_msg={error_msg} where id={id_20}"
                logging.info(f"Going to execute update_query")
                logging.info(f"Going to execute")
                update_data_dict = {"progress": "Error in Sync", "error_msg": error_msg}
                ue = self.update_table(
                    postgres_conn_a,
                    "sim_management_bulk_change",
                    update_data_dict,
                    {"id": id_20},
                )
                mssql_conn.close()

            return False
    def bulk_update_table(self, conn, df, table_name, match_dict):
        if df.empty:
            logging.info(f"No data to update in {table_name}.")
            return

        try:
            logging.info(f"match_dict gotten is {match_dict}")

            # Step 1: Get column types from information_schema
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT column_name, data_type
                    FROM information_schema.columns
                    WHERE table_name = %s
                """, (table_name,))
                col_type_raw = cur.fetchall()
                col_type_dict = {col: dtype for col, dtype in col_type_raw}

            # Define skip list
            skip_cols = {"customer_billing_period_id", "billing_period_id"}

            # Ensure all match_dict keys are present either in df or we inject them
            for col in match_dict.keys():
                if col not in df.columns and col not in skip_cols:
                    # Inject as constant column into df
                    df[col] = match_dict[col]

            all_columns = df.columns.tolist()

            # Exclude match + skip columns from update
            update_columns = [
                col for col in all_columns
                if col not in match_dict.keys() and col not in skip_cols
            ]
            logging.info(f"Update columns are {update_columns}")

            alias = 'incoming'

            # Step 2: Build SET clause
            set_clauses = []
            for col in update_columns:
                col_type = col_type_dict.get(col, None)
                if col_type:
                    if col_type == 'character varying':
                        col_type_cast = 'varchar'
                    elif col_type == 'timestamp without time zone':
                        col_type_cast = 'timestamp'
                    elif col_type == 'bigint':
                        col_type_cast = 'bigint'
                    elif col_type == 'integer':
                        col_type_cast = 'integer'
                    elif col_type == 'boolean':
                        col_type_cast = 'boolean'
                    else:
                        col_type_cast = col_type
                    clause = f"{col} = CASE WHEN {alias}.{col} IS NULL THEN NULL::{col_type_cast} ELSE {alias}.{col}::{col_type_cast} END"
                else:
                    clause = f"{col} = {alias}.{col}"
                set_clauses.append(clause)
            set_clause = ', '.join(set_clauses)

            # Step 3: Build WHERE clause (always col=col, no ANY)
            where_clauses = [
                f"{table_name}.{col} = {alias}.{col}"
                for col in match_dict.keys()
                if col not in skip_cols
            ]
            where_clause = ' AND '.join(where_clauses)

            # Step 4: Prepare values for execute_values
            values = [
                tuple(None if pd.isna(v) else v for v in row)
                for row in df.to_numpy()
            ]
            values_clause = ', '.join(all_columns)

            # Step 5: Construct query
            update_query = f"""
                UPDATE {table_name}
                SET {set_clause}
                FROM (VALUES %s) AS {alias} ({values_clause})
                WHERE {where_clause}
            """

            logging.info(f"Constructed UPDATE query:\n{update_query}")
            logging.info(f"join clause formed is {where_clause}")
            logging.info(f"Values prepared: {values[:2]} ...")

            # Step 6: Execute
            start_time = time.time()
            with conn.cursor() as cur:
                execute_values(cur, update_query, values, template=None, page_size=100)
            conn.commit()
            end_time = time.time()
            logging.info(f"Bulk update completed in {end_time - start_time:.2f} seconds.")
            logging.info(f"Updated {len(values)} rows in {table_name}.")

        except Exception as e:
            conn.rollback()
            logging.info(f"Bulk update failed for {table_name}: {e}")

    def bulk_update_table_bak_26_08_2025(self, conn, df, table_name, match_dict):

        if df.empty:
            logging.info(f"No data to update in {table_name}.")
            return

        try:
            # Step 1: Build col_type_dict dynamically from Postgres information_schema
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT column_name, data_type
                    FROM information_schema.columns
                    WHERE table_name = %s
                """, (table_name,))
                col_type_raw = cur.fetchall()
                col_type_dict = {col: dtype for col, dtype in col_type_raw}
                logging.info(f"Column types for {table_name}: {col_type_dict}")

            match_columns = list(match_dict.keys())

            # Check if all match columns are present
            missing_cols = [col for col in match_columns if col not in df.columns]
            if missing_cols:
                raise ValueError(f"Missing match columns in DataFrame: {missing_cols}")

            all_columns = df.columns.tolist()
            update_columns = [col for col in all_columns if col not in match_columns]

            alias = 'incoming'

            #  Step 2: Build SET clause with casting for NULLs and ELSE branches
            set_clauses = []
            for col in update_columns:
                col_type = col_type_dict.get(col, None)
                if col_type:
                    # Convert information_schema data_type to Postgres type syntax if needed
                    if col_type == 'character varying':
                        col_type_cast = 'varchar'
                    elif col_type == 'timestamp without time zone':
                        col_type_cast = 'timestamp'
                    elif col_type == 'bigint':
                        col_type_cast = 'bigint'
                    else:
                        col_type_cast = col_type

                    clause = f"{col} = CASE WHEN {alias}.{col} IS NULL THEN NULL::{col_type_cast} ELSE {alias}.{col}::{col_type_cast} END"
                else:
                    clause = f"{col} = {alias}.{col}"  # Fallback if type not found
                set_clauses.append(clause)

            set_clause = ', '.join(set_clauses)

            join_clause = ' AND '.join([f"{table_name}.{col} = {alias}.{col}" for col in match_columns])
            values_clause = ', '.join(all_columns)

            update_query = f"""
                UPDATE {table_name}
                SET {set_clause}
                FROM (VALUES %s) AS {alias} ({values_clause})
                WHERE {join_clause}
            """

            #  Step 3: Prepare values with None for NULLs
            values = [tuple(None if pd.isna(v) else v for v in row) for row in df.to_numpy()]

            logging.info(f"Constructed UPDATE query:\n{update_query}")
            logging.info(f"Values prepared: {values[:2]} ...")  # Preview first 2 rows for brevity


            start_time = time.time()
            with conn.cursor() as cur:

                execute_values(cur, update_query, values, template=None, page_size=100)
            conn.commit()
            end_time= time.time()
            logging.info(f"Bulk update completed in {end_time - start_time:.2f} seconds.")

            logging.info(f" Updated {len(values)} rows in {table_name}.")

        except Exception as e:
            conn.rollback()
            logging.info(f" Bulk update failed for {table_name}: {e}")
    def build_select_query_with_in_clause(self,base_query: str, condition_columns: list, condition_values: dict) -> str:
        """
        Appends WHERE/AND IN clauses to a SELECT SQL query for list-based conditions.

        :param base_query: Original SELECT query (without WHERE clause).
        :param condition_columns: List of column names to filter.
        :param condition_values: Dictionary with column names as keys and list of values to include.
        :return: Full SQL query string with IN clause(s).
        """
        conditions = []
        for col in condition_columns:
            values = condition_values.get(col)
            if values:
                formatted_vals = ', '.join(f"'{v}'" if isinstance(v, str) else str(v) for v in values)
                conditions.append(f"{col} IN ({formatted_vals})")

        if conditions:
            connector = "WHERE" if " where " not in base_query.lower() else "AND"
            return f"{base_query.strip()} {connector} " + " AND ".join(conditions)
        else:
            return base_query
    def insert_table_data(self,conn, df, table_name):
        """
        Inserts all rows from a DataFrame into a PostgreSQL table (no batching, no conflict handling).

        :param conn: psycopg2 connection
        :param df: Pandas DataFrame to insert
        :param table_name: Target PostgreSQL table
        """
        if df.empty:
            logging.info(f"No data to insert into {table_name}.")
            return

        try:
            df = df.replace({np.nan: None})
            def clean_value(val):
                if val is None:
                    return None
                if isinstance(val, float) and val.is_integer():
                    return int(val)
                if isinstance(val, int) and not (-2_147_483_648 <= val <= 2_147_483_647):
                    return str(val)  # Cast large integers to string
                return val
            values = [tuple(map(clean_value, row)) for row in df.itertuples(index=False, name=None)]
            columns_str = ', '.join(f'"{col}"' for col in df.columns)
            '''columns = df.columns.tolist()
            columns_str = ', '.join(columns)
            values = [tuple(row) for row in df.to_numpy()]'''
            insert_query = f"INSERT INTO {table_name} ({columns_str}) VALUES %s"
            logging.info(f"Constructed INSERT query:\n{insert_query} values are {values}")

            with conn.cursor() as cur:
                execute_values(cur, insert_query, values)
            conn.commit()
            logging.info(f"Inserted {len(values)} rows into {table_name}.")

        except Exception as e:
            conn.rollback()
            logging.info(f"Failed to insert data into {table_name}: {e}")
    def get_billing_period_ids_after(self, conn, effective_date, service_provider_id):
        """
        Fetch all billing period IDs greater than the one that includes effective_date
        for the given service_provider_id.

        :param conn: psycopg2 database connection
        :param effective_date: A string or datetime object
        :param service_provider_id: Integer
        :return: List of billing_period_id values greater than the matched one
        """
        query_current = """
            SELECT id
            FROM billing_period
            WHERE %s::timestamp BETWEEN billing_cycle_start_date AND billing_cycle_end_date
            AND service_provider_id = %s
            LIMIT 1;
        """

        query_following = """
            SELECT id
            FROM billing_period
            WHERE id >= %s AND service_provider_id = %s
            ORDER BY id;
        """

        try:
            with conn.cursor() as cur:
                # Step 1: Find the current billing period ID
                cur.execute(query_current, (effective_date, service_provider_id))
                result = cur.fetchone()
                logging.info("empty result gotten")
                if not result:
                    return []

                current_id = result[0]
                logging.info(f"effective in which cycle gotten is {current_id} ")

                # Step 2: Fetch all billing_period_id > current_id for the same service_provider_id
                cur.execute(query_following, (current_id, service_provider_id))
                ids = [row[0] for row in cur.fetchall()]
                logging.info(f"billing period ids gotten is {ids}")
                return ids

        except Exception as e:
            logging.info(f"Error fetching billing_period_ids: {e}")
            return []
    def find_effective_date(self,d):
        results = []
        if isinstance(d, dict):
            for k, v in d.items():
                if k == 'EffectiveDate':
                    results.append(v)
                else:
                    results.extend(self.find_effective_date(v))
        elif isinstance(d, list):
            for item in d:
                results.extend(self.find_effective_date(item))
        return results
    def clean_data_list_updated(self, data_list):
        """Convert NaT, NaN, and string 'null' values to None for PostgreSQL compatibility."""
        for record in data_list:
            for key, value in record.items():
                if isinstance(value, float) and (math.isnan(value) or value is None):
                    record[key] = None
                elif isinstance(value, pd._libs.tslibs.nattype.NaTType):
                    record[key] = None
                elif isinstance(value, pd.Timestamp):
                    if pd.isna(value):
                        record[key] = None
                elif isinstance(value, str) and value.strip().lower() in ["nat", "nan", "none", "null"]:
                    record[key] = None
        return data_list
    def get_customer_billing_period_id(self,db_config, effective_date):
        """
        Get billing period id(s) from customer_billing_period table.

        Rules:
        - If effective_date is in the future: return the latest (last) id.
        - Otherwise: return all ids where
            bill_year > effective_date.year
            OR bill_year = effective_date.year AND bill_month >= effective_date.month
        """

        try:
            # Connect to DB

            today = datetime.today().date()


            with db_config.cursor() as cursor:
                # Case 1: Future effective_date -> get the last id
                if effective_date.date() > today:
                    cursor.execute("SELECT id FROM customer_billing_period ORDER BY id DESC LIMIT 1;")
                    row = cursor.fetchone()
                    return row[0] if row else None

                # Case 2: Current or past -> match month & year logic
                bill_month = effective_date.month
                bill_year = effective_date.year
                logging.info(f"effetive date is {effective_date}")
                logging.info(f"bill year,billmonth is {bill_year} {bill_month}")

                query = """
                    SELECT id
                    FROM customer_billing_period
                    WHERE bill_year >= %s
                    AND (bill_year >= %s AND bill_month >= %s)
                    ORDER BY bill_year, bill_month;
                """

                cursor.execute(query, (bill_year, bill_year, bill_month))
                rows = cursor.fetchall()
                logging.info(f"ids are {rows}")

                # Return first id if found, else None
                return [row[0] for row in rows] if rows else []

        except Exception as e:
            logging.info(f"Error fetching billing period id: {e}")
            return None
    def cross_provider_sync(self, tenant_name, bulk_change_id, parent_tenant_id, postgres_data):
        try:
            logging.info(f"Starting cross_provider_sync for bulk_change_id {bulk_change_id} (reverse sync from 1.0 to 2.0)")

            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'

            tenant_id = parent_tenant_id
            data_list = postgres_data.get("sim_management_bulk_change", [])
            if not data_list:
                logging.warning("No sim_management_bulk_change data found.")
                return True

            service_provider_id = data_list[0].get("service_provider_id")
            logging.info(f"Service Provider ID: {service_provider_id}")

            # Load configs and get Telegence IDs
            json_data = self.load_json()
            telegence_ids = self.get_provider_ids(json_data, tenant_name, ["Telegence"])

            # Determine transfer_name and filtering conditions
            if tenant_name.lower() in ('altaworx_test', 'altaworx') and int(service_provider_id) in telegence_ids:
                transfer_name = "mobility_device_history_crossprovider_altaworx"
                msisdns = [item.get("subscriber_number") for item in postgres_data.get("sim_management_bulk_change_request", []) if "subscriber_number" in item]
                condition_cols = ["msisdn", "tenant_id"]
                condition_vals = {"msisdn": msisdns, "tenant_id": [tenant_id]}
                m2m=False
                inv_history='mobility_device_history'
            else:
                transfer_name = "device_history_crossprovider_altaworx"
                iccids = [item.get("iccid") for item in postgres_data.get("sim_management_bulk_change_request", []) if "iccid" in item]
                condition_cols = ["iccid", "tenant_id"]
                condition_vals = {"iccid": iccids, "tenant_id": [tenant_id]}
                m2m=True
                inv_history='device_history'

            logging.info(f"Transfer name: {transfer_name}")

            # Setup DB connections
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            postgres_conn1 = self.create_connection(db_type, hostname, db_name, user, password, port)

            mapping_table = os.getenv("MAPPING_TABLE")
            mapping_query = f"""
                SELECT db_name_20, db_config, reverse_table_mapping, reverse_col_mapping,
                    data_from_10, update_cond_cols, db_name_10, db_config
                FROM {mapping_table}
                WHERE transfer_name = '{transfer_name}'
                ORDER BY id ASC
            """
            mapping_details = self.execute_query(postgres_conn1, mapping_query)

            if mapping_details.empty:
                logging.warning("No mappings found for transfer.")
                return True

            mapping = mapping_details.to_dict(orient="records")[0]
            db_name_20 = mapping["db_name_20"]
            logging.info(f"Target DB: {db_name_20}")

            # Check cross-provider setting
            postgres_conn = self.create_connection(db_type, hostname, db_name_20, user, password, port)
            setting_query = f"""
                SELECT optino_cross_providercustomer_optimization
                FROM optimization_setting
                WHERE tenant_id = {parent_tenant_id}
            """
            setting_result = self.execute_query(postgres_conn, setting_query)

            if setting_result is not None and not setting_result.empty:
                is_cross_enabled = setting_result["optino_cross_providercustomer_optimization"][0]
                logging.info(f"Cross provider enabled: {is_cross_enabled}")
                if not is_cross_enabled:
                    logging.info("Cross provider sync is disabled. Skipping.")
                    return True
            else:
                logging.info("No cross-provider setting found. Skipping.")
                return True

            # Build query and fetch inventory
            data_query_raw = mapping["data_from_10"]
            select_query = data_query_raw[0]["query"]
            insert_table = data_query_raw[0]["table"]

            final_query = self.build_select_query_with_in_clause(select_query, condition_cols, condition_vals)
            logging.info(f"Inventory select query: {final_query}")

            inve_result = self.execute_query(postgres_conn, final_query)
            inv_dict = inve_result.to_dict(orient='records') if not inve_result.empty else []
            logging.info(f"Inventory rows fetched: {len(inv_dict)}")

            try:
                cleaned_data = self.clean_data_list(inv_dict)
                inve_result = pd.DataFrame(cleaned_data)
            except Exception as e:
                logging.error(f"Error during data cleanup: {e}")
                return True

            logging.info(f"Inventory rows after cleaning {inve_result}")
            logging.info(f"Inventory rows fetched: {len(inve_result)}")

            # Insert data
            self.insert_table_data(postgres_conn, inve_result, insert_table)
            logging.info(f"Inserted inventory data into {insert_table}")
            self.insert_table_data(postgres_conn, inve_result, inv_history)
            logging.info(f"Inserted inventory data into {inv_history}")


            # Get effective date
            effective_date_query = f"""
                SELECT change_request
                FROM sim_management_bulk_change_request
                WHERE bulk_change_id = {bulk_change_id}
                ORDER BY id DESC
                LIMIT 1
            """
            try:
                effective_result = self.execute_query(postgres_conn, effective_date_query)
                if effective_result.empty:
                    logging.warning("No effective date found.")
                    return True

                effective_json_str = effective_result['change_request'][0]
                effective_date_json = json.loads(effective_json_str)
                effective_date = self.find_effective_date(effective_date_json)

                if not effective_date:
                    logging.warning("Effective date not found in JSON.")
                    return True

                effective_date_obj = datetime.fromisoformat(effective_date[0])
            except Exception as e:
                logging.error(f"Error retrieving effective date: {e}")
                return True
            logging.info(f"Effective date: {effective_date_obj} {bulk_change_id}")
            logging.info(f"M2m or inventory is {m2m} {bulk_change_id}")
            if m2m:
                filtered_dict = inve_result[["m2m_device_id", "service_provider_id","tenant_id"]].to_dict(orient="list")
            else:
                filtered_dict = inve_result[["mobility_device_id", "service_provider_id","tenant_id"]].to_dict(orient="list")

            # Get billing period IDs
            #billing_ids = self.get_billing_period_ids_after(postgres_conn, effective_date_obj, int(service_provider_id))
            billing_ids = self.get_customer_billing_period_id(postgres_conn, effective_date_obj)
            if not billing_ids:
                logging.info("No billing period IDs found.")
                return True

            filtered_dict["customer_billing_period_id"] = billing_ids
            logging.info(f"Customer billing period IDs: {billing_ids}")

            # Bulk update with billing IDs
            try:
                batch_size = 1000
                df = inve_result.copy()
                df_expanded = pd.concat([df.assign(billing_period_id=bp) for bp in billing_ids], ignore_index=True)

                num_batches = math.ceil(len(df_expanded) / batch_size)
                for i in range(num_batches):
                    start_idx = i * batch_size
                    end_idx = min((i + 1) * batch_size, len(df_expanded))
                    df_batch = df_expanded.iloc[start_idx:end_idx]
                    self.bulk_update_table(postgres_conn, df_batch, insert_table, filtered_dict)
            except Exception as e:
                logging.info(f"Error during bulk update: {e}")

        except Exception as e:
            logging.error(f"Exception in cross_provider_sync: {e}")

        return True

