import boto3
import os
import json
import time
from datetime import datetime
from user_login import funtion_caller
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging
from common_utils.email_trigger import get_memory_usage, memory_sns
from common_utils.authentication_check import validate_token, Validate_Ui_token
from common_utils.permission_manager import PermissionManager

# Dictionary to store database configuration settings retrieved from environment variables.
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}

# Initialize the SNS client
sns = boto3.client("sns")
cloudwatch = boto3.client("cloudwatch")


def get_logging_instance(session_id):
    global logging
    logging = Logging(name="user_authentication", session_id=session_id)
    return True


def lambda_handler(event, context):

    data = event.get("data")
    if not data:
        return {"message": "No details provided or Invalid details", "status_code": 400}
    if data:
        try:
            data = data
        except json.JSONDecodeError:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid JSON in body"}),
            }
    else:
        data = {}

    # Extract the HTTP method, path, and query string parameters from the event
    if "data" in data:
        data = data.get("data")
    service_path = event.get("path")
    if service_path:
        data["path"] = service_path
    path = data.get("path")

    # Get the current time when the request is received
    request_received_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    session_id = data.get("sessionID", "Common_id")
    get_logging_instance(session_id)

    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    performance_matrix = {}
    # Record the start time of the function
    start_time = time.time()
    performance_matrix["start_time"] = (
        f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time))}.{int((start_time % 1) * 1000):03d}"
    )
    logging.info(
        f"Request received at {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time))}.{int((start_time % 1) * 1000):03d}"
    )

    # token validation
    result = {}
    access_token = ""
    verified_request = True
    if path != "/get_auth_token" and path != "/login_using_database":
        access_token = data.get("z_access_token", "")
        if access_token and not validate_token(access_token):
            result = {"message": "AD INVALID TOKEN"}
            result["status_code"] = 401
            result["flag"] = False
            verified_request = False

        # ui_token=data.get('access_token','')
        # username = data.get('username')
        # elif ui_token and not Validate_Ui_token(username,access_token) and verified_request:
        #     result = {"message": "AD INVALID TOKEN"}
        #     result["status_code"] = 401
        #     result['flag']=False
        #     verified_request=False

    # permission validation
    if path not in ("/login_using_database","/get_auth_token"):
        if verified_request:
            permission_manager_instance = PermissionManager(db_config)
            result = permission_manager_instance.permission_manager(data)
            if isinstance(result, dict) and result.get("flag") is False:
                result.pop("flag")
                verified_request = False
                result["status_code"] = 400

    if verified_request:
        result = funtion_caller(path, data)

    if result.get("flag") == False:
        status_code = 400  # You can change this to an appropriate error code
        # Sending email
        result_response = send_email("Exception Mail")
        if isinstance(result, dict) and result.get("flag") is False:
            logging.info(result)
        else:
            to_emails, cc_emails, subject, body, from_email, partner_name = (
                result_response
            )
            common_utils_database.update_dict(
                "email_templates",
                {"last_email_triggered_at": request_received_at},
                {"template_name": "Exception Mail"},
            )
            query = """
                SELECT parents_module_name, sub_module_name, child_module_name, partner_name
                FROM email_templates
                WHERE template_name = 'Exception Mail'
            """

            # Execute the query and fetch the result
            email_template_data = common_utils_database.execute_query(query, True)
            if not email_template_data.empty:
                # Unpack the results
                (
                    parents_module_name,
                    sub_module_name,
                    child_module_name,
                    partner_name,
                ) = email_template_data.iloc[0]
            else:
                # If no data is found, assign default values or log an error
                parents_module_name = ""
                sub_module_name = ""
                child_module_name = ""
                partner_name = ""

            # Email audit logging
            error_message = result.get(
                "error", "Unknown error occurred"
            )  # Extracting the error message
            email_audit_data = {
                "template_name": "Exception Mail",
                "email_type": "Application",
                "partner_name": partner_name,
                "email_status": "success",
                "from_email": from_email,
                "to_email": to_emails,
                "cc_email": cc_emails,
                "comments": f"{path} - Error: {error_message}",  # Adding error message to comments
                "subject": subject,
                "body": body,
                "action": "Email triggered",
                "parents_module_name": parents_module_name,
                "sub_module_name": sub_module_name,
                "child_module_name": child_module_name,
            }
            common_utils_database.update_audit(email_audit_data, "email_audit")

    else:
        status_code = 200

    # Record the end time of the function
    end_time = time.time()
    performance_matrix["end_time"] = (
        f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
    )
    performance_matrix["execution_time"] = f"{end_time - start_time:.4f}"
    logging.info(
        f"Request processed at {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
    )
    logging.info(f"Function performance_matrix: {performance_matrix} seconds")

    memory_limit = int(context.memory_limit_in_mb)
    memory_used = int(get_memory_usage()) + 100
    final_memory_used = get_memory_usage()
    logging.info(
        f"$$$$$$$$$$$$$$$$$$$$$$$Final Memory Used: {final_memory_used:.2f} MB"
    )
    memory_sns(memory_limit, memory_used, context)

    if access_token or path == "/get_auth_token" or path=='/generate_access_token':
        return result
    else:
        return {
            "statusCode": status_code,
            "body": json.dumps(result,default=str),
            "performance_matrix": json.dumps(performance_matrix),
        }
