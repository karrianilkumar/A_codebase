"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil .N
Created Date: 21-06-24
"""

# Importing the necessary Libraries

import os
import string
import json
import random
import uuid
import requests
import base64
import hashlib
import pandas as pd
from time import time
from hashlib import md5
from base64 import b64decode
from Crypto.Cipher import AES
from datetime import datetime, timezone
from requests.auth import HTTPBasicAuth
from urllib.parse import urlparse, parse_qs, urljoin

from common_utils.logging_utils import Logging
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email

logging = Logging(name="user_authentication")

def get_logging_instance(session_id):
    global logging
    logging=Logging(name="user_authentication", session_id=session_id)
    return True

# Dictionary to store database configuration settings retrieved from environment variables.
def db_config_maker(user,db_config_making):
    """
    Generates and updates a database configuration dictionary with user-specific access filters.

    This function retrieves the list of customers and service providers associated with the given user
    from the 'users' table in the database. It then updates the provided db_config_making dictionary
    with these values under the keys 'customers' and 'service_providers'.

    Args:
        user (str): The username for which to fetch access filters.
        db_config_making (dict): The base database configuration dictionary to update.

    Returns:
        dict: The updated db_config_making dictionary with user-specific access filters.
    """

    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config_making)

    query="select customers,service_provider from users where username = %s"
    filters=common_utils_database.execute_query(query, params=[user])
    try:
        customer=tuple(json.loads(filters['customers'].to_list()[0]))
    except Exception as e:
        logging.info(f"### db_config_maker customer exception : {e}")
        customer=None
    try:
        service_provider=tuple(json.loads(filters['service_provider'].to_list()[0]))
    except Exception as e:
        logging.info(f"### db_config_maker service_provider exception : {e}")
        service_provider=None

    db_config_making["customers"]= customer
    db_config_making["service_providers"]=service_provider

    return db_config_making


def funtion_caller(path,data):
    """
    Routes incoming authentication and user management requests to the appropriate handler function.

    This function initializes the database configuration using environment variables and user-specific access filters.
    It then selects the correct handler based on the provided API path and executes it with the given data.

    Args:
        path (str): The API endpoint path (e.g., "/login_using_database", "/reset_password_email").
        data (dict): The request payload containing necessary parameters for the selected handler.

    Returns:
        dict: The response from the called handler function. If the path is invalid, returns:
              {"flag": False, "error": "Invalid path or method"}
    """

    global db_config

    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

    user=data.get('username')
    if not user:
        user=data.get('user_name')

    db_config_making=db_config_maker(user,db_config)
    db_config=db_config_making
    logging.info(f"db_config created is : {db_config}")

    session_id=data.get("sessionID","Common_id")
    get_logging_instance(session_id)

    ROUTES = {
        "/login_using_database": login_using_database,
        "/reset_password_email": reset_password_email,
        "/token_check": token_check,
        "/generate_access_token": generate_access_token,
        "/get_auth_token": generate_access_token,  # same handler as above
        "/get_user_auth_token": get_auth_token,
        "/get_service_account": get_service_account,
        "/create_service_account": create_service_account,
        "/process_service_account": process_service_account,
        "/login_to_cyberreef": login_to_cyberreef,
        "/password_reset": password_reset,
        "/impersonate_login_using_database": impersonate_login_using_database,
        "/logout": logout,
        "/get_redirection_modules": get_redirection_modules,
        "/create_machine_user": create_machine_user,
        "/regenarate_client_secret": regenarate_client_secret,
    }

    handler = ROUTES.get(path)
    if handler:
        return handler(data)
    return {"flag": False, "error": "Invalid path or method"}

# def get_request_id():
#     """
#     Retrieves the request ID from an authorization URL by making a GET request with specified parameters.

#     Args:
#         data (dict): A dictionary containing request-specific data (not used in this function).

#     Returns:
#         str: The extracted request ID from the URL query parameters, or None if not found.
#     """
#     try:
#         # Retrieve the URL for the authorization endpoint from an environment variable
#         url = os.getenv("REQUEST_ID_URL", " ")
#         # Retrieve the client ID and redirect URI from environment variables
#         client_id = os.getenv("CLIENT_ID", " ")
#         redirect_uri = os.getenv("REDIRECT_URL", " ")
#         # Define the response type and scope for the authorization request
#         response_type = "code"
#         scope = "openid email profile offline_access urn:zitadel:iam:user:metadata"
#         # Define request headers
#         headers = {
#             "x-zitadel-login-client": "278680282679256500",
#             "Cookie": "_Host-zitadel.useragent=MTcyMzA5OTU3N...",
#             "Cache-Control": "no-cache",
#             "User-Agent": "PostmanRuntime/7.41.0",
#             "Accept": "*/*",
#             "Accept-Encoding": "gzip, deflate, br",
#             "Connection": "keep-alive",
#         }
#         # Define query parameters for the GET request
#         params = {
#             "client_id": client_id,
#             "redirect_uri": redirect_uri,
#             "response_type": response_type,
#             "scope": scope,
#         }
#         # Send a GET request
#         response = requests.get(url, params=params, headers=headers)
#         # Parse the URL and extract the request ID
#         parsed_url = urlparse(response.url)
#         query_params = parse_qs(parsed_url.query)

#         # Extract the request ID from the query parameters
#         request_id = query_params.get("authRequest", [None])[0]

#         return request_id
#     except Exception as e:
#         logging.exception(f"Exception is {e}")
#         message = "Something went wrong fetching request id"
#         return None

def get_request_id():
    """
    Retrieves the request ID from an authorization URL by making a GET request with specified parameters.

    Returns:
        str: The extracted request ID from the URL query parameters, or None if not found.
    """
    try:
        # Retrieve environment variables
        url = os.getenv("REQUEST_ID_URL", " ")
        # Retrieve the client ID and redirect URI from environment variables
        client_id = os.getenv("CLIENT_ID", " ")
        redirect_uri = os.getenv("REDIRECT_URL", " ")

        service_account_id=os.getenv('SERVICE_ACCOUNT_ID')
        if not url or not client_id or not redirect_uri or not service_account_id:
            logging.error("### get_request_id Missing required environment variables.")
            return None

        # Define authorization request parameters
        params = {
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": "openid email profile offline_access urn:zitadel:iam:user:metadata",
        }

        # Define request headers
        headers = {
            "x-zitadel-login-client": service_account_id,
            "Cache-Control": "no-cache",
            "User-Agent": "PythonRequests/2.x",
            "Accept": "*/*",
        }

        # Send a GET request to the authorization URL
        response = requests.get(url, params=params, headers=headers, allow_redirects=False)

        # Check if the response contains a redirect location
        if "Location" not in response.headers:
            logging.error("### get_request_id No redirect location found in response.")
            return None

        # Parse the URL and extract the request ID
        parsed_url = urlparse(response.headers["Location"])
        query_params = parse_qs(parsed_url.query)
        request_id = query_params.get("authRequest", [None])[0]

        if not request_id:
            logging.error("### get_request_id Request ID not found in the redirect URL.")
            return None

        return request_id

    except Exception as e:
        logging.exception(f"### get_request_id Error fetching request ID : {e}")
        return None


def create_user(
    username, given_name, family_name, display_name, email, phone, password
):
    """
    Creates a new user in the system by sending a POST request to the specified URL with user details.
    Args:
        username (str): The username of the new user.
        given_name (str): The given name of the new user.
        family_name (str): The family name of the new user.
        display_name (str): The display name of the new user.
        email (str): The email address of the new user.
        phone (str): The phone number of the new user.
        password (str): The password for the new user.

    Returns:
        dict: The response from the server in JSON format, or an error message if an exception occurs.
    """
    try:
        # Retrieve the URL for creating a new user and Authentication token from an environment variable
        url = os.getenv("CREATE_USER_URL", " ")
        auth_token = os.getenv("AUTH_TOKEN", " ")
        # Define the request payload with user details
        payload = {
            "username": username,
            "profile": {
                "givenName": given_name,
                "familyName": family_name,
                "displayName": display_name,
                "prefferedLanguage": "en",
                "gender": "GENDER_UNSPECIFIED",
            },
            "email": {"email": email, "isVerified": True},
            "phone": {"phone": phone, "isVerified": True},
            "password": {"password": password, "changeRequired": False},
        }

        ## Define the headers for the POST request
        headers = {
            "Authorization": f"Bearer {auth_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Cache-Control": "no-cache",
            "User-Agent": "PostmanRuntime/7.41.0",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
        }

        # Send a POST request to create the new use
        response = requests.post(url, json=payload, headers=headers)
        # Return the response JSON
        try:
            return response.json()
        except ValueError:
            # If response is not JSON, logging.info the raw text
            logging.warning(f"### create_user Response Text:{response.text}")
            return None
    except Exception as e:
        logging.exception(f"### create_user Exception is {e}")
        message = "Something went wrong creating new user in Authentication"
        response = {"flag": False, "message": message}
        return response


def authenticate_user(username, password):
    """
    Authenticates a user by sending a POST request to the authentication endpoint with the username and password.

    Args:
        username (str): The username of the user to authenticate.
        password (str): The password of the user to authenticate.

    Returns:
        tuple: A tuple containing the session ID and session token if successful, or a dictionary with an error message if an exception occurs.
    """
    try:
        # Retrieve the URL for the authentication endpoint from an environment variable
        url = os.getenv("AUTHENTICATE_USER_URL", " ")
        # Retrieve the authorization token from an environment variable
        auth_token = os.getenv("AUTH_TOKEN", " ")
        # Define the request body with the provided username and password
        data = {
            "checks": {
                "user": {"loginName": username},
                "password": {"password": password},
            }
        }

        # Define the headers with the provided authorization token
        headers = {
            "Authorization": f"Bearer {auth_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Cache-Control": "no-cache",
            "User-Agent": "PostmanRuntime/7.41.0",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
        }

        # Send a POST request
        response = requests.post(url, json=data, headers=headers)
        # Extract sessionId and sessionToken from the response
        response_data = response.json()
        session_id = response_data.get("sessionId")
        session_token = response_data.get("sessionToken")
        return session_id, session_token
    except Exception as e:
        logging.exception(f"### authenticate_user Exception is {e}")
        message = (
            "Something went wrong fetching sessionid and sessiontoken using  Authentication"
        )
        response = {"flag": False, "message": message}
        return response


def send_auth_request(auth_request_id, session_id, session_token):
    """
    Sends an authorization request to the specified endpoint and extracts the authorization code from the response.

    Args:
        auth_request_id (str): The ID for the authentication request.
        session_id (str): The session ID obtained from the authentication process.
        session_token (str): The session token obtained from the authentication process.

    Returns:
        str: The authorization code extracted from the callback URL, or None if an error occurs
    """
    try:
        # Base URL with the placeholder for authRequestId
        base_url_without_authrequestid = os.getenv("SEND_AUTH_REQUEST_URL", " ").rstrip(
            "/"
        )

        base_url = f"{base_url_without_authrequestid}/{auth_request_id}"
        auth_token = os.getenv("AUTH_TOKEN", " ")
        # Construct the full URL by formatting the base URL with the auth_request_id
        url = base_url.format(authRequestId=auth_request_id)

        # Request body
        payload = {"session": {"sessionId": session_id, "sessionToken": session_token}}

        # Define the headers for the POST request, including the authorization token
        headers = {
            "Authorization": f"Bearer {auth_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Cache-Control": "no-cache",
            "User-Agent": "PostmanRuntime/7.41.0",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
        }

        # Send the POST request to the constructed URL with the headers and payload
        response = requests.post(url, headers=headers, json=payload)
        try:
            # Attempt to parse the response as JSON
            response_data = response.json()
            # logging.info(f"Response JSON:{response_data}")

            # Extract the callbackUrl from the response
            callback_url = response_data.get("callbackUrl", "")

            # Parse the authorization code from the callbackUrl
            parsed_url = urlparse(callback_url)
            query_params = parse_qs(parsed_url.query)
            auth_code = query_params.get("code", [None])[0]

            return auth_code

        except Exception as e:
            # If response is not JSON, logging.info the raw text
            logging.warning(f"### send_auth_request Response Text: {response.text} - exception : {e}")
            return None
    except Exception as e:
        logging.exception(f"### send_auth_request Exception is {e}")
        message = "Something went wrong fetching auth_code using  Authentication"
        response = {"flag": False, "message": message}
        return response


def get_access_token(auth_code):
    """Retrieves an access token using the authorization code and request ID.

    Args:
        auth_code (str): The authorization code received after user authentication.
        auth_request_id (str): The ID of the authentication request (not used in this function but included for context).

    Returns:
        str: The access token if the request is successful, or None if an error occurs.
    """
    try:
        # Define the URL
        url = os.getenv("ACCESS_TOKEN_URL", " ")
        client_id = os.getenv("CLIENT_ID", " ")
        client_secret = os.getenv("CLIENT_SECRET", " ")
        redirect_uri = os.getenv("REDIRECT_URL", " ")
        auth_token = os.getenv("AUTH_TOKEN", " ")

        # Define the form data for x-www-form-urlencoded
        data = {
            "client_id": client_id,
            "client_secret": client_secret,
            "grant_type": "authorization_code",
            "redirect_uri": redirect_uri,
            "code": auth_code,
        }

        # Define the headers (removing Accept-Encoding)
        headers = {
            "Authorization": f"Bearer {auth_token}",
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
            "Cache-Control": "no-cache",
            "User-Agent": "PostmanRuntime/7.41.0",
            "Connection": "keep-alive",
        }

        # Send a POST request
        response = requests.post(url, data=data, headers=headers)
        logging.info(f"### get_access_token response is {response}")
        # Check if the response is in JSON format
        # content_type = response.headers.get("Content-Type", "")
        # if 'application/json' in content_type:
        try:
            response_data = response.json()
            access_token = response_data.get("access_token")
            return access_token
        except ValueError:
            # If JSON decoding fails, logging.info the raw text
            logging.info(f"### get_access_token Response Text:  {response.text}")
            return None

    except Exception as e:
        logging.exception(f"### get_access_token Exception is {e}")
        message = "Something went wrong fetching auth_code using  Authentication"
        response = {"flag": False, "message": message}
        return response


def update_user_in_zitadel(user_id, email, phone, password):
    """
    Updates the password of a user in the Zitadel system.

    Parameters:
        user_id (str): The unique ID of the user to update.
        email (str): User's email (currently not used).
        phone (str): User's phone (currently not used).
        password (str): The new password for the user.

    Returns:
        bool: True if the password update was successful, False otherwise.
    """
    try:
        zitadel_domain = os.getenv("zitadel_domain", " ")
        access_token = os.getenv("AUTH_TOKEN", " ")

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }

        # API endpoint for updating the password
        password_url = (
            f"https://{zitadel_domain}/management/v1/users/{user_id}/password"
        )
        password_payload = {"password": password, "changeRequired": False}

        # Send a POST request to update the password
        password_response = requests.post(
            password_url, headers=headers, json=password_payload
        )
        logging.info(f"### update_user_in_zitadel password response - {password_response}")

        # Check response status
        if password_response.status_code != 200:
            return False

        return True
    except Exception as e:
        logging.error("### update_user_in_zitadel Error here", e)
        return False


def process_service_account(data):
    """
    Handles operations on service accounts, such as updating or deleting accounts.

    Parameters:
        data (dict): Dictionary containing account details like client_id, client_secret, role, tenant, etc.

    Returns:
        dict: Response indicating the success or failure of the operation.
    """
    start_time = time()
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:

        # Extract necessary data from the input dictionary
        client_id = data.get("client_id")
        client_secret = data.get("client_secret")
        role = data.get("role")
        tenant = data.get("tenant")
        email = data.get("email")
        phone = data.get("phone")
        tax_profile = data.get("tax_profile")
        flag = data.get("flag")

        if flag == "update":
            # Update details in the database
            data = {
                "client_id": client_id,
                "client_secret": client_secret,
                "role": role,
                "tenant": tenant,
                "email": email,
                "phone": phone,
                "tax_profile": tax_profile,
            }
            database.update_dict("service_accounts", data, {"client_id": client_id})
            logging.info("### process_service_account User updated successfully")
            
            message = "Updated successfully"

        elif flag == "delete":
            # Mark the account as inactive in the database
            user_id = database.get_data(
                "service_accounts", {"client_id": client_id}, ["user_id"]
            )["user_id"].to_list()[0]
            data = {"is_active": "False"}
            database.update_dict("service_accounts", data, {"user_id": user_id})
            #response_data = update_user_in_zitadel(user_id, email, phone, client_secret)
            message = "Deleted successfully"

        response = {"flag": True, "message": message}
        try:
        # End time calculation
            end_time = time()
            time_consumed = end_time - start_time
            ## Auditing
            audit_data = {
                "service_name": "process_service_account",
                "created_date": datetime.now(),
                "created_by": client_id,
                "status": True,
                "time_consumed_secs": time_consumed,
                "session_id": None,
                "tenant_name": tenant,
                "comments": "service account processed",
                "module_name": "User_authentication",
                "request_received_at": datetime.now(),
            }
            database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### process_service_account audit_user_actions exception : {e}")
        return response

    except Exception as e:
        logging.exception(f"### process_service_account Exception is {e}")
        message = "Error while processing service account details"
        response = {"flag": False, "message": message}
        error_data = {
            "service_name": "process_service_account",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("client_id"),
            "session_id": None,
            "tenant_name": data.get("tenant"),
            "comments": "process_service_account failed",
            "module_name": "User_authentication",
            "request_received_at": datetime.now(),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response

def get_service_account(data):
    """
    Retrieves a list of active service accounts along with additional metadata.

    Parameters:
        data (dict): Contains pagination details such as 'limit' and 'offset'.

    Returns:
        dict: A dictionary containing the service accounts, total count, tenants, roles, and tax profiles.
    """
    start_time = time()
    try:
        logging.info(f"### get_service_account Data is {data}")
        limit = data.get("limit", 10)
        start = data.get("offset", 0)
        end = start + limit

        database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        # Fetch paginated service account data
        response_data = database.get_data(
            "service_accounts",
            {"is_active": "True"},
            order={"id": "desc"},
            mod_pages={"start": start, "end": end},
        ).to_dict(orient="records")

        # Get additional metadata
        total = len(
            database.get_data("service_accounts", columns=["user_id"])[
                "user_id"
            ].to_list()
        )
        tenants = list(
            set(
                database.get_data("tenant", {"is_active": True}, ["tenant_name"])[
                    "tenant_name"
                ].to_list()
            )
        )
        roles = list(
            set(
                database.get_data("roles", {"is_active": True}, ["role_name"])[
                    "role_name"
                ].to_list()
            )
        )
        tax_profile = []
        try:
            # End time calculation
            end_time = time()
            time_consumed = end_time - start_time
            ## Auditing
            audit_data = {
                "service_name": "get_service_account",
                "created_date": datetime.now(),
                "created_by": "",
                "status": True,
                "time_consumed_secs": time_consumed,
                "session_id": None,
                "tenant_name": "",
                "comments": "service accounts fetched",
                "module_name": "User_authentication",
                "request_received_at": datetime.now(),
            }
            database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### get_service_account audit_user_actions exception : {e}")

        return {
            "flag": True,
            "results": response_data,
            "totalResults": total,
            "tenants": tenants,
            "roles": roles,
            "tax_profile": tax_profile,
        }

    except Exception as e:
        logging.exception(f"### get_service_account Exception is {e}")
        message = "Error getting service account details"
        response = {"flag": False, "message": message}
        error_data = {
            "service_name": "get_service_account",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": "",
            "session_id": None,
            "tenant_name": "",
            "comments": "get_service_account failed",
            "module_name": "User_authentication",
            "request_received_at": datetime.now(),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response


def generate_client_secret(length=20):
    """
    Generates a random client secret string of the specified length.

    The client secret consists of uppercase and lowercase ASCII letters and digits.
    The minimum allowed length is 8 characters; otherwise, a ValueError is raised.

    Args:
        length (int, optional): The desired length of the client secret. Default is 20.

    Returns:
        str: A randomly generated client secret string.

    Raises:
        ValueError: If the specified length is less than 8.
    """

    if length < 8:
        raise ValueError("Client secret length should be at least 8 characters.")

    all_characters = string.ascii_letters + string.digits

    client_secret = ''.join(random.choices(all_characters, k=length))

    return client_secret

def create_service_account(data):
    """
    Creates a new service account in the system and stores it in the database.

    Parameters:
        data (dict): Should contain:
            - client_id (str)
            - client_secret (str)
            - role (str)
            - tenant (str)
            - email (str)
            - phone (str)
            - tax_profile (str)
            - user_id (str)
            - z_access_token (optional str)

    Returns:
        dict: 
          On success: {'flag': True, 'message': 'User created successfully'}
          On failure: {'flag': False, 'message': <error message>}
    """
    logging.info("### create_service_account data: %s", data)
    start_time = time()

    try:
        db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.exception("### create_service_account Database connection failed:")
        return {"flag": False, "message": f"Database connection failed: {e}"}

    # Extract all expected fields with defaults
    client_id = data.get("client_id", "")
    client_secret = data.get("client_secret", "")
    role = data.get("role", "")
    tenant = data.get("tenant", "")
    email = data.get("email", "")
    phone = data.get("phone", "")
    tax_profile = data.get("tax_profile", "")
    user_id = data.get("user_id", "")
    z_access_token = data.get("z_access_token", "")

    # Validate mandatory inputs
    if not all([client_id, client_secret, role, tenant, user_id]):
        msg = "Missing required fields for service account creation."
        logging.error(msg)
        return {"flag": False, "message": msg}

    try:
        # Prepare insert payload
        record = {
            "client_id": client_id,
            "client_secret": client_secret,
            "role": role,
            "tenant": tenant,
            "email": email,
            "phone": phone,
            "tax_profile": tax_profile,
            "user_id": user_id,
            "is_active": "True",
        }

        db.insert_dict(record, "service_accounts")
        logging.info(f"### create_service_account Service account created successfully for client_id: {client_id}")

        response = {"flag": True, "message": "Service account created successfully."}
        try:
            # End time calculation
            end_time = time()
            time_consumed = end_time - start_time
            ## Auditing
            audit_data = {
                "service_name": "create_service_account",
                "created_date": datetime.now(),
                "created_by": user_id,
                "status": True,
                "time_consumed_secs": time_consumed,
                "session_id": None,
                "tenant_name": tenant,
                "comments": f"service account created for client - {client_id}",
                "module_name": "User_authentication",
                "request_received_at": datetime.now(),
            }
            db.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### create_service_account audit_user_actions exception : {e}")
        # If the token was passed, optionally return it
        if z_access_token:
            response["z_access_token"] = z_access_token
        return response

    except Exception as e:
        logging.exception(f"### create_service_account Error inserting service account record: {e}")
        error_data = {
            "service_name": "create_service_account",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": user_id,
            "session_id": None,
            "tenant_name": "",
            "comments": f"create_service_account failed for client - {client_id}",
            "module_name": "User_authentication",
            "request_received_at": datetime.now(),
        }
        db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "Failed to create service account"}


def get_auth_token(data):
    """
    Retrieves an authentication token for a service account.

    Parameters:
        data (dict): Contains client_id and client_secret for authentication.

    Returns:
        dict: A dictionary containing the access token or an error message.
    """
    start_time = time()
    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        client_id = data.get("client_id")
        client_secret = data.get("client_secret")

        if not client_secret or not client_id:
            return {"message": "Missing credentials", "status_code": 400}

        # Fetch client secret from the database
        user_info = database.get_data(
            "service_accounts", {"client_id": client_id}, ["client_secret"]
        )
        db_client_secret = user_info["client_secret"].to_list()

        if db_client_secret:
            db_client_secret = db_client_secret[0]
        else:
            return {"message": "Not registered", "status_code": 400}

        if db_client_secret != client_secret:
            return {"message": "Invalid secret code", "status_code": 400}

        # Authenticate and retrieve session information
        auth_request_id = get_request_id()
        logging.info(f"### get_auth_token auth_request_id is {auth_request_id}")

        session_id, session_token = authenticate_user(client_id, client_secret)
        logging.info(f"### get_auth_token session_id is {session_id}")
        logging.info(f"### get_auth_token session_token is {session_token}")

        # Exchange authorization code for access token
        auth_code = send_auth_request(auth_request_id, session_id, session_token)
        logging.info(f"### get_auth_token auth_code is {auth_code}")

        access_token = get_access_token(auth_code)
        logging.info(f"### get_auth_token access_token is {access_token}")
        try:
            # End time calculation
            end_time = time()
            time_consumed = end_time - start_time
            ## Auditing
            audit_data = {
                "service_name": "get_auth_token",
                "created_date": datetime.now(),
                "created_by": client_id,
                "status": "True",
                "time_consumed_secs": time_consumed,
                "session_id": None,
                "tenant_name": "",
                "comments": f"Auth token generated for user - {client_id}",
                "module_name": "User_authentication",
                "request_received_at": datetime.now(),
            }
            database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### get_auth_token audit_user_actions exception : {e}")

        return {"access_token": access_token}

    except Exception as e:
        logging.exception(f"### get_auth_token Exception is {e}")
        message = "Something went wrong while generating access token"
        response = {"message": message, "status_code": 500}
        error_data = {
            "service_name": "get_auth_token",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": client_id,
            "session_id": None,
            "tenant_name": "",
            "comments": "generate auth token failed",
            "module_name": "User_authentication",
            "request_received_at": datetime.now(),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response


def fetch_request_id_from_authorize():
    """
    Performs a GET to the ZITADEL authorize endpoint and extracts the authRequest value
    (your request_id) from the Location header. Returns the request_id or None if not found.
    """
    CLIENT_ID=os.getenv('ZITADEL_CLIENTID',None)
    REDIRECT_URI=os.getenv('REDIRECT_URL',None)
    ZITADEL_API_BASE_URL = os.getenv('ZITADEL_API_BASE_URL',None)
    try:
        params = {
            "client_id": CLIENT_ID,
            "redirect_uri": REDIRECT_URI,
            "response_type": "code",
            "scope": "openid email profile offline_access urn:zitadel:iam:user:metadata"
        }

        resp = requests.get(
            f"{ZITADEL_API_BASE_URL}/oauth/v2/authorize",
            params=params,
            headers={"x-zitadel-login-client": CLIENT_ID},
            allow_redirects=False
        )
        location = resp.headers.get("Location")
        if not location:
            logging.error("No Location header found in authorize response")
            return None

        parsed = urlparse(location)
        params = parse_qs(parsed.query)
        request_id = params.get("authRequest", [None])[0]
        if not request_id:
            logging.error("authRequest parameter missing in redirect URL")
            return None

        return request_id
    except Exception as e:
        logging.exception(f"Failed to retrive the request id")




def retrieve_session_id_and_session(username, password):
    """
    Authenticates via username/password using ZITADEL v2 session API.
    Returns (session_id, session_token).
    """
    ZITADEL_API_BASE_URL = os.getenv('ZITADEL_API_BASE_URL',None)
    url = f"{ZITADEL_API_BASE_URL}/v2/sessions"
    TOKEN=os.getenv('ZITADEL_TOKEN',None)
    headers = {
        "Authorization": f"Bearer {TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "checks": {
            "user": {"loginName": username},
            "password": {"password": password}
        }
    }

    resp = requests.post(url, json=payload, headers=headers)
    resp.raise_for_status()
    data = resp.json()

    session_id = data.get("sessionId")
    session_token = data.get("sessionToken")
    if not session_id or not session_token:
        raise ValueError("Unexpected session response format")

    return session_id, session_token


def get_auth_code(request_id,session_id, session_token):
    """
    Finalizes the auth request with ZITADEL and returns the authorization code.

    - base_url: e.g. "https://testing-x2kmoa.zitadel.cloud"
    - auth_id: the authRequestId
    - session_id / session_token: from the session creation
    - api_token: Bearer token permitted to finalize auth requests

    Raises ValueError if callbackUrl or code parameter is missing.
    """
    ZITADEL_API_BASE_URL = os.getenv('ZITADEL_API_BASE_URL',None)
    TOKEN=os.getenv('ZITADEL_TOKEN',None)
    url = f"{ZITADEL_API_BASE_URL}/v2beta/oidc/auth_requests/{request_id}"
    headers = {
        "Authorization": f"Bearer {TOKEN}",
        "Content-Type": "application/json"
    }
    payload = { "session": { "sessionId": session_id, "sessionToken": session_token } }

    resp = requests.post(url, json=payload, headers=headers)
    resp.raise_for_status()
    data = resp.json()

    callback = data.get("callbackUrl")
    if not callback:
        raise ValueError("callbackUrl not found in finalize-auth response")

    query = urlparse(callback).query
    code = parse_qs(query).get("code", [None])[0]
    if not code:
        raise ValueError("authorization code not found in callback URL")

    return code



def get_user_Access_token(
    authorization_code
):
    """
    Exchanges authorization code for access_token (and optionally refresh_token, id_token).
    Uses ZITADEL's /oauth/v2/token endpoint with client_secret_post auth.

    Returns the full token response dict.
    """
    ZITADEL_API_BASE_URL = os.getenv('ZITADEL_API_BASE_URL',None)
    CLIENT_ID=os.getenv('ZITADEL_CLIENTID',None)
    REDIRECT_URI=os.getenv('REDIRECT_URL',None)
    CLIENT_SECRET=os.getenv('ZITADEL_CLIENT_SECRET',None)
    token_url = f"{ZITADEL_API_BASE_URL}/oauth/v2/token"
    headers = {
        "Authorization": f"Bearer {CLIENT_ID}",
        "Content-Type": "application/x-www-form-urlencoded"
    }
    payload = {
        "grant_type": "authorization_code",
        "code": authorization_code,
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "redirect_uri": REDIRECT_URI
    }

    resp = requests.post(token_url, data=payload, headers=headers)
    token_data = resp.json()
    access_token = token_data.get("access_token")
    return access_token

def zitadel_check(data, user_name,db):
    """
    Description:
    Handles the process of checking and creating a user in Zitadel and retrieving an access token.

    Args:
        data (dict): Contains user credentials and other relevant information.
        user_name (str): The username of the user.
        auth_code (str, optional): The authorization code, if available. Defaults to None.

    Returns:
        str: The access token if the process is successful, or a dictionary with error details if an exception occurs.
    """
    logging.info(f"###Zitadel_check recieved data is {data}")
    request_received_at=data.get('request_received_at','')
    # Extract user credentials from the request data
    username = user_name
    password = data.get("password", "")
    try:
        request_id=fetch_request_id_from_authorize()
        logging.info(f"##zitadel_check request id is {request_id}")
        ##fetch the session id and session token
        session_id, session_token=retrieve_session_id_and_session(username, password)
        logging.info(f"##zitadel_check session_id and session_token is {session_id} and {session_token}")
        # Get the authorization code
        authorization_code=get_auth_code(request_id,session_id, session_token)
        logging.info(f"##zitadel_check authorization_code is {authorization_code}")
        #fetch the access token
        access_token=get_user_Access_token(
            authorization_code
        )  
        if access_token:      
        # Update the database with the access token
            db.update_dict(
                "users", {"access_token": access_token}, {"username": username}
            )
        else:
            message = "Invalid User Credentials"
            response={"flag":False,"message":message}
            try:
                # Log error to database
                error_data = {
                    "service_name": "login_using_database",
                    "error_message": f"Failed to retrived the access token for username : {username}",
                    "error_type": "Authenitacation Error",
                    "users": user_name,
                    "session_id": session_id,
                    "tenant_name": "",
                    "comments": message,
                    "module_name": "User_authentication",
                    "request_received_at": request_received_at,
                }
                db.log_error_to_db(error_data, "error_log_table")
            except Exception as e:
                logging.exception(f"### login_using_database error_log_table exception : {e}")
            return response
        return access_token
    except Exception as e:
        logging.exception(f"### zitadel_check Exception is {e}")
        message = "Authentication is not responding"
        response = {"flag": False, "message": message}
        error_type = type(e).__name__
        try:
            # Log error to database
            error_data = {
                "service_name": "login_using_database",
                "error_message": f"Failed to retrived the access token for username : {username}",
                "error_type": error_type,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": "",
                "comments": message,
                "module_name": "User_authentication",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### login_using_database error_log_table exception : {e}")

        return response


def generate_token(data):
    ##used to get the random authenticaton number
    random_number = random.randint(100000, 999999)
    logging.info(f"### zitadel_check Random Numbers: {random_number}")
    return random_number


def reset_password_email(data):
    """
    Sends a password reset email to a user and performs associated database updates and auditing.

    This function handles the generation of a temporary password, updates the user's record in the database,
    sends an email with the password reset information, and audits the entire process for success or failure.

    Parameters:
    ----------
    data : dict
        A dictionary containing the following keys:
        - 'username' (str): The username of the user requesting a password reset.
        - 'template_name' (str): The email template name to use (default: 'Forgot password').
        - 'session_id' (str): The session identifier for the current user session.
        - 'Partner' (str): The tenant or partner name associated with the user.
        - 'role' (str): The role of the user.
        - 'request_received_at' (str): Timestamp indicating when the request was received.

    Returns:
    -------
    dict
        A dictionary containing:
        - 'flag' (bool): Indicates if the operation was successful.
        - 'message' (str): A success or failure message.
    """
    # logging.info(f"Request Data: {data}")
    request_received_at = data.get("request_received_at", None)
    try:
        # Start time  and date calculation
        start_time = time()
        date_started = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        logging.info(f"### reset_password_email Start time: {date_started}")
    except Exception as e:
        logging.exception(f"### reset_password_email reset_password_email datetime exception : {e}")
        date_started = 0
        start_time = 0
        logging.warning("### reset_password_email Failed to start ram and time calc")
        pass
    ##the function endpoint is used to reset the password
    username = data.get("username", "")
    template_name = data.get("template_name", "Forgot password")
    session_id = data.get("session_id", "")
    Partner = data.get("Partner", "")
    role = data.get("role", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    # tenant_database = data.get('db_name', '')
    token = generate_token(data)
    update_data = {"temp_password":token}
    # logging.info(F"update_data is {update_data}")
    #common_utils_database.update_dict("users", update=update_data, where={'id': unique_id}, logic_operator='AND')
    common_utils_database.update_dict("users", update_data, {"username": username})
    to_email = common_utils_database.get_data(
        "users", {"username": username}, ["email"]
    )["email"].to_list()[0]
    # Call send_email and assign the result to 'result'
    result = send_email(template_name, username=username, user_mail=to_email, tenant_database='altaworx_central')
    logging.info(f"### reset_password_email result is {result}")
    # Check the result and handle accordingly
    if isinstance(result, dict) and result.get("flag") is False:
        logging.info(result)
        to_emails = result.get("to_emails")
        cc_emails = result.get("cc_emails")
        subject = result.get("subject")
        body = result.get("body")
        from_email = result.get("from_email")
        partner_name = result.get("partner_name")
        try:
            ##email audit
            email_audit_data = {
                "template_name": template_name,
                "email_type": "Application",
                "partner_name": "",
                "email_status": "failure",
                "from_email": from_email,
                "to_email": to_email,
                "cc_email": cc_emails,
                "subject": subject,
                "body": body,
                "role": role,
                "comments": "Forgot Password Auditing",
                "parents_module_name": "User authentication",
                "child_module_name": "",
                "sub_module_name": "",
                "template_type": "User Authentication",
            }
            common_utils_database.update_audit(email_audit_data, "email_audit")
        except Exception as e:
            logging.exception(f"### reset_password_email email_audit Exception is {e}")
    else:
        # Continue with other logic if needed
        to_emails, cc_emails, subject, body, from_email, partner_name = result
        # to_emails,cc_emails,subject,body,from_email,partner_name=send_email(template_name,username=username,user_mail=to_email)
        common_utils_database.update_dict(
            "email_templates",
            {"last_email_triggered_at": request_received_at},
            {"template_name": template_name},
        )
        query = """
                SELECT parents_module_name, sub_module_name, child_module_name, partner_name
                FROM email_templates
                WHERE template_name = 'Exception Mail'
            """

        # Execute the query and fetch the result
        email_template_data = common_utils_database.execute_query(query, True)
        if not email_template_data.empty:
            # Unpack the results
            parents_module_name, sub_module_name, child_module_name, partner_name = (
                email_template_data.iloc[0]
            )
        else:
            # If no data is found, assign default values or log an error
            parents_module_name = ""
            sub_module_name = ""
            child_module_name = ""
            partner_name = ""
        try:
            ##email audit
            email_audit_data = {
                "template_name": template_name,
                "email_type": "Application",
                "partner_name": partner_name,
                "email_status": "success",
                "from_email": from_email,
                "to_email": to_emails,
                "cc_email": cc_emails,
                "action": "Email triggered",
                "subject": subject,
                "body": body,
                "role": role,
                "comments": "Forgot Password Auditing",
                "parents_module_name": parents_module_name,
                "child_module_name": child_module_name,
                "sub_module_name": sub_module_name,
                "template_type": "User Authentication",
            }
            common_utils_database.update_audit(email_audit_data, "email_audit")
        except Exception as e:
            logging.exception(f"### reset_password_email email_audit Exception is {e}")
    message = "mail sent sucessfully"
    response = {"flag": True, "message": message}
    try:
        # End time calculation
        end_time = time()
        time_consumed = end_time - start_time
        ## Auditing
        audit_data = {
            "service_name": "reset_password_email",
            "created_date": date_started,
            "created_by": username,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": f"password reset email to a user - {username}",
            "module_name": "User_authentication",
            "request_received_at": request_received_at,
        }
        common_utils_database.update_audit(audit_data, "audit_user_actions")

        return response
    except Exception as e:
        logging.exception(f"### reset_password_email Error sending email: {e}")
        message = "mail not sent"
        error_data = {
            "service_name": "reset_password_email",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": message,
            "module_name": "User_authentication",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": message}


def add_username(username, password):
    """
    Updates a user's password in Zitadel by sending a POST request to the authentication endpoint.

    This function sends a POST request to the Zitadel authentication service to update the password
    for the specified username. It uses an API key for authentication and expects the Zitadel endpoint
    URL to be set in the "ZITADEL_USERNAME" environment variable.

    Args:
        username (str): The username whose password is to be updated.
        password (str): The new password to set for the user.

    Returns:
        dict: A dictionary indicating the result of the operation:
            - 'flag' (bool): True if the password was updated successfully, False otherwise.
            - 'message' (str): A message describing the result or error.
    """
    try:
        url = os.getenv("ZITADEL_USERNAME", "").strip()
        if not url:
            raise ValueError("ZITADEL_USERNAME environment variable is not set.")

        data = {"username": username, "password": password}
        headers = {
            "x-api-key": "IiI1IV82XAsdkfPFQpqWFLLvQAiWR0xB",
        }

        response = requests.post(url, json=data, headers=headers)
        logging.info(f"### add_username Zitadel password update response: {response.text} and {response.status_code}")

        if response.status_code != 200:
            return {"flag": False, "message": "Failed to update password in Zitadel"}

        return {"flag": True, "message": "Password updated successfully in Zitadel"}

    except Exception as e:
        logging.exception(f"### add_username Exception occurred: {e}")
        return {
            "flag": False,
            "message": f"Something went wrong updating password in Zitadel: {str(e)}",
        }

# def password_reset(data):
#     """
#     Resets a user's password in the database and in Zitadel.

#     Parameters:
#     ----------
#     data : dict
#         A dictionary containing:
#         - 'username' (str): The username of the user whose password is to be reset.
#         - 'New_password' (str): The new password to be set for the user.

#     Returns:
#     -------
#     dict
#         A dictionary indicating success or failure of the operation.
#     """
#     try:
#         # Extract parameters from input data
#         username = data.get("username")
#         new_password = data.get("New_password")

#         if not username or not new_password:
#             return {"flag": False, "message": "Username and new password must be provided."}

#         # Initialize the database connection
#         db = DB("common_utils", **db_config)

#         # Retrieve the user's current password and ID
#         user_info = db.get_data("users", {"username": username, "is_active": "true"})
#         if user_info.empty:
#             return {"flag": False, "message": "User not found or inactive."}

#         current_password = user_info["password"].to_list()[0]
#         user_id = user_info["user_id"].to_list()[0]

#         # Update password in Zitadel
#         zitadel_response = add_username(username, new_password)
#         if not zitadel_response.get("flag"):
#             return zitadel_response  # Return Zitadel error message

#         return {"flag": True, "message": "Password reset successfully in database and Zitadel"}

#     except Exception as e:
#         logging.exception(f"Password reset failed: {e}")
#         return {"flag": False, "message": f"An unexpected error occurred: {str(e)}"}

def reset_zitadel_user_password(username, new_password):
    """
    Retrieves userId by login name and updates the user's password using ZITADEL management API.
    Returns a dict: {"flag": True/False, "message": "..."}.
    """

    # Step 1: Get user by login name
    base_url = os.getenv("ZITADEL_API_BASE_URL")
    token = os.getenv("ZITADEL_TOKEN")
    lookup_url = f"{base_url.rstrip('/')}/management/v1/global/users/_by_login_name"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    try:
        logging.info(f"Fetching userId for username: {username} ")
        resp = requests.get(lookup_url, params={"loginName": username}, headers=headers)
        logging.info(f"GET user-by-login response ({resp.status_code}): {resp.text}")
        if resp.status_code != 200:
            return {"flag": False, "message": f"Failed to retrieve user: {resp.status_code} {resp.text}"}

        user_id = resp.json().get("user", {}).get("id")
        if not user_id:
            return {"flag": False, "message": "User lookup succeeded but no userId returned."}
    except Exception as e:
        logging.exception("Exception during user lookup")
        return {"flag": False, "message": f"Exception during user lookup: {str(e)}"}

    # Step 2: Update password
    password_url = f"{base_url.rstrip('/')}/management/v1/users/{user_id}/password"
    payload = {"password": new_password, "changeRequired": False}

    try:
        resp = requests.post(password_url, json=payload, headers=headers)
        logging.info(f"POST update-password response ({resp.status_code}): {resp.text}")
        if resp.status_code == 200:
            return {"flag": True, "message": f"Password updated successfully for userId {user_id}"}
        else:
            return {"flag": False, "message": f"Failed to update password: {resp.status_code} {resp.text}"}
    except Exception as e:
        logging.exception("Exception during password update")
        return {"flag": False, "message": f"Exception during password update: {str(e)}"}


def password_reset(data):
    """
    Resets a user's password in the database and in Zitadel.

    Parameters:
    ----------
    data : dict
        A dictionary containing:
        - 'username' (str): The username of the user whose password is to be reset.
        - 'New_password' (str): The new password to be set for the user.

    Returns:
    -------
    dict
        A dictionary indicating success or failure of the operation.
    """
    start_time = time()
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        # Extract parameters from input data
        username = data.get("username")
        new_password = data.get("New_password")
        login_username=data.get("login_username","")

        if not username or not new_password:
            return {"flag": False, "message": "Username and new password must be provided."}

        # Initialize the database connection

        # Retrieve the user's current password and ID
        user_info = db.get_data("users", {"username": username, "is_active": "true"})
        if user_info.empty:
            return {"flag": False, "message": "User not found or inactive."}

        # current_password = user_info["password"].to_list()[0]
        # salt = user_info["salt"].to_list()[0]
        user_id = user_info["user_id"].to_list()[0]

        # Update password in Zitadel
        zitadel_response=reset_zitadel_user_password(username, new_password)
        if not zitadel_response.get("flag"):
            # Get the original message string
            outer_message = zitadel_response.get("message", "An unknown error occurred")
            
            # Try to extract and parse the inner JSON
            start_index = outer_message.find('{')
            if start_index != -1:
                json_string = outer_message[start_index:]
                try:
                    inner_error = json.loads(json_string)
                    # Get the clean message from details if available, otherwise from message
                    clean_message = outer_message  # default to original
                    
                    if "details" in inner_error and len(inner_error["details"]) > 0:
                        clean_message = inner_error["details"][0].get("message", outer_message)
                    else:
                        clean_message = inner_error.get("message", outer_message)
                        
                    # Return with the same structure but cleaned message
                    return {
                        "flag": False,
                        "message": clean_message
                    }
                    
                except json.JSONDecodeError:
                    # If parsing fails, return original message structure
                    return {
                        "flag": False, 
                        "message": outer_message
                    }
            else:
                # If no JSON found, return original message structure
                return {
                    "flag": False,
                    "message": outer_message
                }

        # Prepare update data dictionary
        update_data = {}

        # Check if salt exists
        if not user_info["salt"].empty and user_info["salt"].to_list()[0]:
            # Use existing salt
            salt = user_info["salt"].to_list()[0]
            # Only update password in this case
            hashed_password = generate_hash(new_password, salt)
            if login_username:
                update_data = {"password": hashed_password,"modified_by":login_username}
            else:
                update_data = {"password": hashed_password,"modified_by":username}
        else:
            # Generate a new salt if none exists
            salt = os.urandom(16).hex()
            # Update both password and salt
            hashed_password = generate_hash(new_password, salt)
            if login_username:
                update_data = {"password": hashed_password, "salt": salt,"modified_by":login_username}
            else:
                update_data = {"password": hashed_password, "salt": salt}

        # Update the database with the appropriate fields
        update_result = db.update_dict(
            "users",
            update_data,
            {"user_id": user_id}
        )

        try:
        # End time calculation
            end_time = time()
            time_consumed = end_time - start_time
            ## Auditing
            audit_data = {
                "service_name": "password_reset",
                "created_date": datetime.now(),
                "created_by": username,
                "status": True,
                "time_consumed_secs": time_consumed,
                "session_id": None,
                "tenant_name": "",
                "comments": f"Password reset status {update_result} for user - {username}",
                "module_name": "User_authentication",
                "request_received_at": datetime.now(),
            }
            db.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### password_reset audit_user_actions exception : {e}")

        if not update_result:
            return {"flag": False, "message": "Failed to update password in database."}

        return {"flag": True, "message": "Password reset successfully in database and Authentication"}

    except Exception as e:
        logging.exception(f"### password_reset Password reset failed: {e}")
        error_data = {
            "service_name": "password_reset",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("client_id"),
            "session_id": None,
            "tenant_name": data.get("tenant"),
            "comments": "password reset failed",
            "module_name": "User_authentication",
            "request_received_at": datetime.now(),
        }
        db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": f"An unexpected error occurred: {str(e)}"}


def format_tenant_data(tenants, role_tenant_name, role=""):
    """
    Formats a list of tenants into a hierarchical structure of parent tenants and their sub-tenants.

    This function organizes tenants into a hierarchy based on their parent-child relationships.
    Only tenants whose names are in `role_tenant_name` or if the role is "Super Admin" are included.
    Parent tenants are listed with their details, and each parent contains a list of its sub-tenants.

    Args:
        tenants (list of dict): List of tenant dictionaries, each containing at least
            'id', 'tenant_name', and 'parent_tenant_id' keys.
        role_tenant_name (list): List of tenant names associated with the user's role.
        role (str, optional): The user's role. If "Super Admin", all tenants are included. Default is "".

    Returns:
        list: A list of dictionaries representing the tenant hierarchy, where each dictionary has:
            - 'id': The tenant's ID.
            - 'name': The tenant's name.
            - 'subPartners': A list of sub-tenant dictionaries (with 'id' and 'name').
    """
    # Create a dictionary to hold the hierarchy
    tenant_hierarchy = []

    # First, add all parent tenants with their details
    for tenant in tenants:
        if tenant["parent_tenant_id"] is None and (
            tenant["tenant_name"] in role_tenant_name or role == "Super Admin"
        ):
            tenant_hierarchy.append(
                {"id": tenant["id"], "name": tenant["tenant_name"], "subPartners": []}
            )

    # Then, add all sub-tenants to their respective parents
    for tenant in tenants:
        if tenant["parent_tenant_id"] is not None and (
            tenant["tenant_name"] in role_tenant_name or role == "Super Admin"
        ):
            parent_id = tenant["parent_tenant_id"]

            for parent in tenant_hierarchy:
                if parent["id"] == parent_id:
                    parent["subPartners"].append(
                        {"id": tenant["id"], "name": tenant["tenant_name"]}
                    )
    return tenant_hierarchy


def token_check(username, reset_token, db):
    """
    Verifies whether the provided reset token matches the one stored in the database for a given user.

    This function retrieves the temporary password (reset token) for the specified username from the database
    and compares it with the provided reset token. If they match, the function returns True, indicating the
    token is valid; otherwise, it returns False.

    Args:
        username (str): The username whose reset token is to be verified.
        reset_token (str): The reset token provided by the user.
        db (DB): The database connection object to use for fetching user data.

    Returns:
        bool: True if the reset token matches the one in the database, False otherwise.
    """
    start_time = time()
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        # Connect to the database
        # database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        if not username or not reset_token:
            raise ValueError("Username, and reset token must be provided.")

        # Fetch the reset token from the database
        db_reset_token = db.get_data(
            "users", {"username": username}, ["temp_password"]
        )["temp_password"].to_list()

        if not db_reset_token:
            raise ValueError("User not found or reset token is missing.")

        db_reset_token = db_reset_token[0]  # Assuming there's only one token per user

        try:
        # End time calculation
            end_time = time()
            time_consumed = end_time - start_time
            ## Auditing
            audit_data = {
                "service_name": "token_check",
                "created_date": datetime.now(),
                "created_by": username,
                "status": "True",
                "time_consumed_secs": time_consumed,
                "session_id": None,
                "tenant_name": "",
                "comments": "Verifies whether the provided reset token matches the one stored in the database for a given user",
                "module_name": "User_authentication",
                "request_received_at": datetime.now(),
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### token_check audit_user_actions exception : {e}")

        # Check if the provided reset token matches the one in the database
        if str(reset_token) == str(db_reset_token):
            # Return success message
            return True
        else:
            # Return invalid token message
            return False

    except Exception as e:
        logging.exception(f"### token_check Exception is {e}")
        error_data = {
            "service_name": "token_check",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "session_id": None,
            "tenant_name": "",
            "comments": f"token_check failed for user - {username}",
            "module_name": "User_authentication",
            "request_received_at": datetime.now(),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        # Handle any other exceptions
        return False

def authenticating_username(username, password):

    """
    Authenticates a user by sending a POST request to the authentication endpoint with the username and password.
    Args:
        username (str): The username of the user to authenticate.
        password (str): The password of the user to authenticate.
    Returns:
        tuple: A tuple containing the session ID and session token if successful, or a dictionary with an error message if an exception occurs.
    """
    try:
        # Retrieve the URL for the authentication endpoint from an environment variable
        #url ='https://sandbox-device-api.amop.services/api/auth/authenticate'
        url =os.getenv("ZITADEL_AUTHENTICATING", " ")
        # Retrieve the authorization token from an environment variable
        # Define the request body with the provided username and password
        data =  {
                    "username":username,
                    "password":password
                }
        # Define the headers with the provided authorization token
        # headers = {
        #     "Content-Type": "application/json",
        #     "Accept": "application/json",
        #     "Cache-Control": "no-cache",
        #     "User-Agent": "PostmanRuntime/7.41.0",
        #     "Connection": "keep-alive",
        # }
        # Send a POST request
        response = requests.post(url, json=data)
        logging.info(f"### authenticating_username response {response.text}")
        return response.status_code
    except Exception as e:
        logging.info(f"### authenticating_username Exception is {e}")
        message = (
            "Something went wrong fetching sessionid and sessiontoken using  Authentication"
        )
        response = {"flag": False, "message": message}
        return response

# Generate a random salt (16 bytes)
salt = os.urandom(16)

# def generate_hash(password, salt):
#     """
#     Generates a hash for the given password and salt using SHA1.
#     The encoding is designed to match C# Unicode encoding.
#     """
#     # Convert password to bytes (utf-16-le) and treat salt as bytes (no need to decode)
#     combined = password.encode('utf-16-le') + salt

#     # Use SHA1 to match C# SHA1Managed
#     hash_object = hashlib.sha1(combined)
#     return base64.b64encode(hash_object.digest()).decode('utf-8')

def generate_hash(password, salt):
    """
    Generates a hash for the given password and salt using SHA1.
    The encoding is designed to match C# Unicode encoding.
    """
    combined = (password + salt).encode("utf-16-le")
    hash_object = hashlib.sha1(combined)
    return base64.b64encode(hash_object.digest()).decode("utf-8")



def derive_key_and_iv(password, salt, key_length, iv_length):
    """
    Derives a cryptographic key and initialization vector (IV) from a password and salt.

    This function uses an OpenSSL-compatible key derivation method (MD5-based) to generate
    a key and IV of specified lengths from the given password and salt. It is typically used
    for AES encryption/decryption where a key and IV are required.

    Args:
        password (bytes): The password to use for key derivation (as bytes).
        salt (bytes): The salt to use for key derivation (as bytes).
        key_length (int): The desired length of the derived key in bytes.
        iv_length (int): The desired length of the derived IV in bytes.

    Returns:
        tuple: A tuple (key, iv) where:
            - key (bytes): The derived cryptographic key.
            - iv (bytes): The derived initialization vector.
    """

    d = d_i = b''
    while len(d) < key_length + iv_length:
        d_i = md5(d_i + password + salt).digest()
        d += d_i
    return d[:key_length], d[key_length:key_length+iv_length]

def decrypt_cryptojs_aes(encrypted_b64):
    """
    Decrypts a base64-encoded AES-encrypted string compatible with CryptoJS (OpenSSL format).

    This function expects the encrypted input to be in the OpenSSL-compatible format:
    - The first 8 bytes are the ASCII string "Salted__"
    - The next 8 bytes are the salt
    - The remainder is the ciphertext

    The function derives the AES key and IV using the provided passphrase and salt,
    then decrypts the ciphertext using AES CBC mode and removes PKCS7 padding.

    Args:
        encrypted_b64 (str): The base64-encoded encrypted string.

    Returns:
        str: The decrypted plaintext string if successful, otherwise returns the input string on error.
    """
    try:
        passphrase='7f3e9dff84c2b1a9e6d4c785aa109e3bf2dbe643190ab8de5cfa7340d6b2a817'
        encrypted = b64decode(encrypted_b64)
        assert encrypted[:8] == b"Salted__"
        salt = encrypted[8:16]
        key, iv = derive_key_and_iv(passphrase.encode(), salt, 32, 16)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        decrypted = cipher.decrypt(encrypted[16:])
        # remove PKCS7 padding
        padding_len = decrypted[-1]
        return decrypted[:-padding_len].decode('utf-8')
    except Exception as e:
        logging.exception(f"### decrypt_cryptojs_aes Exception : {e}")
        return encrypted_b64

def user_authentication(access_token):
    """
    Sends a GET request to ZITADEL’s userinfo endpoint using the provided access token.
    Returns True if status code is 200, otherwise False.
    """
    ZITADEL_API_BASE_URL = os.getenv('ZITADEL_API_BASE_URL',None)
    url = f"{ZITADEL_API_BASE_URL}/oidc/v1/userinfo"
    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    resp = requests.get(url, headers=headers)
    return resp


def login_using_database(data):
    """
    Authenticates a user by validating their credentials against a database,
    optionally migrating them to Zitadel if required, and managing their session.

    The function performs the following tasks:
    1. Validates the user's credentials by checking the database.
    2. Retrieves an access token from Zitadel for authenticated users.
    3. Manages user session by checking for active sessions, updating existing ones,
       or creating a new session.
    4. Retrieves tenant information based on user roles and permissions.
    5. Logs audit data and errors in the database for monitoring and debugging.

    Args:
        data (dict): Input data containing the following keys:
            - 'user_name' (str): Username of the user.
            - 'password' (str): Password of the user.
            - 'request_received_at' (str): Timestamp when the request was received.

    Returns:
        dict: A response dictionary with the following keys:
            - 'flag' (bool): True if authentication was successful, False otherwise.
            - 'message' (str): A message describing the result of the authentication.
            - 'tenant_names' (list): List of tenant names accessible to the user.
            - 'role' (str): The role of the authenticated user.
            - 'access_token' (str): Access token for the authenticated user.
            - 'email' (str): Email address of the authenticated user.
            - 'user_name' (str): Username of the authenticated user.
            - 'session_id' (str): The session ID for the user's active session.
    """
    request_received_at = data.get("request_received_at", None)
    logging.info(f"### login_using_database data : {data}" )
    # logging.info(f"Request Data: {data}")
    ##database connection
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    input_user_name = data.get("user_name", None)
    params = [input_user_name]
    is_last_login=None
    switch_user_20_modules_json=None
    try:
        username_query = "SELECT username FROM users WHERE LOWER(username) = LOWER(%s) AND is_active = TRUE;"
        user_name = db.execute_query(username_query, params=params)[
            "username"
        ].to_list()[0]
    except Exception as e:
        logging.exception(f"### login_using_database username exception : {e}")
        response = {"flag": False, "message": "User is Inactive or Invalid Username"}
        return response

    params=[input_user_name]
    try:
        # Query to select the first and last name of the user
        username_query = """
            SELECT first_name, last_name, dynamic_cols, last_login,switch_user_2_0,switch_user_20_modules_json
            FROM users
            WHERE LOWER(username) = LOWER(%s) AND is_active = TRUE
        """

        # Execute the query with the provided parameter
        result = db.execute_query(username_query, params=params)

        # Debugging: Print the raw query result
        logging.info(f"### login_using_database Query result: {result}")

        # Ensure the query result is not empty
        if not result.empty:
            first_name = result.iloc[0].get("first_name", None)
            last_name = result.iloc[0].get("last_name", None)
            first_last_name = " ".join(filter(None, [first_name, last_name])).strip()
            dynamic_cols = result.iloc[0].get("dynamic_cols", None)
            is_last_login = result.iloc[0].get("last_login", None)
            switch_user_2_0 = result.iloc[0].get("switch_user_2_0", False)
            switch_user_20_modules_json = result.iloc[0].get("switch_user_20_modules_json", None)
        else:
            logging.info("### login_using_database No active user found.")

    except Exception as e:
        # Log the exception and return an error response
        logging.info(f"### login_using_database Exception occurred: {e}")
        response = {"flag": False, "message": "User is Inactive or Invalid"}
    try:
        tenant_sub_dif_query = '''
        SELECT 
            tenant_name,
            CASE 
                WHEN parent_tenant_id IS NULL THEN FALSE 
                ELSE TRUE 
            END AS is_subtenant
        FROM 
            public.tenant 
        WHERE 
            is_active = TRUE
        '''

        # Fetch tenant data from DB
        tenant_sub_tenant_list = db.execute_query(tenant_sub_dif_query, True).to_dict(orient='records')

        # Convert to dictionary
        tenant_sub_tenant_dict = {item['tenant_name']: item['is_subtenant'] for item in tenant_sub_tenant_list}
    except Exception as e:
        logging.info(f"### login_using_database Exception occurred: {e}")
        tenant_sub_tenant_dict={}
    try:
        # Start time  and date calculation
        start_time = time()
        date_started = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        logging.info(f"### login_using_database Start time: {date_started}")
    except Exception as e:
        logging.exception(f"### login_using_database datetime exception : {e}")
        date_started = 0
        start_time = 0
        logging.warning("### login_using_database Failed to start ram and time calc")
        pass

    try:
        # session_id = data.get('session_id', None)
        encrypted_password = data.get("password", None)
        password = decrypt_cryptojs_aes(encrypted_password)
        data['password']=password
        try:
            reset_token = db.get_data(
            "users", {"username": user_name}, ["temp_password"]
            )["temp_password"].to_list()[0]
            if reset_token == str(password):
                response={"flag":True, "message":
                        "Successfully token is entered please move it to password reset page"}
                return response
            logging.info("### login_using_database Reset token mismatch, proceeding with other checks...")
        except Exception as e:
            logging.exception(f"### login_using_database password check exception : {e}")
        # access_token=''
        data["user_name"] = data["user_name"].lower()
        access_token = zitadel_check(data, user_name,db)
        #Check if access_token was successfully retrievedd
        response=user_authentication(access_token)
        logging.info(f"###login_using_database the response of zitadel is {response.json()} and status code is {response.status_code}")
        if response.status_code  in (200,201):
            logging.info("login successfully")
        else:
            message = "Invalid User Credentials"
            response={"flag":False,"message":message}
            try:
                # Log error to database
                error_data = {
                    "service_name": "login_using_database",
                    "created_date": date_started,
                    "error_message": f"Authentication failed status code is {response.status_code}",
                    "error_type": "Authenitacation Error",
                    "users": user_name,
                    "session_id": session_id,
                    "tenant_name": "",
                    "comments": message,
                    "module_name": "User_authentication",
                    "request_received_at": request_received_at,
                }
                db.log_error_to_db(error_data, "error_log_table")
            except Exception as e:
                logging.exception(f"### login_using_database error_log_table exception : {e}")
            return response


        login_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        # Generate a new session ID
        session_id = str(uuid.uuid4())

        # Check if the user already has an active session
        try:
            session_record = db.get_data(
                "live_sessions", {"username": user_name}, ["username", "session_id"]
            )["username"].to_list()[0]
        except Exception as e:
            logging.exception(f"### login_using_database session_record exception : {e}")
            session_record = None

        # Check if session_record is either a string or a DataFrame
        if isinstance(session_record, pd.DataFrame) and not session_record.empty:
            # If session is active, update the record with new details
            session_data = {
                "access_token": access_token,
                "login": login_time,
                "session_id": session_id,
                "last_request": login_time,
            }
            db.update_dict(
                "live_sessions",
                session_data,
                {"username": user_name, "status": "active"},
            )
            logging.info("### login_using_database Session updated.")
        elif isinstance(session_record, str) and session_record == user_name:
            # If session is found but returned as a string (i.e., user already exists)
            session_data = {
                "username": user_name,
                "access_token": access_token,
                "session_id": session_id,  # Insert session ID
                "status": "active",
                "login": login_time,
                "last_request": login_time,
            }
            db.update_dict("live_sessions", session_data)
            logging.info("### login_using_database Session updated for user found as string.")
        else:
            # If no active session, insert a new record
            logging.info(
                f"### login_using_database No active session found for {user_name}. Inserting new session record."
            )
            session_data = {
                "username": user_name,
                "access_token": access_token,
                "status": "active",
                "session_id": session_id,
                "login": login_time,
                "last_request": login_time,
            }
            db.insert_dict(session_data, "live_sessions")

        request_received_at_utc =  datetime.now(timezone.utc)
        formatted_time = request_received_at_utc.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

        db.update_dict(
            "users", {"last_login": formatted_time}, {"username": user_name}
        )

        tenant_names = common_utils_database.get_data(
            "tenant", {"is_active": "true"}, ["tenant_name", "db_name"]
        ).to_dict(orient="records")
        db_tenant_names = {
            tenant["tenant_name"]: tenant["db_name"] for tenant in tenant_names
        }
        if password:
            flag = token_check(user_name, password, db)
            if flag:
                return {"flag": True, "message": "Token is Valid."}

        if not user_name:
            message = "Username not present in request data."
            logging.info(f"### login_using_database message :{message}")
        else:
            # Fetch user information from the database
            user_info = db.get_data(
                "users", {"username": user_name, "is_active": True}
            )
            if not user_info.empty:
                role_name = user_info["role"].to_list()[0]
                role = user_info.iloc[0]["role"]
                email = user_info.iloc[0]["email"]
                # Check if user_info is empty (no user found)
                if user_info.empty:
                    message = "Invalid user credentials."
                    logging.info(f"### login_using_database message : {message}")
                    response = {
                        "flag": False,
                        "message": message,
                        "tenant_names": [],
                        "role": "",
                    }
                else:
                    # Check username and password validity
                    #if user_info.iloc[0]["username"] != user_name or authenticating_username(input_user_name, password) != 200:
                    if user_info.iloc[0]["username"] != user_name:

                        message = "Invalid user credentials."
                        logging.info(f"### login_using_database message : {message}")
                        response = {
                            "flag": False,
                            "message": message,
                            "tenant_names": [],
                            "role": "",
                        }
                    else:
                        if user_info.iloc[0]["salt"] is None:
                            salt = os.urandom(16)
                            #salt = salt
                            hash_password = generate_hash(str(user_info.iloc[0]["password"]), salt)
                            common_utils_database.update_dict(
                                    "users", {"password": hash_password, "salt": salt}, {"username": user_info.iloc[0]["username"]}
                                )
                        # getting tenant_ids for all the users
                        if role_name == "Super Admin":
                            tenant_names_all = common_utils_database.get_data(
                                "tenant", {"is_active": True}
                            ).to_dict(orient="records")
                            final_tenants = format_tenant_data(
                                tenant_names_all, [], role_name
                            )
                        else:
                            # Fetch user data
                            user_tenants_data = db.get_data(
                                "users", {"username": user_name, "is_active": True}
                            )

                            final_tenants = []

                            if not user_tenants_data.empty:
                                parent_tenant_name = user_tenants_data["tenant_name"].iloc[0]
                                sub_tenant_names = user_tenants_data["subtenant_name"].iloc[0]

                                # Normalize parent_tenant_name -> list
                                if isinstance(parent_tenant_name, str):
                                    try:
                                        parent_tenant_name = (
                                            json.loads(parent_tenant_name)
                                            if parent_tenant_name.strip().startswith("[")
                                            else [parent_tenant_name]
                                        )
                                    except Exception:
                                        parent_tenant_name = [parent_tenant_name]

                                # Normalize sub_tenant_names -> list
                                try:
                                    sub_tenant_names = eval(sub_tenant_names) if sub_tenant_names else []
                                except Exception:
                                    sub_tenant_names = []

                                # Fetch all tenant data
                                tenant_data = common_utils_database.get_data(
                                    "tenant", {"is_active": True}, ["id", "tenant_name", "parent_tenant_id"]
                                ).to_dict(orient="records")

                                # Build maps
                                tenant_id_map = {t["id"]: t for t in tenant_data}
                                tenant_name_to_ids = {}
                                for t in tenant_data:
                                    tenant_name_to_ids.setdefault(t["tenant_name"], []).append(t["id"])

                                final_tenants = []

                                # Prepare final structured data
                                for parent_name in parent_tenant_name:
                                    # Identify main tenant (parent_tenant_id=None)
                                    parent_candidates = tenant_name_to_ids.get(parent_name, [])
                                    parent_id = next(
                                        (tid for tid in parent_candidates if tenant_id_map[tid]["parent_tenant_id"] is None),
                                        None,
                                    )
                                    if not parent_id:
                                        continue  # skip if no valid parent

                                    # Collect sub-partners only if sub_tenant_names exist
                                    sub_partners = []
                                    if sub_tenant_names:
                                        for sub_name in sub_tenant_names:
                                            if sub_name in tenant_name_to_ids:
                                                for tid in tenant_name_to_ids[sub_name]:
                                                    if tenant_id_map[tid]["parent_tenant_id"] == parent_id:
                                                        sub_partners.append({"id": tid, "name": sub_name})

                                    tenant_entry = {
                                        "id": parent_id,
                                        "name": parent_name,
                                        "subPartners": sub_partners
                                    }
                                    final_tenants.append(tenant_entry)
                            else:
                                final_tenants = []
                                logging.info("### login_using_database No tenant data found for the user.")
                        if not is_last_login:
                            message = "Successfully token is entered please move it to password reset page"
                        else:
                            message = "User login is successful."
                        logging.info(f"### login_using_database message : {message}")
                        response = {
                            "flag": True,
                            "message": message,
                            "db_tenant_names": db_tenant_names,
                            "tenant_names": final_tenants,
                            "role": role,
                            "access_token": access_token,
                            "email": email,
                            "user_name": user_name,
                            "first_last_name": first_last_name,
                            "session_id": session_id,
                            "dynamic_cols":dynamic_cols,
                            "tenant_sub_tenant_dict":tenant_sub_tenant_dict,
                            "switch_user_2_0":switch_user_2_0,
                            "switch_user_20_modules_json":switch_user_20_modules_json,
                        }
            else:
                message = "Invalid user credentials."
                logging.info(f"### login_using_database message : {message}")
                response = {
                    "flag": False,
                    "message": message,
                    "tenant_names": [],
                    "role": "",
                }

        # End time calculation
        end_time = time()
        time_consumed = end_time - start_time
        try:
            # Example usage
            ## Auditing
            audit_data_user_actions = {
                "service_name": "login_using_database",
                "created_date": date_started,
                "created_by": user_name,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": "",
                "comments": f"{message} - {input_user_name}",
                "module_name": "User_authentication",
                "request_received_at": request_received_at,
            }
            db.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### login_using_database audit_user_actions exception : {e}")

        return response

    except Exception as e:
        error_type = type(e).__name__
        # Error handling and logging
        logging.exception(f"### login_using_database Something went wrong and error is {e}")
        message = "Invalid User Credentials"
        try:
            # Log error to database
            error_data = {
                "service_name": "login_using_database",
                "created_date": date_started,
                "error_message": str(e),
                "error_type": error_type,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": "",
                "comments": message,
                "module_name": "User_authentication",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### login_using_database error_log_table exception : {e}")

        return {"flag": False, "message": message}





def impersonate_login_using_database(data):
    """
    Handles impersonation login functionality, transitioning the session from
    the original user to the impersonated user while ensuring proper session
    management, logging, and validation.

    Parameters:
        data (dict): A dictionary containing the required input data:
            - request_received_at (str): The timestamp when the impersonation request was received.
            - tenant_name (str): The name of the tenant organization.
            - username (str): The username of the original user initiating the impersonation.
            - impersonate_data (dict): Information about the user to impersonate:
                - id (str): The ID of the impersonated user.
                - email (str): The email of the impersonated user.
            - role_name (str): The role name of the original user.
            - session_id (str): The current session ID of the original user.

    Returns:
        dict: A response indicating the status of the impersonation login:
            - flag (bool): Whether the impersonation was successful.
            - message (str): A message detailing the operation's outcome.
            - user_impersonate (bool): Indicates if the impersonated user belongs to a specific partner type.
            - db_tenant_names (dict): A mapping of tenant names to database names.
            - tenant_names (list): The list of tenant information available to the impersonated user.
            - role (str): The role name of the impersonated user.
            - session_id (str): The new session ID for the impersonated user.
            - email (str): The email of the impersonated user.
            - user_name (str): The username of the impersonated user.

    """
    request_received_at = data.get("request_received_at", None)
    tenant_name = data.get("tenant_name", "")
    original_user = data.get("username", "")
    impersonated_user_id = data.get("impersonate_data").get("id", "")
    impersonated_user_email = data.get("impersonate_data").get("email", "")
    role = data.get("impersonate_data").get("role", "")
    session_id = data.get("session_id", "")

    logging.info(f"### impersonate_login_using_database Request Data: {data}")
    ##database connection
    db = DB("common_utils", **db_config)

    # Start time and date calculation
    try:
        start_time = time()
        date_started = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    except Exception as e:
        logging.exception(f"### impersonate_login_using_database datetime exception : {e}")
        date_started = 0
        start_time = 0
        pass

    try:
        params= [impersonated_user_id]
        # Query to select the first and last name of the user
        username_query = """
            SELECT first_name, last_name,dynamic_cols,switch_user_2_0,switch_user_20_modules_json
            FROM users
            WHERE id = %s AND is_active = TRUE
        """

        # Execute the query with the provided parameter
        result = db.execute_query(username_query, params=params)

        # Debugging: Print the raw query result
        logging.info(f"### impersonate_login_using_database Query result: {result}")

        # Ensure the query result is not empty
        if not result.empty:
            first_name = result.iloc[0].get("first_name", None)
            last_name = result.iloc[0].get("last_name", None)
            dynamic_cols = result.iloc[0].get("dynamic_cols", None)
            switch_user_2_0 = result.iloc[0].get("switch_user_2_0", None)
            first_last_name = " ".join(filter(None, [first_name, last_name])).strip()
            switch_user_20_modules_json = result.iloc[0].get("switch_user_20_modules_json", None)
        else:
            logging.info("### impersonate_login_using_database No active user found.")

    except Exception as e:
        # Log the exception and return an error response
        logging.info(f"### impersonate_login_using_database Exception occurred: {e}")
        response = {"flag": True, "message": "User is Inactive"}


    try:
        # Step 1: Clear session ID for the original user (if any)
        logging.info(f"### impersonate_login_using_database Clearing session for original user: {original_user}")
        update_data = {"status": "inactive", "session_id": ""}
        db.update_dict("live_sessions", update_data, {"username": original_user})
        logging.info(f"### impersonate_login_using_database Session for {original_user} cleared.")
        # Audit logging for clearing session
        audit_data_clear_session = {
            "service_name": "impersonate_login_using_database",
            "created_date": date_started,
            "created_by": original_user,
            "status": "Cleared",
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": f"Session for {original_user} cleared",
            "module_name": "User_authentication",
            "request_received_at": request_received_at,
        }
        # Save audit data to database
        db.update_audit(audit_data_clear_session, "audit_user_actions")

        # Step 2: Check if impersonated user already has an active session
        impersonated_user_name = db.get_data("users", {"id": impersonated_user_id})[
            "username"
        ].to_list()[0]
        impersonated_tenant_name = db.get_data("users", {"id": impersonated_user_id})[
            "tenant_name"
        ].to_list()[0]
        # Normalize parent_tenant_name -> list
        if isinstance(impersonated_tenant_name, str):
            try:
                impersonated_tenant_name = json.loads(impersonated_tenant_name) if impersonated_tenant_name.strip().startswith("[") else [impersonated_tenant_name]
            except Exception:
                impersonated_tenant_name = [impersonated_tenant_name]

        user_data = db.get_data("tenant", {"tenant_name": impersonated_tenant_name})

        if isinstance(user_data, bool):
            is_10_partner = user_data
        else:
            is_10_partner = (
                user_data["is_10_partner"].to_list()[0]
                if "is_10_partner" in user_data.columns
                else False
            )

        new_session_id = str(uuid.uuid4())  # Generates a new UUID string

        try:
            session_record = db.get_data(
                "live_sessions",
                {"username": impersonated_user_name},
                ["username", "session_id"],
            )
        except Exception as e:
            logging.exception(f"### impersonate_login_using_database session_record exception : {e}")
            session_record = None

        # Check if session_record is either a string or a DataFrame
        if isinstance(session_record, pd.DataFrame) and not session_record.empty:
            # If session is active, update the record with new details
            logging.info(
                f"### impersonate_login_using_database Updating existing session for impersonated user: {impersonated_user_name}"
            )
            session_data = {
                "login": request_received_at,
                "session_id": new_session_id,
            }
            db.update_dict(
                "live_sessions",
                session_data,
                {"username": impersonated_user_name, "status": "active"},
            )
            # Audit logging for session update
            audit_data_update_session = {
                "service_name": "impersonate_login_using_database",
                "created_date": date_started,
                "created_by": impersonated_user_name,
                "status": "Updated",
                "session_id": new_session_id,
                "tenant_name": tenant_name,
                "comments": f"Session for impersonate {impersonated_user_name} updated and is_10_partner: {is_10_partner}",
                "module_name": "User_authentication",
                "request_received_at": request_received_at,
            }
            db.update_audit(audit_data_update_session, "audit_user_actions")
        else:
            # If no active session, insert a new session
            logging.info(
                f"### impersonate_login_using_database No active session found for {impersonated_user_name}. Creating new session."
            )
            session_data = {
                "username": impersonated_user_name,
                "session_id": new_session_id,
                "status": "active",
                "login": request_received_at,
            }
            db.update_dict(session_data, "live_sessions")
            # Audit logging for session insert
            audit_data_insert_session = {
                "service_name": "impersonate_login_using_database",
                "created_date": date_started,
                "created_by": impersonated_user_name,
                "status": "True",
                "session_id": new_session_id,
                "tenant_name": tenant_name,
                "comments": f"Session for impersonate {impersonated_user_name} updated and is_10_partner: {is_10_partner}",
                "module_name": "User_authentication",
                "request_received_at": request_received_at,
            }
            db.update_audit(audit_data_insert_session, "audit_user_actions")

        request_received_at_utc =  datetime.now(timezone.utc)
        formatted_time = request_received_at_utc.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

        # Update the last login for the impersonated user
        db.update_dict(
            "users",
            {"last_login": formatted_time},
            {"username": impersonated_user_name},
        )

        # Fetch tenant names
        tenant_names = db.get_data("tenant", {"is_active": "true","tenant_name":impersonated_tenant_name}).to_dict(
            orient="records"
        )
        db_tenant_names = {
            tenant["tenant_name"]: tenant["db_name"] for tenant in tenant_names
        }

        # Verify user information for the impersonated user
        user_info = db.get_data(
            "users", {"username": impersonated_user_name, "is_active": "true"}
        )
        if not user_info.empty:
            role_name = role
            email = impersonated_user_email

            if role_name == "Super Admin":
                tenant_names_all = db.get_data("tenant", {"is_active": "true"}).to_dict(
                    orient="records"
                )
                final_tenants = format_tenant_data(tenant_names_all, [], role_name)
            else:
                # Fetch user data
                user_tenants_data = db.get_data(
                    "users", {"username": impersonated_user_name, "is_active": True}
                )

                final_tenants = []

                if not user_tenants_data.empty:
                    parent_tenant_name = user_tenants_data["tenant_name"].iloc[0]
                    sub_tenant_names = user_tenants_data["subtenant_name"].iloc[0]

                    # Normalize parent_tenant_name -> list
                    if isinstance(parent_tenant_name, str):
                        try:
                            parent_tenant_name = (
                                json.loads(parent_tenant_name)
                                if parent_tenant_name.strip().startswith("[")
                                else [parent_tenant_name]
                            )
                        except Exception:
                            parent_tenant_name = [parent_tenant_name]

                    # Normalize sub_tenant_names -> list
                    try:
                        sub_tenant_names = eval(sub_tenant_names) if sub_tenant_names else []
                    except Exception:
                        sub_tenant_names = []

                    # Fetch all tenant data
                    tenant_data = db.get_data(
                        "tenant", {"is_active": True}, ["id", "tenant_name", "parent_tenant_id"]
                    ).to_dict(orient="records")

                    # Build maps
                    tenant_id_map = {t["id"]: t for t in tenant_data}
                    tenant_name_to_ids = {}
                    for t in tenant_data:
                        tenant_name_to_ids.setdefault(t["tenant_name"], []).append(t["id"])

                    final_tenants = []

                    # Prepare final structured data
                    for parent_name in parent_tenant_name:
                        # Identify main tenant (parent_tenant_id=None)
                        parent_candidates = tenant_name_to_ids.get(parent_name, [])
                        parent_id = next(
                            (tid for tid in parent_candidates if tenant_id_map[tid]["parent_tenant_id"] is None),
                            None,
                        )
                        if not parent_id:
                            continue  # skip if no valid parent

                        # Collect sub-partners only if sub_tenant_names exist
                        sub_partners = []
                        if sub_tenant_names:
                            for sub_name in sub_tenant_names:
                                if sub_name in tenant_name_to_ids:
                                    for tid in tenant_name_to_ids[sub_name]:
                                        if tenant_id_map[tid]["parent_tenant_id"] == parent_id:
                                            sub_partners.append({"id": tid, "name": sub_name})

                        tenant_entry = {
                            "id": parent_id,
                            "name": parent_name,
                            "subPartners": sub_partners
                        }
                        final_tenants.append(tenant_entry)
                else:
                    final_tenants = []
                    logging.info("### impersonate_login_using_database No tenant data found for the user.")

            message = "Impersonation login is successful."
            response = {
                "flag": True,
                "message": message,
                "user_impersonate": is_10_partner,
                "db_tenant_names": db_tenant_names,
                "tenant_names": final_tenants,
                "role": role,
                "session_id": new_session_id,
                "email": email,
                "user_name": impersonated_user_name,
                "first_last_name":first_last_name,
                "dynamic_cols":dynamic_cols,
                "switch_user_2_0":switch_user_2_0,
                "switch_user_20_modules_json":switch_user_20_modules_json,
            }
        else:
            message = "Invalid impersonation user credentials."
            response = {
                "flag": False,
                "message": message,
                "tenant_names": [],
                "role": "",
            }

        # End time calculation
        end_time = time()
        time_consumed = end_time - start_time
        # Example auditing
        audit_data_user_actions = {
            "service_name": "impersonate_login_using_database",
            "created_date": date_started,
            "created_by": impersonated_user_name,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": new_session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "User_authentication",
            "request_received_at": request_received_at,
        }
        db.update_audit(audit_data_user_actions, "audit_user_actions")

        return response

    except Exception as e:
        error_type = type(e).__name__
        # Error handling and logging
        logging.info(f"### impersonate_login_using_database Exception is: {e}")
        message = "Invalid  impersonate User Credentials"
        try:
            # Log error to database
            error_data = {
                "service_name": "impersonate_login_using_database",
                "created_date": date_started,
                "error_message": str(e),
                "error_type": error_type,
                "users": impersonated_user_name,
                "session_id": new_session_id,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "User_authentication",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### impersonate_login_using_database error_log_table exception : {e}")

        return {"flag": False, "message": message}


def logout(data):
    """
    Handles the logout process for a user, clearing their access token and updating session details.

    Parameters:
        data (dict): A dictionary containing the required input data:
            - username (str): The username of the user logging out.

    Returns:
        dict: A response indicating the status of the logout process:
            - flag (bool): Whether the logout was successful.
            - message (str): A message detailing the operation's outcome.
    """
    try:
        username = data.get("username", "")
        request_received_at     = data.get("request_received_at", None)
        tenant_name = data.get("tenant_name", "")
        ui_session_id = data.get("sessionID", "")
        dynamic_cols = data.get("dynamic_cols", "")
        dynamic_cols = json.dumps(dynamic_cols, indent=4)

        db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        update_data = {"access_token": " ", "dynamic_cols": dynamic_cols}
        db.update_dict("users", update_data, {"username": username})

        # Update live_sessions table on logout
        logout_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        session_data = {
            "status": "inactive",
            "logout": logout_time,
            "last_request": logout_time,
            "session_id": "",
            "access_token": " ",
        }
        db.update_dict("live_sessions", session_data, {"username": username})

        # Auditing the logout event
        audit_data_user_actions = {
            "service_name": "logout",
            "created_date": logout_time,
            "created_by": username,
            "status": "true",
            "session_id": ui_session_id,  # Include session ID
            "tenant_name": tenant_name,
            "comments": "User logged out successfully",
            "module_name": "User_authentication",
            "request_received_at": logout_time,
        }
        db.update_audit(audit_data_user_actions, "audit_user_actions")

        message = "The User has been successfully logged out"
        response = {"flag": True, "message": message}
        return response
    except Exception as e:
        message = "The User has been successfully logged out"
        error_type = error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "logout",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "User_authentication",
            "request_received_at": request_received_at,
        }
        db.log_error_to_db(error_data, "error_log_table")
        response = {"flag": True, "message": message}
        return response


def form_modules_dict(data, sub_modules, tenant_modules, role_name):
    """
    Description:The form_modules_dict function constructs a nested dictionary that maps parent modules
    to their respective submodules and child modules. It filters and organizes modules based on the
    user's role, tenant permissions, and specified submodules.
    """
    # Initialize an empty dictionary to store the output
    out = {}
    # Iterate through the list of modules in the data
    for item in data:
        parent_module = item["parent_module_name"]
        # Skip modules not assigned to the tenant unless the role is 'super admin'
        if (
            parent_module not in tenant_modules and parent_module
        ) and role_name.lower() != "super admin":
            continue
        # If there's no parent module, initialize an empty dictionary for the module
        if not parent_module:
            out[item["module_name"]] = {}
            continue
        else:
            out[item["parent_module_name"]] = {}
        # Iterate through the data again to find related modules and submodules
        for module in data:
            temp = {}
            # Skip modules not in the specified submodules unless the role is 'super admin'
            if (
                module["module_name"] not in sub_modules
                and module["submodule_name"] not in sub_modules
            ) and role_name.lower() != "super admin":
                logging.info(f"### form_modules_dict Skipping parent module: {parent_module} (not in tenant modules)")
                continue
            # Handle modules without submodules and create a list for them
            if (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and not module["submodule_name"]
            ):
                temp = {module["module_name"]: []}
            # Handle modules with submodules and map them accordingly
            elif (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and module["submodule_name"]
            ):
                temp = {module["submodule_name"]: [module["module_name"]]}
            # Update the output dictionary with the constructed module mapping
            if temp:
                for key, value in temp.items():
                    if key in out[item["parent_module_name"]]:
                        out[item["parent_module_name"]][key].append(value[0])
                    elif temp:
                        out[item["parent_module_name"]].update(temp)

    # Return the final dictionary containing the module mappings
    return out

def login_to_cyberreef(data):
    """
    Authenticates a user with the CyberReef integration using Digest Authentication and returns a redirect URL.

    This function performs the following steps:
        1. Retrieves integration configuration and authentication details from the database.
        2. Initiates a POST request to the CyberReef authentication endpoint to obtain a nonce.
        3. Computes the Digest Authentication header using the nonce, username, password, and realm.
        4. Sends a second POST request with the Digest Authentication header to authenticate the user.
        5. If authentication is successful, extracts the redirect URL from the response.
        6. Logs audit information and errors to the database.

    Args:
        data (dict): A dictionary containing the following keys:
            - Partner (str): The partner or tenant name.
            - request_received_at (str): Timestamp of when the request was received.
            - module_name (str): The name of the module making the request.
            - user_name (str): The username of the user.
            - session_id (str): The session ID for the request.
            - db_name (str): The tenant database name.
            - username (str): The username to authenticate with CyberReef.

    Returns:
        dict: A dictionary with the authentication result:
            - 'flag' (bool): True if authentication was successful, False otherwise.
            - 'data' (dict): Contains 'redirect_url' if authentication is successful.
            - 'message' (str): Error message if authentication fails.
    """
    logging.info("Starting login_to_cyberreef process")
    try:
        db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        Partner = data.get("Partner", "")
        request_received_at = data.get("request_received_at", None)
        module_name = data.get("module_name", "")
        user_name = data.get("user_name", "")
        session_id = data.get("session_id", "")
        tenant_database = data.get('db_name', '')
        # Database Connection
        database = DB(tenant_database, **db_config)
        username = data.get("username")

        if not username:
            logging.info("### login_to_cyberreef Missing username or email in payload.")
            return {"error": "Invalid payload"}

        # Fetch integration data
        integration = database.execute_query("SELECT * FROM integration WHERE id = '16'", True)
        if integration.empty:
            logging.info("### login_to_cyberreef Integration record not found.")
            return {"error": "Integration not configured"}

        integration_id = integration.iloc[0]["id"]

        # Fetch integration_authentication and connection data
        integration_auth = database.execute_query("SELECT * FROM integration_authentication WHERE integration_id = %s", params=[integration_id])
        integration_conn = database.execute_query("SELECT * FROM integration_connection WHERE integration_id = %s", params=[integration_id])

        if integration_auth.empty:
            logging.info("### login_to_cyberreef Integration data not found.")
            return {"error": "Integration configuration error"}

        if integration_conn.empty:
            logging.info("### login_to_cyberreef configuration data not found.")
            return {"error": "Integration configuration error"}


        if not integration.iloc[0]["is_active"]:
            logging.warning("### login_to_cyberreef Integration is inactive.")
            return {"error": "Integration is inactive"}

        # Extract necessary credentials and URLs
        partner_token = integration_auth.iloc[0]["password"]
        realm = integration_auth.iloc[0]["realm_id"]
        auth_test_url = integration_conn.iloc[0]["auth_test_url"]
        api_url = integration_conn.iloc[0]["sandbox_url"]
        uri = urljoin(api_url, auth_test_url)
        logging.info(f"### login_to_cyberreef Request URL prepared: {uri}")

        # Step 1: Initial POST Request to get nonce
        response = requests.post(uri, allow_redirects=False)
        logging.debug(f"### login_to_cyberreef Initial POST Response: Status {response.status_code}, Headers {response.headers}")

        if response.status_code != 302:
            logging.info(f"### login_to_cyberreef Failed to retrieve nonce. Response: {response.text}")
            return {"error": "Failed to retrieve nonce"}

        # Extract nonce from WWW-Authenticate header
        nonce = None
        if "WWW-Authenticate" in response.headers:
            try:
                nonce = response.headers.get("WWW-Authenticate").split('nonce="')[1].split('"')[0]
            except IndexError:
                logging.info("### login_to_cyberreef Failed to parse nonce from WWW-Authenticate header.")

        if not nonce:
            logging.info("### login_to_cyberreef Nonce not found in response.")
            return {"error": "Nonce missing from response"}

        # Step 2: Compute Digest Authentication header
        digest_auth = compute_digest_auth(uri, username, partner_token, realm, nonce)
        logging.info(f"### login_to_cyberreef Computed Digest Auth Header: {digest_auth}")

        headers = {"Authorization": f"Digest {digest_auth}"}

        # Step 3: Second POST Request with Digest Authentication
        response = requests.post(uri, headers=headers, allow_redirects=False)
        logging.debug(f"### login_to_cyberreef Second POST Response: Status {response.status_code}, Headers {response.headers}")

        # Initialize response_data to ensure it is always defined
        response_data = {"flag": False, "message": "Authentication failed"}

        if response.status_code == 303:
            location = response.headers.get("Location")
            full_redirect_url = urljoin(api_url, location)
            logging.info(f"### login_to_cyberreef Authentication successful. Redirect URL: {full_redirect_url}")

            response_data = {"flag": True, "data": {"redirect_url": full_redirect_url}}

        # Log success
        try:
            audit_data_user_actions = {
                "service_name": "login_to_cyberreef",
                "created_date": request_received_at,
                "created_by": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": json.dumps(response_data),
                "module_name": "User_authentication",
                "request_received_at": request_received_at,
            }
            db.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.info(f"### login_to_cyberreef Exception during audit log: {e}")

        # Return the response_data
        return response_data

    except Exception as e:
        logging.info(f"### login_to_cyberreef exception is: {e}")
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name}
        )
        db.log_error_to_db(
            {
                "service_name": "login_to_cyberreef",
                "created_date": request_received_at,
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": str(e),
                "module_name": "User_authentication",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Session ID: {session_id} - The export {module_name} process encountered an error. Contact support if the issue persists."}


def compute_digest_auth(uri, username, password, realm, nonce, method="POST"):
    # Create the digest auth string based on the given username, password, and realm
    ha1 = hashlib.sha256(f"{username}:{realm}:{password}".encode()).hexdigest()
    ha2 = hashlib.sha256(f"{method}:{uri}".encode()).hexdigest()
    response = hashlib.sha256(f"{ha1}:{nonce}:{ha2}".encode()).hexdigest()

    # Return the Digest Authentication header format
    return f'username="{username}", realm="{realm}", nonce="{nonce}", uri="{uri}", response="{response}"'


def testing(data):
    send_email('Partner creation',id=1)
    return {"flag":True}


def get_modules(data):
    """
    Retrieves and formats modules and sub-modules for a tenant and user based on roles, permissions,
    and configurations in the database.

    Args:
        data (dict): Input data containing the following keys:
            - username (str): Username of the user.
            - tenant_name (str): Name of the tenant.
            - session_id (str, optional): Session ID of the user (not used in processing).
            - role_name (str): Role of the user (e.g., "Super Admin").
            - db_name (str, optional): Name of the database (default is empty string).

    Returns:
        dict: A response dictionary containing the following keys:
            - flag (bool): Indicates success of the operation.
            - message (str): Success message.
            - Modules (list): List of formatted module data with parent modules, child modules,
              and sub-children.
            - logo (str): Logo of the tenant.
    """
    # start_time = time.time()
    try:
        keys_to_remove = [
            'customers',
            'service_providers',
            'billing_account_number',
            'feature_codes',
            'tenant_ids'
        ]

        for key in keys_to_remove:
            db_config.pop(key, None)
    except Exception as e:
        logging.info(f'### Exception is : {e}')
    ### try block added here 
    try :     
        username = data.get("username", None)
        tenant_name = data.get("tenant_name", None)
        data.get("session_id", None)
        ui_timeout=None
        role_name = data.get("role_name", None)
        data.get("db_name", "")
        db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        tenant_id = db.get_data("tenant", {"tenant_name": tenant_name}, ["id"])[
            "id"
        ].to_list()[0]
        # Step 1: Fetch tenant modules
        tenant_module_query_params = [tenant_name]
        tenant_module_query = """SELECT module_name
                                FROM tenant_module
                                WHERE tenant_name = %s AND is_active = TRUE order by id asc;"""
        tenant_module_dataframe = db.execute_query(
            tenant_module_query, params=tenant_module_query_params
        )

        main_tenant_modules = tenant_module_dataframe["module_name"].to_list()
        logging.info(f"### Tenant modules fetched: {main_tenant_modules}")
        user_module_df = db.get_data(
            "user_module_tenant_mapping",
            {"user_name": username, "tenant_id": tenant_id},
            ["module_names", "sub_module"],
        ).to_dict(orient="records")
        logging.info(f'### user_module_df is : {user_module_df}')
        # Step 2: Handle modules based on role
        if (role_name.lower() == "super admin") and (
            not user_module_df or not user_module_df[0].get("module_names")
        ):
            # For Super Admin, get all tenant modules
            final_modules = [
                {"module": mod, "sub_module": []} for mod in main_tenant_modules
            ]  # Ensure final_modules is a list of dicts
            logging.info(f'### final_modules----{final_modules}')
        else:
            # Fetch role modules for non-super admin
            role_module_data = db.get_data(
                "role_module", {"role": role_name}, ["module", "sub_module"]
            ).to_dict(orient="records")
            # role_module_query=f"select module,sub_module from role_module"
            # role_module_data=db.execute_query(role_module_query,True).to_dict(
            #         orient="records"
            #             )
            # Step 2.1: Deserialize the JSON-like strings if needed
            if role_module_data:
                for item in role_module_data:
                    item["module"] = json.loads(
                        item["module"]
                    )  # Convert module string to list
                    item["sub_module"] = json.loads(
                        item["sub_module"]
                    )  # Convert sub_module string to dict

            # Step 3: Filter role modules by tenant modules
            filtered_modules = []
            for module in role_module_data:
                # Iterate over the list of modules
                for mod in module["module"]:
                    if mod in main_tenant_modules:
                        filtered_modules.append(
                            {
                                "module": mod,
                                "sub_module": module["sub_module"].get(
                                    mod, []
                                ),  # Get sub_modules or empty list if not found
                            }
                        )

            # Step 4: Add filtered modules to final_modules
            final_modules = filtered_modules
            logging.info(f"### Final modules after filtering: {final_modules}")
        # Fetch the data from the database
        result = db.get_data(
            "tenant", {"tenant_name": tenant_name}, ["logo", "id", "db_name","collapsed_logo","billing_platform_flag","dark_mode_logo","dark_mode_collapsed_logo"]
        )
        billing_platform_flag = result["billing_platform_flag"].to_list()[0]
        if not user_module_df or not user_module_df[0].get("module_names"):
            # If no user-specific modules are found, use final_modules as is
            logging.info("### No user-specific modules found, using final modules.")
            # Now `final_modules` contains either the filtered data or the entire modules
            # if no filtering was applied.
            logging.info(f"### final_modules : {final_modules}")
            # Transforming the keys
            transformed_data = [
                {"parent_module_name": item["module"], "module_name": item["sub_module"]}
                for item in final_modules  # Use final_modules instead of data
            ]

            logging.info(f"### transformed_data : {transformed_data}")
            module_table_df = db.get_data(
                "module",
                {"is_active": True},
                ["module_name", "parent_module_name", "submodule_name"],
                {"id": "asc"},
            ).to_dict(orient="records")

            # Process the data
            formatted_data = format_module_data(
                transformed_data, main_tenant_modules, module_table_df, role_name
            )

            # Output the formatted data
            logging.info(f"### formatted_data : {formatted_data}")
        else:
            # Convert module_names to a list
            module_names_list = json.loads(user_module_df[0]["module_names"])

            # Convert sub_module JSON string to a dictionary
            sub_module_dict = json.loads(user_module_df[0]["sub_module"])

            # Prepare the output data
            filtered_output = []

            # Iterate through the module names to filter based on the user data
            for module_name in module_names_list:
                # Get the corresponding sub_modules
                valid_sub_modules = []
                for sub_module in sub_module_dict.get(module_name, []):
                    # You can apply any further logic if needed for filtering sub_modules
                    valid_sub_modules.append(sub_module)

                # Append valid module and sub_modules to the output
                if valid_sub_modules:
                    filtered_output.append(
                        {
                            "parent_module_name": module_name,
                            "module_name": valid_sub_modules,
                        }
                    )

            # Final output
            filter_data = filtered_output
            modules = []
            module_data = db.get_data(
                "module", {}, ["id", "parent_module_name", "module_name", "submodule_name"],order={"order_by": "asc"}
            ).to_dict(orient="records")

            # Initialize lists to store filtered results
            filtered_results = []

            # Loop through the filter data
            for filter_item in filter_data:
                parent_name = filter_item["parent_module_name"]
                module_names = filter_item["module_name"]

                # Check the module_data for matching parent and module names
                for module_item in module_data:
                    # Check if the parent_module_name matches
                    if module_item["parent_module_name"] == parent_name:
                        # Now, only add if the module_name or submodule_name exists in filter data
                        if (
                            module_item["module_name"] in module_names
                            or module_item["submodule_name"] in module_names
                        ):
                            filtered_results.append(module_item)
                        elif (
                            not module_item["module_name"]
                            and not module_item["submodule_name"]
                        ):
                            filtered_results.append(module_item)

            # Create structured output for modules with IDs
            modules = []  # Resetting modules to gather results
            logging.info(f"### filtered_results is : {filtered_results}")
            for item in filtered_results:
                module_entry = {
                    "id": item["id"],  # Use the existing ID from module_data
                    "parent_module_name": item["parent_module_name"],
                    "module_name": item["module_name"],
                    "submodule_name": item["submodule_name"],
                }
                modules.append(module_entry)

            my_dict = modules
            # Initialize the output structure
            output_structure = []

            # Group by parent_module_name
            logging.info(f'### my_dict is : {my_dict}')
            for item in my_dict:
                parent_name = item["parent_module_name"]
                # Check if the parent entry already exists
                parent_entry = next(
                    (
                        entry
                        for entry in output_structure
                        if entry["parent_module_name"] == parent_name
                    ),
                    None,
                )
                if not parent_entry:
                    parent_entry = {
                        "parent_module_name": parent_name,
                        "queue_order": item["id"],  # Use id as queue_order for parent
                        "children": [],
                    }
                    output_structure.append(parent_entry)

                # Only add a child if module_name is not None
                if item["module_name"] is not None:
                    # Check if the child module already exists
                    child_entry = next(
                        (
                            child
                            for child in parent_entry["children"]
                            if child["child_module_name"] == item["module_name"]
                        ),
                        None,
                    )

                    if not child_entry:
                        child_entry = {
                            "child_module_name": item["module_name"],
                            "queue_order": len(parent_entry["children"])
                            + 1,  # Position-based queue_order for children
                            "sub_children": [],  # Always include sub_children key
                        }
                        parent_entry["children"].append(child_entry)

                    # If there is a submodule, add it to sub_children
                    if item["submodule_name"]:
                        sub_child_entry = {
                            "sub_child_module_name": item["submodule_name"],
                            "queue_order": len(child_entry["sub_children"])
                            + 1,  # Position-based queue_order for sub-children
                            "sub_children": [],  # Always include sub_children key for sub-modules
                        }
                        child_entry["sub_children"].append(sub_child_entry)
            try:
                output_structure = filter_modules_by_flag(output_structure, billing_platform_flag)
            except Exception as e:
                logging.info(f'### Exception while removing billing platform modules :{e}')
            logging.info(f'### output_structure---------{output_structure}')
            formatted_data = output_structure
        

        # ordring modules
        parent_module_order_query = (
            "select parent_module_name,parent_module_order from module"
        )
        parent_module_order = db.execute_query(parent_module_order_query, True).to_dict(
            orient="records"
        )

        module_order = {}
        for mod in parent_module_order:
            module_order[mod["parent_module_name"]] = mod["parent_module_order"]

        new_formated_data = []
        logging.info(f"### formatted_data is : {formatted_data}")
        for modules in formatted_data:
            temp = modules
            if modules["parent_module_name"] in module_order:
                temp["queue_order"] = int(module_order[modules["parent_module_name"]])
            new_formated_data.append(temp)

        logging.info(f"### new_formated_data is : {new_formated_data}")
        new_formated_data = sorted(new_formated_data, key=lambda x: x["queue_order"])

        # Extract 'logo' and 'id' separately
        logo = result["logo"].to_list()[0]  # Assuming the result contains a column 'logo'
        dark_mode_logo = result["dark_mode_logo"].to_list()[0]  # Assuming the result contains a column 'logo'
        collapsed_logo = result["collapsed_logo"].to_list()[0]
        dark_mode_collapsed_logo = result["dark_mode_collapsed_logo"].to_list()[0]
        tenant_id = result["id"].to_list()[0]  # Assuming the result contains a column 'id'
        db_name = result["db_name"].to_list()[
            0
        ]  # Assuming the result contains a column 'id'
        
        # Retrieve user-specific timeout
        user_timeout = db.get_data('users', {
            "username": username,
            "is_active": True
        }, ['ui_timeout'])

        if not user_timeout.empty:
            # User found — use their UI timeout
            ui_timeout = user_timeout['ui_timeout'].iloc[0]
        else:
            # No user setting found — check role defaults
            role_timeout = db.get_data('role', {
                "role_name": role_name,
                "tenant_id": tenant_id,
                "is_active": True
            }, ['ui_timeout'])

            if not role_timeout.empty:
                ui_timeout = role_timeout['ui_timeout'].iloc[0]
            else:
                # Neither user nor role has a setting — fallback to default
                ui_timeout = 15
        
        message = "Module data sent sucessfully"
        response = {
            "flag": True,
            "message": message,
            "Modules": new_formated_data,
            "logo": logo,
            "dark_mode_logo":dark_mode_logo,
            "billing_platform_flag":billing_platform_flag,
            "collapsed_logo":collapsed_logo,
            "dark_mode_collapsed_logo":dark_mode_collapsed_logo,
            "tenant_id": tenant_id,
            "db_name": db_name,
            "ui_timeout":ui_timeout
        }
        logging.info("### get_modules function executed successfully")
        try:
            audit_data_user_actions = {
                "service_name":"get_modules",
                "created_by": username,
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "module_name": "Module management",
                "comments": "fetched modules data",
                "request_received_at": data.get("request_received_at", ""),
            }

            db.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
        return response

    except Exception as e:
        logging.warning(f"### Something went wrong while fetching modules data and error is : {e}")
        message = "Something went wrong while fetching modules data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_modules",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "comments": message ,
                "module_name": "Module Managament",
                "request_received_at": data.get("request_received_at", ""),
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.warning(f"### Audit logging exception in error case : {e}")
        response = {
                "flag": False,
                "message": "Something went wrong while fetching modules data",
                "Modules": [],
                "logo": "",
                "dark_mode_logo": "",
                "billing_platform_flag": False,
                "collapsed_logo": "",
                "dark_mode_collapsed_logo": "",
                "tenant_id": "",
                "db_name": data.get("db_name", "") ,
            }


        return response 


def filter_modules_by_flag(modules, billing_platform_flag):
    """
    Filters out modules related to the 'Billing Platform' based on a boolean flag.

    This function:
    - Removes modules whose 'parent_module_name' is "Billing Platform" if the flag is False.
    - Returns the original module list if the flag is True.

    Args:
        modules (list): A list of dictionaries representing module metadata.
        billing_platform_flag (bool): Flag to include or exclude Billing Platform modules.

    Returns:
        list: A filtered list of modules based on the billing_platform_flag.
    """
    if not billing_platform_flag:
        modules = [m for m in modules if m.get("parent_module_name") != "Billing Platform"]
    return modules


def format_module_data(transformed_data, tenant_modules, module_table_df, role_name):
    """
    Formats module data into a structured hierarchy with parent modules, child modules, and sub-children, including queue order.

    This function organizes module information into a nested structure based on parent-child relationships.
    It filters modules according to tenant permissions and user role, and assigns a queue order to each module level.

    Args:
        transformed_data (list): List of dictionaries containing parent module and module names.
        tenant_modules (list): List of module names assigned to the tenant.
        module_table_df (list): List of dictionaries representing all modules with keys such as
            'parent_module_name', 'module_name', and 'submodule_name'.
        role_name (str): The role of the user (e.g., "Super Admin").

    Returns:
        list: A list of dictionaries representing the formatted module hierarchy, where each parent module
              contains its children and sub-children, each with a queue order.
    """
    logging.info("Starting format_module_data function")
    # Step 1: Create a mapping for transformed_data to find parent modules easily
    parent_module_map = {
        item["parent_module_name"]: {
            "parent_module_name": item["parent_module_name"],
            "queue_order": 0,  # Placeholder for queue order
            "children": [],
        }
        for item in transformed_data
    }
    logging.debug(
        f"### format_module_data Parent module map initialized with {len(parent_module_map)} entries"
    )

    # Step 2: Populate the parent_module_map with child and sub-child modules
    for module in module_table_df:
        parent_name = module["parent_module_name"]
        module_name = module["module_name"]
        submodule_name = module.get("submodule_name")
        module_access = True
        logging.debug(f"### format_module_data Processing module: {module_name} under parent: {parent_name}")
        if not module_name:
            continue
        # Check if the parent module name exists in the transformed_data
        if (
            parent_name in parent_module_map and parent_name in tenant_modules
        ):  # Ensure module_name is not None or empty
            # Check if the child already exists in the parent's children list
            for item in transformed_data:
                if item["parent_module_name"] == parent_name:
                    if submodule_name:
                        if submodule_name not in item["module_name"]:
                            module_access = False
                            break
                    else:
                        if module_name not in item["module_name"]:
                            module_access = False
                            break

            if not module_access and (role_name.lower() != "super admin"):
                continue

            child_module = next(
                (
                    child
                    for child in parent_module_map[parent_name]["children"]
                    if child["child_module_name"] == module_name
                ),
                None,
            )

            if not child_module:
                # If the child module doesn't exist, create a new one
                child_module = {
                    "child_module_name": module_name,
                    "queue_order": len(parent_module_map[parent_name]["children"]) + 1,
                    "sub_children": [],
                }
                # Append the child module to the parent's children
                parent_module_map[parent_name]["children"].append(child_module)
                logging.debug(
                    f"""### format_module_data Added child module: {module_name} with
                    queue order {child_module['queue_order']}
                    """
                )

            # If submodule_name exists, add it to sub_children
            if submodule_name:
                sub_child_module = {
                    "sub_child_module_name": submodule_name,
                    "queue_order": len(child_module["sub_children"]) + 1,
                    "sub_children": [],
                }
                child_module["sub_children"].append(sub_child_module)
                logging.debug(
                    f"""### format_module_data Added sub-child module: {submodule_name} with
                      queue order {sub_child_module['queue_order']}
                      """
                )
        else:
            if parent_name in parent_module_map:
                parent_module_map.pop(parent_name)
    # Step 3: Convert parent_module_map to a list
    structured_data = []

    for index, (parent_name, parent_data) in enumerate(parent_module_map.items()):
        parent_data["queue_order"] = index + 1  # Set queue_order based on the index
        structured_data.append(parent_data)  # Include even if no children
        logging.debug(
            f"### format_module_data Set queue order {parent_data['queue_order']} for parent module: {parent_name}"
        )

    logging.info("### format_module_data Successfully formatted module data")
    return structured_data



def get_redirection_modules(data):
    """
    Retrieves and combines module data for a specified user and tenant from the database.

    This function performs the following:
    1. Extracts relevant data from the input `data` dictionary, including user details, tenant information,
       session details, and database names.
    2. Handles special cases for requests originating from version "1.0" of the system by:
        - Updating user and session data in the database.
        - Logging user authentication events in the audit table.
        - Ensuring active session details are properly updated or inserted.
    3. Fetches module data based on the user's roles, tenant associations, and user-specific configurations.
    4. Combines module data from various sources, removes duplicates, and sorts the results.
    5. Formats the retrieved module data into a structured JSON format and includes tenant logo information.
    6. Logs audit information for the module retrieval process.
    7. Handles and logs any errors encountered during execution.

    Parameters:
    ----------
    data : dict
        Input data containing details such as:
        - "username": str, Username of the requesting user.
        - "tenant_id": str, Tenant ID associated with the user.
        - "session_id": str, Active session ID.
        - "db_name": str, Name of the tenant's database.
        - "auth_code": str, Authorization code for access token generation.
        - "request_received_at": str, Timestamp of the request.
        - "1.0": bool, Indicates whether the request originates from version 1.0.

    Returns:
    -------
    dict
        Response containing the following keys:
        - "flag" : bool, Indicates the success or failure of the operation.
        - "message" : str, Describes the result or error encountered.
        - "Modules" : dict, Structured module data (if successful).
        - "logo" : str, Tenant's logo information.
        - "access_token" : str, Generated access token (if applicable).
    """
    """
    if the data is coming from 1.0 then saving and auditing the user  details
    """
    # Check if "1.0": true exists in the data
    start_time = time()
    user_name = data.get("username", "")
    if data.get("1.0"):
        # Add values to the database since "1.0": true is present
        try:
            tenant_id = data.get("tenant_id", "")
            auth_code = data.get("auth_code", "")

            # Database connection

            db = DB("common_utils", **db_config)
            tenant_name = db.get_data("tenant", {"id": tenant_id}, ["tenant_name"])[
                "tenant_name"
            ].to_list()[0]

            request_received_at_utc =  datetime.now(timezone.utc)
            formatted_time = request_received_at_utc.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

            access_token = get_access_token(auth_code)
            p = {"last_login": formatted_time, "access_token": access_token}
            update_result = db.update_dict("users", p, {"username": user_name})

            if update_result:
                message = f"User table successfully updated for user: {user_name}."
            else:
                message = f"Failed to update user table for user: {user_name}."

            if not user_name:
                message = "Username not present in request data."

            # Check and update the live_sessions table
            login_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            # Check if the user already has an active session
            try:
                session_record = db.get_data(
                    "live_sessions", {"username": user_name}, ["username"]
                )["username"].to_list()[0]
            except Exception as e:
                logging.exception(f"### get_redirection_modules session_record exception : {e}")
                session_record = None

            # Check if session_record is either a string or a DataFrame
            if isinstance(session_record, pd.DataFrame) and not session_record.empty:
                # If session is active, update the record with new details
                session_data = {
                    "access_token": access_token,
                    "login": login_time,
                    "last_request": login_time,
                }
                db.update_dict(
                    "live_sessions",
                    session_data,
                    {"username": user_name, "status": "active"},
                )
            elif isinstance(session_record, str) and session_record == user_name:
                # If session is found but returned as a string (i.e., user already exists)
                session_data = {
                    "access_token": access_token,
                    "login": login_time,
                    "last_request": login_time,
                }
                db.update_dict(
                    "live_sessions",
                    session_data,
                    {"username": user_name, "status": "active"},
                )
            else:
                # If no active session, insert a new record
                session_data = {
                    "username": user_name,
                    "access_token": access_token,
                    "status": "active",
                    "login": login_time,
                    "last_request": login_time,
                }
                db.insert_dict(session_data, "live_sessions")
        except Exception as e:
            logging.exception(f"### get_redirection_modules exception is: {e}")
            message = "Something went wrong while updating user login data."
            return {"flag": False, "message": message}

    ##Restriction Check for the Amop API's
    # request_received_at = data.get("request_received_at", "")
    ##database connection
    db = DB("common_utils", **db_config)
    # Start time  and date calculation
    # username = data.get("username", None)
    tenant_name = tenant_name
    # session_id = data.get("session_id", None)
    role_name = data.get("role_name", None)

    # database Connection
    try:
        return_dict=get_modules(data)
        # Extracting the Modules list
        modules_data = return_dict.get("Modules", [])


        # Retrieve tenant logo
        tenant_data = db.get_data("tenant", {"tenant_name": tenant_name}, ["logo", "collapsed_logo", "dark_mode_logo","dark_mode_collapsed_logo"])
        logo = tenant_data["logo"].to_list()[0] if not tenant_data.empty else ""
        dark_mode_logo = tenant_data["dark_mode_logo"].to_list()[0] if not tenant_data.empty else ""
        collapsed_logo = tenant_data["collapsed_logo"].to_list()[0] if not tenant_data.empty else ""
        dark_mode_collapsed_logo = tenant_data["dark_mode_collapsed_logo"].to_list()[0] if not tenant_data.empty else ""
        # getting tenant_ids for all the users
        if role_name == "Super Admin":
            tenant_names_all = db.get_data("tenant", {"is_active": "true"}).to_dict(
                orient="records"
            )
            final_tenants = format_tenant_data(tenant_names_all, [], role_name)
        else:
            tenant_ids = db.get_data(
                "user_module_tenant_mapping",
                {"user_name": user_name},
                ["tenant_id"],
            )["tenant_id"].to_list()
            role_tenant_ids = db.get_data(
                "roles",
                {"role_name": role_name, "is_active": True},
                ["tenant_id"],
            )["tenant_id"].to_list()
            role_tenant_name = db.get_data(
                "tenant", {"id": role_tenant_ids}, ["tenant_name"]
            )["tenant_name"].to_list()
            # logging.info(f"tenant_id : {tenant_ids} and role_tenant_name are {role_tenant_name}")
            message = "User authenticated successfully."

            tenant_all_df = db.get_data(
                "tenant", {"id": tenant_ids, "is_active": "true"}
            ).to_dict(orient="records")
            final_tenants = format_tenant_data(tenant_all_df, role_tenant_name, "")
        db_name = db.get_data("tenant", {"tenant_name": tenant_name}, ["db_name"])[
            "db_name"
        ].to_list()[0]
        message = "Module data sent sucessfully"
        try:
            # End time calculation
            end_time = time()
            time_consumed = end_time - start_time
            ## Auditing
            audit_data = {
                "service_name": "get_redirection_modules",
                "created_date": datetime.now(),
                "created_by": user_name,
                "status": True,
                "time_consumed_secs": time_consumed,
                "session_id": None,
                "tenant_name": tenant_name,
                "comments": f"fetch redirection modiles for client - {user_name}",
                "module_name": "User_authentication",
                "request_received_at": datetime.now(),
            }
            db.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### get_redirection_modules audit_user_actions exception : {e}")
        response = {
            "flag": True,
            "message": message,
            "Modules": modules_data,
            "tenant_names": final_tenants,
            "db_name": db_name,
            "logo": logo,
            "dark_mode_logo": dark_mode_logo,
            "dark_mode_collapsed_logo": dark_mode_collapsed_logo,
            "collapsed_logo": collapsed_logo,
            "access_token": access_token,
        }

        return response
    except Exception as e:
        logging.exception(f"### get_redirection_modules excepton is {e}")
        message = "Something went wrong while getting modules"
        error_data = {
            "service_name": "get_redirection_modules",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": user_name,
            "session_id": None,
            "tenant_name": "",
            "comments": f"get_redirection_modules failed for user - {user_name}",
            "module_name": "User_authentication",
            "request_received_at": datetime.now(),
        }
        db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": message}

def create_machine_user(data):
    """
    Creates a machine user and generates credentials (clientId and clientSecret).

    Args:
        data (dict): Required keys include:
            - client_id: username for new machine user
            - partner_token: (unused in this flow)
            - zitadel_domain: ZITADEL host domain
            - session_id, user_name, Partner: for audit context

    Returns:
        dict: { flag: bool, message: str, data: { userId, clientId, clientSecret } }
    """
    logging.info(f"### create_machine_user data : {data}")
    # 1) Read API-token and build headers
    zitadel_domain = os.getenv("zitadel_domain", "")
    bearer = os.getenv("AUTH_TOKEN", "")
    username= data.get("user_name", "")
    tenant_name = data.get("Partner", "")
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:  
        logging.exception(f"### create_machine_user Error connecting to common_utils database : {e}")
        return {"flag": False, "message": f"Database connection failed: {e}"}
    ## Check if bearer token is provided
    if not bearer:
        return {"flag": False, "message": "AUTH_TOKEN environment variable is not set."}
    headers = {"Authorization": f"Bearer {bearer}", "Content-Type": "application/json"}
    try:
        # 2) Send POST to create the machine user
        body = {
            "userName": data["client_id"],
            "description": "Machine Account for APIS",
            "name": data["client_id"],
            "accessTokenType": "ACCESS_TOKEN_TYPE_BEARER"
        }

        create_url = f"https://{zitadel_domain}/management/v1/users/machine"
        try:
            resp = requests.post(create_url, headers=headers, json=body)
            resp.raise_for_status()
            logging.info(f"### create_machine_user response is: {resp.json()}")
        except Exception as e:
            logging.exception(f"### create_machine_user exception : {e}")
            return {"flag": False, "message": "Failed to Create Machine User"}

        user_data = resp.json()
        user_id = user_data.get("userId")
        if not user_id:
            return {"flag": False, "message": "No userId returned after creation."}

        # 3) Call PUT /users/{userId}/secret to get client credentials
        secret_url = f"https://{zitadel_domain}/management/v1/users/{user_id}/secret"
        try:
            resp2 = requests.put(secret_url, headers=headers)
            resp2.raise_for_status()
        except Exception as e:
            logging.exception(f"### create_machine_user Error retrieving secret : {e}")
            return {"flag": False, "message": f"Retrieve secret failed: {e}"}

        secret_data = resp2.json()
        client_id = secret_data.get("clientId")
        client_secret = secret_data.get("clientSecret")
        if not client_id or not client_secret:
            return {"flag": False, "message": "clientId or clientSecret missing in secret response"}
        response={
            "flag": True,
            "message": "Created machine user and generated secret successfully",
            "data": {
                "userId": user_id,
                "clientId": client_id,
                "clientSecret": client_secret
            }}
        try:
            ##auditing the user actions
            audit_data_user_actions = {
                "service_name": "create_machine_user",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "module_name": "User_authentication",
                "comments": "Creates a machine user and generates credentials (clientId and clientSecret)",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### create_machine_user Exception is {e}")
        # 4) Return results
        return response
        
    except Exception as e:
        logging.exception(f"### create_machine_user Unexpected error:{e}")
        message="Failed to create machine user"
        response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "create_machine_user",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "comments": "",
                "module_name": "User_authentication",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### create_machine_user Exception is {e}")
        return response


def regenarate_client_secret(data):
    """
    regenrate a machine user and generates credentials (clientId and clientSecret).

    Args:
        data (dict): Required keys include:
            - client_id: username for new machine user
            - partner_token: (unused in this flow)
            - zitadel_domain: ZITADEL host domain
            - session_id, user_name, Partner: for audit context

    Returns:
        dict: { flag: bool, message: str, data: { userId, clientId, clientSecret } }
    """
    # 1) Read API-token and build headers
    zitadel_domain = os.getenv("zitadel_domain", "")
    bearer = os.getenv("AUTH_TOKEN", "")
    username= data.get("user_name", "")
    tenant_name = data.get("Partner", "")
    client_id=data.get('client_id','')
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:  
        logging.exception(f"### regenarate_client_secret Error connecting to common_utils database : {e}")
        return {"flag": False, "message": f"Database connection failed: {e}"}
    ## Check if bearer token is provided
    if not bearer:
        return {"flag": False, "message": "AUTH_TOKEN environment variable is not set."}
    headers = {"Authorization": f"Bearer {bearer}", "Content-Type": "application/json"}
    try:
        user_id=common_utils_database.get_data('service_accounts',{'client_id':client_id},['user_id'])['user_id'].to_list()[0]

        # 3) Call PUT /users/{userId}/secret to get client credentials
        secret_url = f"https://{zitadel_domain}/management/v1/users/{user_id}/secret"
        try:
            resp2 = requests.put(secret_url, headers=headers)
            resp2.raise_for_status()
        except Exception as e:
            logging.exception("### regenarate_client_secret Error retrieving secret")
            return {"flag": False, "message": f"Retrieve secret failed: {e}"}

        secret_data = resp2.json()
        client_id = secret_data.get("clientId")
        client_secret = secret_data.get("clientSecret")
        if not client_id or not client_secret:
            return {"flag": False, "message": "clientId or clientSecret missing in secret response"}
        response={
            "flag": True,
            "message": "generated secret successfully",
            "data": {
                "clientSecret": client_secret
            }}
        try:
            ##auditing the user actions
            audit_data_user_actions = {
                "service_name": "regenarate_client_secret",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "True",
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "module_name": "User_authentication",
                "comments": f"regenrate a machine user and generates credentials - {client_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### regenarate_client_secret Exception is {e}")
        # 4) Return results
        return response
        
    except Exception as e:
        logging.exception(f"### regenarate_client_secret Unexpected error :{e}")
        message="Failed to create machine user"
        response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "regenarate_client_secret",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "User_authentication",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### regenarate_client_secret error_log_table Exception is {e}")
        return response


def generate_access_token(data):
    """
    Exchanges client credentials for an access token using ZITADEL's OAuth2 endpoint.

    Returns:
        dict: {
            flag (bool),
            message (str),
            data: {
                access_token (str),
                expires_in (int),
                token_type (str)
            } or None
        }
    """
    logging.info(f"### generate_access_token data {data}")
    start_time = time()
    zitadel_domain = os.getenv("zitadel_domain", "")
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.exception(f"### generate_access_token Exception while connecting to database : {e}")

    client_id_api = data.get("client_id")
    client_secret = data.get("client_secret")
    client_id = f"{client_id_api}_api"
    if not client_secret or not client_id:
        return {"message": "Missing credentials", "status_code": 400}

    # Fetch client secret from the database
    user_info = common_utils_database.get_data(
        "service_accounts", {"client_id": client_id}, ["client_secret"]
    )
    db_client_secret = user_info["client_secret"].to_list()

    if db_client_secret:
        db_client_secret = db_client_secret[0]
    else:
        return {"message": "Not registered", "status_code": 400}

    if db_client_secret != client_secret:
        return {"message": "Invalid secret code", "status_code": 400}
    token_url = f"https://{zitadel_domain}/oauth/v2/token"
    try:
        response = requests.post(
                token_url,
                data={
                    "grant_type": "client_credentials",
                    "scope": "openid profile"
                },
                auth=HTTPBasicAuth(client_id, client_secret),
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=30
            )
        try:
            response.raise_for_status()
        except Exception as e:
            logging.exception(f"### generate_access_token raise_for_status exception : {e}")
        token_data = response.json()
        access_token = token_data.get("access_token")
        if not access_token:
            token_data=get_auth_token(data)
            access = token_data.get("access_token")
            if isinstance(access, str):
                access_token = access
            elif isinstance(access, dict):
                access_token = access.get("access_token")
            else:
                logging.error(f"### generate_access_token Invalid token_data structure: {token_data}")
                return {"flag": False, "message": "Invalid token response format", "data": None}

        expires_in = token_data.get("expires_in",'')
    except (ValueError, KeyError) as e:
        msg = f"Invalid token response: {e}"
        logging.error(msg, exc_info=True)
        error_data = {
            "service_name": "generate_access_token",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": client_id,
            "session_id": None,
            "tenant_name": "",
            "comments": "generate access toke failed",
            "module_name": "User_authentication",
            "request_received_at": datetime.now(),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": msg, "data": None}
    '''
    update query to update the token in service accounts tableeee
    '''
    update_data={"z_access_token":access_token}
    common_utils_database.update_dict("service_accounts", update_data, {"client_id": client_id})
    logging.info(f"### generate_access_token Fetched token successfully; expires in {expires_in} seconds")
    response={
            "access_token": access_token,
        }
    try:
        # End time calculation
        end_time = time()
        time_consumed = end_time - start_time
        ## Auditing
        audit_data = {
            "service_name": "generate_access_token",
            "created_date": datetime.now(),
            "created_by": client_id,
            "status": "True",
            "time_consumed_secs": time_consumed,
            "session_id": None,
            "tenant_name": "",
            "comments": f"acces token generate for user - {client_id}",
            "module_name": "User_authentication",
            "request_received_at": datetime.now(),
        }
        common_utils_database.update_audit(audit_data, "audit_user_actions")
    except Exception as e:
        logging.exception(f"### generate_access_token audit_user_actions exception : {e}")
    return response