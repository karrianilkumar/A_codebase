"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil.N
Created Date: 21-06-24
"""

# Importing the necessary Libraries
import traceback
import os
import sqlalchemy
import datetime
import json
from time import time
from common_utils.authentication_check import validate_access_token
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging

logging = Logging(name="user_management")
# Dictionary to store database configuration settings retrieved from environment variables.
# db_config = {
#     'host': "amopuatpostgresdb.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
#     'port': "5432",
#     'user':"root",
#     'password':"AlgoTeam123"
# }
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}


def delete_user(data):
    """The  function deletes a user from the Users_directory table based on the provided username
    and returns a success or error message depending on the outcome"""

    try:
        start_time = time()
        date_started = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    except:
        logging.warning("Failed to start ram and time calc")
        pass

    tenant_name = data.get("tenant_name", None)
    session_id = data.get("session_id", None)
    module_name = data.get("module_name", None)

    # checking the access token valididty
    acess_token = data.get("acess_token", None)
    user_name = data.get("user_name", None)
    if not validate_access_token(acess_token, user_name):
        message = "Invalid Access,Token Cannot Process Request"
        return {"flag": False, "message": message}

    try:
        try:
            created_date = data["date"]
            session_id = data["session_id"]
        except:
            traceback.print_exc()
            message = "id not present in request data."
            return {"flag": False, "message": message}
        ##connecting to the database
        db = DB("AmopAlgouatDB", **db_config)
        Users_directory_query_parms = [user_name]
        Users_directory_query = "DELETE FROM `Users_directory` WHERE `username` = %s"
        result = db.execute_query(
            Users_directory_query, parms=Users_directory_query_parms
        )
        if not result:
            message = f"Something went wrong while deleting the user {user_name}  from Users_directory"
            response = {"flag": False, "message": message}
        message = f"Successfully deleted {user_name}"
        response = {"flag": True, "message": message}

        # End time calculation
        end_time = time()
        time_consumed = end_time - start_time

        ##auditing
        audit_data_user_actions = {
            "service_name": "User_managemant",
            "created_date": date_started,
            "created_by": user_name,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": module_name,
            "request_received_at": start_time,
        }
        db.update_audit(audit_data_user_actions, "audit_user_actions")

        return response

    except Exception as e:

        logging.error(f"Something went wrong and error is {e}")
        message = "Something went wrong while adding user_name"
        ##Error Management
        error_data = {
            "service_name": "User_managemant",
            "created_date": start_time,
            "error_messag": message,
            "error_type": e,
            "user": user_name,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": module_name,
            "request_received_at": start_time,
        }
        db.log_error_to_db(error_data, "error_table")

        return {"flag": False, "message": message}


def edit_user(data):
    """
    Edits user details in the Users_directory table.
    Parameters:
    - data (dict): Contains 'username' and 'edited_details' to update.
    - db (object): Database connection object.
    Returns:
    - dict: A flag indicating success or failure, and a corresponding message.
    """

    try:
        start_time = time()
        date_started = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    except:
        logging.warning("Failed to start ram and time calc")
        pass

    tenant_name = data.get("tenant_name", None)
    session_id = data.get("session_id", None)
    module_name = data.get("module_name", None)

    # checking the access token valididty
    acess_token = data.get("acess_token", None)
    user_name = data.get("user_name", None)
    if not validate_access_token(acess_token, user_name):
        message = "Invalid Access,Token Cannot Process Request"
        return {"flag": False, "message": message}

    try:
        try:
            ##connecting to the database
            db = DB("AmopAlgouatDB", **db_config)
            edited_details = data["edited_details"]
            session_id = data["session_id"]
        except:
            traceback.print_exc()
            message = "id not present in request data."
            return {"flag": False, "message": message}

        db.update_dict("Users_directory", update=edited_details)

        message = f"user changes are updated Sucessfully"
        response = {"flag": True, "message": message}

        # End time calculation
        end_time = time()
        time_consumed = end_time - start_time

        ##auditing
        audit_data_user_actions = {
            "service_name": "User_managemant",
            "created_date": date_started,
            "created_by": user_name,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": module_name,
            "request_received_at": start_time,
        }
        db.update_audit(audit_data_user_actions, "audit_user_actions")

        return response

    except Exception as e:

        logging.error(f"Something went wrong and error is {e}")
        message = "Something went wrong while adding user_name"
        ##Error Management
        error_data = {
            "service_name": "User_managemant",
            "created_date": start_time,
            "error_messag": message,
            "error_type": e,
            "user": user_name,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": module_name,
            "request_received_at": start_time,
        }
        db.log_error_to_db(error_data, "error_table")

        return {"flag": False, "message": message}


def fetch_user_Management():
    """
    Description:The  function retrieves user roles, existing user data, and tenant information,
    returning them in a structured format. If an error occurs, it logs the exception and returns a failure message.
    """
    try:
        # Initialize an empty dictionary to store the data.
        data = {}
        # Populate the dictionary with data fetched from various sources.
        data["roles"] = fetch_user_roles
        data["existing_user_data"] = fetch_existing_user_data
        data["tenants"] = fetch_tenants
        return {"flag": True, "data": data}
    except Exception as e:
        # Log an error message if an exception occurs.
        logging.error(f"Something went wrong and error is {e}")
        message = "Something went wrong while getting roles."
        return {"flag": False, "message": message}


def fetch_user_roles():
    # The function is used to fetch user from User_Role_Site
    try:
        ##connecting to the database
        db = DB("AmopAlgouatDB", **db_config)
        get_roles_query = f"SELECT roles FROM `user_role_site`"
        df = db.execute_query(get_roles_query)
        # Extract the 'role' values from the DataFrame and convert them to a list
        roles = df["roles"].tolist()
        return roles
    except Exception as e:
        logging.error(f"Something went wrong and error is {e}")
        message = "Something went wrong while getting roles."
        return {"flag": False, "message": message}


def fetch_existing_user_data():
    # The function is used to all the present user from Users_directory
    try:
        ##connecting to the database
        db = DB("AmopAlgouatDB", **db_config)
        get_users_query = f"SELECT * FROM `users_directory`"
        df = db.execute_query(get_users_query)
        # Extract the 'role' values from the DataFrame and convert them to a list
        user_data = df.to_dict(orinet="records")
        return user_data
    except Exception as e:
        logging.error(f"Something went wrong and error is {e}")
        message = "Something went wrong while getting roles."
        return {"flag": False, "message": message}


def fetch_tenants():
    # The function is used to  fetch tenants from Tenants table
    try:
        ##connecting to the database
        db = DB("AmopAlgouatDB", **db_config)
        get_tenants_query = f"SELECT tenants FROM `tenants`"
        df = db.execute_query(get_tenants_query)
        # Extract the 'tenants' values from the DataFrame and convert them to a list
        tenants = df["tenants"].tolist()
        return tenants
    except Exception as e:
        logging.error(f"Something went wrong and error is {e}")
        message = "Something went wrong while getting tenants."
        return {"flag": False, "message": message}


def creating_the_user(data):
    # The function is used to create user

    try:
        start_time = time()
        date_started = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    except:
        logging.warning("Failed to start ram and time calc")
        pass

    tenant_name = data.get("tenant_name", None)
    session_id = data.get("session_id", None)
    module_name = data.get("module_name", None)

    # checking the access token valididty
    acess_token = data.get("acess_token", None)
    user_name = data.get("user_name", None)
    if not validate_access_token(acess_token, user_name):
        message = "Invalid Access,Token Cannot Process Request"
        return {"flag": False, "message": message}

    try:
        try:
            user_details = data["user_details"]
            session_id = data["session_id"]
        except:
            traceback.print_exc()
            message = "id not present in request data."
            return {"flag": False, "message": message}

        try:
            ##connecting to the database
            db = DB("AmopAlgouatDB", **db_config)
            db.insert_dict(user_details, "Users_directory")
        except sqlalchemy.exc.IntegrityError:
            traceback.print_exc()
            message = "Duplicate entry for username"
            return {"flag": False, "message": message}
        except:
            traceback.print_exc()
            message = f"Something went wrong while creating user_name"
            return {"flag": False, "message": message}

        message = "user created sucessfully"
        response = {"flag": True, "message": message}

        # End time calculation
        end_time = time()
        time_consumed = end_time - start_time
        ##auditing
        audit_data_user_actions = {
            "service_name": "User_managemant",
            "created_date": date_started,
            "created_by": user_name,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": module_name,
            "request_received_at": start_time,
        }
        db.update_audit(audit_data_user_actions, "audit_user_actions")
        return response
    except Exception as e:
        logging.error(f"Something went wrong and error is {e}")
        message = "Something went wrong while adding user_name"
        ##Error Management
        error_data = {
            "service_name": "User_managemant",
            "created_date": start_time,
            "error_messag": message,
            "error_type": e,
            "user": user_name,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": module_name,
            "request_received_at": start_time,
        }
        db.log_error_to_db(error_data, "error_table")
        return {"flag": False, "message": message}
