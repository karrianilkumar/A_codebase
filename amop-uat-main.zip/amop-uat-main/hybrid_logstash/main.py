import json
from opensearchpy import OpenSearch, helpers
import psycopg2
# from datetime import datetime
from datetime import datetime, timedelta, timezone
import uuid
import json
from multiprocessing import Pool
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests.auth import HTTPBasicAuth
import time

# Configuration
BATCH_SIZE = 50000  # Adjust this batch size based on testing
NUM_PROCESSES = 2  # Number of processes (matches the number of vCPUs in your PostgreSQL instance)
batch_count = 0
# Connect to OpenSearch
es = OpenSearch(
    ['https://search-amopsearchuat-dzxpse4exyj37kauestkbgeady.us-east-1.es.amazonaws.com'],
    http_auth=('admin', 'Amopteam@123'),
    use_ssl=True,
    verify_certs=True,
    timeout=60
)

def lambda_handler(event, context):
    try:
        # Print the payload from the event
        print("Lambda triggered from scheduler")
        print(f"Payload received: {json.dumps(event)}")
        # event=json.dumps(event)
        # Extract view_name and last_modified from the event
        view_name = event.get("view_name")
        start_date = event.get("start_date")
        # end_date =  event.get("end_date")
        tenant_name= event.get("tenant_name")

        # if not last_modified:
        #     print("Error: last_modified is not provided in the event payload.")
        #     return

        # Parse last_modified and calculate end_date
        # start_date = start_date = datetime.fromisoformat(last_modified)
        

        if not start_date:
            print("Error: Invalid or missing start_date.")
            return  
        
        # end_date = start_date + timedelta(seconds=10)

        # # Convert back to string format for use in your query
        # start_date_str = start_date.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        # end_date_str = end_date.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

        

        # Print the calculated dates
        # print(f"Start Date: {start_date}")
        # print(f"End Date: {end_date}")
        start_time = time.time()    


        # lambda_flag = True
        # update_flag(view_name,lambda_flag,tenant_name)
        # # print(f"Updated true for {view_name}")
        # process_table(view_name, tenant_name, start_date)

        # lambda_flag = False
        # update_flag(view_name,lambda_flag,tenant_name)
        # print(f"updated the flag")

        try:
            lambda_flag = True
            update_flag(view_name,lambda_flag,tenant_name)
            print(f"Updated true for {view_name}")
            process_table(view_name, tenant_name, start_date)
            print(f"Processed table for {view_name} successfully")
        except Exception as e:
            print(f"Error in process_table: {e}")
        finally:
            lambda_flag = False
            update_flag(view_name,lambda_flag,tenant_name)
            print(f"Updated false for {view_name}")

        end_time = time.time()  # Record the end time

        execution_time = end_time - start_time
        # print(f"Time taken to execute process_table  for view {view_name}: {execution_time:.2f} seconds")
        # table_names = fetch_table_names()

        # # Define your start and end date for the filtering
        # start_date = '2025-01-02 15:33:58.000'
        # end_date = '2025-01-03 15:33:59.999'

        # # Use multiprocessing Pool to parallelize the indexing process
        # with Pool(processes=NUM_PROCESSES) as pool:
        #     pool.starmap(process_table, [(table_info, start_date, end_date) for table_info in table_names])



        # Add your logic here to handle the data (e.g., sync to OpenSearch, etc.)
        # Example: processing the view_name and last_modified.

        return {
            'statusCode': 200,
            'body': json.dumps(f"Lambda processed {view_name} with startdate : {start_date} ")
        }

    except Exception as e:
        print(f"Error in Lambda function: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps("Internal server error")
        }

def connect_to_postgres(db_name):
    return psycopg2.connect(
        dbname=db_name,
        user="root",
        password="AmopTeam123",
        host="amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
        port="5432"
    )

def parse_datetime(value):
    if value in (None, 'null', 'NULL', ''):
        return None
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value)  # Assuming ISO format is used
        except ValueError:
            try:
                return datetime.strptime(value, '%Y-%m-%d %H:%M:%S.%f')  # If it's in the format with microseconds
            except ValueError:
                print(f"Warning: Unable to parse date time string: {value}\n")
                return None
    elif isinstance(value, datetime):
        return value
    return None


def update_flag(view_name,flag,tenant_name):
    conn = connect_to_postgres(tenant_name)
    query="""
    UPDATE opensearch_lambda_status
    SET flag = %s
    WHERE view_name = %s;
    """
    try:
        with conn.cursor() as cur:
            cur.execute(query, (flag, view_name))
        conn.commit()  # Commit the transaction
    except Exception as e:
        print(f"Error updating flag: {e}")
    finally:
        conn.close()  # Always close the connection
    

def get_table_schema(conn, table_name):
    query = """
        SELECT column_name, data_type
        FROM information_schema.columns
        WHERE table_name = %s
        ORDER BY ordinal_position
    """
    with conn.cursor() as cur:
        cur.execute(query, (table_name,))
        columns = cur.fetchall()
    
    return {column[0]: column[1] for column in columns}

def parse_datetime(value):
    if value in (None, 'null', 'NULL', ''):
        return None
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value).isoformat()
        except ValueError:
            try:
                return datetime.strptime(value, '%Y-%m-%d %H:%M:%S.%f').isoformat()
            except ValueError:
                print(f"Warning: Unable to parse date time string: {value}\n")
                return value
    elif isinstance(value, datetime):
        return value.isoformat()
    return value

def convert_value_bk(value, data_type):
    if value in (None, 'null', 'NULL', ''):
        return None
    if data_type == 'boolean':
        return str(value).lower() in ('true', '1')
    elif data_type == 'timestamp without time zone':
        return parse_datetime(value)
    elif data_type == ('character varying', 'text'):
        return str(value)
    elif data_type == 'integer':
        return int(value)
    elif data_type == 'real':
        return float(value)
    elif data_type == 'uuid':
        try:
            return str(uuid.UUID(value))
        except ValueError:
            print(f"Warning: Invalid UUID format: {value}\n")
            return value
    # elif data_type == 'json':
    #     if isinstance(value, (dict, list)):
    #         return json.dumps(value)  # Convert dict or list to string
    #     try:
    #         loaded = json.loads(value)
    #         return json.dumps(loaded) if isinstance(loaded, (dict, list)) else loaded
    #     except json.JSONDecodeError:
    #         print(f"Warning: Invalid JSON format: {value}\n")
    #         return value
    elif data_type == 'json':
        if isinstance(value, (dict, list)):
            return value  # ✅ send as object/array
        try:
            return json.loads(value)  # ✅ decode JSON string to object/array
        except json.JSONDecodeError:
            print(f"Warning: Invalid JSON format: {value}\n")
            return None
        return value

import json
import uuid
import decimal
from dateutil.parser import parse as parse_datetime

def convert_value(value, data_type):
    if value in (None, 'null', 'NULL', ''):
        return None
    try:
        if data_type == 'boolean':
            return str(value).lower() in ('true', '1')
        elif data_type == 'timestamp without time zone':
            return parse_datetime(value).isoformat() if isinstance(value, str) else value.isoformat()
        elif data_type in ('character varying', 'text'):
            return str(value)
        elif data_type == 'integer':
            return int(value)
        elif data_type == 'real':
            return float(value)
        elif isinstance(value, decimal.Decimal):
            return float(value)
        elif data_type == 'uuid':
            return str(uuid.UUID(value))
        elif data_type == 'json':
            if isinstance(value, (dict, list)):
                return value  # Keep as object/array
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                print(f"Warning: Invalid JSON format: {value}\n")
                return None
        # Optional fallback for unknown types
        else:
            return value
    except Exception as e:
        print(f"[convert_value] Error converting value '{value}' with type '{data_type}': {e}")
        return None


def bulk_index_data(batch_data,db_name):
    table_name, rows, schema = batch_data
    if db_name == "altaworx_central":
        index_name = table_name
    else:
        index_name=f"{table_name}_{db_name}"
    actions = []
    print(f"\n### rows data : {rows}")
    for item in rows:
        doc = {}
        for i, column_name in enumerate(schema.keys()):
            value = item[i]
            data_type = schema[column_name]
            converted_value = convert_value(value, data_type)
            doc[column_name] = converted_value

        if 'id' not in doc:
            print(f"Warning: 'id' key not found in document for {table_name} --------'{index_name}': {doc}")
            break
        
        action = {
            "_op_type": "index",  # Use "update" if you want to update existing documents
            "_index": index_name,
            '_id': doc['id'],
            "_source": doc,
        }

        # date = datetime.now(timezone.utc).isoformat()

        # action = {
        #     "_op_type": "index",  # Use "update" if updating existing docs
        #     "_index": index_name,
        #     "_id": doc["id"],
        #     "_source": {
        #         **doc,  # Keep existing fields
        #         "_doc_modified_date": date  # Add modified date inside _source
        #     }
        # }
        actions.append(action)
    # if index_name == "vw_usage_line_report_altaworx_test":
    #     print("******************",actions)
    try:
        print(f"\n### Indexing batch for table '{table_name}' into index '{index_name}' with {len(actions)} documents")
        print(f"### Actions data : {actions}")
    except Exception as e:
        print(f"Error in bulk_index_data debug: {e}")
        
    try:
        response = helpers.bulk(es, actions)
        print(f"Successfully indexed {response[0]} documents for {table_name} and {index_name}")
    except Exception as e:
        print(f"Error indexing documents: {e}")



def fetch_and_bulk_index_data(table_name, db_name, start_date):
    conn = connect_to_postgres(db_name)
    schema = get_table_schema(conn, table_name)
    columns_list = ', '.join([f'"{col}"' for col in schema.keys()])
    
    # Identify the primary key column dynamically
    primary_key_column = "id"  # Assuming 'id' is always the primary key (even if not the first column)
    
    last_id = None
    
    while True:
        if last_id:
            query = f"""
                SELECT {columns_list} 
                FROM {table_name} 
                WHERE modified_date >= %s AND "{primary_key_column}" > %s
                ORDER BY "{primary_key_column}" ASC 
                LIMIT %s
            """
            query_params = (start_date, last_id, BATCH_SIZE)
        else:
            query = f"""
                SELECT {columns_list} 
                FROM {table_name} 
                WHERE modified_date >= %s
                ORDER BY "{primary_key_column}" ASC 
                LIMIT %s
            """
            query_params = (start_date, BATCH_SIZE)

        with conn.cursor() as cur:
            cur.execute(query, query_params)
            rows = cur.fetchall()
            if not rows:
                break

            yield (table_name, rows, schema)
            
            # Get the index of the primary key column dynamically
            primary_key_index = list(schema.keys()).index(primary_key_column)
            last_id = rows[-1][primary_key_index]  # Use the last processed primary key for pagination
    
    conn.close()




def process_table(table_name, db_name, start_date):
    # table_name, db_name = table_info
    for batch_data in fetch_and_bulk_index_data(table_name, db_name, start_date):
        print(f"Got data for {table_name} between {start_date} ")
        bulk_index_data(batch_data,db_name)

