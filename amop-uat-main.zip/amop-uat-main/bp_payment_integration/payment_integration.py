#Lambda
"""
@Author1 : Srikanth Rekkala
Created Date: 26-08-2025
"""

# Importing the necessary Libraries
import ast
import boto3
import requests
import os
import pandas as pd
from common_utils.billing_platform_email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import datetime
from datetime import time,date
from datetime import datetime, timedelta
import time
from io import BytesIO
from common_utils.data_transfer_main import DataTransfer
import json
import base64
import re
import pytds
from pytz import timezone
import numpy as np
from collections import defaultdict
#download template dependencies
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
import uuid
#authorize.net dependencies
import xml.etree.ElementTree as ET
# from authorizenet import apicontractsv1
# from authorizenet.apicontrollers import createCustomerProfileController
# from flask import request
from reportlab.lib.utils import ImageReader
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
import io
from dateutil.parser import parse
import copy
from dateutil.rrule import rrule, MONTHLY
import threading
# from concurrent.futures import ThreadPoolExecutor
import concurrent.futures
# import apicontractsv1
# import createCustomerProfileController
from io import StringIO
# from lxml import etree
import xml.etree.ElementTree as ET
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
import csv
from openpyxl import load_workbook
from openpyxl import Workbook
from pytz import UnknownTimeZoneError, timezone
import pandas as pd
from dateutil.relativedelta import relativedelta
import ast
from collections import Counter
from reportlab.lib.pagesizes import landscape, A4
from reportlab.lib.colors import HexColor
from reportlab.lib import colors
from PIL import Image, UnidentifiedImageError


# Dictionary to store database configuration settings retrieved from environment variables.
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema":False
}
logging = Logging(name="sim_management")

def get_transaction_details(trans_id, authentication_name, transaction_key):
    """
    Retrieves detailed transaction information from Authorize.Net, including the authorization code.

    This function constructs an XML request to fetch transaction details, sends it to the Authorize.Net API,
    and extracts the authorization code from the response.

    Args:
        trans_id (str): The transaction ID to retrieve details for.
        authentication_name (str): The API login ID for authentication.
        transaction_key (str): The transaction key for authentication.

    Returns:
        str or None: The authorization code if found, otherwise None.
    """
    try:
        # Create the XML request for transaction details
        root = ET.Element('getTransactionDetailsRequest', xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd")
        
        # Add authentication
        merchant_authentication = ET.SubElement(root, 'merchantAuthentication')
        ET.SubElement(merchant_authentication, 'name').text = authentication_name
        ET.SubElement(merchant_authentication, 'transactionKey').text = transaction_key
        
        # Add transaction ID
        ET.SubElement(root, 'transId').text = trans_id

        # Convert XML to string
        xml_output = ET.tostring(root, encoding="unicode", xml_declaration=True)

        # Send request to Authorize.Net
        url=os.environ["AUTHORIZE_NET_URL"]
        headers = {'Content-Type': 'application/xml'}
        response = requests.post(url, headers=headers, data=xml_output)

        # Process response if request was successful
        if response.status_code == 200:
            namespaces = {'ns': 'AnetApi/xml/v1/schema/AnetApiSchema.xsd'}
            response_root = ET.fromstring(response.text)
            
            # Get authorization code
            auth_code = get_element_text(response_root, './/ns:authCode', namespaces)
            return auth_code
    except Exception as e:
        print(f"Error getting transaction details: {str(e)}")
        return None

def get_customer_transaction_history(payment_profile_id):
    """
    Fetches the transaction history for a given customer payment profile from Authorize.Net.

    This function constructs an XML request to retrieve the list of transactions associated with a 
    specific customer profile, sends the request to the Authorize.Net API, and processes the response.

    Args:
        payment_profile_id (str): The payment profile ID of the customer.

    Returns:
        dict: A dictionary containing transaction details or an error message.
            - 'flag' (bool): Indicates success or failure.
            - 'transactions' (list): List of transaction details (if successful).
            - 'message' (str): Success or error message.
            - 'totalNumInResultSet' (str, optional): Total number of transactions found.
            - 'error' (str, optional): Error details in case of failure.
    """
    # Assign customer profile ID
    customer_profile_id = payment_profile_id
    print(f'##customer_profile_id{customer_profile_id}')

    # API authentication credentials
    authentication_name = os.environ["AUTHENTICATION_NAME"]
    transactionKey=os.environ["TRANSACTION_KEY"]

    try:
        # Create the XML request
        root = ET.Element('getTransactionListForCustomerRequest', xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd")
        
        # Add authentication
        merchant_authentication = ET.SubElement(root, 'merchantAuthentication')
        ET.SubElement(merchant_authentication, 'name').text = authentication_name
        ET.SubElement(merchant_authentication, 'transactionKey').text = transactionKey
        
        # Add customer profile ID
        ET.SubElement(root, 'customerProfileId').text = str(customer_profile_id)

        # Convert XML to string
        xml_output = ET.tostring(root, encoding="unicode", xml_declaration=True)

        # Send request to Authorize.Net
        url=os.environ["AUTHORIZE_NET_URL"]
        headers = {'Content-Type': 'application/xml'}
        response = requests.post(url, headers=headers, data=xml_output)

        if response.status_code == 200:
            namespaces = {'ns': 'AnetApi/xml/v1/schema/AnetApiSchema.xsd'}
            response_root = ET.fromstring(response.text)

            # Check for errors
            result_code = response_root.find('.//ns:resultCode', namespaces)
            if result_code is not None and result_code.text == "Error":
                error_text = response_root.find('.//ns:text', namespaces)
                error_message = error_text.text if error_text is not None else "Unknown error"
                return {
                    "flag": False,
                    "message": error_message
                }
            
             # Extract transaction details
            transactions = []
            trans_list = response_root.findall('.//ns:transaction', namespaces) or \
                        response_root.findall('.//transaction') # Handle missing namespace

            for transaction in trans_list:
                trans_id = get_element_text(transaction, './/ns:transId', namespaces)
                
                # Get authorization code for this transaction
                auth_code = get_transaction_details(trans_id, authentication_name, transactionKey)
                
                trans_info = {
                    'transId': trans_id,
                    'authCode': auth_code,  # Fetched from detailed transaction info
                    'submitTimeUTC': get_element_text(transaction, './/ns:submitTimeUTC', namespaces),
                    'submitTimeLocal': get_element_text(transaction, './/ns:submitTimeLocal', namespaces),
                    'transactionStatus': get_element_text(transaction, './/ns:transactionStatus', namespaces),
                    'firstName': get_element_text(transaction, './/ns:firstName', namespaces),
                    'lastName': get_element_text(transaction, './/ns:lastName', namespaces),
                    'accountType': get_element_text(transaction, './/ns:accountType', namespaces),
                    'accountNumber': get_element_text(transaction, './/ns:accountNumber', namespaces),
                    'settleAmount': get_element_text(transaction, './/ns:settleAmount', namespaces),
                    'marketType': get_element_text(transaction, './/ns:marketType', namespaces),
                    'product': get_element_text(transaction, './/ns:product', namespaces),
                    'profile': {
                        'customerProfileId': get_element_text(transaction, './/ns:customerProfileId', namespaces),
                        'customerPaymentProfileId': get_element_text(transaction, './/ns:customerPaymentProfileId', namespaces)
                    }
                }

                # Remove None values from the transaction dictionary
                trans_info = {k: v for k, v in trans_info.items() if v is not None}
                transactions.append(trans_info)
            print(f'##transactions {transactions}')
            transaction_response={
                "flag": True,
                "transactions": transactions,
                "message": "Transaction Details fetched" if transactions else "No transactions found",
                "totalNumInResultSet": get_element_text(response_root, './/ns:totalNumInResultSet', namespaces)
            }
        else:
            # Handle API request failure
            error_message = f"Error: Received {response.status_code} from API - {response.text}"
            transaction_response={
                "flag": False,
                "message": "API Request Failed",
                "error": error_message
            }
        return transaction_response

    except Exception as e:
        # Handle any unexpected errors
        error_message = f"An error occurred: {str(e)}"
        transaction_response={
            "flag": False,
            "message": "An error occurred",
            "error": error_message
        }
        return transaction_response

def update_transaction_status(data):
    """
    Retrieves and updates the transaction status for a given bill ID from the billing database, 
    retrying with exponential backoff if not found. Returns a success message if the transaction is successful, 
    a failure message if unsuccessful, or an error if the bill ID is not found.

    Args:
        data (dict): A dictionary containing the following keys:
            - username (str, optional): The username associated with the transaction. Defaults to an empty string.
            - table_name (str, optional): The database table to query. Defaults to "payment_history".
            - bill_id (str): The bill ID for which the transaction status needs to be retrieved.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if the transaction is successful, False otherwise.
            - message (str): A descriptive message about the transaction status.
    """
    
    # Extract values from the input dictionary
    username = data.get("username", "")
    table_name = data.get("table_name", "payment_batch_info")
    batch_id = data.get("batch_id", "")
    if not batch_id:
        return {"flag": False, "message": "Batch ID is Empty"}
    try:
        # Initialize database connection
        killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    except Exception as e:
        print(f"Database connection failed: {e}")
        return {"flag": False, "message": "Database connection error"}

    # Define retry parameters
    retries = 3  # Number of retry attempts
    delay = 2    # Initial delay in seconds for exponential backoff

    bill_id_df = None  # Initialize variable to store query result
    message='Transaction is Pending'
    flag=True
    # Retry mechanism to fetch transaction status
    for attempt in range(retries):
        try:
            #Fetch the transaction tratus of a Bill ID
            batch_id_df = killbill_database.get_data('payment_batch_info', {"id": batch_id}, ["batch_id"])
            if batch_id_df is not None and not batch_id_df.empty:
                # Extract the transaction status if data is found
                batch_status = str(batch_id_df['batch_id'].tolist()[0])
                print(f'##batch_status attempt {attempt+1}: {batch_status}')
                if str(batch_status)=='1':
                    message = "Transaction Successful"
                    break  # Exit loop if status is found
                elif str(batch_status)=='0':
                    message = "Transaction Failed"
                    flag=False
                    break  # Exit loop if status is found
                else:
                    print(f"Transaction is pending, retrying ({attempt+1}/{retries})...")
                    time.sleep(delay)
                    delay *= 2  # Exponential backoff (2s -> 4s -> 8s)
            else:
                # If transaction is not found, retry after a delay
                print(f"Transaction not found, retrying ({attempt+1}/{retries})...")
                time.sleep(delay)
                delay *= 2  # Exponential backoff (2s -> 4s -> 8s)
        except Exception as e:
            print(f"Error retrieving transaction data (attempt {attempt+1}): {e}")
            time.sleep(delay)
            delay *= 2
    return {'flag':flag,"message":message}


# Function to parse XML and extract required fields
def parse_transaction(xml_response, invoice_id,account_number):
    """
    Parses an XML response from Authorize.Net to find a transaction associated with a given invoice ID.

    Parameters:
        xml_response (str): The XML response string from Authorize.Net.
        invoice_id (str): The invoice number to search for.
        account_number (str): The account number associated with the transaction.

    Returns:
        dict: Parsed transaction details if a match is found.
        None: If no matching transaction is found.
    """

    # Parse XML response
    root = ET.fromstring(xml_response)

    # Namespace to parse the XML correctly
    namespace = {'anet': 'AnetApi/xml/v1/schema/AnetApiSchema.xsd'}

    # Find all transactions
    transactions = root.findall('.//anet:transaction', namespace)
    parse_transaction_info=''

    # Iterate through each transaction in the response
    for transaction in transactions:
        invoice = transaction.find('anet:invoiceNumber', namespace)
        
        # Check if the invoice number matches the requested invoice_id
        if invoice is not None and invoice.text == str(invoice_id):
            transaction_id=transaction.find('anet:transId', namespace).text
            parse_transaction_info=parse_transaction_data(transaction_id,account_number)

    if parse_transaction_info:
        print(f"Transactions for Invoice Number {invoice_id}:")
        return parse_transaction_info
    else:
        print(f"No Transactions found for Invoice Number {invoice_id}")
        return None

def parse_transaction_data(transaction_id,account_number):
    """
    Fetch transaction details from Authorize.Net using a transaction ID
    and return the parsed data as a dictionary.

    Parameters:
        transaction_id (str): The unique transaction identifier from Authorize.Net.
        account_number (str): The associated account number for reference.

    Returns:
        dict: Parsed transaction details including:
            - 'ref': Transaction ID
            - 'status': Transaction status
            - 'date': Transaction submission time
            - 'amount': Settlement amount
            - 'method': Payment method
            - 'bill_id': Associated invoice number
            - 'applied_to': Customer profile ID
            - 'auth_code': Authorization code
            - 'account_number': The provided account number
        None: If the request fails or an error occurs.
    """

    # Authorize.Net API credentials
    API_LOGIN_ID = os.environ["AUTHENTICATION_NAME"]
    TRANSACTION_KEY = os.environ["TRANSACTION_KEY"]

    # API Endpoint (Sandbox environment)
    API_URL=os.environ["AUTHORIZE_NET_URL"]

    # Construct XML request to fetch transaction details
    xml_request = f"""
    <getTransactionDetailsRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">
        <merchantAuthentication>
            <name>{API_LOGIN_ID}</name>
            <transactionKey>{TRANSACTION_KEY}</transactionKey>
        </merchantAuthentication>
        <transId>{transaction_id}</transId>
    </getTransactionDetailsRequest>
    """

    headers = {"Content-Type": "application/xml"}

    try:
        # Construct XML request to fetch transaction details
        response = requests.post(API_URL, data=xml_request, headers=headers)

         # If API response is unsuccessful, log the error and return None
        if response.status_code != 200:
            print(f"Error: Failed to fetch transaction details (HTTP {response.status_code})")
            return None

        # Log the raw XML response for debugging purposes
        print("Raw XML Response:")
        print(response.text)

        # Parse XML response into an ElementTree object
        root = ET.fromstring(response.text)

        # Define the XML namespace used in Authorize.Net responses
        namespace = {'': 'AnetApi/xml/v1/schema/AnetApiSchema.xsd'}

        # Extract relevant transaction details
        transaction_data = {
            "ref": transaction_id,
            "status": root.find(".//transactionStatus", namespace).text if root.find(".//transactionStatus", namespace) is not None else None,
            "date": root.find(".//submitTimeUTC", namespace).text if root.find(".//submitTimeUTC", namespace) is not None else None,
            "amount": root.find(".//settleAmount", namespace).text if root.find(".//settleAmount", namespace) is not None else None,
            "method": root.find(".//payment/paymentMethod", namespace).text if root.find(".//payment/paymentMethod", namespace) is not None else None,
            "bill_id": root.find(".//order/invoiceNumber", namespace).text if root.find(".//order/invoiceNumber", namespace) is not None else None,
            "applied_to": root.find(".//profile/customerProfileId", namespace).text if root.find(".//profile/customerProfileId", namespace) is not None else None,
            "auth_code": root.find(".//authCode", namespace).text if root.find(".//authCode", namespace) is not None else None,
            "account_number":account_number
        }
        return transaction_data # Return parsed transaction details
    except Exception as e:
        print(f"Exception occurred while fetching transaction data: {e}")
        return None

def get_element_text(element, xpath, namespaces):
    """Helper function to safely get element text"""
    try:
        elem = element.find(xpath, namespaces)
        return elem.text if elem is not None else None
    except:
        return None

def get_or_create_customer_profile(account_id, email, authentication_name, transactionKey):
    """
    Create or retrieve a customer profile in Authorize.net.
    
    This function sends an API request to Authorize.net to create a customer profile. If the profile is successfully
    created, the function extracts and returns the customerProfileId. If an error occurs, it logs the error and returns None.
    
    Args:
        account_id (str): Unique identifier for the customer.
        email (str): Customer's email address.
        authentication_name (str): Authorize.net API login ID.
        transactionKey (str): Authorize.net transaction key.
    
    Returns:
        str or None: The customerProfileId if successful, otherwise None.
    """

    # Initialize database connections (if needed for additional operations)
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    try:
        # Create the XML request
        root = ET.Element('createCustomerProfileRequest', xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd")
        merchant_authentication = ET.SubElement(root, 'merchantAuthentication')
        ET.SubElement(merchant_authentication, 'name').text = authentication_name
        ET.SubElement(merchant_authentication, 'transactionKey').text = transactionKey

        ## Add customer profile details
        profile = ET.SubElement(root, 'profile')
        ET.SubElement(profile, 'merchantCustomerId').text = account_id
        ET.SubElement(profile, 'email').text = email

        # Convert XML to string
        xml_output = ET.tostring(root, encoding="unicode", xml_declaration=True)

        # Send the request to Authorize.Net
        url=os.environ["AUTHORIZE_NET_URL"]
        headers = {'Content-Type': 'application/xml'}
        response = requests.post(url, headers=headers, data=xml_output)
        print(f'###response {response}')

        # Check if the request was successful
        if response.status_code == 200:
            # Parse the response
            response_text = response.text
            print(f'###response_text {response_text}')  # Add this for debugging
            
            # Define the namespace mapping
            namespaces = {'ns': 'AnetApi/xml/v1/schema/AnetApiSchema.xsd'}
            
            response_root = ET.fromstring(response_text)
            print(f'###response_root {response_root}')

            # Check for error response first
            result_code = response_root.find('.//ns:resultCode', namespaces)
            if result_code is not None and result_code.text == "Error":
                error_text = response_root.find('.//ns:text', namespaces)
                error_message = error_text.text if error_text is not None else "Unknown error"
                print(f"--------->Error from Authorize.Net: {error_message}")
                return None

            # Try different approaches to find customerProfileId
            customer_profile_id = None
            
            # Approach 1: Using namespace
            customer_profile_id = response_root.find('.//ns:customerProfileId', namespaces)
            
            # Approach 2: Direct path if namespace approach fails
            if customer_profile_id is None:
                customer_profile_id = response_root.find('.//*customerProfileId')
            
            # Approach 3: Full path if other approaches fail
            if customer_profile_id is None:
                for elem in response_root.iter():
                    if elem.tag.endswith('customerProfileId'):
                        customer_profile_id = elem
                        break
            
            # If customerProfileId is found, return it
            if customer_profile_id is not None:
                profile_id = customer_profile_id.text
                print(f"------>Successfully retrieved customerProfileId: {profile_id}")
                return profile_id
            else:
                print("--------->Failed to create customer profile: No customerProfileId in response")
                print(f"Full response content: {response_text}")  # Add this for debugging
                return None
        else:
            print(f"------->Error: Received {response.status_code} from API - {response.text}")
            return None

    # Handle request exceptions
    except requests.RequestException as req_err:
        print(f"------->API Request failed: {req_err}")
        return None
    # Handle XML parsing errors
    except ET.ParseError as xml_err:
        print(f"------->XML Parsing error: {xml_err}")
        print("Response content:", response.text)
        return None
    # Handle general exceptions
    except Exception as e:
        print(f"------->An error occurred: {str(e)}")
        return None
def get_token(data):
    url_response = {
        "Message": {
            "Response": {
                "Reference": {
                    "Guid": "EBZRFX5HFKF8WKX",
                    "TranDate": "08/25/2025",
                    "TranTime": "07:04:02"
                },
                "Result": {
                    "ResponseCode": "00",
                    "ResponseText": "Initialized"
                },
                "PayPage": {
                    "Guid": "EBZNZFZ2G1Q0V01",
                    "Session": "f6wM0O76l7p3yyWyhNGcCt%2Fao7XnrCO346gPslTzJRrkml%2Fynax2ZaZ6h5fGfNfPH9RU6Rz64QTxks9FUa0GMer87KHYN52o7%2FgCZuiaRN1z3sBrcrD%2BWZTqGWHTz9TaBizUYpsJeXWlXI6UKMck9IYq5w36ZTFCu3ejogQODi9YRYNGINnR5lOb6GkxiKZj2hl3djKsI43BSHxQvc8L2mWBD1B88yfnCgO%2BBWyALqZSup3M49Dt6g0JxOpdglhazlmuy3RFQwFGp96ePno1GlBnAjGksVLtBfI46Ux0p85QodVVY38WUi0qyaUXPj2rY4zafycHc1cZrcA8BDwW0mudiCfMgwCdhIciv8ba5OUz9qcUxUiGX9pGy6OIiqJbll0uCRpSerJdhWpk44lzFkjqHA0IE1B15lMrP%2BuP%2Fz8dc%2F3QLDDNkZpeyCK5YCLPJC7Fhb4VkkClgdJNX1c%2FxTnd9pqjoIsieXKYkmStsyXkawwXKhDjE1dY7XKpB8dy8gkqLrBN8p1HiNqtHbD5RXn91NMh8Vos6OnP%2BUzriaEEVBrty0hDRuku0eqaSFYWSIH1luicRPeO3hwrtpRzqIlm4EBFdO67ywT0%2BSM%2BEU1EbvWtnb0K6d3Is%2FkpMIJUYtEVaid38yVgLnzBscEWswcqFuk0johBK5FUatjH14mmyb3uouvCeIkupjrSI8%2B1GMGDCXye0riagbyP5I%2B3DXn8yqKIzNvNAXjY%2BQ8Y6hmRrUrlYWtABF94L8IH1NgWjUi2eHg3Q2ZPDBM2SBXX8OHNPTJ4jm%2FCMDP%2BOfncYxv82L97bOqPkZ2fCt5keZcRNZCkTn%2FOieVA1NZHYvGuC4ALcvHEO4OKNMhjQF0XZI%2BqQil1%2B%2BtHU0vazxYHuPcVK30ZNN%2Bjd6gZKHdQ7mD5YhT%2F7vPhe7xIzkvft4xcGxSdNbpUNQJnFhtzwT7xKcdgOQZLV86aKunILCJkpmHgLTmdyGm7RrPLTP1QKsNyNXl%2FDsrseJOBmYOSaXAX3tmsQqr%2B8G5p0o2KibZAu5pXA2HGEGswuzI9YNz9zOFEKZ5IlnoUGVC1dkk9Gw6DXdNdQxWPTnbNiV1YNsv7tgIK8aF1zK7TXoQOqKuqRwhTrlWXWeSgsf1%2FQkW20xPnKggiA4ulbu7Oi6soaqiUI5D%2F7raDnpdp%2FmcODkZX2FcZDSW2ERzUCbS37YhF6unNS7TvvihTCjpatKGH0tJHb0igCPJ7czLRjZ4GMT%2FbSGu0FbelnjMmsP1ZP4TWzHnN7H5x6MB5fyOlVC4%2B6IR%2BJhIE%2F%2B7goXq0pibM4sFVpNKEFUsF1wqqH7AzpVuqf3MjduGIU6a1iNRgU9ynzESxwIKNG7QQ1diq4pnVCxGz2LARc118LQ6c4Y2QJwhtDWXq0uOIi7fOjj1JKPZV0dy%2Bvse94TY17rbwSZCCYBmNsBxURjGdq9fMc%2FWMmytwNv5izbAPvnAS%2F9xNciayAh5%2BswzJtNQMfwHhzvPGY8CZgFpldKe35wSQyYV7xpgyAojpa1sf3KOY1asC7UKV3axa%2Fo0ksrnhqGun2Fiv8atOwsJLSMv4cJt%2FjfsI6JqQa4tvWR27d36HmDp%2BGEe%2BxXXBAJql9GWbAJtGl4Q3rYcfTCa4UO1sWvx%2B2iycLOReYk%2FSPwTRG%2FTzVuXwEbCoBGH4U%2BQ3I8F6cY%2FGM%2FagdnzCpEwYKs78OsRjMWooxBiDvDjspfhMt8yCLjbU4m2mhoVeECJjcLjqOAE8V3bdJkvvd4pwWeokncQNrvWuG94ilW7qwZwp1C9z0raywaJC2BMHvx3Ku9PK5n5SkMTT9CcROdfRaIoGDA%2FNB7dY9at8R7HbYfO8NdDzWa1cKBEPh5IKEeGoHAOGN6l8yGvsf31p%2Ba4YcKd%2FBbckCX1%2FTS4zyVg207pdumCcDUXGgLKrYNRuB101kUs1qd6KWlonUU16Dn77hP7ApfW%2F6dEbD7%2FqxywlV%2FjBporhX086QcwIgd%2F%2Fg%2FoBNJQWfGSv6jiEJsg2N0mEz7sAqIlMnhD%2B19aNvdTTcEthvccmBRcJi%2FBKi7PxnRliUG9gWkM%2BbCE7OgdHLARkXSQp9USARdDeKG2jUMvGli2vPWfvB3ghFngCqGdmOZWavQbUqyX6bu1p9xLI5%2Fy5jLJQMXF%2FXUJFW4qmMf8rpg1RBU7uzIBUV77bKFjxjGUv1kD%2FwNENoPJ7Z8wp8F5CBt33b8JRTYxS6%2FXgsN93CSnl"
                }
            }
        }
    }
    paypage_guid = url_response["Message"]["Response"]["PayPage"]["Guid"]
    session_id = url_response["Message"]["Response"]["PayPage"]["Session"]

    # Construct payment URL
    payment_url = f"https://pay.trxservices.net/?clientId=1053&paypage={paypage_guid}&session={session_id}"

    return {
        "flag": True,
        "token": payment_url
    }

def payment_method_handler(storage_safe_data, account_number, billing_platform_db, reference_data, card_last_four, account_brand):
    """
    Handles payment method persistence in the billing platform.

    This function checks if a payment method already exists in the `payment_methods` table 
    based on account_number, account_guid, and storage_safe_guid. 
    If not found, it inserts a new payment method record with details like card last four digits,
    expiry date, and brand.

    Args:
        storage_safe_data (dict): StorageSafe response containing account identifiers.
        account_number (str): The unique account number in the billing platform.
        billing_platform_db (object): Database handler with methods get_data and insert_data.
        reference_data (dict): Reference details containing card expiration info.
        card_last_four (str): Last four digits of the card.
        account_brand (str): Card brand (e.g., VISA, MasterCard).

    Returns:
        None
    """
    logging.info(f'## payment_method_handler function called')
    try:
        if storage_safe_data:
            # Extract identifiers from StorageSafe data
            account_guid = storage_safe_data.get("AccountGuid")
            storage_safe_guid = storage_safe_data.get("Guid")

            # Proceed only if required identifiers and account number exist
            if account_guid and storage_safe_guid and account_number:
                # Check if the payment method already exists in DB
                existing_pm_df = billing_platform_db.get_data(
                    "payment_methods",
                    {
                        "account_number": account_number,
                        "account_guid": account_guid,
                        "storage_safe_guid": storage_safe_guid
                    },
                    ["id"]
                )

                if existing_pm_df is None or existing_pm_df.empty:
                    # Format expiry date (e.g., "1134" → "11/34")
                    expiry_date = reference_data.get("Expiration", "")
                    if len(expiry_date) == 4:
                        expiry_date = expiry_date[:2] + "/" + expiry_date[2:]

                    # Prepare new payment method entry
                    new_payment_method = {
                        "account_number": account_number,
                        "account_guid": account_guid,
                        "storage_safe_guid": storage_safe_guid,
                        "last_four": card_last_four,
                        "expiry_date": expiry_date,
                        "payment_method": account_brand
                    }

                    # Insert into payment_methods table
                    insert_id = billing_platform_db.insert_data([new_payment_method], "payment_methods")
                    logging.info(f"## payment_method_handler New payment method stored: {new_payment_method}")
                    return insert_id
                else:
                    # Log if the payment method already exists
                    logging.info("## payment_method_handler Payment method already exists, skipping insert.")
                    return False
        else:
            logging.info("## payment_method_handler Empty storage_safe_data")
            return False
    except Exception as e:
        logging.info(f"## payment_method_handler exception occured as {e}")
        return False

def convert_to_tenant_timezone(event_date, tenant_name, database):
    """
    Convert a given datetime object to the tenant's timezone.

    Parameters:
        event_date (datetime): The timestamp to be converted.
        tenant_name (str): The tenant identifier.
        database: Database connection object for fetching tenant timezone.

    Returns:
        datetime: Converted datetime object in tenant's timezone.
    """
    if not event_date or not tenant_name:
        logging.info("## convert_to_tenant_timezone: Invalid input parameters.")
        return event_date

    # Fetch tenant timezone from DB
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = database.execute_query(
        tenant_timezone_query, params=[tenant_name]
    )

    if tenant_timezone.empty or not tenant_timezone.iloc[0]['time_zone']:
        return event_date  # No timezone found, return as is

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']

    # Handle formats like: "(UTC+05:30) Asia/Kolkata"
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(\S+/\S+)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')
    logging.info(f"## convert_to_tenant_timezone: tenant_time_zone: {tenant_time_zone}")
    try:
        # Attach UTC if event_date is naive
        if event_date.tzinfo is None:
            logging.info(f"## convert_to_tenant_timezone: event_date is naive, attaching UTC: {event_date}")
            event_date = event_date.replace(tzinfo=pytz.UTC)
        # Convert to tenant's timezone
        return event_date.astimezone(pytz.timezone(tenant_time_zone))
    except Exception as e:
        logging.info(f"## convert_to_tenant_timezone: Error in timezone conversion. {e}")
        return event_date  # Fallback: return original


def webhook_response_handler(data):
    """
    Processes webhook transaction data received from a payment gateway (TRX), 
    updates billing platform database with payment and billing information, 
    manages customer account balances and ledgers, and triggers notification emails.

    Parameters
    ----------
    data : dict
        The webhook payload containing transaction results and reference information.
        Expected to have keys 'Result' and 'Reference' with transaction details.

    Returns
    -------
    dict
        A dictionary with:
        - 'flag': bool indicating if processing succeeded,
        - 'message': str providing success or error details.

    Overview
    --------
    The function performs these key operations:
    1. Extracts and parses the transaction data, including response code, reference IDs,
       payment amount, and transaction date/time.
    2. Determines payment status ("Success" or "Fail") based on response code.
    3. Retrieves related bill IDs and associated bill records.
    4. Fetches customer profile including account balance and contact info.
    5. For successful transactions:
       - Applies payment amount across bills, updating payments, remaining, and amount_due fields.
       - Updates the customer's account balance and amount due.
       - Creates ledger entries recording payment receipts.
       - Triggers a "Payment Successful" email notification (if enabled).
    6. For failed transactions:
       - Creates ledger entries recording payment failure.
       - Triggers a "Payment Failure" email notification (if enabled).
       - Does not modify bills or account balances.
    7. Saves all transaction history entries in the payment history table.
    8. Updates the transaction status in the database.
    9. Logs audit information regarding the webhook processing duration and details.
    """
    # function implementation here...

    logging.info("## webhook_response_handler function called")
    try:
        logging.info(f"## webhook_response_handler Received TRX transaction data: {data}")

        start_time = time.time()
        billing_platform_db = DB(os.environ['BILLING_PLATFORM'], **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
        database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

        # Extract key fields
        result = data.get('Result', {})
        reference_data = data.get('Reference', {})
        storage_safe_data = data.get("StorageSafe", {})

        response_code = result.get('ResponseCode')
        reference = reference_data.get('Guid', '')
        bill_id = reference_data.get('PurchaseId', '')
        card_last_four = reference_data.get('LastFour', '')
        tran_date = reference_data.get('TranDate')
        tran_time = reference_data.get('TranTime')
        account_brand = reference_data.get('AccountBrand', '')
        mail_payment_mode = 'Card Payment'
        if account_brand.lower() == 'ach':
            mail_payment_mode = 'ACH Payment'
            amount = None
        else:
            amount = float(result.get('ApprovedAmount', '0'))

        # Fetch CustomFields
        agent = ""
        custom_fields = data.get("CustomFields", [])
        for field in custom_fields:
            if isinstance(field, dict) and field.get("Id") == "UserDefinedAgent":
                agent = field.get("Value", "")
                break
        
        # Date parsing
        event_date = None
        if tran_date and tran_time:
            try:
                event_date = datetime.strptime(f"{tran_date} {tran_time}", "%m/%d/%Y %H:%M:%S")
                # Convert to tenant's timezone
                # event_date = convert_to_tenant_timezone(event_date, tenant_name, database)
            except Exception as e:
                logging.warning(f"## webhook_response_handler Failed to parse transaction datetime: {e}")

        status = "Success" if response_code == "00" else "Fail"
        batch_list_df = billing_platform_db.get_data("transaction_status", {"id": str(bill_id)}, ["bill_list","bill_amount"])
        if not batch_list_df.empty:
            bill_list = batch_list_df['bill_list'].tolist()[0]
            bill_list = ast.literal_eval(bill_list) if bill_list else []
            bill_amount = batch_list_df['bill_amount'].tolist()[0] if batch_list_df['bill_amount'].tolist()[0] else 0
        else:
            bill_amount = 0
            bill_list = []
        if not amount:
            amount = bill_amount
        bills_df = billing_platform_db.get_data('customer_bills', {'id': bill_list},
                                                 ["id", "payments", "total", "amount_due", 'remaining'],
                                                 {'created_date': 'asc'})
        if isinstance(bills_df, bool) or bills_df is None or bills_df.empty:
            bill_id_df = []
        else:
            bill_id_df = bills_df.to_dict(orient="records")

        account_number_df = billing_platform_db.get_data("customer_bills", {"id": bill_list[0]}, ["account_number"])
        account_number = str(account_number_df['account_number'].tolist()[0]) if not account_number_df.empty else ""

        # Handling of Payment method
        insert_id = payment_method_handler(storage_safe_data,account_number ,billing_platform_db ,reference_data , card_last_four , account_brand)
        # fetch customer info
        email, customer_name, tenant_name, tenant_id = '', '', '', None
        account_balance, account_amount_due = 0, 0
        if account_number:
            customer_profiles_df = billing_platform_db.get_data("customer_profiles", {"account_number": account_number},
                                                    ["sales_person", "email", "customer_name", "amount_due",
                                                     "tenant_name", "tenant_id", "account_balance"])
            if customer_profiles_df is not None and not customer_profiles_df.empty:
                email = customer_profiles_df['email'].tolist()[0]
                customer_name = customer_profiles_df['customer_name'].tolist()[0]
                account_amount_due = float(customer_profiles_df['amount_due'].tolist()[0])
                tenant_name = customer_profiles_df['tenant_name'].tolist()[0]
                tenant_id = customer_profiles_df['tenant_id'].tolist()[0]
                account_balance = float(customer_profiles_df['account_balance'].tolist()[0])

        transaction_history_rows = []

        if status == "Success":
            logging.info(f"## webhook_response_handler Transaction Success Case")
            # ----------------------------
            # SPLIT AMOUNT ACROSS BILLS
            # ----------------------------
            amount_paid = amount
            row_index = 0
            total_amount_due = 0
            total_bill_amount = 0
            while amount_paid > 0 and row_index < len(bill_id_df):
                bill_dict = bill_id_df[row_index]
                current_bill_id = bill_dict.get('id', '')
                payments = float(bill_dict.get('payments', 0))
                total = float(bill_dict.get('total', 0))
                amount_due = float(bill_dict.get('amount_due', 0))
                remaining = float(bill_dict.get('remaining', 0))
                total_bill_amount = total_bill_amount + total 

                if amount_paid >= remaining:
                    amount_for_invoice = remaining
                    payments += remaining
                    remaining = 0
                    amount_due = 0
                    amount_paid -= amount_for_invoice
                else:
                    amount_for_invoice = amount_paid
                    payments += amount_paid
                    remaining -= amount_paid
                    amount_due -= amount_paid
                    amount_paid = 0
                
                total_amount_due = total_amount_due + amount_due
                # update bill
                updated_data = {"payments": str(payments), "total": str(total),
                                "amount_due": str(amount_due), "remaining": str(remaining)}
                billing_platform_db.update_dict('customer_bills', updated_data, {"id": current_bill_id})

                # ledger entry
                ledger_description = f'''Payment Received - Thank you!
Amount Paid : {amount_for_invoice}  Date : {event_date.isoformat() if event_date else None}'''
                transaction_data = {
                    "ref": reference,
                    "status": 'Successful',
                    # "date": event_date.isoformat() if event_date else None,
                    "amount": str(amount_for_invoice),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent
                }
                transaction_history_rows.append(transaction_data)
                row_index += 1

            # update account profile
            account_balance -= amount
            account_amount_due -= amount
            update_account_balance_data = {"account_balance": round(account_balance, 2),
                                          "amount_due": round(account_amount_due, 2)}
            billing_platform_db.update_dict('customer_profiles', update_account_balance_data, {"account_number": account_number})

            if transaction_history_rows:
                for tx in transaction_history_rows:
                    tx["account_balance"] = round(account_balance, 2)

            # Email trigger for success
            active_status_query = database.get_data("email_templates", {"template_name": "Payment Successful"}, ["email_status"])
            active_status = active_status_query["email_status"].to_list()[0] if not active_status_query.empty else 'false'
            if str(active_status).strip().lower() == 'true':
                formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
                total_remaining = sum(float(item['remaining']) if 'remaining' in item else 0 for item in bill_id_df)
                # due_amount_is = total_remaining
                total_bill_amount = sum(float(item['total']) if 'total' in item else 0 for item in bill_id_df)
                due_amount_is = total_bill_amount - amount if total_bill_amount > amount else 0
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "total_amount": round(total_bill_amount, 2),
                    "amount_paid": round(amount, 2),
                    "due_amount": round(total_amount_due, 2),
                    "user_name": customer_name,
                    "receipt_link": "https://demo.amop.services/"
                }
                logging.info(f"## webhook_response_handler placeholders_dict: {placeholders_dict}")
                notification_result = send_email(
                    template_name='Payment Successful',
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Successful',
                    customer_name=customer_name,
                    account_number=account_number
                )
                try:
                    email_trigger_time = datetime.fromtimestamp(time.time())
                    logging.info(f'email_trigger_time---------{email_trigger_time}')
                    update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Successful"})
                    logging.info(f"## webhook_response_handler update_status: {update_status}")
                except Exception as e:
                    logging.error(f'## webhook_response_handler Error updating email trigger time: {e}')

        else:  
            logging.info(f"## webhook_response_handler Transaction Failed Case")
            # Mark all bills with zero payment changes, just add failure entry in payment history
            ledger_description = f'''Payment Failed
Amount : {amount}   Date: {event_date.isoformat() if event_date else None}'''
            for bill_dict in bill_id_df:
                current_bill_id = bill_dict.get('id', '')
                transaction_data = {
                    "ref": reference,
                    "status": 'Failed',
                    # "date": event_date.isoformat() if event_date else None,
                    "amount": str(amount),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent
                }
                transaction_history_rows.append(transaction_data)

            # No account balance or bills update on failure

            # Email trigger for failure
            active_status_query = database.get_data("email_templates", {"template_name": "Payment Failure"}, ["email_status"])
            active_status = active_status_query["email_status"].to_list()[0] if not active_status_query.empty else 'false'
            if str(active_status).strip().lower() == 'true':
                formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "amount_paid": amount,
                    "user_name": customer_name,
                    "due_amount": account_amount_due,
                }
                logging.info(f"## webhook_response_handler placeholders_dict: {placeholders_dict}")
                notification_result = send_email(
                    template_name="Payment Failure",
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Failed',
                    customer_name=customer_name,
                    account_number=account_number
                )
                try:
                    email_trigger_time = datetime.fromtimestamp(time.time())
                    logging.info(f'email_trigger_time---------{email_trigger_time}')
                    update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Failure"})
                    logging.info(f"## webhook_response_handler update_status: {update_status}")
                except Exception as e:
                    logging.error(f'## webhook_response_handler Error updating email trigger time: {e}')

        # insert payment history
        if transaction_history_rows:
            logging.info(f"## webhook_response_handler transaction_history_rows: {transaction_history_rows}")
            insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
            logging.info(f"## webhook_response_handler insert_status: {insert_status}")

        # update transaction status table
        payment_status_data = {'batch_status': status}
        if status == "Fail":
            payment_status_data['failed_data'] = str(result)
        billing_platform_db.update_dict('transaction_status', payment_status_data, {"id": str(bill_id)})

        # audit log
        audit_data_user_actions = {
            "service_name": "webhook_response_handler",
            "created_by": 'System',
            "status": 'Success',
            "time_consumed_secs": int(time.time() - start_time),
            "comments": json.dumps(data),
            "module_name": 'Payment History',
            "request_received_at": event_date.isoformat() if event_date else None
        }
        common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")

        return {'flag': True, 'message': 'Transaction processed successfully'}

    except Exception as e:
        message = 'Error occured in Webhook Handler'
        logging.error(f"## webhook_response_handler Error in webhook_response_handler: {e}")
        error_data = {
                "service_name": "webhook_response_handler",
                "error_message": message,
                "error_type": message,
                "users": 'System',
                "comments": json.dumps(data),
                "module_name": 'Payment History',
                "request_received_at": event_date.isoformat() if event_date else None,
                }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {'flag': False, 'message': message}

def webhook_response_handler_29_08_2025(data):
    logging.info("## webhook_response_handler function called")
    try:
        logging.info(f"## webhook_response_handler Received TRX transaction data: {data}")

        #start time
        start_time = time.time()

        billing_platform_db = DB(os.environ['BILLING_PLATFORM'], **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)

        # Extract key fields
        result = data.get('Result', {})
        reference_data = data.get('Reference', {})
        
        response_code = result.get('ResponseCode')
        reference = reference_data.get('Guid', '')
        bill_id = reference_data.get('PurchaseId', '')
        card_last_four = reference_data.get('LastFour', '')
        tran_date = reference_data.get('TranDate')
        tran_time = reference_data.get('TranTime')
        amount = result.get('ApprovedAmount', '0')

        # Date parsing
        event_date = None
        if tran_date and tran_time:
            try:
                event_date = datetime.strptime(f"{tran_date} {tran_time}", "%m/%d/%Y %H:%M:%S")
            except Exception as e:
                logging.warning(f"## webhook_response_handler Failed to parse transaction datetime: {e}")

        status = "Success" if response_code == "00" else "Fail"
        batch_list_df = billing_platform_db.get_data("transaction_status",{"id":str(bill_id)},["bill_list"])
        if not batch_list_df.empty:
            bill_list = batch_list_df['bill_list'].tolist()[0]
            bill_list = ast.literal_eval(bill_list) if bill_list else []
        else:
            bill_list = []
        account_number_df = billing_platform_db.get_data("customer_bills",{"id":bill_list[0]},["account_number"])
        if account_number_df is not None and not account_number_df.empty:
            account_number = str(account_number_df['account_number'].tolist()[0])
        status_message = "Successful" if response_code == "00" else "Failed"
        # ... other field extraction

        # Extract agent value from CustomFields
        agent = ""
        custom_fields = data.get("CustomFields", [])
        for field in custom_fields:
            if isinstance(field, dict) and field.get("Id") == "UserDefinedAgent":
                agent = field.get("Value", "")
                break

        transaction_record = {
            "ref": reference,
            "bill_id": bill_id,
            "method": card_last_four,
            "status": status_message,
            "date": event_date.isoformat() if event_date else None,
            "amount": amount,
            "batch_id": bill_id,
            "source": 'TRX',
            "account_number":account_number,
            "auth_code":"-",
            "agent": agent 
        }

        logging.info(f"## webhook_response_handler Storing transaction record: {transaction_record}")

        # Always update transaction status for batch
        payment_status_data = {'batch_status': status}
        if status == "Fail":
            payment_status_data['failed_data'] = str(result)
            transaction_record['failed_data'] = str(result)
        update_status = billing_platform_db.update_dict('transaction_status', payment_status_data, {"id": str(bill_id)})

        if update_status:
            logging.info("## webhook_response_handler Transaction record updated successfully.")
            insert_status = billing_platform_db.insert_data(transaction_record, 'payment_history')
            # insert_status = True
            if insert_status:
                logging.info("## webhook_response_handler Transaction record inserted successfully.")
                if status == "Fail":
                    # On failure, include Result dict for UI
                    return {
                        'flag': False,
                        'message': 'Transaction failed',
                        'result': result
                    }
                audit_data_user_actions = {
                    "service_name": "webhook_response_handler",
                    "created_by": 'System',
                    "status": 'Success',
                    "time_consumed_secs": int(time.time() - start_time),
                    "comments": json.dumps(data),
                    "module_name": 'Payment History',
                    "request_received_at": event_date.isoformat() if event_date else None
                    }
                common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")
                return {'flag': True, 'message': 'Transaction processed successfully'}
            else:
                message = 'Failed to insert Transaction Record'
                logging.error(f"## webhook_response_handler {message}")
                error_data = {
                    "service_name": "webhook_response_handler",
                    "error_message": message,
                    "error_type": message,
                    "users": 'System',
                    "comments": json.dumps(data),
                    "module_name": 'Payment History',
                    "request_received_at": event_date.isoformat() if event_date else None,
                    }
                common_utils_db.log_error_to_db(error_data, "error_log_table")
                return {'flag': False, 'message': message}
        else:
            message = 'Failed to update Transaction Status'
            logging.info(f"## webhook_response_handler {message}")
            error_data = {
                    "service_name": "webhook_response_handler",
                    "error_message": message,
                    "error_type": message,
                    "users": 'System',
                    "comments": json.dumps(data),
                    "module_name": 'Payment History',
                    "request_received_at": event_date.isoformat() if event_date else None,
                }
            common_utils_db.log_error_to_db(error_data, "error_log_table")
            return {'flag': False, 'message': message}

    except Exception as e:
        message = 'Error occured in Webhook Handler'
        logging.error(f"## webhook_response_handler Error in webhook_response_handler: {e}")
        error_data = {
                "service_name": "webhook_response_handler",
                "error_message": message,
                "error_type": message,
                "users": 'System',
                "comments": json.dumps(data),
                "module_name": 'Payment History',
                "request_received_at": event_date.isoformat() if event_date else None,
                }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {'flag': False, 'message': message}



def build_elements_backup(batch_id, customer_name, customer_email, country, city, postal_code, telephone_number, agent, payment_types,payment_method , account_number, billing_platform_db , state,address_line_1):
    """
    Build PayPage Elements dynamically.
    Add StorageSafe fields only for Credit.
    """
    elements = [
        {"Id": "IndustryDataPurchaseId", "Required": "1", "Value": str(batch_id), "Visible": "1"},
        {"Id": "IndustryDataIndustry", "Required": "1", "Value": "CardNotPresent", "Visible": "1"},
        {"Id": "IndustryDataEci", "Required": "1", "Value": "7", "Visible": "1"},
        {"Id": "AccountFirstName", "Required": "1", "Value": customer_name, "Label": "Customer Name", "Visible": "1"},
        {"Id": "UserDefinedAgent", "Required": "0", "Value": agent, "Label": "Agent", "Visible": "1"},
        {"Id": "ShippingEmail", "Required": "0", "Value": customer_email, "Visible": "1"},
        {"Id": "ShippingPhone", "Required": "0", "Value": telephone_number, "Visible": "1"},
        {
            "Id": "ShippingEmail",
            "Required": "1",
            "Label": "Email",
            "Value": customer_email,
            "Visible": "1"
        },
        {
            "Id": "ShippingAddress",
            "Required": "0",
            "Label": "Address",
            "Value": address_line_1,
            "Visible": "1"
        },
        {
            "Id": "ShippingAddress2",
            "Required": "0",
            "Label": "Address 2",
            "Value": "",
            "Visible": "1"
        },
        {
            "Id": "ShippingCity",
            "Required": "0",
            "Label": "City",
            "Value": city,
            "Visible": "1"
        },
        {
            "Id": "ShippingPostal",
            "Required": "0",
            "Label": "Postal Code",
            "Value": postal_code,
            "Visible": "1"
        },
        {
            "Id": "ShippingCountry",
            "Required": "0",
            "Label": "Country",
            "Value": country,
            "Visible": "1"
        },
        {
            "Id": "ShippingRegion",
            "Required": "0",
            "Label": "State",
            "Value": state,
            "Visible": "1"
        }
    ]


    # Add StorageSafe only if Credit payment is enabled
    # if payment_method.lower() == "card payment":
    #     elements.extend([
    #         {"Id": "StorageSafeAccountGuid", "Required": "1", "Value": 'EWH3HG2WG6NKD3W', "Visible": "0"},
    #         {"Id": "StorageSafeGenerate", "Required": "1", "Value": "1", "Visible": "0"},
    #         {"Id": "StorageSafeGuid", "Required": "1", "Value": 'EWH3HG2WG6QBX3B', "Visible": "0"},
    #     ])
    # else:
    #     logging.info(f"## build_elements Payment method is not Credit: {payment_method}")
    #     elements.extend([
    #         {"Id": "StorageSafeAccountGuid", "Required": "0", "Value": 'EW6TWX5VG628030', "Visible": "0"},
    #         {"Id": "StorageSafeGenerate", "Required": "1", "Value": "0", "Visible": "0"},
    #         {"Id": "StorageSafeGuid", "Required": "0", "Value": '', "Visible": "0"},
    #     ])
    payment_method_df = billing_platform_db.get_data(
            "payment_methods",
            {"account_number": str(account_number), "default_payment": True},
            ["account_guid", "storage_safe_guid"]
        )
    if payment_method_df is not None and not payment_method_df.empty:
        row = payment_method_df.iloc[0]
        account_guid = str(row["account_guid"])
        storage_safe_guid = str(row["storage_safe_guid"])

        elements.extend([
            {
                "Id": "StorageSafeGenerate",
                "Required": "1",
                "Value": "0",  # don’t generate since we already have saved one
                "Visible": "0"
            },
            {
                "Id": "StorageSafeGuid",
                "Required": "1",
                "Value": storage_safe_guid,
                "Visible": "0"
            },
            {
                "Id": "StorageSafeAccountGuid",
                "Required": "1",
                "Value": account_guid,
                "Visible": "0"
            }
        ])
    else:
        # No saved payment method → use empty placeholders
        elements.extend([
            {
                "Id": "StorageSafeGenerate",
                "Required": "1",
                "Value": "1",  # generate new
                "Visible": "0"
            },
            {
                "Id": "StorageSafeGuid",
                "Required": "0",
                "Value": "",
                "Visible": "0"
            },
            {
                "Id": "StorageSafeAccountGuid",
                "Required": "0",
                "Value": "",
                "Visible": "0"
            }
        ])
    return {"Element": elements}


def build_elements(batch_id, customer_name, customer_email, country, city, postal_code, telephone_number, agent, payment_types,payment_method , account_number, billing_platform_db,state , address_line_1):
    """
    Build PayPage Elements dynamically.
    Add StorageSafe fields only for Credit.
    """
    elements = [
        {"Id": "IndustryDataPurchaseId", "Required": "1", "Value": str(batch_id), "Visible": "1"},
        {"Id": "IndustryDataIndustry", "Required": "1", "Value": "CardNotPresent", "Visible": "1"},
        {"Id": "IndustryDataEci", "Required": "1", "Value": "7", "Visible": "1"},
        {"Id": "AccountFirstName", "Required": "1", "Value": customer_name, "Label": "Customer Name", "Visible": "1"},
        # {"Id": "AccountFirstName", "Required": "0", "Value": "", "Visible": "1"},
        # {"Id": "AccountLastName", "Required": "0", "Value": "", "Visible": "1"},
        {"Id": "UserDefinedAgent", "Required": "0", "Value": agent, "Label": "Agent", "Visible": "1"},
        {"Id": "ShippingEmail", "Required": "0", "Value": customer_email, "Visible": "1"},
        {"Id": "ShippingCountry", "Required": "1", "Value": country, "Visible": "1"},
        {"Id": "ShippingCity", "Required": "0", "Value": city, "Visible": "1"},
        {"Id": "ShippingPostal", "Required": "1", "Value": postal_code, "Visible": "1"},
        {"Id": "ShippingFirstName", "Required": "1", "Value": "", "Label": "First Name", "Visible": "1"},
        {"Id": "ShippingLastName", "Required": "1", "Value": "", "Label": "Last Name", "Visible": "1"},
        {"Id": "ShippingPhone", "Required": "0", "Value": telephone_number, "Visible": "1"},
        # {
        # "Id": "ShippingEmail",
        # "Required": "1",
        # "Label": "Email",
        # "Value": customer_email,
        # "Visible": "1"
        # },
        {
        "Id": "ShippingAddress",
        "Required": "0",
        "Label": "Address",
        "Value": address_line_1,
        "Visible": "1"
        },
        {
        "Id": "ShippingAddress2",
        "Required": "0",
        "Label": "Address 2",
        "Value": "",
        "Visible": "1"
        },
        # {
        # "Id": "ShippingCity",
        # "Required": "0",
        # "Label": "City",
        # "Value": "",
        # "Visible": "1"
        # },
        {
        "Id": "ShippingRegion",
        "Required": "1",
        "Label": "State",
        "Value": state,
        "Visible": "1"
        },
        # {
        # "Id": "ShippingPostal",
        # "Required": "0",
        # "Label": "Postal Code",
        # "Value": "",
        # "Visible": "1"
        # },
        # {
        # "Id": "ShippingCountry",
        # "Required": "0",
        # "Label": "Country",
        # "Value": "",
        # "Visible": "1"
        # }

    ]

    # Add StorageSafe only if Credit payment is enabled
    # if payment_method.lower() == "card payment":
    #     elements.extend([
    #         {"Id": "StorageSafeAccountGuid", "Required": "1", "Value": 'EWH3HG2WG6NKD3W', "Visible": "0"},
    #         {"Id": "StorageSafeGenerate", "Required": "1", "Value": "1", "Visible": "0"},
    #         {"Id": "StorageSafeGuid", "Required": "1", "Value": 'EWH3HG2WG6QBX3B', "Visible": "0"},
    #     ])
    # else:
    #     logging.info(f"## build_elements Payment method is not Credit: {payment_method}")
    #     elements.extend([
    #         {"Id": "StorageSafeAccountGuid", "Required": "0", "Value": 'EW6TWX5VG628030', "Visible": "0"},
    #         {"Id": "StorageSafeGenerate", "Required": "1", "Value": "0", "Visible": "0"},
    #         {"Id": "StorageSafeGuid", "Required": "0", "Value": '', "Visible": "0"},
    #     ])
    
    payment_method_df = billing_platform_db.get_data(
            "payment_methods",
            {"account_number": str(account_number), "default_payment": True},
            ["account_guid", "storage_safe_guid"]
        )
    if payment_method_df is not None and not payment_method_df.empty:
        row = payment_method_df.iloc[0]
        account_guid = str(row["account_guid"])
        storage_safe_guid = str(row["storage_safe_guid"])

        elements.extend([
            {
                "Id": "StorageSafeGenerate",
                "Required": "1",
                "Value": "0",  # don’t generate since we already have saved one
                "Visible": "0"
            },
            {
                "Id": "StorageSafeGuid",
                "Required": "1",
                "Value": storage_safe_guid,
                "Visible": "0"
            },
            {
                "Id": "StorageSafeAccountGuid",
                "Required": "1",
                "Value": account_guid,
                "Visible": "0"
            }
        ])
    else:
        # No saved payment method → use empty placeholders
        elements.extend([
            {
                "Id": "StorageSafeGenerate",
                "Required": "1",
                "Value": "1",  # generate new
                "Visible": "0"
            },
            {
                "Id": "StorageSafeGuid",
                "Required": "0",
                "Value": "",
                "Visible": "0"
            },
            {
                "Id": "StorageSafeAccountGuid",
                "Required": "0",
                "Value": "",
                "Visible": "0"
            }
        ])
    return {"Element": elements}

def get_payment_token(data):
    """
    Sends Initialize PayPage request to TRX and returns payment URL.
    """
    logging.info(f'## get_payment_token called with data {data}')
    start_time = time.time()

    # Variables
    tenant_name = data.get("tenant_name")
    created_by = data.get("firstLastName", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("sessionID", "")
    module_name = data.get("module_name", "Payment History")

    merchant_key = os.environ.get("merchant_key", "")
    merchant_secret = os.environ.get("merchant_secret", "")
    payment_trigger_url = os.environ.get("payment_trigger_url", "")
    response_url = os.environ.get("response_url", "")
    approval_url = os.environ.get("approval_url", "")
    rejected_url = os.environ.get("rejected_url", "")
    post_url = os.environ.get("post_url", "")
    guid = os.environ.get("Guid", "")


    invoice_id = str(data.get("bill_id", ""))
    amount_from_invoice = data.get("item_amount", "")
    account_number = data.get("account_number", "")
    agent = data.get("agent", "")
    payment_method = data.get('payment_method','Card Payment')

    # Amount validation
    if float(amount_from_invoice) <= 0:
        return {"flag": False, "message": "Amount is Invalid"}

    # DB connections
    billing_platform_db = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)

    # Insert batch
    # batch_data = {"batch_status": "Pending", "bill_list": invoice_id}
    batch_data = {"batch_status": "Pending", "bill_list": invoice_id, "bill_amount": amount_from_invoice ,"payment_type":payment_method}
    batch_id = billing_platform_db.insert_data(batch_data, "transaction_status")

    # Customer lookup
    customer_profiles_df = billing_platform_db.get_data(
        "customer_profiles",
        {"account_number": str(account_number)},
        ["email", "customer_name", "country", "city", "postal_code", "telephone_number", "sales_person","state" , "address_line_1"],
    )
    customer_name = customer_email = city = country = postal_code = telephone_number = sales_person = state = address_line_1 = ""

    if customer_profiles_df is not None and not customer_profiles_df.empty:
        row = customer_profiles_df.iloc[0]
        customer_name = str(row["customer_name"])
        customer_email = str(row["email"])
        country = str(row["country"])
        city = str(row["city"])
        postal_code = str(row["postal_code"])
        telephone_number = str(row["telephone_number"])
        sales_person = str(row["sales_person"])
        state = str(row["state"])
        address_line_1 = str(row["address_line_1"])

    if not agent and sales_person:
        agent = sales_person
    
    # Payment Types (default = Credit + ACH + Finance)
    payment_types = data.get("payment_types", [
        {"TranType": "Ach"},
        {"TranType": "Finance"},
        # {"TranType": "Credit", "CardType": ["Visa", "MasterCard", "Amex", "Discover"], "GooglePay": "0", "ApplePay": "1"}
        {"TranType": "Credit", "CardType": ["Visa", "MasterCard", "Amex", "Discover"]}
    ])

    # Build payload
    payload = {
        "Message": {
            "Request": {
                "PayPage": {
                    "Guid": guid,
                    "Session": {
                        "TimeToLive": 10,
                        "Style": {
                            "bodyBg": "#FFFFFF",  # White main background
                            "mainColor": "#2563EB",  # Primary Blue (Pay Now button)
                            "titleColor": "#111827",  # Dark gray text
                            "subTitleColor": "#6B7280",  # Muted gray
                            "formBg": "#F9FAFB",  # Light gray for input boxes
                            "formBorder": "#E5E7EB",
                            "buttonPrimaryBg": "#2563EB",  # Blue button
                            "buttonPrimaryColor": "#FFFFFF",
                            "buttonPrimaryHoverBg": "#1D4ED8",
                            "buttonPrimaryHoverColor": "#FFFFFF",
                            "buttonSecondaryBg": "#F3F4F6",  # Light gray secondary button
                            "buttonSecondaryColor": "#374151",
                            "buttonSecondaryHoverBg": "#E5E7EB",
                            "buttonSecondaryHoverColor": "#111827",
                            "billingBg": "#FFFFFF",
                            "billingMainColor": "#2563EB"
                            },
                        "Elements": build_elements(batch_id, customer_name, customer_email, country, city, postal_code, telephone_number, agent, payment_types,payment_method ,account_number,billing_platform_db , state,address_line_1),
                        # "SoftDescriptors": {
                        #     "MerchantPhone": "1-800-123-4567",
                        #     "MerchantName": "Test Store",
                        #     "MerchantState": "NY"
                        # },
                        "Detail": {
                            "Amount": amount_from_invoice,
                            "TranAction": "Sale",
                            "CurrencyCode": "840"
                        },
                        "Processing": {
                            "Verbose": "1",
                            "EnableShipping": "1",
                            "EnableBilling": "1",
                            "EnableBillingSummary": "1",
                            "EnableSectionHeaders": "0",
                            "ResponseUrl": response_url,
                            "ApprovalUrl": approval_url,
                            "RejectedUrl": rejected_url
                        },
                        "PaymentTypes": {"PaymentType": payment_types},
                        "Locale": "en-US"
                    }
                },
                "Detail": {"TranType": "PayPage", "TranAction": "Initialize"}
            }
        }
    }
    logging.info(f'## get_payment_token TRX Request Payload {json.dumps(payload)}')

    try:
        response = requests.post(
            post_url,
            json=payload,
            auth=(merchant_key, merchant_secret),
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        response.raise_for_status()
    except requests.RequestException as e:
        logging.error(f'## get_payment_token TRX Request Error {e}')
        failed_data = {"batch_id": batch_id, "error_text": str(e)}
        error_data = {
            "service_name": "get_payment_token",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "token": f"Request error: {str(e)}"}

    # Parse response
    try:
        res_json = response.json()
        logging.info(f'## get_payment_token TRX Response {res_json}')
        result_code = res_json["Message"]["Response"]["Result"]["ResponseCode"]

        if result_code == "00":
            guid = res_json["Message"]["Response"]["PayPage"]["Guid"]
            session = res_json["Message"]["Response"]["PayPage"]["Session"]
            payment_url = f"{payment_trigger_url}/?clientId=1053&paypage={guid}&session={session}"
            logging.info(f'## get_payment_token TRX Payment URL {payment_url}')
            token_data = {"token": payment_url, "batch_id": batch_id}
            audit_data_user_actions = {
                "service_name": "get_payment_token",
                "created_by": created_by,
                "status": "Success",
                "time_consumed_secs": int(time.time() - start_time),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(token_data),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")
            return {"flag": True, "token": payment_url, "batch_id": batch_id}

        # TRX returned error
        error_text = res_json["Message"]["Response"]["Result"].get("ResponseText", "Unknown error")
        logging.error(f'##  get_payment_token TRX Error {error_text}')
        failed_data = {"batch_id": batch_id, "error_response": res_json}
        error_data = {
            "service_name": "get_payment_token",
            "error_message": error_text,
            "error_type": str(type(error_text).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "token": f"TRX error: {error_text}"}

    except (KeyError, TypeError, ValueError) as e:
        logging.error(f'## get_payment_token TRX Parse Error {e}')
        failed_data = {"batch_id": batch_id}
        error_data = {
            "service_name": "get_payment_token",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "token": "Invalid response format"}

def get_payment_token_2(data):
    """
    Sends Initialize PayPage request to TRX and returns payment URL.

    Args:
        order (dict): Dictionary containing order and customer info:
        EX:
            {
                "id": "4651",
                "amount": 1.85,
                "firstName": "Srikanth Rekkala",
                "email": "test@mail.com"
            }
        merchant_key (str): TRX merchant API key/username
        merchant_secret (str): TRX merchant API secret/password

    Returns:
        dict: {
            "flag": True if success,
            "token": payment_url string
        }
    """
    logging.info(f'## get_payment_token function called with data {data}')

    #start time
    start_time = time.time()

    # Variable declaration
    tenant_name = data.get("tenant_name")
    created_by = data.get("firstLastName", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("sessionID", "")
    module_name = data.get('module_name','Payment History')
    merchant_key = os.environ.get('merchant_key', '')
    merchant_secret = os.environ.get('merchant_secret', '')
    Guid = os.environ.get('Guid', '')
    invoice_id=data.get('bill_id',[])
    invoice_id=str(invoice_id)
    response_url = os.environ.get('response_url', '')
    approval_url = os.environ.get('approval_url', '')
    rejected_url = os.environ.get('rejected_url', '')
    payment_trigger_url = os.environ.get('payment_trigger_url', '')
    amount_from_invoice = data.get('item_amount','')
    account_number = data.get('account_number', '')
    agent = data.get('agent','')

    #Amount Validation
    if float(amount_from_invoice)<=0:
        response = {
            "flag": False,
            "message": "Amount is Invalid"
        }
        return response
    
    #DB Connections 
    billing_platform_db = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)

    # Batch Id generation to track the transaction status
    batch_data={'batch_status':'Pending','bill_list':invoice_id}
    batch_id = billing_platform_db.insert_data(batch_data, 'transaction_status')
    
    customer_profiles_df = billing_platform_db.get_data("customer_profiles",{"account_number":str(account_number)},["email","customer_name","country","city","postal_code","telephone_number","sales_person"])
    customer_name = ''
    customer_email = ''
    city = ''
    country = ''
    postal_code = ''
    telephone_number = ''
    sales_person = ''
    # Customer Profiles Data
    if customer_profiles_df is not None and not customer_profiles_df.empty:
        customer_name = str(customer_profiles_df['customer_name'].tolist()[0])
        customer_email = str(customer_profiles_df['email'].tolist()[0])
        country = str(customer_profiles_df['country'].tolist()[0])
        city = str(customer_profiles_df['city'].tolist()[0])
        postal_code = str(customer_profiles_df['postal_code'].tolist()[0])
        telephone_number = str(customer_profiles_df['telephone_number'].tolist()[0])
        sales_person = str(customer_profiles_df['sales_person'].tolist()[0])

    if not agent:
        if sales_person:
            agent = sales_person
    
    # Form Payload
    payload = {
        "Message": {
            "Request": {
                "PayPage": {
                    "Guid": 'EW6PPD83G2D3Y01',
                    "Session": {
                        "TimeToLive": 10,
                        "Style":  {
                            "bodyBg": "#FFFFFF",  # White main background
                            "mainColor": "#2563EB",  # Primary Blue (Pay Now button)
                            "titleColor": "#111827",  # Dark gray text
                            "subTitleColor": "#6B7280",  # Muted gray
                            "formBg": "#F9FAFB",  # Light gray for input boxes
                            "formBorder": "#E5E7EB",
                            "buttonPrimaryBg": "#2563EB",  # Blue button
                            "buttonPrimaryColor": "#FFFFFF",
                            "buttonPrimaryHoverBg": "#1D4ED8",
                            "buttonPrimaryHoverColor": "#FFFFFF",
                            "buttonSecondaryBg": "#F3F4F6",  # Light gray secondary button
                            "buttonSecondaryColor": "#374151",
                            "buttonSecondaryHoverBg": "#E5E7EB",
                            "buttonSecondaryHoverColor": "#111827",
                            "billingBg": "#FFFFFF",
                            "billingMainColor": "#2563EB"
                        },
                        # {
                        #     "bodyBg":"#FAF8F5",
                        #     "mainColor":"#8B572A",
                        #     "titleColor":"#4A4A4A",
                        #     "subTitleColor":"#9D9D9D",
                        #     "labelRadioColor":"#7B7B7B",
                        #     "paymentMethodHeaderColor":"#8B572A",
                        #     "paymentMethodMainColor":"#D8A56D",
                        #     "logoBorderColor":"#BCAAA4",
                        #     "formBg":"#FFFFFF",
                        #     "formBorder":"#EDE6E1",
                        #     "formLabelColor":"#8B572A",
                        #     "formColor":"#4A4A4A",
                        #     "formPlaceholderColor":"#BCAAA4",
                        #     "formBorderActive":"#D8A56D",
                        #     "formFocusVisibleColor":"#FAD7A0",
                        #     "formErrorColor":"#E74C3C",
                        #     "buttonPrimaryBg":"#8B572A",
                        #     "buttonPrimaryColor":"#FFFFFF",
                        #     "buttonPrimaryHoverBg":"#A2673D",
                        #     "buttonPrimaryHoverColor":"#FFFFFF",
                        #     "buttonPrimaryActiveBg":"#6D4A2A",
                        #     "buttonPrimaryActiveColor":"#FFFFFF",
                        #     "buttonPrimaryDisableBg":"#EDE6E1",
                        #     "buttonPrimaryDisableColor":"#9D9D9D",
                        #     "buttonPrimaryFocusVisibleColor":"#D8A56D",
                        #     "buttonSecondaryBg":"#FAF8F5",
                        #     "buttonSecondaryColor":"#8B572A",
                        #     "buttonSecondaryHoverBg":"#FAD7A0",
                        #     "buttonSecondaryHoverColor":"#8B572A",
                        #     "buttonSecondaryActiveBg":"#BCAAA4",
                        #     "buttonSecondaryActiveColor":"#8B572A",
                        #     "buttonSecondaryDisableBg":"#EDE6E1",
                        #     "buttonSecondaryDisableColor":"#BCAAA4",
                        #     "buttonSecondaryFocusVisibleColor":"#D8A56D",
                        #     "billingBg":"#FAF8F5",
                        #     "billingMainColor":"#8B572A",
                        #     "billingSecondColor":"#A2673D",
                        #     "billingBorderColor":"#D8A56D",
                        #     "billingBorderTotalColor":"#BCAAA4",
                        #     "payWithAccountOnFileLabel": "Account on file",
                        #     "payWithAchLabel": "ACH or electronic check"
                        # },
                        "Elements": {
                            "Element": [
                                {"Id": "IndustryDataPurchaseId", "Required": "1", "Value": str(batch_id), "Visible": "1"},
                                {"Id": "IndustryDataIndustry", "Required": "1", "Value": "CardNotPresent", "Visible": "1"},
                                {"Id": "IndustryDataEci", "Required": "1", "Value": "7", "Visible": "1"},
                                {"Id": "AccountFirstName", "Required": "1", "Value": customer_name,"Label":"Customer Name", "Visible": "1"},
                                {"Id": "UserDefinedAgent", "Required": "0", "Value": agent,"Label":"Agent", "Visible": "1"},
                                # {"Id": "AccountEmail", "Required": "1", "Value": customer_email, "Visible": "1"},
                                # {"Id": "AccountCity", "Required": "0", "Value": 'HYD', "Visible": "1"}
                                {
                                    "Id":"ShippingEmail",
                                    "Required":"0",
                                    "Label":"",
                                    "Value":customer_email,
                                    "Visible":"1"
                                },
                                {
                                    "Id":"ShippingCountry",
                                    "Required":"0",
                                    "Label":"",
                                    "Value":country,
                                    "Visible":"1"
                                },
                                {
                                    "Id":"ShippingCity",
                                    "Required":"0",
                                    "Label":"",
                                    "Value":city,
                                    "Visible":"1"
                                },
                                {
                                    "Id":"ShippingPostal",
                                    "Required":"0",
                                    "Label":"",
                                    "Value":postal_code,
                                    "Visible":"1"
                                },
                                {
                                    "Id":"ShippingPhone",
                                    "Required":"0",
                                    "Label":"",
                                    "Value":telephone_number,
                                    "Visible":"1"
                                },
                                {"Id": "StorageSafeAccountGuid", "Required": "0", "Value": 'EW6TWX5VG628030', "Visible": "1"},
                                {"Id": "StorageSafeGenerate", "Required": "1", "Value": "1", "Visible": "1"},
                                {"Id": "StorageSafeGuid", "Required": "0", "Value": 'EW6TW6MLG58FW2D', "Visible": "1"},
                            ]
                        },
                        "SoftDescriptors": {
                            "MerchantPhone": "1-800-123-4567",
                            "MerchantName": "Test Store",
                            "MerchantState": "NY"
                        },
                        "Detail": {
                            "Amount": amount_from_invoice,
                            "TranAction": "Sale",
                            "CurrencyCode": "840"
                        },
                        "Processing": {
                            "Verbose": "1",
                            "EnableShipping":"1",
                            "EnableBilling":"1",
                            "EnableBillingSummary":"1",
                            "EnableSectionHeaders":"0",
                            "ResponseUrl": response_url,
                            "ApprovalUrl": approval_url,
                            "RejectedUrl": rejected_url
                        },
                        "PaymentTypes": {
                            # "PaymentType": [
                            #     {"TranType": "Ach"},
                            #     {"TranType": "Credit", "CardType": ["Visa", "MasterCard"]}
                            # ]
                           "PaymentType": [
                                {
                                    "TranType":"Ach"
                                },
                                {
                                    "TranType":"Finance"
                                },
                                {
                                    "TranType":"Credit",
                                    "CardType":[
                                    "Visa",
                                    "MasterCard",
                                    "Amex",
                                    "Discover"
                                    ],
                                    "GooglePay":"0",
                                    "ApplePay":"1"
                                }
                            ]
                        },
                        "Locale": "en-US"
                    }
                },
                "Detail": {
                    "TranType": "PayPage",
                    "TranAction": "Initialize"
                }
            }
        }
    }
    logging.info(f'## get_payment_token TRX Request Payload {payload}')
    # TRX API endpoint
    post_url = os.environ.get('post_url', '')

    try:
        # Make the POST request with Basic Auth
        response = requests.post(
            post_url,
            json=payload,
            auth=(merchant_key, merchant_secret),
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        response.raise_for_status()
    except requests.RequestException as e:
        logging.info(f'## get_payment_token TRX Request Error {e}')
        failed_data = {"batch_id":batch_id,"error_text":f'{str(e)}'}
        error_data = {
        "service_name": "get_payment_token",
        "error_message": str(e),
        "error_type": str(type(e).__name__),
        "users": created_by,
        "session_id": session_id,
        "tenant_name": tenant_name,
        "comments": json.dumps(failed_data),
        "module_name": module_name,
        "request_received_at": request_received_at,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "token": f"Request error: {str(e)}"}

    # Parse JSON response
    res_json = response.json()
    try:
        logging.info(f'## get_payment_token TRX Response {res_json}')
        result_code = res_json["Message"]["Response"]["Result"]["ResponseCode"]
        if result_code == "00":
            guid = res_json["Message"]["Response"]["PayPage"]["Guid"]
            session = res_json["Message"]["Response"]["PayPage"]["Session"]
            # Construct payment URL
            payment_url = f"{payment_trigger_url}/?clientId=1053&paypage={guid}&session={session}"
            # payment_url = f"https://pay.trxservices.net/?clientId=1053&paypage={guid}&session={session}"
            token_data = {"token": payment_url, "batch_id": batch_id}
            audit_data_user_actions = {
            "service_name": "get_payment_token",
            "created_by": created_by,
            "status": 'Success',
            "time_consumed_secs": int(time.time() - start_time),
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(token_data),
            "module_name": module_name,
            "request_received_at": request_received_at
            }
            common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")
            return {"flag": True, "token": payment_url, "batch_id": batch_id}
        else:
            error_text = res_json["Message"]["Response"]["Result"].get("ResponseText", "Unknown error")
            logging.info(f'## get_payment_token TRX Error {error_text}')
            failed_data = {"batch_id":batch_id,"error_response":res_json}
            error_data = {
            "service_name": "get_payment_token",
            "error_message": str(error_text),
            "error_type": str(type(error_text).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
            }
            common_utils_db.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "token": f"TRX error: {error_text}"}
    except (KeyError, TypeError) as e:
        logging.info(f'## get_payment_token Error occured as {e}')
        failed_data = {"batch_id":batch_id}
        error_data = {
            "service_name": "get_payment_token",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
            }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "token": "Invalid response format"}



def get_payment_token_29_08_2025(data):
    """
    Sends Initialize PayPage request to TRX and returns payment URL.

    Args:
        order (dict): Dictionary containing order and customer info:
        EX:
            {
                "id": "4651",
                "amount": 1.85,
                "firstName": "Srikanth Rekkala",
                "email": "test@mail.com"
            }
        merchant_key (str): TRX merchant API key/username
        merchant_secret (str): TRX merchant API secret/password

    Returns:
        dict: {
            "flag": True if success,
            "token": payment_url string
        }
    """
    logging.info(f'## get_payment_token function called with data {data}')

    #start time
    start_time = time.time()

    # Variable declaration
    tenant_name = data.get("tenant_name")
    created_by = data.get("firstLastName", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("sessionID", "")
    module_name = data.get('module_name','Payment History')
    merchant_key = os.environ.get('merchant_key', '')
    merchant_secret = os.environ.get('merchant_secret', '')
    Guid = os.environ.get('Guid', '')
    invoice_id=data.get('bill_id',[])
    invoice_id=str(invoice_id)
    response_url = os.environ.get('response_url', '')
    approval_url = os.environ.get('approval_url', '')
    rejected_url = os.environ.get('rejected_url', '')
    payment_trigger_url = os.environ.get('payment_trigger_url', '')
    amount_from_invoice = data.get('item_amount','')
    account_number = data.get('account_number', '')
    agent = data.get('agent','')

    #Amount Validation
    if float(amount_from_invoice)<=0:
        response = {
            "flag": False,
            "message": "Amount is Invalid"
        }
        return response
    
    #DB Connections 
    billing_platform_db = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)

    # Batch Id generation to track the transaction status
    batch_data={'batch_status':'Pending','bill_list':invoice_id}
    batch_id = billing_platform_db.insert_data(batch_data, 'transaction_status')
    
    customer_profiles_df = billing_platform_db.get_data("customer_profiles",{"account_number":str(account_number)},["email","customer_name","country","city","postal_code","telephone_number","sales_person"])
    customer_name = ''
    customer_email = ''
    city = ''
    country = ''
    postal_code = ''
    telephone_number = ''
    sales_person = ''
    # Customer Profiles Data
    if customer_profiles_df is not None and not customer_profiles_df.empty:
        customer_name = str(customer_profiles_df['customer_name'].tolist()[0])
        customer_email = str(customer_profiles_df['email'].tolist()[0])
        country = str(customer_profiles_df['country'].tolist()[0])
        city = str(customer_profiles_df['city'].tolist()[0])
        postal_code = str(customer_profiles_df['postal_code'].tolist()[0])
        telephone_number = str(customer_profiles_df['telephone_number'].tolist()[0])
        sales_person = str(customer_profiles_df['sales_person'].tolist()[0])

    if not agent:
        if sales_person:
            agent = sales_person
    
    # Form Payload
    payload = {
        "Message": {
            "Request": {
                "PayPage": {
                    "Guid": 'EW6PPD83G2D3Y01',
                    "Session": {
                        "TimeToLive": 10,
                        "Style":  {
                            "bodyBg": "#FFFFFF",  # White main background
                            "mainColor": "#2563EB",  # Primary Blue (Pay Now button)
                            "titleColor": "#111827",  # Dark gray text
                            "subTitleColor": "#6B7280",  # Muted gray
                            "formBg": "#F9FAFB",  # Light gray for input boxes
                            "formBorder": "#E5E7EB",
                            "buttonPrimaryBg": "#2563EB",  # Blue button
                            "buttonPrimaryColor": "#FFFFFF",
                            "buttonPrimaryHoverBg": "#1D4ED8",
                            "buttonPrimaryHoverColor": "#FFFFFF",
                            "buttonSecondaryBg": "#F3F4F6",  # Light gray secondary button
                            "buttonSecondaryColor": "#374151",
                            "buttonSecondaryHoverBg": "#E5E7EB",
                            "buttonSecondaryHoverColor": "#111827",
                            "billingBg": "#FFFFFF",
                            "billingMainColor": "#2563EB"
                        },
                        # {
                        #     "bodyBg":"#FAF8F5",
                        #     "mainColor":"#8B572A",
                        #     "titleColor":"#4A4A4A",
                        #     "subTitleColor":"#9D9D9D",
                        #     "labelRadioColor":"#7B7B7B",
                        #     "paymentMethodHeaderColor":"#8B572A",
                        #     "paymentMethodMainColor":"#D8A56D",
                        #     "logoBorderColor":"#BCAAA4",
                        #     "formBg":"#FFFFFF",
                        #     "formBorder":"#EDE6E1",
                        #     "formLabelColor":"#8B572A",
                        #     "formColor":"#4A4A4A",
                        #     "formPlaceholderColor":"#BCAAA4",
                        #     "formBorderActive":"#D8A56D",
                        #     "formFocusVisibleColor":"#FAD7A0",
                        #     "formErrorColor":"#E74C3C",
                        #     "buttonPrimaryBg":"#8B572A",
                        #     "buttonPrimaryColor":"#FFFFFF",
                        #     "buttonPrimaryHoverBg":"#A2673D",
                        #     "buttonPrimaryHoverColor":"#FFFFFF",
                        #     "buttonPrimaryActiveBg":"#6D4A2A",
                        #     "buttonPrimaryActiveColor":"#FFFFFF",
                        #     "buttonPrimaryDisableBg":"#EDE6E1",
                        #     "buttonPrimaryDisableColor":"#9D9D9D",
                        #     "buttonPrimaryFocusVisibleColor":"#D8A56D",
                        #     "buttonSecondaryBg":"#FAF8F5",
                        #     "buttonSecondaryColor":"#8B572A",
                        #     "buttonSecondaryHoverBg":"#FAD7A0",
                        #     "buttonSecondaryHoverColor":"#8B572A",
                        #     "buttonSecondaryActiveBg":"#BCAAA4",
                        #     "buttonSecondaryActiveColor":"#8B572A",
                        #     "buttonSecondaryDisableBg":"#EDE6E1",
                        #     "buttonSecondaryDisableColor":"#BCAAA4",
                        #     "buttonSecondaryFocusVisibleColor":"#D8A56D",
                        #     "billingBg":"#FAF8F5",
                        #     "billingMainColor":"#8B572A",
                        #     "billingSecondColor":"#A2673D",
                        #     "billingBorderColor":"#D8A56D",
                        #     "billingBorderTotalColor":"#BCAAA4",
                        #     "payWithAccountOnFileLabel": "Account on file",
                        #     "payWithAchLabel": "ACH or electronic check"
                        # },
                        "Elements": {
                            "Element": [
                                {"Id": "IndustryDataPurchaseId", "Required": "1", "Value": str(batch_id), "Visible": "1"},
                                {"Id": "IndustryDataIndustry", "Required": "1", "Value": "CardNotPresent", "Visible": "1"},
                                {"Id": "IndustryDataEci", "Required": "1", "Value": "7", "Visible": "1"},
                                {"Id": "AccountFirstName", "Required": "1", "Value": customer_name,"Label":"Customer Name", "Visible": "1"},
                                {"Id": "UserDefinedAgent", "Required": "0", "Value": agent,"Label":"Agent", "Visible": "1"},
                                # {"Id": "AccountEmail", "Required": "1", "Value": customer_email, "Visible": "1"},
                                # {"Id": "AccountCity", "Required": "0", "Value": 'HYD', "Visible": "1"}
                                {
                                    "Id":"ShippingEmail",
                                    "Required":"0",
                                    "Label":"",
                                    "Value":customer_email,
                                    "Visible":"1"
                                },
                                {
                                    "Id":"ShippingCountry",
                                    "Required":"0",
                                    "Label":"",
                                    "Value":country,
                                    "Visible":"1"
                                },
                                {
                                    "Id":"ShippingCity",
                                    "Required":"0",
                                    "Label":"",
                                    "Value":city,
                                    "Visible":"1"
                                },
                                {
                                    "Id":"ShippingPostal",
                                    "Required":"0",
                                    "Label":"",
                                    "Value":postal_code,
                                    "Visible":"1"
                                },
                                {
                                    "Id":"ShippingPhone",
                                    "Required":"0",
                                    "Label":"",
                                    "Value":telephone_number,
                                    "Visible":"1"
                                }
                                # {"Id": "StorageSafeAccountGuid", "Required": "1", "Value": 'EA7G6HVDG63E34D', "Visible": "1"}
                                # {"Id": "StorageSafeGenerate", "Required": "1", "Value": "1", "Visible": "1"},
                                # {"Id": "StorageSafeGuid", "Required": "1", "Value": 'EA7G6HVDG6G794W', "Visible": "1"},
                            ]
                        },
                        "SoftDescriptors": {
                            "MerchantPhone": "1-800-123-4567",
                            "MerchantName": "Test Store",
                            "MerchantState": "NY"
                        },
                        "Detail": {
                            "Amount": amount_from_invoice,
                            "TranAction": "Sale",
                            "CurrencyCode": "840"
                        },
                        "Processing": {
                            "Verbose": "1",
                            "EnableShipping":"1",
                            "EnableBilling":"1",
                            "EnableBillingSummary":"1",
                            "EnableSectionHeaders":"0",
                            "ResponseUrl": response_url,
                            "ApprovalUrl": approval_url,
                            "RejectedUrl": rejected_url
                        },
                        "PaymentTypes": {
                            # "PaymentType": [
                            #     {"TranType": "Ach"},
                            #     {"TranType": "Credit", "CardType": ["Visa", "MasterCard"]}
                            # ]
                           "PaymentType": [
                                {
                                    "TranType":"Ach"
                                },
                                {
                                    "TranType":"Finance"
                                },
                                {
                                    "TranType":"Credit",
                                    "CardType":[
                                    "Visa",
                                    "MasterCard",
                                    "Amex",
                                    "Discover"
                                    ],
                                    "GooglePay":"0",
                                    "ApplePay":"1"
                                }
                            ]
                        },
                        "Locale": "en-US"
                    }
                },
                "Detail": {
                    "TranType": "PayPage",
                    "TranAction": "Initialize"
                }
            }
        }
    }
    logging.info(f'## get_payment_token TRX Request Payload {payload}')
    # TRX API endpoint
    post_url = os.environ.get('post_url', '')

    try:
        # Make the POST request with Basic Auth
        response = requests.post(
            post_url,
            json=payload,
            auth=(merchant_key, merchant_secret),
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        response.raise_for_status()
    except requests.RequestException as e:
        logging.info(f'## get_payment_token TRX Request Error {e}')
        failed_data = {"batch_id":batch_id,"error_text":f'{str(e)}'}
        error_data = {
        "service_name": "get_payment_token",
        "error_message": str(e),
        "error_type": str(type(e).__name__),
        "users": created_by,
        "session_id": session_id,
        "tenant_name": tenant_name,
        "comments": json.dumps(failed_data),
        "module_name": module_name,
        "request_received_at": request_received_at,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "token": f"Request error: {str(e)}"}

    # Parse JSON response
    res_json = response.json()
    try:
        logging.info(f'## get_payment_token TRX Response {res_json}')
        result_code = res_json["Message"]["Response"]["Result"]["ResponseCode"]
        if result_code == "00":
            guid = res_json["Message"]["Response"]["PayPage"]["Guid"]
            session = res_json["Message"]["Response"]["PayPage"]["Session"]
            # Construct payment URL
            payment_url = f"{payment_trigger_url}/?clientId=1053&paypage={guid}&session={session}"
            # payment_url = f"https://pay.trxservices.net/?clientId=1053&paypage={guid}&session={session}"
            token_data = {"token": payment_url, "batch_id": batch_id}
            audit_data_user_actions = {
            "service_name": "get_payment_token",
            "created_by": created_by,
            "status": 'Success',
            "time_consumed_secs": int(time.time() - start_time),
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(token_data),
            "module_name": module_name,
            "request_received_at": request_received_at
            }
            common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")
            return {"flag": True, "token": payment_url, "batch_id": batch_id}
        else:
            error_text = res_json["Message"]["Response"]["Result"].get("ResponseText", "Unknown error")
            logging.info(f'## get_payment_token TRX Error {error_text}')
            failed_data = {"batch_id":batch_id,"error_response":res_json}
            error_data = {
            "service_name": "get_payment_token",
            "error_message": str(error_text),
            "error_type": str(type(error_text).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
            }
            common_utils_db.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "token": f"TRX error: {error_text}"}
    except (KeyError, TypeError) as e:
        logging.info(f'## get_payment_token Error occured as {e}')
        failed_data = {"batch_id":batch_id}
        error_data = {
            "service_name": "get_payment_token",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
            }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "token": "Invalid response format"}


def fetch_transaction_status(data):
    """
    Retrieves and updates the transaction status for a given bill ID from the billing database, 
    retrying with exponential backoff if not found. Returns a success message if the transaction is successful, 
    a failure message if unsuccessful, or an error if the bill ID is not found.

    Args:
        data (dict): A dictionary containing the following keys:
            - username (str, optional): The username associated with the transaction. Defaults to an empty string.
            - table_name (str, optional): The database table to query. Defaults to "payment_history".
            - bill_id (str): The bill ID for which the transaction status needs to be retrieved.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if the transaction is successful, False otherwise.
            - message (str): A descriptive message about the transaction status.
    """
    logging.info(f'## fetch_transaction_status function called with data {data}')
    batch_id = data.get("batch_id", "")
    reference_guid = data.get("reference", "")
    if not batch_id:
        return {"flag": False, "message": "Batch ID is Empty"}
    if not reference_guid:
        return {"flag": False, "message": "Reference Guid is Empty"}

    try:
        billing_platform_db = DB(os.environ['BILLING_PLATFORM'], **db_config)
    except Exception as e:
        print(f"Database connection failed: {e}")
        return {"flag": False, "message": "Database connection error"}

    retries = 3
    delay = 2  # seconds exponential backoff
    message = 'Transaction is Pending'
    flag = True

    for attempt in range(retries):
        try:
            batch_id_df = billing_platform_db.get_data('transaction_status', {"id": batch_id}, ["batch_status", "failed_data"])
            if batch_id_df is not None and not batch_id_df.empty:
                batch_status = str(batch_id_df['batch_status'].tolist()[0])
                failed_data_raw = batch_id_df['failed_data'].tolist()[0] if 'failed_data' in batch_id_df.columns else None

                print(f'## fetch_transaction_status batch_status attempt {attempt+1}: {batch_status}')

                if batch_status == 'Success':
                    message = "Transaction Successful"
                    break
                elif batch_status == 'Fail':
                    message = "Transaction Failed"
                    flag = False
                    # Parse failed_data JSON string safely if it's set
                    failed_data = None
                    if failed_data_raw:
                        try:
                            failed_data = ast.literal_eval(failed_data_raw) if isinstance(failed_data_raw, str) else failed_data_raw
                        except Exception as ex:
                            print(f"Error parsing failed_data: {ex}")
                    return {
                        'flag': False,
                        'message': message,
                        'failed_data': failed_data
                    }
                else:
                    print(f"## fetch_transaction_status Transaction is pending, retrying ({attempt+1}/{retries})...")
                    time.sleep(delay)
                    delay *= 2
            else:
                print(f"## fetch_transaction_status Transaction not found, retrying ({attempt+1}/{retries})...")
                time.sleep(delay)
                delay *= 2
        except Exception as e:
            print(f"## fetch_transaction_status Error retrieving transaction data (attempt {attempt+1}): {e}")
            time.sleep(delay)
            delay *= 2

    return {'flag': flag, "message": message}

def fetch_transaction_status_backup(data):
    """
    Retrieves and updates the transaction status for a given bill ID from the billing database, 
    retrying with exponential backoff if not found. Returns a success message if the transaction is successful, 
    a failure message if unsuccessful, or an error if the bill ID is not found.

    Args:
        data (dict): A dictionary containing the following keys:
            - username (str, optional): The username associated with the transaction. Defaults to an empty string.
            - table_name (str, optional): The database table to query. Defaults to "payment_history".
            - bill_id (str): The bill ID for which the transaction status needs to be retrieved.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if the transaction is successful, False otherwise.
            - message (str): A descriptive message about the transaction status.
    """
    
    # Extract values from the input dictionary
    batch_id = data.get("batch_id", "")
    reference_guid = data.get("reference","")
    if not batch_id:
        return {"flag": False, "message": "Batch ID is Empty"}
    if not reference_guid:
        return {"flag": False, "message": "Reference Guid is Empty"}
    try:
        # Initialize database connection
        billing_platform_db = DB(os.environ['BILLING_PLATFORM'], **db_config)
    except Exception as e:
        print(f"Database connection failed: {e}")
        return {"flag": False, "message": "Database connection error"}

    # Define retry parameters
    retries = 3  # Number of retry attempts
    delay = 2    # Initial delay in seconds for exponential backoff

    message='Transaction is Pending'
    flag=True
    # Retry mechanism to fetch transaction status
    for attempt in range(retries):
        try:
            #Fetch the transaction tratus of a Bill ID
            batch_id_df = billing_platform_db.get_data('transaction_status', {"id": batch_id}, ["batch_status"])
            if batch_id_df is not None and not batch_id_df.empty:
                # Extract the transaction status if data is found
                batch_status = str(batch_id_df['batch_status'].tolist()[0])
                print(f'##batch_status attempt {attempt+1}: {batch_status}')
                if str(batch_status)=='Success':
                    message = "Transaction Successful"
                    break  # Exit loop if status is found
                elif str(batch_status)=='Fail':
                    message = "Transaction Failed"
                    flag=False
                    break  # Exit loop if status is found
                else:
                    print(f"Transaction is pending, retrying ({attempt+1}/{retries})...")
                    time.sleep(delay)
                    delay *= 2  # Exponential backoff (2s -> 4s -> 8s)
            else:
                # If transaction is not found, retry after a delay
                print(f"Transaction not found, retrying ({attempt+1}/{retries})...")
                time.sleep(delay)
                delay *= 2  # Exponential backoff (2s -> 4s -> 8s)
        except Exception as e:
            print(f"Error retrieving transaction data (attempt {attempt+1}): {e}")
            time.sleep(delay)
            delay *= 2
    return {'flag':flag,"message":message}

def get_headers_mapping(tenant_database, module_list, role, user, tenant_id, sub_parent_module, parent_module, data,):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.

    This function:
    - Connects to the database.
    - Fetches field mappings and categorizes them into pop-ups, general fields, and table fields.
    - Retrieves and processes module features based on user roles.
    - Returns a structured dictionary containing headers and features for each module.

    Parameters:
        tenant_database (str): The database name of the tenant.
        module_list (list): List of module names to fetch field mappings for.
        role (str): The role of the user (e.g., 'Super Admin').
        user (str): The username of the user.
        tenant_id (int): The ID of the tenant.
        sub_parent_module (str): The name of the sub-parent module.
        parent_module (str): The name of the parent module.
        data (dict): Additional input data, which may contain:
            - feature_module_name (str): The feature module name.
            - username/user_name/user (str): The username.
            - tenant_name/tenant (str): The tenant name.

    Returns:
        dict: A dictionary where each module name maps to its corresponding headers and features.
    """
    # Establish database connections
    database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    billing_platform_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    
    # Extract relevant details from the input data dictionary
    main_module_name=data.get("main_module_name", "Customer Profiles")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")
    parent_module_name = data.get("parent_module", "Billing Platform")

    try:
        logging.info("tenant_name is",tenant_name)
        # Retrieve tenant ID based on tenant name
        tenant_id = database.get_data(
            "tenant", {"tenant_name": tenant_name},["id"]
        )["id"].to_list()[0]
    except Exception as e:
        logging.warning(f"Getting exception at fetching tenant id {e}")
    
    ret_out = {}
    
    # Iterate over each module name in the provided module list
    for module_name in module_list:
        out = billing_platform_database.get_data(
            "field_column_mapping", {"module_name": module_name}
        ).to_dict(orient="records")
        pop_up = []
        general_fields = []
        table_fileds = {}
        # Categorize the fetched data based on field types
        for data in out:
            if data["pop_col"]:
                pop_up.append(data)
            elif data["table_col"]:
                table_fileds.update(
                    {
                        data["db_column_name"]: [
                            data["display_name"],
                            data["table_header_order"],
                        ]
                    }
                )
            else:
                general_fields.append(data)
        # Create a dictionary to store categorized fields
        headers = {}
        headers["general_fields"] = general_fields
        pop_up = sorted(pop_up, key=lambda x: x['id'])
        headers["pop_up"] = pop_up
        headers["header_map"] = table_fileds
        try:
            final_features = []

            # Fetch all features for the 'super admin' role
            if role.lower() == "super admin":
                all_features = database.get_data(
                    "module_features", {"module": main_module_name}, ["features"]
                )["features"].to_list()
                if all_features:
                    final_features = json.loads(all_features[0])
            else:
                final_features = get_features_by_feature_name(
                    user_name, tenant_id, main_module_name, database, parent_module_name, role
                )

        except Exception as e:
            logging.exception(f"there is some error {e}")
            pass
        # Add the final features to the headers dictionary
        headers["module_features"] = final_features
        if module_name in ["Customer Services Carrier","Customer Services Customer"]:
            module_name = "Customer Services"
        ret_out[module_name] = headers

    return ret_out



def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name, role
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        logging.debug("Raw user features fetched: %s", user_features_raw)

        if not user_features_raw or user_features_raw[0] is None:
            query=f'''select module_features from role_module where role='{role}'
            '''
            user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
        
        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  
        
        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        print(
            "Retrieved features: %s", features_list
        )  

    except Exception as e:
        # Catch any exceptions and log a warning
        logging.warning("There was an error while fetching features: %s", e)

    return features_list  # Return the list of retrieved features

def data_update_db(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        print(f'INchanged_data---------{changed_data}---{unique_id}------{table_name}')

        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            print(f"***update_data {update_data}")
            # Perform the update operation
            db.update_dict(table_name, update_data, {"id": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def convert_timestamp(df_dict, tenant_time_zone):
    """
    Convert timestamp columns in the provided dictionary list to the tenant's timezone.

    Parameters:
        df_dict (list of dict): A list of dictionaries where each dictionary represents a record
                                containing timestamp fields.
        tenant_time_zone (str): The timezone to which the timestamps should be converted.

    Returns:
        list of dict: The updated list of dictionaries with timestamps converted to the tenant's timezone.
    """
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at','date']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y %H:%M:%S')  # Ensure it's a string
    return df_dict

def data_update_db_account_number(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            print(f"***update_data {update_data}")
            # Perform the update operation
            db.update_dict(table_name, update_data, {"account_number": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def serialize_data(data):
    """Recursively convert pandas objects in the data structure to serializable types."""
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        return data.strftime('%m-%d-%Y %H:%M:%S')  # Convert to string
    else:
        return data  # Return as is if not a pandas object



def fetch_payment_methods(data):
    """
    Retrieves all payment methods for a given account_number and identifies the default payment method.
    Returns sample:
        {
            "payment_methods": [
                {
                    "number": "XXXXXXXXXX1234",
                    "type": "Visa",
                    "expiry": "03/31",
                },
                ...
            ],
            "default_method": {
                "number": "XXXXXXXXXX1234",
                "type": "Visa",
                "expiry": "03/31",
            }
        }
    """
    logging.info(f'## fetch_payment_methods function called with data {data}')

    try:
        account_number = data.get('account_number','')
        if not account_number:
            return {'flag': False, 'message': 'Account Number Required'}

        billing_platform_db = DB(os.environ['BILLING_PLATFORM'], **db_config)
        methods_df = billing_platform_db.get_data(
            "payment_methods",
            {"account_number": str(account_number),"is_active":True},
            ["last_four", "payment_method", "expiry_date", "default_payment"],
            {'id':'DESC'}
        )

        payment_methods = []
        default_method = None

        if methods_df is not None and not methods_df.empty:
            logging.info(f'## fetch_payment_methods methods_df {methods_df}')
            for _, row in methods_df.iterrows():
                method = {
                    "number": f"XXXXXXXXXX{row['last_four']}",  # Masked number format
                    "type": row["payment_method"],
                    "expiry": row["expiry_date"],
                }
                payment_methods.append(method)
                # Robust check for boolean default field
                if str(row.get("default_payment", "0")).lower() in ("1", "true", "yes"):
                    default_method = method
        if not payment_methods:
            return {
                'flag': False,
                'message': 'This account has no saved payment methods',
                'payment_methods': [],
                'default_method': None
            }
        return {
            'flag': True,
            'message': 'Payment Methods Fetched Successfully',
            "payment_methods": payment_methods,
            "default_method": default_method
        }
    except Exception as e:
        logging.info(f'## fetch_payment_methods Error occurred while fetching payment methods: {e}')
        return {
            'flag': False,
            'message': 'Failed to fetch Payment Methods',
            'payment_methods': [],
            'default_method': None
        }


def update_default_payment_method(data):
    """
    Updates the default payment method for an account.
    Args:
        account_number (str): The account number to update.
        payment_method (dict): Dict like {
            "number": "XXXXXXXXXX1234",
            "type": "Visa",
            "expiry": "03/31",
        }
    Returns:
        dict: { 'flag': True, 'message': "Default payment method updated." }
              or error structure on failure
    """
    logging.info(f'## update_default_payment_method called with data {data}')
    try:
        # Start time to track the action time
        start_time = time.time()

        # Fetch required parameter's from UI
        tenant_name = data.get("tenant_name")
        created_by = data.get("firstLastName", "")
        request_received_at = data.get("request_received_at", "")
        session_id = data.get("sessionID", "")
        module_name = data.get("module_name", "Payment Profiles")
        account_number = data.get('account_number','')
        changed_data = data.get('changed_data','')
        payment_method = changed_data.get('payment_method','')

        # Validation for account_number,payment_method
        if not account_number:
            return {'flag': False, 'message': 'Account number is required'}
        if not payment_method:
            return {'flag': False, 'message': 'Payment method details are required'}
        if not all(k in payment_method for k in ("number", "type", "expiry")):
            return {'flag': False, 'message': 'Incomplete payment method details'}

        # Fetch update payment method details
        last_four = payment_method['number'][-4:]
        pm_type = payment_method['type']
        expiry = payment_method['expiry']
        
        # DB Connections
        billing_platform_db = DB(os.environ['BILLING_PLATFORM'], **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)

        # Step 1: Set all payment methods for this account to default_payment=False
        old_method_update_status = billing_platform_db.update_dict(
            "payment_methods",
            {"default_payment": False},
            {"account_number": str(account_number)}
        )
        new_method_update_status = False
        # Step 2: Set the selected payment method to default_payment=True
        if old_method_update_status:
            new_method_update_status = billing_platform_db.update_dict(
                "payment_methods",
                {"default_payment": True},
                {
                    "account_number": str(account_number),
                    "last_four": last_four,
                    "payment_method": pm_type,
                    "expiry_date": expiry
                }
            )
        
        if new_method_update_status and old_method_update_status:
            audit_data_user_actions = {
                "service_name": "update_default_payment_method",
                "created_by": created_by,
                "status": "Success",
                "time_consumed_secs": int(time.time() - start_time),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(changed_data),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")
            return {'flag': True, 'message': 'Default payment method updated Successfully'}
        else:
            message = 'No matching payment method found to set as default'
            logging.info(f'## update_default_payment_method {message}')
            error_data = {
                "service_name": "update_default_payment_method",
                "error_message": message,
                "error_type": 'Empty Data',
                "users": created_by,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(changed_data),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            common_utils_db.log_error_to_db(error_data, "error_log_table")
            return {'flag': False, 'message': message}
    except Exception as e:
        logging.error(f'## update_default_payment_method error: {e}')
        error_data = {
            "service_name": "update_default_payment_method",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {'flag': False, 'message': 'Failed to update default payment method.'}


def delete_payment_method(data):
    """
    Deactivates (soft deletes) a payment method for an account.
    Performs audit logging for both success and errors.
    Args:
        data (dict): Must include:
            - account_number (str)
            - payment_method (dict) with keys:
                "number" (masked, last 4 digits), "type", "expiry"
    Returns:
        dict: { 'flag': True, 'message': "Payment method deactivated." }
    """
    logging.info(f'## delete_payment_method called with data {data}')
    try:
        start_time = time.time()

        # Metadata for auditing
        tenant_name = data.get("tenant_name")
        created_by = data.get("firstLastName", "")
        request_received_at = data.get("request_received_at", "")
        session_id = data.get("sessionID", "")
        module_name = data.get("module_name", "Payment Profiles")
        account_number = data.get('account_number','')
        changed_data = data.get('changed_data','')
        payment_method = changed_data.get('payment_method','')

        # Validation
        if not account_number:
            return {'flag': False, 'message': 'Account number is required'}
        if not payment_method:
            return {'flag': False, 'message': 'Payment method details are required'}
        if not all(k in payment_method for k in ("number", "type", "expiry")):
            return {'flag': False, 'message': 'Incomplete payment method details'}

        last_four = payment_method['number'][-4:]
        pm_type = payment_method['type']
        expiry = payment_method['expiry']

        billing_platform_db = DB(os.environ['BILLING_PLATFORM'], **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)

        update_status = billing_platform_db.update_dict(
            "payment_methods",
            {"is_active": False},
            {
                "account_number": str(account_number),
                "last_four": last_four,
                "payment_method": pm_type,
                "expiry_date": expiry
            }
        )

        if update_status:
            # Success audit logging
            audit_data_user_actions = {
                "service_name": "delete_payment_method",
                "created_by": created_by,
                "status": "Success",
                "time_consumed_secs": int(time.time() - start_time),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(payment_method),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")
            return {'flag': True, 'message': 'Payment method deactivated successfully.'}
        else:
            # Failure audit logging
            message = 'No matching payment method found to deactivate.'
            logging.info(f'## delete_payment_method {message}')
            error_data = {
                "service_name": "delete_payment_method",
                "error_message": message,
                "error_type": 'Empty Data',
                "users": created_by,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(payment_method),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            common_utils_db.log_error_to_db(error_data, "error_log_table")
            return {'flag': False, 'message': message}

    except Exception as e:
        logging.error(f'## delete_payment_method error: {e}')
        # Exception error audit logging
        error_data = {
            "service_name": "delete_payment_method",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("firstLastName", ""),
            "session_id": data.get("sessionID", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": json.dumps(data),
            "module_name": data.get("module_name", "Payment Profiles"),
            "request_received_at": data.get("request_received_at", ""),
        }
        try:
            common_utils_db.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f'## delete_payment_method error while logging audit: {log_e}')
        return {'flag': False, 'message': 'Failed to deactivate payment method.'}
