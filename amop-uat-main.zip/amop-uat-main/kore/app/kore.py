"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil .N
Created Date: 24-12-24
"""

# Importing the necessary Libraries
# kore.py
import psycopg2
import requests
from datetime import datetime, timedelta
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from psycopg2 import extras
import pandas as pd
import threading
import time
import random
from datetime import datetime
from psycopg2.extras import execute_values
from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta
from sqlalchemy import create_engine, text
import numpy as np
from psycopg2.extras import execute_values
from concurrent.futures import ThreadPoolExecutor, as_completed
import paramiko
import os
import pandas as pd
import io
import openpyxl

def get_access_token(client_id, client_secret, token_url):
    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret
    }
    try:
        response = requests.post(token_url, data=payload)
        response.raise_for_status()
        token_data = response.json()
        access_token = token_data.get("access_token")
        if access_token:
            print("Access Token Generated Successfully:")
            print(f"Access Token: {access_token}")  # Debugging: Print the token
            return access_token
        else:
            print("Error: Access token not found in response.")
            print(token_data)
            return None
    except requests.exceptions.RequestException as e:
        print(f"Error fetching access token: {e}")
        return None


def get_account_id(base_url, email, access_token, api_key=None):
    url = f"{base_url}/v1/accounts?email={email}"
    headers = {
        'Accept': 'application/json',
        'Authorization': f"Bearer {access_token}"
    }
    if api_key:
        headers['x-api-key'] = api_key  # Include API Key if required
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        account_data = response.json()

        # Extract account-id from the list inside 'account'
        accounts = account_data.get('account', [])
        if accounts and isinstance(accounts, list):
            account_id = accounts[0].get('account-id')  # Get the first account's account-id
            print("Account Details:")
            print(account_data)
            return account_id
        else:
            print("Error: No accounts found or invalid response structure.")
            return None
    except requests.exceptions.RequestException as e:
        print(f"Error fetching account ID: {e}")
        print(f"Response: {response.text}")  # Debugging: Log the raw response
        return None

def get_all_plans(base_url, headers, account_id):
    """
    Fetch all plans for a given account.

    :param base_url: The base URL of the API
    :param account_id: The account ID to fetch plans for
    :param api_token: The API token for authentication
    :return: JSON response containing all plans or an error message
    """
    # Construct the URL for the API request
    url = f"{base_url}/v1/accounts/{account_id}/plans"

    try:
        # Send the GET request to the API
        response = requests.get(url, headers=headers)

        # Check if the request was successful
        if response.status_code == 200:
            all_plan_data=response.json()  # Return the JSON response containing plans
            return all_plan_data['plans']
        else:
            print(f"Error in get_all_plans: {response.status_code} - {response.text}")
            return []

    except requests.exceptions.RequestException as e:
        print(f"An error occurred get_all_plans: {e}")
        return []

def get_plan_usage(base_url, headers, account_id, plan_id, start_date, end_date):
    """
    Fetch usage records for a specific plan.

    :param base_url: The base URL of the API
    :param account_id: The account ID
    :param plan_id: The plan ID for which usage records are fetched
    :param start_date: Start date for the usage records (YYYY-MM-DD)
    :param end_date: End date for the usage records (YYYY-MM-DD)
    :param source: Source for the usage records (e.g., 'source')
    :param api_token: The API token for authentication
    :return: JSON response containing usage records or an error message
    """
    # Construct the URL for the API request
    url = f"{base_url}/v1/accounts/{account_id}/plans/{plan_id}/usage-records"

    # Parameters for the query
    params = {
        'start-date': start_date,
        'end-date': end_date,
        'source': "cdr"
    }

    try:
        # Send the GET request to the API with parameters and headers
        response = requests.get(url, headers=headers, params=params)

        # Check if the request was successful
        if response.status_code == 200:
            return response.json()  # Return the JSON response containing usage records
        else:
            print(f"Error in get_plan_usage: {response.status_code} - {response.text}")
            return {}

    except requests.exceptions.RequestException as e:
        print(f"An error occurred get_plan_usage: {e}")
        return {}

def connect_to_db(dbname):
    """ Connect to the PostgreSQL database with dynamic dbname """
    try:
        connection = psycopg2.connect(
            host=os.environ["HOST"],
            port=os.environ["PORT"],
            user=os.environ["USER"],
            password=os.environ["PASSWORD"],
            dbname=dbname
        )
        return connection
    except Exception as e:
        print(f"Error in connecting the database: {e}")
        return None

def hit_stored_proc_device_sync():
    try:
        #hit the stored proc to insert or update data into device history and device status report tables
        db_url = f"postgresql://{os.environ["USER"]}:{os.environ["PASSWORD"]}@{os.environ["HOST"]}:{os.environ["PORT"]}/{os.environ["KOREDATABASE"]}"
        engine = create_engine(db_url)

        with engine.connect() as connection:
            try:
                stored_proc_params = {
                    "inp_integration_id": os.environ["KORE_INTEGRATION_ID"]
                }
                connection.execute(
                    text(
                        "CALL usp_device_sync_common_proc(:inp_integration_id)"
                    ),
                    stored_proc_params,
                )
                connection.commit()
            except Exception as e:
                print(
                    f"Error while inserting into the device_history, device_status_history tables: {e}"
                )

            print(f"Device History, Device Status History Insertion completed")
    except Exception as e:
        print(f"Device History, Device Status History Insertion Exception is : {e}")

def insert_plan_data_bulk(plan_data_list):
    """ Insert multiple plan details into the database in bulk """
    connection = connect_to_db(os.environ['KOREDATABASE'])
    if connection:
        cursor = connection.cursor()

        # Prepare the SQL insert statement, excluding the 'id' column
        insert_query = """
            INSERT INTO kore_carrier_rate_plan_stagging (plan_id, plan_name, plan_type_id, usage_type, service_type_id, created_by, created_date)
            VALUES (%s, %s, %s, %s, %s, %s, %s);
        """

        # Get current date and time for created_date
        current_date_time = datetime.now()

        # Prepare the list of values to be inserted (bulk data)
        values_list = []
        for plan_data in plan_data_list:
            values = (
                plan_data['plan-id'],
                plan_data['plan-name'],
                plan_data['plan-type-id'],
                plan_data['usage-type'],
                plan_data['service-type-id'],
                'phaneendra',  # Static value for created_by
                current_date_time  # Current date and time for created_date
            )
            values_list.append(values)

        try:
            # Execute the insert query in bulk using executemany()
            cursor.executemany(insert_query, values_list)
            connection.commit()  # Commit the transaction
            print(f"Inserted {len(values_list)} plan records.")
        except Exception as e:
            print(f"Error inserting data: {e}")
        finally:
            cursor.close()
            connection.close()
    else:
        print("Failed to connect to the database.")

def insert_device_usage_data_bulk(device_usage_data_list):
    """ Insert multiple device usage records into the database in bulk """
    connection = connect_to_db(os.environ['KOREDATABASE'])
    if connection:
        cursor = connection.cursor()

        # Prepare the SQL insert statement
        insert_query = """
            INSERT INTO kore_device_usage_stagging
            (subscription_id, iccid, eid, imei, model, msisdns, service_type_id,
             sms_usage, data_usage, voice_usage, cost_center_id, plan_id, plan_name,carrier_rate_plan_id, sim_status,created_date,sim_last_effective_date)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s,%s,%s);
        """

        # Get current date and time for created_date
        current_date_time = datetime.now()

        # Prepare the list of values to be inserted (bulk data)
        values_list = []
        for usage_data in device_usage_data_list:
            #print(usage_data,'usage_datausage_data')
           # states = [state['state'] for state in usage_data.get('states', [])] [0] # Extract states only
            # Extract the necessary data from the subscription
            values = (
                usage_data['subscription-id'],  # subscription-id
                usage_data['iccid'],  # iccid
                usage_data.get('eid', ''),  # eid (default empty if not present)
                usage_data.get('imei', ''),  # imei (default empty if not present)
                usage_data.get('model', ''),  # model (default empty if not present)
                usage_data.get('msisdns', []),  # msisdns (empty list if not present)
                usage_data.get('service-type-id', ''),  # service-type-id
                usage_data.get('sms-usage', 0),  # sms_usage (default 0 if not present)
                usage_data.get('data-usage', 0),  # data_usage (default 0 if not present)
                usage_data.get('voice-usage', 0),  # voice_usage (default 0 if not present)
                usage_data.get('cost-center-id', 0),  # cost_center_id
                usage_data.get('plan-id', ''),  # plan_id
                usage_data.get('plan-name', ''),  # plan_name
                usage_data.get('carrier-rate-plan-id', ''), #if isinstance(usage_data.get('carrier-rate-plan-id'), (int, np.integer)) else '',
                usage_data.get('sim_status', ''),  # sim_status (newly added)
                current_date_time  ,  # created_date
                usage_data.get('sim_last_effective_date', ''),  # sim_status (newly added)
            )
            values_list.append(values)
            #print(values_list,'values_listvalues_listvalues_listvalues_listvalues_listvalues_listvalues_listvalues_list')
        try:
            # Execute the insert query in bulk using executemany()
            cursor.executemany(insert_query, values_list)
            connection.commit()  # Commit the transaction
            print(f"Inserted {len(values_list)} device usage records.")
        except Exception as e:
            print(f"Error inserting data: {e}")
        finally:
            cursor.close()
            connection.close()
    else:
        print("Failed to connect to the database.")

def find_carrier_rate_plan_id(df, plan_id=None, plan_name=None):
    """
    Finds the ID in the DataFrame based on given plan_id and/or plan_name.

    Args:
        df (pd.DataFrame): DataFrame containing columns 'id', 'plan_id', and 'plan_name'.
        plan_id (int, optional): The plan_id to filter by.
        plan_name (str, optional): The plan_name to filter by.

    Returns:
        int or None: The matching id, or None if no match is found.
    """
    if plan_id is not None and plan_name is not None:
        result = df[(df['plan_id'] == plan_id) & (df['plan_name'] == plan_name)]
    elif plan_id is not None:
        result = df[df['plan_id'] == plan_id]
    elif plan_name is not None:
        result = df[df['plan_name'] == plan_name]
    else:
        return None  # No filters provided

    return result['id'].iloc[0] if not result.empty else None

def prepare_device_usage_data(subscriptions_data,base_url=None,account_id=None,headers=None,df=None):
    """ Prepare the device usage data for bulk insert """
    device_usage_data_list = []
    for subscription in subscriptions_data:
        #print('subscriptionsubscriptionsubscriptionsubscription',subscription)
        last_effective_states = subscription.get('states', [])
        sim_status = ''

        #print('last_effective_stateslast_effective_stateslast_effective_states',last_effective_states)
        if isinstance(last_effective_states, list) and len(last_effective_states) > 0:
            current_dict = next((item for item in last_effective_states if item.get("is-current") == True), {})
            sim_status = current_dict.get('state', '').lower()
            date_activated = None

            # If the SIM status is Active, get the activation date
            if sim_status == "active":
                date_activated = current_dict.get('start-datetime-utc', None)
        else:
            sim_status = ''
            date_activated = None

        # Prepare the data in the required format
        usage_data = {
            'subscription-id': subscription.get('subscription-id', ''),
            'iccid': subscription.get('iccid', ''),
            'eid': subscription.get('eid', ''),
            'imei': subscription.get('imei', ''),
            'model': subscription.get('model', ''),

            # Handle msisdns to ensure it is a list of strings
            'msisdns': ', '.join(str(msisdn.get('msisdn', '')) for msisdn in subscription.get('msisdns', []) if 'msisdn' in msisdn),  # Convert msisdns to string

            'service-type-id': subscription.get('service-type-id', ''),
            'sms-usage': subscription.get('sms-usage', 0),
            'data-usage': subscription.get('data-usage', 0),
            'voice-usage': subscription.get('voice-usage', 0),
            'cost-center-id': subscription.get('cost-center-id', 0),
            'plan-id': subscription.get('plan-id', ''),
            'plan-name': subscription.get('plan-name', ''),
            'carrier-rate-plan-id': None,  # Default to None below value gets updated
            'sim_status': sim_status,
            'sim_last_effective_date': date_activated  # Adding activation date if SIM is active
        }
        if base_url is not None:
            #print('entered here')
            # Safely get profile_id without IndexError
            profile_info = subscription.get('last-active-profile', [])

            if profile_info and isinstance(profile_info, list) and len(profile_info) > 0:
                profile_id = profile_info[0].get('profile-id', '')
            else:
                profile_id = None  # Avoid IndexError by assigning None
            if profile_id:
                url = f"{base_url}/v1/accounts/{account_id}/profiles/{profile_id}"
                try:
                    time.sleep(1) # To control the requests limit at the carrier end
                    response = requests.get(url, headers=headers)

                    if response.status_code == 200:
                        response = response.json()
                        #print(response,'response at gettig rate plan name')
                        plan_id = next((plan["plan-id"] for plan in response["plans"] if plan["usage-type"] == "DATA"), None)
                        plan_name = next((plan["plan-name"] for plan in response["plans"] if plan["usage-type"] == "DATA"), None)
                        usage_data['plan-id'] = plan_id
                        usage_data['plan-name'] = plan_name
                        if not df.empty:
                            carrier_id = find_carrier_rate_plan_id(df, plan_id, plan_name)
                            #print('carrier_idcarrier_idcarrier_id',carrier_id)
                        else:
                            carrier_id = None
                        if carrier_id is not None:
                            usage_data['carrier-rate-plan-id'] = int(carrier_id)
                        else:
                            usage_data['carrier-rate-plan-id'] = None
                    else:
                        print(f"Error while fetching the plan details: {response.status_code} - {response.text}")
                except requests.exceptions.RequestException as e:
                    print(f"Error while fetching the plan details:An error occurred: {e}")

        device_usage_data_list.append(usage_data)
    return device_usage_data_list

def fetch_and_process_subscriptions(base_url, headers, account_id, page_index, max_page_item,df):
    """ Fetch subscriptions and process them for insertion """

    subscriptions_data = get_all_subscriptions(base_url, headers, account_id, page_index, max_page_item)
    #df = pd.DataFrame(columns=["id", "plan_id", "plan_name"])  # Initialize empty DataFrame

    if isinstance(subscriptions_data, dict) and 'subscriptions' in subscriptions_data:
        subscriptions = subscriptions_data['subscriptions']
        print(f"Number of subscriptions: {len(subscriptions)}")
        if subscriptions:
            #  Now loop happens only in prepare_device_usage_data
            device_usage_data_list = prepare_device_usage_data(subscriptions, base_url, account_id, headers, df)
            insert_device_usage_data_bulk(device_usage_data_list)

            return [{'subscription_id': sub['subscription-id'], 'iccid': sub['iccid']} for sub in subscriptions]

    return []

def get_all_subscriptions(base_url, headers, account_id, page_index=1, max_page_item=100):
    url = f"{base_url}/v1/accounts/{account_id}/subscriptions"
    params = {
        "page-index": page_index,
        "max-page-item": max_page_item,
        "show-state-history": True
    }

    try:
        time.sleep(3) # To control the requests limit at the carrier end
        response = requests.get(url, headers=headers, params=params)

        if response.status_code == 200:
            return response.json()
        else:
            return f"Error: {response.status_code} - {response.text}"
    except requests.exceptions.RequestException as e:
        return f"An error occurred: {e}"

##to ge the usage date ranges
def get_usage_data_range():
    today = datetime.now(timezone.utc)  # Use timezone-aware UTC datetime

    # Define start_date as the 25th of the previous month
    if today.day >= 24:
        start_date = today.replace(day=24)

        # Handle December to January transition safely
        next_month = today + relativedelta(months=1)
        end_date = next_month.replace(day=23)
    else:
        # Handle January to December transition safely
        previous_month = today - relativedelta(months=1)
        start_date = previous_month.replace(day=24)
        end_date = today.replace(day=23)

    # Format timestamps correctly
    start_date_str = start_date.strftime("%Y-%m-%d 00:00:00")
    end_date_str = end_date.strftime("%Y-%m-%d 23:59:59")

    return start_date_str, end_date_str

def Kore_daily_syncs():
    print("Starting with Kore Features implementation")
    mode=os.environ['MODE']
    # # Get today's date
    # today = datetime.today()

    # # Subtract one day from today to get the previous day
    # previous_day = today - timedelta(days=1)

    # # For the range, use a wider time frame (e.g., last 7 days)
    # start_date = (today - timedelta(days=7)).strftime('%Y-%m-%d')  # 7 days ago
    # end_date = previous_day.strftime('%Y-%m-%d')  # Previous day
    # Get current date
    current_date = datetime.now()

    # Create the start and end date for today
    #start_date = current_date.replace(hour=0, minute=0, second=0, microsecond=0)
    #end_date = current_date.replace(hour=23, minute=59, second=59, microsecond=999999)
    # start_date ='2025-01-25 00:00:00'
    # end_date ='2025-02-24 23:59:59'
    start_date, end_date = get_usage_data_range()
    print("Start Date:", start_date)
    print("End Date:", end_date)
    if mode=='sandbox':
        base_url=os.environ['KORE_URL_SANDBOX']
        client_id=os.environ['KORE_CLIENT_ID_SB']
        client_secret=os.environ['KORE_CLIENT_SECRET_KEY_SB']
        token_url=os.environ['KORE_TOKEN_URL_SB']
        api_key=os.environ['KORE_API_KEY_SB']
    elif mode=='PROD':
        email=os.environ['KORE_EMAIL']
        base_url=os.environ['KORE_URL_PROD']
        token_url=os.environ['KORE_TOKEN_URL_PROD']
        client_id=os.environ['KORE_CLIENT_ID_PROD']
        client_secret=os.environ['KORE_CLIENT_SECRET_KEY_PROD']
        api_key=os.environ['KORE_API_KEY_PROD']

    access_token = get_access_token(client_id, client_secret, token_url)

    final_headers = {
        "Authorization": f"Bearer {access_token}",
        'Accept': 'application/json',
        'x-api-key': api_key
    }

    account_id=account_id = get_account_id(base_url, email, access_token, api_key)
    if not account_id:
        return {"flag":False,'Message':'No acccount Id found for this email'}
    #fetching all plans and their usage details
    plans=get_all_plans(base_url, final_headers, account_id)
    print("Plans received from the carrier",plans)
    if plans:
        plan_data_list = []
        for plan in plans:
            plan_data = {
                'plan-id': plan['plan']['plan-id'],
                'plan-name': plan['plan']['plan-name'],
                'plan-type-id': plan['plan']['plan-type-id'],
                'usage-type': plan['plan']['usage-type'],
                'service-type-id': plan['plan']['service-type-id']
            }
            plan_data_list.append(plan_data)

        # Insert all plan data in bulk into the database
        insert_plan_data_bulk(plan_data_list)
        print("Bulk insert done")
    df = pd.DataFrame(columns=["id", "plan_id", "plan_name"])
    if base_url is not None:
        print('Entered database fetch section (only once)')  # ✅ Moved outside loop

        dbname = os.environ['KOREDATABASE']
        connection = connect_to_db(dbname)

        if connection:
            try:
                cursor = connection.cursor()
                query = """
                SELECT id, rate_plan_code as plan_id, rate_plan_short_name as plan_name
                FROM carrier_rate_plan WHERE rate_plan_code LIKE '%%cmp%%';
                """
                cursor.execute(query)
                rows = cursor.fetchall()

                if rows:
                    df = pd.DataFrame(rows, columns=["id", "plan_id", "plan_name"])
                else:
                    df = pd.DataFrame(columns=["id", "plan_id", "plan_name"])

                print("data of top records in carrier_rate_plan had for Kore carrier",df.head())  # Ensuring this prints only once

            except Exception as e:
                print(f"Error fetching data from DB: {e}")

            finally:
                cursor.close()
                connection.close()
    ##subscriptions data inserts using multithreading
    all_iccid_subscriptions = []  # To store all iccid-subscription pairs
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = []
        page_index = 0
        max_page_item = 100  # Fetch 100 records per page

        while True:
            # Below function fetch the subscriptions data and insert into the stagging table
            future = executor.submit(fetch_and_process_subscriptions, base_url, final_headers, account_id, page_index, max_page_item,df)
            futures.append(future)
            page_index += 1

            # Check the last fetched result to decide when to stop
            if len(futures) > 0 and future.result() == []:
                break  # Stop if no more subscriptions

        # Collect results from all futures
        for future in as_completed(futures):
            all_iccid_subscriptions.extend(future.result())  # Add results to the list

    ##need to get these from database tbale need to build that
    tenant_id = os.environ['TENANT_ID']
    service_provider_id = os.environ['SERVICE_PROVIDER_ID']
    mapping_name = os.environ['MAPPING_NAME']
    tenant_db_name = os.environ['KOREDATABASE']  # This is dynamic, depending on the tenant database you want to connect to
    # Below function call is to fetch the usage data of each device and update into stagging table
    process_subscriptions_concurrently(all_iccid_subscriptions, base_url, final_headers, account_id, start_date, end_date)
    print("Processing subscriptions completed inserting data into the stagging table.")

    # Below function call is to insert data from staging to main tables
    insert_staging_to_main(tenant_id, service_provider_id, mapping_name, tenant_db_name)
    api_url = os.getenv("OPTIMIZATIONSYNCURL", None)
    time.sleep(40) # To ensure the data is inserted into the required tables before running the reverse sync procedure
    #list_tables_sync = ['device','device_tenant','device_history','device_status_history']
    #for table in list_tables_sync:
    api_payload = {
            "data": {
                "path": "/lambda_sync_jobs_",
                "key_name": "carrier_rev_sync_jobs",
                "tenant_name": "Altaworx Test"
            }
        }
    print(api_payload,'api_payloadapi_payload')
    # Send the POST request to the API
    print(f"Sending POST request to {api_url} with payload: {api_payload}")
    response = requests.post(api_url, json=api_payload)

    if response.status_code == 200:
        print(f"POST request successful for: {response.json()}")
    else:
        print(f"POST request failed for kore sync: {response.status_code} - {response.text}")
    # Below function call is to sync data into device history and device status history tables
    hit_stored_proc_device_sync()

    # df_sim_inventory = get_sim_management_inventory(dbname="altaworx_test")
    # if df_sim_inventory is not None:
    #     with ThreadPoolExecutor(max_workers=3) as executor:  # Adjust max_workers as necessary
    #         for index, row in df_sim_inventory.iterrows():
    #             executor.submit(process_subscription_data, row, base_url, final_headers, account_id, start_date, end_date)
    print("Processing subscriptions complete to the main tables.")
    return {'flag': True, 'Message': 'Daily Sync Complete'}

def safe_process_subscription_data(row, connection, base_url, headers, account_id, start_date, end_date):
    """Wrapper for process_subscription_data to catch and log errors."""
    try:
        process_subscription_data(row, connection, base_url, headers, account_id, start_date, end_date)
    except Exception as e:
        print(f"Error in thread: {e}", flush=True)

def process_subscription_data(row, connection, base_url, headers, account_id, start_date, end_date):
    """Fetch usage data and update DB immediately."""
    try:
        subscription_id = row['subscription_id']
        iccid = row['iccid']

        # Fetch data from API
        time.sleep(0.4) # to control the requests limit at the carrier end
        usage_data = get_subscription_usage(base_url, headers, account_id, subscription_id, start_date, end_date)

        if usage_data:
            data_usage = usage_data.get('data', {}).get('total-usage', 0)
            sms_usage = usage_data.get('sms', {}).get('total-usage', 0)
            voice_usage = usage_data.get('voice', {}).get('total-usage', 0)

            # Immediately update DB
            update_usage_data(connection, subscription_id, iccid, data_usage)

    except Exception as e:
        print(f"Error in process_subscription_data: {e}")

def update_usage_data(connection, subscription_id, iccid, data_usage):
    """Update usage data in DB for a single subscription."""
    try:
        with connection.cursor() as cursor:
            data_usage_mb = data_usage/1048576  # Data receiving in bytes need to store in mb for inventory
            update_query = """
                UPDATE kore_device_usage_stagging
                SET data_usage = %s, data_usage_mb=%s
                WHERE subscription_id = %s AND iccid = %s
            """
            cursor.execute(update_query, (data_usage, data_usage_mb, subscription_id, iccid))
            connection.commit()
            #print(f"Updated: Subscription {subscription_id}, ICCID {iccid}, Usage {data_usage}")
    except Exception as e:
        print(f"Error during update: {e}")
        connection.rollback()

def process_subscriptions_concurrently(subscriptions_data, base_url, headers, account_id, start_date, end_date, max_workers=10):
    """Fetch API data and update the database one by one."""
    if not subscriptions_data:
        print("No subscriptions to process.")
        return {'flag': False, 'Message': 'No subscriptions found'}

    print(f"Processing {len(subscriptions_data)} subscriptions in parallel...", flush=True)

    connection = connect_to_db(os.environ['KOREDATABASE'])
    if connection is None:
        print("Database connection failed.")
        return {'flag': False, 'Message': 'Database connection failed'}

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(safe_process_subscription_data, row, connection, base_url, headers, account_id, start_date, end_date)
            for row in subscriptions_data
        ]

        for future in as_completed(futures):
            try:
                future.result()  # Ensure any exceptions inside the threads are raised
            except Exception as e:
                print(f"Exception in future: {e}", flush=True)

    connection.close()
    print("Processing subscriptions complete.", flush=True)
    return {'flag': True, 'Message': 'Daily Sync Complete'}

def get_sim_management_inventory(dbname=os.environ['KOREDATABASE']):
    """Fetch SIM Management Inventory data."""
    try:
        connection = connect_to_db(dbname)
        if connection:
            cursor = connection.cursor()

            query = """
            SELECT DISTINCT ON (iccid) id, iccid, subscription_id
            FROM sim_management_inventory
            WHERE service_provider_display_name = 'Kore'
            ORDER BY iccid, id;
            """

            cursor.execute(query)
            rows = cursor.fetchall()
            df = pd.DataFrame(rows, columns=["id", "iccid", "subscription_id"])

            cursor.close()
            connection.close()

            print(f"Data fetched successfully with {len(df)} rows.")
            return df
        else:
            print("Failed to connect to the database.")
            return None
    except Exception as e:
        print(f"Error fetching data: {e}")
        return None

def get_subscription_usage(base_url, headers, account_id, subscription_id, start_date, end_date, max_retries=5):
    """Fetch subscription usage data."""
    url = f"{base_url}/v1/accounts/{account_id}/subscriptions/{subscription_id}/usage-records"
    params = {
        "start-date": start_date,
        "end-date": end_date,
        "source": "cdr"
    }
    params = {key: value for key, value in params.items() if value is not None}

    retries = 0
    while retries < max_retries:
        try:
            response = requests.get(url, headers=headers, params=params)

            if response.status_code == 200:
                return response.json()
            elif response.status_code == 429:
                retries += 1
                wait_time = 2 ** retries + random.uniform(0, 1)
                print(f"Rate limit exceeded {subscription_id}. Retrying in {wait_time:.2f} seconds...")
                time.sleep(wait_time)
            else:
                print(f"Error in fetching get_subscription_usage: {response.status_code} - {response.text}")
                return {}
        except requests.exceptions.RequestException as e:
            print(f"An error occurred: {e}")
            return {}

    print("Max retries reached. Could not fetch subscription usage.")
    return {}

def insert_usage_data(connection, sim_management_inventory_id, data_usage, sms_usage, voice_usage, usage_date):
    """Insert the fetched usage data into the database."""
    cursor = connection.cursor()
    try:
        insert_query = """
        INSERT INTO device_usage (sim_management_inventory_id, data_usage, sms_usage, voice_usage, usage_date, created_by)
        VALUES (%s, %s, %s, %s,%s,%s)
        """
        cursor.execute(insert_query, (sim_management_inventory_id, data_usage, sms_usage, voice_usage, usage_date, 'kore_spectrocel'))
        connection.commit()
        print(f"Inserted usage data for SIM ID {sim_management_inventory_id}")
    except Exception as e:
        print(f"Error inserting data: {e}")
        connection.rollback()
    finally:
        cursor.close()

def clean_daily_sync():
    """ Clean up staging tables for daily sync """
    connection = connect_to_db(os.environ['KOREDATABASE'])  # Static DB for cleanup
    if connection:
        cursor = connection.cursor()

        try:
            # Define the cleanup SQL queries for staging tables
            delete_query_plan = "DELETE FROM kore_carrier_rate_plan_stagging;"
            delete_query_usage = "DELETE FROM kore_device_usage_stagging;"

            # Execute the delete queries
            cursor.execute(delete_query_plan)
            cursor.execute(delete_query_usage)

            # Commit the transaction to apply the changes
            connection.commit()

            print("Successfully cleaned up the staging tables.")

        except Exception as e:
            print(f"Error cleaning up staging tables: {e}")
            connection.rollback()  # Rollback in case of error

        finally:
            # Close the cursor and connection
            cursor.close()
            connection.close()
    else:
        print("Failed to connect to the database.")

def bulk_insert_to_db(data, table, connection):
    """ Insert bulk data into the given table """
    try:
        cursor = connection.cursor()

        # Get the column names from the DataFrame
        columns = data.columns.tolist()
        data = data.astype(object).where(pd.notnull(data), None)
        # Format the INSERT statement dynamically
        insert_query = f"INSERT INTO {table} ({', '.join(columns)}) VALUES %s"

        # Convert the DataFrame to a list of tuples
        values = [tuple(row) for row in data.values]

        # Use execute_values for efficient bulk insert
        extras.execute_values(cursor, insert_query, values)

        # Commit the transaction
        connection.commit()
        print(f"Successfully inserted {len(data)} rows into {table}.")

    except Exception as e:
        # Rollback in case of an error
        connection.rollback()
        print(f"Error inserting data into {table}: {e}")
    finally:
        cursor.close()

def bulk_update_to_db(data, table, key_column, connection):
    """
    Perform a bulk update on the given table based on a key column.

    Parameters:
    - data (pd.DataFrame): Data to be updated
    - table (str): Table name
    - key_column (str): Column used to match records (e.g., 'iccid')
    - connection (psycopg2 connection): Active database connection
    """
    try:
        cursor = connection.cursor()

        # Extract column names dynamically excluding the key column
        update_columns = [col for col in data.columns if col != key_column]

        # Generate the SET clause dynamically
        set_clause = ", ".join([f"{col} = EXCLUDED.{col}" for col in update_columns])

        # Construct the SQL query using INSERT ... ON CONFLICT DO UPDATE
        update_query = f"""
            INSERT INTO {table} ({', '.join(data.columns)})
            VALUES %s
            ON CONFLICT ({key_column})
            DO UPDATE SET {set_clause};
        """

        # Convert DataFrame to list of tuples
        values = [tuple(row) for row in data.itertuples(index=False, name=None)]

        # Use execute_values for efficient batch processing
        extras.execute_values(cursor, update_query, values)

        # Commit transaction
        connection.commit()
        print(f"Successfully updated {len(data)} rows in {table}.")

    except Exception as e:
        connection.rollback()
        print(f"Error updating data in {table}: {e}")

    finally:
        cursor.close()

def fetch_data_from_db(query, connection):
    """ Fetch data from the database using the provided query """
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        data = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]  # Get column names
        return [dict(zip(columns, row)) for row in data]  # Return data as a list of dictionaries
    except Exception as e:
        print(f"Error fetching data: {e}")
        return []
    finally:
        cursor.close()

def insert_staging_to_main(tenant_id, service_provider_id, mapping_name, tenant_db_name):
    """ Insert data from staging table to the main table based on mappings """
    try:
        # Establish the connection to fetch the mappings from the 'Migration_Test' database
        connection = connect_to_db('Migration_Test')  # Static DB for mappings
        if not connection:
            print("Failed to connect to the database.")
            return

        # Load the mappings of the table
        mappings_query = f"""
            SELECT * FROM stagging_table_mappings
            WHERE tenant_id='{tenant_id}' AND service_provider_id='{service_provider_id}' AND mapping_name='{mapping_name}'
        """
        mappings_data = fetch_data_from_db(mappings_query, connection)

        if not mappings_data:
            print(f"No mappings found for tenant_id={tenant_id}, service_provider_id={service_provider_id}, mapping_name={mapping_name}")
            return

        # Close connection after fetching mappings
        connection.close()

        # Establish a new connection to the tenant's database (dynamic dbname)
        connection = connect_to_db(tenant_db_name)
        if not connection:
            print(f"Failed to connect to the tenant's database: {tenant_db_name}")
            return

        # Load data from staging table in the tenant's database
        staging_query = "SELECT * FROM kore_device_usage_stagging"  # You can adjust the limit as needed
        staging_data = fetch_data_from_db(staging_query, connection)
        # Close the connection after fetching data
        connection.close()

        # Extract mappings
        columns_mapping = mappings_data[0]['cols_mapping']
        tables_mapping = mappings_data[0]['table_mapping']

        # Determine the source and target tables
        from_table_name = list(tables_mapping.keys())[0]
        to_tables = tables_mapping[from_table_name]

        # Reconnect for data insertion
        connection = connect_to_db(tenant_db_name)
        if not connection:
            print(f"Failed to reconnect to the tenant's database: {tenant_db_name}")
            return False

        # to get the billing details
        billing_query = f"select * from billing_period where tenant_id = {tenant_id} and service_provider_id = {service_provider_id} and is_active = 'true' limit 1"
        billing_data = fetch_data_from_db(billing_query, connection)
        print("Billing data fetched successfully: {}")
        if billing_data:
            bill_year = int(billing_data[0]['bill_year'])
            bill_month = int(billing_data[0]['bill_month'])
            billing_period_id = int(billing_data[0]['id'])
        else:
            bill_year = ''
            bill_month = ''
            billing_period_id = ''

        # Loop through the target tables and perform the insert
        for table in to_tables:
            # Get column mappings for the table
            mapping = columns_mapping[table]

            # Step 1: Rename columns in the staging data according to the mapping
            transformed_df = pd.DataFrame(staging_data).rename(columns=mapping)

            # Step 2: Select only the columns that are mapped
            transformed_df = transformed_df[list(mapping.values())]
            print(transformed_df.columns,'gdjskfjdsaf')
            # Special handling for specific tables (like 'sim_management_inventory')
            if table == 'sim_management_inventory':
                transformed_df['service_provider_id'] = int(mappings_data[0]['service_provider_id'])
                transformed_df['service_provider_display_name'] = mappings_data[0]['service_provider_name']
                transformed_df['tenant_id'] = int(mappings_data[0]['tenant_id'])
                transformed_df['is_active'] = True
                transformed_df['is_deleted'] = False
                transformed_df['created_by'] = 'Kore_Spectrocel_Container'
                transformed_df['cost_center'] = ''
                transformed_df['billing_period_id'] = billing_period_id
                transformed_df['bill_year'] = bill_year
                transformed_df['bill_month'] = bill_month
                transformed_df['integration_id'] = os.environ['KORE_INTEGRATION_ID']
                if 'sim_status' in transformed_df.columns:
                    transformed_df['sim_status'] = transformed_df['sim_status']
                # First, fetch device status mappings from device_stat
                integration_id = os.environ['KORE_INTEGRATION_ID']
                device_status_query = f"SELECT id, status FROM device_status WHERE integration_id = {integration_id}"
                device_status_data = fetch_data_from_db(device_status_query, connection)

                # Normalize status keys by converting them to lowercase
                status_to_id_mapping = {
                    item['status'].strip().lower(): item['id']
                    for item in device_status_data
                }

                # Step 2: Build reverse mapping from id → original status (case preserved)
                id_to_status_mapping = {
                    item['id']: item['status'].strip()
                    for item in device_status_data
                }

                if 'sim_status' in transformed_df.columns:
                    # Map lowercase normalized sim_status to device_status_id
                    transformed_df['device_status_id'] = (
                        transformed_df['sim_status'].str.strip().str.lower().map(status_to_id_mapping)
                    )

                    # Replace sim_status with the original-cased mapped status
                    transformed_df['sim_status'] = transformed_df['device_status_id'].map(id_to_status_mapping)

                query_sim = "SELECT iccid FROM sim_management_inventory where service_provider_display_name = 'Kore'"
                inventory_data = fetch_data_from_db(query_sim, connection)
                print('Entered here successfully fetched the inventory data')
                inventory_df = pd.DataFrame(inventory_data)  # Convert list of dicts to DataFrame

                if not inventory_df.empty and 'iccid' in inventory_df.columns:
                    exist_data = transformed_df[transformed_df['iccid'].isin(inventory_df['iccid'])]
                else:
                    # Create an empty DataFrame with 'iccid' column to avoid KeyError
                    inventory_df = pd.DataFrame(columns=['iccid'])
                    exist_data = pd.DataFrame()  # Empty DataFrame if no records exist


                #print(exist_data,'exist_dataexist_dataexist_dataexist_data')
                # Convert empty strings to None
                transformed_df.replace('', None, inplace=True)

                # Drop columns with missing values **only for that row**
                transformed_df = transformed_df.apply(lambda row: row.dropna(), axis=1)

                # Drop rows where 'iccid' is missing
                transformed_df.dropna(subset=['iccid'], inplace=True)

                # Perform bulk update only if data exists
                if not exist_data.empty:
                    # Split into two DataFrames based on whether carrier_rate_plan_id is NaN
                    df_with_rate_plan = transformed_df[transformed_df['carrier_rate_plan_id'].notna()].copy()
                    df_without_rate_plan = transformed_df[transformed_df['carrier_rate_plan_id'].isna()].copy()

                    # Replace NaNs with None in df_without_rate_plan
                    df_without_rate_plan['carrier_rate_plan_id'] = None
                    df_without_rate_plan['carrier_rate_plan_name'] = None

                    print('df_with_rate_plan', df_with_rate_plan.head(10))
                    print('df_without_rate_plan', df_without_rate_plan.head(10))

                    # Perform updates
                    if not df_with_rate_plan.empty:
                        bulk_update_sim_inventory(df_with_rate_plan, connection)

                    if not df_without_rate_plan.empty:
                        bulk_update_sim_inventory(df_without_rate_plan, connection)

                # Remove records that were updated
                transformed_df = transformed_df[~transformed_df['iccid'].isin(inventory_df['iccid'])]

                # Perform bulk insert only if data exists
                if not transformed_df.empty:
                    bulk_insert_to_db(transformed_df, 'sim_management_inventory', connection)
                    print('Data inserted successfully')

        # Close the connection after insertion
        connection.close()

        print("Data insertion complete.")
        return {"flag": True, "message": "Data inserted successfully in to main tables."}
    except Exception as e:
        print(f"Error during staging to main insertion: {e}")

def bulk_update_sim_inventory(data, connection):
    try:
        cursor = connection.cursor()

        # Define correct data types for explicit casting in PostgreSQL
        column_data_types = {
            "carrier_cycle_usage_bytes": "BIGINT",
            "subscription_id": "VARCHAR",
            "imei": "VARCHAR",
            "msisdn": "VARCHAR",
            "sim_status": "VARCHAR",
            "carrier_rate_plan_name": "VARCHAR",
            "carrier_rate_plan_id": "INTEGER",
            "service_provider_id": "INTEGER",
            "service_provider_display_name": "VARCHAR",
            "tenant_id": "INTEGER",
            "is_active": "BOOLEAN",
            "is_deleted": "BOOLEAN",
            "created_by": "VARCHAR",
            "modified_by": "VARCHAR",
            "cost_center": "VARCHAR",
            "billing_period_id": "INTEGER",
            "bill_year": "INTEGER",
            "bill_month": "INTEGER",
            "iccid": "VARCHAR",
            "device_status_id": "INTEGER",
            "integration_id": "INTEGER",
            "carrier_cycle_usage_mb": "NUMERIC",
            "date_activated": "TIMESTAMP",
        }

        # Ensure correct column order
        expected_columns = list(column_data_types.keys())

        # Fill missing columns with NULL values
        for col in expected_columns:
            if col not in data.columns:
                data[col] = None

        # Convert NaN to None for NULL handling in SQL
        data = data.replace({np.nan: None})

        # Convert float columns that should be integer
        integer_columns = ["carrier_rate_plan_id", "service_provider_id", "tenant_id", "billing_period_id", "bill_year", "bill_month", "device_status_id"]
        for col in integer_columns:
            data[col] = data[col].apply(lambda x: int(x) if pd.notnull(x) else 0)  # Replace None with 0
        data['carrier_rate_plan_id'] = data['carrier_rate_plan_id'].replace(0, None)
        # Convert text columns to string
        for col, dtype in column_data_types.items():
            if dtype == "VARCHAR":
                data[col] = data[col].astype(str)

        # Ensure correct column order
        data = data[expected_columns]

        # Debugging output
        print("Data Types Before Update:")
        print(data.dtypes)
        print("Sample Row Before Update:")
        print(data.iloc[0])

        # Construct the SET clause with explicit type casting
        set_clause = ", ".join([
            f"{col} = COALESCE(s.{col}::{column_data_types[col]}, t.{col})"
            for col in expected_columns if col != "iccid"
        ])

        # Bulk update query
        query = f"""
        UPDATE sim_management_inventory AS t
        SET {set_clause}
        FROM (VALUES %s) AS s ({', '.join(expected_columns)})
        WHERE t.iccid = s.iccid;
        """

        # Convert DataFrame to list of tuples
        values = [tuple(row) for row in data.itertuples(index=False, name=None)]

        # Execute bulk update
        execute_values(cursor, query, values)

        connection.commit()
        print(f"Successfully updated {cursor.rowcount} rows.")

    except Exception as e:
        connection.rollback()
        print(f"Error updating data: {e}")

    finally:
        cursor.close()



def bulk_update_sim_inventory_webbing(data, connection):
    try:
        cursor = connection.cursor()

        # Define correct data types for explicit casting in PostgreSQL
        column_data_types = {
            "carrier_cycle_usage_bytes": "BIGINT",
            "subscription_id": "VARCHAR",
            "imei": "VARCHAR",
            "msisdn": "VARCHAR",
            "sim_status": "VARCHAR",
            "carrier_rate_plan_name": "VARCHAR",
            "carrier_rate_plan_id": "INTEGER",
            "service_provider_id": "INTEGER",
            "service_provider_display_name": "VARCHAR",
            "tenant_id": "INTEGER",
            "is_active": "BOOLEAN",
            "is_deleted": "BOOLEAN",
            "created_by": "VARCHAR",
            "modified_by": "VARCHAR",
            "cost_center": "VARCHAR",
            "billing_period_id": "INTEGER",
            "bill_year": "INTEGER",
            "bill_month": "INTEGER",
            "iccid": "VARCHAR",
            "device_status_id": "INTEGER",
            "integration_id": "INTEGER",
            "carrier_cycle_usage_mb": "NUMERIC",
            "date_activated": "TIMESTAMP",
             "webbing_service_device_id": "VARCHAR",
        }

        # Ensure correct column order
        expected_columns = list(column_data_types.keys())

        # Fill missing columns with NULL values
        for col in expected_columns:
            if col not in data.columns:
                data[col] = None

        # Convert NaN to None for NULL handling in SQL
        data = data.replace({np.nan: None})

        # Convert float columns that should be integer
        integer_columns = ["carrier_rate_plan_id", "service_provider_id", "tenant_id", "billing_period_id", "bill_year", "bill_month", "device_status_id"]
        for col in integer_columns:
            data[col] = data[col].apply(lambda x: int(x) if pd.notnull(x) else 0)  # Replace None with 0

        # Convert text columns to string
        for col, dtype in column_data_types.items():
            if dtype == "VARCHAR":
                data[col] = data[col].astype(str)

        # Ensure correct column order
        data = data[expected_columns]

        # Debugging output
        print("Data Types Before Update:")
        print(data.dtypes)
        print("Sample Row Before Update:")
        print(data.iloc[0])

        # Construct the SET clause with explicit type casting
        set_clause = ", ".join([
            f"{col} = COALESCE(s.{col}::{column_data_types[col]}, t.{col})"
            for col in expected_columns if col != "iccid"
        ])

        # Bulk update query
        query = f"""
        UPDATE sim_management_inventory AS t
        SET {set_clause}
        FROM (VALUES %s) AS s ({', '.join(expected_columns)})
        WHERE t.iccid = s.iccid;
        """

        # Convert DataFrame to list of tuples
        values = [tuple(row) for row in data.itertuples(index=False, name=None)]

        # Execute bulk update
        execute_values(cursor, query, values)

        connection.commit()
        print(f"Successfully updated {cursor.rowcount} rows.")

    except Exception as e:
        connection.rollback()
        print(f"Error updating data: {e}")

    finally:
        cursor.close()

##webbing code this is one of the carrier in the project
import os
import psycopg2
import requests
import xml.etree.ElementTree as ET
import json
from psycopg2.extras import execute_values
##service products
import xmltodict
import logging
import json
import psycopg2
from datetime import datetime, timedelta


'''Main function to call the webbing api and insert the data in the staging table'''
def webbing_dialy_syncs():
    data={}
    username='spectrotel_api'
    password='4AcO#Fo2HZyn'
    ws_key='cx0kJtwRwlFaKY5WoyuHxjN1gtM='
    ##calling clean up function to clean the staging tables
    clean_webbing_staging_tables()
    ##calling the main funciton to insert the data in the staging table
    print('cleaning the staging tables is successfully done')
    main_function_caller_to_insert_data_to_staging(data,username,password,ws_key)
    main_function_caller_to_insert_deactivated_data_to_staging(data,username,password,ws_key)
    ##calling the function to sync the data from staging to main tables to get the products
    result=webbing_product_sync(data,username,password,ws_key)
    ##calling the function to get the usage of the devices
    fetch_and_update_usage_bulk(username,password,ws_key)
    print('successfully called the clean and sync functions')
    tenant_id = os.environ['TENANT_ID']
    webbing_service_provider_id = os.environ['WEBBING_SERVICE_PROVIDER_ID']
    Webbing_mapping_name = os.environ['WEBBING_MAPPING_NAME']
    webbing_tenant_db_name = os.environ['KOREDATABASE']
    insert_webbing_staging_to_main(tenant_id, webbing_service_provider_id, Webbing_mapping_name, webbing_tenant_db_name)
    api_url = os.getenv("OPTIMIZATIONSYNCURL", None)
    time.sleep(40) # To ensure the data is inserted into the required tables before running the reverse sync procedure
    #list_tables_sync = ['device','device_tenant','device_history','device_status_history']
    #for table in list_tables_sync:
    api_payload = {
            "data": {
                "path": "/lambda_sync_jobs_",
                "key_name": "carrier_rev_sync_jobs",
                "tenant_name": "Altaworx Test"
            }
        }
    print(api_payload,'webbingapi_payloadapi_payload')
    # Send the POST request to the API
    print(f"Sending POST request to {api_url} with payload: {api_payload}")
    response = requests.post(api_url, json=api_payload)

    if response.status_code == 200:
        print(f"POST request successful for: {response.json()}")
    else:
        print(f"POST request failed for kore sync: {response.status_code} - {response.text}")
    print('successfully called the clean and sync functions')
    response={"flag":True,"message":"Webbing sync successfully done"}
    return response

# Database connection function
def connect_to_webbing_db(db_name):
    """ Connect to PostgreSQL database """
    try:
        connection = psycopg2.connect(
            host=os.environ["HOST"],
            port=os.environ["PORT"],
            user=os.environ["USER"],
            password=os.environ["PASSWORD"],
            dbname=db_name
        )
        return connection
    except Exception as e:
        print(f"Error connecting to database: {e}")
        return None

# Function to parse XML response to JSON
def xml_to_json(xml_string):
    """Convert XML response to a JSON dictionary"""
    root = ET.fromstring(xml_string)
    namespace = {"soap": "http://www.w3.org/2003/05/soap-envelope"}

    # Extract SOAP Body
    body = root.find("soap:Body", namespace)
    if body is None:
        return []

    response_element = body.find(".//{http://wws.iamwebbing.com/}GetServiceDevicesResult")
    if response_element is None:
        return []

    # Extract service devices
    service_devices = []
    for device in response_element.findall(".//{http://wws.iamwebbing.com/}ServiceDeviceRecord"):
        device_dict = {d.tag.split("}")[-1]: d.text for d in device}
        service_devices.append(device_dict)

    return service_devices

# Function to fetch paginated data from API
def get_service_devices(page_number,username,password,ws_key):
    """Fetch service devices with pagination"""
    url = "https://wws.iamwebbing.com/Devices.asmx"
    headers = {"Content-Type": "application/soap+xml; charset=utf-8"}

    soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                     xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
      <soap12:Header>
        <Credentials xmlns="http://wws.iamwebbing.com/">
          <Username>{username}</Username>
          <Password>{password}</Password>
          <WSKey>{ws_key}</WSKey>
        </Credentials>
      </soap12:Header>
      <soap12:Body>
        <GetServiceDevices xmlns="http://wws.iamwebbing.com/">
          <GetServiceDevicesRequest>
            <OnlyActivePlansDevices>true</OnlyActivePlansDevices>
            <PaginationRequest>
              <PageSize>1000</PageSize>
              <PageNumber>{page_number}</PageNumber>
            </PaginationRequest>
          </GetServiceDevicesRequest>
        </GetServiceDevices>
      </soap12:Body>
    </soap12:Envelope>"""

    try:
        response = requests.post(url, data=soap_body, headers=headers)
        print(f"Response Status Code ({page_number}):", response.status_code)
        return xml_to_json(response.text)

    except requests.exceptions.RequestException as e:
        print("Error:", e)
        return []

def get_deactivated_service_devices(page_number,username,password,ws_key):
    """Fetch service devices with pagination"""
    url = "https://wws.iamwebbing.com/Devices.asmx"
    headers = {"Content-Type": "application/soap+xml; charset=utf-8"}

    soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                     xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
      <soap12:Header>
        <Credentials xmlns="http://wws.iamwebbing.com/">
          <Username>{username}</Username>
          <Password>{password}</Password>
          <WSKey>{ws_key}</WSKey>
        </Credentials>
      </soap12:Header>
      <soap12:Body>
        <GetServiceDevices xmlns="http://wws.iamwebbing.com/">
          <GetServiceDevicesRequest>
            <OnlyActivePlansDevices>false</OnlyActivePlansDevices>
            <SDStatusID>5</SDStatusID>
            <PaginationRequest>
              <PageSize>1000</PageSize>
              <PageNumber>{page_number}</PageNumber>
            </PaginationRequest>
          </GetServiceDevicesRequest>
        </GetServiceDevices>
      </soap12:Body>
    </soap12:Envelope>"""
    try:
        response = requests.post(url, data=soap_body, headers=headers)
        print(f"Response Status Code ({page_number}):", response.status_code)
        return xml_to_json(response.text)

    except requests.exceptions.RequestException as e:
        print("Error:", e)
        return []

def get_iccid_from_service_device_id(service_device_id, username, password, ws_key):
    """Fetch ICCID using ServiceDeviceID from Webbing SOAP API"""
    url = "https://wws.iamwebbing.com/Service.asmx"
    headers = {"Content-Type": "application/soap+xml; charset=utf-8"}

    soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                     xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
      <soap12:Header>
        <Credentials xmlns="http://wws.iamwebbing.com/">
          <Username>{username}</Username>
          <Password>{password}</Password>
          <WSKey>{ws_key}</WSKey>
        </Credentials>
      </soap12:Header>
      <soap12:Body>
        <GetSDLiveData xmlns="http://wws.iamwebbing.com/">
          <GetSDLiveDataRequest>
            <ServiceDeviceIdentifier>
              <ServiceDeviceID>{service_device_id}</ServiceDeviceID>
            </ServiceDeviceIdentifier>
          </GetSDLiveDataRequest>
        </GetSDLiveData>
      </soap12:Body>
    </soap12:Envelope>"""

    try:
        response = requests.post(url, data=soap_body, headers=headers)
        response.raise_for_status()
        root = ET.fromstring(response.text)
        namespace = {"ns": "http://wws.iamwebbing.com/"}
        iccid = root.find(".//ns:ICCID", namespace)
        if iccid is not None:
            return iccid.text.strip()
        else:
            return None
    except Exception as e:
        print(f"Error retrieving ICCID for ServiceDeviceID {service_device_id}: {e}")
        return None

# Function to insert data into PostgreSQL using BULK INSERT
def bulk_insert_webbing_devices(service_devices, username, password, ws_key):
    """Insert into webbing_devices_staging, resolving ICCID if missing"""
    connection = connect_to_webbing_db(os.environ['WEBBINGDATABASE'])
    if connection is None:
        print("DB connection failed.")
        return

    cursor = connection.cursor()

    insert_query = """
    INSERT INTO webbing_devices_staging (
        iccid, serial, device_type_id, device_type_name,
        product_id, product_name, status_id, status_name,
        order_id, service_device_id, assignment_id, branch_id,
        branch_name, account_id, usage_control_id, msisdn,
        apn_id, apn_name
    ) VALUES %s
    """

    valid_values = []

    for device in service_devices:
        iccid = device.get("ICCID")

        # If ICCID is missing, try fetching it from Webbing
        if not iccid and "ServiceDeviceID" in device:
            iccid = get_iccid_from_service_device_id(
                service_device_id=device["ServiceDeviceID"],
                username=username,
                password=password,
                ws_key=ws_key
            )

        # Add to insert list only if ICCID is available
        if iccid:
            valid_values.append((
                iccid,
                device.get("Serial"),
                device.get("DeviceTypeID"),
                device.get("DeviceTypeName"),
                device.get("ProductID"),
                device.get("ProductName"),
                device.get("StatusID"),
                device.get("StatusName"),
                device.get("OrderID"),
                device.get("ServiceDeviceID"),
                device.get("AssignmentID"),
                device.get("BranchID"),
                device.get("BranchName"),
                device.get("AccountID"),
                device.get("UsageControlID"),
                device.get("MSISDN"),
                device.get("ApnID"),
                device.get("ApnName")
            ))

    if not valid_values:
        print("No valid records to insert.")
        return

    try:
        execute_values(cursor, insert_query, valid_values)
        connection.commit()
        print(f"Inserted {len(valid_values)} records successfully.")
    except Exception as e:
        print(f"Error inserting data: {e}")
        connection.rollback()
    finally:
        cursor.close()
        connection.close()
# def bulk_insert_webbing_devices(service_devices):
#     """Bulk insert data into webbing_devices_staging table, ignoring records without ICCID"""
#     connection = connect_to_webbing_db(os.environ['WEBBINGDATABASE'])
#     if connection is None:
#         return

#     cursor = connection.cursor()

#     insert_query = """
#     INSERT INTO webbing_devices_staging (
#         iccid, serial, device_type_id, device_type_name,
#         product_id, product_name, status_id, status_name,
#         order_id, service_device_id, assignment_id, branch_id,
#         branch_name, account_id, usage_control_id, msisdn,
#         apn_id, apn_name
#     ) VALUES %s
#     """

#     # Filter out records that do not have ICCID
#     valid_values = [
#         (
#             device["ICCID"], device.get("Serial"), device.get("DeviceTypeID"),
#             device.get("DeviceTypeName"), device.get("ProductID"), device.get("ProductName"),
#             device.get("StatusID"), device.get("StatusName"), device.get("OrderID"),
#             device.get("ServiceDeviceID"), device.get("AssignmentID"), device.get("BranchID"),
#             device.get("BranchName"), device.get("AccountID"), device.get("UsageControlID"),
#             device.get("MSISDN"), device.get("ApnID"), device.get("ApnName")
#         )
#         for device in service_devices if "ICCID" in device and device["ICCID"]  # Ensures ICCID is present and not empty
#     ]

#     if not valid_values:
#         print("No valid records to insert.")
#         return

#     try:
#         execute_values(cursor, insert_query, valid_values)
#         connection.commit()
#         print(f"Inserted {len(valid_values)} records successfully.")

#     except Exception as e:
#         print(f"Error inserting data: {e}")
#         connection.rollback()

#     finally:
#         cursor.close()
#         connection.close()

# Main loop to fetch data page by page
def main_function_caller_to_insert_data_to_staging(data,username,password,ws_key):
    page_number = 1
    while True:
        print(f"\nFetching Page {page_number}...")
        data = get_service_devices(page_number,username,password,ws_key)

        if not data:  # If no data is returned, stop fetching
            print("\nNo more records found. Stopping pagination.")
            break

        bulk_insert_webbing_devices(data,username,password,ws_key)  # Insert the data into the database
        print('entered here for all status sims')

        if len(data) < 1000:  # If response length is less than 1000, stop fetching
            print(f"\nReceived only {len(data)} records. Stopping pagination.")
            break

        page_number += 1  # Increment page number for next iteration


def main_function_caller_to_insert_deactivated_data_to_staging(data,username,password,ws_key):
    page_number = 1
    while True:
        print(f"\nFetching Page {page_number}...")
        data = get_deactivated_service_devices(page_number,username,password,ws_key)

        if not data:  # If no data is returned, stop fetching
            print("\nNo more records found. Stopping pagination.")
            break

        bulk_insert_webbing_devices(data,username,password,ws_key)  # Insert the data into the database
        print('entered here for deactivated sims')

        if len(data) < 1000:  # If response length is less than 1000, stop fetching
            print(f"\nReceived only {len(data)} records. Stopping pagination.")
            break

        page_number += 1  # Increment page number for next iteration


def clean_webbing_staging_tables():
    """ Clean up staging tables for daily sync """
    connection = connect_to_webbing_db(os.environ['WEBBINGDATABASE'])  # Static DB for cleanup
    if connection:
        cursor = connection.cursor()

        try:
            # Define the cleanup SQL queries for staging tables
            delete_query_plan = "DELETE FROM webbing_devices_staging;"
            # Execute the delete queries
            cursor.execute(delete_query_plan)
            # Commit the transaction to apply the changes
            connection.commit()
            print("Successfully cleaned up the webbing staging tables.")
        except Exception as e:
            print(f"Error cleaning up staging tables: {e}")
            connection.rollback()  # Rollback in case of error

        finally:
            # Close the cursor and connection
            cursor.close()
            connection.close()
    else:
        print("Failed to connect to the database.")




def get_products_list(username,password,ws_key,page_number):
    url = "https://wws.iamwebbing.com/service/Service.asmx"
    headers = {
        "Content-Type": "text/xml; charset=utf-8",
        "SOAPAction": "http://wws.iamwebbing.com/GetProductsList"
    }

    soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <soap:Header>
    <Credentials xmlns="http://wws.iamwebbing.com/">
    <Username>{username}</Username>
    <Password>{password}</Password>
    <WSKey>{ws_key}</WSKey>
    </Credentials>
    </soap:Header>
    <soap:Body>
    <GetProductsList xmlns="http://wws.iamwebbing.com/">
    <GetProductsRequest>
    <PaginationRequest>
    <PageSize>1000</PageSize>
    <PageNumber>{page_number}</PageNumber>
    </PaginationRequest>
    </GetProductsRequest>
    </GetProductsList>
    </soap:Body>
    </soap:Envelope>"""

    response = requests.post(url, data=soap_body, headers=headers)
    logging.info(f"Response Status Code: {response.status_code}")

    if response.status_code == 200:
        xml_data = response.text
        json_data = xmltodict.parse(xml_data)

        # Debugging: Print full response structure
        print(json.dumps(json_data, indent=4))

        # Extract the products list
        try:
            products = json_data["soap:Envelope"]["soap:Body"]["GetProductsListResponse"]["GetProductsListResult"]["Products"]["ProductRecord"]

            return products
        except KeyError:
            return "Error: Unable to parse products from response. Check printed JSON structure."
    else:
        return f"Error: Received status code {response.status_code}"

def bulk_insert_service_products(service_products):
    """Bulk insert service products into the database"""
    connection = connect_to_webbing_db(os.environ['WEBBINGDATABASE'])
    if connection is None:
        return

    cursor = connection.cursor()

    insert_query = """
    INSERT INTO webbing_service_products_staging (product_id, product_name)
    VALUES %s
    """

    values = [(product.get("ID"), product.get("Name")) for product in service_products]

    try:
        execute_values(cursor, insert_query, values)
        connection.commit()
        print(f"Inserted {len(values)} product records successfully.")

    except Exception as e:
        print(f"Error inserting product data: {e}")
        connection.rollback()

    finally:
        cursor.close()
        connection.close()

def main_function_caller_to_insert_products(data,username,password,ws_key):
    page_number = 1
    while True:
        print(f"\nFetching Product Page {page_number}...")
        products = get_products_list(username,password,ws_key,page_number)

        if not products:
            print("\nNo more product records found. Stopping pagination.")
            break
        bulk_insert_service_products(products)

        if len(products) < 1000:
            print(f"\nReceived only {len(products)} products. Stopping pagination.")
            break

        page_number += 1

def clean_webbing_products_staging():
    """ Clean up products staging table """
    connection = connect_to_webbing_db(os.environ['WEBBINGDATABASE'])
    if connection:
        cursor = connection.cursor()

        try:
            cursor.execute("DELETE FROM webbing_service_products_staging;")
            connection.commit()
            print("Successfully cleaned up the webbing products staging table.")
        except Exception as e:
            print(f"Error cleaning up products staging table: {e}")
            connection.rollback()
        finally:
            cursor.close()
            connection.close()

def webbing_product_sync(data,username,password,ws_key):
    clean_webbing_products_staging()
    main_function_caller_to_insert_products(data,username,password,ws_key)
    print('Successfully cleaned and synced webbing products.')
    return {"flag": True, "message": "Webbing product sync successfully done"}



# Get previous day's start and end date
def get_previous_day_dates():
    yesterday = datetime.now() - timedelta(days=1)
    start_date = yesterday.strftime("%m/%d/%Y")  # Start of previous day
    end_date = yesterday.strftime("%m/%d/%Y")    # End of previous day
    return start_date, end_date

# Function to fetch API data and update DB in bulk
def fetch_and_update_usage_bulk(username,password,ws_key):
    # API details
    API_URL = "https://wws.iamwebbing.com/usage/Usage.asmx"
    HEADERS = {
        "Content-Type": "text/xml; charset=utf-8",
        "SOAPAction": "http://wws.iamwebbing.com/GetDeviceUsage",
    }
    start_date, end_date = get_previous_day_dates()
    page_number = 1
    page_size = 1000
    bulk_data = []  # Store records for bulk update

    # Connect to database
    conn = connect_to_webbing_db(os.environ['WEBBINGDATABASE'])
    if conn is None:
        return

    cursor = conn.cursor()

    while True:
        # SOAP Request Body
        soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                       xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                       xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
        <soap:Header>
        <Credentials xmlns="http://wws.iamwebbing.com/">
        <Username>{username}</Username>
        <Password>{password}</Password>
        <WSKey>{ws_key}</WSKey>
        </Credentials>
        </soap:Header>
        <soap:Body>
        <GetDeviceUsage xmlns="http://wws.iamwebbing.com/">
        <GetDeviceUsageRequest>
        <StartDate>{start_date}</StartDate>
        <EndDate>{end_date}</EndDate>
        <PaginationRequest>
        <PageSize>{page_size}</PageSize>
        <PageNumber>{page_number}</PageNumber>
        </PaginationRequest>
        </GetDeviceUsageRequest>
        </GetDeviceUsage>
        </soap:Body>
        </soap:Envelope>"""

        # API Call
        response = requests.post(API_URL, data=soap_body, headers=HEADERS)
        if response.status_code != 200:
            print(f"Error: {response.status_code}\n{response.text}")
            break

        # Parse XML Response
        response_dict = xmltodict.parse(response.text)
        json_data = json.loads(json.dumps(response_dict))  # Convert to JSON

        # Extract DeviceUsageRecord data
        device_usage_records = json_data.get("soap:Envelope", {}).get("soap:Body", {}).get(
            "GetDeviceUsageResponse", {}).get("GetDeviceUsageResult", {}).get("Usage", {}).get("DeviceUsageRecord", [])

        if not isinstance(device_usage_records, list):
            device_usage_records = [device_usage_records]  # Convert single record to list

        # Prepare bulk update data
        for record in device_usage_records:
            iccid = record.get("ICCID", "")
            imei = record.get("IMEI", "")
            total_usage_days = record.get("TotalUsageDays", "")
            total_usage = record.get("TotalUsage", "")

            if iccid:
                bulk_data.append((total_usage_days, total_usage, imei, iccid))

        # Break loop if records are less than page_size
        if len(device_usage_records) < page_size:
            break

        # Move to next page
        page_number += 1

    # Perform bulk update in one query
    if bulk_data:
        update_query = """
        UPDATE public.webbing_devices_staging AS wds
        SET
            total_usage_days = data.total_usage_days,
            total_usage = data.total_usage,
            imei = data.imei
        FROM (VALUES %s) AS data(total_usage_days, total_usage, imei, iccid)
        WHERE wds.iccid = data.iccid;
        """
        execute_values(cursor, update_query, bulk_data)
        conn.commit()

    cursor.close()
    conn.close()
    print("Updated the device Usage successfully in bulk.")



import pandas as pd
import numpy as np
##webbing code this is one of the carrier in the project
import os
import psycopg2
import requests
from psycopg2 import extras

import xml.etree.ElementTree as ET
import json
from psycopg2.extras import execute_values
##service products
import xmltodict
import logging
import json
import psycopg2
from datetime import datetime, timedelta


def insert_webbing_staging_to_main(tenant_id, service_provider_id, mapping_name, tenant_db_name):
    """ Insert data from staging table to the main table based on mappings """
    try:
        # Establish the connection to fetch the mappings from the 'Migration_Test' database
        connection = connect_to_webbing_db('Migration_Test')  # Static DB for mappings
        if not connection:
            print("Failed to connect to the database.")
            return

        # Load the mappings of the table
        mappings_query = f"""
            SELECT * FROM stagging_table_mappings
            WHERE tenant_id='{tenant_id}' AND service_provider_id='{service_provider_id}' AND mapping_name='{mapping_name}'
        """
        mappings_data = fetch_data_from_db(mappings_query, connection)
        print('mappings_data',mappings_data)
        if not mappings_data:
            print(f"No mappings found for tenant_id={tenant_id}, service_provider_id={service_provider_id}, mapping_name={mapping_name}")
            return

        # Close connection after fetching mappings
        connection.close()

        # Establish a new connection to the tenant's database (dynamic dbname)
        connection = connect_to_webbing_db(tenant_db_name)
        if not connection:
            print(f"Failed to connect to the tenant's database: {tenant_db_name}")
            return

        # Load data from staging table in the tenant's database
        staging_query = "SELECT * FROM webbing_devices_staging"  # You can adjust the limit as needed
        staging_data = fetch_data_from_db(staging_query, connection)
        # Close the connection after fetching data
        connection.close()

        # Extract mappings
        columns_mapping = mappings_data[0]['cols_mapping']
        tables_mapping = mappings_data[0]['table_mapping']

        # Determine the source and target tables
        from_table_name = list(tables_mapping.keys())[0]
        to_tables = tables_mapping[from_table_name]

        # Reconnect for data insertion
        connection = connect_to_webbing_db(tenant_db_name)
        if not connection:
            print(f"Failed to reconnect to the tenant's database: {tenant_db_name}")
            return False

        # to get the billing details
        billing_query = f"select * from billing_period where tenant_id = {tenant_id} and service_provider_id = {service_provider_id} and is_active = 'true' limit 1"
        billing_data = fetch_data_from_db(billing_query, connection)
        print("Billing data fetched successfully: {}",billing_data)
        if billing_data:
            bill_year = int(billing_data[0]['bill_year'])
            bill_month = int(billing_data[0]['bill_month'])
            billing_period_id = int(billing_data[0]['id'])
        else:
            bill_year = ''
            bill_month = ''
            billing_period_id = ''

        # Loop through the target tables and perform the insert
        for table in to_tables:
            # Get column mappings for the table
            mapping = columns_mapping[table]

            # Step 1: Rename columns in the staging data according to the mapping
            transformed_df = pd.DataFrame(staging_data).rename(columns=mapping)

            # Step 2: Select only the columns that are mapped
            transformed_df = transformed_df[list(mapping.values())]
            # Special handling for specific tables (like 'sim_management_inventory')
            if table == 'sim_management_inventory':
                transformed_df['service_provider_id'] = int(mappings_data[0]['service_provider_id'])
                transformed_df['service_provider_display_name'] = mappings_data[0]['service_provider_name']
                transformed_df['tenant_id'] = int(mappings_data[0]['tenant_id'])
                transformed_df['is_active'] = True
                transformed_df['is_deleted'] = False
                transformed_df['tenant_is_active'] = True
                transformed_df['tenant_is_deleted'] = False
                transformed_df['created_by'] = 'Webbing_Container'
                transformed_df['cost_center'] = ''
                transformed_df['billing_period_id'] = billing_period_id
                transformed_df['bill_year'] = bill_year
                transformed_df['bill_month'] = bill_month
                transformed_df['integration_id'] = os.environ['WEBBING_INTEGRATION_ID']
                if 'sim_status' in transformed_df.columns:
                    transformed_df['sim_status'] = transformed_df['sim_status']
                # First, fetch device status mappings from device_stat
                integration_id =os.environ['WEBBING_INTEGRATION_ID']
                device_status_query = f"SELECT id, status FROM device_status WHERE integration_id = {integration_id}"
                device_status_data = fetch_data_from_db(device_status_query, connection)
                carrier_rate_plan_id_query = f"SELECT id, rate_plan_short_name FROM carrier_rate_plan WHERE service_provider_id = {service_provider_id}"
                carrier_rate_data = fetch_data_from_db(carrier_rate_plan_id_query, connection)
                print('carrier_rate_data',carrier_rate_data)
                # Create a mapping dictionary: {rate_plan_short_name: id}
                carrier_rate_mapping = {item['rate_plan_short_name'].strip(): item['id'] for item in carrier_rate_data}

                if 'carrier_rate_plan_name' in transformed_df.columns:
                    # Strip spaces but keep original case
                    transformed_df['carrier_rate_plan_name'] = transformed_df['carrier_rate_plan_name'].str.strip()

                    # Map carrier_rate_plan_id based on carrier_rate_plan_name
                    transformed_df['carrier_rate_plan_id'] = transformed_df['carrier_rate_plan_name'].map(carrier_rate_mapping)
                # # Normalize status keys by converting them to lowercase
                # Maintain original case (remove .lower())
                status_to_id_mapping = {item['status'].strip(): item['id'] for item in device_status_data}
                if 'sim_status' in transformed_df.columns:
                    # Map the normalized sim_status values to device_status_id
                    transformed_df['sim_status'] = transformed_df['sim_status'].str.strip()

                    # Map the normalized sim_status values to device_status_id
                    transformed_df['device_status_id'] = transformed_df['sim_status'].map(status_to_id_mapping)

                query_sim = "SELECT iccid FROM sim_management_inventory where service_provider_display_name = 'Webbing'"
                inventory_data = fetch_data_from_db(query_sim, connection)

                inventory_df = pd.DataFrame(inventory_data)  # Convert list of dicts to DataFrame
                print('Entered here successfully fetched the inventory data',inventory_df)
                if not inventory_df.empty and 'iccid' in inventory_df.columns:
                    exist_data = transformed_df[transformed_df['iccid'].isin(inventory_df['iccid'])]
                else:
                    # Create an empty DataFrame with 'iccid' column to avoid KeyError
                    inventory_df = pd.DataFrame(columns=['iccid'])
                    exist_data = pd.DataFrame()  # Empty DataFrame if no records exist




                # Convert empty strings to None
                transformed_df.replace('', None, inplace=True)

                # Drop columns with missing values **only for that row**
                transformed_df = transformed_df.apply(lambda row: row.dropna(), axis=1)

                # Drop rows where 'iccid' is missing
                transformed_df.dropna(subset=['iccid'], inplace=True)

                # Perform bulk update only if data exists
                if not exist_data.empty:
                    print('entered here')
                    print(transformed_df.columns,'transformed_df columns')
                    print('transformed_dfffffffffffffffffffffffffffffffffffff',transformed_df)
                    integer_columns = ["carrier_cycle_usage_bytes", "carrier_rate_plan_id", "service_provider_id", "device_status_id"]

                    for col in integer_columns:
                        if col in transformed_df.columns:
                            transformed_df[col] = transformed_df[col].apply(lambda x: int(float(x)) if pd.notnull(x) else 0)
                    bulk_update_sim_inventory_webbing(transformed_df, connection)
                    print('updated')

                print('transformed_df.columns',transformed_df.columns)
                print('inventory_df.columns',inventory_df.columns)
                # Ensure 'iccid' column exists
                if 'iccid' in transformed_df.columns and 'iccid' in inventory_df.columns:
                    # Convert to string for correct matching
                    transformed_df['iccid'] = transformed_df['iccid'].astype(str)
                    inventory_df['iccid'] = inventory_df['iccid'].astype(str)

                    # Drop NaN values
                    inventory_df = inventory_df.dropna(subset=['iccid'])

                    # Remove rows where 'iccid' exists in inventory_df
                    transformed_df = transformed_df[~transformed_df['iccid'].isin(inventory_df['iccid'])]

                    print("Filtering complete. Remaining rows:", len(transformed_df))
                else:
                    print("Error: 'iccid' column missing in one of the DataFrames!")


                print('transformed_dfffffffffffffffffffffffffffffffffffff',transformed_df)
                # Perform bulk insert only if data exists
                if not transformed_df.empty:
                    print(transformed_df.columns,'transformed_df columns')
                    print('transformed_dfffffffffffffffffffffffffffffffffffff',transformed_df)
                    integer_columns = ["carrier_cycle_usage_bytes", "carrier_rate_plan_id", "service_provider_id", "device_status_id"]

                    for col in integer_columns:
                        if col in transformed_df.columns:
                            transformed_df[col] = transformed_df[col].apply(lambda x: int(float(x)) if pd.notnull(x) else 0)

                    bulk_insert_to_db(transformed_df, 'sim_management_inventory', connection)
                    print('Data inserted successfully')

        # Close the connection after insertion
        connection.close()

        print("Data insertion complete.")
        return {"flag": True, "message": "Data inserted successfully in to main tables."}
    except Exception as e:
        print(f"Error during staging to main insertion: {e}")

##Telgo functionalities
'''Telgo functionalities'''



###Telgo5 Implementation

###Telgo5 Implementation
def initiate_telgoo5_sim_deactivation_sync():
    """Initiate the Telgoo5 SIM deactivation sync process by reading the latest Excel file from SFTP and deleting it."""
    try:
        connection = connect_to_db(os.getenv("COMMON_UTILS_DATABASE"))  # Static DB for common utilities
        # Read from environment variables
        sftp_host = os.getenv("SFTP_HOST")
        sftp_port = int(os.getenv("SFTP_PORT", 22))  # Default to 22
        sftp_username = os.getenv("SFTP_USERNAME")
        private_key_path = os.getenv("SFTP_PRIVATE_KEY_PATH")
        remote_dir_path = os.getenv("SFTP_REMOTE_DIR_PATH")
        backup_dir_path = os.getenv("SFTP_REMOTE_DIR_PATH_BACKUP")
        # Ensure all required environment variables are set
        key = paramiko.RSAKey.from_private_key_file(private_key_path)
        # Connect to SFTP server
        transport = paramiko.Transport((sftp_host, sftp_port))
        transport.connect(username=sftp_username, pkey=key)
        # Create SFTP client from the transport
        sftp = paramiko.SFTPClient.from_transport(transport)
        print(f"Connected to SFTP server at {sftp_host}:{sftp_port} as {sftp_username}")
        files = sftp.listdir(remote_dir_path)
        print(f"Files in SFTP folder: {files}")

        df = pd.DataFrame()  # Default empty
        if files:
            excel_files = [f for f in files if f.endswith(".xlsx")]
            if excel_files:
                latest_file = sorted(excel_files)[-1]
                full_path = os.path.join(remote_dir_path, latest_file)
                backup_path = os.path.join(backup_dir_path, latest_file)

                # Read Excel file
                with sftp.open(full_path, 'rb') as file_obj:
                    excel_data = file_obj.read()
                    df = pd.read_excel(io.BytesIO(excel_data))
                    print(f"\n--- Content of {latest_file} ---\n")
                    print(df['MDN'].tolist(),' MDN values in the file')
                try:
                    sftp.listdir(backup_dir_path)  # will raise IOError if it doesn't exist
                except IOError:
                    print(f"Backup directory {backup_dir_path} does not exist, creating it...")
                    sftp.mkdir(backup_dir_path)

                # Write backup file
                try:
                    with sftp.file(backup_path, 'wb') as backup_file:
                        backup_file.write(excel_data)
                    print(f"{latest_file} copied to backup directory.")
                except Exception as e:
                    print(f"Error copying file to backup directory: {e}")
                print(f"{latest_file} copied to backup directory.")
                # Delete the file after reading
                sftp.remove(full_path)
                print(f"{latest_file} deleted from SFTP.")
            else:
                print("No Excel files found in the SFTP directory.")
        else:
            print("No files found in the SFTP directory.")

        sftp.close()
        transport.close()

        # === If data exists, send POST request ===
        if not df.empty and 'MDN' in df.columns:
            msisdns = df['MDN'].astype(str).tolist()
            total = len(df)
            batch_size = 2500
            responses = []
            for i in range(0, total, batch_size):
                batch = msisdns[i:i + batch_size]
                logging.info(f"Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                status, text = send_deactivation_request(batch)
                responses.append({"batch": i // batch_size + 1, "status": status, "response": text})

                # Audit for each batch
                try:
                    audit_df = log_audit_actions(batch)
                    bulk_insert_to_db(audit_df, 'audit_user_actions', connection)
                except Exception as e:
                    logging.warning(f"### Audit logging failed for batch {i // batch_size + 1}: {e}")
            return {
            "flag": True,
            "message": "Telgo5 Deactivation completed in batches",
            "batches": responses
                }
        else:
            print("No valid data to send or 'MDN' column missing.")
            response={"flag": True, "message": "Data is not valid", "data": df}
            error_df = prepare_error_df("No valid data to send or 'MDN' column missing", "error_type", "Telgo5Admin", "Altaworx")
            bulk_insert_to_db(error_df, 'error_log_table', connection)
            return response
    except Exception as e:
        print(f"Error during Telgoo5 SIM deactivation sync: {e}")
        return {"flag": False, "message": str(e), "data": pd.DataFrame()}

def send_deactivation_request(msisdn_list):
    url = os.getenv("DEVICE_STATUS_API_URL")
    payload = {
        "service_provider": os.getenv("TELGOSERVICEPROVIDER", ""),
        "msisdn": msisdn_list,
        "z_access_token": os.getenv("Z_ACCESS_TOKEN"),
        "reasonCode": "CAN",
        "changed_data": {"UpdateStatus": "C"},
    }
    resp = requests.post(url, json=payload, headers={"Content-Type": "application/json"})
    return resp.status_code, resp.text

def log_audit_actions(msisdns: list) -> pd.DataFrame:
    audit_data_user_actions = {
        "service_name": ["initiate_telgoo5_sim_deactivation_sync"],
        "created_date": [datetime.now().strftime("%Y-%m-%d %H:%M:%S")],
        "created_by": ["Telgo5Admin"],
        "status": ["Success"],
        "tenant_name": ["Altaworx"],
        "module_name": ["Telgo5 SIM Deactivation"],
        "comments": [f"Telgo5 SIM deactivation initiated for {len(msisdns)} MSISDNs and sims are {msisdns}"],
        "request_received_at": [datetime.now().strftime("%Y-%m-%d %H:%M:%S")]
    }

    df_audit = pd.DataFrame.from_dict(audit_data_user_actions)
    return df_audit

def prepare_error_df(error_message: str, error_type: str,
                     username: str, tenant_name: str) -> pd.DataFrame:
    error_data = {
        "service_name": ["Telgo5 SIM Deactivation"],
        "created_date": [datetime.now().strftime("%Y-%m-%d %H:%M:%S")],
        "error_message": [error_message],
        "error_type": [error_type],
        "users": [username],
        "tenant_name": [tenant_name],
        "comments": [f"Error occurred during deactivation invalid format"],
        "module_name": ["Bulk Change"],
        "request_received_at": [datetime.now().strftime("%Y-%m-%d %H:%M:%S")],
    }

    df_error = pd.DataFrame.from_dict(error_data)
    return df_error

