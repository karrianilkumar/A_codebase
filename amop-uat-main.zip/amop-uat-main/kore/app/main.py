"""
@author: Gopi Teja
Created Date: 2022-11-23
"""

from flask import Flask, request, jsonify
import json
try:
    from kore import Kore_daily_syncs,clean_daily_sync,webbing_dialy_syncs,initiate_telgoo5_sim_deactivation_sync
except:
    from app.kore import Kore_daily_syncs,clean_daily_sync,webbing_dialy_syncs,initiate_telgoo5_sim_deactivation_sync

app = Flask(__name__)

@app.route('/run_scheduled_sync_tasks', methods=['POST'])
def kore_daily_sync():
    data = request.get_json()
    tenant_id = data.get('tenant_id', '')
    print(f"#### Running Kore Daily Sync for {tenant_id}")
    path=data.get('path','')
    print(f"#### Running Kore Daily Sync for {path}")
    if path=='/kore_dialy_sync':
        result=Kore_daily_syncs()
    elif path=='/clean_daily_sync':
        result=clean_daily_sync()
    elif path=='/webbing_dialy_syncs':
        result=webbing_dialy_syncs()
    elif path=='/initiate_telgoo5_sim_deactivation_sync':
        result=initiate_telgoo5_sim_deactivation_sync()
    print(f"#### Running Kore Daily Sync result for {result}")

    # Call your kore_daily_sync logic here
    # Example: kore_daily_sync(tenant_id)

    # If kore_daily_sync is a function, call it here:
    # kore_daily_sync(tenant_id)

    return jsonify({"message": f"Sync started for tenant {tenant_id}"}), 200

if __name__ == "__main__":
    print(f'the main.py is calling')
    app.run(host='0.0.0.0', port=5000)  # Listen on all interfaces
        # Define processes for each task

