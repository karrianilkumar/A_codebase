
# Main
"""
main.py

Module for handling API requests and routing them to the appropriate function.

Functions:
- lambda_handler(event,context=None)

Author: Srikanth R
Date: December 26, 2024
"""

import json
import time
import os
import boto3
import pytz
import datetime
from datetime import datetime
from common_utils.email_trigger import get_memory_usage, memory_sns
from customer_profiles import (
    customer_profiles_list_view,add_customer_profile,customer_basic_details,billing_collections_bills_list_view,billing_collections_ledger_list_view,update_customer_basic_details,unposted_bills_list_view,add_bill,unposted_reverse_transaction,get_token,customer_services_list_view,charge_overview_list_view,add_customer_service,charge_by_service_list_view, customer_deposit_pop_up,edit_service_location,charge_overview_export,charge_by_service_export,get_export_status,customer_service_products_pop_list_view,get_customer_transaction_history,update_customer_basic_details_deposits,change_payment_mode,service_products_headermap_data,payment_history_list_view,bill_export,update_customer_service,generate_bill_pdf,update_transaction_status,check_bill_cycle_date,update_payment_transaction_id_status,customer_payment_profile_data,customer_services_export,customer_payments_export,generate_bill_excel,
    unposted_export,adjust_bill_amount,ledger_export,save_pdf_template, fetch_default_settings, update_defualt_settings,collection_steps_list_view,collection_steps_list_view_save,upload_pdf_to_s3,products_list_view_in_add_service_pop,download_bulk_upload_services_template,import_bulk_data, fetch_specify_amount_to_bill, assigned_accounts, download_credit_charge_template, import_credit_charge_bulk_upload,update_service_products,
    bill_template_management_list_view, save_bill_template, delete_bill_template,download_to_reupload_services_template,reupload_customer_services,product_prorate_calculation,bill_creation_from_unposted_charges,get_products_packages_by_service_type,fetch_account_details,apply_credits_to_bill,late_fee_scheduler,assign_customer_service_line_creation,update_customer_rate_plan_service_line_creation,bulk_update_customer_rate_plan_service_line_creation,bulk_update_device_status_service_line_creation,bulk_update_iccid_imei_service_line_creation,check_prorate_insert_to_unposted_,bulk_update_assign_customer_service_line_creation,bulk_update_device_status,get_bp_status,update_device_status_service_line_creation,transfer_service_date_validation,service_line_creation_from_transfer_service,
    bill_reversal_update,bill_reversal_list_view,reverals_export,reversals_reverse_transaction,test_file,create_reversal_bill,fetch_customer_rate_plan_details,upload_bulk_service_lines_data,reupload_existed_service_line_data,get_reposted_mrcs,save_reposted_mrcs,update_profiles, get_taxes_unposted,fetch_customer_rate_plan_details_by_service_type,get_usage_for_past_bill_cycle, download_bulk_upload_service_types_template,bill_creation_from_unposted_charges_01_09
)
# from customer_profiles import (
#     customer_profiles_list_view,add_customer_profile,customer_basic_details,billing_collections_bills_list_view,billing_collections_ledger_list_view,update_customer_basic_details,unposted_bills_list_view,add_bill,unposted_reverse_transaction,get_token,customer_services_list_view,charge_overview_list_view,add_customer_service,charge_by_service_list_view, customer_deposit_pop_up,edit_service_location,charge_overview_export,charge_by_service_export,get_export_status,customer_service_products_pop_list_view,get_customer_transaction_history,update_customer_basic_details_deposits,change_payment_mode,service_products_headermap_data,payment_history_list_view,bill_export,update_customer_service,generate_bill_pdf,update_transaction_status,check_bill_cycle_date,update_payment_transaction_id_status,customer_payment_profile_data,customer_services_export,authorize_net_webhook_response,customer_payments_export,webhook_response_for_calculation,generate_bill_excel,
#     unposted_export,adjust_bill_amount
# )
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging
from common_utils.authentication_check import validate_token, Validate_Ui_token
from common_utils.permission_manager import PermissionManager
from common_utils.authentication_check import get_client_id


# Dictionary to store database configuration settings retrieved from environment variables.
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}
logging = Logging(name="main")

# Initialize the SNS client
sns = boto3.client("sns")
cloudwatch = boto3.client("cloudwatch")


def lambda_handler(event, context):
    """
    Handles incoming API requests and routes them to the appropriate function.

    Args:
        event (dict): The incoming API request event.

    Returns:
        dict: A dictionary containing the response status code and body.

    Example:
        >>> event = {'data': {'path': '/get_modules'}}
        >>> lambda_handler(event)
        {'statusCode': 200, 'body': '{"flag": True, "modules": [...]}'}
    """
    function_name = context.function_name if context else "sim_management"
    logging.info("Lambda function started: %s", function_name)

    # Record the start time of the function
    performance_matrix = {}
    start_time = time.time()
    performance_matrix["start_time"] = (
        f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time))}."
        f"{int((start_time % 1) * 1000):03d}"
    )

    # Extract the HTTP method, path and query string parameters from the event
    data = event.get("data")
    print('####data',data)
    if not data:
        return {"message": "No details provided or Invalid details", "status_code": 400}

    if data:
        try:
            data = data
        except json.JSONDecodeError:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid JSON in body"}),
            }
    else:
        data = {}

    if "data" in data:
        print('###entred into if')
        data = data.get("data")

    service_path = event.get("path")
    if service_path:
        data["path"] = service_path

    path = data.get("path")
    print('###path',path)

    result = {}
    # token validation
    verified_request = True
    access_token = data.get("z_access_token", "")
    ui_token = data.get("access_token", "")

    if not access_token and not ui_token:
        result = {"message": "MISSING TOKEN"}
        result["status_code"] = 401
        verified_request = False

    if access_token:
        client_id = get_client_id(access_token)
        data["client_id"] = client_id
    if access_token and not validate_token(access_token):
        client_id = get_client_id(access_token)
        data["client_id"] = client_id
        result = {"message": "INVALID TOKEN"}
        result["status_code"] = 401
        verified_request = False
    # permission validation
    if verified_request:
        permission_manager_instance = PermissionManager(db_config)
        result = permission_manager_instance.permission_manager(data)
        print(f"Permission manager result is {result}")
        if isinstance(result, dict) and result.get("flag") is False:
            verified_request = False
            result["flag"] = False
        data["carrier_api_status"] = result.get("api_status", False)
    # username = data.get('username')
    # elif ui_token and not Validate_Ui_token(username,access_token) and verified_request:
    #     result = {"message": "INVALID TOKEN"}
    #     result["status_code"] = 401
    #     verified_request=False

    if verified_request:
        permission_manager_instance = PermissionManager(db_config)
        result = permission_manager_instance.permission_manager(data)
        print(f"Permission manager result is {result}")
        if isinstance(result, dict) and result.get("flag") is False:
            verified_request = False
            result["flag"] = False
        data["carrier_api_status"] = result.get("api_status", False)
    # Capture the hit time when the request is received (same as before)
    hit_time = time.time()
    hit_time_formatted = datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
        "%Y-%m-%d %H:%M:%S"
    )
    logging.info(
        f"Hit Time: {hit_time_formatted}, Request Received at: {hit_time_formatted}"
    )

    request_received_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info("Routing request for path: %s", path)
    # Route based on the path and method
    if path=='/customer_profiles_list_view':
        result=customer_profiles_list_view(data)
    elif path=='/add_customer_profile':
        result=add_customer_profile(data)
    elif path=='/customer_basic_details':
        result=customer_basic_details(data)
    elif path=='/billing_collections_bills_list_view':
        result=billing_collections_bills_list_view(data)
    elif path=='/billing_collections_ledger_list_view':
        result=billing_collections_ledger_list_view(data)
    elif path=='/update_customer_basic_details':
        result=update_customer_basic_details(data)
    elif path=='/unposted_bills_list_view':
        result=unposted_bills_list_view(data)
    elif path=='/add_bill':
        result=add_bill(data)
    elif path=='/unposted_reverse_transaction':
        result=unposted_reverse_transaction(data)
    elif path=='/get_token':
        result=get_token(data)
    elif path=='/customer_services_list_view':
        result=customer_services_list_view(data)
    elif path=='/charge_overview_list_view':
        result=charge_overview_list_view(data)
    elif path=='/add_customer_service':
        result=add_customer_service(data)
    elif path=='/charge_by_service_list_view':
        result=charge_by_service_list_view(data)
    elif path=='/edit_service_location':
        result=edit_service_location(data)
    elif path=='/customer_deposit_pop_up':
        result=customer_deposit_pop_up(data)
    elif path=='/charge_overview_export':
        result=charge_overview_export(data)
    elif path=='/charge_by_service_export':
        result=charge_by_service_export(data)
    elif path=='/get_export_status':
        result=get_export_status(data)
    elif path=='/customer_service_products_pop_list_view':
        result=customer_service_products_pop_list_view(data)
    elif path=='/get_customer_transaction_history':
        result=get_customer_transaction_history(data)
    elif path== '/update_customer_basic_details_deposits':
        result=update_customer_basic_details_deposits(data)
    elif path=='/change_payment_mode':
        result=change_payment_mode(data)
    elif path=='/service_products_headermap_data':
        result=service_products_headermap_data(data)
    elif path=='/payment_history_list_view':
        result=payment_history_list_view(data)
    elif path=='/bill_export':
        result=bill_export(data)
    elif path=='/update_customer_service':
        result=update_customer_service(data)
    elif path=='/generate_bill_pdf':
        result=generate_bill_pdf(data)
    elif path=='/update_transaction_status':
        result=update_transaction_status(data)
    elif path == "/check_bill_cycle_date":
        result = check_bill_cycle_date()
    elif path == "/update_profiles":
        result = update_profiles()
    elif path=="/update_payment_transaction_id_status":
        result=update_payment_transaction_id_status()
    elif path=="/customer_payment_profile_data":
        result=customer_payment_profile_data(data)
    elif path=="/customer_services_export":
        result=customer_services_export(data)
    # elif path=='/authorize_net_webhook_response':
    #     print('####entred into webhook')
    #     result=authorize_net_webhook_response(event, context)
    elif path=='/customer_payments_export':
        result=customer_payments_export(data)
    # elif path=='/webhook_response_for_calculation':
    #     result=webhook_response_for_calculation(event, context)
    elif path=='/generate_bill_excel':
        result=generate_bill_excel(data)
    elif path== '/unposted_export':
        result = unposted_export(data)
    elif path== '/adjust_bill_amount':
        result = adjust_bill_amount(data)
    elif path== '/ledger_export':
        result = ledger_export(data) 
    elif path== '/save_pdf_template':
        result = save_pdf_template(data) 
    elif path == '/fetch_default_settings':
        result = fetch_default_settings(data)
    elif path == '/update_defualt_settings':
        result = update_defualt_settings(data)
    elif path == '/collection_steps_list_view':
        result = collection_steps_list_view(data)
    elif path=='/collection_steps_list_view_save':
        result=collection_steps_list_view_save(data)
    elif path=='/upload_pdf_to_s3':
        result=upload_pdf_to_s3(data)
    elif path=='/products_list_view_in_add_service_pop':
        result=products_list_view_in_add_service_pop(data)
    elif path=='/download_bulk_upload_services_template':
        result=download_bulk_upload_services_template(data)
    elif path=='/import_bulk_data':
        result=import_bulk_data(data) 
    elif path=='/fetch_specify_amount_to_bill':
        result=fetch_specify_amount_to_bill(data)
    elif path=='/assigned_accounts':
        result=assigned_accounts(data)
    elif path=='/download_credit_charge_template':
        result=download_credit_charge_template(data)
    elif path=='/import_credit_charge_bulk_upload':
        result=import_credit_charge_bulk_upload(data)
    elif path=='/update_service_products':
        result=update_service_products(data)
    elif path=='/bill_template_management_list_view':
        result=bill_template_management_list_view(data)
    elif path=='/save_bill_template':
        result=save_bill_template(data)
    elif path=='/delete_bill_template':
        result=delete_bill_template(data)
    elif path=='/download_to_reupload_services_template':
        result=download_to_reupload_services_template(data)
    elif path=='/reupload_customer_services':
        result=reupload_customer_services(data)
    elif path=='/product_prorate_calculation':
        result=product_prorate_calculation()
    elif path=='/bill_creation_from_unposted_charges':
        result=bill_creation_from_unposted_charges(data)
    elif path=='/get_products_packages_by_service_type':
        result=get_products_packages_by_service_type(data)
    elif path=='/fetch_account_details':
        result=fetch_account_details(data)
    elif path=='/apply_credits_to_bill':
        result=apply_credits_to_bill(data)
    elif path=='/late_fee_scheduler':
        result=late_fee_scheduler()
    elif path=='/assign_customer_service_line_creation':
        result=assign_customer_service_line_creation(data)
    elif path=='/update_customer_rate_plan_service_line_creation':
        result=update_customer_rate_plan_service_line_creation(data)
    elif path=='/bulk_update_customer_rate_plan_service_line_creation':
        result=bulk_update_customer_rate_plan_service_line_creation(data)
    # elif path=='/customer_services_list_view_02_07_2025':
    #     result=customer_services_list_view_02_07_2025(data)
    elif path=='/bulk_update_device_status_service_line_creation':
        result=bulk_update_device_status_service_line_creation(data)   
    elif path=='/bulk_update_iccid_imei_service_line_creation':
        result=bulk_update_iccid_imei_service_line_creation(data)
    elif path=='/check_prorate_insert_to_unposted_':
        result=check_prorate_insert_to_unposted_(data)
    elif path=='/bulk_update_assign_customer_service_line_creation':
        result=bulk_update_assign_customer_service_line_creation(data)    
    elif path=='/bulk_update_device_status':
        result=bulk_update_device_status(data)
    elif path=='/get_bp_status':
        result=get_bp_status(data)
    elif path=='/update_device_status_service_line_creation':
        result=update_device_status_service_line_creation(data)
    elif path=='/transfer_service_date_validation':
        result=transfer_service_date_validation(data)
    elif path=='/service_line_creation_from_transfer_service':
        result=service_line_creation_from_transfer_service(data)
    elif path == '/bill_reversal_update':
        result = bill_reversal_update(data)
    elif path == '/bill_reversal_list_view':
        result = bill_reversal_list_view(data)
    elif path =='/reverals_export':
        result = reverals_export(data)
    elif path == '/reversals_reverse_transaction':
        result = reversals_reverse_transaction(data)
    elif path == '/test_file':
        result = test_file()
    elif path == '/create_reversal_bill':
        result = create_reversal_bill(data)
    elif path == '/fetch_customer_rate_plan_details':
        result = fetch_customer_rate_plan_details(data)
    elif path == '/upload_bulk_service_lines_data':
        result = upload_bulk_service_lines_data(data)
    elif path == '/reupload_existed_service_line_data':
        result = reupload_existed_service_line_data(data)
    elif path == '/get_reposted_mrcs':
        result = get_reposted_mrcs(data)
    elif path == '/save_reposted_mrcs':
        result = save_reposted_mrcs(data) 
    elif path == '/get_taxes_unposted':
        result = get_taxes_unposted(data)
    elif path == '/fetch_customer_rate_plan_details_by_service_type':
        result = fetch_customer_rate_plan_details_by_service_type(data)
    elif path == '/get_usage_for_past_bill_cycle':
        result = get_usage_for_past_bill_cycle(data)
    elif path == '/download_bulk_upload_service_types_template':
        result = download_bulk_upload_service_types_template(data)
    elif path == '/bill_creation_from_unposted_charges_01_09':
        result = bill_creation_from_unposted_charges_01_09(data)
        
    else:
        result = {"error": "Invalid path or method"}
        logging.warning("Invalid path or method requested: %s", path)

    # database Connection
    if result.get("flag") == False:
        common_utils_database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
        status_code = 400  # You can change this to an appropriate error code
        logging.error("Error in result: %s", result)
        # Sending email
        result_response = send_email("Exception Mail")
        if isinstance(result, dict) and result.get("flag") is False:
            logging.info(result)
        else:
            to_emails, cc_emails, subject, body, from_email, partner_name = (
                result_response
            )
            common_utils_database.update_dict(
                "email_templates",
                {"last_email_triggered_at": request_received_at},
                {"template_name": "Exception Mail"},
            )
            query = """
                SELECT parents_module_name, sub_module_name, child_module_name, partner_name
                FROM email_templates
                WHERE template_name = 'Exception Mail'
            """
            # Execute the query and fetch the result
            email_template_data = common_utils_database.execute_query(query, True)
            if not email_template_data.empty:
                # Unpack the results
                (
                    parents_module_name,
                    sub_module_name,
                    child_module_name,
                    partner_name,
                ) = email_template_data.iloc[0]
            else:
                # If no data is found, assign default values or log an error
                parents_module_name = ""
                sub_module_name = ""
                child_module_name = ""
                partner_name = ""

            # Email audit logging
            error_message = result.get(
                "error", "Unknown error occurred"
            )  # Extracting the error message
            email_audit_data = {
                "template_name": "Exception Mail",
                "email_type": "Application",
                "partner_name": partner_name,
                "email_status": "success",
                "from_email": from_email,
                "to_email": to_emails,
                "cc_email": cc_emails,
                "comments": f"{path} - Error: {error_message}",  # Adding error message to comments
                "subject": subject,
                "body": body,
                "action": "Email triggered",
                "parents_module_name": parents_module_name,
                "sub_module_name": sub_module_name,
                "child_module_name": child_module_name,
            }
            common_utils_database.update_audit(email_audit_data, "email_audit")

    else:
        status_code = 200

    # Capture the request completion time in IST
    request_completed_time = time.time()
    request_completed_time_formatted = datetime.now(
        pytz.timezone("Asia/Kolkata")
    ).strftime("%Y-%m-%d %H:%M:%S")

    # Calculate the time difference between hit time and request completed time
    time_taken = round(
        request_completed_time - hit_time, 4
    )  # Round to 4 decimal places
    logging.info(
        f"Request Completed: {request_completed_time_formatted}, Time Taken: {time_taken} seconds"
    )

    # Record the end time of the function
    end_time = time.time()
    performance_matrix["end_time"] = (
        f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
    )
    performance_matrix["execution_time"] = f"{end_time - start_time:.4f}"
    logging.info(
        f"Request processed at {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
    )

    performance_matrix["execution_time"] = f"{end_time - start_time:.4f} seconds"
    logging.info(f"Function performance_matrix: {performance_matrix} seconds")
    logging.info(
        "Lambda function execution completed in %.4f seconds", end_time - start_time
    )

    memory_limit = int(context.memory_limit_in_mb)
    memory_used = int(get_memory_usage()) + 100
    final_memory_used = get_memory_usage()
    logging.info(
        f"$$$$$$$$$$$$$$$$$$$$$$$Final Memory Used: {final_memory_used:.2f} MB"
    )
    memory_sns(memory_limit, memory_used, context)

    if access_token or (not access_token and not ui_token):
        if "status_code" in result:
            return result
        else:
            return result
    else:
        return {
            "statusCode": status_code,
            "body": json.dumps(result),
            "performance_matrix": json.dumps(performance_matrix),
            "started": hit_time_formatted,
            "time_taken": time_taken,
            "request_completed_time_formatted": request_completed_time_formatted,
        }
                
