"""
@Author1 : Phaneendra.Y
Created Date: 11-11-24
"""
# Importing the necessary Libraries
import os
import time
import json
import io
import re
import base64
import boto3
from datetime import datetime
from io import BytesIO
import pandas as pd
import zipfile
import openpyxl
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter


# Internal imports
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging




# AWS S3 client
s3_client = boto3.client("s3")
# Retrieve the S3 bucket name from an environment variable
S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME")

logging = Logging(name="charges_history")

##helper function to convert the data to json to make db_config
def clean_tuple(tpl):
    """
    Cleans and formats a tuple for use in SQL queries.

    Parameters:
        tpl (tuple or any): The input value to clean. If it's a tuple, it is returned as a string in appropriate format.
                            - If None or not a tuple, returns an empty tuple.
                            - If a single-element tuple, returns a string like "('value')".
                            - If a multi-element tuple, returns the standard tuple string format.

    Returns:
        str or tuple: A formatted string representation of the tuple for SQL, or an empty tuple if input is invalid.
    """
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        logging.exception(f"### Exception while converting tuple : {e}")
        return ()


##helper function to convert the data to json to make db_config
def db_config_maker(user, db_config_making,tenant_database,tenant_name,role_name,readme_flag=False):
    """
    Creates a database configuration dictionary with user-specific filters based on tenant and role.
    
    Args:
        user (str): Username to look up permissions for
        db_config_making (dict): Base database configuration to extend
        tenant_database (str): Name of the tenant database
        tenant_name (str): Name of the tenant
        role_name (str): User's role (e.g., 'Super Admin')
        readme_flag (bool): Flag to determine query format (client_id vs user_name)
        
    Returns:
        dict: Modified database configuration with user-specific filters
    """
    # Bypass filtering for Super Admin users
    if role_name in ('Super Admin'):
        return db_config_making
    # Connect to common_utils database to get tenant info
    common_utils_database = DB('common_utils',**db_config_making)
    # Get tenant ID and parent tenant ID
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )

    tenant_id = tenant_data["id"].to_list()[0]
    # parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    if tenant_id:
        tenant_id=int(tenant_id)
    #Get user permissions from mapping table
    if readme_flag:
        # query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where client_id ='{user}' and tenant_id={tenant_id}"
        # filters = common_utils_database.execute_query(query, True)
        query = "SELECT customers, service_provider, customer_group FROM user_module_tenant_mapping WHERE client_id = %s AND tenant_id = %s"
        filters = common_utils_database.execute_query(query, True, params=[user, tenant_id])

        if filters.empty:
            query = "SELECT customers, service_provider, customer_group FROM user_module_tenant_mapping WHERE user_name = %s AND tenant_id = %s"
            filters = common_utils_database.execute_query(query, True, params=[user, tenant_id])

    else:
        # query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"

        # filters = common_utils_database.execute_query(query, True)
        query = "SELECT customers, service_provider, customer_group FROM user_module_tenant_mapping WHERE user_name = %s AND tenant_id = %s"
        filters = common_utils_database.execute_query(query, True, params=[user, tenant_id])

    # Connect to tenant database
    database = DB(tenant_database, **db_config)
    # Extract customer group if exists
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except Exception as e:
        logging.exception(f"### Error getting customer_group info: {e}")  
        customer_group = None  

    customer_group_data = None
    # billing_account_number = None
    # feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    # If user has a customer group, get additional filters from it
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            # Extract rate plan names
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception(f"### Error extracting rate_plan_name: {e}")
            # Extract customer names
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception(f"### Error while extracting customer_names : {e}")
                customer_names=None
            # Extract billing account number
            # try:
            #     billing_data = customer_group_data["billing_account_number"].to_list()[0]
            #     if billing_data:
            #         billing_account_number = (billing_data,)  # Wrap int in a tuple
            #     else:
            #         billing_account_number=None


            # except Exception as e:
            #     logging.exception(f"### Error extracting billing_account_number : {e}")
            #     billing_account_number=None
            # Extract feature codes
            # try:
            #     feature_data = customer_group_data["feature_codes"].to_list()[0]

            #     if isinstance(feature_data, str):
            #         feature_codes = tuple(json.loads(feature_data))
            #     elif isinstance(feature_data, list):
            #         feature_codes = tuple(feature_data)
            #     else:
            #         feature_codes = (feature_data,)  # Convert non-list types to tuple

            # except Exception as e:
            #     logging.exception(f"### Error extracting feature_codes: {e}")
    # Set customer filter - use customer group names if available, otherwise use direct mapping
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except Exception as e:
            logging.exception(f"### Error getting customer info: {e}") 
            customer = None   
    else:
        customer=customer_names
    logging.info(f"### customers: {customer}")
    #customer=clean_tuple(customer)
    # Get service provider info and convert names to IDs
    try:
        # service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        # if len(service_provider) == 1:
        #     query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        # else:
        #     formatted_values = "', '".join(service_provider)
        #     query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        # service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())

        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = "SELECT id FROM serviceprovider WHERE service_provider_name = %s"
            params = [service_provider[0]]
        else:
            placeholders = ", ".join(["%s"] * len(service_provider))
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ({placeholders})"
            params = list(service_provider)

        service_provider_id = tuple(database.execute_query(query, True, params=params)["id"].to_list())

    except Exception as e:
        logging.exception(f"### Error getting service provider info : {e}")
        service_provider = None
        service_provider_id = None    
    # Get additional customers created by this user
    logging.info(f"### customers after: {customer}")
    try:
        customers_query = '''SELECT customer_name  FROM customers  WHERE tenant_id = %s AND is_active = TRUE AND created_by = %s'''
        customers_df = database.execute_query(customers_query, flag=True, params=[tenant_id, user])
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                fixed_customer_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer, str):
                    customer = [customer]
                elif isinstance(customer_rate_plan_name, tuple):
                    customer = list(customer)
                else:
                    customer = customer  # Already a list

                fixed_customer_list = customer.copy() 
                # Clean and fix the list by splitting the elements and ensuring they are correctly quoted
                logging.info(f"### before extending customers:{fixed_customer_list}")
                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info(f"### customer after extend:{fixed_customer_list}")

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info(f"### final customer tuple:{customer}")
                customer=clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(f"### Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    logging.info(f"### customers after: {customer}")
    # Get additional rate plans created by this user
    try:
        customer_rate_plan_query = ''' SELECT rate_plan_name  FROM customerrateplan WHERE tenant_id = %s AND is_active = TRUE AND created_by = %s'''
        customer_rate_plan_df = database.execute_query(customer_rate_plan_query, flag=True, params=[tenant_id, user])

        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                fixed_customer_rate_plan_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_list = [customer_rate_plan_name]
                elif isinstance(customer_rate_plan_name, tuple):
                    customer_rate_plan_list = list(customer_rate_plan_name)
                else:
                    customer_rate_plan_list = customer_rate_plan_name  # Already a list

                fixed_customer_rate_plan_list = customer_rate_plan_list.copy() # Remove extra quotes and commas
                logging.info(f'### customer_ rate plan list before extend:{fixed_customer_rate_plan_list}')

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info(f"### customer rate plan_list after extend: {fixed_customer_rate_plan_list}")

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info(f"### final customer rate plan tuple: {customer_rate_plan_name}")

    except Exception as e:
        logging.exception(f"### Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    # Update configuration with all filters
    logging.info(f"### customer at the end of customer:{customer}")
    db_config_making["customers"] = customer
    db_config_making["service_providers"] = service_provider
    db_config_making["service_provider_id"] = service_provider_id
    db_config_making["customer_rate_plan_name"] = customer_rate_plan_name
    return db_config_making



### Main function to call the respective function based on the path
def function_caller(data, path):
    """
    Main router function that initializes DB configuration and calls the appropriate handler 
    based on the provided API path.

    This function:
    1. Sets up the global database configuration using environment variables.
    2. Extracts and resolves user, tenant, and role info from input data.
    3. Uses path-based routing to call the correct function.

    Args:
        data (dict): Dictionary containing request data like username, tenant_name, db_name, role_name, etc.
        path (str): The API endpoint path that determines which function to invoke.

    Returns:
        dict: The output response from the appropriate handler function, or an error if the path is invalid.
    """
    global db_config

    # Step 1: Initialize base DB config from environment variables
    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

    # Step 2: Extract required fields
    user = data.get("username") or data.get("user_name")
    tenant_database = data.get("db_name", "")
    role_name = data.get("role_name") or data.get("role", "") or "Super Admin"
    tenant_name = (
        data.get("tenant_name") or data.get("tenant") or data.get("Partner") or "Altaworx"
    )

    # Normalize tenant name if needed
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    # Step 3: Generate dynamic DB config based on the request
    db_config = db_config_maker(user, db_config, tenant_database, tenant_name, role_name)
    logging.info(f"### db_config created is : {db_config}")

    # Step 4: Map endpoint paths to respective handler functions
    path_function_map = {
        "/get_charge_history_data": get_charge_history_data,
        "/export_row_data_customer_charges": export_row_data_customer_charges,
        "/customers_sessions_customer_charges_export_dropdown_data": customers_sessions_customer_charges_export_dropdown_data,
        "/export_customer_charges": export_customer_charges,
        "/get_export_status": get_export_status,
    }

    # Step 5: Call appropriate handler function
    handler = path_function_map.get(path)
    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result



def get_headers_mapping(
    tenant_database,
    module_list,
    role,
    user,
    tenant_id,
    sub_parent_module,
    parent_module,
    data,
    common_utils_database,
):
    """
    Fetches and organizes header mappings and module features based on module names and user role.

    This function connects to the database and:
    - Retrieves column mapping data (general fields, popup fields, table headers) for each module.
    - Groups the fields for UI rendering.
    - Fetches available module features based on user role (Super Admin or other).
    - Supports dynamic UI generation based on tenant and user permissions.

    Args:
        tenant_database (DB): The tenant-specific database connection.
        module_list (list): List of module names to fetch header mappings for.
        role (str): The user's role (e.g., "Super Admin", "User").
        tenant_id (str): ID of the tenant (can be empty; will be fetched if not passed).
        sub_parent_module (str): (Currently unused) Possible sub-module categorization.
        parent_module (str): Parent module name (e.g., "Sim Management").
        common_utils_database (DB): Connection to the common utilities database (used for shared tables).

    Returns:
        dict: A dictionary where each key is a module name, and each value contains:
              - 'general_fields': Fields to be shown in the general view.
              - 'pop_up': Fields to be shown in popup modals.
              - 'header_map': Table headers and their display order.
              - 'module_features': List of features allowed for this module and user role.
    """
    ##Database connection
    ret_out = {}
    try:
        logging.info(f"### Module name is :{module_list} and role is :{role}")
        # common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        feature_module_name = data.get("feature_module_name", "")
        user_name = data.get("username") or data.get("user_name") or data.get("user")
        tenant_name = data.get("tenant_name") or data.get("tenant")
        parent_module_name = data.get("parent_module_name") or data.get("parent_module")
        if parent_module_name == "Sim Management":
            parent_module_name = "Sim Management"
        try:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            logging.info(f"### tenant_id  is :{tenant_id}")
        except Exception as e:
            logging.exception(f"### Getting exception at fetching tenant id {e}")
        # Iterate over each module name in the provided module list
        for module_name in module_list:
            out = common_utils_database.get_data(
                "field_column_mapping", {"module_name": module_name}
            ).to_dict(orient="records")
            pop_up = []
            general_fields = []
            table_fileds = {}
            # Categorize the fetched data based on field types
            for data in out:
                if data["pop_col"]:
                    pop_up.append(data)
                elif data["table_col"]:
                    table_fileds.update(
                        {
                            data["db_column_name"]: [
                                data["display_name"],
                                data["table_header_order"],
                            ]
                        }
                    )
                else:
                    general_fields.append(data)
            # Create a dictionary to store categorized fields
            headers = {}
            headers["general_fields"] = general_fields
            headers["pop_up"] = pop_up
            headers["header_map"] = table_fileds
            logging.info("### Got the header map here")
            try:
                final_features = []

                # Fetch all features for the 'super admin' role
                if role.lower() == "super admin":
                    all_features = common_utils_database.get_data(
                        "module_features",
                        {"module": feature_module_name},
                        ["features"],
                    )["features"].to_list()
                    if all_features:
                        final_features = json.loads(all_features[0])
                else:
                    final_features = get_features_by_feature_name(
                        user_name,
                        tenant_id,
                        feature_module_name,
                        common_utils_database,
                        role,
                        parent_module_name,
                    )

            except Exception as e:
                logging.warning(f"### there is some error : {e}")
                pass
            # Add the final features to the headers dictionary
            headers["module_features"] = final_features
            ret_out[module_name] = headers
    except Exception as e:
        logging.warning(f"there is some error : {e}")

    return ret_out


##Helper function to fetch the features using the feature name
def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, role, parent_module
):
    """
    Description:
        This function retrieves a list of features associated with a specific
        feature name for a user within a tenant.
        It fetches user-module-tenant mapping data, processes the features,
        and extracts relevant features
        linked to the specified feature name.

    Args:
    ----------
    user_name : str
        The name or identifier of the user for whom the features are being fetched.
    tenant_id : str
        The tenant ID associated with the user.
    feature_name : str
        The specific feature name for which features need to be extracted.
    common_utils_database : object
        Utility database object to query data from the required tables.

    Returns:
    -------
    list
        A list of features associated with the specified feature name for the user.
    """

    # Fetch user features from the database based on user name and tenant ID
    user_features_raw = common_utils_database.get_data(
        "user_module_tenant_mapping",
        {"user_name": user_name, "tenant_id": tenant_id},
        ["module_features"],
    )["module_features"].to_list()
    logging.info(f"### Raw user features fetched :{user_features_raw}")
    if not user_features_raw or user_features_raw[0] is None:
        # query=f'''select module_features from role_module where role='{role}'
        # '''
        # user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
        query = '''SELECT module_features FROM role_module WHERE role = %s'''
        user_features_raw = common_utils_database.execute_query(query, flag=True, params=[role])["module_features"].to_list()

    # Parse the JSON string to a dictionary
    try:
        features = json.loads(
            user_features_raw[0]
        )  # Assuming it's a list with one JSON string
    except Exception as e:
        logging.exception(f"### Error while getting features: {e}")
        features = {}    

    if not features:
        features = common_utils_database.get_data(
            "role_module",
            {"role": role},
            ["module_features"],
        )["module_features"].to_list()
        features = json.loads(
            features[0]
        )


    # Initialize a list to hold features for the specified feature name
    features_list = []

    # Loop through all modules to find the specified feature name and collect its features
    for par_module, modules in features.items():
        if parent_module == par_module:
            for module,features_l in modules.items():
                if module == feature_name:
                    features_list = features_l

    # Log the retrieved features for debugging purposes
    logging.info(f"### Retrieved features:{features_list}")

    # Return the list of features associated with the specified feature name
    return features_list


def get_charge_history_data(data):
    """
    Retrieves charge history report data for a specific module and tenant with optional sorting and pagination.

    Args:
        data (dict): Request data containing the following keys:
            - db_name (str): The name of the tenant-specific database.
            - tenant_name (str): Name of the tenant.
            - role_name (str): Role of the user.
            - action (str): "navigation" or empty for regular fetch.
            - table_name (str, optional): Table/view to fetch data from (default: 'vw_optimization_smi_result_customer_charge_queue').
            - mod_pages (dict): Pagination dictionary with keys like 'start' and 'end'.
            - col_sort (dict, optional): Dictionary to define sorting like {"column_name": "ASC" or "DESC"}.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation (True/False).
            - message (str): Descriptive message about the result.
            - headers_map (dict): Header configuration for rendering in UI.
            - customer_charges_data (list of dicts): List of charge records fetched from the database.

    """
    logging.info(f"### get_charge_history_data called with request data:\n{json.dumps(data, indent=2, default=str)}")

    # Record the start time for performance measurement
    start_time = time.time()
    module_name = data.get("module_name", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", None)
    mod_pages = data.get("mod_pages", {})
    role_name = data.get("role_name", "")
    limit = 100
    offset = mod_pages.get("start", 0)
    end = mod_pages.get("end", 100)
    # start = mod_pages.get("start", 0)
    col_sort = data.get("col_sort", "")
    session_id = data.get("session_id", "")
    action = data.get("action", "")
    tenant_name=data.get("tenant_name","")
    # table = data.get("table_name", "vw_optimization_smi_result_customer_charge_queue")
    # Database connection
    tenant_database = data.get("db_name", "")
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error(f"### Failed to connect to the database:  {str(db_exception)}")
        return {"error": "Database connection failed.", "details": str(db_exception)}
    return_json_data = {}
    # Initialize pagination dictionary
    pages = {"start": offset, "end": end}
    # tenant_timezone = None
    try:

        # count_params = [table]
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        tenant_id=common_utils_database.get_data("tenant",{"tenant_name":tenant_name},['id'])['id'].to_list()[0]
        if action == "navigation":
            # count_query = (
            #     f"SELECT COUNT(*) FROM {table} where session_id='{session_id}'"
            # )
            # count_result = database.execute_query(count_query, count_params).iloc[0, 0]
            count_result=0
            # Set total pages count
            pages["total"] = int(count_result)
            # return {"flag":True}
            module_query_df = common_utils_database.get_data(
                "module_view_queries", {"module_name": "Charge history navigation"}
            )
            if module_query_df.empty:
                raise ValueError(f"No query found for module name: {module_name}")
            query = module_query_df.iloc[0]["module_query"]
            if not query:
                raise ValueError(f"Unknown module name: {module_name}")
            params = [tenant_id,session_id, offset, limit]
        else:
            # count_query = f"SELECT COUNT(*) FROM {table}"
            # count_result = database.execute_query(count_query, count_params).iloc[0, 0]
            count_result=0
            # Set total pages count
            pages["total"] = int(count_result)
            # return {"flag":True}
            module_query_df = common_utils_database.get_data(
                "module_view_queries", {"module_name": module_name}
            )
            if module_query_df.empty:
                raise ValueError(f"No query found for module name: {module_name}")
            query = module_query_df.iloc[0]["module_query"]
            if not query:
                raise ValueError(f"Unknown module name: {module_name}")
            params = [tenant_id,offset, limit]

        if col_sort:
            # Extract the single key-value pair for sorting
            key, value = list(col_sort.items())[0]

            # Remove any existing ORDER BY clause
            order_by_pattern = (
                r"\sORDER\s+BY\s+[^\s]+(\sASC|\sDESC)?(?=\s+(OFFSET|LIMIT))"
            )
            query = re.sub(order_by_pattern, "", query, flags=re.IGNORECASE)

            # Insert the new ORDER BY clause before OFFSET and LIMIT
            limit_offset_pattern = (
                r"(OFFSET\s+%s\s+LIMIT\s+%s;)"  # Captures OFFSET and LIMIT
            )
            query = re.sub(
                limit_offset_pattern,
                f"ORDER BY {key} {value.upper()} \\1",
                query,
                flags=re.IGNORECASE,
            )

        # main_query_start_time = time.time()
        charge_history_df = database.execute_query(query, params=params)
        tenant_time_zone = fetch_tenant_timezone(data, common_utils_database)
        # conversion_start_time = time.time()
        # Convert timestamps
        charge_history_data = convert_timestamp_data(
            charge_history_df, tenant_time_zone
        )
        charge_history_data = charge_history_df.to_dict(orient="records")

        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database,
            [module_name],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )
        # Preparing the response data
        return_json_data.update(
            {
                "message": "Successfully Fetched the Charges history data",
                "flag": True,
                "headers_map": headers_map,
                "customer_charges_data": charge_history_data,
            }
        )
        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = round(end_time - start_time, 4)
            audit_data_user_actions = {
                "service_name": "get_charge_history_data",    
                "created_by": username,
                "status": str(return_json_data["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": "Fetching Charges history data",
                "module_name":module_name ,
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Got Exception while updating the Audit : {e}")
        return return_json_data

    except Exception as e:
        logging.exception(f"### An error occurred: {e}")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database,
            [module_name],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )
        message = f"Unable to fetch the Charges history data{e}"
        response = {"flag": True, "message": message, "headers_map": headers_map}
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "get_charge_history_data",
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name":module_name , 
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return response



def fetch_tenant_timezone(data,common_utils_database):
    """
    Fetches the timezone of a given tenant from the database.

    Args:
        data (dict): Dictionary containing the tenant information.
            - Expected key: "tenant_name" (str): Name of the tenant.
        common_utils_database (DB): Database object to execute queries.

    Returns:
        str: A valid timezone string (e.g., "Asia/Kolkata").
    """
    try :
        # Retrieve the tenant name from the provided data dictionary.
        tenant_name = data.get("tenant_name", "")
        # SQL query to fetch the time zone of the tenant from the 'tenant' table.
        tenant_timezone_query = (
            """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        )
        # Execute the query and retrieve the result from the database.
        tenant_timezone = common_utils_database.execute_query(
            tenant_timezone_query, params=[tenant_name]
        )
        if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
            raise ValueError("No valid timezone found for tenant.")
        tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
        match = re.search(
            r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)",
            tenant_time_zone,
        )
        # If a match is found, format the time zone string by removing spaces.
        if match:
            tenant_time_zone = match.group(1).replace(
                " ", ""
            )  # Ensure it's formatted correctly
        return tenant_time_zone
    except Exception as e:
        logging.exception(f"[fetch_tenant_timezone] Error occurred for tenant '{data.get('tenant_name', '')}': {e}")
        return None
        # raise keyword in python Rethrows the current exception
        # raise     

def format_timestamp(ts):
    """
    Formats a given timestamp into a readable string.

    Args:
        ts (datetime or pandas.Timestamp): The timestamp to format.

    Returns:
        str: A formatted string representing the timestamp, or a blank space if None.
    """
    # Check if the timestamp is not None
    if ts is not None:
        # Convert a Timestamp or datetime object to the desired string format
        return ts.strftime("%b %d, %Y, %I:%M %p")
    else:
        # Return a placeholder or empty string if the timestamp is None
        return " "


def export_row_data_customer_charges(data):
    """
    Exports customer charge data into an Excel-compatible blob format.

    Args:
        data (dict): A dictionary containing required details like:
            - 'Partner': (str) Tenant name for audit.
            - 'user_name': (str) Username performing the operation.
            - 'queue_id': (str) ID to be passed as a query parameter.
            - 'db_name': (str) Tenant-specific DB to connect to.

    Returns:
        dict: A dictionary with:
            - 'flag' (bool): Success or failure status.
            - 'blob' (str, optional): Base64 string of the Excel file (if successful).

    """

    logging.info(f"### export_row_data_customer_charges called with request data:\n{json.dumps(data, indent=2, default=str)}")

    ### Extract parameters from the Request Data
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "Optimization row data")
    user_name = data.get("user_name", "")
    queue_id = data.get("queue_id", "")
    ##database connection for common utilss
    try:
        ##databse connenction
        tenant_database = data.get("db_name", "")
        # database Connection
        database = DB(tenant_database, **db_config)
        db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error(f"### Failed to connect to the database: {str(db_exception)}")
        return {"error": "Database connection failed.", "details": str(db_exception)}
    # Start time  and date calculation
    start_time = time.time()
    try:

        # Fetch the query from the database based on the module name
        module_query_df = db.get_data(
            "export_queries", {"module_name": "Optimization row data"}
        )
        logging.info(f"### module_query_df : {module_query_df}")
        ##checking the dataframe is empty or not
        if module_query_df.empty:
            return {
                "flag": False,
                "message": f"No query found for module name: {module_name}",
            }
        # Extract the query string from the DataFrame
        query = module_query_df.iloc[0]["module_query"]
        if not query:
            return {"flag": False, "message": f"Unknown module name: {module_name}"}
        ##params for the specific module
        params = [queue_id]
        ##executing the query
        data_frame = database.execute_query(query, params=params)
        # Capitalize each word and add spaces
        data_frame.columns = [
            col.replace("_", " ").title() for col in data_frame.columns
        ]
        data_frame["S.NO"] = range(1, len(data_frame) + 1)
        # Reorder columns dynamically to put S.NO at the first position
        columns = ["S.NO"] + [col for col in data_frame.columns if col != "S.NO"]
        data_frame = data_frame[columns]
        # Proceed with the export if row count is within the allowed limit
        data_frame = data_frame.astype(str)
        data_frame.replace(to_replace="None", value="", inplace=True)

        blob_data = dataframe_to_blob(data_frame)
        # End time calculation
        end_time = time.time()
        time_consumed = round(end_time - start_time, 4)
        # Create the filename with the date format YYYYMMDDHHMM
        current_time = datetime.now()
        formatted_date = current_time.strftime("%Y%m%d%H%M")
        filename = f"CustomerChargeDetailOutboardRecycle_{formatted_date}"
        # Return JSON response
        response = {
            "flag": True,
            "blob": blob_data.decode("utf-8"),
            "filename": filename,
        }
        audit_data_user_actions = {
            "service_name": "export_row_data_customer_charges",
            "created_by": user_name,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "tenant_name": Partner,
            "comments": "exporting customer charges data ",
            "module_name": "Charges history",
            "request_received_at": request_received_at,
        }
        db.update_audit(audit_data_user_actions, "audit_user_actions")
        return response
    except Exception as e:
        error_type = str(type(e).__name__)
        logging.exception(f"### An error occurred: {e}")
        message = "Error while exporting customer charges data"
        response = {"flag": False, "message": message}
        try:
            # Log error to database
            error_data = {
                "service_name": "export_row_data_customer_charges",
                "error_message": str(e),
                "error_type": error_type,
                "users": user_name,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "Charges history",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Error while auditing the error: {e}")
        return response


def dataframe_to_blob(data_frame):
    """
    Converts a pandas DataFrame into a base64-encoded Excel blob.
    Args:
        data_frame (pd.DataFrame): The pandas DataFrame to convert.

    Returns:
        bytes: A base64-encoded binary blob of the Excel file, ready to be sent over APIs or stored.
    """
    # Create a BytesIO buffer
    bio = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        data_frame.to_excel(writer, index=False)

    # Get the value from the buffer
    bio.seek(0)
    blob_data = base64.b64encode(bio.read())
    return blob_data

##charge history dropdown data
def customers_sessions_customer_charges_export_dropdown_data(data):
    """
    Fetches dropdown data for customer sessions and billing periods for charge history exports.
    Args:
        data (dict): Request input data including:
            - db_name (str): Tenant database name.
            - Partner/tenant_name (str): Name of the tenant.
            - request_received_at (str): Timestamp when the request was made.

    Returns:
        dict: A response dictionary with:
            - flag (bool): Indicates success or failure.
            - customer_sessions (dict): Session data grouped by customer name.
            - message (str): Status message.
    """
    start_time = time.time()  # Start performance measurement
    sessionID = data.get('sessionID') or data.get('session_id') or ""
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    Partner = data.get("Partner") or data.get("tenant_name") or ""
    logging.info("### Request Data Received")

    # Extract parameters from the request data
    tenant_database = data.get("db_name", "")
    if not tenant_database:
        logging.error("### Database name is missing from the request data.")
        return {
            "flag": False,
            "customer_sessions": {},
            "message": "Database name is required",
        }

    # Database connection setup
    try:
        database = DB(
            tenant_database, **db_config
        )  # Assuming DB is a predefined database connection class
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config) 
    except Exception as e:
        logging.exception(f"### Error establishing database connection: {e}")
        return {
            "flag": False,
            "customer_sessions": {},
            "message": "Error establishing database connection",
        }

    try:
        # Fetch customer names, session IDs, and billing period end date
        query = """
        SELECT DISTINCT customer_name, CAST(session_id AS TEXT) AS session_id,
        TO_CHAR(billing_period_end_date::date, 'YYYY-MM-DD') AS billing_period_end_date
        FROM vw_optimization_smi_result_customer_charge_queue;
        """

        # Get data from the database
        customer_session_df = database.execute_query(
            query, True
        )  # Assuming execute_query returns a DataFrame
        if customer_session_df.empty:
            logging.info("### No data found for customer sessions.")
            return {
                "flag": True,
                "customer_sessions": {},
                "message": "No customer sessions found",
            }

        # Initialize a dictionary to store the result with differentiation of session details
        customer_sessions = {}

        # Iterate over the dataframe to build the dictionary
        for index, row in customer_session_df.iterrows():
            customer_name = row["customer_name"]
            session_id = row["session_id"]
            billing_period_end_date = row["billing_period_end_date"]

            # Check if the customer_name already exists in the dictionary
            if customer_name in customer_sessions:
                # Append a dictionary with session details for the existing customer
                customer_sessions[customer_name].append(
                    {
                        "session_id": session_id,
                        "billing_period_end_date": billing_period_end_date,
                    }
                )
            else:
                # Create a new list for the customer with session details
                customer_sessions[customer_name] = [
                    {
                        "session_id": session_id,
                        "billing_period_end_date": billing_period_end_date,
                    }
                ]

        response = {"flag": True, "customer_sessions": customer_sessions}

        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = round(end_time - start_time, 4)
            audit_data_user_actions = {
                "service_name": "customers_sessions_customer_charges_export_dropdown_data",    
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": sessionID,
                "tenant_name": Partner,
                "comments": "Fetching customer charges export dropdown data",
                "module_name":"Charges history" ,
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Got Exception while updating the Audit : {e}")
        return response
    

    except Exception as e:
        logging.exception(f"###Error fetching data: {e}")
        message = "unable to get customer charges export dropdown data"
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "customers_sessions_customer_charges_export_dropdown_data",
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": sessionID,
            "tenant_name": Partner,
            "comments": message,
            "module_name":"Charges history",
            "request_received_at": request_received_at,
        }
        if common_utils_database: 
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        response =  {"flag": False, "customer_sessions": {}, "message": f"Error: {str(e)}"}
        return response
# def export_customer_charges(data):
#     """
#     Export customer charges to Excel files, zip them, and upload the zip file to an S3 bucket.

#     Args:
#         data (dict): Input data containing session_ids, db_name, and other details.

#     Returns:
#         dict: Response with a flag, message, and download_url if successful.
#     """
#     logging.info("### Request Data Received")
#     # Record the start time for performance measurement
#     start_time = time.time()
#     session_ids = data.get("session_ids", [])
#     sessionID = data.get('sessionID', '')
#     tenant_database = data.get("db_name", "")
#     request_received_at = data.get("request_received_at", "")
#     username = data.get("username", "")
#     module_name = data.get("module_name", "")
#     partner = data.get("Partner", "")
#     database = DB(
#         tenant_database, **db_config
#     )  # Assuming DB class is defined elsewhere
#     zip_filename = "CustomerCharges.zip"
#     s3_key = f"exports/customer_charges/{zip_filename}"
#     db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

#     # Update export status to 'Waiting'
#     db.update_dict(
#         "export_status",
#         {"status_flag": "Waiting", "url": ""},
#         {"module_name": "Charge History"},
#     )
#     try:
#         # Create an in-memory buffer to hold the zip file
#         zip_buffer = io.BytesIO()

#         with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zipf:
#                 try:
#                     logging.info("### Processing all customer charges")
#                     query = """
#                         SELECT rev_account_number,iccid, msisdn, customer_name,
#                         billing_period_end_date - billing_period_start_date AS billing_period_duration,
#                         billing_period_start_date, billing_period_end_date, usage_mb,
#                         base_charge_amount, rate_charge_amt, overage_charge_amount,COALESCE(base_charge_amount, 0) + COALESCE(rate_charge_amt, 0) AS total_charges_pushed,COALESCE(base_charge_amount, 0) + COALESCE(rate_charge_amt, 0) + COALESCE(overage_charge_amount, 0) AS total_data_charge_amount,
#                         is_processed, error_message,
#                          sms_usage, sms_charge_amount, total_charge_amount
#                         FROM vw_optimization_smi_result_customer_charge_queue limit 1
#                     """
#                     dataframe = database.execute_query(query,True)

#                     # Validate DataFrame content
#                     if dataframe.empty:
#                         logging.warning(f"No data found ")
#                         return {"flag": False, "message": "No data found"}

#                     logging.debug(
#                         f"DataFrame shape: {dataframe.shape}"
#                     )

#                     # Rename columns for better readability
#                     dataframe.columns = [
#                         col.replace("_", " ").title() for col in dataframe.columns
#                     ]
#                     dataframe["S.NO"] = range(1, len(dataframe) + 1)
#                     columns = ["S.NO"] + [
#                         col for col in dataframe.columns if col != "S.NO"
#                     ]
#                     dataframe = dataframe[columns]

#                     # Extract billing period dates
#                     billing_period_start_date = dataframe.iloc[0][
#                         "Billing Period Start Date"
#                     ].strftime("%Y%m%d")
#                     billing_period_end_date = dataframe.iloc[0][
#                         "Billing Period End Date"
#                     ].strftime("%Y%m%d")

#                     logging.debug(
#                         f"Billing Period: {billing_period_start_date} to {billing_period_end_date}"
#                     )

#                     # Create filename for Excel
#                     excel_filename = f"CustomerChargeDetail_{billing_period_start_date}_{billing_period_end_date}.xlsx"

#                     # Write DataFrame to an in-memory Excel file with styling
#                     customer_excel_buffer = io.BytesIO()
#                     with pd.ExcelWriter(customer_excel_buffer, engine="openpyxl") as writer:
#                         dataframe.to_excel(writer, index=False, sheet_name="Charges")

#                         # Apply styling
#                         workbook = writer.book
#                         sheet = writer.sheets["Charges"]

#                         # Format header row
#                         for cell in sheet[1]:  # Header row is the first row (1-based indexing)
#                             cell.alignment = Alignment(horizontal="center", vertical="center")
#                             cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
#                             cell.font = Font(bold=True)

#                         # Adjust column widths
#                         for col_idx, col_cells in enumerate(sheet.columns, 1):  # 1-based indexing for columns
#                             max_length = max(len(str(cell.value or "")) for cell in col_cells)
#                             sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

#                         # Ensure consistent number formatting
#                         for col_idx, col_cells in enumerate(sheet.columns, 1):
#                             for cell in col_cells:
#                                 if isinstance(cell.value, int):
#                                     cell.number_format = '0'  # Format as an integer without decimal points
#                                 elif isinstance(cell.value, float):
#                                     cell.number_format = '0.00'  # Format as float with 2 decimal places

#                     # Write Excel file to the zip archive
#                     customer_excel_buffer.seek(0)
#                     zipf.writestr(excel_filename, customer_excel_buffer.getvalue())
#                     customer_excel_buffer.close()

#                 except Exception as e:
#                     logging.exception(f"Error processing charges: {e}")

#         # Upload the zip file to S3
#         zip_buffer.seek(0)
#         try:
#             s3_client = boto3.client("s3")
#             s3_client.put_object(
#                 Bucket=S3_BUCKET_NAME,
#                 Key=s3_key,
#                 Body=zip_buffer.getvalue(),
#                 ContentType="application/zip",
#             )
#             download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{s3_key}"
#             logging.info("### File uploaded to S3 successfully.")
#             response = {
#                 "flag": True,
#                 "message": "Export successful",
#                 "download_url": download_url,
#             }
#             db.update_dict(
#                 "export_status",
#                 {"status_flag": "Success", "url": download_url},
#                 {"module_name": "Charge History"},
#             )
#             # End time and audit logging
#             end_time = time.time()
#             time_consumed = round(end_time - start_time, 4)
#             audit_data_user_actions = {
#                 "service_name": "export_customer_charges",
#                 "created_by": username,
#                 "status": str(response["flag"]),
#                 "time_consumed_secs": time_consumed,
#                 "session_id": sessionID,
#                 "tenant_name": partner,
#                 "comments": "Uploading to S3 bucket",
#                 "module_name": "Charges History",
#                 "request_received_at": request_received_at,
#             }
#             db.update_audit(audit_data_user_actions, "audit_user_actions")
#             return response
#         except Exception as e:
#             logging.exception(f"Error uploading to S3: {e}")
#             return {"flag": False, "message": "Failed to upload zip file to S3"}
#     except Exception as e:
#         logging.exception(f"Exceptions is {e}")
#         message = f"Failed to upload zip file to S3"
#         return_json_data = {"flag": True, "message": message}
#         error_type = str(type(e).__name__)
#         # Error logging
#         error_data = {
#             "service_name": "export_customer_charges",
#             "error_message": message,
#             "error_type": error_type,
#             "users": username,
#             "session_id": sessionID,
#             "tenant_name": partner,
#             "comments": message,
#             "module_name": "Charge History",
#             "request_received_at": request_received_at,
#         }
#         db.log_error_to_db(error_data, "error_log_table")

#         return return_json_data



def export_customer_charges(data):
    """
    Exports customer charge data to a formatted Excel file, zips it, uploads to S3, and returns the download link.

    Args:
        data (dict): Input dictionary with required keys such as:
            - session_ids (list): List of session IDs.
            - db_name (str): Tenant database name.
            - module_name (str): Name of the module.
            - Partner (str): Tenant or partner name.

    Returns:
        dict: A response with:
            - flag (bool): Indicates success or failure.
            - message (str): Human-readable status message.
            - download_url (str): Public URL to download the exported ZIP file (on success).
    """
    logging.info("### Request Data Received")
    start_time = time.time()  # Start performance measurement
    # session_ids = data.get("session_ids", [])
    sessionID = data.get('sessionID', '')
    tenant_database = data.get("db_name", "")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    # module_name = data.get("module_name", "")
    partner = data.get("Partner", "")
    database = DB(tenant_database, **db_config)  # Assuming DB class is defined elsewhere
    zip_filename = "CustomerCharges.zip"
    s3_key = f"exports/customer_charges/{zip_filename}"

    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_name= data.get("Partner", "")
    if tenant_name == 'Altaworx Test':
        tenant_name = 'Altaworx'
    tenant_id= db.get_data("tenant", {"tenant_name": tenant_name}, ["id"])["id"].to_list()[0]

    # Update export status to 'Waiting'
    db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": "Charge History"},
    )
    acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "SIM"}
    special_replacements = {
        "Att": "AT&T",
        "And": "and",
    }
    download_url = ""

    try:
        # Create an in-memory buffer for the zip file
        zip_buffer = io.BytesIO()

        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zipf:
            try:
                logging.info("### Processing all customer charges")
                query = """
                        SELECT rev_account_number, iccid, msisdn, customer_name,
                        billing_period_end_date - billing_period_start_date AS billing_period_duration,
                        billing_period_start_date, billing_period_end_date, TO_CHAR(TRUNC(usage_mb, 2), 'FM999,999,999.00') AS usage_mb,
                        base_charge_amount, rate_charge_amt, overage_charge_amount,
                        COALESCE(overage_charge_amount, 0) + COALESCE(rate_charge_amt, 0) AS total_charges_pushed,
                        COALESCE(base_charge_amount, 0) + COALESCE(rate_charge_amt, 0) + COALESCE(overage_charge_amount, 0) AS total_data_charge_amount,
                        is_processed, error_message, sms_usage, sms_charge_amount, total_charge_amount
                        FROM vw_optimization_smi_result_customer_charge_queue WHERE tenant_id = %s
                    """
                dataframe = database.execute_query(query, True, params=[tenant_id])


                if dataframe.empty:
                    logging.warning("### No data found")
                    return {"flag": False, "message": "No data found"}

                # Format column names
                dataframe.columns = [
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in col.split("_")
                    )
                    for col in dataframe.columns
                ]

                # Apply special replacements (e.g., Att -> AT&T, And -> and)
                dataframe.columns = [
                    " ".join([special_replacements.get(word, word) for word in col.split(" ")])
                    for col in dataframe.columns
                ]

                billing_period_start_date = dataframe.iloc[0]["Billing Period Start Date"].strftime("%Y%m%d")
                billing_period_end_date = dataframe.iloc[0]["Billing Period End Date"].strftime("%Y%m%d")

                excel_filename = f"CustomerChargeDetail_{billing_period_start_date}_{billing_period_end_date}.xlsx"

                # Create an in-memory buffer for the Excel file
                customer_excel_buffer = io.BytesIO()

                # Write DataFrame to Excel
                with pd.ExcelWriter(customer_excel_buffer, engine="openpyxl") as writer:
                    dataframe.to_excel(writer, index=False, sheet_name="Charges")

                # Load workbook and apply formatting
                customer_excel_buffer.seek(0)
                workbook = openpyxl.load_workbook(customer_excel_buffer)
                sheet = workbook.active

                # Apply formatting
                for cell in sheet[1]:  # Header row formatting
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                    cell.font = Font(bold=True)

                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

                # Save the formatted workbook back to the buffer
                customer_excel_buffer = io.BytesIO()
                workbook.save(customer_excel_buffer)
                customer_excel_buffer.seek(0)

                zipf.writestr(excel_filename, customer_excel_buffer.getvalue())

            except Exception as e:
                logging.exception(f"### Error processing charges: {e}")
                raise

        # Upload zip file to S3
        zip_buffer.seek(0)
        try:
            s3_client = boto3.client("s3")
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=s3_key,
                Body=zip_buffer.getvalue(),
                ContentType="application/zip",
            )
            download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{s3_key}"
            logging.info("### File uploaded to S3 successfully.")
            response = {
                "flag": True,
                "message": "Export successful",
                "download_url": download_url,
            }
            db.update_dict(
                "export_status",
                {"status_flag": "Success", "url": download_url},
                {"module_name": "Charge History"},
            )

            try : 
                 # End time and audit logging
                end_time = time.time()
                time_consumed = round(end_time - start_time, 4)
                audit_data_user_actions = {
                    "service_name": "export_customer_charges",    
                    "created_by": username,
                    "status": str(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "session_id": sessionID,
                    "tenant_name": partner,
                    "comments": "Exporting customer charges data",
                    "module_name":"Charges history" , 
                    "request_received_at": request_received_at,
                }
                db.update_audit(
                    audit_data_user_actions, "audit_user_actions"
                )
            except Exception as e:
                logging.warning(f"### Got Exception while updating the Audit:{e}")
            
            return response

        except Exception as e:
            logging.exception(f"### Error uploading to S3: {e}")
            return {"flag": False, "message": "Failed to upload zip file to S3"}

    except Exception as e:
        logging.exception(f"### Exception occurred: {e}")
        db.update_dict(
                "export_status",
                {"status_flag": "Failed", "url": download_url},
                {"module_name": "Charge History"},
            )
        message = "Unable to fetch the customer Charges data"
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_customer_charges",
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": sessionID,
            "tenant_name": partner,
            "comments": "Charges history data",
            "module_name":"Charges history" ,
            "request_received_at": request_received_at,
        }
        if db : 
            db.log_error_to_db(error_data, "error_log_table")
        response = {"flag": False, "message": message} 
        return response
 



def convert_timestamp_data(df, tenant_time_zone):
    """
    Converts specific timestamp columns in a DataFrame from UTC to the tenant's timezone.

    Args:
        df (pd.DataFrame): The input DataFrame containing timestamp columns.
        tenant_time_zone (str): The timezone string (e.g., 'Asia/Kolkata') to which timestamps should be converted.

    Returns:
        pd.DataFrame: A DataFrame with updated timestamp columns in the specified timezone as formatted strings.

    """
    # List of timestamp columns to convert
    timestamp_columns = [
        "created_date",
        "modified_date",
        "deleted_date",
        "session_created_date",
    ]  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for col in timestamp_columns:
        if col in df.columns:
            # Convert the column to datetime format if it isn't already
            df[col] = pd.to_datetime(df[col], errors="coerce")
            # Localize the datetime column to UTC if it's naive
            df[col] = df[col].dt.tz_localize("UTC", ambiguous="NaT", nonexistent="NaT")
            # Convert to the target timezone
            df[col] = df[col].dt.tz_convert(tenant_time_zone)
            # Format as string if needed (optional)
            df[col] = df[col].dt.strftime("%m-%d-%Y %I:%M:%S %p")

    return df


def serialize_data(data):
    """
    Recursively converts pandas-specific objects (like pd.Timestamp) into JSON-serializable types.

    This function:
    - Converts pandas Timestamp objects into formatted strings (MM-DD-YYYY HH:MM:SS)
    -Useful when preparing data for JSON responses or storing in systems that don't support pandas objects.

    Args:
        data (any): The input data structure (can be a dict, list, or single value) possibly containing pandas objects.

    Returns:
        any: A fully serialized version of the input data, safe for JSON conversion or storage.
    """
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        return data.strftime("%m-%d-%Y %H:%M:%S")  # Convert to string
    else:
        return data  # Return as is if not a pandas object




def get_export_status(data):
    """
    Fetches the export status for a specified module from the database.

    Args:
        data (dict): A dictionary containing the `module_name` key to specify the module whose export status is being requested.

    Returns:
        dict: A response dictionary with a flag indicating success or failure and the export status data.
              If successful, it returns the export status data for the specified module.
              If unsuccessful, it returns an empty list and a failure flag.
    """
    # Initialize values early for exception block access
    module_name = data.get("module_name")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    common_utils_database = None

    try:
        start_time = time.time()
        # connect to Database 
        common_utils_database = DB("common_utils", **db_config)

        export_status_query = (
            f"select * from export_status where module_name='{module_name}'"
        )
        export_status_data = common_utils_database.execute_query(
            export_status_query, True
        ).to_dict(orient="records")
        response = {"flag": True, "export_status_data": export_status_data[0]}

        try:
            end_time = time.time()
            time_consumed = round(end_time - start_time, 4)

            # Success audit logging
            audit_data_user_actions = {
                "service_name": "get_export_status",
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": sessionID,
                "tenant_name": tenant_name,
                "comments": "Fetched export status data",
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Got Exception while updating the Audit: {e}")

        return response

    except Exception as e:
        try:
            logging.exception(f"### Exception occurred: {e}")
            message = "Unable to fetch the export status data"
            error_type = str(type(e).__name__)
            error_data = {
                "service_name": "get_export_status",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": sessionID,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            if common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.warning(f"### Got Exception while auditing error: {e}")

        return {"flag": False, "export_status_data": []}

