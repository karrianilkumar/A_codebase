"""
main.py
Module for handling API requests and routing them to the appropriate function.
Functions:
- lambda_handler(event,context=None)
Author: Vyshnavi, Tejashwini Kottha
Date: July 22, 2024
"""

import boto3
import json
import time
from datetime import datetime
import pytz
from common_utils.db_utils import DB
import os
import boto3

# from common_utils.daily_migration_management.migration_api import MigrationScheduler
from common_utils.email_trigger import (
    send_sns_email,
    get_memory_usage,
    memory_sns,
    insert_email_audit,
)

# from migration_management.migration_api import MigrationScheduler

from migration_api_opt import MigrationScheduler

from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging

logging = Logging(name="main")
##database configuration
# db_config = {
#     'host': "amoppostgres.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
#     'port': "5432",
#     'user': "root",
#     'password': "AmopTeam123"}

db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}

# Initialize the SNS client
sns = boto3.client("sns")
sqs_client = boto3.client("sqs", region_name="us-east-1")
cloudwatch = boto3.client("cloudwatch")


def delete_message_from_sqs(receipt_handle, data):
    try:
        QueueUrl=os.getenv("OPTIMIZATION_QUEUE_URL")
        response = sqs_client.delete_message(
            QueueUrl=QueueUrl,
            # QueueUrl="https://sqs.us-east-1.amazonaws.com/008971638399/optimisation_sync_uat.fifo",
            ReceiptHandle=receipt_handle,
        )
        if response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            logging.info(f"Message deleted from SQS successfully. , message is {data}")
        else:
            logging.warning(f"Failed to delete message: {response}")

    except Exception as e:
        logging.error(f"Error deleting message from SQS: {e}")
        raise


def lambda_handler(event, context):
    """
    Handles incoming API requests and routes them to the appropriate function.

    Args:
        event (dict): The incoming API request event.

    Returns:
        dict: A dictionary containing the response status code and body.

    Example:
        >>> event = {'data': {'path': '/get_modules'}}
        >>> lambda_handler(event)
        {'statusCode': 200, 'body': '{"flag": True, "modules": [...]}'}
    """

    print("event------------", event)
    # Extract the HTTP method, path, and query string parameters from the event

    if "Records" in event:
        # Extract the SQS message body
        sqs_message = event["Records"][-1]
        receipt_handle = sqs_message.get("receiptHandle")
        print("receipt--------------", receipt_handle)
        body = sqs_message.get("body")
        if body:
            data = json.loads(body)  # Parse the JSON message body

            # Check if the message has the sqs_flag set to True
            if data.get("sqs_flag"):
                print("Processing SQS message with sqs_flag set to True")
                path = data.get("path", "")
                if receipt_handle:
                    try:
                        # Call your delete function here (make sure to pass the receipt_handle)
                        delete_message_from_sqs(receipt_handle, data)
                        print("Message deleted successfully after processing.")
                    except Exception as e:
                        print(f"Error deleting message from SQS: {e}")
    else:
        data = event.get("data")
        if not data:
            data = {}

        data = data.get("data", {})
        path = data.get("path", "")
        user = (
            data.get("username")
            or data.get("user_name")
            or data.get("user")
            or "superadmin"
        )
        print("getting user", user)
        print("getting path ", path)
        print("condition ", data)
    # Route based on the path and method
    if path == "/optimization_sync_comm_group":
        scheduler = MigrationScheduler()
        result = scheduler.optimization_sync_comm_group(data)
    elif path == "/lambda_sync_jobs_":
        print("inside lambda sync jobs", data)
        scheduler = MigrationScheduler()
        result = scheduler.lambda_sync_jobs_(data)
    elif path == "/optimization_status_syncs":
        scheduler = MigrationScheduler()
        result = scheduler.optimization_status_syncs()
        logging.info(f"Optimization Status Syncs: {result}")
    elif path == "/push_charges_sync":
        scheduler = MigrationScheduler()
        result = scheduler.push_charges_sync(data)
    elif path == "/optimization_sync_comm_group":
        logging.info(f"comm group is running  {data}!!")
        scheduler = MigrationScheduler()
        result = scheduler.optimization_sync_comm_group(data)
        logging.info(f"comm group running done {data}!!")

    elif path == "/main_migration_func":
        scheduler = MigrationScheduler()
        # (self,job_name,key_name=None,scheduler_flag=False,data=None)
        job_name=data.get("job_name")
        key_name=data.get("key_name")
        result = scheduler.main_migration_func(job_name,key_name)
    else:
        result = {"flag": False, "error": "Invalid path or method"}

    memory_limit = int(context.memory_limit_in_mb)
    memory_used = int(get_memory_usage()) + 100
    final_memory_used = get_memory_usage()
    logging.info(
        f"$$$$$$$$$$$$$$$$$$$$$$$Final Memory Used: {final_memory_used:.2f} MB"
    )
    memory_sns(memory_limit, memory_used, context)

    return {"statusCode": 200, "body": json.dumps(result)}
