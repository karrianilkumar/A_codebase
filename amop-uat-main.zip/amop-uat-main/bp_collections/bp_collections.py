"""
@Author1 : Srikanth R
Created Date: 27-12-2024
"""

# Importing the necessary Libraries
import ast
import boto3
import requests
import os
import pandas as pd
from common_utils.billing_platform_email_trigger import send_email, send_email_without_template
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import datetime
from datetime import time
from datetime import datetime, timedelta
import time
from io import BytesIO
from common_utils.data_transfer_main import DataTransfer
import json
import base64
import re
import pytds
from pytz import timezone
import numpy as np
from collections import defaultdict
#download template dependencies
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
from io import StringIO
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
import csv
from openpyxl import load_workbook
from openpyxl import Workbook
from pytz import UnknownTimeZoneError, timezone
import pandas as pd
import psycopg2
import random
import string

# Dictionary to store database configuration settings retrieved from environment variables.
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema":False
}
db_config_common_utils = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}
logging = Logging(name="sim_management")


def get_headers_mapping(tenant_database, module_list, role, user, tenant_id, sub_parent_module, parent_module, data,):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.

    This function:
    - Connects to the database.
    - Fetches field mappings and categorizes them into pop-ups, general fields, and table fields.
    - Retrieves and processes module features based on user roles.
    - Returns a structured dictionary containing headers and features for each module.

    Parameters:
        tenant_database (str): The database name of the tenant.
        module_list (list): List of module names to fetch field mappings for.
        role (str): The role of the user (e.g., 'Super Admin').
        user (str): The username of the user.
        tenant_id (int): The ID of the tenant.
        sub_parent_module (str): The name of the sub-parent module.
        parent_module (str): The name of the parent module.
        data (dict): Additional input data, which may contain:
            - feature_module_name (str): The feature module name.
            - username/user_name/user (str): The username.
            - tenant_name/tenant (str): The tenant name.

    Returns:
        dict: A dictionary where each module name maps to its corresponding headers and features.
    """
    # Establish database connections
    database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    billing_platform_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    
    # Extract relevant details from the input data dictionary
    main_module_name=data.get("main_module_name", "Customer Profiles")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")
    parent_module_name = data.get("parent_module", "Billing Platform")
    print(f'tenant_name-----{tenant_name}')

    tenant_id_query = database.get_data(
        "tenant", {"tenant_name": tenant_name},["id"]
    )
    tenant_id = tenant_id_query["id"].to_list()[0]
    print(f"tenant_id_query-------{tenant_id_query}")
    # try:
    #     # Retrieve tenant ID based on tenant name
    #     tenant_id = database.get_data(
    #         "tenant", {"tenant_name": tenant_name}["id"]
    #     )
    #     print(f'tenant_id--------{tenant_id}')
    # except Exception as e:
    #     print(f"Getting exception at fetching tenant id {e}")
    
    ret_out = {}
    
    # Iterate over each module name in the provided module list
    for module_name in module_list:
        out = billing_platform_database.get_data(
            "field_column_mapping", {"module_name": module_name}
        ).to_dict(orient="records")
        pop_up = []
        general_fields = []
        table_fileds = {}
        # Categorize the fetched data based on field types
        for data in out:
            if data["pop_col"]:
                pop_up.append(data)
            elif data["table_col"]:
                table_fileds.update(
                    {
                        data["db_column_name"]: [
                            data["display_name"],
                            data["table_header_order"],
                        ]
                    }
                )
            else:
                general_fields.append(data)
        # Create a dictionary to store categorized fields
        headers = {}
        headers["general_fields"] = general_fields
        pop_up = sorted(pop_up, key=lambda x: x['id'])
        headers["pop_up"] = pop_up
        headers["header_map"] = table_fileds
        try:
            final_features = []

            # Fetch all features for the 'super admin' role
            if role.lower() == "super admin":
                all_features = database.get_data(
                    "module_features", {"module": main_module_name}, ["features"]
                )["features"].to_list()
                if all_features:
                    final_features = json.loads(all_features[0])
            else:
                final_features = get_features_by_feature_name(
                    user_name, tenant_id, main_module_name, database,parent_module_name,role
                )

        except Exception as e:
            logging.exception(f"there is some error {e}")
            pass
        # Add the final features to the headers dictionary
        headers["module_features"] = final_features
        if module_name in ["Customer Services Carrier","Customer Services Customer"]:
            module_name = "Customer Services"
        ret_out[module_name] = headers

    return ret_out



def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name, role
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        logging.debug("Raw user features fetched: %s", user_features_raw)

        if not user_features_raw or user_features_raw[0] is None:
            query=f'''select module_features from role_module where role='{role}'
            '''
            user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
        
        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  
        
        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        print(
            "Retrieved features: %s", features_list
        )  

    except Exception as e:
        # Catch any exceptions and log a warning
        logging.warning("There was an error while fetching features: %s", e)

    return features_list  # Return the list of retrieved features

def data_update_db(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        logging.info(f'INchanged_data---------{changed_data}---{unique_id}------{table_name}')

        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            logging.info("***update_data",update_data)
            # Perform the update operation
            db.update_dict(table_name, update_data, {"id": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def convert_timestamp(df_dict, tenant_time_zone):
    """
    Convert timestamp columns in the provided dictionary list to the tenant's timezone.

    Parameters:
        df_dict (list of dict): A list of dictionaries where each dictionary represents a record
                                containing timestamp fields.
        tenant_time_zone (str): The timezone to which the timestamps should be converted.

    Returns:
        list of dict: The updated list of dictionaries with timestamps converted to the tenant's timezone.
    """
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y %H:%M:%S')  # Ensure it's a string
    return df_dict

def serialize_data(data):
    """Recursively convert pandas objects in the data structure to serializable types."""
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        return data.strftime('%m-%d-%Y %H:%M:%S')  # Convert to string
    else:
        return data  # Return as is if not a pandas object
def collections_list_view(data):
    """
    Retrieves a paginated and sorted list of customer collection templates, including filtering, 
    dropdown options, and timezone adjustments.

    Args:
        data (dict): A dictionary containing:
            - table_name (str, optional): Name of the table (default: 'collection_templates').
            - role_name (str, optional): User's role for permissions.
            - tenant_name (str, optional): Tenant name for fetching timezone.
            - mod_pages (dict, optional): Pagination details {start, end}.
            - col_sort (dict, optional): Sorting preferences.
            - module_name (str, optional): Module name for header mapping.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - data (dict): Customer collection templates with pagination.
            - header_map (dict): Mapped headers for UI display.
            - dropdown (dict): Dropdown values for collection steps.
            - pages (dict): Pagination details.
    """

    # Database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    killbill_database =  DB(os.environ["BILLING_PLATFORM"] ,**db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    
    # Extract relevant details from the input data dictionary
    table_name = data.get('table_name','collection_templates')
    role_name = data.get('role_name', '')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    module_name=data.get('module_name', '')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1

    # Set default pagination if not provided
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)

    limit = end - start
    offset = start

    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

    # Get total customer profile count
    total_count_result = killbill_database.get_data(
            table_name, {"is_deleted": "false","tenant_id": tenant_id},["id"]
        )["id"].to_list()
    total_count=len(total_count_result)

    # Pagination information
    pages_data = {
        "start": start,
        "end": end,
        "total": total_count
    }

    # Sort order handling (ensure valid keys)
    if col_sort:
        order =  {k: v.lower() for k, v in col_sort.items()}
        # logging.info("orderis",order)
    else:
        order= {"modified_date":"desc"}

    # Fetch paginated customer profiles from the database
    df_dict= killbill_database.get_data(
        table_name=table_name,
        condition={"is_deleted": "false","tenant_id": tenant_id},
        columns=None,
        order=order,
        mod_pages={"start": start, "end": end}
    ).to_dict(orient="records")

    # Convert timestamps to the tenant's timezone
    df_dict = convert_timestamp(df_dict, tenant_time_zone)
    # logging.info('####df_dict',df_dict)
    # add_a_step=['Letter','Email','Phone Call','Text Message (SMS)','2-Way Suspend','1-Way Suspend','Block LD','Disconnect','Manual Step']
    add_a_step=['Email','Disconnect','Manual Step']
    # Compile dropdown options
    collection_steps={
        "step_type":add_a_step
    }
    try:
        # Fetch mapped headers
        header_map = get_headers_mapping(killbill_database,["Collection Templates",module_name],role_name, '', '', '', '',data)

        # Serialize customer profiles
        data_dict_all = {"collection_templates": serialize_data(df_dict)}
        logging.info(f'###data_dict_all {data_dict_all}')

         # Construct success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "dropdown":collection_steps,
            "pages": pages_data
        }
        return response

    except Exception as e:
        logging.info(f"Exception occurred: {e}")
        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching Collections list",
            "data": {}  # Return empty dictionary on error
        }
        return response

def add_step_data(data):
    """
    Retrieves step-specific data for collection processes, including relevant columns, dropdown options, and header mappings.

    Args:
        data (dict): A dictionary containing:
            - options (str): The type of collection step (e.g., 'Letter', 'Email', 'Phone Call', etc.).
            - role_name (str, optional): User's role for permissions.
            - module_name (str, optional): Module name for header mapping.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - columns (list): List of relevant columns for the selected step.
            - dropdown (dict): Dropdown values for applicable fields.
            - header_map (dict): Mapped headers with filtered pop-up data.

    Raises:
        ValueError: If an invalid step type is provided.
    """
    try:
        # Extract input values with defaults
        option = data.get("options", "")
        role_name = data.get('role_name', '')
        module_name = data.get('module_name', '')

        # Initialize database connection
        try:
            killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
        except KeyError:
            logging.error("Environment variable 'BILLING_PLATFORM' is missing.")
            return {"flag": False, "message": "Server configuration error: Missing database environment variable."}
        except Exception as e:
            logging.error(f"Database connection failed: {str(e)}")
            return {"flag": False, "message": "Database connection failed."}

        # Define default dropdown values
        display_options = ['PDF', 'PDF Zip', 'Pitney Bowes', 'SpanDocs']
        copy_to_ftp = ['None']
        to_contacts = ['Administrative', 'Agent', 'Billing', 'DocuSign Approver', 'General', '--None--', 
                       'Notifications', 'Other', 'Primary', 'Secondary', 'Technical', 'Vendor']
        include_invoice = ['None', 'Most Recent Invoice', 'All Overdue Invoices']
        close_reason = ['Business Downturn', 'Collections', 'Competitive Loss', 
                        'Non Payment', 'Upgrade_Migration', 'Write-Off']

        # Group dropdowns in a dictionary
        dropdown = {
            "display_option": display_options,
            "copy_to_ftp": copy_to_ftp,
            "to_contact": to_contacts,
            "contact_override":to_contacts,
            "include_invoice": include_invoice,
            "close_reason": close_reason
        }

        # Retrieve header mapping based on module and role
        try:
            header_map = get_headers_mapping(killbill_database, [module_name], role_name, '', '', '', '', data)
        except Exception as e:
            logging.error(f"Error fetching header mapping: {str(e)}")
            return {"flag": False, "message": "Failed to fetch header mappings."}

        logging.info(f'### header_map: {header_map}')

        # Define step-specific columns
        step_columns = {
            "Letter": ['step_description', 'grace_period', 'display_option', 'copy_to_ftp'],
            "Email": ['step_description', 'grace_period', 'from_mail', 'to_contact', 'cc', 'bcc', 
                      'subject', 'include_invoice', 'preview_email'],
            "Phone Call": ['step_description', 'grace_period', 'contact_override'],
            "Text Message (SMS)": ['step_description', 'grace_period', 'contact_override'],
            "2-Way Suspend": ['step_description', 'grace_period'],
            "1-Way Suspend": ['step_description', 'grace_period'],
            "Block LD": ['step_description', 'grace_period'],
            "Disconnect": ['step_description', 'grace_period', 'close_reason'],
            "Manual Step": ['step_description', 'grace_period', 'email_alert']
        }

        # Convert case-insensitive step names for matching
        columns = step_columns.get(option, None)

        if columns is None:
            logging.warning(f"Invalid step option provided: {option}")
            return {"flag": False, "message": "Invalid Step"}
        columns.append('day')
        columns.append('step_type')
        # Filter pop-up data to only include relevant columns
        pop_up_data = header_map.get(module_name, {}).get('pop_up', [])
        filtered_pop_up = [i for i in pop_up_data if i.get('db_column_name') in columns]

        # Update the header map with filtered pop-up data
        header_map[module_name]['pop_up'] = filtered_pop_up

        return {
            "flag": True,
            "columns": columns,
            "message": "Data fetched successfully",
            "dropdown": dropdown,
            "header_map": header_map
        }

    except Exception as e:
        logging.error(f"Unexpected error in add_step_data: {str(e)}")
        return {"flag": False, "message": "An unexpected error occurred while processing the request."}

def generate_unique_text():
    """Generate a random 10-character alphanumeric string."""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=10))
def previous_grace_period(killbill_database,table_name,steps_text_data):    
    try:
        service_provider_query=killbill_database.get_data(table_name,condition={'steps_text_data':steps_text_data},columns=["steps_data"],order={'id':'desc'})
        provider_list_dup = service_provider_query['steps_data'].tolist()[0]
        logging.info(f'provider_list_dup {provider_list_dup}')
        prev_grace_period=provider_list_dup['day']
        logging.info(f'prev_grace_period {prev_grace_period}')
        return prev_grace_period
    except Exception as db_error:
        logging.info(f"### Database Error: {str(db_error)}")
        return 0

def create_new_step(data):
    """
    Inserts a new collection step and returns the unique step_text_data.

    Args:
        data (dict): A dictionary containing:
            - changed_data (dict): The step data to be inserted.
            - table_name (str, optional): Name of the table (default: 'collection_steps_temp_data').

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - step_text_data (str, optional): Generated unique step identifier.
            - message (str, optional): Error message if applicable.
    """
    # Extract input data
    changed_data = data.get('changed_data', {})
    table_name = data.get('step_table_name', 'collection_steps_temp_data')
    steps_text_data=data.get('steps_text_data','')
    killbill_database=DB(os.environ['BILLING_PLATFORM'], **db_config)
    if steps_text_data:
        previous_grace_period_value=previous_grace_period(killbill_database,table_name,steps_text_data)
        current_grace_period=changed_data.get('grace_period','0')
        day=str(int(previous_grace_period_value)+int(current_grace_period))
    else:
        day=changed_data.get('grace_period','0')
    changed_data['day']=day
    logging.info(f'###data{data}')
    try:
        # Generate unique step text
        if not steps_text_data:
            steps_text_data = generate_unique_text()
        logging.info(f'###steps_text_data {steps_text_data}')
        # Convert dictionary to JSON string
        json_data = json.dumps(changed_data)

        # Connect to the database
        conn = psycopg2.connect(
            dbname=os.environ['BILLING_PLATFORM'],
            user=os.environ['USER'],
            password=os.environ['PASSWORD'],
            host=os.environ['HOST'],
            port=os.environ['PORT']
        )
        cur = conn.cursor()

        # Insert data into the table
        insert_steps_query = f"""
        INSERT INTO {table_name} (steps_data, steps_text_data) 
        VALUES (%s, %s) RETURNING steps_text_data;
        """
        cur.execute(insert_steps_query, (json_data, steps_text_data))  # Ensure it is a tuple
        steps_text_data = cur.fetchone()[0]  # Fetch the inserted steps_text_data
        logging.info(f'##after query steps_text_data{steps_text_data}')
        # Commit the transaction
        conn.commit()

        return {'flag': True, "steps_text_data": steps_text_data}

    except Exception as e:
        print(f"Exception occurred: {e}")
        return {'flag': False, "message": "Failed to create new Step"}

    finally:
        # Ensure proper cleanup
        if cur:
            cur.close()
        if conn:
            conn.close()

# def clean_data(row):
#     """
#     Filters the keys with empty values from the dictionary
#     """
#     return {k: v for k, v in row.items() if v not in (None, "None", "")}
def clean_data(row):
    """
    Filters out keys with empty values (None, "None", or "") from the dictionary,
    but ensures 'content_data' is always included as a string if present.
    """
    # cleaned = {k: v for k, v in row.items() if v not in (None, "None", "") or k == "content_data"}
    cleaned = {
        k: v for k, v in row.items()
        if (v not in (None, "None", "") or k == "content_data") and k != "id"
    }
    
    # Convert content_data to string if it exists
    if "content_data" in cleaned:
        cleaned["content_data"] = str(cleaned["content_data"])
    
    return cleaned

def create_new_collection(data):
    """
    Creates a new collection template and associated steps in the database.

    Args:
        data (dict): A dictionary containing:
            - db_name (str, optional): Tenant database name (default: 'altaworx_central').
            - step_table_name (str, optional): Table name for collection steps (default: 'collection_steps').
            - template_table_name (str, optional): Table name for collection templates (default: 'collection_templates').
            - module_name (str, optional): Module name for logging (default: 'Collections Steps').
            - username (str): User performing the creation.
            - session_id (str, optional): User session ID.
            - role_name (str): User's role for permissions.
            - tenant_name (str): Tenant name.
            - changed_data (dict): Dictionary
    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Status message.

    Raises:
        ValueError: If required fields are missing or insertions fail.
    """
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)

    tenant_database = data.get('db_name', 'altaworx_central')
    step_table_name = data.get('step_table_name', 'collection_steps')
    template_table_name = data.get('template_table_name', 'collection_templates')
    module_name = data.get('module_name', 'Collections Steps')
    created_by = data.get('username', '')
    modified_by = data.get('username', '')
    modified_date = data.get('request_received_at', '')
    Partner = data.get("Partner", "")
    username = data.get("username", "")
    session_id = data.get("session_id", "")
    role_name = data.get('role_name', '')
    tenant_name = data.get('tenant_name', '')
    changed_data = data.get('changed_data', {})
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1

    # step_changed_data = data.get('changed_data', {}).copy()  # Use copy to avoid modifying the original dict
    step_changed_data=changed_data.get('stepsData','')
    for step in step_changed_data:
        if step.get("step_type") == "Email":
            step["email_alert"] = True
    logging.info(f'step_changed_data--------{step_changed_data}')
    if "stepsData" in changed_data:
        changed_data.pop('stepsData','')
    template_change_data = {}

    # Move specific keys to the template data
    if 'template_description' in changed_data:
        template_change_data['template_description'] = changed_data.pop('template_description')
    if 'balance_limit' in changed_data:
        template_change_data['balance_limit'] = changed_data.pop('balance_limit')

    template_change_data['created_by'] = created_by
    template_change_data['modified_by'] = modified_by

    # step_changed_data = {k: str(v) for k, v in step_changed_data.items() if v not in (None, "None", "")}
    logging.info(f'##after step_changed_data {step_changed_data}')
    template_change_data = {k: str(v) for k, v in template_change_data.items() if v not in (None, "None", "")}
    logging.info(f'##after template_change_data {template_change_data}')
    conn = psycopg2.connect(
            dbname=os.environ['BILLING_PLATFORM'],
            user=os.environ['USER'],
            password=os.environ['PASSWORD'],
            host=os.environ['HOST'],
            port=os.environ['PORT']
        )
    cur = conn.cursor()

    # Insert into collection_templates and return the template ID
    insert_template_query = f"""
        INSERT INTO {template_table_name} (template_description, balance_limit, created_by, modified_by, tenant_name, tenant_id) 
        VALUES (%s, %s, %s, %s, %s, %s) RETURNING id;
    """
    cur.execute(insert_template_query, (
        template_change_data.get('template_description', ''),
        template_change_data.get('balance_limit', 0),
        template_change_data.get('created_by', ''),
        template_change_data.get('modified_by', ''),
        tenant_name,
        tenant_id if tenant_id else None
    ))
    template_id = cur.fetchone()[0]  # Fetch the returned ID
    if template_id:
        logging.info(f'####template_id {template_id}')
        logging.info(f'type-------{type(template_id)}')
        # Iterate through each step and add template_id
        for step in step_changed_data:
            if 'id' in step:
                step.pop('id')
            if 'is_active' in step:
                step.pop('is_active', '')
            if 'deleted_by' in step:
                step.pop('deleted_by', '')
            if 'is_deleted' not in step:
                step['is_deleted'] = False  # or True, as per your business logic
            val = step.get("include_invoice")
            if val in ['Most Recent Invoice', 'All Overdue Invoices']:
                step.pop("include_invoice", None)
            step['template_id'] = template_id
    else:
        return {'flag':False,"message":"Template Id Empty"}
    logging.info(f'####step_changed_data2 {step_changed_data}')
    
    conn.commit()
    cur.close()
    conn.close()
    logging.info(f'Fetched template_id: {template_id}, Type: {type(template_id)}')
    filtered_step_changed_data = [clean_data(row) for row in step_changed_data]
    logging.info(f'##filtered_step_changed_data {filtered_step_changed_data}')
    required_keys = {'step_description', 'grace_period', 'cc', 'subject', 'step_type', 'content_data', 'day', 'template_id'}
    for row in filtered_step_changed_data:
        for key in required_keys:
            row.setdefault(key, None)
    status=killbill_database.insert_data(filtered_step_changed_data, step_table_name)
    if status:
        response = {
            "flag": True,
            "message": "Successfully added a Step"
        }
    else:
        response = {
            "flag": False,
            "message": "Error Adding a Step"
        }

    return response

def update_collection_data_backup(data):
    """
    Updates collection template and step data in the database.
    Args:
        data (dict): A dictionary containing:
            - db_name (str, optional): Tenant database name (default: 'altaworx_central').
            - step_table_name (str, optional): Table name for collection steps (default: 'collection_steps').
            - template_table_name (str, optional): Table name for collection templates (default: 'collection_templates').
            - module_name (str, optional): Module name for logging (default: 'Collections Steps').
            - username (str): User performing the update.
            - session_id (str, optional): User session ID.
            - role_name (str): User's role for permissions.
            - tenant_name (str): Tenant name.
            - changed_data (dict): Dictionary
    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Status message.
    Raises:
        ValueError: If required fields are missing or updates fail.
    """
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    step_table_name = data.get('step_table_name', 'collection_steps')
    template_table_name = data.get('template_table_name', 'collection_templates')
    module_name = data.get('module_name', 'Collections Steps')
    created_by = data.get('username', '')
    modified_by = data.get('username', '')
    modified_date = data.get('request_received_at', '')
    Partner = data.get("Partner", "")
    username = data.get("username", "")
    session_id = data.get("session_id", "")
    role_name = data.get('role_name', '')
    tenant_name = data.get('tenant_name', '')
    changed_data = data.get('changed_data', {})
    step_changed_data = changed_data.get('stepsData', [])  # Use copy to avoid modifying the original dict
    template_change_data = {}
    template_id=changed_data.get('id','')
    created_date=changed_data.get('created_date','')
    template_description=changed_data.get('template_description','')
    created_by=changed_data.get('created_by','')
    modified_date=changed_data.get('modified_date','')
    modified_by=changed_data.get('modified_by','')
    balance_limit=changed_data.get('balance_limit','')
    is_deleted=changed_data.get('is_deleted','')
    template_change_data['created_date']=created_date
    template_change_data['created_by']=created_by
    template_change_data['modified_date']=modified_date
    template_change_data['modified_by']=modified_by
    template_change_data['balance_limit']=balance_limit
    template_change_data['is_deleted']=is_deleted
    template_change_data['template_description']=template_description
    steps_list = []
    try:
        steps_list_query=killbill_database.get_data("collection_steps",{"template_id":template_id},["id"])
        if not steps_list_query.empty:
            steps_list=steps_list_query['id'].to_list()
    except Exception as e:
        print(f"Error: {e}")
    template_change_data = {k: str(v) for k, v in template_change_data.items() if v not in (None, "None", "")}
    print(f'##after template_change_data {template_change_data}')
    update_status=killbill_database.update_dict(template_table_name, template_change_data, {"id":template_id})
    if update_status:
        for step in step_changed_data:
            step_id=step.get('id', '')
            if 'is_active' in step:
                step.pop('is_active', '')
            if 'deleted_by' in step:
                step.pop('deleted_by', '')
            if not step_id:
                step['template_id']=template_id
                status=killbill_database.insert_data(step, step_table_name)
                if status:
                    continue
                else:
                    return {'flag':False,'message':'Failed to Update the Steps'}
            elif step_id not in steps_list:
                step.pop('id','')
                step['template_id']=template_id
                status=killbill_database.insert_data(step, step_table_name)
                if status:
                    continue
                else:
                    return {'flag':False,'message':'Failed to Update the Steps'}
            if 'id' in step:
                step.pop('id', '')
            print(f'###step {step}')
            step = {k: str(v) for k, v in step.items() if v not in (None, "None", "")}
            step_update_status=killbill_database.update_dict(step_table_name, step, {"id": str(step_id)})
            if not step_update_status:
                return {'flag':False,'message':'Failed to Update'}
        return {'flag':True,'message':'Successfully Updated'}
    return {'flag':False,'message':'Failed to Update'}

def update_collection_data(data):
    logging.info(f"### update_collection_data function called with data: {data}")
    """
    Updates collection template and step data in the database.
    Args:
        data (dict): A dictionary containing:
            - db_name (str, optional): Tenant database name (default: 'altaworx_central').
            - step_table_name (str, optional): Table name for collection steps (default: 'collection_steps').
            - template_table_name (str, optional): Table name for collection templates (default: 'collection_templates').
            - module_name (str, optional): Module name for logging (default: 'Collections Steps').
            - username (str): User performing the update.
            - session_id (str, optional): User session ID.
            - role_name (str): User's role for permissions.
            - tenant_name (str): Tenant name.
            - changed_data (dict): Dictionary
    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Status message.
    Raises:
        ValueError: If required fields are missing or updates fail.
    """
    # Extract all required parameters from Payload
    step_table_name = data.get('step_table_name', 'collection_steps')
    template_table_name = data.get('template_table_name', 'collection_templates')
    module_name = data.get('module_name', 'Collections Steps')
    request_received_at = data.get("modified_date", "")
    partner = data.get("Partner", "")
    username = data.get("username", "")
    session_id = data.get("session_id", "")
    changed_data = data.get('changed_data', {})
    step_changed_data = changed_data.get('stepsData', [])  # Use copy to avoid modifying the original dict
    template_id=changed_data.get('id','')
    created_date=changed_data.get('created_date','')
    template_description=changed_data.get('template_description','')
    created_by=changed_data.get('created_by','')
    modified_date=changed_data.get('modified_date','')
    modified_by=changed_data.get('modified_by','')
    balance_limit=changed_data.get('balance_limit','')
    is_deleted=changed_data.get('is_deleted','')

    # Initialization of template_change_data to update the template data
    template_change_data = {}
    #parameter's to update the template
    template_change_data['created_date']=created_date
    template_change_data['created_by']=created_by
    template_change_data['modified_date']=modified_date
    template_change_data['modified_by']=modified_by
    template_change_data['balance_limit']=balance_limit
    template_change_data['is_deleted']=is_deleted
    template_change_data['template_description']=template_description

    # start time
    start_time = time.time()

    # DB connections
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)

    # Fetching the Steps list tagged with the template ID
    steps_list = []
    try:
        steps_list_query=killbill_database.get_data("collection_steps",{"template_id":template_id},["id"])
        if not steps_list_query.empty:
            steps_list=steps_list_query['id'].to_list()
    except Exception as e:
        logging.info(f"update_collection_data function : Error - {e}")
    template_change_data = {k: str(v) for k, v in template_change_data.items() if v not in (None, "None", "")}
    logging.info(f'update_collection_data function : {template_change_data}')

    # Update the template data in the database
    update_status=killbill_database.update_dict(template_table_name, template_change_data, {"id":template_id})
    if update_status:
        # Update the steps list in the database
        for step in step_changed_data:
            # Check if step is presented or not
            step_id=step.get('id', '')
            # If unwanted elements presented , pop them
            if 'is_active' in step:
                step.pop('is_active', '')
            if 'deleted_by' in step:
                step.pop('deleted_by', '')
            # If step is not presented in the steps list, create new step
            if not step_id:
                step['template_id']=template_id
                status=killbill_database.insert_data(step, step_table_name)
                if status:
                    continue
                else:
                    message = f"Failed to add new step for template {template_id}"
                    logging.info(f"update_collection_data function : {message}")
                    response_data = {"flag": False, "message": message}

                    # Prepare error data for logging
                    error_data = {
                        "service_name": "update_collection_data",
                        "error_message": message,
                        "error_type": message,
                        "users": username,
                        "session_id": session_id,
                        "tenant_name": partner,
                        "comments": json.dumps(changed_data),
                        "module_name": module_name,
                        "request_received_at": request_received_at,
                    }
                    
                    # Log error to database for debugging and monitoring
                    common_utils_db.log_error_to_db(error_data, "error_log_table")
                    return response_data
            # If step ID is not presented in the steps list ,Create new step (in this case Step Id generated from UI as it is a new)
            elif step_id not in steps_list:
                # Remove Id from the step data as it is generated from UI
                step.pop('id','')
                step['template_id']=template_id
                status=killbill_database.insert_data(step, step_table_name)
                if status:
                    continue
                else:
                    message = f"Failed to add new step for template {template_id}"
                    logging.info(f"update_collection_data function : {message}")
                    response_data = {"flag": False, "message": message}

                    # Prepare error data for logging
                    error_data = {
                        "service_name": "update_collection_data",
                        "error_message": message,
                        "error_type": message,
                        "users": username,
                        "session_id": session_id,
                        "tenant_name": partner,
                        "comments": json.dumps(changed_data),
                        "module_name": module_name,
                        "request_received_at": request_received_at,
                    }
                    
                    # Log error to database for debugging and monitoring
                    common_utils_db.log_error_to_db(error_data, "error_log_table")
                    return response_data
            # If step ID is presented in the steps list , Remove before update
            if 'id' in step:
                step.pop('id', '')
            logging.info(f'update_collection_data function : {step}')
            step = {k: str(v) for k, v in step.items() if v not in (None, "None", "")}
            step_update_status=killbill_database.update_dict(step_table_name, step, {"id": str(step_id)})
            if not step_update_status:
                message = "Failed to Update the step"
                logging.info(f"update_collection_data function : {message}")
                response_data = {"flag": False, "message": message}

                # Prepare error data for logging
                error_data = {
                    "service_name": "update_collection_data",
                    "error_message": message,
                    "error_type": message,
                    "users": username,
                    "session_id": session_id,
                    "tenant_name": partner,
                    "comments": json.dumps(changed_data),
                    "module_name": module_name,
                    "request_received_at": request_received_at,
                }
                
                # Log error to database for debugging and monitoring
                common_utils_db.log_error_to_db(error_data, "error_log_table")
                return response_data
        message = "Successfully Updated the Template"
        response_data = {"flag": True, "message": message} 

        # Calculate execution time for performance tracking
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        changed_data = {"changed_data":str(changed_data)}
        # Prepare audit data for successful operation
        audit_data_user_actions = {
            "service_name": "update_collection_data",
            "created_by": username,
            "status": str(response_data["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": partner,
            "comments": json.dumps(changed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        
        # Log successful action to audit table
        common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")
        return response_data
    
    message = "Failed to Update the Template"
    logging.info(f"update_collection_data function : {message}")
    response_data = {"flag": False, "message": message}

    # Prepare error data for logging
    error_data = {
        "service_name": "update_collection_data",
        "error_message": message,
        "error_type": message,
        "users": username,
        "session_id": session_id,
        "tenant_name": partner,
        "comments": json.dumps(changed_data),
        "module_name": module_name,
        "request_received_at": request_received_at,
    }
    
    # Log error to database for debugging and monitoring
    common_utils_db.log_error_to_db(error_data, "error_log_table")
    return response_data


def collection_steps_list_view(data):
    """
    Retrieves a paginated list of collection steps based on provided filters, sorting, 
    and tenant-specific timezone conversion.

    Args:
        data (dict): A dictionary containing:
            - db_name (str, optional): Tenant database name (default: 'altaworx_central').
            - role_name (str): User's role for permissions.
            - tenant_name (str): Tenant name for fetching timezone.
            - mod_pages (dict, optional): Pagination details {start, end}.
            - col_sort (dict, optional): Sorting preferences {column_name: "asc"/"desc"}.
            - template_id (str, optional): Identifier for filtering collection steps.
            - table_name (str, optional): Table name (default: 'collection_steps').
            - module_name (str, optional): Module name for fetching headers (default: 'Collection Steps List View').

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - data (dict): Collection steps data.
            - header_map (dict): Mapped headers for UI display.
            - pages (dict): Pagination details {start, end, total}.
    
    Raises:
        ValueError: If no valid timezone is found for the tenant.
    """
    # Database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    killbill_database =  DB(os.environ["BILLING_PLATFORM"] ,**db_config)
    
    # Extract relevant details from the input data dictionary
    table_name = data.get('table_name','collection_steps')
    role_name = data.get('role_name', '')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    module_name=data.get('module_name', 'Collection Steps List View')
    template_id=data.get('template_id', '')
    # Set default pagination if not provided
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)

    limit = end - start
    offset = start

    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

    # Get total customer profile count
    total_count_result = killbill_database.get_data(
            table_name, {"is_deleted": "false"},["id"]
        )["id"].to_list()
    total_count=len(total_count_result)

    # Pagination information
    pages_data = {
        "start": start,
        "end": end,
        "total": total_count
    }

    # Sort order handling (ensure valid keys)
    if col_sort:
        order =  {k: v.lower() for k, v in col_sort.items()}
        # logging.info("orderis",order)
    else:
        order= {"modified_date":"desc"}

    # Fetch paginated customer profiles from the database
    df_dict= killbill_database.get_data(
        table_name=table_name,
        condition={"is_deleted": "false",'template_id':template_id},
        columns=None,
        order=order,
        mod_pages={"start": start, "end": end}
    ).to_dict(orient="records")

    # Convert timestamps to the tenant's timezone
    df_dict = convert_timestamp(df_dict, tenant_time_zone)
    logging.info('####df_dict',df_dict)
    try:
        # Fetch mapped headers
        header_map = get_headers_mapping(killbill_database,[module_name],role_name, '', '', '', '',data)

        # Serialize customer profiles
        data_dict_all = {"collection_steps": serialize_data(df_dict)}
        logging.info(f'###data_dict_all {data_dict_all}')

         # Construct success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        return response

    except Exception as e:
        print(f"Exception occurred: {e}")

        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching Collections list",
            "data": {}  # Return empty dictionary on error
        }
        return response

def delete_collection_template(data):
    """
    Marks a collection template as deleted in the database.

    Args:
        data (dict): A dictionary containing:
            - db_name (str, optional): Tenant database name (default: 'altaworx_central').
            - table_name (str, optional): Table name (default: 'collection_templates').
            - module_name (str, optional): Module name for logging purposes.
            - username (str): Name of the user performing the deletion.
            - request_received_at (str, optional): Timestamp of the request.
            - Partner (str, optional): Partner details (if applicable).
            - session_id (str, optional): User session ID.
            - role_name (str, optional): User role information.
            - tenant_name (str, optional): Tenant name for reference.
            - changed_data (dict): Data containing:
                - id (str): Unique identifier of the collection template.
                - is_deleted (bool or str): Flag indicating deletion status.
            - flag (str, optional): Indicator message for deletion.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.

    Raises:
        Exception: If the database update fails.
    """

    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    tenant_database = data.get('db_name', 'altaworx_central')
    table_name = data.get('table_name', 'collection_templates')
    module_name = data.get('module_name', 'Collections Templates')
    created_by = data.get('username', '')
    modified_by = data.get('username', '')
    modified_date = data.get('request_received_at', '')
    Partner = data.get("Partner", "")
    username = data.get("username", "")
    session_id = data.get("session_id", "")
    role_name = data.get('role_name', '')
    tenant_name = data.get('tenant_name', '')
    changed_data = data.get('changed_data', {})
    unique_id=changed_data.get('id','')
    is_deleted=changed_data.get('is_deleted','')
    flag=data.get('flag', '')
    update_data={"is_deleted":is_deleted}
    if not unique_id:
        return {'flag':False,"message":'Empty Template ID'}
    try:
        status=status=killbill_database.update_dict(table_name, update_data, {"id": unique_id})
        if status:
            print(f'### Updated customer_profiles')
            message=f'{flag} Deleted successfully'
            return {"flag": True, "message": message}
        else:
            raise Exception("Database Insert Failed")
    except Exception as db_error:
        print(f"### Database Error: {str(db_error)}")
        return {"flag": False, "message": "Database insertion failed"}


def collection_steps_temp_list_view(data):
    """
    Retrieves collection step details by step_id.

    Args:
        data (dict): A dictionary containing:
            - table_name (str, optional): Table name (default: 'collection_steps_temp_data').
            - role_name (str): User's role for permissions.
            - tenant_name (str): Tenant name for fetching timezone.
            - id (int): Step ID to fetch.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - data (dict): Collection step data.
            - header_map (dict): Mapped headers for UI display.
    """
    # Database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    killbill_database = DB(os.environ["BILLING_PLATFORM"], **db_config)

    # Extract relevant details from input data
    table_name = data.get('table_name', 'collection_steps_temp_data')  # Default table
    role_name = data.get('role_name', '')
    tenant_name = data.get('tenant_name', '')
    module_name = data.get('module_name', 'Collection Steps List View')
    steps_text_data = data.get("steps_text_data", "")
    if not steps_text_data:
        return {'flag': False, "message": "Empty steps_text_data"}
    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

    try:
        # Fetch the step data from the database
        df_dict = killbill_database.get_data(
            table_name=table_name,
            condition={'steps_text_data': steps_text_data},
            columns=["id","steps_data"]  # Ensure these columns exist
        ).to_dict(orient="records")
        # Convert timestamps to the tenant's timezone (if applicable)
        df_dict = convert_timestamp(df_dict, tenant_time_zone)
        logging.info(f'####df_dict: {df_dict}')
        # Fetch mapped headers
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, '', '', '', '', data
        )
        # Serialize data 
        df_dict=serialize_data(df_dict)
        data_dict_all = {"collection_temp_steps": df_dict}
        logging.info(f'data_dict_all----------{data_dict_all}')
        #data_dict_all={"collection_temp_steps":[step["steps_data"] for step in data_dict_all.get("collection_temp_steps", [])]}
        data_dict_all = {
            "collection_temp_steps": [
                {"id": step["id"], **step["steps_data"]}
                for step in df_dict
            ]
        }
        logging.info(f'###data_dict_all: {data_dict_all}')
        return {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map
        }
    except Exception as e:
        logging.error(f"Exception occurred: {e}", exc_info=True)

        return {
            "flag": False,
            "message": "Something went wrong fetching Collections list",
            "data": {}
        }

def collections_template_edit_view(data):
    """
    Fetches collection steps data with pagination, filtering, and dropdown options.

    Args:
        data (dict): A dictionary containing:
            - table_name (str, optional): Name of the table (default: 'collection_steps').
            - role_name (str): User's role for permission handling.
            - tenant_name (str): Tenant name used to fetch timezone.
            - module_name (str): Module name for fetching header mappings.
            - template_id (str): Template ID used as a filter.
            - mod_pages (dict, optional): Pagination details {start, end}.
            - col_sort (dict, optional): Sorting preferences.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - data (dict): Collection steps data.
            - header_map (dict): Mapped headers for UI display.
            - dropdown (dict): Dropdown values for step types.
            - pages (dict): Pagination details.
    """
    # Database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    killbill_database =  DB(os.environ["BILLING_PLATFORM"] ,**db_config)
    
    # Extract relevant details from the input data dictionary
    table_name = data.get('table_name','collection_steps')
    role_name = data.get('role_name', '')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    module_name=data.get('module_name', '')
    template_id=data.get('template_id','')

    # Set default pagination if not provided
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)

    limit = end - start
    offset = start

    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

    # Get total customer profile count
    total_count_result = killbill_database.get_data(
            table_name, {"is_deleted": "false","template_id":template_id},["id"]
        )["id"].to_list()
    total_count=len(total_count_result)

    # Pagination information
    pages_data = {
        "start": start,
        "end": end,
        "total": total_count
    }

    # Sort order handling (ensure valid keys)
    # if col_sort:
    #     order =  {k: v.lower() for k, v in col_sort.items()}
    #     # logging.info("orderis",order)
    # else:
    #     order= {"modified_date":"desc"}

    # Fetch paginated customer profiles from the database
    df_dict= killbill_database.get_data(
        table_name=table_name,
        condition={"is_deleted": "false","template_id":template_id},
        columns=None,
        order={"day":"asc"},
        mod_pages={"start": start, "end": end}
    ).to_dict(orient="records")

    # Convert timestamps to the tenant's timezone
    df_dict = convert_timestamp(df_dict, tenant_time_zone)
    # logging.info('####df_dict',df_dict)
    add_a_step=['Letter','Email','Phone Call','Text Message (SMS)','2-Way Suspend','1-Way Suspend','Block LD','Disconnect','Manual Step']
    # Compile dropdown options
    collection_steps={
        "step_type":add_a_step
    }
    try:
        # Fetch mapped headers
        header_map = get_headers_mapping(killbill_database,[module_name],role_name, '', '', '', '',data)

        # Serialize customer profiles
        data_dict_all = {"collection_steps": serialize_data(df_dict)}
        logging.info(f'###data_dict_all {data_dict_all}')

         # Construct success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "dropdown":collection_steps,
            "pages": pages_data
        }
        return response

    except Exception as e:
        print(f"Exception occurred: {e}")

        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching Collections list",
            "data": {}  # Return empty dictionary on error
        }
        return response

def collection_step_edit(data):
    """
    Retrieves step-specific data for collection processes, including relevant columns, dropdown options, and header mappings.

    Args:
        data (dict): A dictionary containing:
            - options (str): The type of collection step (e.g., 'Letter', 'Email', 'Phone Call', etc.).
            - role_name (str, optional): User's role for permissions.
            - module_name (str, optional): Module name for header mapping.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - columns (list): List of relevant columns for the selected step.
            - dropdown (dict): Dropdown values for applicable fields.
            - header_map (dict): Mapped headers with filtered pop-up data.

    Raises:
        ValueError: If an invalid step type is provided.
    """
    try:
        # Extract input values with defaults
        changed_data=data.get("changed_data","")
        option = changed_data.get("step_type", "")
        if not option:
            return {'flag': False, "message": 'Empty Step Type'}
        role_name = data.get('role_name', '')
        module_name = data.get('module_name', '')
        # Initialize database connection
        try:
            killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
        except KeyError:
            logging.error("Environment variable 'BILLING_PLATFORM' is missing.")
            return {"flag": False, "message": "Server configuration error: Missing database environment variable."}
        except Exception as e:
            logging.error(f"Database connection failed: {str(e)}")
            return {"flag": False, "message": "Database connection failed."}

        # Define default dropdown values
        display_options = ['PDF', 'PDF Zip', 'Pitney Bowes', 'SpanDocs']
        copy_to_ftp = ['None']
        to_contacts = ['Administrative', 'Agent', 'Billing', 'DocuSign Approver', 'General', '--None--', 
                       'Notifications', 'Other', 'Primary', 'Secondary', 'Technical', 'Vendor']
        include_invoice = ['None', 'Most Recent Invoice', 'All Overdue Invoices']
        close_reason = ['Business Downturn', 'Collections', 'Competitive Loss', 
                        'Non Payment', 'Upgrade_Migration', 'Write-Off']

        # Group dropdowns in a dictionary
        dropdown = {
            "display_option": display_options,
            "copy_to_ftp": copy_to_ftp,
            "to_contact": to_contacts,
            "contact_override":to_contacts,
            "include_invoice": include_invoice,
            "close_reason": close_reason
        }

        # Retrieve header mapping based on module and role
        try:
            header_map = get_headers_mapping(killbill_database, [module_name], role_name, '', '', '', '', data)
        except Exception as e:
            logging.error(f"Error fetching header mapping: {str(e)}")
            return {"flag": False, "message": "Failed to fetch header mappings."}

        logging.info(f'### header_map: {header_map}')

        # Define step-specific columns
        step_columns = {
            "Letter": ['step_description', 'grace_period', 'display_option', 'copy_to_ftp_site'],
            "Email": ['step_description', 'grace_period', 'from_email', 'to_contact', 'cc', 'bcc', 
                      'subject', 'include_invoice', 'preview_email'],
            "Phone Call": ['step_description', 'grace_period', 'contact_override'],
            "Text Message (SMS)": ['step_description', 'grace_period', 'contact_override'],
            "2-Way Suspend": ['step_description', 'grace_period'],
            "1-Way Suspend": ['step_description', 'grace_period'],
            "Block LD": ['step_description', 'grace_period'],
            "Disconnect": ['step_description', 'grace_period', 'close_reason'],
            "Manual Step": ['step_description', 'grace_period', 'email_alert']
        }

        # Convert case-insensitive step names for matching
        columns = step_columns.get(option, None)

        if columns is None:
            logging.warning(f"Invalid step option provided: {option}")
            return {"flag": False, "message": "Invalid Step"}
        columns.append('day')
        columns.append('step_type')
        # Filter pop-up data to only include relevant columns
        pop_up_data = header_map.get(module_name, {}).get('pop_up', [])
        filtered_pop_up = [i for i in pop_up_data if i.get('db_column_name') in columns]

        # Update the header map with filtered pop-up data
        header_map[module_name]['pop_up'] = filtered_pop_up

        return {
            "flag": True,
            "columns": columns,
            "message": "Data fetched successfully",
            "dropdown": dropdown,
            "header_map": header_map,
            "changed_data":changed_data
        }

    except Exception as e:
        logging.error(f"Unexpected error in add_step_data: {str(e)}")
        return {"flag": False, "message": "An unexpected error occurred while processing the request."}


# def collections_mail_trigger(data):
#     """
#     Triggers email notifications for overdue customer bills based on predefined collection steps.

#     Args:
#         data (dict): A dictionary containing relevant billing and customer details.

#     Workflow:
#         1. Retrieves customer profiles from the database, filtering accounts with active collection steps.
#         2. Maps account numbers to their respective collection steps and associated email addresses.
#         3. Fetches collection step details for accounts where the step type is 'Email'.
#         4. Retrieves bill due dates for customers with valid collection steps.
#         5. Combines collection steps and billing data to determine when emails should be triggered.
#         6. Compares the due date and grace period with the current date to determine overdue bills.
#         7. Sends email notifications for accounts whose final due date has passed.
#         8. Updates the database with email step tracking details for audit purposes.

#     Returns:
#         dict: Response structure containing:
#             - flag (bool): Indicates whether the email trigger process was successful.
#             - message (str): Success or failure message.
    
#     Raises:
#         KeyError: If required environment variables or database keys are missing.
#         ValueError: If there are issues with data retrieval or processing.
#     """
#     database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
#     killbill_database =  DB(os.environ["BILLING_PLATFORM"] ,**db_config)
#     #get data from customer_profiles for email templates
#     customer_profiles_data = killbill_database.get_data(
#             "customer_profiles",
#             # None,
#             {"account_number":"300000068"},
#             ["account_number", "collection_step","email"]
#         )
#     filtered_data = customer_profiles_data[customer_profiles_data['collection_step'].notnull()]
#     # Get account numbers from the filtered data
#     collection_steps = filtered_data['collection_step'].tolist()
#     account_numbers = filtered_data['account_number'].tolist()
#     email_list=filtered_data['email'].tolist()
#     zipped_dict = dict(zip(account_numbers, collection_steps))
#     emails_zipped_data=dict(zip(account_numbers, email_list))
#     print("Unique Collection Steps:", collection_steps)
#     print(f'zipped_list--------{zipped_dict}')
#     account_data_mapping = {}
#     for account_number, template_id in zipped_dict.items():
#         # Query to fetch grace period if step_type is 'Email'
#         df_dict = killbill_database.get_data(
#             "collection_steps",
#             {"template_id": template_id, "step_type": "Email"},
#             None
#         ).to_dict(orient="records")
#         # print(f'grace_period_data--------{grace_period_data}')
#         # grace_period_data_list = grace_period_data["grace_period"].tolist()
#         # if grace_period_data_list:
#         #     grace_period = grace_period_data_list[0]  # Directly get the integer value
#         #     final_zipped_list.append((account_number, grace_period))
#         if df_dict:
#             account_data_mapping[account_number] = df_dict
#     # Convert to dictionary if needed
#     # Print the final result
#     account_numbers = list(account_data_mapping.keys())
#     account_bill_data_mapping = {}

#     for account_number in account_numbers:
#         account_number_id=killbill_database.get_data("customer_profiles",{"account_number":account_number},["id"])
#         account_number_id = account_number_id['id'].tolist()[0]
#         # df_dict = killbill_database.get_data(
#         #     "customer_bills",
#         #     {"customer_profile_id": account_number_id},
#         #     ["due_date_of_this_bill","id"]
#         # ).to_dict(orient="records")
#         yesterday_date = (datetime.now() - timedelta(days=1)).date()
#         condition = {
#         "customer_profile_id": account_number_id,
#         "due_date_of_this_bill": ('>', yesterday_date)
#         }
#         df_dict = killbill_database.get_data(
#             "customer_bills",
#             {"customer_profile_id": account_number_id},
#             ["due_date_of_this_bill","id"]
#         ).to_dict(orient="records")
#         # df_dict = killbill_database.get_data_bp(
#         #         "customer_bills",
#         #         condition,
#         #         ["due_date_of_this_bill","id"]
#         #     ).to_dict(orient="records")
#         if df_dict:
#             account_bill_data_mapping[account_number] = df_dict
#         # query = """select bill_id, bill_due_date from customer_bills where customer_profile_id = {account_number_id} and remaining > 0"""
#         # df_dict = execute_query(query, killbill_database)
#     today_date = datetime.today().date()
#     combined_data = {}
#     for account, steps in account_data_mapping.items():
#         combined_data[account] = {"steps_data": []}  # Initialize account level

#         # Get bill data for the account
#         bills = account_bill_data_mapping.get(account, [])

#         for step in steps:
#             for bill in bills:
#                 if not bill.get("due_date_of_this_bill"):  # Skip if bill_due_date is empty or null
#                     continue

#                 # Add bill_due_date and bill_id to step
#                 step_entry = step.copy()
#                 step_entry["due_date_of_this_bill"] = bill["due_date_of_this_bill"]
#                 step_entry["bill_id"] = bill["id"]
#                 combined_data[account]["steps_data"].append(step_entry)
#     for account, data in combined_data.items():
#         email_steps_data=[]
#         try:
#             email_steps_data_dict=killbill_database.get_data("customer_profiles",{"account_number":account},["steps_data"])
#             email_steps_data=email_steps_data_dict['steps_data'].tolist()[0]
#             email_steps_data=ast.literal_eval(email_steps_data)
#         except:
#             email_steps_data=[]
#             pass
#         for step in data["steps_data"]:
#             bill_due_date_str = step.get("due_date_of_this_bill")
#             grace_period_days = step.get("day", 0)  # Default to 0 if "day" is missing

#             if isinstance(bill_due_date_str, pd.Timestamp):  
#                 bill_due_date_str = bill_due_date_str.strftime("%Y-%m-%d %H:%M:%S")  

#             bill_due_date = datetime.strptime(bill_due_date_str, "%Y-%m-%d %H:%M:%S").date()

#             # Calculate final due date
#             final_due_date = bill_due_date + timedelta(days=grace_period_days)
#             final_due_datetime = datetime.combine(final_due_date, datetime.min.time())
#             now = datetime.now()
#             yesterday_start = datetime.combine(now.date() - timedelta(days=1), datetime.min.time())
#             # yesterday_date = (datetime.now() - timedelta(days=1)).date()
#             # Compare with today's date
#             # if final_due_date <= today_date:
#             if final_due_datetime <= now:
#                 print(f"Account: {account} | Bill ID: {step['bill_id']}")
#                 notification_result={}
#                 cc_emails= step.get("cc", 'srikanth.rekkala@algonox.com'),
#                 to_email = emails_zipped_data[account],
#                 subject = step.get("subject", ''),
#                 body = step.get("content_data", ''),
#                 is_html=True,
#                 step_description=step.get("step_description", ''),
#                 comments = 'Collection Email trigger'
#                 # notification_result['cc_emails']=cc_emails
#                 # notification_result['to_email']=to_email
#                 # notification_result['subject']=subject
#                 # notification_result['body']=body
#                 # notification_result['is_html']=is_html
#                 # notification_result['comments']=comments
#                 notification_result = send_email_without_template(
#                     cc_emails= step.get("cc", 'srikanth.rekkala@algonox.com'),
#                     to_email = emails_zipped_data[account],
#                     subject = step.get("subject") or "",
#                     body = step.get("content_data") or "",
#                     is_html=True,
#                     comments = 'Collection Email trigger'
#                 )
#                 current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
#                 email_step_dict={'created_date':current_time,'step_description':step_description,'modified_by':'System','reason':'AUTO','result':'Email Sent Successfully','completed_date':current_time,'canceled_date':''}
#                 email_steps_data.append(email_step_dict)
#             email_changed_data={'steps_data':str(email_steps_data)}
#             status=killbill_database.update_dict('customer_profiles', email_changed_data, {"account_number": account})
#             if status:
#                 print("Email steps data updated successfully")
#             else:
#                 print("Email steps data not updated")
#     return {'flag':True,"message":"Email triggered Successfully"}


##--main
# def collections_mail_trigger(data):
#     """
#     Triggers email notifications for overdue customer bills based on predefined collection steps.

#     Args:
#         data (dict): A dictionary containing relevant billing and customer details.

#     Returns:
#         dict: Response structure containing:
#             - flag (bool): Indicates whether the email trigger process was successful.
#             - message (str): Success or failure message.
    
#     Raises:
#         KeyError: If required environment variables or database keys are missing.
#         ValueError: If there are issues with data retrieval or processing.
#     """
#     database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
#     killbill_database = DB(os.environ["BILLING_PLATFORM"], **db_config)

#     # Step 1: Fetch customer profiles with valid collection steps
#     customer_profiles_data = killbill_database.get_data(
#         "customer_profiles",
#         # {"account_number": "300000068"},  # Replace this hardcoded value if needed
#         {'collection_step':'not Null'},
#         ["account_number", "collection_step", "email"]
#     )
#     filtered_data = customer_profiles_data[customer_profiles_data['collection_step'].notnull()]
#     account_numbers = filtered_data['account_number'].tolist()
#     collection_steps = dict(zip(account_numbers, filtered_data['collection_step']))
#     email_map = dict(zip(account_numbers, filtered_data['email']))

#     # Step 2: Fetch collection step details (only of type 'Email')
#     account_data_mapping = {}
#     for account_number, template_id in collection_steps.items():
#         step_data = killbill_database.get_data(
#             "collection_steps",
#             {"template_id": template_id, "step_type": "Email","is_deleted":False},
#             None
#         ).to_dict(orient="records")
#         if step_data:
#             account_data_mapping[account_number] = step_data

#     # Step 3: Fetch bill details for each customer
#     account_bill_data_mapping = {}
#     for account_number in account_data_mapping.keys():
#         profile_id_df = killbill_database.get_data("customer_profiles", {"account_number": account_number}, ["id"])
#         if profile_id_df.empty:
#             continue
#         profile_id = profile_id_df['id'].tolist()[0]
#         bill_data = killbill_database.get_data(
#             "customer_bills",
#             {"customer_profile_id": profile_id},
#             ["due_date_of_this_bill", "id"]
#         ).to_dict(orient="records")
#         if bill_data:
#             account_bill_data_mapping[account_number] = bill_data

#     # Step 4: Merge collection step data with bill data
#     combined_data = {}
#     for account, steps in account_data_mapping.items():
#         combined_data[account] = {"steps_data": []}
#         bills = account_bill_data_mapping.get(account, [])
#         for step in steps:
#             for bill in bills:
#                 due_date = bill.get("due_date_of_this_bill")
#                 if due_date:
#                     step_entry = step.copy()
#                     step_entry["due_date_of_this_bill"] = due_date
#                     step_entry["bill_id"] = bill["id"]
#                     combined_data[account]["steps_data"].append(step_entry)

#     # Step 5: Trigger emails if final due date has passed
#     now = datetime.now()
#     for account, data in combined_data.items():
#         try:
#             email_steps_data_df = killbill_database.get_data(
#                 "customer_profiles", {"account_number": account}, ["steps_data"]
#             )
#             if not email_steps_data_df.empty:
#                 email_steps_data = ast.literal_eval(email_steps_data_df['steps_data'].tolist()[0])
#             else:
#                 email_steps_data = []
#         except:
#             email_steps_data = []

#         for step in data["steps_data"]:
#             bill_due_date_str = step.get("due_date_of_this_bill")
#             grace_days = step.get("day", 0)

#             if isinstance(bill_due_date_str, pd.Timestamp):
#                 bill_due_date_str = bill_due_date_str.strftime("%Y-%m-%d %H:%M:%S")
#             # bill_due_date = datetime.strptime(bill_due_date_str, "%Y-%m-%d %H:%M:%S").date()
#             bill_due_date = datetime.strptime(bill_due_date_str, "%Y-%m-%d %H:%M:%S")
#             final_due_date = bill_due_date + timedelta(days=grace_days)
#             # final_due_datetime = datetime.combine(final_due_date, datetime.min.time())
#             yesterday_start = datetime.combine(now.date() - timedelta(days=1), datetime.min.time())
#             if yesterday_start<= final_due_date <= now:
#                 step_description = step.get("step_description", "")
#                 # result = send_email_without_template(
#                 #     cc_emails=step.get("cc", "srikanth.rekkala@algonox.com"),
#                 #     to_email=email_map.get(account),
#                 #     subject=step.get("subject", ""),
#                 #     body=step.get("content_data", ""),
#                 #     is_html=True,
#                 #     comments="Collection Email trigger"
#                 # )
#                 include_invoice=step.get("include_invoice", "")
#                 try:
#                     if include_invoice in ['Most Recent Invoice', 'All Overdue Invoices']:
#                         result = send_email_without_template(
#                         cc_emails=step.get("cc", "srikanth.rekkala@algonox.com"),
#                         to_email=email_map.get(account),
#                         subject=step.get("subject", ""),
#                         body=step.get("content_data", ""),
#                         is_html=True,
#                         comments="Collection Email trigger",
#                         invoice_link = f"{os.environ.get('BILLS_FOLDER', '')}{step['bill_id']}"
#                     )
#                     else:
#                         result = send_email_without_template(
#                             cc_emails=step.get("cc", "srikanth.rekkala@algonox.com"),
#                             to_email=email_map.get(account),
#                             subject=step.get("subject", ""),
#                             body=step.get("content_data", ""),
#                             is_html=True,
#                             comments="Collection Email trigger",
#                         )
#                     email_steps_data.append({
#                         'created_date': now.strftime('%Y-%m-%d %H:%M:%S'),
#                         'step_description': step_description,
#                         'modified_by': 'System',
#                         'reason': 'AUTO',
#                         'result': 'Email Sent Successfully',
#                         'completed_date': now.strftime('%Y-%m-%d %H:%M:%S'),
#                         'canceled_date': ''
#                     })
#                 except Exception as e:
#                     print(f"Error sending email for account {account}: {e}")
#                     email_steps_data.append({
#                         'created_date': now.strftime('%Y-%m-%d %H:%M:%S'),
#                         'step_description': step_description,
#                         'modified_by': 'System',
#                         'reason': 'AUTO',
#                         'result': 'Email Sending Failed',
#                         'completed_date': '',
#                         'canceled_date': ''
#                     })

#         # Step 6: Update customer_profiles with latest email tracking data
#         update_status = killbill_database.update_dict(
#             "customer_profiles",
#             {"steps_data": str(email_steps_data)},
#             {"account_number": account}
#         )
#         if update_status:
#             print(f" Email tracking updated for account {account}")
#         else:
#             print(f" Failed to update email tracking for account {account}")

#     return {'flag': True, "message": "Email triggered Successfully"}


def collections_mail_trigger(data):
    """
    Triggers email notifications for overdue customer bills based on predefined collection steps.

    Args:
        data (dict): A dictionary containing relevant billing and customer details.

    Returns:
        dict: Response structure containing:
            - flag (bool): Indicates whether the email trigger process was successful.
            - message (str): Success or failure message.
    
    Raises:
        KeyError: If required environment variables or database keys are missing.
        ValueError: If there are issues with data retrieval or processing.
    """
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    killbill_database = DB(os.environ["BILLING_PLATFORM"], **db_config)

    # Step 1: Fetch customer profiles with valid collection steps
    customer_profiles_data = killbill_database.get_data(
        "customer_profiles",
        {'collection_step':'not Null'},
        ["account_number", "collection_step", "email","id"]
    )
    # customer_profiles_data = killbill_database.get_data(
    #     "customer_profiles",
    #     {'account_number':'300000271'},
    #     ["account_number", "collection_step", "email","id"]
    # )
    filtered_data = customer_profiles_data[customer_profiles_data['collection_step'].notnull()]
    account_numbers = filtered_data['account_number'].tolist()
    account_id = filtered_data['id'].tolist()
    account_id_dict=dict(zip(account_numbers, account_id))
    print(f'###account_numbers{account_numbers}')
    collection_steps = dict(zip(account_numbers, filtered_data['collection_step']))
    email_map = dict(zip(account_numbers, filtered_data['email']))

    # Step 2: Fetch collection step details (only of type 'Email')
    account_data_mapping = {}
    for account_number, template_id in collection_steps.items():
        step_data = killbill_database.get_data(
            "collection_steps",
            {"template_id": template_id, "email_alert": True ,"is_deleted":False},
            None
        ).to_dict(orient="records")
        if step_data:
            account_data_mapping[account_number] = step_data

    # Step 3: Fetch bill details for each customer
    account_bill_data_mapping = {}
    accounts_bill_dict={}
    for account_number in account_data_mapping.keys():
        # profile_id_df = killbill_database.get_data("customer_profiles", {"account_number": account_number}, ["id"])
        profile_id = account_id_dict[account_number]
        print(f'###profile_id{profile_id}')
        # if profile_id_df.empty:
        #     continue
        # profile_id = profile_id_df['id'].tolist()[0]
        # bill_data = killbill_database.get_data(
        #     "customer_bills",
        #     {"customer_profile_id": profile_id},
        #     ["due_date_of_this_bill", "id"]
        # ).to_dict(orient="records")
        now = datetime.now()
        bill_data = killbill_database.get_data_bp(
            table_name="customer_bills",
            condition={
                "customer_profile_id": profile_id,
                "amount_due": [">=", 0],
                "due_date_of_this_bill":["<",now]
            },
            columns=["due_date_of_this_bill", "id", "amount_due"]
        ).to_dict(orient="records")
        bill_list=[]
        print(f'##bill_data{bill_data}')
        if bill_data:
            for bill_row in bill_data:
                if 'id' in bill_row:
                    bill_list.append(bill_row['id'])
            if bill_list:
                accounts_bill_dict[account_number]=bill_list
        if bill_data:
            account_bill_data_mapping[account_number] = bill_data
    # Step 4: Merge collection step data with bill data
    combined_data = {}
    for account, steps in account_data_mapping.items():
        combined_data[account] = {"steps_data": []}
        bills = account_bill_data_mapping.get(account, [])
        for step in steps:
            for bill in bills:
                due_date = bill.get("due_date_of_this_bill")
                if due_date:
                    step_entry = step.copy()
                    step_entry["due_date_of_this_bill"] = due_date
                    step_entry["bill_id"] = bill["id"]
                    step_entry["amount_due"] = bill["amount_due"]
                    combined_data[account]["steps_data"].append(step_entry)

    # Step 5: Trigger emails if final due date has passed
    print(f'###combined_data{combined_data}')
    now = datetime.now()
    result = {}
    for account, data in combined_data.items():
        try:
            email_steps_data_df = killbill_database.get_data(
                "customer_profiles", {"account_number": account}, ["steps_data"]
            )
            if not email_steps_data_df.empty:
                email_steps_data = ast.literal_eval(email_steps_data_df['steps_data'].tolist()[0])
            else:
                email_steps_data = []
        except:
            email_steps_data = []
        steps_data = data.get("steps_data", [])
        steps_by_bill = defaultdict(list)
        for step in steps_data:
            steps_by_bill[step["bill_id"]].append(step)

        for bill_id, steps in steps_by_bill.items():
            steps_sorted = sorted(steps, key=lambda x: x["day"])  # optional, sort by step day
            bill_steps_dict = {}
            for idx, step in enumerate(steps_sorted, 1):  # idx starts at 1
                bill_steps_dict[idx] = step["day"]
            result[bill_id] = bill_steps_dict
        
        logging.info(f"###result{result}")

        for step in data["steps_data"]:
            bill_due_date_str = step.get("due_date_of_this_bill")
            grace_days = step.get("day", 0)
            bill_id = step.get("bill_id", "")

            if isinstance(bill_due_date_str, pd.Timestamp):
                bill_due_date_str = bill_due_date_str.strftime("%Y-%m-%d %H:%M:%S")
            # bill_due_date = datetime.strptime(bill_due_date_str, "%Y-%m-%d %H:%M:%S").date()
            bill_due_date = datetime.strptime(bill_due_date_str, "%Y-%m-%d %H:%M:%S")
            bill_due_date_str = bill_due_date.strftime("%m-%d-%Y")
            final_due_date = bill_due_date + timedelta(days=grace_days)
            # final_due_datetime = datetime.combine(final_due_date, datetime.min.time())
            yesterday_start = datetime.combine(now.date() - timedelta(days=1), datetime.min.time())
            if yesterday_start <= final_due_date <= now:
                step_description = step.get("step_description", "")
                include_invoice=step.get("include_invoice", "")
                try:
                    step_type = step.get("step_type", "")
                    if step_type.lower() == 'email':
                        if include_invoice in ['All Overdue Invoices']:
                            overdue_bills = accounts_bill_dict.get(account, [])
                            invoice_link = [f"{os.environ.get('BILLS_FOLDER', '')}{bill_id}" for bill_id in overdue_bills]
                            mail_data={"invoice_link":invoice_link,"account_number":account,"bill_id":overdue_bills,"subject":step.get("subject", ""),"content_data":step.get("content_data", "")}
                            print(f'###mail_data{mail_data}')
                            result = send_email_without_template(
                                cc_emails=step.get("cc", "srikanth.rekkala@algonox.com"),
                                to_email=email_map.get(account),
                                subject=step.get("subject", ""),
                                body=step.get("content_data", ""),
                                is_html=True,
                                comments="Collection Email trigger",
                                invoice_link = invoice_link
                            )
                        elif include_invoice in ['Most Recent Invoice']:
                            result = send_email_without_template(
                            cc_emails=step.get("cc", "srikanth.rekkala@algonox.com"),
                            to_email=email_map.get(account),
                            subject=step.get("subject", ""),
                            body=step.get("content_data", ""),
                            is_html=True,
                            comments="Collection Email trigger",
                            invoice_link = [f"{os.environ.get('BILLS_FOLDER', '')}{step['bill_id']}"]
                            )
                        else:
                            result = send_email_without_template(
                                cc_emails=step.get("cc", "srikanth.rekkala@algonox.com"),
                                to_email=email_map.get(account),
                                subject=step.get("subject", ""),
                                body=step.get("content_data", ""),
                                is_html=True,
                                comments="Collection Email trigger",
                                invoice_link=[]
                            )
                    if step_type.lower() == 'manual step':
                        followup_messages = {
                            1: "",  # First email (no intro, just base body)
                            2: "Just seeing if you have had a chance to review our previous message.<br><br>",
                            3: "We are following up to see if you have been able to review any of our previous communications.<br><br>",
                            4: "We have been reaching out for a couple of weeks working to resolve the outstanding balance on your account.<br><br>",
                            5: "We have been working to resolve the outstanding balance on your account for the past few weeks.<br><br>"
                        }
                        logging.info(f"email_steps_data---------{email_steps_data}")           
                        if final_due_date.date() == now.date():
                            if bill_id in result:
                                day_mapping = result[bill_id]
                                # search for the key that has this day
                                step_key = next((k for k, v in day_mapping.items() if v == grace_days), None)
                                logging.info(f'step_key-------{step_key}')
                            else:
                                step_key = 1
                            prefix = followup_messages.get(step_key, "")
                            logging.info(f'Follow-up prefix: {prefix}')
                            subject = "Collection Email Trigger"
                            amount_due = step.get("amount_due", "")
                            email_body = f"""
                                    Dear Customer,<br>
                                    Greetings!<br><br>

                                    {prefix}

                                    We noticed your account-{account} is past due for Bill-{bill_id} in the amount of ${amount_due} as of {bill_due_date_str}.<br><br>
                                    Could you please let us know if there's an update on remittance, or if you have any questions regarding your account?<br><br>
                                    We're happy to assist with any issues or provide additional details if needed.<br><br>
                                    For any questions regarding your services please reach out to billing@altaworx.com.<br><br>
                                    For questions regarding a payment or balance on your account, please reply to this email or send an email to receivables@altaworx.com.<br><br>
                                    If you have already remitted payment, please disregard this email.<br><br>
                                    Thanks,<br>
                                    Altaworx Receivables
                                    """
                            result = send_email_without_template(
                                cc_emails=step.get("cc", "srikanth.rekkala@algonox.com"),
                                to_email=email_map.get(account),
                                subject=subject,
                                body=email_body,
                                is_html=True,
                                comments="Collection Email trigger",
                                invoice_link = []
                            )
                            logging.info(f'###result{result}')
                            email_steps_data.append({
                                'created_date': now.strftime('%Y-%m-%d %H:%M:%S'),
                                'step_description': step_description,
                                'modified_by': 'System',
                                'reason': 'AUTO',
                                'result': 'Email Sent Successfully',
                                'completed_date': now.strftime('%Y-%m-%d %H:%M:%S'),
                                'canceled_date': '',
                                'bill_id': step.get("bill_id"),
                                'step_type': step_type,
                                'day': step.get("day", 0),
                                'grace_period':step.get("grace_period", 0)
                            })
                except Exception as e:
                    print(f"Error sending email for account {account}: {e}")
                    email_steps_data.append({
                        'created_date': now.strftime('%Y-%m-%d %H:%M:%S'),
                        'step_description': step_description,
                        'modified_by': 'System',
                        'reason': 'AUTO',
                        'result': 'Email Sending Failed',
                        'completed_date': '',
                        'canceled_date': '',
                        'bill_id': step.get("bill_id")
                    })

        # Step 6: Update customer_profiles with latest email tracking data
        update_status = killbill_database.update_dict(
            "customer_profiles",
            {"steps_data": str(email_steps_data)},
            {"account_number": account}
        )
        if update_status:
            print(f" Email tracking updated for account {account}")
        else:
            print(f" Failed to update email tracking for account {account}")

    return {'flag': True, "message": "Email triggered Successfully"}


def fetch_default_templates(data):
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    killbill_database = DB(os.environ["BILLING_PLATFORM"], **db_config)
    flag = data.get('flag', '')

    try:
        if flag == 'fetch':
            #get all templates
            templates = killbill_database.get_data(
                "collection_templates",
                {"is_deleted":False},
                ["id","template_description"]
            )
            logging.info(f'templates----------{templates}')
            if not templates.empty:
                templates_list = (
                    templates['template_description'].astype(str) + '--' + templates['id'].astype(str)
                ).tolist()
            else:
                templates_list = []
            # Check if default_settings has a collection_template_id
            selected_template = ''
            default_settings_df = killbill_database.get_data(
                "default_settings", None, ["collection_template_id"]
            ).to_dict(orient="records")
            logging.info(f'default_settings----------{default_settings_df}')

            if default_settings_df:  #just check if list is not empty
                template_id = str(int(float(default_settings_df[0]["collection_template_id"])))
                logging.info(f'template_id-----------{template_id}')
                match = templates[templates["id"].astype(str) == template_id]
                logging.info(f'match-----------{match}')
                if not match.empty:
                    selected_template = f"{match.iloc[0]['template_description']}--{template_id}"
            return {
                'flag': True,
                "message": "Templates fetched successfully",
                "templates": templates_list,
                "selected_template": selected_template
            }

        elif flag == 'save':
            selected_template = data.get('selected_template', '')
            template_id = selected_template.split("--")[-1]

            collection_template_id = {
                "collection_template_id": template_id
            }

            df_dict=killbill_database.get_data("default_settings",None,["id"])
            logging.info(f'df_dict_records-------------{df_dict}')
            df_dict_ = df_dict.to_dict(orient="records")
            if df_dict_:  # Check if list is not empty
                unique_id = df_dict["id"].to_list()[0] 
                # Perform actions when data is available
                status=data_update_db(collection_template_id,unique_id,"default_settings",killbill_database)
                return {'flag': True, "message": "Template saved Successfully"}
            else:
                # Perform actions when df_dict_records is empty
                logging.info("No records found, executing alternative logic to insert the details")
                status=killbill_database.insert_dict(collection_template_id,"default_settings")
                return {'flag': True, "message": "Template saved Successfully"}
    except Exception as e:
        logging.error(f"Error in fetch_defualt_templates: {e}")
        return {'flag': False, "message": "Error in fetching templates"}