import ast
import json
import math
import os
import re
import time
import uuid
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from dotenv import load_dotenv
from tenacity import retry, stop_after_attempt, wait_fixed

import psycopg2
from psycopg2.extras import execute_values
import pytds
from sqlalchemy import create_engine, exc, text

# Importing project-specific modules
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import *

# Load environment variables

logging = Logging(name="notification_services")
load_dotenv()


##TO CONNECT TO DATABASE

onepoint_o_database=os.getenv("ONEPOINTODATABASE","AltaworxCentral_Test")

class UsageNotifications:


    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
    def create_connection(
        self,
        db_type="",
        host="",
        db_name="",
        username="",
        password="",
        port="",
        driver="",
        max_retry=3,
    ):
        connection = None
        logging.info(f"db_type--------{db_type}")
        logging.info(f"host--------------{host}")

        if db_type == "postgresql":
            try:
                logging.info(f"Creating PostgreSQL connection")
                connection = psycopg2.connect(
                    host=os.environ["HOST"],
                    database=db_name,
                    user=os.environ["USER"],
                    password=os.environ["PASSWORD"],
                    port=os.environ["PORT"],
                )
                logging.info("Connection to PostgreSQL DB successful")
            except Exception as e:
                logging.info(f"Failed to connect to PostgreSQL DB: {e}")
        elif db_type == "mssql":
            logging.info(
                f"conn : {db_type},{host},{db_name},{username},{password},{driver},{port}"
            )
            logging.info("Creating MSSQL connection")
            logging.info(f"Creating MSSQL connection using pytds")
            try:
                connection = pytds.connect(
                    server = os.environ["ONEPOINTOSERVER"] ,
                    database = os.environ["ONEPOINTODATABASE"],
                    user = os.environ["ONEPOINTOUSERNAME"],
                    password = os.environ["ONEPOINTOPASSWORD"],
                    port = os.environ["ONEPOINTOPORT"],

                    # server="altaworx-test.cd98i7zb3ml3.us-east-1.rds.amazonaws.com",
                    # database="{onepoint_o_database}",
                    # user="ALGONOX-Vyshnavi",
                    # password="cs!Vtqe49gM32FDi",
                    # port="1433",
                    # server="altaworx-test.cd98i7zb3ml3.us-east-1.rds.amazonaws.com",
                    # database="{onepoint_o_database}",
                    # user="ALGONOX-Vyshnavi",
                    # password="cs!Vtqe49gM32FDi",
                    # port="1433",
                )
                # connection = pymssql.connect(
                #     server=host,
                #     user=username,
                #     password=password,
                #     database=db_name,
                #     port=port,
                #     timeout=5
                # )
                # connection = pymssql.connect(host=host,user=username,password=password,db_name=db_name,connect_timeout=5)
                logging.info("Connection to MSSQL successful!")
            except Exception as e:
                logging.info(f"Failed to connect to MSSQL DB: {e}")
                logging.error(f"Failed to connect to MSSQL DB: {e}")

        return connection

    def execute_query(self, connection, query, params=None):

        try:
            # Check if params are provided
            if params:
                # Execute the query with parameters
                logging.info(f"params--------{params}")
                result_df = pd.read_sql_query(query, connection, params=params)
            else:
                # Execute the query without parameters
                result_df = pd.read_sql_query(query, connection)

            return result_df
        except Exception as e:
            logging.info(f"Error executing query: {e}")
            return None

    def load_env_pgsql(self):
        load_dotenv()
        hostname = os.getenv("LOCAL_DB_HOST")
        port = os.getenv("LOCAL_DB_PORT")
        user = os.getenv("LOCAL_DB_USER")
        password = os.getenv("LOCAL_DB_PASSWORD")
        db_type = os.getenv("LOCAL_DB_TYPE")
        db_name = os.getenv("LOCAL_DB_NAME")
        return hostname, port, user, password, db_type, db_name

    def load_env_mssql(self):
        from_host = os.getenv("FROM_DB_HOST")
        from_port = os.getenv("FROM_DB_PORT")
        from_db = os.getenv("FROM_DB_NAME")
        from_user = os.getenv("FROM_DB_USER")
        from_pwd = os.getenv("FROM_DB_PASSWORD")
        from_db_type = os.getenv("FROM_DB_TYPE")
        from_driver = os.getenv("FROM_DB_DRIVER")
        return (
            from_host,
            from_port,
            from_db,
            from_user,
            from_pwd,
            from_db_type,
            from_driver,
        )

    def usage_notification(self, data):
        logging.info(f"Received data for usage_notification is {data}")
        load_dotenv()
        flag = data["action"]
        tenant_database=data.get('db_name','altaworx_central')
        logging.info(f"flag----------{flag}")
        rule_id_2_0 = data["rule_def_id"]
        logging.info(f"rule_id_2_0-----------{rule_id_2_0}")
        # expression_type_id = '33e9b000-a43f-4649-92af-ec3d7925a8a2'
        hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
        # logging.info(f'db_type---------{db_type}')
        hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
        # logging.info(f'hostname------------{hostname}')
        mapping_table = os.getenv("MAPPING_TABLE")

        def to_camel_case(snake_str):
            components = snake_str.split("_")
            return components[0].capitalize() + "".join(
                x.capitalize() for x in components[1:]
            )

        postgres_conn_start = time.time()
        postgres_conn = self.create_connection(
            "postgresql", hostname, tenant_database, user, password, port
        )
        (
            from_host,
            from_port,
            ssms_db_name,
            from_user,
            from_pwd,
            from_db_type,
            from_driver,
        ) = self.load_env_mssql()
        mssql_conn_start = time.time()
        mssql_conn = self.create_connection(
            "mssql",
            from_host,
            ssms_db_name,
            from_user,
            from_pwd,
            from_port,
            from_driver,
        )
        # logging.info(f"mssql_conn {mssql_conn}")
        # logging.info(f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds")
        # logging.info(f"Postgres connection time: {time.time() - postgres_conn_start:.4f} seconds")
        # logging.info(f"Postgres connection time: {time.time() - postgres_conn_start:.4f} seconds")
        ##getting all the details for a particular transfer
        query_start = time.time()
        # fetching data from 2.0 rule_rule_definition table based on id column
        if flag == "create":
            rule_rule_defintiton_details_query = f"select * from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}'"
            rule_rule_definition_details = self.execute_query(
                postgres_conn, rule_rule_defintiton_details_query
            )
            logging.info(f'rule_rule_definition_details----------------{rule_rule_definition_details}')

            # insert the details  fetched from 2.0 rule_rule_definition table to 1.0 rule_rule_definition without id(that will generate automatically)

            if not rule_rule_definition_details.empty:
                # logging.info(f'in if condition')
                rule_rule_definition_details = rule_rule_definition_details.drop(
                    columns=["id"]
                )
                all_columns = rule_rule_definition_details.columns
                columns_to_insert = all_columns[
                    :-9
                ]  # Exclude last 5 columns and rule_id column
                columns_to_insert_camel_case = [
                    to_camel_case(col) for col in columns_to_insert
                ]
                logging.info(f'columns_to_insert-----------{columns_to_insert_camel_case}')
                column_names = ", ".join(columns_to_insert_camel_case)
                logging.info(f'column_names------------{column_names}')
                placeholders = ", ".join(
                    ["%s"] * len(columns_to_insert)
                )  # Get column names
                insert_query = f""" INSERT INTO {onepoint_o_database}.dbo.RULE_RuleDefinition ({column_names}) OUTPUT INSERTED.id VALUES ({placeholders});"""  # fetch the id from 1.0 database and store it in a new column

                logging.info(f'insert_query RULE_RuleDefinition {insert_query}')
                logging.info(f'placeholders RULE_RuleDefinition {placeholders}')
                def convert_value(x):
                    if pd.isna(x):  # Handle NaT or NaN
                        return None
                    elif isinstance(x, np.int64):
                        return int(x)
                    elif isinstance(x, np.float64):
                        return float(x)
                    elif isinstance(x, np.bool_):
                        return bool(x)
                    elif isinstance(x, pd.Timestamp):
                        return x.to_pydatetime()
                    else:
                        return x

                data_to_insert = tuple(
                    rule_rule_definition_details.iloc[0][
                        columns_to_insert
                    ]  # Exclude rule_id
                    .apply(convert_value)
                    .tolist()
                )
                logging.info(f'data_to_insert----------{data_to_insert}')
                with mssql_conn.cursor() as cursor:
                    cursor.execute(insert_query, data_to_insert)
                    # cursor.execute("SELECT LASTVAL()")  # Fetch the last inserted ID
                    new_id = cursor.fetchone()[0]
                    logging.info(f"New ID inserted:RULE_RuleDefinition {new_id}")
                    mssql_conn.commit()
                    # def_id = '0050535b-e2c3-4f98-9b63-cb3fc28fe6ca'

                # Now update the `1_0_rule_id` column in the `rule_rule_definition` table
                new_id = str(new_id)
                with postgres_conn.cursor() as cursor:
                    update_query = """UPDATE public.rule_rule_definition
                                        SET "rule_id_1_0" = %s
                                        WHERE rule_def_id = %s"""
                    # logging.info(f'update_query----------{update_query}')
                    cursor.execute(update_query, (new_id, rule_id_2_0))
                    postgres_conn.commit()
                    logging.info(f"Updated 1_0_rule_id in rule_rule_definition table")

            else:
                logging.info("No data found to insert into backup table.")
            # with that id insert into rules version table

            rule_rule_defintiton_bak_details_query = f"select * from {onepoint_o_database}.dbo.RULE_RuleDefinition where id = '{new_id}'"
            rule_rule_defintiton_bak_details = self.execute_query(
                mssql_conn, rule_rule_defintiton_bak_details_query
            )

            logging.info(
                f"rule_rule_defintiton_bak_details---------------{rule_rule_defintiton_bak_details}"
            )
            # logging.info(f'rule_rule_defintiton_bak_details.columns-------{rule_rule_defintiton_bak_details.columns}')

            if not rule_rule_defintiton_bak_details.empty:
                rule_rule_defintiton_bak_details = (
                    rule_rule_defintiton_bak_details.drop(columns=["RuleId"])
                )
                rule_rule_defintiton_bak_details = (
                    rule_rule_defintiton_bak_details.drop(columns=["VersionId"])
                )
                rule_rule_defintiton_bak_details = (
                    rule_rule_defintiton_bak_details.rename(columns={"id": "RuleId"})
                )
                # logging.info(f'rule_rule_defintiton_bak_details.columns-------{rule_rule_defintiton_bak_details.columns}')
                all_columns = rule_rule_defintiton_bak_details.columns
                column_names = ", ".join(all_columns)
                logging.info(f'column_names------------{column_names}')
                placeholders = ", ".join(["%s"] * len(all_columns))
                insert_query = f"""
                    INSERT INTO {onepoint_o_database}.dbo.RULE_Version ({column_names}) OUTPUT INSERTED.id
                    VALUES ({placeholders})
                    """
                logging.info(f'insert_query RULE_Version {insert_query}')

                # Build the INSERT query dynamically
                def convert_value(x):
                    if isinstance(x, np.int64):
                        return int(x)
                    elif isinstance(x, np.float64):
                        return float(x)
                    elif isinstance(x, np.bool_):
                        return bool(x)
                    elif isinstance(x, uuid.UUID):  # Handle UUIDs
                        return str(x)
                    elif isinstance(x, pd.Timestamp):
                        return x.to_pydatetime()
                    else:
                        return x

                data_to_insert = tuple(
                    rule_rule_defintiton_bak_details.iloc[0][
                        all_columns
                    ]  # Exclude rule_id
                    .apply(convert_value)
                    .tolist()
                )
                logging.info(f'data_to_insert----------{data_to_insert}')
                with mssql_conn.cursor() as cursor:
                    cursor.execute(insert_query, data_to_insert)
                    version_id = cursor.fetchone()[0]
                    logging.info(f"New version ID inserted: {version_id}")
                    mssql_conn.commit()
                logging.info("Data inserted successfully.")

                # now get the version_id and update back in rule_definition table

                update_query = f"""
                    UPDATE {onepoint_o_database}.dbo.RULE_RuleDefinition
                    SET VersionId = %s
                    WHERE id = %s
                """

                # Get the new version_id (this was fetched earlier after the insert)
                # 'version_id' is the ID of the newly inserted row in the RULE_Version table
                logging.info(
                    f"Updating RULE_RuleDefinition with version_id {version_id} for id {new_id}"
                )

                # Execute the UPDATE query
                with mssql_conn.cursor() as cursor:
                    cursor.execute(update_query, (version_id, new_id))
                    mssql_conn.commit()

                logging.info("RULE_RuleDefinition table updated successfully.")

            rule_rule_defintiton_customer_details_query = f"select rule_id_1_0, customers_list, created_date, created_by from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}'"
            rule_rule_definition_customer_details = self.execute_query(
                postgres_conn, rule_rule_defintiton_customer_details_query
            )

            logging.info(f'rule_rule_definition_customer_details-------------{rule_rule_definition_customer_details}')
            customers_list = rule_rule_definition_customer_details.get("customers_list")
            # logging.info(f'customers_list-----------{customers_list}')
            rule_id_1_0_value = rule_rule_definition_customer_details.get("rule_id_1_0")
            created_date_value = rule_rule_definition_customer_details.get(
                "created_date"
            )
            # logging.info(f'created_date_value----------{created_date_value}')
            created_by_value = rule_rule_definition_customer_details.get("created_by")

            rule_id_1_0 = (
                rule_id_1_0_value.iloc[0] if not rule_id_1_0_value.empty else None
            )
            created_date = (
                created_date_value.iloc[0]
                if not created_date_value.empty
                else datetime.utcnow()
            )
            created_date = created_date.strftime("%Y-%m-%d %H:%M:%S")
            logging.info(f'created_date-----------{created_date}')
            created_by = (
                created_by_value.iloc[0] if not created_by_value.empty else None
            )
            # logging.info(f'customers_list---{customers_list}')
            customers_list = customers_list.iloc[
                0
            ]  # Accessing the first (and probably only) element in the series
            # logging.info(f'customers_list---{customers_list}')
            # customers_data = ast.literal_eval(customers_list)
            customers_data = json.loads(customers_list)
            # logging.info(f'customers_data----------{customers_data}')

            # Now you can access 'customer_names' and 'customer_groups'
            customer_names_id = [
                customer_id
                for customer in customers_data.get("customer_names") or []
                for _, customer_id in customer.items()
            ]
            # customer_groups_id = [group_id for group in customers_data.get("customer_groups") or [] for _, group_id in group.items()]
            customer_groups_id = [
                group_id
                for group in customers_data.get("customer_groups") or []
                for _, group_id in group.items()
            ]
            logging.info(f"Customer Names IDs: {customer_names_id}")
            logging.info(f"Customer Groups IDs: {customer_groups_id}")
            column_names = "RuleId, CustomerId, CustomerGroupId, CreatedDate, CreatedBy"
            placeholders = "%s, %s, %s, %s, %s"

            # logging.info(f'customer_names_id----------{type(customer_names_id)}')
            for customer_id in customer_names_id:
                try:
                    insert_query = f"""
                        INSERT INTO {onepoint_o_database}.dbo.NotificationRuleRecipient ({column_names})
                        VALUES ({placeholders})
                        """
                            # logging.info(f'insert_query-------{insert_query}')
                    # logging.info(f"Values: {[rule_id_1_0, customer_id, None, created_date, created_by]}")
                    with mssql_conn.cursor() as cursor:
                        cursor.execute(
                            insert_query,
                            tuple(
                                [rule_id_1_0, customer_id, None, created_date, created_by]
                            ),  # Replace None and other placeholders as needed
                        )
                except Exception as e:
                    logging.error(f"Error inserting customer_id {customer_id}: {e}")
                    logging.info(f"Error inserting customer_id {customer_id}: {e}")
                    continue


            for customer_group_id in customer_groups_id:
                try:
                    insert_query = f"""
                INSERT INTO {onepoint_o_database}.dbo.NotificationRuleRecipient ({column_names})
                VALUES ({placeholders})
                """
                    # logging.info(f'insert_query-------{insert_query}')
                    with mssql_conn.cursor() as cursor:
                        cursor.execute(
                            insert_query,
                            tuple(
                                [
                                    rule_id_1_0,
                                    None,
                                    customer_group_id,
                                    created_date,
                                    created_by,
                                ]
                            ),  # Replace None and other placeholders as needed
                        )

                    mssql_conn.commit()
                except Exception as e:
                    logging.error(
                        f"Error inserting customer_group_id {customer_group_id}: {e}"
                    )
                    logging.info(
                        f"Error inserting customer_group_id {customer_group_id}: {e}"
                    )
                    continue

            logging.info("Data inserted into notifiaction table successfully.")

            # fetching the data of expression list from 2.0 based on rule_id

            expression_details_query = (
                f"select * from rule_rule_definition where id = '{rule_id_2_0}'"
            )
            expression_details_df = self.execute_query(
                postgres_conn, expression_details_query
            )
            # expression_ids = expression_details_df.get('expression_ids')
            expression_details_str = expression_details_df["expression_ids"].iloc[0]
            created_date = expression_details_df["created_date"].iloc[0]
            created_by = expression_details_df["created_by"].iloc[0]
            # created_date= created_date_value.iloc[0] if not created_date_value.empty else datetime.utcnow()
            created_date = created_date.strftime("%Y-%m-%d %H:%M:%S")
            # logging.info(f'created_date------------{created_date}')
            expression_details = json.loads(expression_details_str)
            logging.info(f'expression_details---------{expression_details}')

            def get_type(value):
                if isinstance(value, bool):
                    return "Boolean"
                if isinstance(value, int) and value > 10**9:
                    return "BigInteger"
                elif isinstance(value, int):
                    return "Integer"
                elif isinstance(value, float):
                    return "Decimal"
                elif isinstance(value, str):
                    try:
                        int(value)
                        return "Integer"
                    except ValueError:
                        pass
                    try:
                        float(value)
                        return "Decimal"
                    except ValueError:
                        pass
                    return "String"
                elif isinstance(value, str) and ("-" in value or ":" in value):
                    return "DateTime"
                try:
                    import uuid

                    uuid.UUID(value)
                    return "Guid"
                except (ValueError, TypeError):
                    pass
                if isinstance(value, str) and value.startswith("$"):
                    return "Money"
                return "Unknown"

            def inserting(expression_details, ordinal_counter):
                field_1_id = None
                const_one_id = None
                field_2_id = None
                const_two_id = None
                logging.info("inserting of an expression")
                logging.info(f"expression_details----------{expression_details}")
                condtion_value = list(expression_details["cond"].values())[0]
                if (
                    "const_one" in expression_details
                    or "field_one" in expression_details
                ):
                    if "field_one" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            # field_one_value = list(expression_details['field_one'].values())[0]
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Constant';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            constant_value = expression_details["field_one"]
                            logging.info(f"constant_value-----{constant_value}")
                            constant_type = get_type(constant_value)
                            logging.info(f"constant_type-----{constant_type}")
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            constant_type_id_query = f""" select id from {onepoint_o_database}.dbo.DataType where DataTypeName = '{constant_type}';"""
                            query_result = self.execute_query(
                                mssql_conn, constant_type_id_query
                            )
                            logging.info(f"query_result---------{query_result}")
                            change_type_id = query_result.iloc[0]["id"]
                            logging.info(f"change_type_id---------{change_type_id}")
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            data_to_insert = (
                                rule_id_1_0,
                                expression_type_id,
                                expression_details["field_one"],
                                change_type_id,
                                created_by,
                                created_date,
                                ordinal_counter,
                                version_id,
                            )
                            logging.info(f"data_to_insert-----------{data_to_insert}")
                            try:
                                insert_query = f"""
                                    INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                    OUTPUT INSERTED.id
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                                """
                                logging.info(f"insert_query RULE_Expression {insert_query}")
                                cursor.execute(insert_query, data_to_insert)
                                field_1_id = cursor.fetchone()[0]
                                logging.info(f"New ID inserted:RULE_Expression {field_1_id}")
                                logging.info(
                                    expression_details["field_one"], "inserted", "field_one"
                                )
                                mssql_conn.commit()
                            except Exception as e:
                                logging.error(f"Error inserting field_one: {e}")
                                logging.info(f"Error inserting field_one: {e}")
                                mssql_conn.rollback()
                                return None
                    elif "const_one" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Field';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            const_one_value = list(
                                expression_details["const_one"].values()
                            )[0]
                            data_to_insert = (
                                rule_id_1_0,
                                expression_type_id,
                                const_one_value,
                                created_by,
                                created_date,
                                ordinal_counter,
                                version_id,
                            )
                            insert_query = f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                OUTPUT INSERTED.id
                                VALUES (%s, %s, %s, %s, %s, %s, %s);
                            """
                            cursor.execute(insert_query, data_to_insert)
                            const_one_id = cursor.fetchone()[0]
                            logging.info(f"New ID inserted: {const_one_id}")
                            logging.info(expression_details["const_one"], "inserted const_one")
                            mssql_conn.commit()
                if (
                    "field_two" in expression_details
                    or "const_two" in expression_details
                ):
                    # if condtion_value == 'HAS vALUE' or 'HAS NO VALUE':
                    if "field_two" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Constant';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            field_two_value = expression_details.get("field_two")
                            logging.info(f"field_two_value------------{field_two_value}")
                            if not field_two_value:  # Handle empty const_two
                                logging.info("field_two is empty; skipping insertion.")
                            else:
                                unit = expression_details.get("unit", "").lower()
                                logging.info(f"unit-----------{unit}")
                                # Default to an empty string if 'unit' is missing
                                if unit:
                                    logging.info(f"if unit condition")
                                    try:
                                        field_two_numeric = float(
                                            field_two_value
                                        )  # Ensure it's numeric for conversion
                                        logging.info(
                                            f"field_two_numeric----------{field_two_numeric}"
                                        )
                                        if unit == "mb":
                                            field_two_value = (
                                                field_two_numeric * 1024**2
                                            )
                                            field_two_value = int(field_two_value)

                                        elif unit == "gb":
                                            field_two_value = (
                                                field_two_numeric * 1024**3
                                            )
                                            field_two_value = int(field_two_value)
                                        else:
                                            logging.info(
                                                f"Unit '{unit}' is not recognized; assuming value is already in bytes."
                                            )
                                        logging.info(
                                            f"field_two_value---------------{field_two_value}"
                                        )
                                    except ValueError:
                                        logging.info(
                                            f"Error: field_two value '{field_two_value}' is not numeric."
                                        )
                                else:
                                    logging.info(
                                        "No unit provided; assuming field_two is in bytes."
                                    )

                                constant_type = get_type(field_two_value)
                                logging.info(f"constant_type-----{constant_type}")
                                logging.info(
                                    f"expression_type_id-----------{expression_type_id}"
                                )
                                constant_type_id_query = f""" select id from {onepoint_o_database}.dbo.DataType where DataTypeName = '{constant_type}';"""
                                logging.info(
                                    f"constant_type_id_query------------{constant_type_id_query}"
                                )
                                query_result = self.execute_query(
                                    mssql_conn, constant_type_id_query
                                )
                                logging.info(f"query_result---------{query_result}")
                                change_type_id = query_result.iloc[0]["id"]
                                logging.info(f"change_type_id---------{change_type_id}")

                                # field_two_value = list(expression_details['field_two'].values())[0]
                                data_to_insert = (
                                    rule_id_1_0,
                                    expression_type_id,
                                    field_two_value,
                                    int(change_type_id),
                                    created_by,
                                    created_date,
                                    ordinal_counter,
                                    version_id,
                                )
                                insert_query = f"""
                                    INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                    OUTPUT INSERTED.id
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                                """
                                logging.info(f"insert_query-------{insert_query}")
                                logging.info(f"data_to_insert--------{data_to_insert}")
                                cursor.execute(insert_query, data_to_insert)
                                field_2_id = cursor.fetchone()[0]
                                logging.info(f"New ID inserted: {field_2_id}")
                                logging.info(
                                    expression_details["field_two"],
                                    "inserted",
                                    "field_two",
                                )
                                mssql_conn.commit()
                    elif "const_two" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Field';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            const_two_details = expression_details.get("const_two", {})
                            if not const_two_details:  # Handle empty const_two
                                logging.info("const_two_value is empty; skipping insertion.")
                            else:
                                const_two_value = list(
                                    expression_details["const_two"].values()
                                )[0]
                                data_to_insert = (
                                    rule_id_1_0,
                                    expression_type_id,
                                    const_two_value,
                                    created_by,
                                    created_date,
                                    ordinal_counter,
                                    version_id,
                                )
                                insert_query = f"""
                                    INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                    OUTPUT INSERTED.id
                                    VALUES (%s, %s, %s, %s, %s, %s, %s);
                                """
                                cursor.execute(insert_query, data_to_insert)
                                const_two_id = cursor.fetchone()[0]
                                logging.info(f"New ID inserted: {const_two_id}")
                                logging.info(
                                    expression_details["const_two"],
                                    "inserted const_two",
                                )
                                mssql_conn.commit()
                left_hand_expression_id = field_1_id or const_one_id
                right_hand_expression_id = field_2_id or const_two_id
                condtion_value = list(expression_details["cond"].values())[0]
                logging.info(f"left_hand_expression_id------------{left_hand_expression_id}")
                logging.info(
                    f"right_hand_expression_id--------------{right_hand_expression_id}"
                )
                logging.info(f"condtion_value-----------{condtion_value}")
                logging.info(
                    f"before inserting left_hand_expression_id and right_hand_expression_id -----------{ordinal_counter}"
                )
                # if left_hand_expression_id and right_hand_expression_id and condtion_value:
                if condtion_value:
                    expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Simple';"""
                    query_result = self.execute_query(
                        mssql_conn, expression_type_id_query
                    )
                    expression_type_id = query_result.iloc[0]["id"]
                    logging.info(f"expression_type_id-----------{expression_type_id}")
                    right_hand_expression_id = right_hand_expression_id or "NULL"
                    with mssql_conn.cursor() as cursor:
                        final_insert_query = f"""
                        INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, Ordinal, VersionId)  OUTPUT INSERTED.id
                        VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', {right_hand_expression_id if right_hand_expression_id == 'NULL' else f"'{right_hand_expression_id}'"}, '{condtion_value}', '{created_by}', '{created_date}', {ordinal_counter}, '{version_id}') ;
                        """
                        cursor.execute(final_insert_query)
                        final_query_id = cursor.fetchone()[0]
                        logging.info(f"final_query_id--------------{final_query_id}")
                        logging.info("Final rule_expression inserted")
                        mssql_conn.commit()
                        # with mssql_conn.cursor() as cursor:
                        #     update_ordinal_query = f"""
                        #     UPDATE {onepoint_o_database}.dbo.RULE_Expression
                        #     SET Ordinal = {ordinal_counter}
                        #     WHERE id IN ('{left_hand_expression_id}', '{right_hand_expression_id}', '{final_query_id}')
                        #     """
                        #     cursor.execute(update_ordinal_query)
                        #     mssql_conn.commit()
                logging.info(expression_details["cond"], "inserted cond")

                return final_query_id

            def expresion_builder(expression_details, ordinal_counter):
                logging.info("in create function")
                if len(expression_details) > 1:
                    logging.info(f"exp got is", expression_details)
                    logging.info(f"\n")
                    logging.info(f"ordinal_counter----------{ordinal_counter}")
                    exp_3_id, ordinal_counter = expresion_builder(
                        expression_details[2:], ordinal_counter
                    )
                    logging.info(f"ordinal_counter----------{ordinal_counter}")
                    logging.info(f"exp_3_id--------{exp_3_id}")
                    if ordinal_counter % 2 == 0:
                        ordinal_counter = ordinal_counter - 1
                    exp_1_id = inserting(expression_details[0], ordinal_counter)
                    ordinal_counter = ordinal_counter + 1
                    logging.info(f"ordinal_counter----------{ordinal_counter}")
                    logging.info(f"exp_1_id--------{exp_1_id}")
                    cond = list(expression_details[1].values())[0]
                    logging.info(f"cond------{cond}")
                    left_hand_expression_id = (
                        exp_1_id  # The first expression part (field_1 or const_one)
                    )
                    right_hand_expression_id = exp_3_id
                    logging.info(
                        f"left_hand_expression_id--------------{left_hand_expression_id}"
                    )
                    logging.info(
                        f"right_hand_expression_id------------{right_hand_expression_id}"
                    )
                    logging.info(exp_1_id, cond, exp_3_id)
                    if cond == "OR":
                        operator_type_query = f"""select id from public.rule_operator_type where name = '{cond}' """
                        operator_type = self.execute_query(
                            postgres_conn, operator_type_query
                        )
                        operator_type = operator_type["id"].iloc[0]
                        logging.info(f"operator_type----------{operator_type}")
                        expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Complex';"""
                        query_result = self.execute_query(
                            mssql_conn, expression_type_id_query
                        )
                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"expression_type_id-----------{expression_type_id}")
                        with mssql_conn.cursor() as cursor:
                            final_insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, VersionId)  OUTPUT INSERTED.id
                            VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', '{right_hand_expression_id}', '{operator_type}', '{created_by}', '{created_date}', '{version_id}') ;
                            """
                            cursor.execute(final_insert_query)
                            final_query_id = cursor.fetchone()[0]
                            logging.info(f"final_query_id--------------{final_query_id}")
                            logging.info("Final rule_expression inserted")
                            mssql_conn.commit()
                            with mssql_conn.cursor() as cursor:
                                update_ordinal_query = f"""
                                UPDATE {onepoint_o_database}.dbo.RULE_Expression
                                SET Ordinal = {ordinal_counter}
                                WHERE id IN ('{final_query_id}')
                                """
                                cursor.execute(update_ordinal_query)
                                mssql_conn.commit()
                            return final_query_id, ordinal_counter - 2

                    elif cond == "AND":
                        expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Complex';"""
                        query_result = self.execute_query(
                            mssql_conn, expression_type_id_query
                        )
                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"expression_type_id-----------{expression_type_id}")
                        operator_type_query = f"""select id from public.rule_operator_type where name = '{cond}' """
                        operator_type = self.execute_query(
                            postgres_conn, operator_type_query
                        )
                        operator_type = operator_type["id"].iloc[0]
                        with mssql_conn.cursor() as cursor:
                            final_insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, VersionId)  OUTPUT INSERTED.id
                            VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', '{right_hand_expression_id}', '{operator_type}', '{created_by}', '{created_date}', '{version_id}') ;
                            """
                            cursor.execute(final_insert_query)
                            final_query_id = cursor.fetchone()[0]
                            logging.info(f"final_query_id--------------{final_query_id}")
                            logging.info("Final rule_expression inserted")
                            mssql_conn.commit()
                            with mssql_conn.cursor() as cursor:
                                update_ordinal_query = f"""
                                UPDATE {onepoint_o_database}.dbo.RULE_Expression
                                SET Ordinal = {ordinal_counter}
                                WHERE id IN ('{final_query_id}')
                                """
                                cursor.execute(update_ordinal_query)
                                mssql_conn.commit()
                            return final_query_id, ordinal_counter - 2
                else:
                    logging.info(f"exp got is in else", expression_details)
                    logging.info(f"\n")
                    expression_details = expression_details[0]
                    logging.info(f"ordinal_counter-----------{ordinal_counter}")
                    return (
                        inserting(expression_details, ordinal_counter),
                        ordinal_counter - 2,
                    )

            ordinal_counter = len(expression_details)
            # ordinal_counter = 1
            expresion_builder(expression_details, ordinal_counter)

        elif flag == "delete":
            rule_rule_defintiton_details_query = f"select rule_id_1_0, deleted_date, deleted_by from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}'"
            rule_rule_definition_details = self.execute_query(
                postgres_conn, rule_rule_defintiton_details_query
            )
            logging.info(f"rule_rule_definition_details--------{rule_rule_definition_details}")
            rule_id_1_0 = rule_rule_definition_details.get("rule_id_1_0")
            logging.info(f"rule_id_1_0--------{rule_id_1_0}")
            deleted_date = rule_rule_definition_details.get("deleted_date")
            deleted_by = rule_rule_definition_details.get("deleted_by")
            deleted_date = deleted_date.iloc[0]
            if pd.isna(deleted_date):
                deleted_date = "NULL"
            else:
                deleted_date = f"'{deleted_date.strftime('%Y-%m-%d %H:%M:%S')}'"
            deleted_by = deleted_by.iloc[0]
            rule_id_1_0 = rule_id_1_0.iloc[0]

            delete_query = f"update {onepoint_o_database}.dbo.RULE_RuleDefinition set IsActive = '0', IsDeleted = '1', DeletedDate = {deleted_date}, DeletedBy = '{deleted_by}' where id = '{rule_id_1_0}'"
            logging.info(f"delete_query----------{delete_query}")
            with mssql_conn.cursor() as cursor:
                cursor.execute(delete_query)
                mssql_conn.commit()

        elif flag == "edit":

            # fetch the details from 2.0 rule_rule_definition table

            rule_rule_defintiton_rule_id_1_0_query = f"select rule_id_1_0 from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}' order by version_no"
            rule_rule_defintiton_rule_id_1_0 = self.execute_query(
                postgres_conn, rule_rule_defintiton_rule_id_1_0_query
            )
            rule_id_1_0 = rule_rule_defintiton_rule_id_1_0.loc[0, "rule_id_1_0"]
            logging.info(f"rule_id_1_0---------{rule_id_1_0}")

            with postgres_conn.cursor() as cursor:
                update_query = f"""
                    UPDATE public.rule_rule_definition
                    SET rule_id_1_0 = '{rule_id_1_0}'
                    WHERE rule_def_id = '{rule_id_2_0}' AND is_active = true
                    """
                logging.info(f"update_query----------{update_query}")
                cursor.execute(update_query)
                postgres_conn.commit()
                logging.info(f"Updated 1_0_rule_id in rule_rule_definition table")

            rule_rule_defintiton_details_query = f"select * from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}' and is_active = true"
            rule_rule_definition_details = self.execute_query(
                postgres_conn, rule_rule_defintiton_details_query
            )
            logging.info(
                f"rule_rule_definition_details-----------{rule_rule_definition_details}"
            )

            # fetch rule_id_1_0 column to take that as id column to update in 1.0 rule_defintion table
            rule_id_1_0 = rule_rule_definition_details.loc[0, "rule_id_1_0"]
            logging.info(f"rule_id_1_0-----{rule_id_1_0}")

            # dropping id details
            rule_rule_definition_details = rule_rule_definition_details.drop(
                columns=["id"]
            ).iloc[:, :-9]

            # updating the details in rule_definition tables with the latest data
            all_columns = rule_rule_definition_details.columns
            columns_to_insert_camel_case = [to_camel_case(col) for col in all_columns]
            logging.info(f'columns_to_insert-----------{columns_to_insert_camel_case}')
            # update_set_statements = ", ".join(columns_to_insert_camel_case)
            # logging.info(f'update_set_statements-------------{update_set_statements}')

            update_set_statements = ", ".join(
                [f"{col} = %s" for col in columns_to_insert_camel_case]
            )
            logging.info(f'update_set_statements-----------{update_set_statements}')
            update_query = f"UPDATE {onepoint_o_database}.dbo.RULE_RuleDefinition SET {update_set_statements} WHERE id = '{rule_id_1_0}'"
            logging.info(f"Update query: {update_query}")

            def convert_value(value):
                if isinstance(
                    value, pd.Timestamp
                ):  # Convert pandas.Timestamp to Python datetime
                    return value.to_pydatetime()
                if isinstance(value, bool):  # Ensure booleans are Python native
                    return bool(value)
                if isinstance(value, np.bool_):  # Convert numpy.bool_ to Python bool
                    return bool(value)
                if isinstance(
                    value, np.int64
                ):  # Explicitly handle numpy.int64 conversion to int
                    return int(value)
                if pd.isna(value):  # Convert NaT (pandas missing time) to None for SQL
                    return None
                if value is None:  # Handle None (SQL NULL)
                    return None
                return value  # Leave other types as they are

            # logging.info(len(all_columns))
            # logging.info(len(rule_rule_definition_details.columns))
            update_values = [
                convert_value(value)
                for value in rule_rule_definition_details.iloc[0].tolist()
            ]
            update_values = [
                value if value is not None else None for value in update_values
            ]
            update_values = tuple(update_values)
            logging.info(f"values -----------{update_values}")
            with mssql_conn.cursor() as cursor:
                cursor.execute(update_query, update_values)
                mssql_conn.commit()

            logging.info(f"query is executed to edit the rule_rule_definition")

            # insert the details as a new row in rules_verison table

            rule_rule_definition_updated_details_query = f"select * from {onepoint_o_database}.dbo.RULE_RuleDefinition where id = '{rule_id_1_0}'"
            rule_rule_definition_updated_details = self.execute_query(
                mssql_conn, rule_rule_definition_updated_details_query
            )

            logging.info(
                f"rule_rule_definition_updated_details------------{rule_rule_definition_updated_details.columns}"
            )

            if not rule_rule_definition_updated_details.empty:
                rule_rule_definition_updated_details = (
                    rule_rule_definition_updated_details.drop(columns=["RuleId"])
                )
                rule_rule_definition_updated_details = (
                    rule_rule_definition_updated_details.drop(columns=["VersionId"])
                )
                rule_rule_definition_updated_details = (
                    rule_rule_definition_updated_details.rename(
                        columns={"id": "RuleId"}
                    )
                )
                columns_to_insert = rule_rule_definition_updated_details.columns
                # columns_to_insert = all_columns[:-8]  # Exclude last 5 columns and rule_id column
                logging.info(f"columns_to_insert-----------{columns_to_insert}")
                column_names = ", ".join(columns_to_insert)
                placeholders = ", ".join(["%s"] * len(columns_to_insert))

                insert_query = f"""
                    INSERT INTO {onepoint_o_database}.dbo.RULE_Version ({column_names}) OUTPUT INSERTED.id
                    VALUES ({placeholders})
                    """
                logging.info(f"insert_query RULE_Version {insert_query}")

                # Build the INSERT query dynamically
                def convert_value(x):
                    if isinstance(x, np.int64):
                        return int(x)
                    elif isinstance(x, np.float64):
                        return float(x)
                    elif isinstance(x, np.bool_):
                        return bool(x)
                    elif isinstance(x, pd.Timestamp):
                        return x.to_pydatetime()
                    else:
                        return x

                data_to_insert = (
                    rule_rule_definition_updated_details.iloc[0][
                        columns_to_insert
                    ]  # Exclude rule_id
                    .apply(convert_value)
                    .tolist()
                )
                logging.info(f"data_to_insert----------{data_to_insert}")
                with mssql_conn.cursor() as cursor:
                    cursor.execute(insert_query, tuple(data_to_insert))
                    new_id = cursor.fetchone()[0]
                    logging.info(f"New ID inserted: {new_id}")
                    cursor.execute(
                        f"SELECT VersionNumber FROM {onepoint_o_database}.dbo.RULE_Version WHERE RuleId = %s order by VersionNumber desc",
                        (rule_id_1_0,),
                    )
                    current_version_number = cursor.fetchone()
                    logging.info(
                        f"Current VersionNumber before update: {current_version_number}"
                    )
                    updated_version_number = int(current_version_number[0]) + 1
                    mssql_conn.commit()
                    update_query = f"""UPDATE {onepoint_o_database}.dbo.RULE_Version
                                    SET "VersionNumber" = %s
                                    WHERE id = %s"""
                    logging.info(f"update_query----------{update_query}")
                    cursor.execute(update_query, (updated_version_number, new_id))
                    mssql_conn.commit()
                    logging.info(f"Updated version_number in rule version table table")
                # fetched the id from updated_rule version and update it back to rule_defintion

                update_query = f"""
                    UPDATE {onepoint_o_database}.dbo.RULE_RuleDefinition
                    SET VersionId = %s
                    WHERE id = %s
                """

                # Get the new version_id (this was fetched earlier after the insert)
                # 'version_id' is the ID of the newly inserted row in the RULE_Version table
                logging.info(
                    f"Updating RULE_RuleDefinition with version_id {new_id} for id {rule_id_1_0}"
                )

                # Execute the UPDATE query
                with mssql_conn.cursor() as cursor:
                    cursor.execute(update_query, (new_id, rule_id_1_0))
                    mssql_conn.commit()

                logging.info("Data inserted successfully.")

            # edit customer_list based on changes
            customer_list_edited_details_query = f"select * from {onepoint_o_database}.dbo.NotificationRuleRecipient where RuleId = '{rule_id_1_0}'"
            customer_list_edited_details = self.execute_query(
                mssql_conn, customer_list_edited_details_query
            )

            if not customer_list_edited_details.empty:
                delete_query = f"DELETE FROM {onepoint_o_database}.dbo.NotificationRuleRecipient WHERE RuleId = '{rule_id_1_0}'"
                with mssql_conn.cursor() as cursor:
                    cursor.execute(delete_query)
                    mssql_conn.commit()
            rule_rule_defintiton_customer_details_query = f"select rule_id_1_0, customers_list, created_date, created_by from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}' and is_active = true"
            rule_rule_definition_customer_details = self.execute_query(
                postgres_conn, rule_rule_defintiton_customer_details_query
            )

            logging.info(
                f"rule_rule_definition_customer_details-------------{rule_rule_definition_customer_details}"
            )
            customers_list = rule_rule_definition_customer_details.get("customers_list")
            logging.info(f"customers_list--------{customers_list}")
            rule_id_1_0_value = rule_rule_definition_customer_details.get("rule_id_1_0")
            created_date_value = rule_rule_definition_customer_details.get(
                "created_date"
            )
            created_by_value = rule_rule_definition_customer_details.get("created_by")

            rule_id_1_0 = (
                rule_id_1_0_value.iloc[0] if not rule_id_1_0_value.empty else None
            )
            created_date = (
                created_date_value.iloc[0] if not created_date_value.empty else None
            )
            created_by = (
                created_by_value.iloc[0] if not created_by_value.empty else None
            )
            # logging.info(f'customers_list---{customers_list}')
            created_date = created_date.strftime("%Y-%m-%d %H:%M:%S")
            customers_list = customers_list.iloc[
                0
            ]  # Accessing the first (and probably only) element in the series
            logging.info(f"customers_list------{customers_list}")
            customers_data = json.loads(customers_list)
            logging.info(f"customers_data----------{customers_data}")

            # Now you can access 'customer_names' and 'customer_groups'
            customer_names_id = [
                customer_id
                for customer in customers_data.get("customer_names") or []
                for _, customer_id in customer.items()
            ]
            # customer_groups_id = [group_id for group in customers_data.get("customer_groups") or [] for _, group_id in group.items()]
            customer_groups_id = [
                group_id
                for group in customers_data.get("customer_groups") or []
                for _, group_id in group.items()
            ]

            logging.info(f"Customer Names IDs: {customer_names_id}")
            logging.info(f"Customer Groups IDs: {customer_groups_id}")
            column_names = "RuleId, CustomerId, CustomerGroupId, CreatedDate, CreatedBy"
            placeholders = "%s, %s, %s, %s, %s"

            logging.info(f"customer_names_id----------{type(customer_names_id)}")
            for customer_id in customer_names_id:
                insert_query = f"""
            INSERT INTO {onepoint_o_database}.dbo.NotificationRuleRecipient ({column_names})
            VALUES ({placeholders})
            """
                logging.info(f"insert_query-------{insert_query}")
                with mssql_conn.cursor() as cursor:
                    cursor.execute(
                        insert_query,
                        tuple(
                            [rule_id_1_0, customer_id, None, created_date, created_by]
                        ),  # Replace None and other placeholders as needed
                    )

            for customer_group_id in customer_groups_id:
                insert_query = f"""
            INSERT INTO {onepoint_o_database}.dbo.NotificationRuleRecipient ({column_names})
            VALUES ({placeholders})
            """
                logging.info(f"insert_query-------{insert_query}")
                with mssql_conn.cursor() as cursor:
                    cursor.execute(
                        insert_query,
                        tuple(
                            [
                                rule_id_1_0,
                                None,
                                customer_group_id,
                                created_date,
                                created_by,
                            ]
                        ),  # Replace None and other placeholders as needed
                    )

                mssql_conn.commit()

                logging.info("Data inserted successfully.")

            # update is_active false for already existed expressions
            logging.info(f"rule_id_2_0----------{rule_id_2_0}")
            rule_rule_defintiton_details_query = f"select * from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}' and is_active = true"
            rule_rule_definition_details = self.execute_query(
                postgres_conn, rule_rule_defintiton_details_query
            )
            logging.info(
                f"rule_rule_definition_details------------{rule_rule_definition_details}"
            )
            expression_details_str = rule_rule_definition_details[
                "expression_ids"
            ].iloc[0]
            logging.info(f"expression_details_str-------{expression_details_str}")
            rule_id_1_0 = rule_rule_definition_details.get("rule_id_1_0")
            deleted_date = rule_rule_definition_details.get("deleted_date")
            deleted_by = rule_rule_definition_details.get("deleted_by")
            deleted_date = deleted_date.iloc[0]
            if pd.isna(deleted_date):
                deleted_date = "NULL"
            else:
                deleted_date = f"'{deleted_date.strftime('%Y-%m-%d %H:%M:%S')}'"
            deleted_by = deleted_by.iloc[0]
            rule_id_1_0 = rule_id_1_0.iloc[0]

            delete_query = f"update {onepoint_o_database}.dbo.RULE_Expression set IsActive = '0', IsDeleted = '1', DeletedDate = {deleted_date}, DeletedBy = '{deleted_by}' where RuleDefinitionId = '{rule_id_1_0}'"
            logging.info(f"delete_query----------{delete_query}")
            with mssql_conn.cursor() as cursor:
                cursor.execute(delete_query)
                mssql_conn.commit()

            # fetching the data of expression list from 2.0 based on rule_id
            created_date = rule_rule_definition_details["created_date"].iloc[0]
            created_date = created_date.strftime("%Y-%m-%d %H:%M:%S")
            created_by = rule_rule_definition_details["created_by"].iloc[0]
            expression_details = json.loads(expression_details_str)
            logging.info(f"expression_details---------{expression_details}")

            def get_type(value):
                if isinstance(value, bool):
                    return "Boolean"
                if isinstance(value, int) and value > 10**9:
                    return "BigInteger"
                elif isinstance(value, int):
                    return "Integer"
                elif isinstance(value, float):
                    return "Decimal"
                elif isinstance(value, str):
                    try:
                        int(value)
                        return "Integer"
                    except ValueError:
                        pass
                    try:
                        float(value)
                        return "Decimal"
                    except ValueError:
                        pass
                    return "String"
                elif isinstance(value, str) and ("-" in value or ":" in value):
                    return "DateTime"
                try:
                    import uuid

                    uuid.UUID(value)
                    return "Guid"
                except (ValueError, TypeError):
                    pass
                if isinstance(value, str) and value.startswith("$"):
                    return "Money"

                return "Unknown"

            def inserting(expression_details, ordinal_counter):
                field_1_id = None
                const_one_id = None
                field_2_id = None
                const_two_id = None
                logging.info("inserting of an expression")
                logging.info(f"expression_details----------{expression_details}")
                condtion_value = list(expression_details["cond"].values())[0]
                if (
                    "const_one" in expression_details
                    or "field_one" in expression_details
                ):
                    if "field_one" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            # field_one_value = list(expression_details['field_one'].values())[0]
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Constant';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            constant_value = expression_details["field_one"]
                            logging.info(f"constant_value-----{constant_value}")
                            constant_type = get_type(constant_value)
                            logging.info(f"constant_type-----{constant_type}")
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            constant_type_id_query = f""" select id from {onepoint_o_database}.dbo.DataType where DataTypeName = '{constant_type}';"""
                            query_result = self.execute_query(
                                mssql_conn, constant_type_id_query
                            )
                            logging.info(f"query_result---------{query_result}")
                            change_type_id = query_result.iloc[0]["id"]
                            logging.info(f"change_type_id---------{change_type_id}")
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            data_to_insert = (
                                rule_id_1_0,
                                expression_type_id,
                                expression_details["field_one"],
                                change_type_id,
                                created_by,
                                created_date,
                                ordinal_counter,
                                new_id,
                            )
                            logging.info(f"data_to_insert-----------{data_to_insert}")
                            insert_query = f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                OUTPUT INSERTED.id
                                VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                            """
                            logging.info(f"insert_query------{insert_query}")
                            cursor.execute(insert_query, data_to_insert)
                            field_1_id = cursor.fetchone()[0]
                            logging.info(f"New ID inserted: {field_1_id}")
                            logging.info(
                                expression_details["field_one"], "inserted", "field_one"
                            )
                            mssql_conn.commit()
                    elif "const_one" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Field';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            const_one_value = list(
                                expression_details["const_one"].values()
                            )[0]
                            data_to_insert = (
                                rule_id_1_0,
                                expression_type_id,
                                const_one_value,
                                created_by,
                                created_date,
                                ordinal_counter,
                                new_id,
                            )
                            insert_query =f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                OUTPUT INSERTED.id
                                VALUES (%s, %s, %s, %s, %s, %s, %s);
                            """
                            cursor.execute(insert_query, data_to_insert)
                            const_one_id = cursor.fetchone()[0]
                            logging.info(f"New ID inserted: {const_one_id}")
                            logging.info(expression_details["const_one"], "inserted const_one")
                            mssql_conn.commit()
                if (
                    "field_two" in expression_details
                    or "const_two" in expression_details
                ):
                    # if condtion_value == 'HAS vALUE' or 'HAS NO VALUE':
                    if "field_two" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Constant';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            field_two_value = expression_details.get("field_two")
                            logging.info(f"field_two_value------------{field_two_value}")
                            if not field_two_value:  # Handle empty const_two
                                logging.info("field_two is empty; skipping insertion.")
                            else:
                                unit = expression_details.get("unit", "").lower()
                                logging.info(f"unit-----------{unit}")
                                # Default to an empty string if 'unit' is missing
                                if unit:
                                    logging.info(f"if unit condition")
                                    try:
                                        field_two_numeric = float(
                                            field_two_value
                                        )  # Ensure it's numeric for conversion
                                        logging.info(
                                            f"field_two_numeric----------{field_two_numeric}"
                                        )
                                        if unit == "mb":
                                            field_two_value = (
                                                field_two_numeric * 1024**2
                                            )
                                            field_two_value = int(field_two_value)

                                        elif unit == "gb":
                                            field_two_value = (
                                                field_two_numeric * 1024**3
                                            )
                                            field_two_value = int(field_two_value)
                                        else:
                                            logging.info(
                                                f"Unit '{unit}' is not recognized; assuming value is already in bytes."
                                            )
                                        logging.info(
                                            f"field_two_value---------------{field_two_value}"
                                        )
                                    except ValueError:
                                        logging.info(
                                            f"Error: field_two value '{field_two_value}' is not numeric."
                                        )
                                else:
                                    logging.info(
                                        "No unit provided; assuming field_two is in bytes."
                                    )

                                constant_type = get_type(field_two_value)
                                logging.info(f"constant_type-----{constant_type}")
                                logging.info(
                                    f"expression_type_id-----------{expression_type_id}"
                                )
                                constant_type_id_query = f""" select id from {onepoint_o_database}.dbo.DataType where DataTypeName = '{constant_type}';"""
                                logging.info(
                                    f"constant_type_id_query------------{constant_type_id_query}"
                                )
                                query_result = self.execute_query(
                                    mssql_conn, constant_type_id_query
                                )
                                logging.info(f"query_result---------{query_result}")
                                change_type_id = query_result.iloc[0]["id"]
                                logging.info(f"change_type_id---------{change_type_id}")

                                # field_two_value = list(expression_details['field_two'].values())[0]
                                data_to_insert = (
                                    rule_id_1_0,
                                    expression_type_id,
                                    field_two_value,
                                    int(change_type_id),
                                    created_by,
                                    created_date,
                                    ordinal_counter,
                                    new_id,
                                )
                                insert_query = f"""
                                    INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                    OUTPUT INSERTED.id
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                                """
                                logging.info(f"insert_query-------{insert_query}")
                                logging.info(f"data_to_insert--------{data_to_insert}")
                                cursor.execute(insert_query, data_to_insert)
                                field_2_id = cursor.fetchone()[0]
                                logging.info(f"New ID inserted: {field_2_id}")
                                logging.info(
                                    expression_details["field_two"],
                                    "inserted",
                                    "field_two",
                                )
                                mssql_conn.commit()
                    elif "const_two" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Field';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            const_two_details = expression_details.get("const_two", {})
                            if not const_two_details:  # Handle empty const_two
                                logging.info("const_two_value is empty; skipping insertion.")
                            else:
                                const_two_value = list(
                                    expression_details["const_two"].values()
                                )[0]
                                data_to_insert = (
                                    rule_id_1_0,
                                    expression_type_id,
                                    const_two_value,
                                    created_by,
                                    created_date,
                                    ordinal_counter,
                                    new_id,
                                )
                                insert_query = f"""
                                    INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                    OUTPUT INSERTED.id
                                    VALUES (%s, %s, %s, %s, %s, %s, %s);
                                """
                                cursor.execute(insert_query, data_to_insert)
                                const_two_id = cursor.fetchone()[0]
                                logging.info(f"New ID inserted: {const_two_id}")
                                logging.info(
                                    expression_details["const_two"],
                                    "inserted const_two",
                                )
                                mssql_conn.commit()
                left_hand_expression_id = field_1_id or const_one_id
                right_hand_expression_id = field_2_id or const_two_id
                condtion_value = list(expression_details["cond"].values())[0]
                logging.info(f"left_hand_expression_id------------{left_hand_expression_id}")
                logging.info(
                    f"right_hand_expression_id--------------{right_hand_expression_id}"
                )
                logging.info(f"condtion_value-----------{condtion_value}")
                logging.info(
                    f"before inserting left_hand_expression_id and right_hand_expression_id -----------{ordinal_counter}"
                )
                # if left_hand_expression_id and right_hand_expression_id and condtion_value:
                if condtion_value:
                    expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Simple';"""
                    query_result = self.execute_query(
                        mssql_conn, expression_type_id_query
                    )
                    expression_type_id = query_result.iloc[0]["id"]
                    logging.info(f"expression_type_id-----------{expression_type_id}")
                    right_hand_expression_id = right_hand_expression_id or "NULL"
                    with mssql_conn.cursor() as cursor:
                        final_insert_query = f"""
                        INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, Ordinal, VersionId)  OUTPUT INSERTED.id
                        VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', {right_hand_expression_id if right_hand_expression_id == 'NULL' else f"'{right_hand_expression_id}'"}, '{condtion_value}', '{created_by}', '{created_date}', {ordinal_counter}, '{new_id}') ;
                        """
                        cursor.execute(final_insert_query)
                        final_query_id = cursor.fetchone()[0]
                        logging.info(f"final_query_id--------------{final_query_id}")
                        logging.info("Final rule_expression inserted")
                        mssql_conn.commit()
                        # with mssql_conn.cursor() as cursor:
                        #     update_ordinal_query = f"""
                        #     UPDATE {onepoint_o_database}.dbo.RULE_Expression
                        #     SET Ordinal = {ordinal_counter}
                        #     WHERE id IN ('{left_hand_expression_id}', '{right_hand_expression_id}', '{final_query_id}')
                        #     """
                        #     cursor.execute(update_ordinal_query)
                        #     mssql_conn.commit()
                logging.info(expression_details["cond"], "inserted cond")

                return final_query_id

            # def expresion_builder(expression_details, ordinal_counter):
            #     logging.info('in create function')
            #     if len(expression_details)>1:
            #         logging.info(F"exp got is",expression_details)
            #         logging.info(F"\n")
            #         logging.info(f'ordinal_counter----------{ordinal_counter}')
            #         exp_3_id,ordinal_counter = expresion_builder(expression_details[2:], ordinal_counter)
            #         logging.info(f'ordinal_counter----------{ordinal_counter}')
            #         logging.info(f'exp_3_id--------{exp_3_id}')
            #         exp_1_id=inserting(expression_details[0], ordinal_counter)
            #         ordinal_counter=ordinal_counter-1
            #         logging.info(f'ordinal_counter----------{ordinal_counter}')
            #         logging.info(f'exp_1_id--------{exp_1_id}')
            #         cond=list(expression_details[1].values())[0]
            #         logging.info(f'cond------{cond}')
            #         left_hand_expression_id = exp_1_id  # The first expression part (field_1 or const_one)
            #         right_hand_expression_id = exp_3_id
            def expresion_builder(expression_details, ordinal_counter):
                logging.info("in create function")
                if len(expression_details) > 1:
                    logging.info(f"exp got is", expression_details)
                    logging.info(f"\n")
                    logging.info(f"ordinal_counter----------{ordinal_counter}")
                    exp_3_id, ordinal_counter = expresion_builder(
                        expression_details[2:], ordinal_counter
                    )
                    logging.info(f"ordinal_counter----------{ordinal_counter}")
                    logging.info(f"exp_3_id--------{exp_3_id}")
                    if ordinal_counter % 2 == 0:
                        ordinal_counter = ordinal_counter - 1
                    exp_1_id = inserting(expression_details[0], ordinal_counter)
                    ordinal_counter = ordinal_counter + 1
                    logging.info(f"ordinal_counter----------{ordinal_counter}")
                    logging.info(f"exp_1_id--------{exp_1_id}")
                    cond = list(expression_details[1].values())[0]
                    logging.info(f"cond------{cond}")
                    left_hand_expression_id = (
                        exp_1_id  # The first expression part (field_1 or const_one)
                    )
                    right_hand_expression_id = exp_3_id
                    logging.info(
                        f"left_hand_expression_id--------------{left_hand_expression_id}"
                    )
                    logging.info(
                        f"right_hand_expression_id------------{right_hand_expression_id}"
                    )
                    logging.info(exp_1_id, cond, exp_3_id)
                    if cond == "OR":
                        operator_type_query = f"""select id from public.rule_operator_type where name = '{cond}' """
                        operator_type = self.execute_query(
                            postgres_conn, operator_type_query
                        )
                        operator_type = operator_type["id"].iloc[0]
                        logging.info(f"operator_type----------{operator_type}")
                        expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Complex';"""
                        query_result = self.execute_query(
                            mssql_conn, expression_type_id_query
                        )
                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"expression_type_id-----------{expression_type_id}")
                        with mssql_conn.cursor() as cursor:
                            final_insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, VersionId)  OUTPUT INSERTED.id
                            VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', '{right_hand_expression_id}', '{operator_type}', '{created_by}', '{created_date}', '{version_id}') ;
                            """
                            cursor.execute(final_insert_query)
                            final_query_id = cursor.fetchone()[0]
                            logging.info(f"final_query_id--------------{final_query_id}")
                            logging.info("Final rule_expression inserted")
                            mssql_conn.commit()
                            with mssql_conn.cursor() as cursor:
                                update_ordinal_query = f"""
                                UPDATE {onepoint_o_database}.dbo.RULE_Expression
                                SET Ordinal = {ordinal_counter}
                                WHERE id IN ('{final_query_id}')
                                """
                                cursor.execute(update_ordinal_query)
                                mssql_conn.commit()
                            return final_query_id, ordinal_counter - 2

                    elif cond == "AND":
                        expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Complex';"""
                        query_result = self.execute_query(
                            mssql_conn, expression_type_id_query
                        )
                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"expression_type_id-----------{expression_type_id}")
                        operator_type_query = f"""select id from public.rule_operator_type where name = '{cond}' """
                        operator_type = self.execute_query(
                            postgres_conn, operator_type_query
                        )
                        operator_type = operator_type["id"].iloc[0]
                        with mssql_conn.cursor() as cursor:
                            final_insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, VersionId)  OUTPUT INSERTED.id
                            VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', '{right_hand_expression_id}', '{operator_type}', '{created_by}', '{created_date}', '{version_id}') ;
                            """
                            cursor.execute(final_insert_query)
                            final_query_id = cursor.fetchone()[0]
                            logging.info(f"final_query_id--------------{final_query_id}")
                            logging.info("Final rule_expression inserted")
                            mssql_conn.commit()
                            with mssql_conn.cursor() as cursor:
                                update_ordinal_query = f"""
                                UPDATE {onepoint_o_database}.dbo.RULE_Expression
                                SET Ordinal = {ordinal_counter}
                                WHERE id IN ('{final_query_id}')
                                """
                                cursor.execute(update_ordinal_query)
                                mssql_conn.commit()
                            return final_query_id, ordinal_counter - 2
                else:
                    logging.info(f"exp got is in else", expression_details)
                    logging.info(f"\n")
                    expression_details = expression_details[0]
                    logging.info(f"ordinal_counter-----------{ordinal_counter}")
                    return (
                        inserting(expression_details, ordinal_counter),
                        ordinal_counter - 2,
                    )

            ordinal_counter = len(expression_details)
            # ordinal_counter = 1
            expresion_builder(expression_details, ordinal_counter)

        else:
            pass
