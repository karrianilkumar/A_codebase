-- public.automation_rule_verification_report_view source
CREATE OR REPLACE VIEW public.automation_rule_verification_report_view
AS SELECT array_to_string(array_remove(ARRAY[art.id, ar.id], NULL::integer), '-'::text) AS id,
    art.automation_rule_id,
    ar.automation_rule_name AS rule_name,
    art.rule_action_id,
    ar.service_provider_name,
    ar.description,
    art.created_date,
    art.is_active,
        CASE
            WHEN art.rule_action_value::text ~ '[A-Za-z]'::text THEN art.rule_action_value
            ELSE NULL::character varying
        END AS apply1,
        CASE
            WHEN art.rule_action_value::text ~ '^[0-9]+$'::text THEN ( SELECT ds.description
               FROM device_status ds
              WHERE ds.id = art.rule_action_value::integer)
            ELSE NULL::character varying
        END AS apply2,
        CASE
            WHEN art.rule_condition_value::text ~ '[A-Za-z]'::text THEN art.rule_condition_value
            ELSE NULL::character varying
        END AS apply_trigger_1,
        CASE
            WHEN art.rule_condition_value::text ~ '^[0-9]+$'::text THEN ( SELECT ds.description
               FROM device_status ds
              WHERE ds.id = art.rule_condition_value::integer)
            ELSE NULL::character varying
        END AS apply_trigger_2,
        CASE
            WHEN art.rule_action_id = 2 THEN
            CASE
                WHEN art.rule_action_value::text ~ '^[0-9]+$'::text THEN ( SELECT ds.description
                   FROM device_status ds
                  WHERE ds.id = art.rule_action_value::integer
                 LIMIT 1)
                ELSE art.rule_action_value
            END
            ELSE NULL::character varying
        END AS remove_trigger_1,
        CASE
            WHEN art.rule_action_id = 2 THEN
            CASE
                WHEN art.rule_condition_value::text ~ '^[0-9]+$'::text THEN ( SELECT ds.description
                   FROM device_status ds
                  WHERE ds.id = art.rule_condition_value::integer)
                ELSE art.rule_condition_value
            END
            ELSE NULL::character varying
        END AS remove_trigger_2,
    art.modified_date
   FROM automation_rule_detail art
     LEFT JOIN automation_rule ar ON ar.id = art.automation_rule_id;


-- public.cross_provider_view source

CREATE OR REPLACE VIEW public.cross_provider_view
AS WITH summed_data_usage AS (
         SELECT cpdh.id,
            cpdh.m2m_device_id,
            cpdh.mobility_device_id,
            sum(device_usage_1.data_usage) AS total_usage,
            max(device_usage_1.usage_date) AS last_date
           FROM device_usage device_usage_1
             JOIN device_status device_status_1 ON device_status_1.id = device_usage_1.device_status_id
             JOIN cross_provider_device_history cpdh ON cpdh.m2m_device_id IS NOT NULL AND device_usage_1.m2m_device_id = cpdh.m2m_device_id OR cpdh.mobility_device_id IS NOT NULL AND device_usage_1.mobility_device_id = cpdh.mobility_device_id
          WHERE (cpdh.m2m_device_id IS NOT NULL OR cpdh.mobility_device_id IS NOT NULL) AND (device_usage_1.data_usage > 0 OR device_status_1.is_active_status = true)
          GROUP BY cpdh.id, cpdh.m2m_device_id, cpdh.mobility_device_id
        )
 SELECT DISTINCT cross_provider_device_history.id,
    cross_provider_device_history.service_provider_id,
    service_provider.display_name AS service_provider_display_name,
    service_provider.integration_id,
    cross_provider_device_history.iccid,
    cross_provider_device_history.msisdn,
    cross_provider_device_history.imei,
    jasper_carrier_rate_plan.friendly_name AS carrier_rate_plan,
    summed_data_usage.total_usage AS data_usage_bytes,
        CASE
            WHEN integration.id = 1 THEN round(COALESCE(summed_data_usage.total_usage, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(summed_data_usage.total_usage, 0.0) / 1024.0 / 1024.0, 3)
        END AS data_usage_mb,
    cross_provider_device_history.provider_date_added AS date_added,
    cross_provider_device_history.provider_date_activated AS date_activated,
    jasper_customer_rate_plan.rate_plan_code AS customer_rate_plan_code,
    jasper_customer_rate_plan.rate_plan_name,
    jasper_customer_rate_plan.allows_sim_pooling AS customer_rate_plan_allows_sim_pooling,
    jasper_customer_rate_plan.plan_mb AS customer_rate_plan_mb,
    cross_provider_device_history.created_date,
    cross_provider_device_history.created_by,
    cross_provider_device_history.modified_by,
    cross_provider_device_history.modified_date,
    cross_provider_device_history.deleted_by,
    cross_provider_device_history.deleted_date,
    cross_provider_device_history.is_active,
    cross_provider_device_history.is_deleted,
    device_tenant.account_number,
    cross_provider_device_history.carrier_rate_plan_id,
    device_status.status AS status_code,
    device_status.display_name AS status_display_name,
    device_status.status_color,
    device_status.status_color_code,
    device_tenant.tenant_id,
    rev_customer.rev_customer_id,
    site.customer_name,
    rev_customer.rev_parent_customer_id,
    cross_provider_device_history.foundation_account_number,
    cross_provider_device_history.billing_account_number,
    cross_provider_device_history.username,
    customer_rate_pool.name AS customer_rate_pool_name
   FROM summed_data_usage
     JOIN cross_provider_device_history ON cross_provider_device_history.id = summed_data_usage.id
     JOIN device_usage ON (summed_data_usage.m2m_device_id IS NOT NULL AND summed_data_usage.m2m_device_id = device_usage.m2m_device_id OR summed_data_usage.mobility_device_id IS NOT NULL AND summed_data_usage.mobility_device_id = device_usage.mobility_device_id) AND summed_data_usage.last_date = device_usage.usage_date
     JOIN device_tenant ON cross_provider_device_history.tenant_id = device_tenant.id
     JOIN serviceprovider service_provider ON cross_provider_device_history.service_provider_id = service_provider.id
     LEFT JOIN customers site ON site.id = cross_provider_device_history.customer_id
     LEFT JOIN device_status ON device_status.id = device_usage.device_status_id
     LEFT JOIN revcustomer rev_customer ON site.rev_customer_id = rev_customer.id
     LEFT JOIN integration ON integration.id = service_provider.integration_id
     LEFT JOIN carrier_rate_plan jasper_carrier_rate_plan ON cross_provider_device_history.carrier_rate_plan_id = jasper_carrier_rate_plan.id
     LEFT JOIN customerrateplan jasper_customer_rate_plan ON cross_provider_device_history.customer_rate_plan_id = jasper_customer_rate_plan.id
     LEFT JOIN customer_rate_pool ON cross_provider_device_history.customer_rate_pool_id = customer_rate_pool.id
  WHERE cross_provider_device_history.is_active = true AND cross_provider_device_history.is_deleted = false AND integration.portal_type_id = 0;

CREATE OR REPLACE FUNCTION public.usp_get_customer_billing_period_by_siteid(siteid integer)
 RETURNS TABLE(id integer, bill_month integer, bill_year integer, customer_bill_period_end_day integer, customer_bill_period_end_hour integer)
 LANGUAGE plpgsql
AS $function$
DECLARE
    current_date TIMESTAMP := NOW();
BEGIN
    RETURN QUERY
    SELECT DISTINCT
        customer_billing_period.id,
        customer_billing_period.bill_month,
        customer_billing_period.bill_year,
        customers.customer_bill_period_end_day,
        customers.customer_bill_period_end_hour
    FROM customer_billing_period
    INNER JOIN customers
        ON customers.id = siteid
    WHERE
   TO_TIMESTAMP(
       customer_billing_period.bill_year || '-' ||
       LPAD(customer_billing_period.bill_month::TEXT, 2, '0') || '-' ||
       LPAD(
           LEAST(
               COALESCE(customers.customer_bill_period_end_day, 1),
               EXTRACT(DAY FROM (
                   DATE_TRUNC('month', TO_DATE(
                       customer_billing_period.bill_year || '-' || customer_billing_period.bill_month || '-01',
                       'YYYY-MM-DD'
                   )) + INTERVAL '1 MONTH - 1 day'
               ))
           )::TEXT,
           2, '0'
       ) || ' ' ||
       LPAD(COALESCE(customers.customer_bill_period_end_hour, 0)::TEXT, 2, '0') || ':00:00',
       'YYYY-MM-DD HH24:MI:SS'
   ) - INTERVAL '1 month' <= (CURRENT_TIMESTAMP - INTERVAL '5 hours')

    ORDER BY customer_billing_period.bill_year, customer_billing_period.bill_month;
END;
$function$
;


CREATE OR REPLACE VIEW public.customer_billing_periods
AS WITH billing_data AS (
         SELECT c.id AS customer_id,
            c.customer_name,
            bp.id AS billing_period_id,
            bp.bill_month,
            bp.bill_year,
            COALESCE(bp.customer_bill_period_end_day, 1) AS customer_bill_period_end_day,
            COALESCE(bp.customer_bill_period_end_hour, 0) AS customer_bill_period_end_hour,
            row_number() OVER (PARTITION BY c.id ORDER BY bp.id DESC) AS row_num
           FROM customers c
             JOIN LATERAL usp_get_customer_billing_period_by_siteid(c.id) bp(id, bill_month, bill_year, customer_bill_period_end_day, customer_bill_period_end_hour) ON true
          WHERE c.is_active = true
        )
 SELECT billing_data.customer_name,
    billing_data.billing_period_id,
    array_agg(concat(lpad(billing_data.bill_month::text, 2, '0'::text), '-', lpad(billing_data.customer_bill_period_end_day::text, 2, '0'::text), '-', billing_data.bill_year::text, ' ', lpad(billing_data.customer_bill_period_end_hour::text, 2, '0'::text), ':00:00')) AS billing_periods
   FROM billing_data
  WHERE billing_data.row_num = 1
  GROUP BY billing_data.customer_name, billing_data.billing_period_id
  ORDER BY billing_data.customer_name;

-- public.customer_billing_periods_dropdown source
CREATE OR REPLACE VIEW public.customer_billing_periods_dropdown
AS WITH billing_data AS (
         SELECT c.id AS customer_id,
            c.customer_name,
            bp.id AS billing_period_id,
            bp.bill_month,
            bp.bill_year,
            COALESCE(bp.customer_bill_period_end_day, 1) AS customer_bill_period_end_day,
            COALESCE(bp.customer_bill_period_end_hour, 0) AS customer_bill_period_end_hour,
            row_number() OVER (PARTITION BY c.id ORDER BY bp.id DESC) AS row_num
           FROM customers c
             LEFT JOIN LATERAL usp_get_customer_billing_period_by_siteid(c.id) bp(id, bill_month, bill_year, customer_bill_period_end_day, customer_bill_period_end_hour) ON true
          WHERE c.is_active = true AND bp.id IS NOT NULL
        )
 SELECT billing_data.customer_id,
    billing_data.customer_name,
    billing_data.billing_period_id,
    concat(lpad(billing_data.bill_month::text, 2, '0'::text), '-', lpad(billing_data.customer_bill_period_end_day::text, 2, '0'::text), '-', billing_data.bill_year::text, ' ', lpad(billing_data.customer_bill_period_end_hour::text, 2, '0'::text), ':00:00') AS billing_cycle_end_date
   FROM billing_data
  WHERE billing_data.row_num = 1
  ORDER BY billing_data.customer_name;

-- public.customer_rate_plan_report source

CREATE OR REPLACE VIEW public.customer_rate_plan_report
AS SELECT jc.rate_plan_name,
    jc.optimization_type,
    jc.service_provider_name,
    jc.rate_plan_code,
        CASE
            WHEN jc.base_rate = 0::numeric THEN '0'::text
            WHEN jc.base_rate < 0.0001 AND jc.base_rate > '-0.0001'::numeric THEN TRIM(TRAILING '0'::text FROM to_char(jc.base_rate, 'FM9999999999999999999999999999999999999999.00000000000000000000'::text))
            ELSE to_char(jc.base_rate, 'FM9999999999999999999999999999999999999999.00'::text)
        END AS base_rate,
        CASE
            WHEN jc.rate_charge_amt = 0::numeric THEN '0'::text
            WHEN jc.rate_charge_amt < 0.0001 AND jc.rate_charge_amt > '-0.0001'::numeric THEN TRIM(TRAILING '0'::text FROM to_char(jc.rate_charge_amt, 'FM9999999999999999999999999999999999999999.00000000000000000000'::text))
            ELSE to_char(jc.rate_charge_amt, 'FM9999999999999999999999999999999999999999.00'::text)
        END AS rate_charge,
        CASE
            WHEN jc.display_rate = 0::numeric THEN '0'::text
            WHEN jc.display_rate < 0.0001 AND jc.display_rate > '-0.0001'::numeric THEN TRIM(TRAILING '0'::text FROM to_char(jc.display_rate, 'FM9999999999999999999999999999999999999999.00000000000000000000'::text))
            ELSE to_char(jc.display_rate, 'FM9999999999999999999999999999999999999999.00'::text)
        END AS total_charge,
        CASE
            WHEN jc.plan_mb = 0::numeric THEN '0'::text
            WHEN jc.plan_mb < 0.0001 AND jc.plan_mb > '-0.0001'::numeric THEN TRIM(TRAILING '0'::text FROM to_char(jc.plan_mb, 'FM9999999999999999999999999999999999999999.00000000000000000000'::text))
            ELSE to_char(jc.plan_mb, 'FM9999999999999999999999999999999999999999.00'::text)
        END AS mb_included,
    TRIM(TRAILING '0'::text FROM TRIM(TRAILING '.'::text FROM to_char(jc.data_per_overage_charge, 'FM9999999999999999999999999999999999999999.00000000000000000000'::text))) AS data_per_overage_charge,
        CASE
            WHEN jc.overage_rate_cost = 0::numeric THEN '0'::text
            WHEN jc.overage_rate_cost < 0.0001 AND jc.overage_rate_cost > '-0.0001'::numeric THEN TRIM(TRAILING '0'::text FROM to_char(jc.overage_rate_cost, 'FM9999999999999999999999999999999999999999.00000000000000000000'::text))
            ELSE to_char(jc.overage_rate_cost, 'FM9999999999999999999999999999999999999999.00'::text)
        END AS overage_rate_cost,
        CASE
            WHEN jc.min_plan_data_mb = 0::numeric THEN '0'::text
            WHEN jc.min_plan_data_mb < 0.0001 AND jc.min_plan_data_mb > '-0.0001'::numeric THEN TRIM(TRAILING '0'::text FROM to_char(jc.min_plan_data_mb, 'FM9999999999999999999999999999999999999999.00000000000000000000'::text))
            ELSE to_char(jc.min_plan_data_mb, 'FM9999999999999999999999999999999999999999.00'::text)
        END AS min_plan_mb,
        CASE
            WHEN jc.max_plan_data_mb = 0::numeric THEN '0'::text
            WHEN jc.max_plan_data_mb < 0.0001 AND jc.max_plan_data_mb > '-0.0001'::numeric THEN TRIM(TRAILING '0'::text FROM to_char(jc.max_plan_data_mb, 'FM9999999999999999999999999999999999999999.00000000000000000000'::text))
            ELSE to_char(jc.max_plan_data_mb, 'FM9999999999999999999999999999999999999999.00'::text)
        END AS max_plan_mb,
        CASE
            WHEN jc.allows_sim_pooling THEN 'True'::text
            ELSE 'False'::text
        END AS allows_sim_pooling,
        CASE
            WHEN jc.is_billing_advance_eligible THEN 'True'::text
            ELSE 'False'::text
        END AS uses_bill_in_advance,
        CASE
            WHEN jc.sms_rate = 0::numeric THEN '0'::text
            WHEN jc.sms_rate < 0.0001 AND jc.sms_rate > '-0.0001'::numeric THEN TRIM(TRAILING '0'::text FROM to_char(jc.sms_rate, 'FM9999999999999999999999999999999999999999.00000000000000000000'::text))
            ELSE to_char(jc.sms_rate, 'FM9999999999999999999999999999999999999999.00'::text)
        END AS sms_rate,
    jc.automation_rule,
    jc.soc_code,
    jc.modified_by AS last_modified_by,
    to_char(jc.modified_date, 'MM-DD-YYYY HH24:MI:SS'::text) AS last_modified_datetime,
        CASE
            WHEN jc.is_active THEN 'True'::text
            ELSE 'False'::text
        END AS status,
        CASE
            WHEN jc.automation_rule_flag THEN 'True'::text
            ELSE 'False'::text
        END AS automation,
    jc.tenant_id,
    jc.modified_date,
    jc.id
   FROM customerrateplan jc
     JOIN serviceprovider s ON s.id = jc.service_provider_id
  WHERE jc.service_provider_id IS NOT NULL AND s.is_active = true AND s.is_deleted = false AND jc.is_active = true AND jc.is_deleted = false AND s.integration_id IS NOT NULL;


-- public.provider_usage_by_line_report_for_customer_billing_dates source
CREATE OR REPLACE VIEW public.provider_usage_by_line_report_for_customer_billing_dates
AS WITH billing_data AS (
         SELECT c.id AS customer_id,
            c.customer_name,
            bp.id AS billing_period_id,
            bp.bill_month,
            bp.bill_year,
            COALESCE(bp.customer_bill_period_end_day, 1) AS customer_bill_period_end_day,
            COALESCE(bp.customer_bill_period_end_hour, 0) AS customer_bill_period_end_hour
           FROM customers c
             JOIN LATERAL usp_get_customer_billing_period_by_siteid(c.id) bp(id, bill_month, bill_year, customer_bill_period_end_day, customer_bill_period_end_hour) ON true
          WHERE c.is_active = true
        )
 SELECT billing_data.customer_id,
    billing_data.customer_name,
    billing_data.billing_period_id,
    to_timestamp(concat(lpad(billing_data.bill_month::text, 2, '0'::text), '-', lpad(billing_data.customer_bill_period_end_day::text, 2, '0'::text), '-', billing_data.bill_year, ' ', lpad(billing_data.customer_bill_period_end_hour::text, 2, '0'::text), ':00:00'), 'MM-DD-YYYY HH24:MI:SS'::text) AS billing_cycle_end_date,
    array_to_string(array_remove(ARRAY[billing_data.customer_id, billing_data.billing_period_id], NULL::integer), '-'::text) AS id
   FROM billing_data
  ORDER BY billing_data.customer_name, (to_timestamp(concat(lpad(billing_data.bill_month::text, 2, '0'::text), '-', lpad(billing_data.customer_bill_period_end_day::text, 2, '0'::text), '-', billing_data.bill_year, ' ', lpad(billing_data.customer_bill_period_end_hour::text, 2, '0'::text), ':00:00'), 'MM-DD-YYYY HH24:MI:SS'::text));

-- public.sim_management_bulk_change_view source

CREATE OR REPLACE VIEW public.sim_management_bulk_change_view
AS SELECT array_to_string(array_remove(ARRAY[smbcg.id, smbc.id], NULL::integer::bigint), '-'::text) AS id,
    smbcg.id AS bulk_change_id,
    smbcg.service_provider_id,
    smbcg.service_provider,
    smbcg.change_request_type_id,
    smbcg.change_request_type,
    smbcg.status,
    smbcg.uploaded,
    smbcg.customer_id,
    smbcg.processed_date,
    smbcg.processed_by,
    smbcg.created_by,
    smbcg.created_date,
    smbcg.modified_by,
    smbcg.modified_date,
    smbcg.deleted_by,
    smbcg.deleted_date,
    smbcg.is_deleted,
    smbcg.is_active,
    smbcg.errors,
    smbcg.success,
    smbc.iccid,
    smbc.msisdn,
    smbc.subscriber_number,
    smbc.ip_address,
    smbc.change_request,
    smbc.device_id,
    smbc.sim_management_inventory_id,
    smbc.is_processed,
    smbc.has_errors,
    smbcg.progress,
    smbcg.tenant_id
   FROM sim_management_bulk_change smbcg
     JOIN sim_management_bulk_change_request smbc ON smbc.bulk_change_id = smbcg.id;

-- public.tel_feature_updates source

CREATE OR REPLACE VIEW public.tel_feature_updates
AS SELECT md.msisdn,
    ( SELECT string_agg(mf.soc_code::text, ','::text) AS string_agg
           FROM telegence_device_mobility_feature tdmf
             JOIN mobility_feature mf ON mf.id = tdmf.mobility_feature_id
          WHERE td.id IS NOT NULL AND tdmf.is_active = true AND tdmf.telegence_device_id = td.id AND mf.is_active = true AND mf.is_retired = false) AS telegence_feature,
    ( SELECT string_agg(mf.soc_code::text, ','::text) AS string_agg
           FROM e_bonding_device_mobility_feature ebdmf
             JOIN mobility_feature mf ON mf.id = ebdmf.mobility_feature_id
          WHERE e_bonding_device.id IS NOT NULL AND ebdmf.is_active = true AND ebdmf.e_bonding_device_id = e_bonding_device.id AND mf.is_active = true AND mf.is_retired = false) AS e_bonding_feature
   FROM mobility_device md
     LEFT JOIN telegence_device td ON td.subscriber_number::text = md.msisdn::text AND td.service_provider_id = md.service_provider_id
     LEFT JOIN e_bonding_device ON e_bonding_device.subscriber_number::text = md.msisdn::text AND e_bonding_device.service_provider_id = md.service_provider_id
  WHERE md.is_active = true AND md.is_deleted = false;

-- public.usage_by_line_report_stored_proc_cross_prov_search source

CREATE OR REPLACE VIEW public.usage_by_line_report_stored_proc_cross_prov_search
AS SELECT smih.billing_cycle_end_date,
    smih.service_provider_id,
    sp.display_name AS service_provider_display_name,
    smih.iccid,
    smih.msisdn,
    smih.imei,
    smih.rate_plan AS carrier_rate_plan,
    smih.carrier_cycle_usage,
    smih.provider_date_added AS date_added,
    smih.provider_date_activated AS date_activated,
    smih.created_date,
    smih.created_by,
    smih.modified_by,
    smih.modified_date,
    smih.deleted_by,
    smih.deleted_date,
    smih.is_active,
    smih.is_deleted,
    smih.carrier_rate_plan_id,
    smih.status AS status_code,
    smih.id AS device_history_id,
    smih.is_pushed,
    smih.last_activated_date,
    smi.customer_rate_plan_code,
    smi.customer_rate_plan_name,
    smi.customer_rate_plan_mb,
    smi.account_number,
    smi.sim_status AS status_display_name,
    smi.tenant_id,
    smi.rev_customer_id,
    smi.customer_name,
    smi.rev_parent_customer_id,
    smi.customer_rate_pool_name,
    smi.customer_rate_plan_allows_sim_pooling,
    smi.customer_data_allocation_mb,
    smi.foundation_account_number,
    smi.service_zip_code,
    smi.rate_plan_soc,
    smi.data_group_id,
    smi.pool_id,
    smi.device_make,
    smi.device_model,
    smi.contract_status,
    smi.ban_status,
    smi.plan_limit_mb,
    smi.username,
    smi.ctd_voice_usage AS minutes_used,
    smi.ip_address,
    smi.billing_account_number,
    smi.integration_id,
        CASE
            WHEN smi.id = 12 THEN round(COALESCE(smih.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(smih.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS data_usage_mb,
    array_to_string(array_remove(ARRAY[smih.id::bigint, smi.id::bigint], NULL::integer::bigint), '-'::text) AS id
   FROM cross_provider_device_history smih
     LEFT JOIN customer_billing_period bp ON smih.customer_billing_period_id = bp.id
     JOIN serviceprovider sp ON sp.id = smih.service_provider_id
     JOIN sim_management_inventory smi ON smih.iccid::text = smi.iccid::text
  WHERE smih.is_active = true AND smih.is_deleted = false AND smi.is_active_status = true AND (smih.last_activated_date < smi.billing_cycle_end_date AND smih.last_activated_date > smi.billing_cycle_start_date OR smih.carrier_cycle_usage >= 0);

CREATE OR REPLACE VIEW public.usage_by_line_report_stored_proc_search
AS WITH history_data AS (
         WITH mobility_bill_periods AS (
                 SELECT billing_period_1.id
                   FROM billing_period billing_period_1
                  WHERE billing_period_1.is_active = true AND billing_period_1.is_deleted = false AND billing_period_1.service_provider_id = 6
                ), m2m_bill_periods AS (
                 SELECT billing_period_1.id
                   FROM billing_period billing_period_1
                  WHERE billing_period_1.is_active = true AND billing_period_1.is_deleted = false AND billing_period_1.service_provider_id <> 6
                )
         SELECT mobility_device_history.device_history_id,
            mobility_device_history.service_provider_id,
            mobility_device_history.iccid,
            mobility_device_history.msisdn,
            mobility_device_history.imei,
            mobility_device_history.rate_plan AS carrier_rate_plan,
            mobility_device_history.carrier_cycle_usage,
            mobility_device_history.provider_date_added AS date_added,
            mobility_device_history.provider_date_activated AS date_activated,
            mobility_device_history.created_date,
            mobility_device_history.created_by,
            mobility_device_history.modified_by,
            COALESCE(mobility_device_history.modified_date, mobility_device_history.created_date) AS modified_date,
            mobility_device_history.deleted_by,
            mobility_device_history.deleted_date,
            mobility_device_history.is_active,
            mobility_device_history.is_deleted,
            mobility_device_history.account_number,
            mobility_device_history.carrier_rate_plan_id,
            mobility_device_history.status AS status_code,
            mobility_device_history.foundation_account_number,
            mobility_device_history.billing_account_number,
            mobility_device_history.service_zip_code,
            mobility_device_history.single_user_code AS rate_plan_soc,
            mobility_device_history.single_user_code_description AS rate_plan_soc_description,
            mobility_device_history.data_group_id,
            mobility_device_history.pool_id,
            mobility_device_history.device_make,
            mobility_device_history.device_model,
            mobility_device_history.contract_status,
            mobility_device_history.ban_status,
            mobility_device_history.imei_type_id,
            mobility_device_history.plan_limit_mb,
            mobility_device_history.username,
            COALESCE(mobility_device_history.ctd_sms_usage, 0::bigint) AS sms_usage,
            mobility_device_history.ctd_voice_usage AS minutes_used,
            mobility_device_history.ip_address,
            mobility_device_history.is_pushed,
            mobility_device_tenant.tenant_id,
            mobility_device_history.customer_id,
            mobility_device_history.device_status_id,
            mobility_device_history.billing_period_id,
            mobility_device_history.customer_rate_plan_id,
            mobility_device_history.customer_rate_pool_id,
            mobility_device_tenant.id AS dev_tenant_id
           FROM mobility_device_history
             LEFT JOIN mobility_device_tenant ON mobility_device_history.id = mobility_device_tenant.mobility_device_id AND mobility_device_history.mobility_device_tenant_id = mobility_device_tenant.id
          WHERE mobility_device_history.is_active = true AND mobility_device_history.is_deleted = false AND (mobility_device_history.billing_period_id IN ( SELECT mobility_bill_periods.id
                   FROM mobility_bill_periods))
        UNION ALL
         SELECT device_history.device_history_id,
            device_history.service_provider_id,
            device_history.iccid,
            device_history.msisdn,
            device_history.imei,
            device_history.rate_plan AS carrier_rate_plan,
            device_history.carrier_cycle_usage,
            device_history.provider_date_added AS date_added,
            device_history.provider_date_activated AS date_activated,
            device_history.created_date,
            device_history.created_by,
            device_history.modified_by,
            COALESCE(device_history.modified_date, device_history.created_date) AS modified_date,
            device_history.deleted_by,
            device_history.deleted_date,
            device_history.is_active,
            device_history.is_deleted,
            device_tenant.account_number,
            device_history.carrier_rate_plan_id,
            device_history.status AS status_code,
            NULL::character varying AS foundation_account_number,
            NULL::character varying AS billing_account_number,
            NULL::character varying AS service_zip_code,
            NULL::character varying AS rate_plan_soc,
            NULL::character varying AS rate_plan_soc_description,
            NULL::character varying AS data_group_id,
            NULL::character varying AS pool_id,
            NULL::character varying AS device_make,
            NULL::character varying AS device_model,
            NULL::character varying AS contract_status,
            NULL::character varying AS ban_status,
            NULL::integer AS imei_type_id,
            NULL::numeric AS plan_limit_mb,
            device_history.username,
            COALESCE(device_history.ctd_sms_usage, 0::bigint) AS sms_usage,
            device_history.ctd_voice_usage AS minutes_used,
            NULL::character varying AS ip_address,
            device_history.is_pushed,
            device_tenant.tenant_id,
            device_tenant.customer_id,
            device_history.device_status_id,
            device_history.billing_period_id,
            device_history.customer_rate_plan_id,
            device_history.customer_rate_pool_id,
            device_tenant.id AS dev_tenant_id
           FROM device_history
             JOIN device_tenant ON device_history.device_tenant_id = device_tenant.id
          WHERE device_history.is_active = true AND device_history.is_deleted = false AND (device_history.billing_period_id IN ( SELECT m2m_bill_periods.id
                   FROM m2m_bill_periods))
        )
 SELECT history_data.device_history_id,
    billing_period.billing_cycle_end_date,
    history_data.service_provider_id,
    serviceprovider.display_name AS service_provider_display_name,
    serviceprovider.integration_id,
    history_data.iccid,
    history_data.msisdn,
    history_data.imei,
    history_data.carrier_rate_plan,
    history_data.carrier_cycle_usage,
        CASE
            WHEN integration.id = 12 THEN round(COALESCE(history_data.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(history_data.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS data_usage_mb,
    history_data.date_added,
    history_data.date_activated,
    customerrateplan.rate_plan_code,
    customerrateplan.rate_plan_name,
    customerrateplan.allows_sim_pooling AS customer_rate_plan_allows_sim_pooling,
    customerrateplan.plan_mb,
    history_data.created_date,
    history_data.created_by,
    history_data.modified_by,
    history_data.modified_date,
    history_data.deleted_by,
    history_data.deleted_date,
    history_data.is_active,
    history_data.is_deleted,
    history_data.account_number,
    history_data.carrier_rate_plan_id,
    history_data.status_code,
    device_status.display_name AS status_display_name,
    device_status.status_color,
    device_status.status_color_code,
    history_data.tenant_id,
    revcustomer.rev_customer_id,
    COALESCE(revcustomer.customer_name, customers.customer_name) AS customer_name,
    revcustomer.rev_parent_customer_id,
    history_data.foundation_account_number,
    history_data.billing_account_number,
    history_data.service_zip_code,
    history_data.rate_plan_soc,
    history_data.rate_plan_soc_description,
    history_data.data_group_id,
    history_data.pool_id,
    history_data.device_make,
    history_data.device_model,
    history_data.contract_status,
    history_data.ban_status,
    history_data.imei_type_id,
    history_data.plan_limit_mb,
    history_data.username,
    history_data.sms_usage,
    history_data.minutes_used,
    history_data.ip_address,
    customer_rate_pool.name AS customer_rate_pool_name,
    history_data.is_pushed,
    customerrateplan.plan_mb AS customer_data_allocation_mb,
    billing_period.id AS billing_period_id,
    array_to_string(array_remove(ARRAY[history_data.device_history_id, history_data.dev_tenant_id::bigint, serviceprovider.id::bigint], NULL::integer::bigint), '-'::text) AS id
   FROM history_data
     JOIN serviceprovider ON history_data.service_provider_id = serviceprovider.id
     LEFT JOIN customers ON customers.id = history_data.customer_id
     LEFT JOIN device_status ON device_status.id = history_data.device_status_id
     LEFT JOIN revcustomer ON revcustomer.id = customers.rev_customer_id
     LEFT JOIN billing_period ON history_data.billing_period_id = billing_period.id
     LEFT JOIN integration ON integration.id = serviceprovider.integration_id
     LEFT JOIN customerrateplan ON history_data.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customer_rate_pool ON history_data.customer_rate_pool_id = customer_rate_pool.id;

-- public.usp_optimization_customer_charges_count_for_cross_optimization source

CREATE OR REPLACE VIEW public.usp_optimization_customer_charges_count_for_cross_optimization
AS SELECT customer_charges_count.instance_id,
    sum(customer_charges_count.charge_count) AS chargecount,
    sum(customer_charges_count.overage_charge_amount) AS overagechargeamount,
    sum(customer_charges_count.total_charge_amount) AS totalchargeamount,
    sum(customer_charges_count.unassigned_device_count) AS unassigneddevicecount,
    sum(customer_charges_count.sms_charge_total) AS smschargetotal,
    row_number() OVER (ORDER BY customer_charges_count.instance_id) AS id
   FROM ( SELECT oq.instance_id,
            sum(
                CASE
                    WHEN jcust_rp.id IS NOT NULL THEN 1
                    ELSE 0
                END) AS charge_count,
            sum(COALESCE(odr.charge_amt::numeric, 0.0) - COALESCE(jcust_rp.base_rate::numeric, 0.0)) AS overage_charge_amount,
            sum(COALESCE(odr.charge_amt::numeric, 0.0)) AS total_charge_amount,
            sum(
                CASE
                    WHEN jcust_rp.id IS NULL THEN 1
                    ELSE 0
                END) AS unassigned_device_count,
            sum(COALESCE(odr.sms_charge_amount::numeric, 0.0)) AS sms_charge_total
           FROM optimization_smi_result odr
             JOIN optimization_queue oq ON odr.queue_id = oq.id
             JOIN optimization_instance oi ON oq.instance_id = oi.id
             JOIN sim_management_inventory smi ON odr.sim_management_inventory_id = smi.id
             LEFT JOIN customerrateplan jcust_rp ON odr.assigned_customer_rate_plan_id = jcust_rp.id
          GROUP BY oq.instance_id) customer_charges_count
  GROUP BY customer_charges_count.instance_id;

CREATE OR REPLACE FUNCTION public.get_billing_cycle_date_for_customer(p_customer_id integer DEFAULT NULL::integer, p_tenant_id integer DEFAULT NULL::integer)
 RETURNS timestamp without time zone
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_cycle_date TIMESTAMP;
    v_customer_id INT;
BEGIN
    -- Log input parameters
    RAISE NOTICE 'Input - Customer ID: %, Tenant ID: %', p_customer_id, p_tenant_id;

    -- If customer_id is null, fetch the 'Unassigned' customer's ID
    IF p_customer_id IS NULL THEN
        RAISE NOTICE 'Customer ID is null, attempting to fetch ''Unassigned'' customer ID for tenant %', p_tenant_id;

        SELECT id INTO v_customer_id
        FROM customers
        WHERE customer_name ILIKE 'Unassigned'
          AND tenant_id = p_tenant_id
          AND is_active = true
          AND is_deleted = false
        LIMIT 1;

        RAISE NOTICE 'Fetched Unassigned Customer ID: %', v_customer_id;
    ELSE
        v_customer_id := p_customer_id;
        RAISE NOTICE 'Using provided Customer ID: %', v_customer_id;
    END IF;

    -- Get billing cycle date
    RAISE NOTICE 'Attempting to fetch billing cycle date for Customer ID: %', v_customer_id;

    SELECT
	  to_timestamp(((((((cbp.bill_year || '-'::text) || lpad(cbp.bill_month::text, 2, '0'::text)) || '-'::text) || lpad(LEAST(COALESCE(c.customer_bill_period_end_day, 1)::numeric, EXTRACT(day FROM date_trunc('month'::text, to_date(((cbp.bill_year || '-'::text) || cbp.bill_month) || '-01'::text, 'YYYY-MM-DD'::text)::timestamp with time zone) + '1 mon -1 days'::interval))::text, 2, '0'::text)) || ' '::text) || lpad(COALESCE(c.customer_bill_period_end_hour, 0)::text, 2, '0'::text)) || ':00:00'::text, 'YYYY-MM-DD HH24:MI:SS'::text) AS billing_end_date
    INTO v_cycle_date
    FROM customer_billing_period cbp
    JOIN customers c
        ON c.id = v_customer_id
        AND c.is_active = true AND c.is_deleted = false
    JOIN (
        SELECT MAX(id) AS last_id
FROM customer_billing_period
WHERE bill_month = EXTRACT(MONTH FROM CURRENT_DATE)

    ) latest_cbp
        ON cbp.id = latest_cbp.last_id;

    RAISE NOTICE 'Billing cycle date: %', v_cycle_date;

    RETURN v_cycle_date;
END;
$function$
;

-- public.usp_report_customer_usage_by_line source

CREATE OR REPLACE VIEW public.usp_report_customer_usage_by_line
AS SELECT combined.id,
    combined.device_id,
    combined.billing_cycle_start_date,
    combined.billing_cycle_end_date,
    combined.service_provider_id,
    combined.service_provider_name AS service_provider_display_name,
    combined.integration_id,
    combined.iccid,
    combined.msisdn,
    combined.imei,
    combined.carrier_rate_plan,
    combined.data_usage_mb,
    combined.date_added,
    combined.date_activated,
    combined.rate_plan_code,
    combined.rate_plan_name,
    combined.allows_sim_pooling,
    combined.plan_mb,
    combined.created_date,
    combined.created_by,
    combined.modified_by,
    combined.modified_date,
    combined.deleted_by,
    combined.deleted_date,
    combined.is_active,
    combined.is_deleted,
    combined.account_number,
    combined.carrier_rate_plan_id,
    combined.status_code,
    combined.status_display_name,
    combined.status_color_code,
    combined.customer_id,
    combined.tenant_id,
    combined.rev_customer_id,
    combined.customer_name,
    combined.sms_usage,
    combined.customer_rate_pool_name,
    combined.foundation_account_number,
    combined.billing_account_number,
    combined.service_zip_code,
    combined.single_user_code,
    combined.single_user_code_description,
    combined.device_make,
    combined.device_model,
    combined.imei_type_id,
    combined.plan_limit_mb,
    combined.username,
    combined.ctd_voice_usage,
    combined.ip_address,
    combined.customer_cycle_end_date
   FROM ( SELECT d.id AS device_id,
            bp.billing_cycle_start_date,
            bp.billing_cycle_end_date,
            d.service_provider_id,
            s.display_name AS service_provider_name,
            s.integration_id,
            d.iccid,
            d.msisdn,
            d.imei,
            d.carrier_rate_plan,
                CASE
                    WHEN i.id = 12 THEN round(COALESCE(d.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
                    ELSE round(COALESCE(d.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
                END AS data_usage_mb,
            d.date_added,
            d.date_activated,
            crp.rate_plan_code,
            crp.rate_plan_name,
            crp.allows_sim_pooling,
            crp.plan_mb,
            d.created_date,
            d.created_by,
            d.modified_by,
            d.modified_date,
            d.deleted_by,
            d.deleted_date,
            d.is_active,
            d.is_deleted,
            dt.account_number,
            d.carrier_rate_plan_id,
            d.sim_status AS status_code,
            ds.display_name AS status_display_name,
            ds.status_color_code,
            c.id AS customer_id,
            dt.tenant_id,
            rc.rev_customer_id,
            c.customer_name,
            COALESCE(d.ctd_sms_usage, 0::bigint) AS sms_usage,
            crp2.name AS customer_rate_pool_name,
            NULL::character varying AS foundation_account_number,
            NULL::character varying AS billing_account_number,
            NULL::character varying AS service_zip_code,
            NULL::character varying AS single_user_code,
            NULL::character varying AS single_user_code_description,
            NULL::character varying AS device_make,
            NULL::character varying AS device_model,
            NULL::integer AS imei_type_id,
            NULL::numeric AS plan_limit_mb,
            d.username,
            d.ctd_voice_usage,
            d.ip_address,
            array_to_string(array_remove(ARRAY[d.id, dt.id, s.id, c.id, ds.id, crp.id, crp2.id], NULL::integer), '-'::text) AS id,
            cycle.cycle_end_date AS customer_cycle_end_date
           FROM device d
             JOIN device_tenant dt ON d.id = dt.device_id
             JOIN serviceprovider s ON d.service_provider_id = s.id
             LEFT JOIN customers c ON c.id = dt.customer_id
             LEFT JOIN device_status ds ON d.device_status_id = ds.id
             LEFT JOIN revcustomer rc ON c.rev_customer_id = rc.id
             LEFT JOIN integration i ON i.id = s.integration_id
             LEFT JOIN customerrateplan crp ON crp.id = dt.customer_rate_plan_id
             LEFT JOIN customer_rate_pool crp2 ON dt.customer_rate_pool_id = crp2.id
             LEFT JOIN billing_period bp ON d.billing_period_id = bp.id
             CROSS JOIN LATERAL ( SELECT get_billing_cycle_date_for_customer(dt.customer_id, dt.tenant_id) AS cycle_end_date) cycle
          WHERE d.is_active = true AND d.is_deleted = false AND i.portal_type_id = 0 AND bp.id = (( SELECT billing_period.id
                   FROM billing_period
                  WHERE d.service_provider_id = billing_period.service_provider_id AND bp.is_active = true AND bp.is_deleted = false
                  ORDER BY billing_period.id DESC
                 LIMIT 1)) AND (ds.is_active_status = true OR d.last_activated_date < bp.billing_cycle_end_date AND d.last_activated_date > bp.billing_cycle_start_date OR d.carrier_cycle_usage > 0)
        UNION ALL
         SELECT md.id AS device_id,
            bp.billing_cycle_start_date,
            bp.billing_cycle_end_date,
            md.service_provider_id,
            s.display_name AS service_provider_name,
            s.integration_id,
            md.iccid,
            md.msisdn,
            md.imei,
            md.carrier_rate_plan,
                CASE
                    WHEN i.id = 12 THEN round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
                    ELSE round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
                END AS data_usage_mb,
            md.date_added,
            md.date_activated,
            crp.rate_plan_code,
            crp.rate_plan_name,
            crp.allows_sim_pooling,
            crp.plan_mb,
            md.created_date,
            md.created_by,
            md.modified_by,
            md.modified_date,
            md.deleted_by,
            md.deleted_date,
            md.is_active,
            md.is_deleted,
            mdt.account_number,
            md.carrier_rate_plan_id,
            md.sim_status AS status_code,
            ds.display_name AS status_display_name,
            ds.status_color_code,
            c.id AS customer_id,
            mdt.tenant_id,
            rc.rev_customer_id,
            c.customer_name,
            COALESCE(md.ctd_sms_usage, 0::bigint) AS sms_usage,
            crp2.name AS customer_rate_pool_name,
            md.foundation_account_number,
            md.billing_account_number,
            md.service_zip_code,
            md.single_user_code,
            md.single_user_code_description,
            md.device_make,
            md.device_model,
            md.imei_type_id,
            md.plan_limit_mb,
            COALESCE(md.amop_username, md.username) AS username,
            md.ctd_voice_usage,
            md.ip_address,
            array_to_string(array_remove(ARRAY[md.id, mdt.id, s.id, c.id, ds.id, crp.id, crp2.id], NULL::integer), '-'::text) AS id,
            cycle.cycle_end_date AS customer_cycle_end_date
           FROM mobility_device md
             JOIN mobility_device_tenant mdt ON mdt.mobility_device_id = md.id
             JOIN serviceprovider s ON s.id = md.service_provider_id
             LEFT JOIN customers c ON c.id = mdt.customer_id
             LEFT JOIN device_status ds ON md.device_status_id = ds.id
             LEFT JOIN revcustomer rc ON c.rev_customer_id = rc.id
             LEFT JOIN integration i ON i.id = s.integration_id
             LEFT JOIN customerrateplan crp ON crp.id = mdt.customer_rate_plan_id
             LEFT JOIN customer_rate_pool crp2 ON mdt.customer_rate_pool_id = crp2.id
             LEFT JOIN billing_period bp ON md.billing_period_id = bp.id
             CROSS JOIN LATERAL ( SELECT get_billing_cycle_date_for_customer(mdt.customer_id, mdt.tenant_id) AS cycle_end_date) cycle
          WHERE md.is_active = true AND md.is_deleted = false AND i.portal_type_id = 2 AND bp.id = (( SELECT billing_period.id
                   FROM billing_period
                  WHERE md.service_provider_id = billing_period.service_provider_id AND bp.is_active = true AND bp.is_deleted = false
                  ORDER BY billing_period.id DESC
                 LIMIT 1)) AND (ds.is_active_status = true OR md.last_activated_date < bp.billing_cycle_end_date AND md.last_activated_date > bp.billing_cycle_start_date OR md.carrier_cycle_usage > 0)) combined;

-- public.vw_automation_rule_log_list_view source

CREATE OR REPLACE VIEW public.vw_automation_rule_log_list_view
AS SELECT autorule.automation_rule_name,
    autorule.service_provider_id,
    serviceprovider.display_name AS service_provider_display_name,
    array_to_string(array_remove(ARRAY[rulelog.id, autorule.id, serviceprovider.id, td.id], NULL::integer), '-'::text) AS id,
    rulelog.status,
    rulelog.device_updated AS sim,
    td.subscriber_number,
    rulelog.description,
    rulelog.request_body,
    rulelog.response_body,
    rulelog.instance_id,
    rulelog.created_date,
    rulelog.created_by,
    row_number() OVER (PARTITION BY rulelog.instance_id ORDER BY rulelog.created_date) AS step_order,
    rulelog.modified_date
   FROM automation_rule autorule
     JOIN automation_rule_log rulelog ON autorule.id = rulelog.automation_rule_id
     JOIN serviceprovider serviceprovider ON serviceprovider.id = autorule.service_provider_id
     JOIN telegence_device td ON td.iccid::text = rulelog.device_updated;

CREATE OR REPLACE VIEW public.vw_combined_device_inventory_export
AS SELECT combined_data.id,
    combined_data.service_provider_id,
    combined_data.service_provider_display_name,
    combined_data.integration_id,
    combined_data.iccid,
    combined_data.msisdn,
    combined_data.imei,
    combined_data.carrier_rate_plan_name,
    combined_data.carrier_rate_plan_display_rate,
    combined_data.carrier_cycle_usage_bytes,
    combined_data.carrier_cycle_usage_mb,
    combined_data.date_added,
    combined_data.date_activated,
    combined_data.created_date,
    combined_data.created_by,
    combined_data.modified_by,
    combined_data.modified_date,
    combined_data.deleted_by,
    combined_data.deleted_date,
    combined_data.is_active,
    combined_data.account_number,
    combined_data.carrier_rate_plan_id,
    combined_data.cost_center,
    combined_data.sim_status AS status_code,
    combined_data.sim_status,
    device_status.status_color,
    device_status.status_color_code,
    combined_data.tenant_id,
    serviceprovider.tenant_id AS service_provider_tenant_id,
    combined_data.rev_customer_id,
    combined_data.rev_customer_name,
    combined_data.rev_parent_customer_id,
    combined_data.foundation_account_number,
    combined_data.billing_account_number,
    combined_data.service_zip_code,
    combined_data.rate_plan_soc,
    combined_data.rate_plan_soc_description,
    combined_data.data_group_id,
    combined_data.pool_id,
    combined_data.next_bill_cycle_date,
    combined_data.device_make,
    combined_data.device_model,
    combined_data.contract_status,
    combined_data.ban_status,
    combined_data.sms_count,
    combined_data.minutes_used,
    combined_data.imei_type_id,
    combined_data.plan_limit_mb,
    combined_data.customer_id,
    combined_data.parent_customer_id,
    combined_data.customer_name,
    combined_data.customer_rate_plan_code,
    combined_data.customer_rate_plan_name,
    combined_data.display_rate AS customer_rate_plan_display_rate,
    combined_data.customer_data_allocation_mb,
    combined_data.username,
    combined_data.customer_rate_pool_id,
    combined_data.customer_rate_pool_name,
    combined_data.billing_cycle_start_date,
    combined_data.billing_cycle_end_date,
    combined_data.is_active_status,
    combined_data.customer_rate_plan_mb,
    combined_data.telegence_features AS telegence_feature,
    combined_data.ebonding_features,
    combined_data.ip_address,
    combined_data.customer_cycle_usage_mb,
    combined_data.eid,
    combined_data.communication_plan,
    combined_data.billing_period_id,
    combined_data.carrier_rate_plan_mb,
    combined_data.dt_id,
    combined_data.mdt_id
   FROM sim_management_inventory combined_data
     JOIN serviceprovider ON combined_data.service_provider_id = serviceprovider.id
     LEFT JOIN device_status ON device_status.id = combined_data.device_status_id
  WHERE combined_data.is_active = true;






-- public.rule_rule_definiton_view source

CREATE OR REPLACE VIEW public.rule_rule_definiton_view
AS SELECT row_number() OVER (ORDER BY rule_rule_definition.created_date) AS id,
    rule_rule_definition.id AS asrule_rule_definition_id,
    rule_rule_definition.object_type_id,
    rule_rule_definition.rule_id,
    rule_rule_definition.name,
    rule_rule_definition.priority,
    rule_rule_definition.subject_line,
    rule_rule_definition.display_message,
    rule_rule_definition.notes,
    rule_rule_definition.order_of_execution,
    rule_rule_definition.created_date,
    rule_rule_definition.created_by,
    rule_rule_definition.modified_date,
    rule_rule_definition.modified_by,
    rule_rule_definition.deleted_date,
    rule_rule_definition.deleted_by,
    rule_rule_definition.is_deleted,
    rule_rule_definition.is_active,
    rule_rule_definition.send_to_carrier,
    rule_rule_definition.send_to_customer,
    rule_rule_definition.should_show_projected_usage_cost,
    rule_rule_definition.version_no,
    rule_rule_definition.version_update_purpose,
    rule_rule_definition.rule_id_1_0,
    rule_rule_definition.rule_def_id,
    rule_rule_definition.service_provider,
    rule_rule_definition.customers_list,
    rule_rule_definition.expression_ids,
    rule_rule_definition.expression_names
   FROM rule_rule_definition;



CREATE OR REPLACE FUNCTION public.get_current_customer_billing_period(
    customer_bill_period_end_day integer, customer_bill_period_end_hour integer)
 RETURNS TABLE(start_date timestamp without time zone, end_date timestamp without time zone)
 LANGUAGE plpgsql
AS $function$
BEGIN
    RETURN QUERY
    SELECT
        CASE
            WHEN customer_bill_period_end_day >= EXTRACT(DAY FROM NOW())
            THEN make_timestamp(
                EXTRACT(YEAR FROM NOW())::INTEGER,
                EXTRACT(MONTH FROM NOW())::INTEGER,
                customer_bill_period_end_day,
                customer_bill_period_end_hour,
                0,
                0
            )
            WHEN customer_bill_period_end_day < EXTRACT(DAY FROM NOW())
            THEN make_timestamp(
                EXTRACT(YEAR FROM NOW())::INTEGER,
                EXTRACT(MONTH FROM NOW())::INTEGER ,
                customer_bill_period_end_day,
                customer_bill_period_end_hour,
                0,
                0
            )
        END AS end_date,
        CASE
            WHEN customer_bill_period_end_day >= EXTRACT(DAY FROM NOW())
            THEN (make_timestamp(
                EXTRACT(YEAR FROM NOW())::INTEGER,
                EXTRACT(MONTH FROM NOW())::INTEGER,
                customer_bill_period_end_day,
                customer_bill_period_end_hour,
                0,
                0
            ) - INTERVAL '1 month')
            WHEN customer_bill_period_end_day < EXTRACT(DAY FROM NOW())
            THEN make_timestamp(
                EXTRACT(YEAR FROM NOW())::INTEGER,
                EXTRACT(MONTH FROM NOW())::INTEGER,
                customer_bill_period_end_day,
                customer_bill_period_end_hour,
                0,
                0
            )
        END AS start_date;
END;
$function$
;


-- public.vw_m2m_device_current_billing_period source
CREATE OR REPLACE VIEW public.vw_m2m_device_current_billing_period
AS SELECT device_tenant.device_id,
    current_customer_billing_period.end_date,
    current_customer_billing_period.start_date,
    device_tenant.tenant_id,
    row_number() OVER (ORDER BY device_tenant.device_id) AS id
   FROM device_tenant
     JOIN customers ON device_tenant.customer_id = customers.id
     LEFT JOIN LATERAL get_current_customer_billing_period(customers.customer_bill_period_end_day, customers.customer_bill_period_end_hour) current_customer_billing_period(start_date, end_date) ON true
  WHERE customers.customer_bill_period_end_day IS NOT NULL OR customers.customer_bill_period_end_hour IS NOT NULL;

-- public.vw_m2m_customer_current_cycle_device_usage source

CREATE OR REPLACE VIEW public.vw_m2m_customer_current_cycle_device_usage
AS SELECT device_usage.m2m_device_id,
    sum(device_usage.data_usage) AS customer_cycle_usage_byte,
    min(device_usage.start_date) AS start_date,
    device_usage.end_date,
    device_usage.tenant_id,
    row_number() OVER (ORDER BY device_usage.m2m_device_id) AS id
   FROM ( SELECT device_usage_1.m2m_device_id,
            device_usage_1.data_usage,
            vw_m2m_device_current_billing_period.end_date,
            vw_m2m_device_current_billing_period.start_date,
            device_usage_1.usage_date,
            vw_m2m_device_current_billing_period.tenant_id
           FROM device_usage device_usage_1
             JOIN vw_m2m_device_current_billing_period ON vw_m2m_device_current_billing_period.device_id = device_usage_1.m2m_device_id
          WHERE device_usage_1.m2m_device_id IS NOT NULL AND device_usage_1.usage_date >= vw_m2m_device_current_billing_period.start_date AND device_usage_1.usage_date < vw_m2m_device_current_billing_period.end_date) device_usage
  GROUP BY device_usage.m2m_device_id, device_usage.end_date, device_usage.tenant_id;

CREATE OR REPLACE VIEW public.vw_m2m_customer_pool_aggregate_usage
AS SELECT customer_rate_pool.id AS customer_rate_pool_id,
    customer_rate_pool.name AS customer_rate_pool_name,
    customer_rate_pool.service_provider_id,
    serviceprovider.display_name AS service_provider_name,
    customer_rate_pool.tenant_id,
    sum(COALESCE(device.carrier_cycle_usage::numeric, 0.0)) AS data_usage_bytes,
    sum(COALESCE(customerrateplan.plan_mb, 0.0)) AS customer_data_allocation_mb,
    count(*) AS num_records,
    serviceprovider.integration_id,
    row_number() OVER (ORDER BY customer_rate_pool.id) AS id,
    max(customer_rate_pool.modified_date) AS modified_date
   FROM customer_rate_pool
     JOIN device_tenant ON device_tenant.customer_rate_pool_id = customer_rate_pool.id
     JOIN device ON device_tenant.device_id = device.id
     JOIN serviceprovider ON customer_rate_pool.service_provider_id = serviceprovider.id
     JOIN customerrateplan ON device_tenant.customer_rate_plan_id = customerrateplan.id
     JOIN device_status ON device_status.id = device.device_status_id
     JOIN billing_period ON billing_period.id = device.billing_period_id
  WHERE customer_rate_pool.is_active = true AND customer_rate_pool.is_deleted = false AND device.is_active = true AND device.is_deleted = false AND serviceprovider.is_active = true AND serviceprovider.is_deleted = false AND customerrateplan.is_active = true AND customerrateplan.is_deleted = false AND device.billing_period_id = (( SELECT billing_period_1.id
           FROM billing_period billing_period_1
          WHERE billing_period_1.service_provider_id = device.service_provider_id AND billing_period_1.is_active = true AND billing_period_1.is_deleted = false
          ORDER BY billing_period_1.bill_year DESC, billing_period_1.bill_month DESC
         LIMIT 1)) AND (device_status.is_active_status = true OR device.last_activated_date < billing_period.billing_cycle_end_date AND device.last_activated_date > billing_period.billing_cycle_start_date)
  GROUP BY customer_rate_pool.id, customer_rate_pool.name, customer_rate_pool.service_provider_id, serviceprovider.display_name, customer_rate_pool.tenant_id, serviceprovider.integration_id;

CREATE OR REPLACE FUNCTION public.convertbytestombbyintegrationid(bytes bigint, integrationid integer)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
BEGIN
    RETURN CASE
        -- Integration Id of 12 is for Teal carrier
        WHEN IntegrationId = 12 THEN ROUND(COALESCE(Bytes, 0) / 1000.0 / 1000.0, 3)
        ELSE ROUND(COALESCE(Bytes, 0) / 1024.0 / 1024.0, 3)
    END;
END;
$function$
;



CREATE OR REPLACE VIEW public.vw_m2m_device_inventory
AS SELECT smi.last_usage_date,
    dt.id AS dt_id,
    smi.id AS device_id,
    smi.service_provider_id,
    sp.display_name AS service_provider_display_name,
    sp.integration_id,
    smi.iccid,
    smi.msisdn,
    smi.imei,
    smi.eid,
    smi.carrier_cycle_usage AS carrier_cycle_usage_bytes,
    COALESCE(carrier_rate_plan.friendly_name, smi.carrier_rate_plan) AS carrier_rate_plan_name,
        CASE
            WHEN i.id = 12 THEN round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS carrier_cycle_usage_mb,
    COALESCE(date_added.date_of_change, smi.date_added) AS date_added,
    COALESCE(date_activated.date_of_change, smi.date_activated) AS date_activated,
    smi.created_by,
    smi.created_date,
    smi.modified_by,
    smi.modified_date,
    smi.deleted_by,
    smi.deleted_date,
    smi.is_active,
    smi.is_deleted,
    dt.account_number,
    smi.cost_center,
    smi.username,
    smi.carrier_rate_plan_id,
    smi.device_status_id,
    ds.display_name AS sim_status,
    ds.is_active_status,
    dt.tenant_id,
    revcust.rev_customer_id,
    revcust.customer_name AS rev_customer_name,
    revcust.rev_parent_customer_id,
    cust.id AS customer_id,
    cust.parent_customer_id,
    cust.customer_name,
    dt.customer_rate_plan_id,
    customerrateplan.rate_plan_code AS customer_rate_plan_code,
    customerrateplan.rate_plan_name AS customer_rate_plan_name,
    smi.ctd_sms_usage AS sms_count,
    smi.communication_plan,
    smi.ip_address,
    dt.customer_rate_pool_id,
    customer_rate_pool.name AS customer_rate_pool_name,
    carrier_rate_plan.plan_mb AS carrier_rate_plan_mb,
    smi.soc,
    bp.billing_cycle_start_date,
    bp.billing_cycle_end_date,
    smi.billing_period_id,
    smi.ctd_sms_usage,
    smi.ctd_session_count,
    smi.package,
    smi.overage_limit_reached,
    smi.overage_limit_override,
    smi.device_description,
    smi.ctd_voice_usage,
    dt.rev_service_id,
    dt.account_number_integration_authentication_id,
    dt.customer_data_allocation_mb,
    customerrateplan.plan_mb AS customer_rate_plan_mb,
    customerrateplan.allows_sim_pooling AS customer_rate_plan_allows_sim_pooling,
    dt.is_active AS tenant_is_active,
    dt.is_deleted AS tenant_is_deleted,
        CASE
            WHEN cust.customer_bill_period_end_day IS NOT NULL AND cust.customer_bill_period_end_hour IS NOT NULL THEN convertbytestombbyintegrationid(COALESCE(vw_m2m_customer_current_cycle_device_usage.customer_cycle_usage_byte, 0.0)::bigint, sp.integration_id)
            ELSE convertbytestombbyintegrationid(COALESCE(smi.carrier_cycle_usage::numeric, 0.0)::bigint, sp.integration_id)
        END AS customer_cycle_usage
   FROM device smi
     JOIN device_tenant dt ON smi.id = dt.device_id
     JOIN serviceprovider sp ON smi.service_provider_id = sp.id
     LEFT JOIN device_status ds ON ds.id = smi.device_status_id
     LEFT JOIN carrier_rate_plan carrier_rate_plan ON smi.carrier_rate_plan_id = carrier_rate_plan.id
     LEFT JOIN customers cust ON cust.id = dt.customer_id AND cust.is_active = true AND cust.is_deleted = false
     LEFT JOIN revcustomer revcust ON cust.rev_customer_id = revcust.id AND cust.is_active = true
     LEFT JOIN integration i ON i.id = sp.integration_id AND i.is_active = true AND i.is_deleted = false
     LEFT JOIN customerrateplan customerrateplan ON dt.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customer_rate_pool customer_rate_pool ON dt.customer_rate_pool_id = customer_rate_pool.id
     LEFT JOIN vw_m2m_customer_current_cycle_device_usage ON vw_m2m_customer_current_cycle_device_usage.m2m_device_id = smi.id AND vw_m2m_customer_current_cycle_device_usage.tenant_id = dt.tenant_id
     LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = smi.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status.status
                   FROM device_status
                  WHERE sp.integration_id = ds.integration_id AND ds.is_active_status = true))
          ORDER BY device_status_history.date_of_change
         LIMIT 1) date_added ON true
     LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = smi.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status.status
                   FROM device_status
                  WHERE sp.integration_id = ds.integration_id))
          ORDER BY device_status_history.date_of_change DESC
         LIMIT 1) date_activated ON true
     LEFT JOIN billing_period bp ON bp.id = smi.billing_period_id
  WHERE smi.is_active = true AND smi.is_deleted = false AND i.portal_type_id = 0;

-- public.vw_m2m_device_inventory_count_check source

CREATE OR REPLACE VIEW public.vw_m2m_device_inventory_count_check
AS SELECT smi.last_usage_date,
    dt.id AS row_id,
    smi.id AS device_id,
    smi.service_provider_id,
    sp.display_name AS service_provider,
    sp.integration_id,
    smi.iccid,
    smi.msisdn,
    smi.imei,
    smi.eid,
    smi.carrier_rate_plan,
    smi.carrier_cycle_usage,
    COALESCE(crp.friendly_name, smi.carrier_rate_plan) AS rate_plan,
        CASE
            WHEN i.id = 12 THEN round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS data_usage_mb,
    COALESCE(date_added.date_of_change, smi.date_added) AS date_added,
    COALESCE(date_activated.date_of_change, smi.date_activated) AS date_activated,
    smi.created_date,
    smi.created_by,
    smi.modified_by,
    smi.modified_date,
    smi.deleted_by,
    smi.deleted_date,
    smi.is_active,
    smi.is_deleted,
    dt.account_number,
    smi.cost_center,
    smi.username,
    smi.carrier_rate_plan_id,
    smi.device_status_id,
    smi.sim_status AS status_code,
    ds.display_name AS sim_status,
    ds.status_color,
    ds.status_color_code,
    ds.is_active_status,
    cust.tenant_id,
    sp.tenant_id AS service_provider_tenant_id,
    revcust.rev_customer_id,
    revcust.customer_name AS rev_customer_name,
    revcust.rev_parent_customer_id,
    cust.id AS customer_id,
    cust.parent_customer_id,
    cust.customer_name,
    dt.customer_rate_plan_id,
    customerrateplan.rate_plan_code AS customer_rate_plan_code,
    customerrateplan.rate_plan_name AS customer_rate_plan_name,
    smi.ctd_sms_usage AS sms_count,
    smi.communication_plan,
    smi.ip_address,
    dt.customer_rate_pool_id,
    customer_rate_pool.name AS customer_rate_pool_name,
        CASE
            WHEN cust.customer_bill_period_end_day IS NOT NULL AND cust.customer_bill_period_end_hour IS NOT NULL THEN convertbytestombbyintegrationid(COALESCE(vw_m2m_customer_current_cycle_device_usage.customer_cycle_usage_byte, 0.0)::bigint, sp.integration_id)
            ELSE convertbytestombbyintegrationid(COALESCE(smi.carrier_cycle_usage::numeric, 0.0)::bigint, sp.integration_id)
        END AS customer_cycle_usage,
    smi.soc,
    crp.display_rate AS carrier_rate_plan_display_rate,
    customerrateplan.display_rate AS customer_rate_plan_display_rate,
    crp.plan_mb AS carrier_rate_plan_mb,
    dt.id AS dt_id
   FROM device smi
     JOIN device_tenant dt ON smi.id = dt.device_id
     JOIN serviceprovider sp ON smi.service_provider_id = sp.id
     LEFT JOIN device_status ds ON ds.id = smi.device_status_id
     LEFT JOIN carrier_rate_plan crp ON smi.carrier_rate_plan_id = crp.id
     LEFT JOIN customers cust ON cust.id = dt.customer_id AND cust.is_active = true AND cust.is_deleted = false
     LEFT JOIN revcustomer revcust ON cust.rev_customer_id = revcust.id AND cust.is_active = true
     LEFT JOIN integration i ON i.id = sp.integration_id AND i.is_active = true AND i.is_deleted = false
     LEFT JOIN customerrateplan customerrateplan ON dt.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customer_rate_pool customer_rate_pool ON dt.customer_rate_pool_id = customer_rate_pool.id
     LEFT JOIN vw_m2m_customer_current_cycle_device_usage ON vw_m2m_customer_current_cycle_device_usage.m2m_device_id = smi.id AND vw_m2m_customer_current_cycle_device_usage.tenant_id = dt.tenant_id
     LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = smi.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status.status
                   FROM device_status
                  WHERE sp.integration_id = ds.integration_id AND ds.is_active_status = true))
          ORDER BY device_status_history.date_of_change
         LIMIT 1) date_added ON true
     LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = smi.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status.status
                   FROM device_status
                  WHERE sp.integration_id = ds.integration_id))
          ORDER BY device_status_history.date_of_change DESC
         LIMIT 1) date_activated ON true
  WHERE smi.is_active = true AND smi.is_deleted = false AND i.portal_type_id = 0;

-- public.vw_m2m_device_inventory_export source

CREATE OR REPLACE VIEW public.vw_m2m_device_inventory_export
AS SELECT d.service_provider_id,
    sp.display_name AS service_provider_display_name,
    COALESCE(dc.date_of_change, d.date_added) AS date_added,
    COALESCE(ac.date_of_change, d.date_activated) AS date_activated,
    d.iccid,
    d.imei,
    d.msisdn,
    d.eid,
    d.carrier_rate_plan AS carrier_rate_plan_name,
    crp1.display_rate AS carrier_rate_plan_display_rate,
    d.communication_plan AS comm_plan,
    d.ip_address,
        CASE
            WHEN i.id = 12 THEN to_char(round(COALESCE(d.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3), 'FM999999999999.0000'::text)
            ELSE to_char(round(COALESCE(d.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3), 'FM999999999999.0000'::text)
        END AS data_usage_mb,
    crp2.name AS customer_rate_pool_name,
    crp1.rate_plan_name AS customer_rate_plan_name,
    crp1.display_rate AS customer_rate_plan_display_rate,
    ds.display_name AS status_display_name,
    d.cost_center,
    rc.rev_customer_id,
    s.customer_name,
    d.ctd_sms_usage AS sms_count,
    s.tenant_id,
    s.id AS customer_id,
    s.parent_customer_id,
    d.sim_status AS status_code,
    d.carrier_cycle_usage AS data_usage_bytes,
    rc.customer_name AS rev_customer_name,
    d.created_date,
    d.created_by,
    d.username,
    to_char(round(
        CASE
            WHEN s.customer_bill_period_end_day IS NOT NULL AND s.customer_bill_period_end_hour IS NOT NULL THEN convertbytestombbyintegrationid(COALESCE(ccdu.customer_cycle_usage_byte::bigint, 0::bigint), sp.integration_id)
            ELSE convertbytestombbyintegrationid(COALESCE(d.carrier_cycle_usage, 0::bigint), sp.integration_id)
        END, 3), 'FM999999999999.0000'::text) AS customer_cycle_usage_mb,
    bp.billing_cycle_start_date,
    bp.billing_cycle_end_date,
    d.id,
    d.is_active
   FROM device d
     JOIN serviceprovider sp ON d.service_provider_id = sp.id
     JOIN integration i ON i.id = sp.integration_id
     JOIN device_tenant dt ON d.id = dt.device_id
     LEFT JOIN device_status ds ON ds.id = d.device_status_id
     LEFT JOIN customers s ON dt.customer_id = s.id AND s.is_active = true
     LEFT JOIN billing_period bp ON d.billing_period_id = bp.id AND bp.is_active = true
     LEFT JOIN revcustomer rc ON s.rev_customer_id = rc.id AND rc.is_active = true
     LEFT JOIN customerrateplan crp1 ON dt.customer_rate_plan_id = crp1.id
     LEFT JOIN customer_rate_pool crp2 ON crp2.id = dt.customer_rate_pool_id
     LEFT JOIN carrier_rate_plan crp3 ON d.carrier_rate_plan_id = crp3.id
     LEFT JOIN vw_m2m_customer_current_cycle_device_usage ccdu ON ccdu.m2m_device_id = d.id AND ccdu.tenant_id = dt.tenant_id
     LEFT JOIN LATERAL ( SELECT dsh.date_of_change
           FROM device_status_history dsh
          WHERE dsh.iccid::text = d.iccid::text AND (dsh.current_status::text IN ( SELECT device_status.status
                   FROM device_status
                  WHERE sp.integration_id = device_status.integration_id AND device_status.is_active_status = true))
          ORDER BY dsh.date_of_change
         LIMIT 1) dc ON true
     LEFT JOIN LATERAL ( SELECT dsh.date_of_change
           FROM device_status_history dsh
          WHERE dsh.iccid::text = d.iccid::text AND (dsh.current_status::text IN ( SELECT device_status.status
                   FROM device_status
                  WHERE sp.integration_id = device_status.integration_id))
          ORDER BY dsh.date_of_change DESC
         LIMIT 1) ac ON true
  WHERE d.is_active = true AND i.is_active = true AND i.portal_type_id = 0;

-- public.vw_m2m_device_status_history source

CREATE OR REPLACE VIEW public.vw_m2m_device_status_history
AS SELECT row_number() OVER (ORDER BY dsh.id)::integer AS id,
    dsh.iccid,
    dsh.msisdn,
    COALESCE(dsh.previous_status, ( SELECT previous_record.previous_status
           FROM device_status_history previous_record
          WHERE previous_record.sim_management_inventory_id = dsh.sim_management_inventory_id AND (dsh.tenant_id IS NULL OR previous_record.tenant_id = dsh.tenant_id) AND previous_record.date_of_change < dsh.date_of_change
          ORDER BY previous_record.date_of_change DESC
         LIMIT 1)) AS previous_status,
    dsh.current_status,
    dsh.change_event_type,
    dsh.changed_by,
    dsh.service_provider_id,
    dsh.sim_management_inventory_id,
    dsh.bulk_change_id,
    dsh.customer_name,
    dsh.customer_account_number,
    dsh.username,
    dsh.customer_rate_plan,
    dsh.customer_rate_pool,
    COALESCE(dsh.tenant_id, dt.tenant_id) AS tenant_id,
    sp.display_name AS serviceprovidername,
    dt.customer_id,
    dt.account_number
   FROM device_status_history dsh
     JOIN device smi ON dsh.iccid::text = smi.iccid::text
     JOIN serviceprovider sp ON smi.service_provider_id = sp.id
     LEFT JOIN device_tenant dt ON dt.device_id = smi.id AND (dt.tenant_id = dsh.tenant_id OR dsh.tenant_id IS NULL);

-- public.vw_mobility_device_current_billing_period source

CREATE OR REPLACE VIEW public.vw_mobility_device_current_billing_period
AS SELECT mobility_device_tenant.mobility_device_id,
    current_customer_billing_period.end_date,
    current_customer_billing_period.start_date,
    mobility_device_tenant.tenant_id,
    row_number() OVER (ORDER BY mobility_device_tenant.mobility_device_id) AS id
   FROM mobility_device_tenant
     JOIN customers ON mobility_device_tenant.customer_id = customers.id
     CROSS JOIN LATERAL get_current_customer_billing_period(customers.customer_bill_period_end_day, customers.customer_bill_period_end_hour) current_customer_billing_period(start_date, end_date)
  WHERE customers.customer_bill_period_end_day IS NOT NULL OR customers.customer_bill_period_end_hour IS NOT NULL;

-- public.vw_mobility_customer_current_cycle_device_usage source

CREATE OR REPLACE VIEW public.vw_mobility_customer_current_cycle_device_usage
AS SELECT device_usage.mobility_device_id,
    sum(device_usage.data_usage) AS customer_cycle_usage_byte,
    min(device_usage.start_date) AS start_date,
    device_usage.end_date,
    device_usage.tenant_id,
    row_number() OVER (ORDER BY device_usage.mobility_device_id) AS id
   FROM ( SELECT device_usage_1.mobility_device_id,
            device_usage_1.data_usage,
            vw_mobility_device_current_billing_period.end_date,
            vw_mobility_device_current_billing_period.start_date,
            device_usage_1.usage_date,
            vw_mobility_device_current_billing_period.tenant_id
           FROM device_usage device_usage_1
             JOIN vw_mobility_device_current_billing_period ON vw_mobility_device_current_billing_period.mobility_device_id = device_usage_1.mobility_device_id
          WHERE device_usage_1.mobility_device_id IS NOT NULL AND device_usage_1.usage_date >= vw_mobility_device_current_billing_period.start_date AND device_usage_1.usage_date < vw_mobility_device_current_billing_period.end_date) device_usage
  GROUP BY device_usage.mobility_device_id, device_usage.end_date, device_usage.tenant_id;


-- public.vw_device_history_view source

CREATE OR REPLACE VIEW public.vw_device_history_view
AS SELECT dh.id,
    bp.billing_cycle_end_date,
    dh.service_provider_id,
    sp.display_name AS service_provider_display_name,
    sp.integration_id,
    dh.iccid,
    dh.msisdn,
    dh.imei,
    dh.rate_plan,
    dh.carrier_cycle_usage,
        CASE
            WHEN i.id = 12 THEN round(COALESCE(dh.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(dh.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS data_usage_mb,
    dh.provider_date_added AS date_added,
    dh.provider_date_activated AS date_activated,
    jcrp.rate_plan_code,
    jcrp.rate_plan_name,
    jcrp.allows_sim_pooling AS customer_rate_plan_allows_sim_pooling,
    jcrp.plan_mb AS customer_rate_plan_mb,
    dh.created_date,
    dh.created_by,
    dh.modified_by,
    dh.modified_date,
    dh.deleted_by,
    dh.deleted_date,
    dh.is_active,
    dh.is_deleted,
    dt.account_number,
    dh.carrier_rate_plan_id,
    dh.status AS status_code,
    ds.display_name AS status_display_name,
    ds.status_color,
    ds.status_color_code,
    dt.tenant_id,
    rc.rev_customer_id,
    s.customer_name,
    rc.rev_parent_customer_id,
    COALESCE(dh.ctd_sms_usage, 0::bigint) AS sms_usage,
    dh.device_history_id,
    dh.is_pushed,
    crp.name AS customer_rate_pool_name,
    dt.customer_data_allocation_mb
   FROM device_history dh
     JOIN device_tenant dt ON dh.device_tenant_id = dt.id
     JOIN serviceprovider sp ON dh.service_provider_id = sp.id
     LEFT JOIN customers s ON s.id = dt.customer_id
     LEFT JOIN device_status ds ON ds.id = dh.device_status_id
     LEFT JOIN revcustomer rc ON s.rev_customer_id = rc.id
     LEFT JOIN integration i ON i.id = sp.integration_id
     LEFT JOIN billing_period bp ON dh.billing_period_id = bp.id
     LEFT JOIN customerrateplan jcrp ON dh.customer_rate_plan_id = jcrp.id
     LEFT JOIN customer_rate_pool crp ON dh.customer_rate_pool_id = crp.id
  WHERE dh.is_active = true AND dh.is_deleted = false AND i.portal_type_id = 0 AND (ds.is_active_status = true OR dh.last_activated_date < bp.billing_cycle_end_date AND dh.last_activated_date > bp.billing_cycle_start_date OR dh.carrier_cycle_usage > 0);

-- public.vw_mobility_device_history source

CREATE OR REPLACE VIEW public.vw_mobility_device_history
AS SELECT mdh.id,
    bp.billing_cycle_end_date,
    mdh.service_provider_id,
    sp.display_name AS service_provider_display_name,
    sp.integration_id,
    mdh.iccid,
    mdh.msisdn,
    mdh.imei,
    mdh.rate_plan,
    mdh.carrier_cycle_usage,
        CASE
            WHEN i.id = 12 THEN round(COALESCE(mdh.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(mdh.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS data_usage_mb,
    mdh.provider_date_added AS date_added,
    mdh.provider_date_activated AS date_activated,
    jcrp.rate_plan_code,
    jcrp.rate_plan_name,
    jcrp.allows_sim_pooling AS customer_rate_plan_allows_sim_pooling,
    mdt.customer_data_allocation_mb,
    jcrp.plan_mb AS customer_rate_plan_mb,
    mdh.created_date,
    mdh.created_by,
    mdh.modified_by,
    mdh.modified_date,
    mdh.deleted_by,
    mdh.deleted_date,
    mdh.is_active,
    mdh.is_deleted,
    mdh.account_number,
    mdh.carrier_rate_plan_id,
    mdh.status AS status_code,
    ds.display_name AS status_display_name,
    ds.status_color,
    ds.status_color_code,
    s.tenant_id,
    rc.rev_customer_id,
    s.customer_name,
    rc.rev_parent_customer_id,
    mdh.foundation_account_number,
    mdh.billing_account_number,
    mdh.service_zip_code,
    mdh.single_user_code AS rate_plan_soc,
    mdh.single_user_code_description AS rate_plan_soc_description,
    mdh.data_group_id,
    mdh.pool_id,
    mdh.device_make,
    mdh.device_model,
    mdh.contract_status,
    mdh.ban_status,
    mdh.imei_type_id,
    mdh.plan_limit_mb,
    mdh.username,
    COALESCE(mdh.ctd_sms_usage, 0::bigint) AS sms_usage,
    mdh.ctd_voice_usage AS minutes_used,
    mdh.ip_address,
    crp.name AS customer_rate_pool_name,
    mdh.device_history_id,
    mdh.is_pushed
   FROM mobility_device_history mdh
     JOIN serviceprovider sp ON mdh.service_provider_id = sp.id
     LEFT JOIN customers s ON s.id = mdh.customer_id
     LEFT JOIN device_status ds ON ds.id = mdh.device_status_id
     LEFT JOIN revcustomer rc ON rc.id = s.rev_customer_id
     LEFT JOIN billing_period bp ON mdh.billing_period_id = bp.id
     LEFT JOIN integration i ON i.id = sp.integration_id
     LEFT JOIN mobility_device_tenant mdt ON mdh.id = mdt.mobility_device_id AND mdh.mobility_device_tenant_id = mdt.id
     LEFT JOIN customerrateplan jcrp ON mdh.customer_rate_plan_id = jcrp.id
     LEFT JOIN customer_rate_pool crp ON mdh.customer_rate_pool_id = crp.id
  WHERE mdh.is_active = true AND mdh.is_deleted = false AND i.portal_type_id = 2 AND mdt.id IS NOT NULL AND (ds.is_active_status = true OR mdh.last_activated_date < bp.billing_cycle_end_date AND mdh.last_activated_date > bp.billing_cycle_start_date OR mdh.carrier_cycle_usage > 0);

CREATE OR REPLACE VIEW public.vw_mobility_device_inventory
AS SELECT md.id AS mobility_device_id,
    mdt.id AS mdt_id,
    mdt.tenant_id,
    md.service_provider_id,
    sp.display_name AS service_provider_display_name,
    sp.integration_id,
    md.billing_account_number,
    md.foundation_account_number,
    md.iccid,
    md.imsi,
    md.msisdn,
    md.imei,
    mdt.customer_id,
    c.customer_name,
    c.parent_customer_id,
    rc.rev_customer_id,
    rc.customer_name AS rev_customer_name,
    rc.rev_parent_customer_id,
    md.device_status_id,
    ds.display_name AS sim_status,
    md.carrier_cycle_usage AS carrier_cycle_usage_bytes,
        CASE
            WHEN i.id = 12 THEN round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS carrier_cycle_usage_mb,
    md.date_added,
    md.date_activated,
    mdt.account_number,
    md.carrier_rate_plan_id,
    COALESCE(crp.friendly_name, md.carrier_rate_plan) AS carrier_rate_plan_name,
        CASE
            WHEN c.customer_bill_period_end_day IS NOT NULL AND c.customer_bill_period_end_hour IS NOT NULL THEN round(COALESCE(vw_mobility_customer_current_cycle_device_usage.customer_cycle_usage_byte, 0.0) / 1024.0 / 1024.0, 3)
            ELSE round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS customer_cycle_usage_mb,
    mdt.customer_rate_pool_id,
    cpool.name AS customer_rate_pool_name,
    mdt.customer_rate_plan_id,
    custrp.rate_plan_name AS customer_rate_plan_name,
    custrp.rate_plan_code AS customer_rate_plan_code,
    md.sms_count,
    md.minutes_used,
    md.username,
    ds.is_active_status,
    md.ip_address,
    md.service_zip_code,
    md.single_user_code AS rate_plan_soc,
    md.single_user_code_description AS rate_plan_soc_description,
    md.data_group_id,
    md.pool_id,
    md.next_bill_cycle_date,
    md.device_make,
    md.device_model,
    md.contract_status,
    md.ban_status,
    md.imei_type_id,
    md.plan_limit_mb,
    mdt.customer_data_allocation_mb,
    bp.billing_cycle_start_date,
    bp.billing_cycle_end_date,
    custrp.plan_mb AS customer_rate_plan_mb,
    custrp.allows_sim_pooling AS customer_rate_plan_allows_sim_pooling,
    crp.plan_mb AS carrier_rate_plan_mb,
    ( SELECT string_agg(mf.soc_code::text, ','::text) AS string_agg
           FROM telegence_device_mobility_feature tdmf
             JOIN mobility_feature mf ON mf.id = tdmf.mobility_feature_id
          WHERE td.id IS NOT NULL AND tdmf.is_active = true AND tdmf.telegence_device_id = td.id AND mf.is_active = true AND mf.is_retired = false) AS telegence_feature,
    ( SELECT string_agg(mf.soc_code::text, ','::text) AS string_agg
           FROM e_bonding_device_mobility_feature ebdmf
             JOIN mobility_feature mf ON mf.id = ebdmf.mobility_feature_id
          WHERE e_bonding_device.id IS NOT NULL AND ebdmf.is_active = true AND ebdmf.e_bonding_device_id = e_bonding_device.id AND mf.is_active = true AND mf.is_retired = false) AS e_bonding_feature,
    md.last_usage_date,
    md.created_by,
    md.created_date,
    md.modified_by,
    md.modified_date,
    md.last_activated_date,
    md.deleted_by,
    md.deleted_date,
    md.is_active,
    md.cost_center_1 AS cost_center1,
    md.soc,
    md.billing_period_id,
    md.ctd_sms_usage,
    md.ctd_session_count,
    md.ctd_voice_usage,
    mdt.rev_service_id,
    mdt.account_number_integration_authentication_id,
    md.delta_ctd_data_usage,
    md.technology_type,
    md.optimization_group_id,
    mdt.is_active AS tenant_is_active
   FROM mobility_device md
     JOIN mobility_device_tenant mdt ON mdt.mobility_device_id = md.id
     JOIN serviceprovider sp ON md.service_provider_id = sp.id
     LEFT JOIN device_status ds ON ds.id = md.device_status_id
     LEFT JOIN customers c ON c.id = mdt.customer_id AND c.is_active = true
     LEFT JOIN revcustomer rc ON c.rev_customer_id = rc.id AND rc.is_active = true
     LEFT JOIN integration i ON i.id = sp.integration_id AND i.is_active = true
     LEFT JOIN carrier_rate_plan crp ON crp.id = md.carrier_rate_plan_id
     LEFT JOIN customerrateplan custrp ON custrp.id = mdt.customer_rate_plan_id
     LEFT JOIN customer_rate_pool cpool ON cpool.id = mdt.customer_rate_pool_id
     LEFT JOIN billing_period bp ON bp.id = md.billing_period_id
     LEFT JOIN telegence_device td ON td.subscriber_number::text = md.msisdn::text AND td.service_provider_id = md.service_provider_id
     LEFT JOIN e_bonding_device ON e_bonding_device.subscriber_number::text = md.msisdn::text AND e_bonding_device.service_provider_id = md.service_provider_id
     LEFT JOIN vw_mobility_customer_current_cycle_device_usage ON vw_mobility_customer_current_cycle_device_usage.mobility_device_id = md.id AND vw_mobility_customer_current_cycle_device_usage.tenant_id = mdt.tenant_id
  WHERE md.is_active = true AND i.portal_type_id = 2;

  -- public.vw_combined_device_history source
CREATE OR REPLACE VIEW public.vw_combined_device_history
AS SELECT vw_mobility_device_history.id,
    vw_mobility_device_history.billing_cycle_end_date,
    vw_mobility_device_history.service_provider_id,
    vw_mobility_device_history.service_provider_display_name,
    vw_mobility_device_history.integration_id,
    vw_mobility_device_history.iccid,
    vw_mobility_device_history.msisdn,
    vw_mobility_device_history.imei,
    vw_mobility_device_history.rate_plan AS carrier_rate_plan,
    vw_mobility_device_history.carrier_cycle_usage,
    vw_mobility_device_history.data_usage_mb,
    vw_mobility_device_history.date_added,
    vw_mobility_device_history.date_activated,
    vw_mobility_device_history.rate_plan_code,
    vw_mobility_device_history.rate_plan_name,
    vw_mobility_device_history.customer_rate_plan_allows_sim_pooling,
    vw_mobility_device_history.customer_rate_plan_mb AS plan_mb,
    vw_mobility_device_history.created_date,
    vw_mobility_device_history.created_by,
    vw_mobility_device_history.modified_by,
    vw_mobility_device_history.modified_date,
    vw_mobility_device_history.deleted_by,
    vw_mobility_device_history.deleted_date,
    vw_mobility_device_history.is_active,
    vw_mobility_device_history.is_deleted,
    vw_mobility_device_history.account_number,
    vw_mobility_device_history.carrier_rate_plan_id,
    vw_mobility_device_history.status_code,
    vw_mobility_device_history.status_display_name,
    vw_mobility_device_history.status_color,
    vw_mobility_device_history.status_color_code,
    vw_mobility_device_history.tenant_id,
    vw_mobility_device_history.rev_customer_id,
    vw_mobility_device_history.customer_name,
    vw_mobility_device_history.rev_parent_customer_id,
    vw_mobility_device_history.foundation_account_number,
    vw_mobility_device_history.billing_account_number,
    vw_mobility_device_history.service_zip_code,
    vw_mobility_device_history.rate_plan_soc,
    vw_mobility_device_history.rate_plan_soc_description,
    vw_mobility_device_history.data_group_id,
    vw_mobility_device_history.pool_id,
    vw_mobility_device_history.device_make,
    vw_mobility_device_history.device_model,
    vw_mobility_device_history.contract_status,
    vw_mobility_device_history.ban_status,
    vw_mobility_device_history.imei_type_id,
    vw_mobility_device_history.plan_limit_mb,
    vw_mobility_device_history.username,
    vw_mobility_device_history.sms_usage AS smsusage,
    vw_mobility_device_history.minutes_used,
    vw_mobility_device_history.ip_address,
    vw_mobility_device_history.customer_rate_pool_name,
    vw_mobility_device_history.device_history_id,
    vw_mobility_device_history.is_pushed,
    vw_mobility_device_history.customer_data_allocation_mb
   FROM vw_mobility_device_history
UNION ALL
 SELECT vw_device_history_view.id,
    vw_device_history_view.billing_cycle_end_date,
    vw_device_history_view.service_provider_id,
    vw_device_history_view.service_provider_display_name,
    vw_device_history_view.integration_id,
    vw_device_history_view.iccid,
    vw_device_history_view.msisdn,
    vw_device_history_view.imei,
    vw_device_history_view.rate_plan AS carrier_rate_plan,
    vw_device_history_view.carrier_cycle_usage,
    vw_device_history_view.data_usage_mb,
    vw_device_history_view.date_added,
    vw_device_history_view.date_activated,
    vw_device_history_view.rate_plan_code,
    vw_device_history_view.rate_plan_name,
    vw_device_history_view.customer_rate_plan_allows_sim_pooling,
    vw_device_history_view.customer_rate_plan_mb AS plan_mb,
    vw_device_history_view.created_date,
    vw_device_history_view.created_by,
    vw_device_history_view.modified_by,
    vw_device_history_view.modified_date,
    vw_device_history_view.deleted_by,
    vw_device_history_view.deleted_date,
    vw_device_history_view.is_active,
    vw_device_history_view.is_deleted,
    vw_device_history_view.account_number,
    vw_device_history_view.carrier_rate_plan_id,
    vw_device_history_view.status_code,
    vw_device_history_view.status_display_name,
    vw_device_history_view.status_color,
    vw_device_history_view.status_color_code,
    vw_device_history_view.tenant_id,
    vw_device_history_view.rev_customer_id,
    vw_device_history_view.customer_name,
    vw_device_history_view.rev_parent_customer_id,
    NULL::character varying AS foundation_account_number,
    NULL::character varying AS billing_account_number,
    NULL::character varying AS service_zip_code,
    NULL::character varying AS rate_plan_soc,
    NULL::character varying AS rate_plan_soc_description,
    NULL::character varying AS data_group_id,
    NULL::character varying AS pool_id,
    NULL::character varying AS device_make,
    NULL::character varying AS device_model,
    NULL::character varying AS contract_status,
    NULL::character varying AS ban_status,
    NULL::integer AS imei_type_id,
    NULL::numeric AS plan_limit_mb,
    NULL::character varying AS username,
    vw_device_history_view.sms_usage AS smsusage,
    NULL::bigint AS minutes_used,
    NULL::character varying AS ip_address,
    vw_device_history_view.customer_rate_pool_name,
    vw_device_history_view.device_history_id,
    vw_device_history_view.is_pushed,
    vw_device_history_view.customer_data_allocation_mb
   FROM vw_device_history_view;

-- public.vw_mobility_device_usage_trend_by_month source

-- public.vw_mobility_device_usage_trend_by_month source

CREATE OR REPLACE VIEW public.vw_mobility_device_usage_trend_by_month
AS SELECT du_month.service_provider_id,
    du_month.service_provider_name,
    COALESCE(row_number() OVER (ORDER BY du_month.bill_year, du_month.bill_month, du_month.account_number), 0::bigint) AS id,
    du_month.bill_year,
    du_month.bill_month,
    du_month.account_number,
    sum(du_month.carrier_cycle_usage) AS total_usage_bytes,
    sum(du_month.carrier_cycle_usage_mb) AS total_usage_mb,
    count(1) AS total_cards,
    avg(du_month.carrier_cycle_usage) AS avg_usage_per_card_bytes,
    avg(du_month.carrier_cycle_usage_mb) AS avg_usage_per_card_mb,
    du_month.tenant_id,
    du_month.portal_type_id,
    du_month.customer_id,
    du_month.parent_customer_id,
    du_month.customer_name
   FROM ( SELECT md.service_provider_id,
            sp.service_provider_name,
            jduh.bill_year,
            jduh.bill_month,
            COALESCE(jduh.carrier_cycle_usage::numeric, 0.0) AS carrier_cycle_usage,
                CASE
                    WHEN i.id = 12 THEN COALESCE(jduh.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0
                    ELSE COALESCE(jduh.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0
                END AS carrier_cycle_usage_mb,
            mt.account_number,
            c.tenant_id,
            i.portal_type_id,
            c.id AS customer_id,
            c.parent_customer_id,
            c.customer_name
           FROM mobility_device md
             JOIN mobility_device_tenant mt ON md.id = mt.mobility_device_id
             JOIN serviceprovider sp ON sp.id = md.service_provider_id
             JOIN device_status dst ON md.device_status_id = dst.id
             LEFT JOIN customers c ON mt.customer_id = c.id
             LEFT JOIN ( SELECT bp.bill_year,
                    bp.bill_month,
                    dh.iccid,
                    dh.service_provider_id,
                    dh.carrier_cycle_usage,
                    dh.msisdn,
                    dh.status,
                    dh.created_date,
                    COALESCE(sp_1.bill_period_end_day::character varying, '18'::character varying) AS billing_period_end_day,
                    COALESCE(sp_1.bill_period_end_hour::character varying, '18'::character varying) AS billing_period_end_hour,
                    dh.customer_id
                   FROM mobility_device_history dh
                     JOIN device_status dst_1 ON dst_1.id = dh.device_status_id
                     JOIN serviceprovider sp_1 ON sp_1.id = dh.service_provider_id
                     JOIN billing_period bp ON bp.id = dh.billing_period_id
                  WHERE dst_1.is_active_status = true OR dh.carrier_cycle_usage > 0 AND dh.status::text <> 'TEST READY'::text) jduh ON md.msisdn::text = jduh.msisdn::text AND md.service_provider_id = jduh.service_provider_id AND mt.customer_id = jduh.customer_id
             LEFT JOIN integration i ON i.id = sp.integration_id
          WHERE md.is_active = true AND md.is_deleted = false AND (dst.is_active_status = true OR md.last_activated_date IS NOT NULL AND md.last_activated_date > (to_timestamp(((((((jduh.bill_year || '-'::text) || lpad(jduh.bill_month::text, 2, '0'::text)) || '-'::text) || lpad(jduh.billing_period_end_day::text, 2, '0'::text)) || ' '::text) || lpad(jduh.billing_period_end_hour::text, 2, '0'::text)) || ':00'::text, 'YYYY-MM-DD HH24:MI'::text) - '1 mon'::interval))) du_month
  GROUP BY du_month.service_provider_id, du_month.service_provider_name, du_month.bill_year, du_month.bill_month, du_month.account_number, du_month.tenant_id, du_month.portal_type_id, du_month.customer_id, du_month.parent_customer_id, du_month.customer_name;

-- public.vw_device_status_trend_by_month source

CREATE OR REPLACE VIEW public.vw_device_status_trend_by_month
AS SELECT COALESCE(gen_random_uuid(), '00000000-0000-0000-0000-000000000000'::uuid) AS id,
    jdsa.activated_count,
    jdsa.activation_ready_count,
    jdsa.deactivated_count,
    jdsa.inventory_count,
    jdsa.retired_count,
    jdsa.test_ready_count,
    to_char(jdsa.created_date, 'YYYY-MM-DD'::text) AS created_date,
    jdsa.bill_year,
    jdsa.bill_month,
    jdsa.service_provider_id,
    sp.service_provider_name AS service_provider,
    i.portal_type_id
   FROM jasper_device_sync_audit jdsa
     JOIN serviceprovider sp ON jdsa.service_provider_id = sp.id
     JOIN ( SELECT jasper_device_sync_audit.bill_year,
            jasper_device_sync_audit.bill_month,
            jasper_device_sync_audit.service_provider_id,
            max(jasper_device_sync_audit.id) AS id
           FROM jasper_device_sync_audit
          GROUP BY jasper_device_sync_audit.bill_year, jasper_device_sync_audit.bill_month, jasper_device_sync_audit.service_provider_id) jdsa_month ON jdsa.id = jdsa_month.id AND jdsa_month.service_provider_id = sp.id
     LEFT JOIN integration i ON i.id = sp.integration_id
UNION
 SELECT COALESCE(gen_random_uuid(), '00000000-0000-0000-0000-000000000000'::uuid) AS id,
    COALESCE(jdsa.active_count, 0) + COALESCE(jdsa.pending_mdn_change_count, 0) + COALESCE(jdsa.pending_prl_update_count, 0) + COALESCE(jdsa.pending_service_plan_change_count, 0) + COALESCE(jdsa.pending_account_update_count, 0) AS activated_count,
    COALESCE(jdsa.pending_resume_count, 0) + COALESCE(jdsa.pending_preactive_count, 0) + COALESCE(jdsa.pending_activation_count, 0) AS activation_ready_count,
    COALESCE(jdsa.deactive_count, 0) + COALESCE(jdsa.suspend_count, 0) + COALESCE(jdsa.pending_deactivation_count, 0) + COALESCE(jdsa.pending_suspend_count, 0) AS deactivated_count,
    0 AS inventory_count,
    0 AS retired_count,
    COALESCE(jdsa.pre_active_count, 0) AS test_ready_count,
    to_char(jdsa.created_date, 'YYYY-MM-DD'::text) AS created_date,
    jdsa.bill_year,
    jdsa.bill_month,
    jdsa.service_provider_id,
    sp.service_provider_name AS service_provider,
    i.portal_type_id
   FROM thing_space_device_sync_audit jdsa
     JOIN serviceprovider sp ON sp.id = jdsa.service_provider_id
     JOIN ( SELECT thing_space_device_sync_audit.bill_year,
            thing_space_device_sync_audit.bill_month,
            max(thing_space_device_sync_audit.id) AS id
           FROM thing_space_device_sync_audit
          GROUP BY thing_space_device_sync_audit.bill_year, thing_space_device_sync_audit.bill_month) jdsa_month ON jdsa.id = jdsa_month.id
     LEFT JOIN integration i ON i.id = sp.integration_id
UNION
 SELECT COALESCE(gen_random_uuid(), '00000000-0000-0000-0000-000000000000'::uuid) AS id,
    COALESCE(jdsa.active_count, 0) AS activated_count,
    0 AS activation_ready_count,
    COALESCE(jdsa.suspend_count, 0) AS deactivated_count,
    0 AS inventory_count,
    0 AS retired_count,
    0 AS test_ready_count,
    to_char(jdsa.created_date, 'YYYY-MM-DD'::text) AS created_date,
    jdsa.bill_year,
    jdsa.bill_month,
    jdsa.service_provider_id,
    sp.service_provider_name AS service_provider,
    i.portal_type_id
   FROM telegence_device_sync_audit jdsa
     JOIN serviceprovider sp ON sp.id = jdsa.service_provider_id
     JOIN ( SELECT telegence_device_sync_audit.bill_year,
            telegence_device_sync_audit.bill_month,
            max(telegence_device_sync_audit.id) AS id
           FROM telegence_device_sync_audit
          GROUP BY telegence_device_sync_audit.bill_year, telegence_device_sync_audit.bill_month) jdsa_month ON jdsa.id = jdsa_month.id
     LEFT JOIN integration i ON i.id = sp.integration_id
UNION
 SELECT COALESCE(gen_random_uuid(), '00000000-0000-0000-0000-000000000000'::uuid) AS id,
    COALESCE(jdsa.active_count, 0) AS activated_count,
    0 AS activation_ready_count,
    COALESCE(jdsa.suspend_count, 0) AS deactivated_count,
    0 AS inventory_count,
    0 AS retired_count,
    0 AS test_ready_count,
    to_char(jdsa.created_date, 'YYYY-MM-DD'::text) AS created_date,
    jdsa.bill_year,
    jdsa.bill_month,
    jdsa.service_provider_id,
    sp.service_provider_name AS service_provider,
    i.portal_type_id
   FROM e_bonding_device_sync_audit jdsa
     JOIN serviceprovider sp ON sp.id = jdsa.service_provider_id
     JOIN ( SELECT e_bonding_device_sync_audit.bill_year,
            e_bonding_device_sync_audit.bill_month,
            max(e_bonding_device_sync_audit.id) AS id
           FROM e_bonding_device_sync_audit
          GROUP BY e_bonding_device_sync_audit.bill_year, e_bonding_device_sync_audit.bill_month) jdsa_month ON jdsa.id = jdsa_month.id
     LEFT JOIN integration i ON i.id = sp.integration_id;



-- public.vw_cross_provider_usage_by_line_report_for_customer source
CREATE OR REPLACE VIEW public.vw_cross_provider_usage_by_line_report_for_customer
AS WITH billing_data AS (
         SELECT c.id AS customer_id,
            c.customer_name,
            c.tenant_id,
            cbp.id AS billing_period_id,
            cbp.bill_month,
            cbp.bill_year,
            COALESCE(c.customer_bill_period_end_day, 1) AS customer_bill_period_end_day,
            COALESCE(c.customer_bill_period_end_hour, 0) AS customer_bill_period_end_hour,
            c.is_active,
            c.is_deleted
           FROM customers c
             LEFT JOIN LATERAL usp_get_customer_billing_period_by_siteid(c.id) cbp(id, bill_month, bill_year, customer_bill_period_end_day, customer_bill_period_end_hour) ON true
        )
 SELECT billing_data.customer_id,
    billing_data.customer_name,
    billing_data.tenant_id,
    array_agg(billing_data.billing_period_id) AS billing_period_ids,
    array_agg(
        CASE
            WHEN billing_data.billing_period_id IS NOT NULL THEN concat(lpad(billing_data.bill_month::text, 2, '0'::text), '-', lpad(billing_data.customer_bill_period_end_day::text, 2, '0'::text), '-', billing_data.bill_year::text, ' ', lpad(billing_data.customer_bill_period_end_hour::text, 2, '0'::text), ':00:00')
            ELSE NULL::text
        END) AS billing_cycle_end_date,
    billing_data.is_active,
    billing_data.is_deleted
   FROM billing_data
  GROUP BY billing_data.customer_id, billing_data.customer_name, billing_data.tenant_id, billing_data.is_active, billing_data.is_deleted
  ORDER BY billing_data.customer_name;

-- public.vw_customer_pool_aggregate_usage source
CREATE OR REPLACE VIEW public.vw_customer_pool_aggregate_usage
AS WITH combined_data AS (
         SELECT customer_rate_pool.id AS customer_rate_pool_id,
            customer_rate_pool.name AS customer_rate_pool_name,
            customer_rate_pool.service_provider_id,
            serviceprovider.display_name AS service_provider_name,
            customer_rate_pool.tenant_id,
            sum(COALESCE(mobility_device.carrier_cycle_usage::numeric, 0.0)) AS data_usage_bytes,
            sum(COALESCE(mobility_device_tenant.customer_data_allocation_mb, customerrateplan.plan_mb)) AS customer_data_allocation_mb,
            count(*) AS num_records,
            serviceprovider.integration_id,
            max(customer_rate_pool.modified_date) AS modified_date
           FROM customer_rate_pool customer_rate_pool
             JOIN mobility_device_tenant mobility_device_tenant ON mobility_device_tenant.customer_rate_pool_id = customer_rate_pool.id
             JOIN mobility_device mobility_device ON mobility_device_tenant.mobility_device_id = mobility_device.id AND mobility_device.service_provider_id = customer_rate_pool.service_provider_id
             JOIN serviceprovider serviceprovider ON customer_rate_pool.service_provider_id = serviceprovider.id
             JOIN customerrateplan customerrateplan ON mobility_device_tenant.customer_rate_plan_id = customerrateplan.id
          WHERE customer_rate_pool.is_active = true AND mobility_device.is_active = true AND serviceprovider.is_active = true AND customerrateplan.is_active = true
          GROUP BY customer_rate_pool.id, customer_rate_pool.name, customer_rate_pool.service_provider_id, serviceprovider.display_name, customer_rate_pool.tenant_id, serviceprovider.integration_id
        UNION ALL
         SELECT customer_rate_pool.id AS customer_rate_pool_id,
            customer_rate_pool.name AS customer_rate_pool_name,
            customer_rate_pool.service_provider_id,
            serviceprovider.display_name AS service_provider_name,
            customer_rate_pool.tenant_id,
            sum(COALESCE(device.carrier_cycle_usage::numeric, 0.0)) AS data_usage_bytes,
            sum(COALESCE(device_tenant.customer_data_allocation_mb, customerrateplan.plan_mb)) AS customer_data_allocation_mb,
            count(*) AS num_records,
            serviceprovider.integration_id,
            max(customer_rate_pool.modified_date) AS modified_date
           FROM customer_rate_pool customer_rate_pool
             JOIN device_tenant device_tenant ON device_tenant.customer_rate_pool_id = customer_rate_pool.id
             JOIN device device ON device_tenant.device_id = device.id AND device.service_provider_id = customer_rate_pool.service_provider_id
             JOIN serviceprovider serviceprovider ON customer_rate_pool.service_provider_id = serviceprovider.id
             JOIN customerrateplan customerrateplan ON device_tenant.customer_rate_plan_id = customerrateplan.id
          WHERE customer_rate_pool.is_active = true AND device.is_active = true AND serviceprovider.is_active = true AND customerrateplan.is_active = true
          GROUP BY customer_rate_pool.id, customer_rate_pool.name, customer_rate_pool.service_provider_id, serviceprovider.display_name, customer_rate_pool.tenant_id, serviceprovider.integration_id
        )
 SELECT combined_data.customer_rate_pool_id,
    combined_data.customer_rate_pool_name,
    combined_data.service_provider_id,
    combined_data.service_provider_name,
    combined_data.tenant_id,
    combined_data.data_usage_bytes,
    combined_data.customer_data_allocation_mb,
    combined_data.num_records,
    combined_data.integration_id,
    row_number() OVER (ORDER BY (( SELECT NULL::text AS text))) AS id,
    combined_data.modified_date
   FROM combined_data;

-- public.vw_smi_projected_usage_customer_rate_pool source

CREATE OR REPLACE VIEW public.vw_smi_projected_usage_customer_rate_pool
AS SELECT sim_management_inventory.iccid,
    sim_management_inventory.msisdn,
    sim_management_inventory.service_provider_id,
    sim_management_inventory.service_provider_display_name,
    sim_management_inventory.billing_account_number,
    sim_management_inventory.foundation_account_number,
    sim_management_inventory.imei,
    sim_management_inventory.eid,
    sim_management_inventory.customer_id,
    sim_management_inventory.customer_name,
    sim_management_inventory.device_status_id,
    sim_management_inventory.sim_status,
    sim_management_inventory.carrier_cycle_usage_bytes,
    sim_management_inventory.billing_cycle_start_date,
    sim_management_inventory.billing_cycle_end_date,
    sim_management_inventory.carrier_rate_plan_id,
    sim_management_inventory.carrier_rate_plan_name,
    sim_management_inventory.customer_rate_plan_id,
    sim_management_inventory.customer_rate_plan_name,
    sim_management_inventory.customer_rate_pool_id,
    sim_management_inventory.customer_rate_pool_name,
    now()::date AS "current_date",
    date_part('day'::text, now()::date::timestamp without time zone - sim_management_inventory.billing_cycle_start_date) AS days_passed,
    date_part('day'::text, sim_management_inventory.billing_cycle_end_date - now()::date::timestamp without time zone) AS remaining_days,
        CASE
            WHEN date_part('day'::text, now()::date::timestamp without time zone - sim_management_inventory.billing_cycle_start_date) > 0::double precision THEN sim_management_inventory.carrier_cycle_usage_bytes::double precision / date_part('day'::text, now()::date::timestamp without time zone - sim_management_inventory.billing_cycle_start_date)
            ELSE 0::double precision
        END AS usage_per_day,
        CASE
            WHEN date_part('day'::text, now()::date::timestamp without time zone - sim_management_inventory.billing_cycle_start_date) > 0::double precision THEN sim_management_inventory.carrier_cycle_usage_bytes::double precision / date_part('day'::text, now()::date::timestamp without time zone - sim_management_inventory.billing_cycle_start_date) * date_part('day'::text, sim_management_inventory.billing_cycle_end_date - now()::date::timestamp without time zone)
            ELSE 0::double precision
        END AS projected_usage,
    sim_management_inventory.integration_id,
    sim_management_inventory.id
   FROM sim_management_inventory
  WHERE (sim_management_inventory.sim_status::text = ANY (ARRAY['Active'::character varying::text, 'ACTIVE'::character varying::text, 'A'::character varying::text, 'Activated'::character varying::text, 'ACTIVATED'::character varying::text, 'Online'::character varying::text, 'ONLINE'::character varying::text])) AND sim_management_inventory.is_active = true AND sim_management_inventory.is_deleted = false AND sim_management_inventory.tenant_id = 1 AND now()::date >= sim_management_inventory.billing_cycle_start_date AND now()::date < sim_management_inventory.billing_cycle_end_date;
-- public.vw_smi_projected_usage_by_customer_pool source

CREATE OR REPLACE VIEW public.vw_smi_projected_usage_by_customer_pool
AS WITH usage_data AS (
         SELECT sim_management_inventory.service_provider_display_name,
            sim_management_inventory.customer_rate_pool_name,
                CASE
                    WHEN date_part('day'::text, now()::date::timestamp without time zone - sim_management_inventory.billing_cycle_start_date) > 0::double precision THEN sim_management_inventory.carrier_cycle_usage_bytes::double precision / date_part('day'::text, now()::date::timestamp without time zone - sim_management_inventory.billing_cycle_start_date)
                    ELSE 0::double precision
                END AS usage_per_day,
                CASE
                    WHEN date_part('day'::text, now()::date::timestamp without time zone - sim_management_inventory.billing_cycle_start_date) > 0::double precision THEN sim_management_inventory.carrier_cycle_usage_bytes::double precision / date_part('day'::text, now()::date::timestamp without time zone - sim_management_inventory.billing_cycle_start_date) * date_part('day'::text, sim_management_inventory.billing_cycle_end_date - now()::date::timestamp without time zone)
                    ELSE 0::double precision
                END AS projected_usage,
            sim_management_inventory.service_provider_id,
            sim_management_inventory.integration_id
           FROM sim_management_inventory
          WHERE (sim_management_inventory.sim_status::text = ANY (ARRAY['Active'::text, 'ACTIVE'::text, 'A'::text, 'Activated'::text, 'ACTIVATED'::text, 'Online'::text, 'ONLINE'::text])) AND sim_management_inventory.is_active = true AND sim_management_inventory.is_deleted = false AND sim_management_inventory.tenant_id = 1 AND now()::date >= sim_management_inventory.billing_cycle_start_date AND now()::date < sim_management_inventory.billing_cycle_end_date
        )
 SELECT usage_data.service_provider_display_name,
    usage_data.customer_rate_pool_name,
    sum(usage_data.usage_per_day) AS total_usage_per_day,
    sum(usage_data.projected_usage) AS total_projected_usage,
    usage_data.service_provider_id,
    usage_data.integration_id
   FROM usage_data
  GROUP BY usage_data.service_provider_display_name, usage_data.customer_rate_pool_name, usage_data.service_provider_id, usage_data.integration_id
  ORDER BY usage_data.service_provider_display_name, usage_data.customer_rate_pool_name, usage_data.service_provider_id, usage_data.integration_id;
-- public.vw_customer_rate_pool_projected_usage source

CREATE OR REPLACE VIEW public.vw_customer_rate_pool_projected_usage
AS WITH summed_usage AS (
         SELECT vw_smi_projected_usage_by_customer_pool.customer_rate_pool_name,
            sum(vw_smi_projected_usage_by_customer_pool.total_projected_usage) AS total_projected_usage
           FROM vw_smi_projected_usage_by_customer_pool
          GROUP BY vw_smi_projected_usage_by_customer_pool.customer_rate_pool_name
        )
 SELECT row_number() OVER (ORDER BY crp.id)::integer AS id,
    crp.name,
    COALESCE(su.total_projected_usage, 0.0::double precision) AS projected_data_usage,
    crp.service_provider_id,
        CASE
            WHEN i.id = 12 THEN round((COALESCE(su.total_projected_usage, 0.0::double precision) / 1000.0::double precision / 1000.0::double precision)::numeric, 3)
            ELSE round((COALESCE(su.total_projected_usage, 0.0::double precision) / 1024.0::double precision / 1024.0::double precision)::numeric, 3)
        END AS projected_usage_mb,
    crp.tenant_id,
    crp.created_by,
    crp.created_date,
    crp.modified_by,
    crp.modified_date,
    crp.is_deleted,
    crp.is_active,
    COALESCE(crp.service_provider_name) AS service_provider_name,
    crp.id AS customer_rate_pool_id,
    crp.id::text AS pool_id
   FROM customer_rate_pool crp
     JOIN serviceprovider sp ON crp.service_provider_id = sp.id
     LEFT JOIN integration i ON sp.integration_id = i.id
     LEFT JOIN summed_usage su ON crp.name::text = su.customer_rate_pool_name::text
  WHERE crp.is_active = true AND crp.is_deleted = false AND sp.is_active = true AND sp.is_deleted = false;

-- public.vw_customer_rate_pool_usage_report source
CREATE OR REPLACE VIEW public.vw_customer_rate_pool_usage_report
AS SELECT customer_rate_pool.customer_rate_pool_id,
    customer_rate_pool.customer_rate_pool_name,
    customer_rate_pool.customer_rate_pool_usage_mb,
    customer_rate_pool.customer_rate_pool_allocated_mb,
    customer_rate_pool.customer_rate_pool_allocated_mb - customer_rate_pool.customer_rate_pool_usage_mb AS customer_rate_pool_data_remaining,
        CASE
            WHEN COALESCE(customer_rate_pool.customer_rate_pool_allocated_mb, 0::numeric) = 0::numeric THEN 0::numeric
            ELSE (customer_rate_pool.customer_rate_pool_usage_mb * 100::numeric / customer_rate_pool.customer_rate_pool_allocated_mb)::numeric(18,2)
        END AS customer_rate_pool_data_usage_percentage,
    customer_rate_pool.customer_rate_pool_device_count,
    customer_rate_pool.customer_rate_pool_tenant_id,
    serviceprovider.id AS service_provider_id,
    serviceprovider.display_name AS service_provider_name,
    integration.portal_type_id,
    mobility_device.msisdn AS subscriber_number,
        CASE
            WHEN integration.id = 12 THEN round(COALESCE(mobility_device.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 4)
            ELSE round(COALESCE(mobility_device.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 4)
        END AS data_usage_mb,
    COALESCE(device_tenant.customer_data_allocation_mb, COALESCE(customerrateplan.plan_mb, 0.0)) AS data_allocation_mb,
    device_tenant.account_number,
    site_info.tenant_id,
    site_info.id AS customer_id,
    site_info.parent_customer_id,
    site_info.customer_name,
    COALESCE(mobility_device.amop_username, mobility_device.username) AS username,
    customerrateplan.rate_plan_name AS customer_rate_plan_name,
    customerrateplan.overage_rate_cost,
    customerrateplan.data_per_overage_charge,
    mobility_device.iccid,
    serviceprovider.integration_id,
    billing_period.billing_cycle_end_date AS billing_period_end_date,
    billing_period.billing_cycle_start_date AS billing_period_start_date,
    device_tenant.is_active,
    customer_rate_pool.modified_date,
    customer_rate_pool.customer_rate_pool_usage_mb + customer_rate_pool.customer_rate_pool_allocated_mb AS total_used,
    array_to_string(array_remove(ARRAY[device_tenant.id, mobility_device.id, serviceprovider.id, integration.id], NULL::integer), '-'::text) AS id
   FROM ( SELECT vw_customer_pool_aggregate_usage.customer_rate_pool_id,
            vw_customer_pool_aggregate_usage.customer_rate_pool_name,
                CASE
                    WHEN vw_customer_pool_aggregate_usage.integration_id = 12 THEN round(vw_customer_pool_aggregate_usage.data_usage_bytes / 1000.0 / 1000.0, 4)
                    ELSE round(vw_customer_pool_aggregate_usage.data_usage_bytes / 1024.0 / 1024.0, 4)
                END AS customer_rate_pool_usage_mb,
            vw_customer_pool_aggregate_usage.customer_data_allocation_mb AS customer_rate_pool_allocated_mb,
            vw_customer_pool_aggregate_usage.num_records AS customer_rate_pool_device_count,
            vw_customer_pool_aggregate_usage.tenant_id AS customer_rate_pool_tenant_id,
            vw_customer_pool_aggregate_usage.service_provider_id,
            vw_customer_pool_aggregate_usage.modified_date
           FROM vw_customer_pool_aggregate_usage) customer_rate_pool
     JOIN mobility_device_tenant device_tenant ON device_tenant.customer_rate_pool_id = customer_rate_pool.customer_rate_pool_id
     JOIN mobility_device ON mobility_device.id = device_tenant.mobility_device_id
     JOIN serviceprovider ON mobility_device.service_provider_id = serviceprovider.id AND serviceprovider.is_active = true
     JOIN integration ON integration.id = serviceprovider.integration_id
     JOIN device_status ON device_status.id = mobility_device.device_status_id
     LEFT JOIN billing_period ON billing_period.id = mobility_device.billing_period_id
     LEFT JOIN customerrateplan ON device_tenant.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customers site_info ON device_tenant.customer_id = site_info.id AND site_info.is_active = true
     LEFT JOIN revcustomer account_info ON site_info.rev_customer_id = account_info.id AND account_info.is_active = true AND account_info.is_deleted = false
  WHERE mobility_device.is_active = true AND customerrateplan.is_active = true AND integration.portal_type_id = 2 AND mobility_device.billing_period_id = (( SELECT billing_period_1.id
           FROM billing_period billing_period_1
          WHERE billing_period_1.service_provider_id = mobility_device.service_provider_id AND billing_period_1.is_active = true
          ORDER BY billing_period_1.bill_year DESC, billing_period_1.bill_month DESC
         LIMIT 1)) AND (device_status.is_active_status = true OR mobility_device.last_activated_date < billing_period.billing_cycle_end_date AND mobility_device.last_activated_date > billing_period.billing_cycle_start_date)
UNION ALL
 SELECT customer_rate_pool.customer_rate_pool_id,
    customer_rate_pool.customer_rate_pool_name,
    customer_rate_pool.customer_rate_pool_usage_mb,
    customer_rate_pool.customer_rate_pool_allocated_mb,
    customer_rate_pool.customer_rate_pool_allocated_mb - customer_rate_pool.customer_rate_pool_usage_mb AS customer_rate_pool_data_remaining,
        CASE
            WHEN COALESCE(customer_rate_pool.customer_rate_pool_allocated_mb, 0::numeric) = 0::numeric THEN 0::numeric
            ELSE round(customer_rate_pool.customer_rate_pool_usage_mb * 100.0 / customer_rate_pool.customer_rate_pool_allocated_mb, 2)
        END AS customer_rate_pool_data_usage_percentage,
    customer_rate_pool.customer_rate_pool_device_count,
    customer_rate_pool.customer_rate_pool_tenant_id,
    serviceprovider.id AS service_provider_id,
    serviceprovider.display_name AS service_provider_name,
    integration.portal_type_id,
    device.msisdn AS subscriber_number,
        CASE
            WHEN integration.id = 12 THEN round(COALESCE(device.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 4)::numeric(25,4)
            ELSE round(COALESCE(device.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 4)::numeric(25,4)
        END AS data_usage_mb,
    COALESCE(device_tenant.customer_data_allocation_mb, COALESCE(customerrateplan.plan_mb, 0.0)) AS data_allocation_mb,
    device_tenant.account_number,
    customers.tenant_id,
    customers.id AS customer_id,
    customers.parent_customer_id,
    customers.customer_name,
    device.username,
    customerrateplan.rate_plan_name AS customer_rate_plan_name,
    customerrateplan.overage_rate_cost,
    customerrateplan.data_per_overage_charge,
    device.iccid,
    integration.id AS integration_id,
    billing_period.billing_cycle_end_date AS billing_period_end_date,
    billing_period.billing_cycle_start_date AS billing_period_start_date,
    device_tenant.is_active,
    customer_rate_pool.modified_date,
    customer_rate_pool.customer_rate_pool_usage_mb + customer_rate_pool.customer_rate_pool_allocated_mb AS total_used,
    array_to_string(array_remove(ARRAY[device_tenant.id, device.id, serviceprovider.id, integration.id], NULL::integer), '-'::text) AS id
   FROM ( SELECT vw_m2m_customer_pool_aggregate_usage.customer_rate_pool_id,
            vw_m2m_customer_pool_aggregate_usage.customer_rate_pool_name,
                CASE
                    WHEN vw_m2m_customer_pool_aggregate_usage.integration_id = 12 THEN round(vw_m2m_customer_pool_aggregate_usage.data_usage_bytes / 1000.0 / 1000.0, 4)::numeric(25,4)
                    ELSE round(vw_m2m_customer_pool_aggregate_usage.data_usage_bytes / 1024.0 / 1024.0, 4)::numeric(25,4)
                END AS customer_rate_pool_usage_mb,
            vw_m2m_customer_pool_aggregate_usage.customer_data_allocation_mb AS customer_rate_pool_allocated_mb,
            vw_m2m_customer_pool_aggregate_usage.num_records AS customer_rate_pool_device_count,
            vw_m2m_customer_pool_aggregate_usage.tenant_id AS customer_rate_pool_tenant_id,
            vw_m2m_customer_pool_aggregate_usage.service_provider_id,
            vw_m2m_customer_pool_aggregate_usage.modified_date
           FROM vw_m2m_customer_pool_aggregate_usage) customer_rate_pool
     JOIN device_tenant device_tenant ON device_tenant.customer_rate_pool_id = customer_rate_pool.customer_rate_pool_id
     JOIN device device ON device.id = device_tenant.device_id
     JOIN serviceprovider ON customer_rate_pool.service_provider_id = serviceprovider.id AND serviceprovider.is_active = true AND serviceprovider.is_deleted = false
     JOIN integration ON integration.id = serviceprovider.integration_id
     JOIN device_status ON device_status.id = device.device_status_id
     JOIN billing_period ON billing_period.id = device.billing_period_id
     LEFT JOIN customerrateplan ON device_tenant.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customers ON device_tenant.customer_id = customers.id AND customers.is_active = true AND customers.is_deleted = false
     LEFT JOIN revcustomer ON customers.rev_customer_id = revcustomer.id AND revcustomer.is_active = true AND revcustomer.is_deleted = false
  WHERE device.is_active = true AND customerrateplan.is_active = true AND integration.portal_type_id = 0 AND device.billing_period_id = (( SELECT billing_period_1.id
           FROM billing_period billing_period_1
          WHERE billing_period_1.service_provider_id = device.service_provider_id AND billing_period_1.is_active = true AND billing_period_1.is_deleted = false
          ORDER BY billing_period_1.bill_year DESC, billing_period_1.bill_month DESC
         LIMIT 1)) AND (device_status.is_active_status = true OR device.last_activated_date < billing_period.billing_cycle_end_date AND device.last_activated_date > billing_period.billing_cycle_end_date);

-- public.vw_daily_usage_report source
CREATE OR REPLACE VIEW public.vw_daily_usage_report
AS SELECT row_number() OVER (ORDER BY sm.id)::integer AS id,
    sm.service_provider_display_name AS service_provider,
    bp.billing_cycle_end_date,
    sm.iccid,
    sm.msisdn,
    sm.foundation_account_number,
    sm.billing_account_number,
    sm.customer_rate_pool_name AS customer_pool,
    sm.customer_name,
    sm.username,
    sm.carrier_rate_plan_name AS carrier_rate_plan,
    sm.customer_rate_plan_name AS customer_rate_plan,
    sp.integration_id,
        CASE
            WHEN sp.integration_id = 12 THEN round(COALESCE(sm.carrier_cycle_usage_bytes::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(sm.carrier_cycle_usage_bytes::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS datausagemb,
    sm.carrier_cycle_usage_bytes AS carrier_cycle_usage,
    sm.sim_status,
    sm.date_activated,
    sm.created_date,
    sm.modified_date,
    sm.is_active,
    sm.tenant_id
   FROM sim_management_inventory sm
     JOIN serviceprovider sp ON sm.service_provider_id = sp.id
     LEFT JOIN billing_period bp ON sm.billing_period_id = bp.id;

-- public.vw_device_bulk_change source

CREATE OR REPLACE VIEW public.vw_device_bulk_change
AS SELECT bc.id,
    bc.id AS bulk_change_id,
    bc.service_provider_id,
    bc.service_provider,
    bc.tenant_id,
    bc.change_request_type_id,
    bc.change_request_type,
    bc.status,
    count(*) AS uploaded,
    count(
        CASE
            WHEN rt.is_processed AND NOT rt.has_errors THEN 1
            ELSE NULL::integer
        END) AS success,
    count(
        CASE
            WHEN rt.is_processed AND rt.has_errors THEN 1
            ELSE NULL::integer
        END) AS errors,
    bc.customer_id,
    bc.app_file_id,
    bc.processed_date,
    bc.processed_by,
    bc.created_by,
    bc.created_date,
    bc.modified_by,
    bc.modified_date,
    bc.deleted_by,
    bc.deleted_date,
    bc.is_deleted,
    bc.is_active,
    c.customer_name,
    bc.progress AS sync_status,
    bc.readme_flag
   FROM sim_management_bulk_change bc
     JOIN sim_management_bulk_change_request rt ON bc.id = rt.bulk_change_id AND rt.is_active = true
     LEFT JOIN customers c ON c.id = bc.customer_id
  WHERE bc.is_active = true
  GROUP BY bc.id, bc.service_provider_id, bc.service_provider, bc.tenant_id, bc.change_request_type_id, bc.change_request_type, bc.status, bc.customer_id, bc.app_file_id, bc.processed_date, bc.processed_by, bc.created_by, bc.created_date, bc.modified_by, bc.modified_date, bc.deleted_by, bc.deleted_date, bc.is_deleted, bc.is_active, c.customer_name, bc.progress;

-- public.vw_device_high_usage_scatter_chart source
-- public.vw_device_high_usage_scatter_chart source

CREATE OR REPLACE VIEW public.vw_device_high_usage_scatter_chart
AS SELECT row_number() OVER (ORDER BY dt.id)::integer AS id,
    dt.device_id,
        CASE
            WHEN i.id = 12 THEN round(smi.carrier_cycle_usage::numeric / 1000.0 / 1000.0, 3)
            ELSE round(smi.carrier_cycle_usage::numeric / 1024.0 / 1024.0, 3)
        END AS ctd_data_usage_mb,
    smi.ctd_session_count,
    dt.account_number,
    smi.iccid,
    smi.msisdn,
    smi.service_provider_id,
    sp.service_provider_name,
    c.tenant_id AS customer_tenant_id,
    i.portal_type_id,
    c.id AS customer_id,
    c.parent_customer_id,
    c.customer_name,
    dt.tenant_id
   FROM device smi
     JOIN device_tenant dt ON dt.device_id = smi.id
     JOIN serviceprovider sp ON sp.id = smi.service_provider_id
     LEFT JOIN customers c ON dt.customer_id = c.id
     LEFT JOIN integration i ON i.id = sp.integration_id
  WHERE smi.is_active = true AND smi.is_deleted = false AND smi.carrier_cycle_usage > 0 AND (smi.sim_status::text = 'a'::text OR smi.sim_status::text = 'A'::text OR smi.sim_status::text = 'Activated'::text OR smi.sim_status::text = 'ACTIVATED'::text OR smi.sim_status::text = 'active'::text OR smi.sim_status::text = 'Active'::text);

-- public.vw_history_zero_usage_report source

CREATE OR REPLACE VIEW public.vw_history_zero_usage_report
AS SELECT jd.device_history_id,
    jd.iccid,
    jd.msisdn,
    jd.rate_plan AS carrier_rate_plan,
    jds.display_name AS status,
    jd.communication_plan,
    dt.account_number,
    s.customer_name,
    jd.created_by,
    jd.created_date,
    jd.modified_by,
    jd.modified_date,
    jd.deleted_by,
    jd.deleted_date,
    jd.is_active,
    jd.is_deleted,
    sp.display_name AS service_provider_name,
    jd.last_usage_date,
    jd.billing_cycle_end_date,
    crp.rate_plan_name AS customer_rate_plan_name,
    jd.customer_rate_plan_id
   FROM device_history jd
     JOIN device_tenant dt ON jd.device_tenant_id = dt.id
     JOIN serviceprovider sp ON jd.service_provider_id = sp.id
     JOIN integration i ON sp.integration_id = i.id
     LEFT JOIN customers s ON s.id = dt.customer_id
     LEFT JOIN device_status jds ON jds.id = jd.device_status_id
     LEFT JOIN revcustomer account_info ON s.rev_customer_id = account_info.id
     LEFT JOIN customerrateplan crp ON jd.customer_rate_plan_id = crp.id
  WHERE jds.is_active_status = true AND jd.carrier_cycle_usage = 0 AND i.portal_type_id = 0
UNION ALL
 SELECT jd.device_history_id,
    jd.iccid,
    jd.msisdn,
    jd.rate_plan AS carrier_rate_plan,
    jds.display_name AS status,
    NULL::character varying AS communication_plan,
    jd.account_number,
    s.customer_name,
    jd.created_by,
    jd.created_date,
    jd.modified_by,
    jd.modified_date,
    jd.deleted_by,
    jd.deleted_date,
    jd.is_active,
    jd.is_deleted,
    sp.display_name AS service_provider_name,
    jd.last_usage_date,
    bp.billing_cycle_end_date,
    crp.rate_plan_name AS customer_rate_plan_name,
    jd.customer_rate_plan_id
   FROM mobility_device_history jd
     JOIN serviceprovider sp ON jd.service_provider_id = sp.id
     JOIN integration i ON sp.integration_id = i.id
     LEFT JOIN customers s ON s.id = jd.customer_id
     LEFT JOIN device_status jds ON jds.id = jd.device_status_id
     LEFT JOIN revcustomer account_info ON account_info.id = s.rev_customer_id
     LEFT JOIN billing_period bp ON jd.billing_period_id = bp.id
     LEFT JOIN customerrateplan crp ON jd.customer_rate_plan_id = crp.id
  WHERE (jds.display_name::text = 'Activated'::text OR jds.display_name::text = 'Active'::text) AND jd.carrier_cycle_usage = 0 AND i.portal_type_id = 2;

-- public.vw_mobility_sim_cards_by_carrier_rate_plan_limit_report source

-- public.vw_mobility_sim_cards_by_carrier_rate_plan_limit_report source

CREATE OR REPLACE VIEW public.vw_mobility_sim_cards_by_carrier_rate_plan_limit_report
AS SELECT COALESCE(gen_random_uuid(), gen_random_uuid()) AS id,
    smi.service_provider_id,
    sp.service_provider_name,
    mt.account_number,
    count(1) AS sim_count,
    sum(COALESCE(smi.carrier_cycle_usage_bytes, 0::bigint)) AS carrier_cycle_usage,
    sum(COALESCE(smi.ctd_session_count, 0::bigint)) AS ctd_session_count,
    c.tenant_id,
    i.portal_type_id,
    crp.plan_mb,
    c.id AS customer_id,
    c.parent_customer_id,
    c.customer_name
   FROM sim_management_inventory smi
     JOIN mobility_device_tenant mt ON smi.mobility_device_id = mt.mobility_device_id
     JOIN serviceprovider sp ON smi.service_provider_id = sp.id
     JOIN device_status ds ON smi.device_status_id = ds.id
     LEFT JOIN carrier_rate_plan crp ON crp.id = smi.carrier_rate_plan_id
     LEFT JOIN customers c ON mt.customer_id = c.id
     LEFT JOIN integration i ON i.id = sp.integration_id
  WHERE smi.is_active = true AND smi.is_deleted = false AND ds.is_active_status = true
  GROUP BY smi.service_provider_id, sp.service_provider_name, mt.account_number, crp.plan_mb, i.portal_type_id, c.id, c.parent_customer_id, c.customer_name, c.tenant_id;


-- public.vw_mobility_sim_cards_by_customer_rate_plan_limit_report source

CREATE OR REPLACE VIEW public.vw_mobility_sim_cards_by_customer_rate_plan_limit_report
AS SELECT COALESCE(gen_random_uuid(), gen_random_uuid()) AS id,
    smi.service_provider_id,
    sp.service_provider_name,
    mt.account_number,
    count(1) AS sim_count,
    sum(COALESCE(smi.carrier_cycle_usage, 0::bigint)) AS carrier_cycle_usage,
    sum(COALESCE(smi.ctd_session_count, 0::bigint)) AS ctd_session_count,
    c.tenant_id,
    i.portal_type_id,
    crp.plan_mb,
    c.id AS customer_id,
    c.parent_customer_id,
    c.customer_name
   FROM mobility_device smi
     JOIN mobility_device_tenant mt ON smi.id = mt.mobility_device_id
     JOIN serviceprovider sp ON smi.service_provider_id = sp.id
     JOIN device_status ds ON smi.device_status_id = ds.id
     LEFT JOIN customerrateplan crp ON crp.id = mt.customer_rate_plan_id
     LEFT JOIN customers c ON mt.customer_id = c.id
     LEFT JOIN integration i ON i.id = sp.integration_id
  WHERE smi.is_active = true AND ds.is_active_status = true
  GROUP BY smi.service_provider_id, sp.service_provider_name, mt.account_number, crp.plan_mb, i.portal_type_id, c.id, c.parent_customer_id, c.customer_name, c.tenant_id;



CREATE OR REPLACE VIEW public.vw_mobility_status_history_report
AS SELECT row_number() OVER (ORDER BY dsh.id) AS id,
    dsh.id AS dsh_id,
    dsh.iccid,
    dsh.msisdn,
        CASE
            WHEN dsh.previous_status::text = dsh.current_status::text THEN ( SELECT previous_record.current_status
               FROM device_status_history previous_record
              WHERE previous_record.device_id = dsh.device_id AND (dsh.tenant_id IS NULL OR dsh.tenant_id = previous_record.tenant_id) AND previous_record.date_of_change < dsh.date_of_change
              ORDER BY previous_record.date_of_change DESC
             LIMIT 1)
            ELSE dsh.previous_status
        END AS previous_status,
    dsh.current_status,
    dsh.change_event_type,
    dsh.date_of_change,
    dsh.changed_by,
    dsh.is_deleted,
    dsh.service_provider_id,
    dsh.device_id,
    dsh.bulk_change_id,
    dsh.customer_name,
    dsh.customer_account_number,
    dsh.username,
    dsh.customer_rate_plan,
    dsh.customer_rate_pool,
    mdt.tenant_id,
    sp.display_name AS service_provider_name,
    mdt.customer_id,
    mdt.account_number_integration_authentication_id,
    bp.billing_cycle_start_date,
    bp.billing_cycle_end_date,
    md.modified_date,
    mdt.account_number
   FROM device_status_history dsh
     JOIN mobility_device md ON dsh.mobility_device_id = md.id
     JOIN serviceprovider sp ON md.service_provider_id = sp.id
     LEFT JOIN mobility_device_tenant mdt ON mdt.mobility_device_id = md.id AND (mdt.tenant_id = dsh.tenant_id OR dsh.tenant_id IS NULL)
     LEFT JOIN billing_period bp ON md.billing_period_id = bp.id
  WHERE dsh.date_of_change >= (now() - '30 days'::interval);



-- public.vw_mobility_usage_by_customer_pools source

CREATE OR REPLACE VIEW public.vw_mobility_usage_by_customer_pools
AS SELECT gen_random_uuid() AS id,
    customer_rate_pool.customer_rate_pool_id,
    customer_rate_pool.customer_rate_pool_name,
    customer_rate_pool.customer_rate_pool_usage_mb,
    customer_rate_pool.customer_rate_pool_allocated_mb,
    customer_rate_pool.customer_rate_pool_allocated_mb - customer_rate_pool.customer_rate_pool_usage_mb AS customer_rate_pool_data_remaining,
        CASE
            WHEN COALESCE(customer_rate_pool.customer_rate_pool_allocated_mb, 0::numeric) = 0::numeric THEN 0::numeric
            ELSE (customer_rate_pool.customer_rate_pool_usage_mb * 100::numeric / customer_rate_pool.customer_rate_pool_allocated_mb)::numeric(18,2)
        END AS customer_rate_pool_data_usage_percentage,
    customer_rate_pool.customer_rate_pool_device_count,
    customer_rate_pool.customer_rate_pool_tenant_id,
    serviceprovider.id AS service_provider_id,
    serviceprovider.display_name AS service_provider_name,
    integration.portal_type_id,
    mobility_device.msisdn AS subscriber_number,
        CASE
            WHEN integration.id = 12 THEN round(COALESCE(mobility_device.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 4)
            ELSE round(COALESCE(mobility_device.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 4)
        END AS data_usage_mb,
    COALESCE(device_tenant.customer_data_allocation_mb, COALESCE(customerrateplan.plan_mb, 0.0)) AS data_allocation_mb,
    device_tenant.account_number,
    site_info.tenant_id,
    site_info.id AS customer_id,
    site_info.parent_customer_id,
    site_info.customer_name,
    mobility_device.username,
    customerrateplan.rate_plan_name AS customer_rate_plan_name,
    customerrateplan.overage_rate_cost,
    customerrateplan.data_per_overage_charge,
    mobility_device.iccid,
    serviceprovider.integration_id,
    billing_period.billing_cycle_end_date AS billing_period_end_date,
    billing_period.billing_cycle_start_date AS billing_period_start_date
   FROM ( SELECT vw_customer_pool_aggregate_usage.customer_rate_pool_id,
            vw_customer_pool_aggregate_usage.customer_rate_pool_name,
                CASE
                    WHEN vw_customer_pool_aggregate_usage.integration_id = 12 THEN round(vw_customer_pool_aggregate_usage.data_usage_bytes / 1000.0 / 1000.0, 4)
                    ELSE round(vw_customer_pool_aggregate_usage.data_usage_bytes / 1024.0 / 1024.0, 4)
                END AS customer_rate_pool_usage_mb,
            vw_customer_pool_aggregate_usage.customer_data_allocation_mb AS customer_rate_pool_allocated_mb,
            vw_customer_pool_aggregate_usage.num_records AS customer_rate_pool_device_count,
            vw_customer_pool_aggregate_usage.tenant_id AS customer_rate_pool_tenant_id,
            vw_customer_pool_aggregate_usage.service_provider_id
           FROM vw_customer_pool_aggregate_usage) customer_rate_pool
     JOIN mobility_device_tenant device_tenant ON device_tenant.customer_rate_pool_id = customer_rate_pool.customer_rate_pool_id
     JOIN mobility_device ON mobility_device.id = device_tenant.mobility_device_id
     JOIN serviceprovider ON mobility_device.service_provider_id = serviceprovider.id AND serviceprovider.is_active = true
     JOIN integration ON integration.id = serviceprovider.integration_id
     JOIN device_status ON device_status.id = mobility_device.device_status_id
     LEFT JOIN billing_period ON billing_period.id = mobility_device.billing_period_id
     LEFT JOIN customerrateplan ON device_tenant.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customers site_info ON device_tenant.customer_id = site_info.id AND site_info.is_active = true
     LEFT JOIN revcustomer account_info ON site_info.rev_customer_id = account_info.id AND account_info.is_active = true
  WHERE mobility_device.is_active = true AND customerrateplan.is_active = true AND integration.portal_type_id = 2 AND mobility_device.billing_period_id = (( SELECT billing_period_1.id
           FROM billing_period billing_period_1
          WHERE billing_period_1.service_provider_id = mobility_device.service_provider_id AND billing_period_1.is_active = true
          ORDER BY billing_period_1.bill_year DESC, billing_period_1.bill_month DESC
         LIMIT 1)) AND (device_status.is_active_status = true OR mobility_device.last_activated_date < billing_period.billing_cycle_end_date AND mobility_device.last_activated_date > billing_period.billing_cycle_start_date);



-- public.vw_mobility_usage_by_group_pools source

-- public.vw_mobility_usage_by_group_pools source

CREATE OR REPLACE VIEW public.vw_mobility_usage_by_group_pools
AS SELECT DISTINCT ua.id,
    ua.foundation_account_number,
    ua.billing_account_number,
    ua.data_group_id,
    ua.pool_id,
    ua.data_usage,
    ua.data_total AS plan_limit_bytes,
        CASE
            WHEN COALESCE(ua.data_total, 0::bigint) = 0 THEN NULL::bigint
            ELSE ua.data_total - COALESCE(ua.data_usage, 0::bigint)
        END AS data_remaining,
        CASE
            WHEN COALESCE(ua.data_total, 0::bigint) = 0 THEN NULL::bigint::numeric
            ELSE (COALESCE(ua.data_usage, 0::bigint)::numeric * 100.0 / ua.data_total::numeric)::numeric(18,2)
        END AS data_usage_percentage,
        CASE
            WHEN COALESCE(ua.data_total, 0::bigint) = 0 THEN NULL::numeric
            ELSE ((ua.data_total - COALESCE(ua.data_usage, 0::bigint))::numeric * 100.0 / ua.data_total::numeric)::numeric(18,2)
        END AS data_remaining_percentage,
    ua.service_provider_id,
    sp.display_name AS service_provider_name,
    i.portal_type_id,
    COALESCE(pool_device_count.count, 0::bigint) AS pool_device_count,
    COALESCE(data_group_device_count.count, 0::bigint) AS data_group_device_count,
    ua.tenant_id
   FROM mobility_device_usage_aggregate ua
     JOIN serviceprovider sp ON ua.service_provider_id = sp.id
     JOIN integration i ON i.id = sp.integration_id
     LEFT JOIN telegence_device td ON ua.id = td.usage_aggregate_id
     LEFT JOIN e_bonding_device ebd ON ua.id = ebd.usage_aggregate_id
     LEFT JOIN mobility_device d ON td.subscriber_number::text = d.msisdn::text OR ebd.subscriber_number::text = d.msisdn::text
     LEFT JOIN mobility_device_tenant dt ON d.id = dt.mobility_device_id
     LEFT JOIN customers c ON dt.customer_id = c.id
     LEFT JOIN revcustomer r ON c.rev_customer_id = r.id
     LEFT JOIN ( SELECT sim_management_inventory.pool_id,
            count(1) AS count
           FROM sim_management_inventory
          WHERE sim_management_inventory.is_deleted = false
          GROUP BY sim_management_inventory.pool_id) pool_device_count ON ua.pool_id::text = pool_device_count.pool_id::text
     LEFT JOIN ( SELECT sim_management_inventory.data_group_id,
            count(1) AS count
           FROM sim_management_inventory
          WHERE sim_management_inventory.is_deleted = false
          GROUP BY sim_management_inventory.data_group_id) data_group_device_count ON ua.data_group_id::text = data_group_device_count.data_group_id::text
  WHERE (COALESCE(ua.data_group_id, ''::character varying)::text <> ''::text OR COALESCE(ua.pool_id, ''::character varying)::text <> ''::text) AND (d.is_active IS NULL OR d.is_active = true);



-- public.vw_newly_activated_report source

CREATE OR REPLACE VIEW public.vw_newly_activated_report
AS SELECT combined.composite_id AS id,
    combined.device_id,
    combined.iccid,
    combined.msisdn,
    combined.carrier_rate_plan,
    combined.status,
    combined.communication_plan,
    combined.account_number,
    combined.customer_name,
    combined.date_activated,
    combined.service_provider_id,
    combined.service_provider_name AS service_provider,
    combined.created_date,
    combined.created_by,
    combined.modified_by,
    combined.modified_date,
    combined.deleted_by,
    combined.deleted_date,
    combined.is_active,
    combined.is_deleted,
    combined.ip_address,
    combined.last_usage_date,
    combined.billing_cycle_start_date,
    combined.billing_cycle_end_date,
    combined.customer_rate_plan_name,
    combined.customer_rate_plan_id,
    combined.tenant_id,
    combined.billing_account_number
   FROM ( SELECT jd.id AS device_id,
            jd.iccid,
            jd.msisdn,
            jd.carrier_rate_plan,
            jds.display_name AS status,
            jd.communication_plan,
            dt.account_number,
            account_info.customer_name,
            jd.date_activated,
            jd.service_provider_id,
            sp.display_name AS service_provider_name,
            jd.created_date,
            jd.created_by,
            jd.modified_by,
            jd.modified_date,
            jd.deleted_by,
            jd.deleted_date,
            jd.is_active,
            jd.is_deleted,
            jd.ip_address,
            jd.last_usage_date,
            bp.billing_cycle_start_date,
            bp.billing_cycle_end_date,
            crp.rate_plan_name AS customer_rate_plan_name,
            dt.customer_rate_plan_id,
            dt.tenant_id,
            NULL::character varying AS billing_account_number,
            array_to_string(array_remove(ARRAY[jd.id, dt.id, sp.id, i.id], NULL::integer), '-'::text) AS composite_id
           FROM device jd
             JOIN device_tenant dt ON jd.id = dt.device_id
             JOIN serviceprovider sp ON jd.service_provider_id = sp.id
             JOIN integration i ON sp.integration_id = i.id
             LEFT JOIN customers s ON s.id = dt.customer_id
             LEFT JOIN device_status jds ON jds.id = jd.device_status_id
             LEFT JOIN revcustomer account_info ON s.rev_customer_id = account_info.id
             LEFT JOIN customerrateplan crp ON dt.customer_rate_plan_id = crp.id
             LEFT JOIN billing_period bp ON jd.billing_period_id = bp.id
          WHERE jds.is_active_status = true AND i.portal_type_id = 0 AND jd.date_activated >= (CURRENT_DATE - '1 day'::interval * COALESCE(30, 30)::double precision)
        UNION ALL
         SELECT jd.id AS device_id,
            jd.iccid,
            jd.msisdn,
            jd.carrier_rate_plan,
            jds.display_name AS status,
            NULL::character varying AS communication_plan,
            dt.account_number,
            account_info.customer_name,
            jd.date_activated,
            jd.service_provider_id,
            sp.display_name AS service_provider_name,
            jd.created_date,
            jd.created_by,
            jd.modified_by,
            jd.modified_date,
            jd.deleted_by,
            jd.deleted_date,
            jd.is_active,
            jd.is_deleted,
            jd.ip_address,
            jd.last_usage_date,
            bp.billing_cycle_start_date,
            bp.billing_cycle_end_date,
            crp.rate_plan_name AS customer_rate_plan_name,
            dt.customer_rate_plan_id,
            dt.tenant_id,
            jd.billing_account_number,
            array_to_string(array_remove(ARRAY[jd.id, dt.id, sp.id, i.id], NULL::integer), '-'::text) AS composite_id
           FROM mobility_device jd
             JOIN mobility_device_tenant dt ON jd.id = dt.mobility_device_id
             JOIN serviceprovider sp ON jd.service_provider_id = sp.id
             JOIN integration i ON sp.integration_id = i.id
             LEFT JOIN customers s ON s.id = dt.customer_id
             LEFT JOIN device_status jds ON jds.id = jd.device_status_id
             LEFT JOIN revcustomer account_info ON account_info.id = s.rev_customer_id
             LEFT JOIN billing_period bp ON jd.billing_period_id = bp.id
             LEFT JOIN customerrateplan crp ON dt.customer_rate_plan_id = crp.id
          WHERE jds.is_active_status = true AND i.portal_type_id = 2 AND jd.date_activated >= (CURRENT_DATE - '1 day'::interval * COALESCE(30, 30)::double precision)) combined;

-- public.vw_status_history_report source

-- public.vw_status_history_report source

CREATE OR REPLACE VIEW public.vw_status_history_report
AS SELECT combined.composite_id AS id,
    combined.dsh_id,
    combined.iccid,
    combined.msisdn,
    combined.previous_status,
    combined.current_status,
    combined.change_event_type,
    combined.date_of_change,
    combined.changed_by,
    combined.is_deleted,
    combined.service_provider_id,
    combined.device_id,
    combined.bulk_change_id,
    combined.customer_name,
    combined.customer_account_number,
    combined.username,
    combined.customer_rate_plan,
    combined.customer_rate_pool,
    combined.tenant_id,
    combined.service_provicer_name AS service_provider_display_name,
    combined.customer_id,
    combined.account_number_integration_authentication_id,
    combined.billing_cycle_start_date,
    combined.billing_cycle_end_date,
    combined.modified_date,
    combined.account_number
   FROM ( SELECT dsh.id AS dsh_id,
            dsh.iccid,
            dsh.msisdn,
                CASE
                    WHEN dsh.previous_status::text = dsh.current_status::text THEN ( SELECT previous_record.current_status
                       FROM device_status_history previous_record
                      WHERE previous_record.device_id = dsh.device_id AND (dsh.tenant_id IS NULL OR dsh.tenant_id = previous_record.tenant_id) AND previous_record.date_of_change < dsh.date_of_change
                      ORDER BY previous_record.date_of_change DESC
                     LIMIT 1)
                    ELSE dsh.previous_status
                END AS previous_status,
            dsh.current_status,
            dsh.change_event_type,
            dsh.date_of_change,
            dsh.changed_by,
            dsh.is_deleted,
            dsh.service_provider_id,
            dsh.device_id,
            dsh.bulk_change_id,
            dsh.customer_name,
            dsh.customer_account_number,
            dsh.username,
            dsh.customer_rate_plan,
            dsh.customer_rate_pool,
            dt.tenant_id,
            sp.display_name AS service_provicer_name,
            dt.customer_id,
            dt.account_number_integration_authentication_id,
            bp.billing_cycle_start_date,
            bp.billing_cycle_end_date,
            COALESCE(dsh.modified_date, dsh.created_date) AS modified_date,
            dt.account_number,
            array_to_string(array_remove(ARRAY[dsh.id, sp.id, dt.id, d.id], NULL::integer), '-'::text) AS composite_id
           FROM device_status_history dsh
             JOIN device d ON dsh.device_id = d.id
             JOIN serviceprovider sp ON d.service_provider_id = sp.id
             LEFT JOIN device_tenant dt ON dt.device_id = d.id AND (dt.tenant_id = dsh.tenant_id OR dsh.tenant_id IS NULL)
             LEFT JOIN billing_period bp ON d.billing_period_id = bp.id
        UNION ALL
         SELECT dsh.id AS dsh_id,
            dsh.iccid,
            dsh.msisdn,
                CASE
                    WHEN dsh.previous_status::text = dsh.current_status::text THEN ( SELECT previous_record.current_status
                       FROM device_status_history previous_record
                      WHERE previous_record.device_id = dsh.device_id AND (dsh.tenant_id IS NULL OR dsh.tenant_id = previous_record.tenant_id) AND previous_record.date_of_change < dsh.date_of_change
                      ORDER BY previous_record.date_of_change DESC
                     LIMIT 1)
                    ELSE dsh.previous_status
                END AS previous_status,
            dsh.current_status,
            dsh.change_event_type,
            dsh.date_of_change,
            dsh.changed_by,
            dsh.is_deleted,
            dsh.service_provider_id,
            dsh.device_id,
            dsh.bulk_change_id,
            dsh.customer_name,
            dsh.customer_account_number,
            dsh.username,
            dsh.customer_rate_plan,
            dsh.customer_rate_pool,
            mdt.tenant_id,
            sp.display_name AS service_provider_name,
            mdt.customer_id,
            mdt.account_number_integration_authentication_id,
            bp.billing_cycle_start_date,
            bp.billing_cycle_end_date,
            COALESCE(dsh.modified_date, dsh.created_date) AS modified_date,
            mdt.account_number,
            array_to_string(array_remove(ARRAY[dsh.id, sp.id, mdt.id, md.id], NULL::integer), '-'::text) AS composite_id
           FROM device_status_history dsh
             JOIN mobility_device md ON dsh.mobility_device_id = md.id
             JOIN serviceprovider sp ON md.service_provider_id = sp.id
             LEFT JOIN mobility_device_tenant mdt ON mdt.mobility_device_id = md.id AND (mdt.tenant_id = dsh.tenant_id OR dsh.tenant_id IS NULL)
             LEFT JOIN billing_period bp ON md.billing_period_id = bp.id) combined;

-- public.vw_usage_by_line_from_devices source
-- public.vw_usage_by_line_from_devices source

CREATE OR REPLACE VIEW public.vw_usage_by_line_from_devices
AS SELECT combined.composite_id AS id,
    combined.device_id,
    combined.billing_cycle_start_date,
    combined.billing_cycle_end_date,
    combined.service_provider_id,
    combined.service_provider_name,
    combined.integration_id,
    combined.iccid,
    combined.msisdn,
    combined.imei,
    combined.carrier_rate_plan,
    combined.data_usage_mb,
    combined.date_added,
    combined.date_activated,
    combined.rate_plan_code,
    combined.rate_plan_name,
    combined.allows_sim_pooling,
    combined.plan_mb,
    combined.created_date,
    combined.created_by,
    combined.modified_by,
    combined.modified_date,
    combined.deleted_by,
    combined.deleted_date,
    combined.is_active,
    combined.is_deleted,
    combined.account_number,
    combined.carrier_rate_plan_id,
    combined.status_code,
    combined.status_display_name,
    combined.status_color_code,
    combined.customer_id,
    combined.tenant_id,
    combined.rev_customer_id,
    combined.customer_name,
    combined."coalesce",
    combined.customer_rate_pool_name,
    combined.foundation_account_number,
    combined.billing_account_number,
    combined.service_zip_code,
    combined.single_user_code,
    combined.single_user_code_description,
    combined.device_make,
    combined.device_model,
    combined.imei_type_id,
    combined.plan_limit_mb,
    combined.username,
    combined.ctd_voice_usage,
    combined.ip_address
   FROM ( SELECT d.id AS device_id,
            bp.billing_cycle_start_date,
            bp.billing_cycle_end_date,
            d.service_provider_id,
            s.display_name AS service_provider_name,
            s.integration_id,
            d.iccid,
            d.msisdn,
            d.imei,
            d.carrier_rate_plan,
                CASE
                    WHEN i.id = 12 THEN round(COALESCE(d.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
                    ELSE round(COALESCE(d.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
                END AS data_usage_mb,
            d.date_added,
            d.date_activated,
            crp.rate_plan_code,
            crp.rate_plan_name,
            crp.allows_sim_pooling,
            crp.plan_mb,
            d.created_date,
            d.created_by,
            d.modified_by,
            d.modified_date,
            d.deleted_by,
            d.deleted_date,
            d.is_active,
            d.is_deleted,
            dt.account_number,
            d.carrier_rate_plan_id,
            d.sim_status AS status_code,
            ds.display_name AS status_display_name,
            ds.status_color_code,
            c.customer_id,
            dt.tenant_id,
            rc.rev_customer_id,
            rc.customer_name,
            COALESCE(d.ctd_sms_usage, 0::bigint) AS "coalesce",
            crp2.name AS customer_rate_pool_name,
            NULL::character varying AS foundation_account_number,
            NULL::character varying AS billing_account_number,
            NULL::character varying AS service_zip_code,
            NULL::character varying AS single_user_code,
            NULL::character varying AS single_user_code_description,
            NULL::character varying AS device_make,
            NULL::character varying AS device_model,
            NULL::integer AS imei_type_id,
            NULL::numeric AS plan_limit_mb,
            d.username,
            d.ctd_voice_usage,
            d.ip_address,
            array_to_string(array_remove(ARRAY[d.id, dt.id, s.id, c.id, ds.id, i.id, crp.id, crp2.id, bp.id], NULL::integer), '-'::text) AS composite_id
           FROM device d
             JOIN device_tenant dt ON d.id = dt.device_id
             JOIN serviceprovider s ON d.service_provider_id = s.id
             LEFT JOIN customers c ON c.id = dt.customer_id
             LEFT JOIN device_status ds ON d.device_status_id = ds.id
             LEFT JOIN revcustomer rc ON c.rev_customer_id = rc.id
             LEFT JOIN integration i ON i.id = s.integration_id
             LEFT JOIN customerrateplan crp ON crp.id = dt.customer_rate_plan_id
             LEFT JOIN customer_rate_pool crp2 ON dt.customer_rate_pool_id = crp2.id
             LEFT JOIN billing_period bp ON d.billing_period_id = bp.id
          WHERE d.is_active = true AND d.is_deleted = false AND i.portal_type_id = 0 AND bp.id = (( SELECT billing_period.id
                   FROM billing_period
                  WHERE d.service_provider_id = billing_period.service_provider_id AND bp.is_active = true AND bp.is_deleted = false
                  ORDER BY billing_period.id DESC
                 LIMIT 1)) AND (ds.is_active_status = true OR d.last_activated_date < bp.billing_cycle_end_date AND d.last_activated_date > bp.billing_cycle_start_date OR d.carrier_cycle_usage > 0)
        UNION ALL
         SELECT md.id AS device_id,
            bp.billing_cycle_start_date,
            bp.billing_cycle_end_date,
            md.service_provider_id,
            s.display_name AS service_provider_name,
            s.integration_id,
            md.iccid,
            md.msisdn,
            md.imei,
            md.carrier_rate_plan,
                CASE
                    WHEN i.id = 12 THEN round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
                    ELSE round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
                END AS data_usage_mb,
            md.date_added,
            md.date_activated,
            crp.rate_plan_code,
            crp.rate_plan_name,
            crp.allows_sim_pooling,
            crp.plan_mb,
            md.created_date,
            md.created_by,
            md.modified_by,
            md.modified_date,
            md.deleted_by,
            md.deleted_date,
            md.is_active,
            md.is_deleted,
            mdt.account_number,
            md.carrier_rate_plan_id,
            md.sim_status AS status_code,
            ds.display_name AS status_display_name,
            ds.status_color_code,
            c.customer_id,
            mdt.tenant_id,
            rc.rev_customer_id,
            rc.customer_name,
            COALESCE(md.ctd_sms_usage, 0::bigint) AS "coalesce",
            crp2.name AS customer_rate_pool_name,
            md.foundation_account_number,
            md.billing_account_number,
            md.service_zip_code,
            md.single_user_code,
            md.single_user_code_description,
            md.device_make,
            md.device_model,
            md.imei_type_id,
            md.plan_limit_mb,
            COALESCE(md.amop_username, md.username) AS username,
            md.ctd_voice_usage,
            md.ip_address,
            array_to_string(array_remove(ARRAY[md.id, mdt.id, s.id, c.id, ds.id, i.id, crp.id, crp2.id, bp.id], NULL::integer), '-'::text) AS composite_id
           FROM mobility_device md
             JOIN mobility_device_tenant mdt ON mdt.mobility_device_id = md.id
             JOIN serviceprovider s ON s.id = md.service_provider_id
             LEFT JOIN customers c ON c.id = mdt.customer_id
             LEFT JOIN device_status ds ON md.device_status_id = ds.id
             LEFT JOIN revcustomer rc ON c.rev_customer_id = rc.id
             LEFT JOIN integration i ON i.id = s.integration_id
             LEFT JOIN customerrateplan crp ON crp.id = mdt.customer_rate_plan_id
             LEFT JOIN customer_rate_pool crp2 ON mdt.customer_rate_pool_id = crp2.id
             LEFT JOIN billing_period bp ON md.billing_period_id = bp.id
          WHERE md.is_active = true AND md.is_deleted = false AND i.portal_type_id = 2 AND bp.id = (( SELECT billing_period.id
                   FROM billing_period
                  WHERE md.service_provider_id = billing_period.service_provider_id AND bp.is_active = true AND bp.is_deleted = false
                  ORDER BY billing_period.id DESC
                 LIMIT 1)) AND (ds.is_active_status = true OR md.last_activated_date < bp.billing_cycle_end_date AND md.last_activated_date > bp.billing_cycle_start_date OR md.carrier_cycle_usage > 0)) combined;

-- public.vw_usage_by_line_report source
-- public.vw_usage_by_line_report source

CREATE OR REPLACE VIEW public.vw_usage_by_line_report
AS WITH mobility_bill_periods AS (
         SELECT billing_period.id
           FROM billing_period
          WHERE billing_period.is_active = true AND billing_period.is_deleted = false AND billing_period.service_provider_id = 6
        ), m2m_bill_periods AS (
         SELECT billing_period.id
           FROM billing_period
          WHERE billing_period.is_active = true AND billing_period.is_deleted = false AND billing_period.service_provider_id <> 6
        )
 SELECT t.composite_id AS id,
    t.billing_cycle_end_date,
    t.service_provider_id,
    t.service_provider_display_name,
    t.integration_id,
    t.iccid,
    t.msisdn,
    t.imei,
    t.carrier_rate_plan,
    t.carrier_cycle_usage,
    t.data_usage_mb,
    t.date_added,
    t.date_activated,
    t.rate_plan_code,
    t.rate_plan_name,
    t.customer_rate_plan_allows_sim_pooling,
    t.plan_mb,
    t.created_date,
    t.created_by,
    t.modified_by,
    t.modified_date,
    t.deleted_by,
    t.deleted_date,
    t.is_active,
    t.is_deleted,
    t.account_number,
    t.carrier_rate_plan_id,
    t.status_code,
    t.status_display_name,
    t.status_color,
    t.status_color_code,
    t.tenant_id,
    t.rev_customer_id,
    t.customer_name,
    t.rev_parent_customer_id,
    t.foundation_account_number,
    t.billing_account_number,
    t.service_zip_code,
    t.rate_plan_soc,
    t.rate_plan_soc_description,
    t.data_group_id,
    t.pool_id,
    t.device_make,
    t.device_model,
    t.contract_status,
    t.ban_status,
    t.imei_type_id,
    t.plan_limit_mb,
    t.username,
    t.sms_usage,
    t.minutes_used,
    t.ip_address,
    t.customer_rate_pool_name,
    t.device_history_id,
    t.is_pushed,
    t.customer_data_allocation_mb,
    t.billing_period_id
   FROM ( SELECT mobility_device_history.device_history_id,
            billing_period.billing_cycle_end_date,
            mobility_device_history.service_provider_id,
            serviceprovider.display_name AS service_provider_display_name,
            serviceprovider.integration_id,
            mobility_device_history.iccid,
            mobility_device_history.msisdn,
            mobility_device_history.imei,
            mobility_device_history.rate_plan AS carrier_rate_plan,
            mobility_device_history.carrier_cycle_usage,
                CASE
                    WHEN integration.id = 12 THEN round(COALESCE(mobility_device_history.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
                    ELSE round(COALESCE(mobility_device_history.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
                END AS data_usage_mb,
            mobility_device_history.provider_date_added AS date_added,
            mobility_device_history.provider_date_activated AS date_activated,
            customerrateplan.rate_plan_code,
            customerrateplan.rate_plan_name,
            customerrateplan.allows_sim_pooling AS customer_rate_plan_allows_sim_pooling,
            customerrateplan.plan_mb,
            mobility_device_history.created_date,
            mobility_device_history.created_by,
            mobility_device_history.modified_by,
            COALESCE(mobility_device_history.modified_date, mobility_device_history.created_date) AS modified_date,
            mobility_device_history.deleted_by,
            mobility_device_history.deleted_date,
            mobility_device_history.is_active,
            mobility_device_history.is_deleted,
            mobility_device_history.account_number,
            mobility_device_history.carrier_rate_plan_id,
            mobility_device_history.status AS status_code,
            device_status.display_name AS status_display_name,
            device_status.status_color,
            device_status.status_color_code,
            customers.tenant_id,
            revcustomer.rev_customer_id,
            revcustomer.customer_name,
            revcustomer.rev_parent_customer_id,
            mobility_device_history.foundation_account_number,
            mobility_device_history.billing_account_number,
            mobility_device_history.service_zip_code,
            mobility_device_history.single_user_code AS rate_plan_soc,
            mobility_device_history.single_user_code_description AS rate_plan_soc_description,
            mobility_device_history.data_group_id,
            mobility_device_history.pool_id,
            mobility_device_history.device_make,
            mobility_device_history.device_model,
            mobility_device_history.contract_status,
            mobility_device_history.ban_status,
            mobility_device_history.imei_type_id,
            mobility_device_history.plan_limit_mb,
            mobility_device_history.username,
            COALESCE(mobility_device_history.ctd_sms_usage, 0::bigint) AS sms_usage,
            mobility_device_history.ctd_voice_usage AS minutes_used,
            mobility_device_history.ip_address,
            customer_rate_pool.name AS customer_rate_pool_name,
            mobility_device_history.is_pushed,
            customerrateplan.plan_mb AS customer_data_allocation_mb,
            array_to_string(array_remove(ARRAY[mobility_device_history.device_history_id, mobility_device_tenant.id, serviceprovider.id], NULL::integer), '-'::text) AS composite_id,
            billing_period.id AS billing_period_id
           FROM mobility_device_history
             JOIN serviceprovider ON mobility_device_history.service_provider_id = serviceprovider.id
             LEFT JOIN customers ON customers.id = mobility_device_history.customer_id
             LEFT JOIN device_status ON device_status.id = mobility_device_history.device_status_id
             LEFT JOIN revcustomer ON revcustomer.id = customers.rev_customer_id
             LEFT JOIN billing_period ON mobility_device_history.billing_period_id = billing_period.id
             LEFT JOIN integration ON integration.id = serviceprovider.integration_id
             LEFT JOIN mobility_device_tenant ON mobility_device_history.id = mobility_device_tenant.mobility_device_id AND mobility_device_history.mobility_device_tenant_id = mobility_device_tenant.id
             LEFT JOIN customerrateplan ON mobility_device_history.customer_rate_plan_id = customerrateplan.id
             LEFT JOIN customer_rate_pool ON mobility_device_history.customer_rate_pool_id = customer_rate_pool.id
          WHERE mobility_device_history.is_active = true AND mobility_device_history.is_deleted = false AND integration.portal_type_id = 2 AND (mobility_device_history.billing_period_id IN ( SELECT mobility_bill_periods.id
                   FROM mobility_bill_periods)) AND (device_status.is_active_status = true OR mobility_device_history.last_activated_date < billing_period.billing_cycle_end_date AND mobility_device_history.last_activated_date > billing_period.billing_cycle_start_date OR mobility_device_history.carrier_cycle_usage > 0)
        UNION ALL
         SELECT device_history.device_history_id,
            billing_period.billing_cycle_end_date,
            device_history.service_provider_id,
            serviceprovider.display_name AS service_provider_display_name,
            serviceprovider.integration_id,
            device_history.iccid,
            device_history.msisdn,
            device_history.imei,
            device_history.rate_plan AS carrier_rate_plan,
            device_history.carrier_cycle_usage,
                CASE
                    WHEN integration.id = 12 THEN round(COALESCE(device_history.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
                    ELSE round(COALESCE(device_history.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
                END AS data_usage_mb,
            device_history.provider_date_added AS date_added,
            device_history.provider_date_activated AS date_activated,
            customerrateplan.rate_plan_code,
            customerrateplan.rate_plan_name,
            customerrateplan.allows_sim_pooling AS customer_rate_plan_allows_sim_pooling,
            customerrateplan.plan_mb,
            device_history.created_date,
            device_history.created_by,
            device_history.modified_by,
            COALESCE(device_history.modified_date, device_history.created_date) AS modified_date,
            device_history.deleted_by,
            device_history.deleted_date,
            device_history.is_active,
            device_history.is_deleted,
            device_tenant.account_number,
            device_history.carrier_rate_plan_id,
            device_history.status AS status_code,
            device_status.display_name AS status_display_name,
            device_status.status_color,
            device_status.status_color_code,
            device_tenant.tenant_id,
            revcustomer.rev_customer_id,
            revcustomer.customer_name,
            revcustomer.rev_parent_customer_id,
            NULL::character varying AS foundation_account_number,
            NULL::character varying AS billing_account_number,
            NULL::character varying AS service_zip_code,
            NULL::character varying AS rate_plan_soc,
            NULL::character varying AS rate_plan_soc_description,
            NULL::character varying AS data_group_id,
            NULL::character varying AS pool_id,
            NULL::character varying AS device_make,
            NULL::character varying AS device_model,
            NULL::character varying AS contract_status,
            NULL::character varying AS ban_status,
            NULL::integer AS imei_type_id,
            NULL::numeric AS plan_limit_mb,
            device_history.username,
            COALESCE(device_history.ctd_sms_usage, 0::bigint) AS sms_usage,
            device_history.ctd_voice_usage AS minutes_used,
            NULL::character varying AS ip_address,
            customer_rate_pool.name AS customer_rate_pool_name,
            device_history.is_pushed,
            customerrateplan.plan_mb AS customer_data_allocation_mb,
            array_to_string(array_remove(ARRAY[device_history.device_history_id, device_tenant.id::bigint, serviceprovider.id::bigint], NULL::integer::bigint), '-'::text) AS composite_id,
            billing_period.id AS billing_period_id
           FROM device_history
             JOIN device_tenant ON device_history.device_tenant_id = device_tenant.id
             JOIN serviceprovider ON device_history.service_provider_id = serviceprovider.id
             LEFT JOIN customers ON customers.id = device_tenant.customer_id
             LEFT JOIN device_status ON device_status.id = device_history.device_status_id
             LEFT JOIN revcustomer ON revcustomer.id = customers.rev_customer_id
             LEFT JOIN billing_period ON device_history.billing_period_id = billing_period.id
             LEFT JOIN integration ON integration.id = serviceprovider.integration_id
             LEFT JOIN customerrateplan ON device_history.customer_rate_plan_id = customerrateplan.id
             LEFT JOIN customer_rate_pool ON device_history.customer_rate_pool_id = customer_rate_pool.id
          WHERE device_history.is_active = true AND device_history.is_deleted = false AND integration.portal_type_id = 0 AND device_tenant.tenant_id = 1 AND (device_history.billing_period_id IN ( SELECT m2m_bill_periods.id
                   FROM m2m_bill_periods)) AND (device_status.is_active_status = true OR device_history.last_activated_date < billing_period.billing_cycle_end_date AND device_history.last_activated_date > billing_period.billing_cycle_start_date OR device_history.carrier_cycle_usage > 0)) t;


-- public.vw_zero_usage_report source

CREATE OR REPLACE VIEW public.vw_zero_usage_report
AS SELECT combined.composite_id AS id,
    combined.device_id,
    combined.iccid,
    combined.msisdn,
    combined.carrier_rate_plan,
    combined.status AS sim_status,
    combined.communication_plan,
    combined.account_number,
    combined.customer_name,
    combined.created_by,
    combined.created_date,
    combined.modified_by,
    combined.modified_date,
    combined.deleted_by,
    combined.deleted_date,
    combined.is_active,
    combined.is_deleted,
    combined.service_provider_name AS service_provider,
    combined.last_usage_date,
    combined.billing_cycle_end_date,
    combined.customer_rate_plan_name,
    combined.customer_rate_plan_id,
    combined.username,
    combined.service_provider_id,
    combined.tenant_id
   FROM ( SELECT jd.id AS device_id,
            jd.iccid,
            jd.msisdn,
            jd.carrier_rate_plan,
            jds.display_name AS status,
            jd.communication_plan,
            dt.account_number,
            account_info.customer_name,
            jd.created_by,
            jd.created_date,
            jd.modified_by,
            jd.modified_date,
            jd.deleted_by,
            jd.deleted_date,
            jd.is_active,
            jd.is_deleted,
            sp.display_name AS service_provider_name,
            jd.last_usage_date,
            bp.billing_cycle_end_date,
            crp.rate_plan_name AS customer_rate_plan_name,
            dt.customer_rate_plan_id,
            NULL::character varying AS username,
            jd.service_provider_id,
            dt.tenant_id,
            array_to_string(array_remove(ARRAY[jd.id, sp.id, dt.id], NULL::integer), '-'::text) AS composite_id
           FROM device jd
             JOIN device_tenant dt ON jd.id = dt.device_id
             JOIN serviceprovider sp ON jd.service_provider_id = sp.id
             JOIN integration i ON sp.integration_id = i.id
             LEFT JOIN customers s ON s.id = dt.customer_id
             LEFT JOIN device_status jds ON jds.id = jd.device_status_id
             LEFT JOIN revcustomer account_info ON s.rev_customer_id = account_info.id
             LEFT JOIN customerrateplan crp ON dt.customer_rate_plan_id = crp.id
             LEFT JOIN billing_period bp ON bp.id = jd.billing_period_id
          WHERE jds.is_active_status = true AND jd.carrier_cycle_usage = 0 AND i.portal_type_id = 0
        UNION ALL
         SELECT jd.id AS device_id,
            jd.iccid,
            jd.msisdn,
            jd.carrier_rate_plan,
            jds.display_name AS status,
            NULL::character varying AS communication_plan,
            dt.account_number,
            account_info.customer_name,
            jd.created_by,
            jd.created_date,
            jd.modified_by,
            jd.modified_date,
            jd.deleted_by,
            jd.deleted_date,
            jd.is_active,
            jd.is_deleted,
            sp.display_name AS service_provider_name,
            jd.last_usage_date,
            bp.billing_cycle_end_date,
            crp.rate_plan_name AS customer_rate_plan_name,
            dt.customer_rate_plan_id,
            COALESCE(jd.amop_username, jd.username) AS username,
            jd.service_provider_id,
            dt.tenant_id,
            array_to_string(array_remove(ARRAY[jd.id, sp.id, dt.id], NULL::integer), '-'::text) AS composite_id
           FROM mobility_device jd
             JOIN mobility_device_tenant dt ON jd.id = dt.mobility_device_id
             JOIN serviceprovider sp ON jd.service_provider_id = sp.id
             JOIN integration i ON sp.integration_id = i.id
             LEFT JOIN customers s ON s.id = dt.customer_id
             LEFT JOIN device_status jds ON jds.id = jd.device_status_id
             LEFT JOIN revcustomer account_info ON account_info.id = s.rev_customer_id
             LEFT JOIN billing_period bp ON jd.billing_period_id = bp.id
             LEFT JOIN customerrateplan crp ON dt.customer_rate_plan_id = crp.id
          WHERE jds.is_active_status = true AND jd.carrier_cycle_usage = 0 AND i.portal_type_id = 2) combined;

-- public.vw_people_bandwidth_customers source

CREATE OR REPLACE VIEW public.vw_people_bandwidth_customers
AS SELECT extent1.id,
    extent1.tenant_name,
    extent1.customer_name,
    extent1.description,
    extent1.inactivity_start,
    extent1.inactivity_end,
    extent1.apt_suite,
    extent1.address1,
    extent1.address2,
    extent1.city,
    bws.bandwidth_account_id,
    extent1.state,
    extent1.postal_code,
    extent1.country,
    extent1.created_date,
    extent1.created_by,
    extent1.modified_date,
    extent1.modified_by,
    extent1.deleted_date,
    extent1.deleted_by,
    extent1.is_deleted,
    extent1.is_active,
    extent1.rev_customer_id,
    extent1.bandwidth_customer_id,
    extent1.netsapiens_customer_id,
    extent1.is_system_default,
    extent1.e911_customer_id,
    extent1.netsapiens_domain_id,
    extent1.customer_rate_plans,
    extent1.customer_bill_period_end_hour,
    extent1.customer_bill_period_end_day,
    extent1.tenant_id
   FROM customers extent1
     JOIN bandwidth_customers bws ON bws.id = extent1.bandwidth_customer_id::double precision::integer
  WHERE extent1.is_deleted <> true AND extent1.is_active = true AND (extent1.bandwidth_customer_id IS NOT NULL OR extent1.is_system_default = true)
  ORDER BY extent1.modified_date DESC, extent1.customer_name;

-- public.vw_people_netsapiens_customers_list_view source

CREATE OR REPLACE VIEW public.vw_people_netsapiens_customers_list_view
AS SELECT extent1.id,
    extent1.tenant_name,
    extent1.customer_name,
    extent1.description,
    extent1.inactivity_start,
    extent1.inactivity_end,
    extent1.apt_suite,
    extent1.address1,
    extent1.address2,
    extent1.city,
    extent1.state,
    extent1.postal_code,
    extent1.country,
    extent1.created_date,
    extent1.created_by,
    extent1.modified_date,
    extent1.modified_by,
    extent1.deleted_date,
    extent1.deleted_by,
    extent1.is_deleted,
    extent1.is_active,
    extent1.netsapiens_type,
    extent1.rev_customer_id,
    extent1.bandwidth_customer_id,
    extent1.netsapiens_customer_id,
    extent1.is_system_default,
    extent1.e911_customer_id,
    extent1.netsapiens_domain_id,
    extent1.customer_rate_plans,
    extent1.customer_bill_period_end_hour,
    extent1.customer_bill_period_end_day,
    extent1.tenant_id
   FROM customers extent1
  WHERE extent1.is_deleted <> true AND extent1.is_active = true AND (extent1.netsapiens_customer_id IS NOT NULL OR extent1.netsapiens_domain_id IS NOT NULL)
  ORDER BY extent1.modified_date DESC, extent1.customer_name;


-- public.vw_people_revio_customer_list_view source

CREATE OR REPLACE VIEW public.vw_people_revio_customer_list_view
AS SELECT c.id,
    c.tenant_name AS partner,
    ra.agent_name AS agent,
    rc.customer_name AS name,
    rc.rev_customer_id AS account,
    c.customer_bill_period_end_day,
    c.customer_bill_period_end_hour,
    rc.modified_date,
    rc.tenant_id
   FROM revcustomer rc
     LEFT JOIN revagent ra ON ra.rev_agent_id = rc.agent_id
     LEFT JOIN customers c ON c.rev_customer_id = rc.id;

-- public.vw_people_revio_customers source

CREATE OR REPLACE VIEW public.vw_people_revio_customers
AS WITH distinct_agents AS (
         SELECT DISTINCT min(ra.id) AS id,
            ra.rev_agent_id,
            ra.agent_name
           FROM revagent ra
          WHERE ra.is_active = true AND ra.is_deleted = false
          GROUP BY ra.rev_agent_id, ra.agent_name
        )
 SELECT row_number() OVER (ORDER BY c.id)::integer AS id,
    c.tenant_name AS partner,
    da.agent_name,
    rc.customer_name AS name,
    rc.rev_customer_id AS account,
    c.customer_bill_period_end_day,
    c.customer_bill_period_end_hour,
    rc.bill_profile_id,
    c.modified_date,
    rc.customer_name,
    c.created_by,
    c.modified_by,
    rc.tenant_id,
    c.id AS cust_id
   FROM revcustomer rc
     JOIN customers c ON rc.id = c.rev_customer_id
     LEFT JOIN distinct_agents da ON da.rev_agent_id = rc.agent_id
  WHERE (rc.bill_profile_id IN ( SELECT revbillprofile.bill_profile_id
           FROM revbillprofile
          WHERE (revbillprofile.integration_authentication_id IN ( SELECT integration_authentication.id
                   FROM integration_authentication)) AND revbillprofile.is_active = true AND revbillprofile.is_deleted = false)) AND c.is_active = true AND c.is_deleted = false AND rc.is_active = true AND rc.is_deleted = false
  ORDER BY c.modified_date DESC;

-- public.vw_pool_group_summary_report source

CREATE OR REPLACE VIEW public.vw_pool_group_summary_report
AS SELECT du.foundation_account_number,
    du.billing_account_number,
    du.data_group_id,
    du.pool_id,
    du.data_usage,
    du.data_total AS plan_limit_bytes,
        CASE
            WHEN COALESCE(du.data_total, 0::bigint) = 0 THEN NULL::bigint
            ELSE du.data_total - COALESCE(du.data_usage, 0::bigint)
        END AS data_remaining,
        CASE
            WHEN COALESCE(du.data_total, 0::bigint) = 0 THEN NULL::numeric
            ELSE (COALESCE(du.data_usage, 0::bigint)::numeric * 100.0 / du.data_total::numeric)::numeric(18,2)
        END AS data_usage_percentage,
        CASE
            WHEN COALESCE(du.data_total, 0::bigint) = 0 THEN NULL::numeric
            ELSE ((du.data_total - COALESCE(du.data_usage, 0::bigint))::numeric * 100.0 / du.data_total::numeric)::numeric(18,2)
        END AS data_remaining_percentage,
    sp.display_name AS service_provider_name,
        CASE
            WHEN COALESCE(du.pool_id, ''::character varying)::text <> ''::text THEN ( SELECT count(1) AS count
               FROM mobility_device m
              WHERE m.is_deleted = false AND m.pool_id::text = du.pool_id::text)
            ELSE 0::bigint
        END AS pool_device_count,
        CASE
            WHEN COALESCE(du.data_group_id, ''::character varying)::text <> ''::text THEN ( SELECT count(1) AS count
               FROM mobility_device m
              WHERE m.is_deleted = false AND m.data_group_id::text = du.data_group_id::text)
            ELSE 0::bigint
        END AS data_group_device_count,
    du.created_date,
    array_to_string(array_remove(ARRAY[du.id, sp.id, i.id], NULL::integer), '-'::text) AS id,
    du.is_active,
    du.modified_date,
    du.tenant_id
   FROM mobility_device_usage_aggregate du
     JOIN serviceprovider sp ON du.service_provider_id = sp.id
     JOIN integration i ON sp.integration_id = i.id
  WHERE COALESCE(du.data_group_id, ''::character varying)::text <> ''::text OR COALESCE(du.pool_id, ''::character varying)::text <> ''::text;


-- public.vw_pool_group_summary_report_with_billing_cycles source

CREATE OR REPLACE VIEW public.vw_pool_group_summary_report_with_billing_cycles
AS SELECT du.foundation_account_number,
    du.billing_account_number,
    du.data_group_id,
    du.pool_id,
    du.data_usage,
    du.data_total AS plan_limit_bytes,
        CASE
            WHEN COALESCE(du.data_total, 0::bigint) = 0 THEN NULL::bigint
            ELSE du.data_total - COALESCE(du.data_usage, 0::bigint)
        END AS data_remaining,
        CASE
            WHEN COALESCE(du.data_total, 0::bigint) = 0 THEN NULL::numeric
            ELSE (COALESCE(du.data_usage, 0::bigint)::numeric * 100.0 / du.data_total::numeric)::numeric(18,2)
        END AS data_usage_percentage,
        CASE
            WHEN COALESCE(du.data_total, 0::bigint) = 0 THEN NULL::numeric
            ELSE ((du.data_total - COALESCE(du.data_usage, 0::bigint))::numeric * 100.0 / du.data_total::numeric)::numeric(18,2)
        END AS data_remaining_percentage,
    sp.display_name AS service_provider_name,
        CASE
            WHEN COALESCE(du.pool_id, ''::character varying)::text <> ''::text THEN ( SELECT count(1) AS count
               FROM mobility_device m
              WHERE m.is_deleted = false AND m.pool_id::text = du.pool_id::text)
            ELSE 0::bigint
        END AS pool_device_count,
        CASE
            WHEN COALESCE(du.data_group_id, ''::character varying)::text <> ''::text THEN ( SELECT count(1) AS count
               FROM mobility_device m
              WHERE m.is_deleted = false AND m.data_group_id::text = du.data_group_id::text)
            ELSE 0::bigint
        END AS data_group_device_count,
    du.created_date,
    row_number() OVER (ORDER BY du.created_date) AS id,
    du.is_active,
    smi.billing_cycle_start_date,
    smi.billing_cycle_end_date,
    du.modified_date,
    du.tenant_id
   FROM mobility_device_usage_aggregate du
     JOIN sim_management_inventory smi ON du.billing_account_number::text = smi.billing_account_number::text
     JOIN serviceprovider sp ON du.service_provider_id = sp.id
     JOIN integration i ON sp.integration_id = i.id
  WHERE COALESCE(du.data_group_id, ''::character varying)::text <> ''::text OR COALESCE(du.pool_id, ''::character varying)::text <> ''::text;


-- public.vw_m2m_rev_service_products source

CREATE OR REPLACE VIEW public.vw_m2m_rev_service_products
AS SELECT devicetenant.id,
        CASE
            WHEN serviceprovider.integration_id = 12 THEN device.eid
            ELSE
            CASE
                WHEN serviceprovider.integration_id = 13 THEN device.iccid
                ELSE COALESCE(device.msisdn, device.iccid)
            END
        END AS service_number,
    device_status.display_name AS device_status,
    COALESCE(dateactivated.date_of_change, device.date_activated) AS carrier_last_status_date,
        CASE
            WHEN device_status.display_name::text = ANY (ARRAY['RestoredFromArchive'::text, 'Restored from archive'::text]) THEN true
            ELSE device_status.is_active_status
        END AS is_active_status,
    device_status.should_have_billed_service,
    device.iccid,
    device.service_provider_id,
    serviceprovider.display_name AS service_provider,
    device.communication_plan,
    rev_service.activated_date,
    rev_service.disconnected_date,
    rev_service_product.service_product_id,
        CASE
            WHEN rev_service_product.package_id = 0 THEN NULL::integer
            ELSE rev_service_product.package_id
        END AS package_id,
    rev_service_product.service_id,
    rev_service_product.product_id,
    rev_service_product.description,
    rev_service_product.rate,
    rev_service_product.status AS reviostatus,
        CASE
            WHEN rev_service_product.status::text = 'ACTIVE'::text THEN true
            ELSE false
        END AS rev_is_active_status,
    rev_service_product.cost,
    rev_service_product.wholesale_description,
    rev_service_product.quantity,
    rev_service_product.integration_authentication_id,
    COALESCE(revcustomer.rev_customer_id, sitecustomer.rev_customer_id::text::character varying) AS rev_account_number,
    COALESCE(revcustomer.customer_name, sitecustomer.customer_name) AS customer_name,
    rev_product.id AS rev_product_id,
    rev_product.product_type_id,
    rev_product.description AS product_description,
    rev_service_type.service_type_id,
    devicetenant.tenant_id,
    device.last_activated_date AS carrier_activated_date,
    customerrateplan.rate_plan_name AS customer_rate_plan,
    device.carrier_rate_plan,
    site.id AS customer_id,
    COALESCE(rev_service.rev_service_line_status, devicetenant.rev_line_status) AS rev_service_line_status,
    device.modified_date,
    rev_service.id AS rev_service_id,
    rev_service_product.id AS rev_service_product_id,
    devicetenant.id AS dev_tenant_id
   FROM device_tenant devicetenant
     JOIN device ON devicetenant.device_id = device.id AND device.is_active = true AND device.is_deleted = false
     JOIN device_status ON device_status.id = device.device_status_id
     JOIN serviceprovider ON serviceprovider.id = device.service_provider_id AND serviceprovider.is_active = true AND serviceprovider.is_deleted = false
     JOIN integration ON integration.id = serviceprovider.integration_id AND integration.portal_type_id = 0
     LEFT JOIN rev_service ON rev_service.id = devicetenant.rev_service_id
     LEFT JOIN customerrateplan ON devicetenant.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customers site ON devicetenant.customer_id = site.id AND site.rev_customer_id IS NOT NULL
     LEFT JOIN revcustomer sitecustomer ON site.rev_customer_id = sitecustomer.id AND sitecustomer.status::text <> 'CLOSED'::text AND sitecustomer.is_active = true AND sitecustomer.is_deleted = false
     LEFT JOIN rev_service_product ON rev_service.rev_service_id = rev_service_product.service_id AND rev_service_product.integration_authentication_id = rev_service.integration_authentication_id AND rev_service_product.status::text = 'ACTIVE'::text AND rev_service_product.is_active = true AND rev_service_product.is_deleted = false
     LEFT JOIN revcustomer ON rev_service_product.customer_id::text = revcustomer.rev_customer_id::text AND rev_service_product.integration_authentication_id = revcustomer.integration_authentication_id AND revcustomer.status::text <> 'CLOSED'::text AND revcustomer.is_active = true AND revcustomer.is_deleted = false
     LEFT JOIN integration_authentication integrationauthentication ON revcustomer.integration_authentication_id = integrationauthentication.id
     LEFT JOIN rev_product ON rev_service_product.product_id = rev_product.product_id AND rev_service_product.integration_authentication_id = rev_product.integration_authentication_id
     LEFT JOIN rev_service_type ON rev_service_type.id = rev_service.rev_service_type_id AND rev_service_type.integration_authentication_id = rev_service.integration_authentication_id
     LEFT JOIN rev_product_type ON rev_product_type.product_type_id = rev_product.product_type_id AND rev_product_type.integration_authentication_id = rev_product.integration_authentication_id AND (rev_product_type.product_type_code IS NULL OR rev_product_type.product_type_code::text ~~ 'RECURRING_%'::text)
     LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = device.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status_1.status
                   FROM device_status device_status_1
                  WHERE serviceprovider.integration_id = device_status_1.integration_id))
          ORDER BY device_status_history.date_of_change DESC
         LIMIT 1) dateactivated ON true
  WHERE device.is_deleted = false AND devicetenant.is_deleted = false AND (rev_service_type.service_type_id IS NULL OR rev_service_type.service_type_id = 18 OR rev_service_type.description::text = 'Wireless Service'::text);


-- public.vw_m2m_rev_service_products_export source

CREATE OR REPLACE VIEW public.vw_m2m_rev_service_products_export
AS WITH billing_period_cte AS (
         SELECT bp.service_provider_id,
            bp.billing_cycle_end_date,
            bp.id
           FROM ( SELECT billing_period_1.service_provider_id,
                    billing_period_1.billing_cycle_end_date,
                    billing_period_1.id,
                    row_number() OVER (PARTITION BY billing_period_1.service_provider_id ORDER BY billing_period_1.billing_cycle_end_date DESC) AS row_num
                   FROM billing_period billing_period_1
                  WHERE billing_period_1.bill_year::numeric = EXTRACT(year FROM CURRENT_DATE) AND billing_period_1.is_active = true AND billing_period_1.billing_cycle_end_date < CURRENT_DATE AND billing_period_1.is_deleted = false) bp
          WHERE bp.row_num = 1
        )
 SELECT device_tenant.id,
        CASE
            WHEN serviceprovider.integration_id = 12 THEN device.eid
            ELSE
            CASE
                WHEN serviceprovider.integration_id = 13 THEN device.iccid
                ELSE COALESCE(device.msisdn, device.iccid)
            END
        END AS service_number,
    device_status.display_name AS device_status,
    COALESCE(date_activated.date_of_change, device.date_activated) AS carrier_last_status_date,
        CASE
            WHEN device_status.display_name::text = ANY (ARRAY['RestoredFromArchive'::character varying::text, 'Restored from archive'::character varying::text]) THEN true
            ELSE device_status.is_active_status
        END AS is_active_status,
    device_status.should_have_billed_service,
    device.iccid,
    device.service_provider_id,
    serviceprovider.display_name AS service_provider,
    device.communication_plan,
    rev_service.activated_date,
    rev_service.disconnected_date,
    rev_service_product.service_product_id,
    NULLIF(rev_service_product.package_id, 0) AS package_id,
    rev_service_product.service_id,
    rev_service_product.product_id,
    rev_service_product.description,
    rev_service_product.rate,
    rev_service_product.status AS rev_io_status,
    rev_service_product.status::text = 'ACTIVE'::text AS rev_is_active_status,
    rev_service_product.cost,
    rev_service_product.wholesale_description,
    rev_service_product.quantity,
    rev_service_product.integration_authentication_id,
    COALESCE(revcustomer.rev_customer_id, site_customer.rev_customer_id) AS rev_account_number,
    COALESCE(revcustomer.customer_name, site_customer.customer_name) AS customer_name,
    rev_product.id AS rev_product_id,
    rev_product.product_type_id,
    rev_product.description AS product_description,
    rev_service_type.service_type_id,
    device_tenant.tenant_id,
    device.last_activated_date AS carrier_activated_date,
    customerrateplan.rate_plan_name AS customer_rate_plan,
    device.carrier_rate_plan,
    COALESCE(device_history_grouped.usage, 0::numeric) AS usage,
    billing_period.billing_cycle_end_date AS usage_cycle
   FROM device_tenant
     JOIN device ON device_tenant.device_id = device.id AND device.is_active = true AND device.is_deleted = false
     JOIN device_status ON device_status.id = device.device_status_id
     JOIN serviceprovider ON serviceprovider.id = device.service_provider_id AND serviceprovider.is_active = true AND serviceprovider.is_deleted = false
     JOIN integration ON integration.id = serviceprovider.integration_id AND integration.portal_type_id = 0
     LEFT JOIN rev_service ON rev_service.id = device_tenant.rev_service_id
     LEFT JOIN customerrateplan ON device_tenant.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customers ON device_tenant.customer_id = customers.id AND customers.rev_customer_id IS NOT NULL
     LEFT JOIN revcustomer site_customer ON customers.rev_customer_id = site_customer.id AND site_customer.status::text <> 'CLOSED'::text AND site_customer.is_active = true AND site_customer.is_deleted = false
     LEFT JOIN rev_service_product ON rev_service.rev_service_id = rev_service_product.service_id AND rev_service_product.integration_authentication_id = rev_service.integration_authentication_id AND rev_service_product.status::text = 'ACTIVE'::text AND rev_service_product.is_active = true AND rev_service_product.is_deleted = false
     LEFT JOIN revcustomer ON rev_service_product.customer_id::text = revcustomer.rev_customer_id::text AND rev_service_product.integration_authentication_id = revcustomer.integration_authentication_id AND revcustomer.status::text <> 'CLOSED'::text AND revcustomer.is_active = true AND revcustomer.is_deleted = false
     LEFT JOIN integration_authentication integration_authentication ON revcustomer.integration_authentication_id = integration_authentication.id
     LEFT JOIN rev_product ON rev_service_product.product_id = rev_product.product_id AND rev_service_product.integration_authentication_id = rev_product.integration_authentication_id
     LEFT JOIN rev_service_type ON rev_service_type.id = rev_service.rev_service_type_id AND rev_service_type.integration_authentication_id = rev_service.integration_authentication_id
     LEFT JOIN rev_product_type ON rev_product_type.product_type_id = rev_product.product_type_id AND rev_product_type.integration_authentication_id = rev_product.integration_authentication_id AND (rev_product_type.product_type_code IS NULL OR rev_product_type.product_type_code::text ~~ 'RECURRING_%'::text)
     LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = device.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status_1.status
                   FROM device_status device_status_1
                  WHERE serviceprovider.integration_id = device_status_1.integration_id))
          ORDER BY device_status_history.date_of_change DESC
         LIMIT 1) date_activated ON true
     LEFT JOIN ( WITH bp AS (
                 SELECT billing_period_1.service_provider_id,
                    billing_period_1.billing_cycle_end_date,
                    billing_period_1.id,
                    row_number() OVER (PARTITION BY billing_period_1.service_provider_id ORDER BY billing_period_1.billing_cycle_end_date DESC) AS row_num
                   FROM billing_period billing_period_1
                  WHERE EXTRACT(year FROM CURRENT_DATE) = billing_period_1.bill_year::numeric AND billing_period_1.is_active = true AND billing_period_1.billing_cycle_end_date < CURRENT_DATE AND billing_period_1.is_deleted = false
                )
         SELECT bp.service_provider_id,
            bp.billing_cycle_end_date,
            bp.id
           FROM bp
          WHERE bp.row_num = 1) billing_period ON billing_period.service_provider_id = device.service_provider_id
     LEFT JOIN LATERAL ( SELECT device_history.id,
            device_history.tenant_id,
            device_history.iccid,
            round(COALESCE(device_history.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3) AS usage,
            device_history.billing_period_id
           FROM device_history
             JOIN billing_period b ON b.id = device_history.billing_period_id
             LEFT JOIN device_status device_status_1 ON device_status_1.id = device_history.device_status_id
             JOIN billing_period_cte c ON c.id = device_history.billing_period_id
          WHERE device_status_1.is_active_status = true OR device_history.last_activated_date < b.billing_cycle_end_date AND device_history.last_activated_date > b.billing_cycle_start_date OR device_history.carrier_cycle_usage > 0) device_history_grouped ON device_history_grouped.id = device_tenant.device_id AND device_history_grouped.iccid::text = device.iccid::text AND device_tenant.tenant_id = device_history_grouped.tenant_id
  WHERE device.is_active = true AND device_tenant.is_active = true AND (rev_service_type.service_type_id IS NULL OR rev_service_type.service_type_id = 18 OR rev_service_type.description::text = 'Wireless Service'::text);

-- public.vw_mobility_rev_service_products source

CREATE OR REPLACE VIEW public.vw_mobility_rev_service_products
AS WITH cte_devicestatushistory AS (
         SELECT mobility_device_status_history.date_of_change,
            mobility_device_status_history.mobility_device_id,
            mobility_device_status_history.current_status,
            mobility_device_status_history.previous_status
           FROM mobility_device_status_history
          WHERE mobility_device_status_history.date_of_change IS NOT NULL
        ), cte_devicestatushistory_cancelstatustounknownstatus AS (
         SELECT cte_devicestatushistory.date_of_change,
            cte_devicestatushistory.mobility_device_id,
            cte_devicestatushistory.current_status,
            cte_devicestatushistory.previous_status
           FROM cte_devicestatushistory
          WHERE lower(cte_devicestatushistory.current_status::text) = 'c'::text AND lower(cte_devicestatushistory.previous_status::text) <> 'c'::text
        ), cte_devicestatushistory_notcancelstatustounknownstatus AS (
         SELECT cte_devicestatushistory.date_of_change,
            cte_devicestatushistory.mobility_device_id,
            cte_devicestatushistory.current_status,
            cte_devicestatushistory.previous_status
           FROM cte_devicestatushistory
          WHERE lower(cte_devicestatushistory.current_status::text) = 'unknown'::text AND lower(cte_devicestatushistory.previous_status::text) <> 'c'::text
        )
 SELECT gen_random_uuid() AS id,
    mobility_device.msisdn AS service_number,
        CASE
            WHEN device_status.is_active_status = false AND (EXISTS ( SELECT 1
               FROM mobility_device_status_history
              WHERE mobility_device_status_history.mobility_device_id = mobility_device.id AND mobility_device_status_history.date_of_change IS NOT NULL AND (mobility_device_status_history.current_status::text IN ( SELECT device_status_1.status
                       FROM device_status device_status_1
                      WHERE serviceprovider.integration_id = device_status_1.integration_id))
              ORDER BY mobility_device_status_history.date_of_change DESC
             LIMIT 1)) THEN
            CASE
                WHEN (EXISTS ( SELECT 1
                   FROM cte_devicestatushistory
                  WHERE cte_devicestatushistory.mobility_device_id = mobility_device.id AND lower(cte_devicestatushistory.current_status::text) = 'unknown'::text AND lower(cte_devicestatushistory.previous_status::text) = 'c'::text)) AND ((( SELECT max(cte_devicestatushistory_notcancelstatustounknownstatus.date_of_change) AS max
                   FROM cte_devicestatushistory_notcancelstatustounknownstatus
                  WHERE cte_devicestatushistory_notcancelstatustounknownstatus.mobility_device_id = mobility_device.id)) IS NULL OR (( SELECT max(cte_devicestatushistory_notcancelstatustounknownstatus.date_of_change) AS max
                   FROM cte_devicestatushistory_notcancelstatustounknownstatus
                  WHERE cte_devicestatushistory_notcancelstatustounknownstatus.mobility_device_id = mobility_device.id)) < (( SELECT max(cte_devicestatushistory_cancelstatustounknownstatus.date_of_change) AS max
                   FROM cte_devicestatushistory_cancelstatustounknownstatus
                  WHERE cte_devicestatushistory_cancelstatustounknownstatus.mobility_device_id = mobility_device.id))) OR lower((( SELECT cte_devicestatushistory.current_status
                   FROM cte_devicestatushistory
                  WHERE cte_devicestatushistory.mobility_device_id = mobility_device.id AND lower(cte_devicestatushistory.current_status::text) = 'c'::text
                  ORDER BY cte_devicestatushistory.date_of_change DESC
                 LIMIT 1))::text) = 'c'::text THEN 'C'::character varying
                ELSE mobility_device.sim_status
            END
            ELSE mobility_device.sim_status
        END AS device_status,
        CASE
            WHEN (EXISTS ( SELECT 1
               FROM mobility_device_status_history
              WHERE mobility_device_status_history.mobility_device_id = mobility_device.id AND mobility_device_status_history.date_of_change IS NOT NULL AND (mobility_device_status_history.current_status::text IN ( SELECT device_status_1.status
                       FROM device_status device_status_1
                      WHERE serviceprovider.integration_id = device_status_1.integration_id))
              ORDER BY mobility_device_status_history.date_of_change DESC
             LIMIT 1)) THEN
            CASE
                WHEN (EXISTS ( SELECT 1
                   FROM cte_devicestatushistory
                  WHERE cte_devicestatushistory.mobility_device_id = mobility_device.id AND lower(cte_devicestatushistory.current_status::text) = 'unknown'::text AND lower(cte_devicestatushistory.previous_status::text) = 'c'::text
                 LIMIT 1)) AND ((( SELECT max(cte_devicestatushistory_cancelstatustounknownstatus.date_of_change) AS max
                   FROM cte_devicestatushistory_cancelstatustounknownstatus
                  WHERE cte_devicestatushistory_cancelstatustounknownstatus.mobility_device_id = mobility_device.id)) IS NULL OR (( SELECT max(cte_devicestatushistory_cancelstatustounknownstatus.date_of_change) AS max
                   FROM cte_devicestatushistory_cancelstatustounknownstatus
                  WHERE cte_devicestatushistory_cancelstatustounknownstatus.mobility_device_id = mobility_device.id)) < (( SELECT max(cte_devicestatushistory_cancelstatustounknownstatus.date_of_change) AS max
                   FROM cte_devicestatushistory_cancelstatustounknownstatus
                  WHERE cte_devicestatushistory_cancelstatustounknownstatus.mobility_device_id = mobility_device.id))) OR ((( SELECT cte_devicestatushistory.current_status
                   FROM cte_devicestatushistory
                  WHERE cte_devicestatushistory.mobility_device_id = mobility_device.id AND lower(cte_devicestatushistory.current_status::text) = 'c'::text
                  ORDER BY cte_devicestatushistory.date_of_change DESC
                 LIMIT 1))::text) = 'C'::text THEN ( SELECT cte_devicestatushistory_cancelstatustounknownstatus.date_of_change
                   FROM cte_devicestatushistory_cancelstatustounknownstatus
                  WHERE cte_devicestatushistory_cancelstatustounknownstatus.mobility_device_id = mobility_device.id
                  ORDER BY cte_devicestatushistory_cancelstatustounknownstatus.date_of_change DESC
                 LIMIT 1)
                ELSE ( SELECT cte_devicestatushistory.date_of_change
                   FROM cte_devicestatushistory
                  WHERE cte_devicestatushistory.mobility_device_id = mobility_device.id AND (cte_devicestatushistory.current_status::text IN ( SELECT device_status_1.status
                           FROM device_status device_status_1
                          WHERE serviceprovider.integration_id = device_status_1.integration_id))
                  ORDER BY cte_devicestatushistory.date_of_change DESC
                 LIMIT 1)
            END
            ELSE mobility_device.date_activated
        END AS carrierlaststatusdate,
    device_status.is_active_status,
    device_status.should_have_billed_service,
    mobility_device.iccid,
    mobility_device.service_provider_id,
    serviceprovider.display_name AS serviceprovider,
    rev_service.activated_date,
    rev_service.disconnected_date,
    rev_service_product.service_product_id,
    NULLIF(rev_service_product.package_id, 0) AS package_id,
    rev_service_product.service_id,
    rev_service_product.product_id,
    rev_service_product.description,
    rev_service_product.rate,
    rev_service_product.status AS reviostatus,
        CASE
            WHEN rev_service_product.status::text = 'ACTIVE'::text THEN true
            ELSE false
        END AS rev_is_active_status,
    rev_service_product.cost,
    rev_service_product.wholesale_description,
    rev_service_product.quantity,
    rev_service_product.integration_authentication_id,
    COALESCE(revcustomer.rev_customer_id, sitecustomer.rev_customer_id) AS revaccountnumber,
    COALESCE(revcustomer.customer_name, sitecustomer.customer_name) AS customername,
    rev_product.id AS rev_product_id,
    rev_product.product_type_id,
    rev_product.description AS product_description,
    rev_service_type.service_type_id,
    COALESCE(device_tenant.tenant_id, integration_authentication.tenant_id, serviceprovider.tenant_id) AS tenant_id,
    mobility_device.last_activated_date AS carrieractivateddate,
    customerrateplan.rate_plan_name AS customerrateplan,
    mobility_device.carrier_rate_plan,
    site.id AS customer_id,
    COALESCE(rev_service.rev_service_line_status, device_tenant.rev_line_status) AS rev_service_line_status,
    rev_service_product.id AS dt_id,
    mobility_device.modified_date,
    rev_service_product.id AS rev_service_product_id,
    rev_service.id AS rev_service_id,
    mobility_device.id AS mob_dev_id
   FROM mobility_device
     JOIN mobility_device_tenant device_tenant ON mobility_device.id = device_tenant.mobility_device_id
     JOIN device_status ON device_status.id = mobility_device.device_status_id
     JOIN serviceprovider ON serviceprovider.id = mobility_device.service_provider_id
     JOIN integration ON integration.id = serviceprovider.integration_id
     LEFT JOIN customers site ON device_tenant.customer_id = site.id AND site.rev_customer_id IS NOT NULL
     LEFT JOIN revcustomer sitecustomer ON site.rev_customer_id = sitecustomer.id AND sitecustomer.status::text <> 'CLOSED'::text AND sitecustomer.is_active = true AND sitecustomer.is_deleted = false
     LEFT JOIN rev_service ON device_tenant.rev_service_id = rev_service.id
     LEFT JOIN rev_service_product ON rev_service.rev_service_id = rev_service_product.service_id AND rev_service_product.integration_authentication_id = rev_service.integration_authentication_id AND rev_service_product.status::text = 'ACTIVE'::text
     LEFT JOIN revcustomer ON rev_service_product.customer_id::text = revcustomer.rev_customer_id::text AND rev_service_product.integration_authentication_id = revcustomer.integration_authentication_id AND revcustomer.status::text <> 'CLOSED'::text AND revcustomer.is_active = true AND revcustomer.is_deleted = false
     LEFT JOIN integration_authentication integration_authentication ON revcustomer.integration_authentication_id = integration_authentication.id
     LEFT JOIN rev_product ON rev_service_product.product_id = rev_product.product_id AND rev_service_product.integration_authentication_id = rev_product.integration_authentication_id
     LEFT JOIN rev_service_type ON rev_service_type.id = rev_service.rev_service_type_id AND rev_service_type.integration_authentication_id = rev_service.integration_authentication_id
     LEFT JOIN rev_product_type ON rev_product_type.product_type_id = rev_product.product_type_id AND rev_product_type.integration_authentication_id = rev_product.integration_authentication_id
     LEFT JOIN customerrateplan ON device_tenant.customer_rate_plan_id = customerrateplan.id
  WHERE mobility_device.is_deleted = false AND device_tenant.is_deleted = false AND (rev_product_type.product_type_code IS NULL OR rev_product_type.product_type_code::text ~~ 'RECURRING_%'::text) AND integration.portal_type_id = 2;


-- public.vw_mobility_rev_service_products_export source

CREATE OR REPLACE VIEW public.vw_mobility_rev_service_products_export
AS WITH cte_device_status_history AS (
         SELECT device_status_history.date_of_change,
            device_status_history.mobility_device_id,
            device_status_history.current_status,
            device_status_history.previous_status
           FROM device_status_history
          WHERE device_status_history.date_of_change IS NOT NULL
        ), cte_device_status_history_cancel_to_unknown AS (
         SELECT cte_device_status_history.date_of_change,
            cte_device_status_history.mobility_device_id,
            cte_device_status_history.current_status,
            cte_device_status_history.previous_status
           FROM cte_device_status_history
          WHERE lower(cte_device_status_history.current_status::text) = 'c'::text AND lower(cte_device_status_history.previous_status::text) <> 'c'::text
        ), cte_device_status_history_not_cancel_to_unknown AS (
         SELECT cte_device_status_history.date_of_change,
            cte_device_status_history.mobility_device_id,
            cte_device_status_history.current_status,
            cte_device_status_history.previous_status
           FROM cte_device_status_history
          WHERE lower(cte_device_status_history.current_status::text) = 'unknown'::text AND lower(cte_device_status_history.previous_status::text) <> 'c'::text
        ), billing_period_cte AS (
         SELECT bp_1.service_provider_id,
            bp_1.billing_cycle_end_date,
            bp_1.id
           FROM ( SELECT billing_period.service_provider_id,
                    billing_period.billing_cycle_end_date,
                    billing_period.id,
                    row_number() OVER (PARTITION BY billing_period.service_provider_id ORDER BY billing_period.billing_cycle_end_date DESC) AS row_num
                   FROM billing_period
                  WHERE EXTRACT(year FROM CURRENT_DATE) = billing_period.bill_year::numeric AND billing_period.is_active = true AND billing_period.billing_cycle_end_date < CURRENT_DATE AND billing_period.is_deleted = false) bp_1
          WHERE bp_1.row_num = 1
        )
 SELECT gen_random_uuid() AS id,
    md.msisdn AS service_number,
        CASE
            WHEN (EXISTS ( SELECT 1
               FROM device_status_history dsh
              WHERE dsh.mobility_device_id = md.id AND dsh.date_of_change IS NOT NULL AND (dsh.current_status::text IN ( SELECT ds_1.status
                       FROM device_status ds_1
                      WHERE sp.integration_id = ds_1.integration_id))
              ORDER BY dsh.date_of_change DESC
             LIMIT 1)) THEN
            CASE
                WHEN (EXISTS ( SELECT 1
                   FROM cte_device_status_history cte
                  WHERE cte.mobility_device_id = md.id AND lower(cte.current_status::text) = 'unknown'::text AND lower(cte.previous_status::text) = 'c'::text)) AND ((( SELECT max(cte_device_status_history_not_cancel_to_unknown.date_of_change) AS max
                   FROM cte_device_status_history_not_cancel_to_unknown
                  WHERE cte_device_status_history_not_cancel_to_unknown.mobility_device_id = md.id)) IS NULL OR (( SELECT max(cte_device_status_history_not_cancel_to_unknown.date_of_change) AS max
                   FROM cte_device_status_history_not_cancel_to_unknown
                  WHERE cte_device_status_history_not_cancel_to_unknown.mobility_device_id = md.id)) < (( SELECT max(cte_device_status_history_cancel_to_unknown.date_of_change) AS max
                   FROM cte_device_status_history_cancel_to_unknown
                  WHERE cte_device_status_history_cancel_to_unknown.mobility_device_id = md.id))) OR lower((( SELECT cte_device_status_history.current_status
                   FROM cte_device_status_history
                  WHERE cte_device_status_history.mobility_device_id = md.id AND lower(cte_device_status_history.current_status::text) = 'c'::text
                  ORDER BY cte_device_status_history.date_of_change DESC
                 LIMIT 1))::text) = 'c'::text THEN 'C'::character varying
                ELSE md.sim_status
            END
            ELSE md.sim_status
        END AS device_status,
        CASE
            WHEN (EXISTS ( SELECT 1
               FROM device_status_history dsh
              WHERE dsh.mobility_device_id = md.id AND dsh.date_of_change IS NOT NULL AND (dsh.current_status::text IN ( SELECT ds_1.status
                       FROM device_status ds_1
                      WHERE sp.integration_id = ds_1.integration_id))
              ORDER BY dsh.date_of_change DESC
             LIMIT 1)) THEN
            CASE
                WHEN (EXISTS ( SELECT 1
                   FROM cte_device_status_history cte
                  WHERE cte.mobility_device_id = md.id AND lower(cte.current_status::text) = 'unknown'::text AND lower(cte.previous_status::text) = 'c'::text)) AND ((( SELECT max(cte_device_status_history_not_cancel_to_unknown.date_of_change) AS max
                   FROM cte_device_status_history_not_cancel_to_unknown
                  WHERE cte_device_status_history_not_cancel_to_unknown.mobility_device_id = md.id)) IS NULL OR (( SELECT max(cte_device_status_history_not_cancel_to_unknown.date_of_change) AS max
                   FROM cte_device_status_history_not_cancel_to_unknown
                  WHERE cte_device_status_history_not_cancel_to_unknown.mobility_device_id = md.id)) < (( SELECT max(cte_device_status_history_cancel_to_unknown.date_of_change) AS max
                   FROM cte_device_status_history_cancel_to_unknown
                  WHERE cte_device_status_history_cancel_to_unknown.mobility_device_id = md.id))) OR ((( SELECT cte_device_status_history.current_status
                   FROM cte_device_status_history
                  WHERE cte_device_status_history.mobility_device_id = md.id AND lower(cte_device_status_history.current_status::text) = 'c'::text
                  ORDER BY cte_device_status_history.date_of_change DESC
                 LIMIT 1))::text) = 'C'::text THEN ( SELECT cte_device_status_history_cancel_to_unknown.date_of_change
                   FROM cte_device_status_history_cancel_to_unknown
                  WHERE cte_device_status_history_cancel_to_unknown.mobility_device_id = md.id
                  ORDER BY cte_device_status_history_cancel_to_unknown.date_of_change DESC
                 LIMIT 1)
                ELSE ( SELECT cte_device_status_history.date_of_change
                   FROM cte_device_status_history
                  WHERE cte_device_status_history.mobility_device_id = md.id AND (cte_device_status_history.current_status::text IN ( SELECT ds_1.status
                           FROM device_status ds_1
                          WHERE sp.integration_id = ds_1.integration_id))
                  ORDER BY cte_device_status_history.date_of_change DESC
                 LIMIT 1)
            END
            ELSE md.date_activated
        END AS carrier_last_status_date,
    ds.is_active_status,
    ds.should_have_billed_service,
    md.iccid,
    md.service_provider_id,
    sp.display_name AS service_provider,
    rs.activated_date,
    rs.disconnected_date,
    rsp.service_product_id,
    NULLIF(rsp.package_id, 0) AS packageid,
    rsp.service_id,
    rsp.product_id,
    rsp.description,
    rsp.rate,
    rsp.status AS revio_status,
        CASE
            WHEN rsp.status::text = 'ACTIVE'::text THEN true
            ELSE false
        END AS rev_is_active_status,
    rsp.cost,
    rsp.wholesale_description,
    rsp.quantity,
    rsp.integration_authentication_id,
    COALESCE(rc.rev_customer_id, sc.rev_customer_id) AS rev_account_number,
    COALESCE(rc.customer_name, sc.customer_name) AS customer_name,
    rp.id AS rev_product_id,
    rp.product_type_id,
    rp.description AS product_description,
    rst.service_type_id,
    COALESCE(dt.tenant_id, ia.tenant_id, sp.tenant_id) AS tenant_id,
    md.last_activated_date AS carrier_activated_date,
    jcrp.rate_plan_name AS customer_rate_plan,
    md.carrier_rate_plan,
    COALESCE(dhg.usage, 0::numeric) AS usage,
    bp.billing_cycle_end_date AS usage_cycle
   FROM mobility_device md
     JOIN mobility_device_tenant dt ON md.id = dt.mobility_device_id
     JOIN device_status ds ON ds.id = md.device_status_id
     JOIN serviceprovider sp ON sp.id = md.service_provider_id
     JOIN integration i ON i.id = sp.integration_id
     LEFT JOIN customers s ON dt.customer_id = s.id AND s.rev_customer_id IS NOT NULL
     LEFT JOIN revcustomer sc ON s.rev_customer_id = sc.id AND sc.status::text <> 'CLOSED'::text AND sc.is_active = true AND sc.is_deleted = false
     LEFT JOIN rev_service rs ON dt.rev_service_id = rs.id
     LEFT JOIN rev_service_product rsp ON rs.rev_service_id = rsp.service_id AND rsp.integration_authentication_id = rs.integration_authentication_id AND rsp.status::text = 'ACTIVE'::text
     LEFT JOIN revcustomer rc ON rsp.customer_id::text = rc.rev_customer_id::text AND rsp.integration_authentication_id = rc.integration_authentication_id AND rc.status::text <> 'CLOSED'::text AND rc.is_active = true AND rc.is_deleted = false
     LEFT JOIN integration_authentication ia ON rc.integration_authentication_id = ia.id
     LEFT JOIN rev_product rp ON rsp.product_id = rp.product_id AND rsp.integration_authentication_id = rp.integration_authentication_id
     LEFT JOIN rev_service_type rst ON rst.id = rs.rev_service_type_id AND rst.integration_authentication_id = rs.integration_authentication_id
     LEFT JOIN rev_product_type rpt ON rpt.product_type_id = rp.product_type_id AND rpt.integration_authentication_id = rp.integration_authentication_id
     LEFT JOIN customerrateplan jcrp ON dt.customer_rate_plan_id = jcrp.id
     LEFT JOIN billing_period_cte bp ON bp.service_provider_id = md.service_provider_id
     LEFT JOIN ( SELECT dh.id,
            dh.tenant_id,
            dh.iccid,
            round(COALESCE(dh.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3) AS usage,
            dh.billing_period_id
           FROM device_history dh
             JOIN billing_period b ON b.id = dh.billing_period_id
             LEFT JOIN device_status ds_1 ON ds_1.id = dh.device_status_id
             JOIN billing_period_cte c ON c.id = dh.billing_period_id
          WHERE ds_1.is_active_status = true OR dh.last_activated_date < b.billing_cycle_end_date AND dh.last_activated_date > b.billing_cycle_start_date OR dh.carrier_cycle_usage > 0) dhg ON dhg.id = dt.mobility_device_id AND dhg.iccid::text = md.iccid::text AND dt.tenant_id = dhg.tenant_id
  WHERE md.is_active = true AND dt.is_active = true AND md.sim_status IS NOT NULL;


-- public.vw_m2m_rev_service_products_comp_id source



CREATE OR REPLACE VIEW public.vw_m2m_rev_service_products_comp_id_
AS WITH billing_period_cte AS (
         SELECT bp.service_provider_id,
            bp.billing_cycle_end_date,
            bp.id
           FROM ( SELECT billing_period_1.service_provider_id,
                    billing_period_1.billing_cycle_end_date,
                    billing_period_1.id,
                    row_number() OVER (PARTITION BY billing_period_1.service_provider_id ORDER BY billing_period_1.billing_cycle_end_date DESC) AS row_num
                   FROM billing_period billing_period_1
                  WHERE billing_period_1.bill_year::numeric = EXTRACT(year FROM CURRENT_DATE) AND billing_period_1.is_active = true AND billing_period_1.billing_cycle_end_date < (CURRENT_TIMESTAMP - '05:00:00'::interval) AND billing_period_1.is_deleted = false) bp
          WHERE bp.row_num = 1
        )
 SELECT devicetenant.id,
        CASE
            WHEN serviceprovider.integration_id = 12 THEN device.eid
            ELSE
            CASE
                WHEN serviceprovider.integration_id = 13 THEN device.iccid
                ELSE COALESCE(device.msisdn, device.iccid)
            END
        END AS service_number,
    device_status.display_name AS device_status,
    COALESCE(dateactivated.date_of_change, device.date_activated) AS carrier_last_status_date,
        CASE
            WHEN device_status.display_name::text = ANY (ARRAY['RestoredFromArchive'::text, 'Restored from archive'::text]) THEN true
            ELSE device_status.is_active_status
        END AS is_active_status,
    device_status.should_have_billed_service,
    device.iccid,
    device.service_provider_id,
    serviceprovider.display_name AS service_provider,
    device.communication_plan,
    rev_service.activated_date::timestamp without time zone AS activated_date,
    rev_service.disconnected_date,
    rev_service_product.service_product_id,
        CASE
            WHEN rev_service_product.package_id = 0 THEN NULL::integer
            ELSE rev_service_product.package_id
        END AS package_id,
    rev_service_product.service_id,
    rev_service_product.product_id,
    rev_service_product.description,
    rev_service_product.rate,
    rev_service_product.status AS reviostatus,
        CASE
            WHEN rev_service_product.status::text = 'ACTIVE'::text THEN true
            ELSE false
        END AS rev_is_active_status,
    rev_service_product.cost,
    rev_service_product.wholesale_description,
    rev_service_product.quantity,
    rev_service_product.integration_authentication_id,
    COALESCE(revcustomer.rev_customer_id, sitecustomer.rev_customer_id::text::character varying) AS rev_account_number,
    COALESCE(revcustomer.customer_name, sitecustomer.customer_name) AS customer_name,
    rev_product.id AS rev_product_id,
    rev_product.product_type_id,
    rev_product.description AS product_description,
    rev_service_type.service_type_id,
    devicetenant.tenant_id,
    device.last_activated_date AS carrier_activated_date,
    customerrateplan.rate_plan_name AS customer_rate_plan,
    device.carrier_rate_plan,
    site.id AS customer_id,
    COALESCE(rev_service.rev_service_line_status, devicetenant.rev_line_status) AS rev_service_line_status,
    COALESCE(device.modified_date, device.created_date) AS modified_date,
    rev_service.id AS rev_service_id,
    rev_service_product.id AS rev_service_product_id,
    devicetenant.id AS dev_tenant_id,
    COALESCE(device_history_grouped.usage, 0::numeric) AS usage,
    array_to_string(array_remove(ARRAY[device.id::bigint, devicetenant.id::bigint, device_status.id::bigint, serviceprovider.id::bigint, integration.id::bigint, site.id::bigint, rev_service.id::bigint, rev_service_product.id::bigint, rev_product.id::bigint, rev_service_type.id::bigint, rev_product_type.id::bigint, customerrateplan.id::bigint, device_history_grouped.id::bigint, device_history_grouped.device_history_id], NULL::integer::bigint), '-'::text) AS composite_id,
    billing_period.billing_cycle_end_date AS usage_cycle
   FROM device_tenant devicetenant
     JOIN device ON devicetenant.device_id = device.id AND device.is_active = true AND device.is_deleted = false
     JOIN device_status ON device_status.id = device.device_status_id
     JOIN serviceprovider ON serviceprovider.id = device.service_provider_id AND serviceprovider.is_active = true AND serviceprovider.is_deleted = false
     JOIN integration ON integration.id = serviceprovider.integration_id AND integration.portal_type_id = 0
     LEFT JOIN rev_service ON rev_service.id = devicetenant.rev_service_id
     LEFT JOIN customerrateplan ON devicetenant.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customers site ON devicetenant.customer_id = site.id AND site.rev_customer_id IS NOT NULL
     LEFT JOIN revcustomer sitecustomer ON site.rev_customer_id = sitecustomer.id AND sitecustomer.status::text <> 'CLOSED'::text AND sitecustomer.is_active = true AND sitecustomer.is_deleted = false
     LEFT JOIN rev_service_product ON rev_service.rev_service_id = rev_service_product.service_id AND rev_service_product.integration_authentication_id = rev_service.integration_authentication_id AND rev_service_product.status::text = 'ACTIVE'::text AND rev_service_product.is_active = true AND rev_service_product.is_deleted = false
     LEFT JOIN revcustomer ON rev_service_product.customer_id::text = revcustomer.rev_customer_id::text AND rev_service_product.integration_authentication_id = revcustomer.integration_authentication_id AND revcustomer.status::text <> 'CLOSED'::text AND revcustomer.is_active = true AND revcustomer.is_deleted = false
     LEFT JOIN integration_authentication integrationauthentication ON revcustomer.integration_authentication_id = integrationauthentication.id
     LEFT JOIN rev_product ON rev_service_product.product_id = rev_product.product_id AND rev_service_product.integration_authentication_id = rev_product.integration_authentication_id
     LEFT JOIN rev_service_type ON rev_service_type.id = rev_service.rev_service_type_id AND rev_service_type.integration_authentication_id = rev_service.integration_authentication_id
     LEFT JOIN rev_product_type ON rev_product_type.product_type_id = rev_product.product_type_id AND rev_product_type.integration_authentication_id = rev_product.integration_authentication_id AND (rev_product_type.product_type_code IS NULL OR rev_product_type.product_type_code::text ~~ 'RECURRING_%'::text)
     LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = device.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status_1.status
                   FROM device_status device_status_1
                  WHERE serviceprovider.integration_id = device_status_1.integration_id))
          ORDER BY device_status_history.date_of_change DESC
         LIMIT 1) dateactivated ON true
     LEFT JOIN ( WITH bp AS (
                 SELECT billing_period_1.service_provider_id,
                    billing_period_1.billing_cycle_end_date,
                    billing_period_1.id,
                    row_number() OVER (PARTITION BY billing_period_1.service_provider_id ORDER BY billing_period_1.billing_cycle_end_date DESC) AS row_num
                   FROM billing_period billing_period_1
                  WHERE EXTRACT(year FROM CURRENT_DATE) = billing_period_1.bill_year::numeric AND billing_period_1.is_active = true AND billing_period_1.billing_cycle_end_date < CURRENT_DATE AND billing_period_1.is_deleted = false
                )
         SELECT bp.service_provider_id,
            bp.billing_cycle_end_date,
            bp.id
           FROM bp
          WHERE bp.row_num = 1) billing_period ON billing_period.service_provider_id = device.service_provider_id
     LEFT JOIN LATERAL ( SELECT device_history.id,
            device_history.tenant_id,
            device_history.iccid,
            round(COALESCE(device_history.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3) AS usage,
            device_history.billing_period_id,
            device_history.device_history_id
           FROM device_history
             JOIN billing_period b ON b.id = device_history.billing_period_id
             LEFT JOIN device_status device_status_1 ON device_status_1.id = device_history.device_status_id
             JOIN billing_period_cte c ON c.id = device_history.billing_period_id
          WHERE device_status_1.is_active_status = true OR device_history.last_activated_date < b.billing_cycle_end_date AND device_history.last_activated_date > b.billing_cycle_start_date OR device_history.carrier_cycle_usage > 0) device_history_grouped ON device_history_grouped.id = devicetenant.device_id AND device_history_grouped.iccid::text = device.iccid::text AND devicetenant.tenant_id = device_history_grouped.tenant_id
  WHERE device.is_deleted = false AND devicetenant.is_deleted = false AND (rev_service_type.service_type_id IS NULL OR rev_service_type.service_type_id = 18 OR rev_service_type.description::text = 'Wireless Service'::text);


-- public.vw_mobility_rev_service_products_with_ids_ source

CREATE OR REPLACE VIEW public.vw_mobility_rev_service_products_with_ids_
AS WITH cte_devicestatushistory AS (
         SELECT mobility_device_status_history.date_of_change,
            mobility_device_status_history.mobility_device_id,
            mobility_device_status_history.current_status,
            mobility_device_status_history.previous_status
           FROM mobility_device_status_history
          WHERE mobility_device_status_history.date_of_change IS NOT NULL
        ), cte_devicestatushistory_cancelstatustounknownstatus AS (
         SELECT cte_devicestatushistory.date_of_change,
            cte_devicestatushistory.mobility_device_id,
            cte_devicestatushistory.current_status,
            cte_devicestatushistory.previous_status
           FROM cte_devicestatushistory
          WHERE lower(cte_devicestatushistory.current_status::text) = 'c'::text AND lower(cte_devicestatushistory.previous_status::text) <> 'c'::text
        ), cte_devicestatushistory_notcancelstatustounknownstatus AS (
         SELECT cte_devicestatushistory.date_of_change,
            cte_devicestatushistory.mobility_device_id,
            cte_devicestatushistory.current_status,
            cte_devicestatushistory.previous_status
           FROM cte_devicestatushistory
          WHERE lower(cte_devicestatushistory.current_status::text) = 'unknown'::text AND lower(cte_devicestatushistory.previous_status::text) <> 'c'::text
        ), billing_period_cte AS (
         SELECT bp_1.service_provider_id,
            bp_1.billing_cycle_end_date,
            bp_1.id
           FROM ( SELECT billing_period_1.service_provider_id,
                    billing_period_1.billing_cycle_end_date,
                    billing_period_1.id,
                    row_number() OVER (PARTITION BY billing_period_1.service_provider_id ORDER BY billing_period_1.billing_cycle_end_date DESC) AS row_num
                   FROM billing_period billing_period_1
                  WHERE EXTRACT(year FROM CURRENT_DATE) = billing_period_1.bill_year::numeric AND billing_period_1.is_active = true AND billing_period_1.billing_cycle_end_date < (CURRENT_TIMESTAMP - '05:00:00'::interval) AND billing_period_1.is_deleted = false) bp_1
          WHERE bp_1.row_num = 1
        )
 SELECT gen_random_uuid() AS id,
    mobility_device.msisdn AS service_number,
        CASE
            WHEN device_status.is_active_status = false AND (EXISTS ( SELECT 1
               FROM mobility_device_status_history
              WHERE mobility_device_status_history.mobility_device_id = mobility_device.id AND mobility_device_status_history.date_of_change IS NOT NULL AND (mobility_device_status_history.current_status::text IN ( SELECT device_status_1.status
                       FROM device_status device_status_1
                      WHERE serviceprovider.integration_id = device_status_1.integration_id))
              ORDER BY mobility_device_status_history.date_of_change DESC
             LIMIT 1)) THEN
            CASE
                WHEN (EXISTS ( SELECT 1
                   FROM cte_devicestatushistory
                  WHERE cte_devicestatushistory.mobility_device_id = mobility_device.id AND lower(cte_devicestatushistory.current_status::text) = 'unknown'::text AND lower(cte_devicestatushistory.previous_status::text) = 'c'::text)) AND ((( SELECT max(cte_devicestatushistory_notcancelstatustounknownstatus.date_of_change) AS max
                   FROM cte_devicestatushistory_notcancelstatustounknownstatus
                  WHERE cte_devicestatushistory_notcancelstatustounknownstatus.mobility_device_id = mobility_device.id)) IS NULL OR (( SELECT max(cte_devicestatushistory_notcancelstatustounknownstatus.date_of_change) AS max
                   FROM cte_devicestatushistory_notcancelstatustounknownstatus
                  WHERE cte_devicestatushistory_notcancelstatustounknownstatus.mobility_device_id = mobility_device.id)) < (( SELECT max(cte_devicestatushistory_cancelstatustounknownstatus.date_of_change) AS max
                   FROM cte_devicestatushistory_cancelstatustounknownstatus
                  WHERE cte_devicestatushistory_cancelstatustounknownstatus.mobility_device_id = mobility_device.id))) OR lower((( SELECT cte_devicestatushistory.current_status
                   FROM cte_devicestatushistory
                  WHERE cte_devicestatushistory.mobility_device_id = mobility_device.id AND lower(cte_devicestatushistory.current_status::text) = 'c'::text
                  ORDER BY cte_devicestatushistory.date_of_change DESC
                 LIMIT 1))::text) = 'c'::text THEN 'C'::character varying
                ELSE mobility_device.sim_status
            END
            ELSE mobility_device.sim_status
        END AS device_status,
    mobility_device.last_activated_date AS carrierlaststatusdate,
    device_status.is_active_status,
    device_status.should_have_billed_service,
    mobility_device.iccid,
    mobility_device.service_provider_id,
    serviceprovider.display_name AS serviceprovider,
    rev_service.activated_date::timestamp without time zone AS activated_date,
    rev_service.disconnected_date,
    rev_service_product.service_product_id,
    NULLIF(rev_service_product.package_id, 0) AS package_id,
    rev_service_product.service_id,
    rev_service_product.product_id,
    rev_service_product.description,
    rev_service_product.rate,
    rev_service_product.status AS reviostatus,
        CASE
            WHEN rev_service_product.status::text = 'ACTIVE'::text THEN true
            ELSE false
        END AS rev_is_active_status,
    rev_service_product.cost,
    rev_service_product.wholesale_description,
    rev_service_product.quantity,
    rev_service_product.integration_authentication_id,
    COALESCE(revcustomer.rev_customer_id, sitecustomer.rev_customer_id) AS revaccountnumber,
    COALESCE(revcustomer.customer_name, sitecustomer.customer_name) AS customername,
    rev_product.id AS rev_product_id,
    rev_product.product_type_id,
    rev_product.description AS product_description,
    rev_service_type.service_type_id,
    COALESCE(device_tenant.tenant_id, integration_authentication.tenant_id, serviceprovider.tenant_id) AS tenant_id,
    mobility_device.last_activated_date AS carrieractivateddate,
    customerrateplan.rate_plan_name AS customerrateplan,
    mobility_device.carrier_rate_plan,
    site.id AS customer_id,
    COALESCE(rev_service.rev_service_line_status, device_tenant.rev_line_status) AS rev_service_line_status,
    mobility_device.id AS dt_id,
    COALESCE(mobility_device.modified_date, mobility_device.created_date) AS modified_date,
    rev_service_product.id AS rev_service_product_id,
    rev_service.id AS rev_service_id,
    mobility_device.id AS mob_dev_id,
    COALESCE(dhg.usage, 0::numeric) AS usage,
    mobility_device.id AS mobility_device_id,
    device_tenant.id AS device_tenant_id,
    device_status.id AS device_status_id,
    serviceprovider.id AS service_provider_id_d,
    integration.id AS integration_id,
    site.id AS customer_id_id,
    sitecustomer.id AS rev_customer_id_id,
    rev_service.id AS rev_service_id_id,
    rev_service_product.id AS rev_service_product_id_id,
    revcustomer.id AS rev_customer_id2,
    integration_authentication.id AS integration_auth_id,
    rev_product.id AS rev_product_id_id,
    rev_service_type.id AS rev_service_type_id,
    rev_product_type.id AS rev_product_type_id_id,
    customerrateplan.id AS customerrateplan_id,
    array_to_string(array_remove(ARRAY[mobility_device.id::bigint, device_tenant.id::bigint, device_status.id::bigint, serviceprovider.id::bigint, integration.id::bigint, site.id::bigint, rev_service.id::bigint, rev_service_product.id::bigint, rev_product.id::bigint, rev_service_type.id::bigint, rev_product_type.id::bigint, customerrateplan.id::bigint, dhg.device_history_id], NULL::integer::bigint), '-'::text) AS composite_id,
    billing_period.billing_cycle_end_date AS usage_cycle
   FROM mobility_device
     JOIN mobility_device_tenant device_tenant ON mobility_device.id = device_tenant.mobility_device_id
     JOIN device_status ON device_status.id = mobility_device.device_status_id
     JOIN serviceprovider ON serviceprovider.id = mobility_device.service_provider_id
     JOIN integration ON integration.id = serviceprovider.integration_id
     LEFT JOIN customers site ON device_tenant.customer_id = site.id AND site.rev_customer_id IS NOT NULL
     LEFT JOIN revcustomer sitecustomer ON site.rev_customer_id = sitecustomer.id AND sitecustomer.status::text <> 'CLOSED'::text AND sitecustomer.is_active = true AND sitecustomer.is_deleted = false
     LEFT JOIN rev_service ON device_tenant.rev_service_id = rev_service.id
     LEFT JOIN rev_service_product ON rev_service.rev_service_id = rev_service_product.service_id AND rev_service_product.integration_authentication_id = rev_service.integration_authentication_id AND rev_service_product.status::text = 'ACTIVE'::text
     LEFT JOIN revcustomer ON rev_service_product.customer_id::text = revcustomer.rev_customer_id::text AND rev_service_product.integration_authentication_id = revcustomer.integration_authentication_id AND revcustomer.status::text <> 'CLOSED'::text AND revcustomer.is_active = true AND revcustomer.is_deleted = false
     LEFT JOIN integration_authentication integration_authentication ON revcustomer.integration_authentication_id = integration_authentication.id
     LEFT JOIN rev_product ON rev_service_product.product_id = rev_product.product_id AND rev_service_product.integration_authentication_id = rev_product.integration_authentication_id
     LEFT JOIN rev_service_type ON rev_service_type.id = rev_service.rev_service_type_id AND rev_service_type.integration_authentication_id = rev_service.integration_authentication_id
     LEFT JOIN rev_product_type ON rev_product_type.product_type_id = rev_product.product_type_id AND rev_product_type.integration_authentication_id = rev_product.integration_authentication_id
     LEFT JOIN customerrateplan ON device_tenant.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN ( WITH bp AS (
                 SELECT billing_period_1.service_provider_id,
                    billing_period_1.billing_cycle_end_date,
                    billing_period_1.id,
                    row_number() OVER (PARTITION BY billing_period_1.service_provider_id ORDER BY billing_period_1.billing_cycle_end_date DESC) AS row_num
                   FROM billing_period billing_period_1
                  WHERE EXTRACT(year FROM CURRENT_DATE) = billing_period_1.bill_year::numeric AND billing_period_1.is_active = true AND billing_period_1.billing_cycle_end_date < CURRENT_DATE AND billing_period_1.is_deleted = false
                )
         SELECT bp.service_provider_id,
            bp.billing_cycle_end_date,
            bp.id
           FROM bp
          WHERE bp.row_num = 1) billing_period ON billing_period.service_provider_id = mobility_device.service_provider_id
     LEFT JOIN ( SELECT dh.id,
            dh.tenant_id,
            dh.iccid,
            round(COALESCE(dh.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3) AS usage,
            dh.billing_period_id,
            dh.device_history_id
           FROM device_history dh
             JOIN billing_period b ON b.id = dh.billing_period_id
             LEFT JOIN device_status ds_1 ON ds_1.id = dh.device_status_id
             JOIN billing_period_cte c ON c.id = dh.billing_period_id
          WHERE ds_1.is_active_status = true OR dh.last_activated_date < b.billing_cycle_end_date AND dh.last_activated_date > b.billing_cycle_start_date OR dh.carrier_cycle_usage > 0) dhg ON dhg.id = device_tenant.mobility_device_id AND dhg.iccid::text = mobility_device.iccid::text AND device_tenant.tenant_id = dhg.tenant_id
  WHERE mobility_device.is_deleted = false AND device_tenant.is_deleted = false AND (rev_product_type.product_type_code IS NULL OR rev_product_type.product_type_code::text ~~ 'RECURRING_%'::text) AND integration.portal_type_id = 2;

 -- public.vw_combined_rev_service_products source
CREATE OR REPLACE VIEW public.vw_combined_rev_service_products
AS WITH combined AS (
         SELECT vmmrsp.service_number,
            vmmrsp.device_status,
            vmmrsp.carrier_last_status_date,
            vmmrsp.is_active_status,
            vmmrsp.should_have_billed_service,
            vmmrsp.iccid,
            vmmrsp.service_provider_id,
            vmmrsp.service_provider,
            vmmrsp.communication_plan,
            vmmrsp.activated_date,
            vmmrsp.disconnected_date,
            vmmrsp.service_product_id,
            vmmrsp.package_id,
            vmmrsp.service_id,
            vmmrsp.product_id,
            vmmrsp.description,
            vmmrsp.rate,
            vmmrsp.reviostatus AS rev_io_status,
            vmmrsp.rev_is_active_status,
            vmmrsp.cost,
            vmmrsp.wholesale_description,
            vmmrsp.quantity,
            vmmrsp.integration_authentication_id,
            vmmrsp.rev_account_number,
            vmmrsp.customer_name,
            vmmrsp.rev_product_id,
            vmmrsp.product_type_id,
            vmmrsp.product_description,
            vmmrsp.service_type_id,
            vmmrsp.tenant_id,
            vmmrsp.carrier_activated_date,
            vmmrsp.customer_rate_plan AS customer_rate_plan_name,
            vmmrsp.carrier_rate_plan,
            ((('Device '::text || COALESCE(vmmrsp.reviostatus::text, 'not'::text)) || ' in Billing Platform but '::text) || vmmrsp.device_status::text) || ' in carrier'::text AS variance,
            vmmrsp.customer_id,
            vmmrsp.rev_service_line_status,
            vmmrsp.id,
            vmmrsp.modified_date,
            vmmrsp.rev_service_id,
            vmmrsp.rev_service_product_id,
            vmmrsp.dev_tenant_id,
            NULL::integer AS mob_tenant_id,
            vmmrsp.usage,
            vmmrsp.composite_id,
            vmmrsp.usage_cycle
           FROM vw_m2m_rev_service_products_comp_id_ vmmrsp
          WHERE vmmrsp.is_active_status = true OR vmmrsp.rev_is_active_status = true
        UNION ALL
         SELECT vmrsp.service_number,
            vmrsp.device_status,
            vmrsp.carrierlaststatusdate AS carrier_last_status_date,
            vmrsp.is_active_status,
            vmrsp.should_have_billed_service,
            vmrsp.iccid,
            vmrsp.service_provider_id,
            vmrsp.serviceprovider AS service_provider,
            NULL::character varying AS communication_plan,
            vmrsp.activated_date,
            vmrsp.disconnected_date,
            vmrsp.service_product_id,
            vmrsp.package_id,
            vmrsp.service_id,
            vmrsp.product_id,
            vmrsp.description,
            vmrsp.rate,
            vmrsp.reviostatus AS rev_io_status,
            vmrsp.rev_is_active_status,
            vmrsp.cost,
            vmrsp.wholesale_description,
            vmrsp.quantity,
            vmrsp.integration_authentication_id,
            vmrsp.revaccountnumber AS rev_account_number,
            vmrsp.customername AS customer_name,
            vmrsp.rev_product_id,
            vmrsp.product_type_id,
            vmrsp.product_description,
            vmrsp.service_type_id,
            vmrsp.tenant_id,
            vmrsp.carrieractivateddate AS carrier_activated_date,
            vmrsp.customerrateplan AS customer_rate_plan_name,
            vmrsp.carrier_rate_plan,
            ((('Device '::text || COALESCE(vmrsp.reviostatus::text, 'not'::text)) || ' in Billing Platform but '::text) || vmrsp.device_status::text) || ' in carrier'::text AS variance,
            vmrsp.customer_id,
            vmrsp.rev_service_line_status,
            vmrsp.dt_id AS id,
            vmrsp.modified_date,
            vmrsp.rev_service_id,
            vmrsp.rev_service_product_id,
            NULL::integer AS dev_tenant_id,
            vmrsp.device_tenant_id AS mob_tenant_id,
            vmrsp.usage,
            vmrsp.composite_id,
            vmrsp.usage_cycle
           FROM vw_mobility_rev_service_products_with_ids_ vmrsp
          WHERE vmrsp.is_active_status = true OR vmrsp.rev_is_active_status = true
        )
 SELECT row_number() OVER (ORDER BY combined.modified_date, combined.tenant_id) AS id_seq,
    combined.service_number,
    combined.device_status,
    combined.carrier_last_status_date,
    combined.is_active_status,
    combined.should_have_billed_service,
    combined.iccid,
    combined.service_provider_id,
    combined.service_provider,
    combined.communication_plan,
    combined.activated_date,
    combined.disconnected_date,
    combined.service_product_id,
    combined.package_id,
    combined.service_id,
    combined.product_id,
    combined.description,
    combined.rate,
    combined.rev_io_status,
    combined.rev_is_active_status,
    combined.cost,
    combined.wholesale_description,
    combined.quantity,
    combined.integration_authentication_id,
    combined.rev_account_number,
    combined.customer_name,
    combined.rev_product_id,
    combined.product_type_id,
    combined.product_description,
    combined.service_type_id,
    combined.tenant_id,
    combined.carrier_activated_date,
    combined.customer_rate_plan_name,
    combined.carrier_rate_plan,
    combined.variance,
    combined.customer_id,
    combined.rev_service_line_status,
    combined.modified_date,
    combined.rev_service_id,
    combined.rev_service_product_id,
    combined.dev_tenant_id,
    combined.mob_tenant_id,
    combined.usage,
    combined.composite_id AS id,
    combined.usage_cycle
   FROM combined
  WHERE (combined.should_have_billed_service = false OR combined.is_active_status <> combined.rev_is_active_status) AND combined.device_status::text <> 'Restored from archive'::text;

-- public.vw_combined_rev_service_products_with_out_variance source
CREATE OR REPLACE VIEW public.vw_combined_rev_service_products_with_out_variance
AS WITH combined AS (
         SELECT vmmrsp.service_number,
            vmmrsp.device_status,
            vmmrsp.carrier_last_status_date,
            vmmrsp.is_active_status,
            vmmrsp.should_have_billed_service,
            vmmrsp.iccid,
            vmmrsp.service_provider_id,
            vmmrsp.service_provider,
            vmmrsp.communication_plan,
            vmmrsp.activated_date,
            vmmrsp.disconnected_date,
            vmmrsp.service_product_id,
            vmmrsp.package_id,
            vmmrsp.service_id,
            vmmrsp.product_id,
            vmmrsp.description,
            vmmrsp.rate,
            vmmrsp.reviostatus AS rev_io_status,
            vmmrsp.rev_is_active_status,
            vmmrsp.cost,
            vmmrsp.wholesale_description,
            vmmrsp.quantity,
            vmmrsp.integration_authentication_id,
            vmmrsp.rev_account_number,
            vmmrsp.customer_name,
            vmmrsp.rev_product_id,
            vmmrsp.product_type_id,
            vmmrsp.product_description,
            vmmrsp.service_type_id,
            vmmrsp.tenant_id,
            vmmrsp.carrier_activated_date,
            vmmrsp.customer_rate_plan AS customer_rate_plan_name,
            vmmrsp.carrier_rate_plan,
            ((('Device '::text || COALESCE(vmmrsp.reviostatus::text, 'not'::text)) || ' in Billing Platform but '::text) || vmmrsp.device_status::text) || ' in carrier'::text AS variance,
            vmmrsp.customer_id,
            vmmrsp.rev_service_line_status,
            vmmrsp.id,
            vmmrsp.modified_date,
            vmmrsp.rev_service_id,
            vmmrsp.rev_service_product_id,
            vmmrsp.dev_tenant_id,
            NULL::integer AS mob_tenant_id,
            vmmrsp.usage,
            vmmrsp.composite_id,
            vmmrsp.usage_cycle
           FROM vw_m2m_rev_service_products_comp_id_ vmmrsp
          WHERE vmmrsp.is_active_status = true OR vmmrsp.rev_is_active_status = true
        UNION ALL
         SELECT vmrsp.service_number,
            vmrsp.device_status,
            vmrsp.carrierlaststatusdate AS carrier_last_status_date,
            vmrsp.is_active_status,
            vmrsp.should_have_billed_service,
            vmrsp.iccid,
            vmrsp.service_provider_id,
            vmrsp.serviceprovider AS service_provider,
            NULL::character varying AS communication_plan,
            vmrsp.activated_date,
            vmrsp.disconnected_date,
            vmrsp.service_product_id,
            vmrsp.package_id,
            vmrsp.service_id,
            vmrsp.product_id,
            vmrsp.description,
            vmrsp.rate,
            vmrsp.reviostatus AS rev_io_status,
            vmrsp.rev_is_active_status,
            vmrsp.cost,
            vmrsp.wholesale_description,
            vmrsp.quantity,
            vmrsp.integration_authentication_id,
            vmrsp.revaccountnumber AS rev_account_number,
            vmrsp.customername AS customer_name,
            vmrsp.rev_product_id,
            vmrsp.product_type_id,
            vmrsp.product_description,
            vmrsp.service_type_id,
            vmrsp.tenant_id,
            vmrsp.carrieractivateddate AS carrier_activated_date,
            vmrsp.customerrateplan AS customer_rate_plan_name,
            vmrsp.carrier_rate_plan,
            ((('Device '::text || COALESCE(vmrsp.reviostatus::text, 'not'::text)) || ' in Billing Platform but '::text) || vmrsp.device_status::text) || ' in carrier'::text AS variance,
            vmrsp.customer_id,
            vmrsp.rev_service_line_status,
            vmrsp.dt_id AS id,
            vmrsp.modified_date,
            vmrsp.rev_service_id,
            vmrsp.rev_service_product_id,
            NULL::integer AS dev_tenant_id,
            vmrsp.mob_dev_id AS mob_tenant_id,
            vmrsp.usage,
            vmrsp.composite_id,
            vmrsp.usage_cycle
           FROM vw_mobility_rev_service_products_with_ids_ vmrsp
          WHERE vmrsp.is_active_status = true OR vmrsp.rev_is_active_status = true
        )
 SELECT combined.service_number,
    combined.device_status,
    combined.carrier_last_status_date,
    combined.is_active_status,
    combined.should_have_billed_service,
    combined.iccid,
    combined.service_provider_id,
    combined.service_provider,
    combined.communication_plan,
    combined.activated_date,
    combined.disconnected_date,
    combined.service_product_id,
    combined.package_id,
    combined.service_id,
    combined.product_id,
    combined.description,
    combined.rate,
    combined.rev_io_status,
    combined.rev_is_active_status,
    combined.cost,
    combined.wholesale_description,
    combined.quantity,
    combined.integration_authentication_id,
    combined.rev_account_number,
    combined.customer_name,
    combined.rev_product_id,
    combined.product_type_id,
    combined.product_description,
    combined.service_type_id,
    combined.tenant_id,
    combined.carrier_activated_date,
    combined.customer_rate_plan_name,
    combined.carrier_rate_plan,
    combined.variance,
    combined.customer_id,
    combined.rev_service_line_status,
    combined.modified_date,
    combined.rev_service_id,
    combined.rev_service_product_id,
    combined.dev_tenant_id,
    combined.mob_tenant_id,
    combined.usage,
    combined.composite_id AS id,
    combined.usage_cycle
   FROM combined;


-- public.vw_optimization_session source

CREATE OR REPLACE VIEW public.vw_optimization_session
AS SELECT os.id,
    os.session_id,
    os.billing_period_start_date,
    os.billing_period_end_date,
    os.tenant_id,
    os.service_provider_id,
    sp.display_name AS serviceprovider,
    os.created_date,
    ot.id AS optimization_type_id,
    ot.name AS optimization_type,
    os.is_active,
    os.is_deleted,
    oi2.device_count,
    oi2.total_cost,
    oi2.total_base_rate_amt,
    oi2.total_rate_charge_amt,
    oi2.total_overage_charge_amt,
    oi2.results_count,
    oi2.instance_count,
    oi2.customer_charge_queue_count,
    oi2.completed_instance_count,
    os.service_provider_ids AS serviceproviderids,
    os.customer_id,
    ( SELECT string_agg(sp_1.display_name::text, ', '::text) AS string_agg
           FROM unnest(string_to_array(os.service_provider_ids, ','::text)) ids(ids)
             LEFT JOIN serviceprovider sp_1 ON sp_1.id = ids.ids::integer) AS displaynames,
    os.optimization_run_status,
    c.customer_name,
    os.progress,
    os.optimization_run_start_date,
    os.optimization_run_time_error,
        CASE
            WHEN (EXISTS ( SELECT 1
               FROM optimization_smi_result_customer_charge_queue customer_charge_queue
                 JOIN optimization_smi_result ON customer_charge_queue.optimization_smi_result_id = optimization_smi_result.id
                 JOIN optimization_queue ON optimization_smi_result.queue_id = optimization_queue.id
                 JOIN optimization_instance ON optimization_queue.instance_id = optimization_instance.id
                 JOIN optimization_session ON optimization_session.id = optimization_instance.optimization_session_id
              WHERE optimization_session.session_id = os.session_id)) AND NOT (EXISTS ( SELECT 1
               FROM optimization_smi_result_customer_charge_queue customer_charge_queue
                 JOIN optimization_smi_result ON customer_charge_queue.optimization_smi_result_id = optimization_smi_result.id
                 JOIN optimization_queue ON optimization_smi_result.queue_id = optimization_queue.id
                 JOIN optimization_instance ON optimization_queue.instance_id = optimization_instance.id
                 JOIN optimization_session ON optimization_session.id = optimization_instance.optimization_session_id
              WHERE optimization_session.session_id = os.session_id AND customer_charge_queue.is_processed = false)) THEN true
            ELSE false
        END AS pushed_charges,
    os.optimization_run_end_time,
    os.modified_date,
    os.push_charge_page,
    os.carrier_assignments_queued,
    os.device_count_20,
    os.total_charges_20
   FROM optimization_session os
     LEFT JOIN serviceprovider sp ON sp.id = os.service_provider_id
     LEFT JOIN customers c ON os.customer_id = c.id
     JOIN optimization_type ot ON ot.id = os.optimization_type_id
     LEFT JOIN ( SELECT oi.optimization_session_id,
            sum(COALESCE(ocg.total_cost, 0::numeric)) AS total_cost,
            sum(ocg.total_base_rate_amt) AS total_base_rate_amt,
            sum(ocg.total_rate_charge_amt) AS total_rate_charge_amt,
            sum(ocg.total_overage_charge_amt) AS total_overage_charge_amt,
            sum(COALESCE(od.device_count, 0::bigint)) AS device_count,
            sum(
                CASE
                    WHEN COALESCE(oirf.id, 0::bigint) > 0 THEN 1
                    ELSE 0
                END) AS results_count,
            count(*) AS instance_count,
            sum(odrccq.customer_charge_queue_count) AS customer_charge_queue_count,
            sum(
                CASE
                    WHEN oi.run_status_id >= 6 THEN 1
                    ELSE 0
                END) AS completed_instance_count
           FROM optimization_instance oi
             LEFT JOIN ( SELECT ocg_1.instance_id,
                    sum(oq.total_cost) AS total_cost,
                    sum(oq.total_base_rate_amt) AS total_base_rate_amt,
                    sum(oq.total_rate_charge_amt) AS total_rate_charge_amt,
                    sum(oq.total_overage_charge_amt) AS total_overage_charge_amt
                   FROM optimization_comm_group ocg_1
                     JOIN ( SELECT oq2.comm_plan_group_id,
                            oq2.total_cost,
                            oq2.total_base_rate_amt,
                            oq2.total_rate_charge_amt,
                            oq2.total_overage_charge_amt
                           FROM ( SELECT optimization_queue.comm_plan_group_id,
                                    optimization_queue.total_cost,
                                    optimization_queue.total_base_rate_amt,
                                    optimization_queue.total_rate_charge_amt,
                                    optimization_queue.total_overage_charge_amt,
                                    row_number() OVER (PARTITION BY optimization_queue.comm_plan_group_id ORDER BY optimization_queue.total_cost) AS record_number
                                   FROM optimization_queue
                                  WHERE optimization_queue.total_cost IS NOT NULL) oq2
                          WHERE oq2.record_number = 1) oq ON ocg_1.id = oq.comm_plan_group_id
                  GROUP BY ocg_1.instance_id) ocg ON ocg.instance_id = oi.id
             LEFT JOIN ( SELECT optimization_smi.instance_id,
                    count(1) AS device_count
                   FROM optimization_smi
                  GROUP BY optimization_smi.instance_id) od ON oi.id = od.instance_id
             LEFT JOIN ( SELECT optimization_instance_result_file.id,
                    optimization_instance_result_file.instance_id,
                    row_number() OVER (PARTITION BY optimization_instance_result_file.instance_id ORDER BY optimization_instance_result_file.created_date DESC) AS record_number
                   FROM optimization_instance_result_file) oirf ON oi.id = oirf.instance_id AND oirf.record_number = 1
             LEFT JOIN ( SELECT customer_charge_queue_count_by_type.instance_id,
                    sum(customer_charge_queue_count_by_type.customer_charge_queue_count) AS customer_charge_queue_count
                   FROM ( SELECT oq4.instance_id,
                            count(1) AS customer_charge_queue_count
                           FROM optimization_smi_result_customer_charge_queue osrccq
                             JOIN optimization_smi_result osr ON osr.id = osrccq.optimization_smi_result_id
                             JOIN optimization_queue oq4 ON osr.queue_id = oq4.id
                          GROUP BY oq4.instance_id) customer_charge_queue_count_by_type
                  GROUP BY customer_charge_queue_count_by_type.instance_id) odrccq ON oi.id = odrccq.instance_id
          GROUP BY oi.optimization_session_id) oi2 ON oi2.optimization_session_id = os.id
  WHERE os.is_active IS TRUE AND (os.created_date < (CURRENT_TIMESTAMP + '35 days'::interval) OR oi2.instance_count > 0);

-- public.vw_optimization_instance source
CREATE OR REPLACE VIEW public.vw_optimization_instance
AS SELECT row_number() OVER (ORDER BY oi.id) AS id,
    oi.billing_period_start_date,
    oi.billing_period_end_date,
    oi.run_status_id,
        CASE
            WHEN os.display_name::text = 'Comm Group Setup'::text THEN 'Pending'::character varying
            ELSE os.display_name
        END AS run_status,
    oi.run_start_time,
    oi.run_end_time,
    rc.rev_customer_id,
    TRIM(BOTH FROM rc.customer_name) AS customer_name,
    od.device_count,
    ocg.total_cost,
    ocg.total_base_rate_amt,
    ocg.total_rate_charge_amt,
    ocg.total_overage_charge_amt,
    oirf.id AS results_id,
    odrrpq.rate_plan_queue_count,
    odrccq.customer_charge_queue_count,
    oi.service_provider_id,
    sp.display_name AS service_provider,
    oi.tenant_id,
    oi.row_uuid,
    oi.optimization_session_id,
    oss.session_id,
    ot.name AS optimization_type,
    oi.amop_customer_id,
    TRIM(BOTH FROM s.customer_name) AS amop_customer_name,
    oi.service_provider_ids,
    ( SELECT string_agg(sp_1.display_name::text, ', '::text) AS string_agg
           FROM unnest(string_to_array(oi.service_provider_ids, ','::text)) ids(ids)
             LEFT JOIN serviceprovider sp_1 ON sp_1.id = ids.ids::integer) AS display_names,
    oi.id AS optimization_instance_id,
    oss.progress,
    oss.optimization_run_time_error,
    oi.modified_date,
    array_to_string(array_remove(ARRAY[oi.id, os.id::bigint, sp.id::bigint, oss.id, ot.id], NULL::integer::bigint), '-'::text) AS composite_id
   FROM optimization_instance oi
     JOIN optimization_status os ON oi.run_status_id = os.id
     LEFT JOIN serviceprovider sp ON sp.id = oi.service_provider_id
     JOIN optimization_session oss ON oss.id = oi.optimization_session_id
     JOIN optimization_type ot ON ot.id = oss.optimization_type_id
     LEFT JOIN ( SELECT ocg_1.instance_id,
            sum(oq.total_cost) AS total_cost,
            sum(oq.total_base_rate_amt) AS total_base_rate_amt,
            sum(oq.total_rate_charge_amt) AS total_rate_charge_amt,
            sum(oq.total_overage_charge_amt) AS total_overage_charge_amt
           FROM optimization_comm_group ocg_1
             JOIN ( SELECT oq2.comm_plan_group_id,
                    oq2.total_cost,
                    oq2.total_base_rate_amt,
                    oq2.total_rate_charge_amt,
                    oq2.total_overage_charge_amt
                   FROM ( SELECT optimization_queue.comm_plan_group_id,
                            optimization_queue.total_cost,
                            optimization_queue.total_base_rate_amt,
                            optimization_queue.total_rate_charge_amt,
                            optimization_queue.total_overage_charge_amt,
                            row_number() OVER (PARTITION BY optimization_queue.comm_plan_group_id ORDER BY optimization_queue.total_cost) AS record_number
                           FROM optimization_queue
                          WHERE optimization_queue.total_cost IS NOT NULL) oq2
                  WHERE oq2.record_number = 1) oq ON ocg_1.id = oq.comm_plan_group_id
          GROUP BY ocg_1.instance_id) ocg ON ocg.instance_id = oi.id
     LEFT JOIN ( SELECT device_count_by_type.instance_id,
            sum(device_count_by_type.device_count) AS device_count
           FROM ( SELECT optimization_smi.instance_id,
                    count(1) AS device_count
                   FROM optimization_smi
                  GROUP BY optimization_smi.instance_id) device_count_by_type
          GROUP BY device_count_by_type.instance_id) od ON oi.id = od.instance_id
     LEFT JOIN ( SELECT optimization_instance_result_file.id,
            optimization_instance_result_file.instance_id,
            row_number() OVER (PARTITION BY optimization_instance_result_file.instance_id ORDER BY optimization_instance_result_file.created_date DESC) AS record_number
           FROM optimization_instance_result_file) oirf ON oi.id = oirf.instance_id AND oirf.record_number = 1
     LEFT JOIN revcustomer rc ON rc.id = oi.rev_customer_id
     LEFT JOIN ( SELECT rate_plan_queue_count_by_type.instance_id,
            sum(rate_plan_queue_count_by_type.rate_plan_queue_count) AS rate_plan_queue_count
           FROM ( SELECT oq.instance_id,
                    count(1) AS rate_plan_queue_count
                   FROM optimization_smi_result_rate_plan_queue osrrpq
                     JOIN optimization_smi_result osr ON osr.id = osrrpq.optimization_smi_result_id
                     JOIN optimization_queue oq ON osr.queue_id = oq.id
                  GROUP BY oq.instance_id) rate_plan_queue_count_by_type
          GROUP BY rate_plan_queue_count_by_type.instance_id) odrrpq ON oi.id = odrrpq.instance_id
     LEFT JOIN ( SELECT customer_charge_queue_count_by_type.instance_id,
            sum(customer_charge_queue_count_by_type.customer_charge_queue_count) AS customer_charge_queue_count
           FROM ( SELECT oq4.instance_id,
                    count(1) AS customer_charge_queue_count
                   FROM optimization_smi_result_customer_charge_queue osrccq2
                     JOIN optimization_smi_result osr2 ON osr2.id = osrccq2.optimization_smi_result_id
                     JOIN optimization_queue oq4 ON osr2.queue_id = oq4.id
                  GROUP BY oq4.instance_id) customer_charge_queue_count_by_type
          GROUP BY customer_charge_queue_count_by_type.instance_id) odrccq ON oi.id = odrccq.instance_id
     LEFT JOIN customers s ON oi.amop_customer_id = s.id
  WHERE oi.is_deleted IS FALSE;

-- public.vw_optimization_smi_rate_plan_change_count source

CREATE OR REPLACE VIEW public.vw_optimization_smi_rate_plan_change_count
AS SELECT oq.instance_id,
    count(1) AS total_device_count,
    sum(
        CASE
            WHEN jd.carrier_rate_plan_id <> COALESCE(odr.assigned_carrier_rate_plan_id, odr.assigned_customer_rate_plan_id) THEN 1
            ELSE 0
        END) AS target_device_count,
    row_number() OVER (ORDER BY (( SELECT NULL::text AS text))) AS id,
    max(odr.modified_date) AS max,
    max(odr.modified_date) AS modified_date
   FROM optimization_smi_result odr
     JOIN sim_management_inventory jd ON odr.sim_management_inventory_id = jd.id
     JOIN ( SELECT oq_group.id,
            oq_group.instance_id
           FROM ( SELECT optimization_queue.id,
                    optimization_queue.instance_id,
                    row_number() OVER (PARTITION BY optimization_queue.comm_plan_group_id ORDER BY optimization_queue.total_cost) AS record_number
                   FROM optimization_queue
                  WHERE optimization_queue.total_cost IS NOT NULL AND optimization_queue.run_end_time IS NOT NULL) oq_group
          WHERE oq_group.record_number = 1) oq ON odr.queue_id = oq.id
  GROUP BY oq.instance_id;

-- public.vw_optimization_customer_charges_count source

CREATE OR REPLACE VIEW public.vw_optimization_customer_charges_count
AS SELECT oq.instance_id,
    sum(
        CASE
            WHEN jcust_rp.id IS NOT NULL THEN 1
            ELSE 0
        END) AS chargecount,
    sum(COALESCE(odr.overage_charge_amt, 0.0) + COALESCE(odr.rate_charge_amt, 0.0)) AS overagechargeamount,
    sum(COALESCE(odr.charge_amt, 0.0)) AS totalchargeamount,
    sum(
        CASE
            WHEN jcust_rp.id IS NULL THEN 1
            ELSE 0
        END) AS unassigneddevicecount,
    sum(COALESCE(odr.sms_charge_amount, 0.0)) AS smschargetotal,
    row_number() OVER (ORDER BY oq.instance_id) AS id,
    max(odr.modified_date) AS modified_date
   FROM optimization_smi_result odr
     JOIN optimization_queue oq ON odr.queue_id = oq.id
     JOIN optimization_instance oi ON oq.instance_id = oi.id
     JOIN sim_management_inventory smi ON odr.sim_management_inventory_id = smi.id
     LEFT JOIN customerrateplan jcust_rp ON odr.assigned_customer_rate_plan_id = jcust_rp.id
  GROUP BY oq.instance_id;


-- public.vw_optimization_instance_summary source

CREATE OR REPLACE VIEW public.vw_optimization_instance_summary
AS SELECT voi.billing_period_start_date,
    voi.billing_period_end_date,
    voi.run_status_id,
    voi.run_status::character varying(50) AS run_status,
    voi.run_start_time,
    voi.run_end_time,
    voi.rev_customer_id,
    voi.customer_name,
    voi.device_count,
    voi.total_cost,
    voi.total_base_rate_amt,
    voi.total_rate_charge_amt,
    voi.total_overage_charge_amt,
    voi.total_overage_charge_amt + voi.total_rate_charge_amt AS total_charge_amount,
    voi.results_id,
    voi.rate_plan_queue_count,
    voi.customer_charge_queue_count,
    voi.service_provider_id,
    voi.service_provider,
    voi.tenant_id,
    voi.row_uuid,
    voi.optimization_session_id,
    voi.session_id,
    voi.optimization_type,
    voi.amop_customer_id,
    voi.amop_customer_name,
    voi.service_provider_ids,
    voi.display_names,
        CASE
            WHEN vos.results_count > 0 AND vos.completed_instance_count = vos.instance_count THEN true
            ELSE false
        END AS download,
        CASE
            WHEN vos.total_cost > 0::numeric AND vos.customer_charge_queue_count >= vos.device_count THEN true
            ELSE false
        END AS info,
        CASE
            WHEN vos.total_cost > 0::numeric AND vos.customer_charge_queue_count <= vos.instance_count::numeric THEN true
            ELSE false
        END AS upload,
    voi.optimization_instance_id AS instance_id,
    osrpcc.total_device_count,
    osrpcc.target_device_count,
    voccc.chargecount AS charge_count,
    voccc.overagechargeamount AS overage_charge_amount,
    voccc.unassigneddevicecount AS unassigned_device_count,
    voccc.smschargetotal AS sms_charge_total,
    uocccfco.chargecount AS cross_opt_charge_count,
    uocccfco.overagechargeamount AS cross_opt_overage_charge_amt,
    uocccfco.totalchargeamount AS cross_opt_total_charge_amt,
    uocccfco.unassigneddevicecount AS cross_opt_unassigned_device_count,
    uocccfco.smschargetotal AS cross_opt_sms_charge_total,
    voi.modified_date,
    array_to_string(array_remove(ARRAY[voi.optimization_instance_id, vos.id], NULL::integer::bigint), '-'::text) AS id
   FROM vw_optimization_instance voi
     LEFT JOIN vw_optimization_session vos ON voi.session_id = vos.session_id
     LEFT JOIN vw_optimization_smi_rate_plan_change_count osrpcc ON osrpcc.instance_id = voi.optimization_instance_id
     LEFT JOIN vw_optimization_customer_charges_count voccc ON voccc.instance_id = voi.optimization_instance_id
     LEFT JOIN usp_optimization_customer_charges_count_for_cross_optimization uocccfco ON uocccfco.instance_id = voi.optimization_instance_id;

-- public.vw_optimization_instance_pushed_charges source

CREATE OR REPLACE VIEW public.vw_optimization_instance_pushed_charges
AS SELECT row_number() OVER (ORDER BY oi.id) AS id,
    oi.billing_period_start_date,
    oi.billing_period_end_date,
    oi.run_status_id,
        CASE
            WHEN os.display_name::text = 'Comm Group Setup'::text THEN 'Pending'::character varying
            ELSE os.display_name
        END AS run_status,
    oi.run_start_time,
    oi.run_end_time,
    rc.rev_customer_id,
    TRIM(BOTH FROM rc.customer_name) AS customer_name,
    od.device_count,
    ocg.total_cost,
    ocg.total_base_rate_amt,
    ocg.total_rate_charge_amt,
    ocg.total_overage_charge_amt,
    oirf.id AS results_id,
    odrrpq.rate_plan_queue_count,
    odrccq.customer_charge_queue_count,
    oi.service_provider_id,
    sp.display_name AS service_provider,
    oi.tenant_id,
    oi.row_uuid,
    oi.optimization_session_id,
    oss.session_id,
    ot.name AS optimization_type,
    oi.amop_customer_id,
    TRIM(BOTH FROM s.customer_name) AS amop_customer_name,
    oi.service_provider_ids,
    ( SELECT string_agg(sp_1.display_name::text, ', '::text) AS string_agg
           FROM unnest(string_to_array(oi.service_provider_ids, ','::text)) ids(ids)
             LEFT JOIN serviceprovider sp_1 ON sp_1.id = ids.ids::integer) AS display_names,
    oi.id AS optimization_instance_id,
    oss.progress,
    oss.optimization_run_time_error,
        CASE
            WHEN (EXISTS ( SELECT 1
               FROM optimization_smi_result_customer_charge_queue customer_charge_queue
                 JOIN optimization_smi_result ON customer_charge_queue.optimization_smi_result_id = optimization_smi_result.id
                 JOIN optimization_queue ON optimization_smi_result.queue_id = optimization_queue.id
                 JOIN optimization_instance ON optimization_queue.instance_id = optimization_instance.id
                 JOIN optimization_session ON optimization_session.id = optimization_instance.optimization_session_id
              WHERE optimization_instance.id = oi.id AND customer_charge_queue.is_processed = true)) THEN true
            ELSE false
        END AS pushed_charges,
    oi.modified_date
   FROM optimization_instance oi
     JOIN optimization_status os ON oi.run_status_id = os.id
     LEFT JOIN serviceprovider sp ON sp.id = oi.service_provider_id
     JOIN optimization_session oss ON oss.id = oi.optimization_session_id
     JOIN optimization_type ot ON ot.id = oss.optimization_type_id
     LEFT JOIN ( SELECT ocg_1.instance_id,
            sum(oq.total_cost) AS total_cost,
            sum(oq.total_base_rate_amt) AS total_base_rate_amt,
            sum(oq.total_rate_charge_amt) AS total_rate_charge_amt,
            sum(oq.total_overage_charge_amt) AS total_overage_charge_amt
           FROM optimization_comm_group ocg_1
             JOIN ( SELECT oq2.comm_plan_group_id,
                    oq2.total_cost,
                    oq2.total_base_rate_amt,
                    oq2.total_rate_charge_amt,
                    oq2.total_overage_charge_amt
                   FROM ( SELECT optimization_queue.comm_plan_group_id,
                            optimization_queue.total_cost,
                            optimization_queue.total_base_rate_amt,
                            optimization_queue.total_rate_charge_amt,
                            optimization_queue.total_overage_charge_amt,
                            row_number() OVER (PARTITION BY optimization_queue.comm_plan_group_id ORDER BY optimization_queue.total_cost) AS record_number
                           FROM optimization_queue
                          WHERE optimization_queue.total_cost IS NOT NULL) oq2
                  WHERE oq2.record_number = 1) oq ON ocg_1.id = oq.comm_plan_group_id
          GROUP BY ocg_1.instance_id) ocg ON ocg.instance_id = oi.id
     LEFT JOIN ( SELECT device_count_by_type.instance_id,
            sum(device_count_by_type.device_count) AS device_count
           FROM ( SELECT optimization_smi.instance_id,
                    count(1) AS device_count
                   FROM optimization_smi
                  GROUP BY optimization_smi.instance_id) device_count_by_type
          GROUP BY device_count_by_type.instance_id) od ON oi.id = od.instance_id
     LEFT JOIN ( SELECT optimization_instance_result_file.id,
            optimization_instance_result_file.instance_id,
            row_number() OVER (PARTITION BY optimization_instance_result_file.instance_id ORDER BY optimization_instance_result_file.created_date DESC) AS record_number
           FROM optimization_instance_result_file) oirf ON oi.id = oirf.instance_id AND oirf.record_number = 1
     LEFT JOIN revcustomer rc ON rc.id = oi.rev_customer_id
     LEFT JOIN ( SELECT rate_plan_queue_count_by_type.instance_id,
            sum(rate_plan_queue_count_by_type.rate_plan_queue_count) AS rate_plan_queue_count
           FROM ( SELECT oq.instance_id,
                    count(1) AS rate_plan_queue_count
                   FROM optimization_smi_result_rate_plan_queue osrrpq
                     JOIN optimization_smi_result osr ON osr.id = osrrpq.optimization_smi_result_id
                     JOIN optimization_queue oq ON osr.queue_id = oq.id
                  GROUP BY oq.instance_id) rate_plan_queue_count_by_type
          GROUP BY rate_plan_queue_count_by_type.instance_id) odrrpq ON oi.id = odrrpq.instance_id
     LEFT JOIN ( SELECT customer_charge_queue_count_by_type.instance_id,
            sum(customer_charge_queue_count_by_type.customer_charge_queue_count) AS customer_charge_queue_count
           FROM ( SELECT oq4.instance_id,
                    count(1) AS customer_charge_queue_count
                   FROM optimization_smi_result_customer_charge_queue osrccq2
                     JOIN optimization_smi_result osr2 ON osr2.id = osrccq2.optimization_smi_result_id
                     JOIN optimization_queue oq4 ON osr2.queue_id = oq4.id
                  GROUP BY oq4.instance_id) customer_charge_queue_count_by_type
          GROUP BY customer_charge_queue_count_by_type.instance_id) odrccq ON oi.id = odrccq.instance_id
     LEFT JOIN customers s ON oi.amop_customer_id = s.id
  WHERE oi.is_deleted IS FALSE;

-- public.vw_optimization_instance_total_charge source

CREATE OR REPLACE VIEW public.vw_optimization_instance_total_charge
AS WITH aggregated_charge_amounts AS (
         SELECT oq_1.instance_id,
            sum(COALESCE(odr.charge_amt, 0.0)) AS total_charge_amount
           FROM optimization_smi_result odr
             JOIN optimization_queue oq_1 ON odr.queue_id = oq_1.id
          GROUP BY oq_1.instance_id
        )
 SELECT oi.billing_period_start_date,
    oi.billing_period_end_date,
    oi.run_status_id,
        CASE
            WHEN os.display_name::text = 'Comm Group Setup'::text THEN 'Pending'::character varying
            ELSE os.display_name
        END AS run_status,
    oi.run_start_time,
    oi.run_end_time,
    rc.rev_customer_id,
    TRIM(BOTH FROM rc.customer_name) AS customer_name,
    od.device_count,
    ocg.total_cost,
    ocg.total_base_rate_amt,
    ocg.total_rate_charge_amt,
    ocg.total_overage_charge_amt,
    oirf.id AS results_id,
    odrrpq.rate_plan_queue_count,
    odrccq.customer_charge_queue_count,
    oi.service_provider_id,
    sp.display_name AS service_provider,
    oi.tenant_id,
    oi.row_uuid,
    oi.optimization_session_id,
    oss.session_id,
    ot.name AS optimization_type,
    oi.amop_customer_id,
    TRIM(BOTH FROM s.customer_name) AS amop_customer_name,
    oi.service_provider_ids,
    ( SELECT string_agg(sp_1.display_name::text, ', '::text) AS string_agg
           FROM unnest(string_to_array(oi.service_provider_ids, ','::text)) ids(ids)
             LEFT JOIN serviceprovider sp_1 ON sp_1.id = ids.ids::integer) AS display_names,
    oi.id AS optimization_instance_id,
    oss.progress,
    oss.optimization_run_time_error,
    aggregated_charge_amounts.total_charge_amount,
    oi.modified_date,
    array_to_string(array_remove(ARRAY[oi.id, os.id::bigint, sp.id::bigint, oss.id, ot.id], NULL::integer::bigint), '-'::text) AS id
   FROM optimization_instance oi
     JOIN optimization_status os ON oi.run_status_id = os.id
     LEFT JOIN serviceprovider sp ON sp.id = oi.service_provider_id
     JOIN optimization_session oss ON oss.id = oi.optimization_session_id
     JOIN optimization_type ot ON ot.id = oss.optimization_type_id
     LEFT JOIN ( SELECT ocg_1.instance_id,
            sum(oq_1.total_cost) AS total_cost,
            sum(oq_1.total_base_rate_amt) AS total_base_rate_amt,
            sum(oq_1.total_rate_charge_amt) AS total_rate_charge_amt,
            sum(oq_1.total_overage_charge_amt) AS total_overage_charge_amt
           FROM optimization_comm_group ocg_1
             JOIN ( SELECT oq2.comm_plan_group_id,
                    oq2.total_cost,
                    oq2.total_base_rate_amt,
                    oq2.total_rate_charge_amt,
                    oq2.total_overage_charge_amt
                   FROM ( SELECT optimization_queue.comm_plan_group_id,
                            optimization_queue.total_cost,
                            optimization_queue.total_base_rate_amt,
                            optimization_queue.total_rate_charge_amt,
                            optimization_queue.total_overage_charge_amt,
                            row_number() OVER (PARTITION BY optimization_queue.comm_plan_group_id ORDER BY optimization_queue.total_cost) AS record_number
                           FROM optimization_queue
                          WHERE optimization_queue.total_cost IS NOT NULL) oq2
                  WHERE oq2.record_number = 1) oq_1 ON ocg_1.id = oq_1.comm_plan_group_id
          GROUP BY ocg_1.instance_id) ocg ON ocg.instance_id = oi.id
     LEFT JOIN ( SELECT device_count_by_type.instance_id,
            sum(device_count_by_type.device_count) AS device_count
           FROM ( SELECT optimization_smi.instance_id,
                    count(1) AS device_count
                   FROM optimization_smi
                  GROUP BY optimization_smi.instance_id) device_count_by_type
          GROUP BY device_count_by_type.instance_id) od ON oi.id = od.instance_id
     LEFT JOIN ( SELECT optimization_instance_result_file.id,
            optimization_instance_result_file.instance_id,
            row_number() OVER (PARTITION BY optimization_instance_result_file.instance_id ORDER BY optimization_instance_result_file.created_date DESC) AS record_number
           FROM optimization_instance_result_file) oirf ON oi.id = oirf.instance_id AND oirf.record_number = 1
     LEFT JOIN revcustomer rc ON rc.id = oi.rev_customer_id
     LEFT JOIN ( SELECT rate_plan_queue_count_by_type.instance_id,
            sum(rate_plan_queue_count_by_type.rate_plan_queue_count) AS rate_plan_queue_count
           FROM ( SELECT oq_1.instance_id,
                    count(1) AS rate_plan_queue_count
                   FROM optimization_smi_result_rate_plan_queue osrrpq
                     JOIN optimization_smi_result osr ON osr.id = osrrpq.optimization_smi_result_id
                     JOIN optimization_queue oq_1 ON osr.queue_id = oq_1.id
                  GROUP BY oq_1.instance_id) rate_plan_queue_count_by_type
          GROUP BY rate_plan_queue_count_by_type.instance_id) odrrpq ON oi.id = odrrpq.instance_id
     LEFT JOIN ( SELECT customer_charge_queue_count_by_type.instance_id,
            sum(customer_charge_queue_count_by_type.customer_charge_queue_count) AS customer_charge_queue_count
           FROM ( SELECT oq4.instance_id,
                    count(1) AS customer_charge_queue_count
                   FROM optimization_smi_result_customer_charge_queue osrccq2
                     JOIN optimization_smi_result osr2 ON osr2.id = osrccq2.optimization_smi_result_id
                     JOIN optimization_queue oq4 ON osr2.queue_id = oq4.id
                  GROUP BY oq4.instance_id) customer_charge_queue_count_by_type
          GROUP BY customer_charge_queue_count_by_type.instance_id) odrccq ON oi.id = odrccq.instance_id
     LEFT JOIN customers s ON oi.amop_customer_id = s.id
     LEFT JOIN aggregated_charge_amounts ON aggregated_charge_amounts.instance_id = oi.id
  WHERE oi.is_deleted IS FALSE;


-- public.vw_optimization_push_charges_data source

CREATE OR REPLACE VIEW public.vw_optimization_push_charges_data
AS SELECT osmi.iccid,
    vos.service_provider_id,
    vos.service_provider,
    vos.rev_customer_id,
    vos.customer_name,
    osmi.msisdn,
        CASE
            WHEN vos.run_status::text = 'Comm Group Setup'::text THEN 'Pending'::character varying
            ELSE vos.run_status
        END AS run_status,
    vos.optimization_instance_id AS instance_id,
    vos.session_id,
    vos.total_charge_amount,
    vos.modified_date,
    array_to_string(array_remove(ARRAY[vos.optimization_instance_id, osmi.id], NULL::integer::bigint), '-'::text) AS id
   FROM vw_optimization_instance_total_charge vos
     LEFT JOIN optimization_smi osmi ON vos.optimization_instance_id = osmi.instance_id;

-- public.vw_optimization_sim_card source

CREATE OR REPLACE VIEW public.vw_optimization_sim_card
AS SELECT COALESCE(gen_random_uuid(), gen_random_uuid()) AS id,
    smi.service_provider_id,
    smi.id AS device_id,
    dt.tenant_id,
    device_usage_history.bill_year,
    device_usage_history.bill_month,
    COALESCE(device_usage_history.carrier_cycle_usage::numeric, 0.0) AS carrier_cycle_usage,
    smi.communication_plan,
    smi.msisdn,
    device_usage_history.changed_date AS usage_date,
        CASE
            WHEN device_usage_history.billing_period_id = smi.billing_period_id THEN c2.rate_plan_code
            ELSE device_usage_history.rate_plan_code
        END AS customer_rate_plan_code,
    COALESCE(dt.account_number_integration_authentication_id, r.integration_authentication_id) AS account_number_integration_authentication_id,
    crp.rate_plan_code AS carrier_rate_plan_code,
    device_usage_history.billing_period_id,
    smi.customer_id,
        CASE
            WHEN device_usage_history.billing_period_id = smi.billing_period_id THEN dt.customer_rate_plan_id
            ELSE device_usage_history.customer_rate_plan_id
        END AS customer_rate_plan_id,
        CASE
            WHEN device_usage_history.billing_period_id = smi.billing_period_id THEN dt.customer_data_allocation_mb
            ELSE device_usage_history.customer_data_allocation_mb
        END AS customer_data_allocation_mb,
        CASE
            WHEN device_usage_history.billing_period_id = smi.billing_period_id THEN dt.customer_rate_pool_id
            ELSE device_usage_history.customer_rate_pool_id
        END AS customer_rate_pool_id,
        CASE
            WHEN device_usage_history.billing_period_id = smi.billing_period_id THEN c2.plan_mb
            ELSE device_usage_history.plan_mb
        END AS customer_rate_plan_mb,
    smi.modified_date
   FROM sim_management_inventory smi
     JOIN device_tenant dt ON smi.device_id = dt.device_id
     JOIN device_status ds ON smi.device_status_id = ds.id
     JOIN customers c ON c.id = smi.customer_id
     LEFT JOIN revcustomer r ON c.rev_customer_id = r.id
     LEFT JOIN carrier_rate_plan crp ON smi.carrier_rate_plan_id = crp.id
     LEFT JOIN customerrateplan c2 ON dt.customer_rate_plan_id = c2.id
     LEFT JOIN ( SELECT dh.id,
            bp.bill_year,
            bp.bill_month,
            dh.iccid,
            dh.carrier_cycle_usage,
            dh.communication_plan,
            COALESCE(ds_1.status, dh.status) AS status,
            dh.changed_date,
            dh.billing_cycle_end_date,
            COALESCE(sp.bill_period_end_day::character varying(2), '18'::character varying) AS billing_period_end_day,
            COALESCE(sp.bill_period_end_hour::character varying(2), '18'::character varying) AS billing_period_end_hour,
            dh.billing_period_id,
            dh.ctd_sms_usage,
            dh.device_tenant_id,
            ds_1.is_active_status,
            dh.customer_rate_plan_id,
            dh.customer_data_allocation_mb,
            dh.customer_rate_pool_id,
            c3.plan_mb,
            c3.rate_plan_code
           FROM sim_management_inventory_history dh
             JOIN device_status ds_1 ON dh.device_status_id = ds_1.id
             JOIN serviceprovider sp ON sp.id = dh.service_provider_id
             JOIN billing_period bp ON dh.billing_period_id = bp.id
             LEFT JOIN customerrateplan c3 ON dh.customer_rate_plan_id = c3.id
          WHERE dh.is_active = true AND dh.is_deleted = false AND (ds_1.is_active_status = true OR dh.carrier_cycle_usage > 0 AND ds_1.status::text <> 'TEST READY'::text OR dh.last_activated_date IS NOT NULL)) device_usage_history ON smi.device_id = device_usage_history.id AND dt.id = device_usage_history.device_tenant_id
  WHERE smi.tenant_is_active = true AND smi.tenant_is_deleted = false AND (ds.is_active_status = true OR device_usage_history.is_active_status = true OR device_usage_history.carrier_cycle_usage > 0 OR smi.last_activated_date IS NOT NULL AND smi.last_activated_date > COALESCE((device_usage_history.billing_cycle_end_date - '1 mon'::interval)::timestamp with time zone, to_timestamp(concat(device_usage_history.bill_year, '/', lpad(device_usage_history.bill_month::text, 2, '0'::text), '/', device_usage_history.billing_period_end_day, ' ', device_usage_history.billing_period_end_hour, ':00'), 'YYYY/MM/DD HH24:MI'::text) - '1 mon'::interval));

-- public.vw_optimization_smi_result_customer_charge_queue source
CREATE OR REPLACE VIEW public.vw_optimization_smi_result_customer_charge_queue
AS SELECT array_to_string(array_remove(ARRAY[customer_charge_queue.id, optimization_smi_result.id, customerrateplan.id::bigint, optimization_queue.id, optimization_instance.id, optimization_session.id, integration_authentication.id::bigint], NULL::integer::bigint), '-'::text) AS id,
    optimization_smi_result.queue_id,
    optimization_session.session_id,
    customer_charge_queue.uploaded_file_id,
    optimization_smi_result.usage_mb,
    optimization_smi_result.assigned_customer_rate_plan_id,
    customerrateplan.rate_plan_code,
    customerrateplan.base_rate,
    customerrateplan.surcharge_3g,
    customerrateplan.plan_mb,
    customer_charge_queue.is_processed,
    customer_charge_queue.charge_id,
    customer_charge_queue.charge_amount,
    customer_charge_queue.base_charge_amount,
    customer_charge_queue.total_charge_amount,
    customer_charge_queue.created_date,
    customer_charge_queue.created_by,
    customer_charge_queue.modified_date,
    customer_charge_queue.modified_by,
    customerrateplan.rate_plan_name,
    customerrateplan.overage_rate_cost AS overage_rate_cost_per_mb,
    customerrateplan.rate_charge_amt,
    customerrateplan.display_rate,
    optimization_instance.billing_period_start_date,
    optimization_instance.billing_period_end_date,
    revcustomer.rev_customer_id AS rev_account_number,
    revcustomer.customer_name,
    customerrateplan.data_per_overage_charge,
    customerrateplan.overage_rate_cost,
    customer_charge_queue.has_errors,
    customer_charge_queue.error_message,
    sim_management_inventory.iccid,
    sim_management_inventory.msisdn,
    customer_charge_queue.rev_product_type_id,
    customer_charge_queue.rev_service_number,
    customer_charge_queue.billing_start_date,
    customer_charge_queue.billing_end_date,
    customer_charge_queue.description,
    NULL::text AS cost_center,
    customer_charge_queue.integration_authentication_id,
    integration_authentication.tenant_id,
    customer_charge_queue.sms_rev_product_type_id,
    customer_charge_queue.sms_charge_amount,
    customer_charge_queue.sms_charge_id,
    customerrateplan.sms_rate,
    optimization_smi_result.sms_usage,
    optimization_queue.is_bill_in_advance,
    optimization_instance.optimization_session_id,
    optimization_session.created_date AS session_created_date,
    NULL::integer AS amop_customer_id,
    NULL::character varying AS amop_customer_name,
    customer_charge_queue.rate_charge_amt AS rate_charge_amount,
    customer_charge_queue.overage_charge_amt AS overage_charge_amount,
    customer_charge_queue.base_rate_amt AS base_rate_amount,
    customer_charge_queue.overage_rev_product_type_id,
    sim_management_inventory.service_provider_id,
    customer_charge_queue.rev_product_id,
    customer_charge_queue.sms_rev_product_id,
    customer_charge_queue.overage_rev_product_id,
    optimization_instance.id AS optimization_instance_id,
    COALESCE(EXTRACT(day FROM optimization_instance.billing_period_end_date - optimization_instance.billing_period_start_date), 0::numeric) AS billing_period_duration,
    optimization_session.optimization_run_start_date,
    concat(to_char(optimization_instance.billing_period_start_date, 'MM/DD/YYYY'::text), ' - ', to_char(optimization_instance.billing_period_end_date, 'MM/DD/YYYY'::text)) AS billing_period_duration_dates,
    sim_management_inventory.service_provider_display_name,
    COALESCE(customer_charge_queue.overage_charge_amt, 0::numeric) + COALESCE(customerrateplan.rate_charge_amt, 0::numeric) AS total_charges_pushed,
    COALESCE(customer_charge_queue.base_charge_amount, 0::numeric) + COALESCE(customerrateplan.rate_charge_amt, 0::numeric) + COALESCE(customer_charge_queue.overage_charge_amt, 0::numeric) AS total_data_charge_amount
   FROM optimization_smi_result_customer_charge_queue customer_charge_queue
     JOIN optimization_smi_result ON customer_charge_queue.optimization_smi_result_id = optimization_smi_result.id
     JOIN sim_management_inventory ON optimization_smi_result.sim_management_inventory_id = sim_management_inventory.id
     LEFT JOIN customerrateplan ON optimization_smi_result.assigned_customer_rate_plan_id = customerrateplan.id
     JOIN optimization_queue ON optimization_smi_result.queue_id = optimization_queue.id
     JOIN optimization_instance ON optimization_queue.instance_id = optimization_instance.id
     JOIN revcustomer ON optimization_instance.rev_customer_id = revcustomer.id
     JOIN optimization_session ON optimization_session.id = optimization_instance.optimization_session_id
     JOIN integration_authentication ON customer_charge_queue.integration_authentication_id = integration_authentication.id OR revcustomer.integration_authentication_id = integration_authentication.id;

CREATE OR REPLACE VIEW public.vw_optimization_push_charges_error
AS SELECT vosrccq.optimization_instance_id AS instance_id,
    vosrccq.iccid,
    vosrccq.service_provider_id,
    vosrccq.service_provider_display_name AS service_provider,
    vosrccq.rev_account_number AS rev_customer_id,
    vosrccq.customer_name,
    vosrccq.msisdn,
    vosrccq.total_charge_amount,
    vosrccq.error_message,
    vosrccq.session_id,
    vosrccq.modified_date
   FROM vw_optimization_smi_result_customer_charge_queue vosrccq
  WHERE vosrccq.has_errors IS TRUE AND vosrccq.error_message IS NOT NULL;

-- public.vw_optimization_smi_result_customer_charge_queue_not_id source

CREATE OR REPLACE VIEW public.vw_optimization_smi_result_customer_charge_queue_not_id
AS SELECT customer_charge_queue.id,
    optimization_smi_result.queue_id,
    optimization_session.session_id,
    customer_charge_queue.uploaded_file_id,
    optimization_smi_result.usage_mb,
    optimization_smi_result.assigned_customer_rate_plan_id,
    customerrateplan.rate_plan_code,
    customerrateplan.base_rate,
    customerrateplan.surcharge_3g,
    customerrateplan.plan_mb,
    customer_charge_queue.is_processed,
    customer_charge_queue.charge_id,
    customer_charge_queue.charge_amount,
    customer_charge_queue.base_charge_amount,
    customer_charge_queue.total_charge_amount,
    customer_charge_queue.created_date,
    customer_charge_queue.created_by,
    customer_charge_queue.modified_date,
    customer_charge_queue.modified_by,
    customerrateplan.rate_plan_name,
    customerrateplan.overage_rate_cost AS overage_rate_cost_per_mb,
    customerrateplan.rate_charge_amt,
    customerrateplan.display_rate,
    optimization_instance.billing_period_start_date,
    optimization_instance.billing_period_end_date,
    revcustomer.rev_customer_id AS rev_account_number,
    revcustomer.customer_name,
    customerrateplan.data_per_overage_charge,
    customerrateplan.overage_rate_cost,
    customer_charge_queue.has_errors,
    customer_charge_queue.error_message,
    sim_management_inventory.iccid,
    sim_management_inventory.msisdn,
    customer_charge_queue.rev_product_type_id,
    customer_charge_queue.rev_service_number,
    customer_charge_queue.billing_start_date,
    customer_charge_queue.billing_end_date,
    customer_charge_queue.description,
    NULL::text AS cost_center,
    customer_charge_queue.integration_authentication_id,
    integration_authentication.tenant_id,
    customer_charge_queue.sms_rev_product_type_id,
    customer_charge_queue.sms_charge_amount,
    customer_charge_queue.sms_charge_id,
    customerrateplan.sms_rate,
    optimization_smi_result.sms_usage,
    optimization_queue.is_bill_in_advance,
    optimization_instance.optimization_session_id,
    optimization_session.created_date AS session_created_date,
    NULL::integer AS amop_customer_id,
    NULL::character varying AS amop_customer_name,
    customer_charge_queue.rate_charge_amt AS rate_charge_amount,
    customer_charge_queue.overage_charge_amt AS overage_charge_amount,
    customer_charge_queue.base_rate_amt AS base_rate_amount,
    customer_charge_queue.overage_rev_product_type_id,
    sim_management_inventory.service_provider_id,
    customer_charge_queue.rev_product_id,
    customer_charge_queue.sms_rev_product_id,
    customer_charge_queue.overage_rev_product_id,
    optimization_instance.id AS optimization_instance_id,
    COALESCE(EXTRACT(day FROM optimization_instance.billing_period_end_date - optimization_instance.billing_period_start_date), 0::numeric) AS billing_period_duration,
    optimization_session.optimization_run_start_date,
    concat(to_char(optimization_instance.billing_period_start_date, 'MM/DD/YYYY'::text), ' - ', to_char(optimization_instance.billing_period_end_date, 'MM/DD/YYYY'::text)) AS billing_period_duration_dates,
    sim_management_inventory.service_provider_display_name,
    COALESCE(customer_charge_queue.overage_charge_amt, 0::numeric) + COALESCE(customerrateplan.rate_charge_amt, 0::numeric) AS total_charges_pushed,
    COALESCE(customer_charge_queue.base_charge_amount, 0::numeric) + COALESCE(customerrateplan.rate_charge_amt, 0::numeric) + COALESCE(customer_charge_queue.overage_charge_amt, 0::numeric) AS total_data_charge_amount
   FROM optimization_smi_result_customer_charge_queue customer_charge_queue
     JOIN optimization_smi_result ON customer_charge_queue.optimization_smi_result_id = optimization_smi_result.id
     JOIN sim_management_inventory ON optimization_smi_result.sim_management_inventory_id = sim_management_inventory.id
     LEFT JOIN customerrateplan ON optimization_smi_result.assigned_customer_rate_plan_id = customerrateplan.id
     JOIN optimization_queue ON optimization_smi_result.queue_id = optimization_queue.id
     JOIN optimization_instance ON optimization_queue.instance_id = optimization_instance.id
     JOIN revcustomer ON optimization_instance.rev_customer_id = revcustomer.id
     JOIN optimization_session ON optimization_session.id = optimization_instance.optimization_session_id
     JOIN integration_authentication ON customer_charge_queue.integration_authentication_id = integration_authentication.id OR revcustomer.integration_authentication_id = integration_authentication.id;

-- public.vw_optimization_smi_result_customer_charge_queue_summary source

CREATE OR REPLACE VIEW public.vw_optimization_smi_result_customer_charge_queue_summary
AS SELECT array_to_string(array_remove(ARRAY[odr_queue.queue_id, oi.id, rc.rev_customer_id::bigint], NULL::integer::bigint), '-'::text) AS id,
    odr_queue.queue_id,
    odr_queue.device_count,
    odr_queue.processed_count,
    COALESCE(odr_queue.charge_amount, 0.0) AS charge_amount,
    COALESCE(odr_queue.base_charge_amount, 0.0) AS base_charge_amount,
    COALESCE(odr_queue.total_data_charge_amount, 0.0) AS total_data_charge_amount,
    COALESCE(odr_queue.rate_charge_amt, 0.0) AS rate_charge_amt,
    odr_queue.display_rate,
    oi.billing_period_start_date,
    oi.billing_period_end_date,
    rc.rev_customer_id AS rev_account_number,
    rc.customer_name,
    oi.optimization_session_id,
    NULL::integer AS amop_customer_id,
    NULL::character varying AS amop_customer_name,
        CASE
            WHEN odr_queue.error_count > 0 THEN 'Processed With Errors'::text
            WHEN odr_queue.processed_count = odr_queue.device_count THEN 'Processed'::text
            WHEN odr_queue.processed_count = 0 THEN 'Not Started'::text
            ELSE 'Pending'::text
        END AS charge_status,
    oi.tenant_id,
    odr_queue.sms_charge_amount,
    COALESCE(odr_queue.total_data_charge_amount, 0.0) + COALESCE(odr_queue.sms_charge_amount, 0.0) AS totalchargeamount,
    COALESCE(odr_queue.rate_charge_amount, 0.0) AS rate_charge_amount,
    COALESCE(odr_queue.overage_charge_amount, 0.0) AS overage_charge_amount,
    odr_queue.modified_date
   FROM ( SELECT odr.queue_id,
            count(1) AS device_count,
            sum(
                CASE
                    WHEN odr_ccq.is_processed::integer = 1 THEN 1
                    ELSE 0
                END) AS processed_count,
            sum(odr_ccq.charge_amount) AS charge_amount,
            sum(odr_ccq.base_charge_amount) AS base_charge_amount,
            sum(odr_ccq.total_charge_amount) AS total_data_charge_amount,
            sum(jcust_rp.rate_charge_amt::numeric) AS rate_charge_amt,
            sum(jcust_rp.display_rate::numeric) AS display_rate,
            sum(odr_ccq.sms_charge_amount) AS sms_charge_amount,
            sum(
                CASE
                    WHEN odr_ccq.has_errors::integer = 1 THEN 1
                    ELSE 0
                END) AS error_count,
            sum(odr_ccq.rate_charge_amt) AS rate_charge_amount,
            sum(odr_ccq.overage_charge_amt) AS overage_charge_amount,
            max(odr_ccq.modified_date) AS modified_date
           FROM optimization_smi_result_customer_charge_queue odr_ccq
             JOIN optimization_smi_result odr ON odr_ccq.optimization_smi_result_id = odr.id
             LEFT JOIN customerrateplan jcust_rp ON odr.assigned_customer_rate_plan_id = jcust_rp.id
          GROUP BY odr.queue_id) odr_queue
     JOIN optimization_queue oq ON odr_queue.queue_id = oq.id
     JOIN optimization_instance oi ON oq.instance_id = oi.id
     JOIN revcustomer rc ON oi.rev_customer_id = rc.id;

CREATE OR REPLACE FUNCTION public.get_sms_charge_total(input_instance_id bigint)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
DECLARE
    sms_total NUMERIC;
BEGIN
    -- Calculate the sum of sms_charge_amount for the given instance_id
    SELECT sum(COALESCE(odr.sms_charge_amount, 0.0))
    INTO sms_total
    FROM optimization_smi_result odr
    WHERE odr.instance_id = input_instance_id;

    -- Return the result
    RETURN sms_total;
END;
$function$
;


-- public.vw_optimization_high_usage_customers source

CREATE OR REPLACE VIEW public.vw_optimization_high_usage_customers
AS SELECT voi.id,
    voi.rev_customer_id,
    voi.customer_name,
    voi.total_cost AS total_charges,
    voi.total_overage_charge_amt + voi.total_rate_charge_amt AS total_charge_amount,
    voi.results_id,
    voi.session_id,
    voi.optimization_instance_id AS instance_id,
    get_sms_charge_total(voi.optimization_instance_id) AS sms_charge_total,
    voi.device_count,
    voi.pushed_charges,
    voi.modified_date
   FROM vw_optimization_instance_pushed_charges voi
  WHERE voi.pushed_charges IS FALSE;

-- public.vw_optimization_error_details source

CREATE OR REPLACE VIEW public.vw_optimization_error_details
AS SELECT vois.rev_customer_id,
    os.iccid,
    os.msisdn,
    vois.customer_name,
    od.error_message,
    vois.session_id,
    array_to_string(array_remove(ARRAY[vois.optimization_instance_id, oi.id, os.id, od.id::bigint], NULL::integer::bigint), '-'::text) AS id,
    vois.modified_date
   FROM vw_optimization_instance vois
     LEFT JOIN optimization_instance oi ON vois.row_uuid::text = oi.row_uuid::text
     LEFT JOIN optimization_smi os ON oi.id = os.instance_id
     LEFT JOIN optimization_details od ON vois.rev_customer_id::text = od.customer_id::text;

-- public.vw_optimization_error_details_carrier source

CREATE OR REPLACE VIEW public.vw_optimization_error_details_carrier
AS SELECT vois.rev_customer_id,
    os.iccid,
    os.msisdn,
    vois.customer_name,
    od.error_message,
    vois.session_id,
    row_number() OVER (ORDER BY od.customer_id) AS id,
    od.optimization_type_id,
    vois.modified_date
   FROM vw_optimization_instance vois
     LEFT JOIN optimization_instance oi ON vois.row_uuid::text = oi.row_uuid::text
     LEFT JOIN optimization_smi os ON oi.id = os.instance_id
     LEFT JOIN optimization_details od ON vois.session_id = od.session_id
  WHERE od.optimization_type_id = 0;

-- public.vw_optimization_error_details_customer source

CREATE OR REPLACE VIEW public.vw_optimization_error_details_customer
AS SELECT vois.rev_customer_id,
    os.iccid,
    os.msisdn,
    vois.customer_name,
    od.error_message,
    vois.session_id,
    row_number() OVER (ORDER BY od.customer_id) AS id,
    od.optimization_type_id,
    vois.modified_date
   FROM vw_optimization_instance vois
     LEFT JOIN optimization_instance oi ON vois.row_uuid::text = oi.row_uuid::text
     LEFT JOIN optimization_smi os ON oi.id = os.instance_id
     LEFT JOIN optimization_details od ON vois.rev_customer_id::text = od.customer_id::text
  WHERE od.optimization_type_id = 1;

-- public.vw_optimization_export_device_assignments source

CREATE OR REPLACE VIEW public.vw_optimization_export_device_assignments
AS SELECT voi.optimization_instance_id AS instance_id,
    voi.row_uuid,
    voi.session_id,
    voi.rev_customer_id,
    voi.customer_name,
    voi.device_count,
        CASE
            WHEN voi.device_count > 0::numeric THEN os.total_cost / voi.device_count
            ELSE 0::numeric
        END AS average_cost,
    voi.billing_period_start_date,
    voi.billing_period_end_date,
    voi.billing_period_end_date - voi.billing_period_start_date AS days_in_billing_period,
    smi.iccid,
    os.cycle_data_usage_mb,
    smi.communication_plan,
    smi.msisdn,
    os.sms_usage,
    smi.date_activated,
    os.was_activated_in_this_billing_period,
    os.days_activated_in_billing_period,
    smi.carrier_rate_plan_id,
    smi.carrier_rate_plan_name AS carrier_rate_plan,
    smi.customer_rate_pool_id AS customer_pool_id,
    smi.customer_rate_pool_name AS customer_pool,
    smi.customer_rate_plan_id,
    smi.customer_rate_plan_name AS customer_rate_plan,
    os.uses_proration,
    os.total_cost,
    voi.optimization_type,
    voi.service_provider,
    voi.run_status,
    os.optimization_comm_group_id,
    crp.base_rate,
    voi.total_cost - voi.total_base_rate_amt + voi.total_overage_charge_amt AS usage_cost,
    voi.modified_date,
    voi.tenant_id
   FROM vw_optimization_instance voi
     JOIN optimization_smi os ON os.instance_id = voi.optimization_instance_id
     JOIN sim_management_inventory smi ON smi.iccid::text = os.iccid::text
     LEFT JOIN carrier_rate_plan crp ON smi.carrier_rate_plan_id = crp.id;

-- public.vw_optimization_export_device_assignments_summary source

CREATE OR REPLACE VIEW public.vw_optimization_export_device_assignments_summary
AS SELECT vw_optimization_export_device_assignments.session_id,
    vw_optimization_export_device_assignments.customer_rate_plan,
    sum(vw_optimization_export_device_assignments.device_count) AS sim_card_count,
    sum(vw_optimization_export_device_assignments.cycle_data_usage_mb) AS average_usage_mb,
    avg(vw_optimization_export_device_assignments.average_cost) AS average_cost,
    sum(vw_optimization_export_device_assignments.total_cost) AS total_cost,
    sum(vw_optimization_export_device_assignments.usage_cost) AS total_usage,
    max(vw_optimization_export_device_assignments.modified_date) AS modified_date
   FROM vw_optimization_export_device_assignments
  GROUP BY vw_optimization_export_device_assignments.session_id, vw_optimization_export_device_assignments.customer_rate_plan;

-- public.vw_customer_optimization source

CREATE OR REPLACE VIEW public.vw_customer_optimization
AS SELECT vos.id,
    vos.billing_period_start_date,
    vos.billing_period_end_date,
    vos.optimization_run_status,
    vos.optimization_run_start_date,
    vos.device_count,
    vos.total_rate_charge_amt,
    vos.total_overage_charge_amt,
    vos.customer_charge_queue_count,
    vos.serviceprovider,
    vos.customer_name,
    vos.session_id,
    vos.optimization_type,
    vos.progress,
    vos.optimization_run_time_error,
    COALESCE(EXTRACT(day FROM vos.billing_period_end_date - vos.billing_period_start_date), 0::numeric) AS billing_period_duration,
    vos.pushed_charges,
    vos.optimization_type_id,
    vos.total_cost AS total_charges,
    vos.total_overage_charge_amt + vos.total_rate_charge_amt AS total_charge_amount,
    vos.optimization_run_end_time,
    vos.service_provider_id,
    vos.modified_date,
    vos.push_charge_page,
    vos.device_count_20,
    vos.total_charges_20,
    vos.tenant_id,
    vos.created_date,
    vos.displaynames,
    vos.serviceproviderids
   FROM vw_optimization_session vos
  WHERE vos.optimization_type_id = 1 AND vos.is_active IS TRUE;

-- public.vw_carrier_optimization source

CREATE OR REPLACE VIEW public.vw_carrier_optimization
AS SELECT vos.id,
    vos.billing_period_start_date,
    vos.billing_period_end_date,
    vos.optimization_run_status,
    vos.optimization_run_start_date,
    vos.device_count,
    vos.total_rate_charge_amt,
    vos.total_overage_charge_amt,
    vos.customer_charge_queue_count,
    vos.serviceprovider,
    vos.session_id,
    vos.optimization_type,
    vos.progress,
    vos.optimization_run_time_error,
    COALESCE(EXTRACT(day FROM vos.billing_period_end_date - vos.billing_period_start_date), 0::numeric) AS billing_period_duration,
    vos.total_cost AS total_charges,
    vos.pushed_charges,
    vos.optimization_type_id,
    vos.optimization_run_end_time,
    vos.modified_date,
    oi.id AS instance_id,
    vos.service_provider_id,
    vos.push_charge_page,
    vos.carrier_assignments_queued,
    vos.device_count_20,
    vos.total_charges_20,
    array_to_string(array_remove(ARRAY[vos.id, oi.id], NULL::integer::bigint), '-'::text) AS compsite_id,
    vos.tenant_id,
    vos.created_date,
    vos.displaynames,
    vos.serviceproviderids
   FROM vw_optimization_session vos
     JOIN optimization_instance oi ON vos.id = oi.optimization_session_id
  WHERE vos.optimization_type_id = 0 AND vos.is_active IS TRUE;

-- public.vw_carrier_search_view source

CREATE OR REPLACE VIEW public.vw_carrier_search_view
AS SELECT vw_carrier_optimization.id,
    vw_carrier_optimization.session_id::text AS session_id,
    to_char(vw_carrier_optimization.optimization_run_end_time, 'MM-DD-YYYY HH24:MI:SS'::text) AS optimization_run_end_time,
    to_char(vw_carrier_optimization.created_date, 'MM-DD-YYYY HH24:MI:SS'::text) AS run_start_time,
    to_char(vw_carrier_optimization.billing_period_start_date, 'MM-DD-YYYY HH24:MI:SS'::text) AS billing_period_start_date,
    to_char(vw_carrier_optimization.billing_period_end_date, 'MM-DD-YYYY HH24:MI:SS'::text) AS billing_period_end_date,
    vw_carrier_optimization.optimization_type,
    vw_carrier_optimization.serviceprovider AS service_provider,
    concat(to_char(vw_carrier_optimization.billing_period_start_date, 'MM/DD/YYYY'::text), ' - ', to_char(vw_carrier_optimization.billing_period_end_date, 'MM/DD/YYYY'::text)) AS billing_period_duration,
    vw_carrier_optimization.device_count,
    vw_carrier_optimization.device_count_20,
        CASE
            WHEN vw_carrier_optimization.device_count IS NOT NULL AND vw_carrier_optimization.device_count > 0::numeric THEN vw_carrier_optimization.device_count
            ELSE vw_carrier_optimization.device_count_20
        END AS final_device_count,
        CASE
            WHEN vw_carrier_optimization.total_charges IS NOT NULL AND vw_carrier_optimization.total_charges > 0::numeric THEN to_char(trunc(vw_carrier_optimization.total_charges, 2), 'FM$999,999,999,999.00'::text)
            ELSE to_char(trunc(vw_carrier_optimization.total_charges_20, 2), 'FM$999,999,999,999,999.00'::text)
        END AS total_charges,
    vw_carrier_optimization.optimization_run_status,
    vw_carrier_optimization.service_provider_id,
    vw_carrier_optimization.instance_id,
    vw_carrier_optimization.progress,
        CASE
            WHEN vw_carrier_optimization.progress::text = ''::text THEN NULL::text
            WHEN vw_carrier_optimization.progress::numeric = 100::numeric THEN 'Run Completed'::text
            WHEN vw_carrier_optimization.progress::numeric = 0::numeric THEN 'Run Not Started Yet'::text
            WHEN vw_carrier_optimization.progress::numeric > 0::numeric AND vw_carrier_optimization.progress::numeric < 100::numeric THEN 'In Progress'::text
            ELSE ' '::text
        END AS optimization_status,
    vw_carrier_optimization.modified_date,
    vw_carrier_optimization.tenant_id
   FROM vw_carrier_optimization;

-- public.vw_customer_search_view source

CREATE OR REPLACE VIEW public.vw_customer_search_view
AS SELECT vw_customer_optimization.id,
    vw_customer_optimization.service_provider_id,
    vw_customer_optimization.push_charge_page,
    vw_customer_optimization.pushed_charges,
    vw_customer_optimization.session_id::text AS session_id,
    to_char(vw_customer_optimization.optimization_run_end_time, 'MM-DD-YYYY HH24:MI:SS'::text) AS optimization_run_end_time,
    to_char(vw_customer_optimization.created_date, 'MM-DD-YYYY HH24:MI:SS'::text) AS run_start_time,
    to_char(vw_customer_optimization.billing_period_start_date, 'MM-DD-YYYY HH24:MI:SS'::text) AS billing_period_start_date,
    to_char(vw_customer_optimization.billing_period_end_date, 'MM-DD-YYYY HH24:MI:SS'::text) AS billing_period_end_date,
    vw_customer_optimization.optimization_type,
    vw_customer_optimization.serviceprovider AS service_provider,
    concat(to_char(vw_customer_optimization.billing_period_start_date, 'MM/DD/YYYY'::text), ' - ', to_char(vw_customer_optimization.billing_period_end_date, 'MM/DD/YYYY'::text)) AS billing_period_duration,
    vw_customer_optimization.device_count,
    vw_customer_optimization.device_count_20,
        CASE
            WHEN vw_customer_optimization.device_count IS NOT NULL AND vw_customer_optimization.device_count > 0::numeric THEN vw_customer_optimization.device_count
            ELSE vw_customer_optimization.device_count_20
        END AS final_device_count,
    to_char(trunc(vw_customer_optimization.total_charges, 2), 'FM$999,999,999,999,999,999.00'::text) AS total_charges,
    to_char(trunc(vw_customer_optimization.total_charge_amount, 2), 'FM$999,999,999,999,999.00'::text) AS total_charge_amount,
    vw_customer_optimization.optimization_run_status,
    vw_customer_optimization.customer_name,
    vw_customer_optimization.progress,
        CASE
            WHEN vw_customer_optimization.progress::numeric = 100::numeric THEN 'Run Completed'::text
            WHEN vw_customer_optimization.progress::numeric = 0::numeric THEN 'Run Not Started Yet'::text
            WHEN vw_customer_optimization.progress::numeric > 0::numeric AND vw_customer_optimization.progress::numeric < 100::numeric THEN 'In Progress'::text
            ELSE ' '::text
        END AS optimization_status,
    vw_customer_optimization.modified_date,
    vw_customer_optimization.tenant_id,
    vw_customer_optimization.created_date
   FROM vw_customer_optimization;


-- public.vw_customer_rate_plans source

CREATE OR REPLACE VIEW public.vw_customer_rate_plans
AS SELECT crp.id,
    crp.rate_plan_code,
    crp.plan_mb,
    crp.base_rate,
    crp.surcharge_3g,
    crp.min_plan_data_mb,
    crp.max_plan_data_mb,
    crp.created_by,
    crp.created_date,
    crp.modified_by,
    COALESCE(crp.modified_date, crp.created_date) AS modified_date,
    crp.deleted_by,
    crp.deleted_date,
    crp.is_deleted,
    crp.rate_plan_name,
    crp.rate_charge_amt,
    crp.display_rate,
    crp.base_rate_per_mb,
    crp.is_active,
    crp.service_provider_id,
    crp.data_per_overage_charge,
    crp.overage_rate_cost,
    crp.allows_sim_pooling,
    crp.tenant_id,
    crp.is_billing_advance_eligible,
    crp.sms_rate,
    crp.auto_change_rate_plan,
    crp.serviceproviderids,
    crp.service_provider_name,
    crp.automation_rule,
    crp.optimization_type,
    crp.active_inactive_status,
    crp.soc_code,
    crp.no_tns,
    crp.id_10,
    crp.projected_usage_data,
    crp.automation_rule_flag
   FROM customerrateplan crp
  WHERE crp.is_active = true AND crp.is_deleted = false;


-- public.vw_device_usage_trend_by_month source

CREATE OR REPLACE VIEW public.vw_device_usage_trend_by_month
AS SELECT du_month.service_provider_id,
    du_month.service_provider_name AS service_provider,
    COALESCE(row_number() OVER (ORDER BY du_month.bill_year, du_month.bill_month, du_month.account_number), 0::bigint) AS id,
    du_month.bill_year,
    du_month.bill_month,
    du_month.account_number,
    sum(du_month.carrier_cycle_usage) AS total_usage_bytes,
    sum(du_month.carrier_cycle_usage_mb) AS total_usage_mb,
    count(1) AS total_cards,
    avg(du_month.carrier_cycle_usage) AS avg_usage_per_card_bytes,
    avg(du_month.carrier_cycle_usage_mb) AS avg_usage_per_card_mb,
    du_month.tenant_id,
    du_month.portal_type_id,
    du_month.customer_id,
    du_month.parent_customer_id,
    du_month.customer_name
   FROM ( SELECT jd.service_provider_id,
            sp.service_provider_name,
            jduh.bill_year,
            jduh.bill_month,
            COALESCE(jduh.carrier_cycle_usage::numeric, 0.0) AS carrier_cycle_usage,
                CASE
                    WHEN i.id = 12 THEN COALESCE(jduh.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0
                    ELSE COALESCE(jduh.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0
                END AS carrier_cycle_usage_mb,
            dt.account_number,
            c.tenant_id,
            i.portal_type_id,
            c.id AS customer_id,
            c.parent_customer_id,
            c.customer_name
           FROM device jd
             JOIN device_tenant dt ON jd.id = dt.device_id
             JOIN serviceprovider sp ON sp.id = jd.service_provider_id
             JOIN device_status st ON jd.device_status_id = st.id
             LEFT JOIN customers c ON dt.customer_id = c.id
             LEFT JOIN ( SELECT dh.id,
                    bp.bill_year,
                    bp.bill_month,
                    dh.iccid,
                    dh.carrier_cycle_usage,
                    dh.msisdn,
                    dh.status,
                    dh.created_date,
                    COALESCE(sp_1.bill_period_end_day::character varying, '18'::character varying) AS billing_period_end_day,
                    COALESCE(sp_1.bill_period_end_hour::character varying, '18'::character varying) AS billing_period_end_hour,
                    dh.customer_id
                   FROM device_history dh
                     JOIN device_status st_1 ON st_1.id = dh.device_status_id
                     JOIN serviceprovider sp_1 ON sp_1.id = dh.service_provider_id
                     JOIN billing_period bp ON bp.id = dh.billing_period_id
                  WHERE st_1.is_active_status = true OR dh.carrier_cycle_usage > 0 AND dh.status::text <> 'TEST READY'::text) jduh ON jd.id = jduh.id AND dt.customer_id = jduh.customer_id
             LEFT JOIN integration i ON i.id = sp.integration_id
          WHERE jd.is_active = true AND (st.is_active_status = true OR jd.last_activated_date IS NOT NULL AND jd.last_activated_date > (to_timestamp(((((((jduh.bill_year || '-'::text) || lpad(jduh.bill_month::text, 2, '0'::text)) || '-'::text) || lpad(jduh.billing_period_end_day::text, 2, '0'::text)) || ' '::text) || lpad(jduh.billing_period_end_hour::text, 2, '0'::text)) || ':00'::text, 'YYYY-MM-DD HH24:MI'::text) - '1 mon'::interval))) du_month
  GROUP BY du_month.service_provider_id, du_month.service_provider_name, du_month.bill_year, du_month.bill_month, du_month.account_number, du_month.tenant_id, du_month.portal_type_id, du_month.customer_id, du_month.parent_customer_id, du_month.customer_name;

-- public.vw_m2m_usage_by_customer_pool source

CREATE OR REPLACE VIEW public.vw_m2m_usage_by_customer_pool
AS SELECT gen_random_uuid() AS id,
    customer_rate_pool.customer_rate_pool_id,
    customer_rate_pool.customer_rate_pool_name,
    customer_rate_pool.customer_rate_pool_usage_mb,
    customer_rate_pool.customer_rate_pool_allocated_mb,
    customer_rate_pool.customer_rate_pool_allocated_mb - customer_rate_pool.customer_rate_pool_usage_mb AS customer_rate_pool_data_remaining,
        CASE
            WHEN COALESCE(customer_rate_pool.customer_rate_pool_allocated_mb, 0::numeric) = 0::numeric THEN 0::numeric
            ELSE round(customer_rate_pool.customer_rate_pool_usage_mb * 100.0 / customer_rate_pool.customer_rate_pool_allocated_mb, 2)
        END AS customer_rate_pool_data_usage_percentage,
    customer_rate_pool.customer_rate_pool_device_count,
    customer_rate_pool.customer_rate_pool_tenant_id,
    serviceprovider.id AS service_provider_id,
    serviceprovider.display_name AS service_provider_name,
    integration.portal_type_id,
    device.msisdn AS subscriber_number,
        CASE
            WHEN integration.id = 12 THEN round(COALESCE(device.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 4)::numeric(25,4)
            ELSE round(COALESCE(device.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 4)::numeric(25,4)
        END AS data_usage_mb,
    COALESCE(device_tenant.customer_data_allocation_mb, COALESCE(customerrateplan.plan_mb, 0.0)) AS data_allocation_mb,
    device_tenant.account_number,
    customers.tenant_id,
    customers.id AS customer_id,
    customers.parent_customer_id,
    customers.customer_name,
    device.username,
    customerrateplan.rate_plan_name AS customer_rate_plan_name,
    customerrateplan.overage_rate_cost,
    customerrateplan.data_per_overage_charge,
    device.iccid,
    integration.id AS integration_id,
    billing_period.billing_cycle_end_date AS billing_period_end_date,
    billing_period.billing_cycle_start_date AS billing_period_start_date
   FROM ( SELECT vw_m2m_customer_pool_aggregate_usage.customer_rate_pool_id,
            vw_m2m_customer_pool_aggregate_usage.customer_rate_pool_name,
                CASE
                    WHEN vw_m2m_customer_pool_aggregate_usage.integration_id = 12 THEN round(vw_m2m_customer_pool_aggregate_usage.data_usage_bytes / 1000.0 / 1000.0, 4)::numeric(25,4)
                    ELSE round(vw_m2m_customer_pool_aggregate_usage.data_usage_bytes / 1024.0 / 1024.0, 4)::numeric(25,4)
                END AS customer_rate_pool_usage_mb,
            vw_m2m_customer_pool_aggregate_usage.customer_data_allocation_mb AS customer_rate_pool_allocated_mb,
            vw_m2m_customer_pool_aggregate_usage.num_records AS customer_rate_pool_device_count,
            vw_m2m_customer_pool_aggregate_usage.tenant_id AS customer_rate_pool_tenant_id,
            vw_m2m_customer_pool_aggregate_usage.service_provider_id
           FROM vw_m2m_customer_pool_aggregate_usage) customer_rate_pool
     JOIN device_tenant ON device_tenant.customer_rate_pool_id = customer_rate_pool.customer_rate_pool_id
     JOIN device ON device.id = device_tenant.device_id
     JOIN serviceprovider ON customer_rate_pool.service_provider_id = serviceprovider.id AND serviceprovider.is_active = true
     JOIN integration ON integration.id = serviceprovider.integration_id
     JOIN billing_period ON billing_period.id = device.billing_period_id
     LEFT JOIN customerrateplan ON device_tenant.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customers ON device_tenant.customer_id = customers.id AND customers.is_active = true
     LEFT JOIN revcustomer ON customers.rev_customer_id = revcustomer.id AND revcustomer.is_active = true
  WHERE device.is_active = true AND customerrateplan.is_active = true;

-- public.vw_mobility_device_high_usage_scatter_charts source

CREATE OR REPLACE VIEW public.vw_mobility_device_high_usage_scatter_charts
AS SELECT s.id AS mobility_device_id,
        CASE
            WHEN i.id = 12 THEN round(s.carrier_cycle_usage::numeric / 1000.0 / 1000.0, 3)
            ELSE round(s.carrier_cycle_usage::numeric / 1024.0 / 1024.0, 3)
        END AS ctd_data_usage_mb,
    s.ctd_session_count,
    mt.account_number,
    s.iccid,
    s.msisdn,
    s.service_provider_id,
    sp.service_provider_name,
    c.tenant_id,
    i.portal_type_id,
    s.plan_limit_mb,
    row_number() OVER (ORDER BY c.id)::integer AS id,
    c.parent_customer_id,
    c.customer_name
   FROM mobility_device s
     JOIN mobility_device_tenant mt ON s.id = mt.mobility_device_id
     JOIN serviceprovider sp ON sp.id = s.service_provider_id
     JOIN device_status dst ON s.device_status_id = dst.id
     LEFT JOIN customers c ON mt.customer_id = c.id
     LEFT JOIN integration i ON i.id = sp.integration_id
  WHERE dst.is_active_status = true AND s.carrier_cycle_usage > 0 AND s.is_active = true;


-- public.vw_optimization_push_charges_error_not_id source

CREATE OR REPLACE VIEW public.vw_optimization_push_charges_error_not_id
AS SELECT vosrccq.optimization_instance_id AS instance_id,
    vosrccq.iccid,
    vosrccq.service_provider_id,
    vosrccq.service_provider_display_name AS service_provider,
    vosrccq.rev_account_number AS rev_customer_id,
    vosrccq.customer_name,
    vosrccq.msisdn,
    vosrccq.total_charge_amount,
    vosrccq.error_message,
    vosrccq.session_id,
    vosrccq.modified_date
   FROM vw_optimization_smi_result_customer_charge_queue_not_id vosrccq
  WHERE vosrccq.has_errors IS TRUE AND vosrccq.error_message IS NOT NULL;

-- public.vw_pool_group_summary_report source

CREATE OR REPLACE VIEW public.vw_pool_group_summary_report
AS SELECT du.foundation_account_number,
    du.billing_account_number,
    du.data_group_id,
    du.pool_id,
    du.data_usage,
    du.data_total AS plan_limit_bytes,
        CASE
            WHEN COALESCE(du.data_total, 0::bigint) = 0 THEN NULL::bigint
            ELSE du.data_total - COALESCE(du.data_usage, 0::bigint)
        END AS data_remaining,
        CASE
            WHEN COALESCE(du.data_total, 0::bigint) = 0 THEN NULL::numeric
            ELSE (COALESCE(du.data_usage, 0::bigint)::numeric * 100.0 / du.data_total::numeric)::numeric(18,2)
        END AS data_usage_percentage,
        CASE
            WHEN COALESCE(du.data_total, 0::bigint) = 0 THEN NULL::numeric
            ELSE ((du.data_total - COALESCE(du.data_usage, 0::bigint))::numeric * 100.0 / du.data_total::numeric)::numeric(18,2)
        END AS data_remaining_percentage,
    sp.display_name AS service_provider_name,
        CASE
            WHEN COALESCE(du.pool_id, ''::character varying)::text <> ''::text THEN ( SELECT count(1) AS count
               FROM mobility_device m
              WHERE m.is_deleted = false AND m.pool_id::text = du.pool_id::text)
            ELSE 0::bigint
        END AS pool_device_count,
        CASE
            WHEN COALESCE(du.data_group_id, ''::character varying)::text <> ''::text THEN ( SELECT count(1) AS count
               FROM mobility_device m
              WHERE m.is_deleted = false AND m.data_group_id::text = du.data_group_id::text)
            ELSE 0::bigint
        END AS data_group_device_count,
    du.created_date,
    array_to_string(array_remove(ARRAY[du.id, sp.id, i.id], NULL::integer), '-'::text) AS id,
    du.is_active,
    du.modified_date,
    du.tenant_id
   FROM mobility_device_usage_aggregate du
     JOIN serviceprovider sp ON du.service_provider_id = sp.id
     JOIN integration i ON sp.integration_id = i.id
  WHERE COALESCE(du.data_group_id, ''::character varying)::text <> ''::text OR COALESCE(du.pool_id, ''::character varying)::text <> ''::text;


-- public.vw_smi_sim_cards_by_carrier_rate_plan_limit_report source

CREATE OR REPLACE VIEW public.vw_smi_sim_cards_by_carrier_rate_plan_limit_report
AS SELECT dt.account_number,
    sp.service_provider_name,
    count(1) AS sim_count,
    sum(COALESCE(smi.carrier_cycle_usage, 0::bigint)) AS carrier_cycle_usage,
    sum(COALESCE(smi.ctd_session_count, 0::bigint)) AS ctd_session_count,
    crp.plan_mb,
    i.portal_type_id,
    row_number() OVER (ORDER BY c.id)::integer AS id,
    c.parent_customer_id,
    c.customer_name,
    c.tenant_id,
    max(smi.modified_date) AS modified_date
   FROM device smi
     JOIN device_tenant dt ON smi.id = dt.device_id
     JOIN device_status ds ON smi.device_status_id = ds.id
     JOIN serviceprovider sp ON smi.service_provider_id = sp.id
     LEFT JOIN carrier_rate_plan crp ON crp.id = smi.carrier_rate_plan_id
     LEFT JOIN customers c ON dt.customer_id = c.id
     LEFT JOIN integration i ON i.id = sp.integration_id
  WHERE smi.is_active = true AND smi.is_deleted = false AND ds.is_active_status = true
  GROUP BY smi.service_provider_id, sp.service_provider_name, dt.account_number, crp.plan_mb, i.portal_type_id, c.id, c.parent_customer_id, c.customer_name, c.tenant_id;

-- public.vw_smi_sim_cards_by_customer_rate_plan_limit_report source

CREATE OR REPLACE VIEW public.vw_smi_sim_cards_by_customer_rate_plan_limit_report
AS SELECT COALESCE(gen_random_uuid(), gen_random_uuid()) AS unique_id,
    smi.service_provider_id,
    sp.service_provider_name,
    dt.account_number,
    count(1) AS sim_count,
    sum(COALESCE(smi.carrier_cycle_usage, 0::bigint)) AS carrier_cycle_usage,
    sum(COALESCE(smi.ctd_session_count, 0::bigint)) AS ctd_session_count,
    c.tenant_id,
    i.portal_type_id,
    crp.plan_mb,
    c.id,
    c.parent_customer_id,
    c.customer_name
   FROM device smi
     JOIN device_tenant dt ON smi.id = dt.device_id
     JOIN device_status ds ON smi.device_status_id = ds.id
     JOIN serviceprovider sp ON smi.service_provider_id = sp.id
     LEFT JOIN customerrateplan crp ON crp.id = dt.customer_rate_plan_id
     LEFT JOIN customers c ON dt.customer_id = c.id
     LEFT JOIN integration i ON i.id = sp.integration_id
  WHERE smi.is_active = true AND smi.is_deleted = false AND ds.is_active_status = true
  GROUP BY smi.service_provider_id, sp.service_provider_name, dt.account_number, c.tenant_id, i.portal_type_id, crp.plan_mb, c.id, c.parent_customer_id, c.customer_name;

-- public.vw_carrier_rate_plan source

CREATE OR REPLACE VIEW public.vw_carrier_rate_plan
AS SELECT carrier_rate_plan.id,
    carrier_rate_plan.service_provider,
        CASE
            WHEN carrier_rate_plan.service_provider_id = 6 THEN carrier_rate_plan.rate_plan_code
            ELSE ''::character varying
        END AS rate_plan_code,
        CASE
            WHEN carrier_rate_plan.service_provider_id = 6 THEN carrier_rate_plan.rate_plan_short_name
            ELSE ''::character varying
        END AS rate_plan_short_name,
        CASE
            WHEN carrier_rate_plan.friendly_name IS NULL THEN
            CASE
                WHEN carrier_rate_plan.rate_plan_code::text = carrier_rate_plan.rate_plan_short_name::text THEN carrier_rate_plan.rate_plan_code::text
                ELSE carrier_rate_plan.rate_plan_code::text || carrier_rate_plan.rate_plan_short_name::text
            END::character varying
            ELSE carrier_rate_plan.friendly_name
        END AS friendly_name,
    carrier_rate_plan.device_type,
    carrier_rate_plan.base_rate,
    carrier_rate_plan.overage_rate_cost,
    carrier_rate_plan.plan_mb,
    carrier_rate_plan.data_per_overage_charge,
    carrier_rate_plan.allows_sim_pooling,
    carrier_rate_plan.is_retired,
    carrier_rate_plan.modified_by,
    carrier_rate_plan.modified_date,
        CASE
            WHEN carrier_rate_plan.assigned = true THEN 'Yes'::text
            WHEN carrier_rate_plan.assigned = false THEN 'No'::text
            ELSE 'No'::text
        END AS assigned,
    carrier_rate_plan.optimization_rate_plan_type_id,
    carrier_rate_plan.default_optimization_group_id,
        CASE
            WHEN carrier_rate_plan.service_provider_id = 6 THEN carrier_rate_plan.friendly_name
            ELSE carrier_rate_plan.rate_plan_short_name
        END::text || COALESCE(carrier_rate_plan.device_type, ''::character varying)::text AS rate_plan,
    carrier_rate_plan.service_provider_id
   FROM carrier_rate_plan
  WHERE carrier_rate_plan.is_active = true
  ORDER BY carrier_rate_plan.modified_date DESC;

-- public.vw_cross_provider_usage_by_line_report_for_customer source

CREATE OR REPLACE VIEW public.vw_cross_provider_usage_by_line_report_for_customer
AS WITH billing_data AS (
         SELECT c.id AS customer_id,
            c.customer_name,
            c.tenant_id,
            cbp.id AS billing_period_id,
            cbp.bill_month,
            cbp.bill_year,
            COALESCE(c.customer_bill_period_end_day, 1) AS customer_bill_period_end_day,
            COALESCE(c.customer_bill_period_end_hour, 0) AS customer_bill_period_end_hour,
            c.is_active,
            c.is_deleted
           FROM customers c
             LEFT JOIN LATERAL usp_get_customer_billing_period_by_siteid(c.id) cbp(id, bill_month, bill_year, customer_bill_period_end_day, customer_bill_period_end_hour) ON true
        )
 SELECT billing_data.customer_id,
    billing_data.customer_name,
    billing_data.tenant_id,
    array_agg(billing_data.billing_period_id) AS billing_period_ids,
    array_agg(
        CASE
            WHEN billing_data.billing_period_id IS NOT NULL THEN concat(lpad(billing_data.bill_month::text, 2, '0'::text), '-', lpad(billing_data.customer_bill_period_end_day::text, 2, '0'::text), '-', billing_data.bill_year::text, ' ', lpad(billing_data.customer_bill_period_end_hour::text, 2, '0'::text), ':00:00')
            ELSE NULL::text
        END) AS billing_cycle_end_date,
    billing_data.is_active,
    billing_data.is_deleted
   FROM billing_data
  GROUP BY billing_data.customer_id, billing_data.customer_name, billing_data.tenant_id, billing_data.is_active, billing_data.is_deleted
  ORDER BY billing_data.customer_name;


-- public.vw_usage_by_line_report_cross_provider_device_history source

CREATE OR REPLACE VIEW public.vw_usage_by_line_report_cross_provider_device_history
AS WITH mobility_bill_periods AS (
         SELECT billing_period.id
           FROM billing_period
          WHERE billing_period.is_active = true AND billing_period.is_deleted = false AND billing_period.service_provider_id = 6
        ), m2m_bill_periods AS (
         SELECT billing_period.id
           FROM billing_period
          WHERE billing_period.is_active = true AND billing_period.is_deleted = false AND billing_period.service_provider_id <> 6
        )
 SELECT t.composite_id AS id,
    t.billing_cycle_end_date,
    t.service_provider_id,
    t.service_provider_display_name,
    t.integration_id,
    t.iccid,
    t.msisdn,
    t.imei,
    t.carrier_rate_plan,
    t.carrier_cycle_usage,
    t.data_usage_mb,
    t.date_added,
    t.date_activated,
    t.rate_plan_code,
    t.rate_plan_name,
    t.customer_rate_plan_allows_sim_pooling,
    t.plan_mb,
    t.created_date,
    t.created_by,
    t.modified_by,
    t.modified_date,
    t.deleted_by,
    t.deleted_date,
    t.is_active,
    t.is_deleted,
    t.account_number,
    t.carrier_rate_plan_id,
    t.status_code,
    t.status_display_name,
    t.status_color,
    t.status_color_code,
    t.tenant_id,
    t.rev_customer_id,
    t.customer_name,
    t.rev_parent_customer_id,
    t.foundation_account_number,
    t.billing_account_number,
    t.service_zip_code,
    t.rate_plan_soc,
    t.rate_plan_soc_description,
    t.data_group_id,
    t.pool_id,
    t.device_make,
    t.device_model,
    t.contract_status,
    t.ban_status,
    t.imei_type_id,
    t.plan_limit_mb,
    t.username,
    t.sms_usage,
    t.minutes_used,
    t.ip_address,
    t.customer_rate_pool_name,
    t.device_history_id,
    t.is_pushed,
    t.customer_data_allocation_mb,
    t.billing_period_id
   FROM ( SELECT mobility_device_history.id AS device_history_id,
            billing_period.billing_cycle_end_date,
            mobility_device_history.service_provider_id,
            serviceprovider.display_name AS service_provider_display_name,
            serviceprovider.integration_id,
            mobility_device_history.iccid,
            mobility_device_history.msisdn,
            mobility_device_history.imei,
            mobility_device_history.rate_plan AS carrier_rate_plan,
            mobility_device_history.carrier_cycle_usage,
                CASE
                    WHEN integration.id = 12 THEN round(COALESCE(mobility_device_history.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
                    ELSE round(COALESCE(mobility_device_history.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
                END AS data_usage_mb,
            mobility_device_history.provider_date_added AS date_added,
            mobility_device_history.provider_date_activated AS date_activated,
            customerrateplan.rate_plan_code,
            customerrateplan.rate_plan_name,
            customerrateplan.allows_sim_pooling AS customer_rate_plan_allows_sim_pooling,
            customerrateplan.plan_mb,
            mobility_device_history.created_date,
            mobility_device_history.created_by,
            mobility_device_history.modified_by,
            COALESCE(mobility_device_history.modified_date, mobility_device_history.created_date) AS modified_date,
            mobility_device_history.deleted_by,
            mobility_device_history.deleted_date,
            mobility_device_history.is_active,
            mobility_device_history.is_deleted,
            mobility_device_history.account_number,
            mobility_device_history.carrier_rate_plan_id,
            mobility_device_history.status AS status_code,
            device_status.display_name AS status_display_name,
            device_status.status_color,
            device_status.status_color_code,
            customers.tenant_id,
            revcustomer.rev_customer_id,
            customers.customer_name,
            revcustomer.rev_parent_customer_id,
            mobility_device_history.foundation_account_number,
            mobility_device_history.billing_account_number,
            mobility_device_history.service_zip_code,
            mobility_device_history.single_user_code AS rate_plan_soc,
            mobility_device_history.single_user_code_description AS rate_plan_soc_description,
            mobility_device_history.data_group_id,
            mobility_device_history.pool_id,
            mobility_device_history.device_make,
            mobility_device_history.device_model,
            mobility_device_history.contract_status,
            mobility_device_history.ban_status,
            mobility_device_history.imei_type_id,
            mobility_device_history.plan_limit_mb,
            mobility_device_history.username,
            COALESCE(mobility_device_history.ctd_sms_usage, 0::bigint) AS sms_usage,
            mobility_device_history.ctd_voice_usage AS minutes_used,
            mobility_device_history.ip_address,
            customer_rate_pool.name AS customer_rate_pool_name,
            mobility_device_history.is_pushed,
            customerrateplan.plan_mb AS customer_data_allocation_mb,
            array_to_string(array_remove(ARRAY[mobility_device_history.id, mobility_device_tenant.id, serviceprovider.id], NULL::integer), '-'::text) AS composite_id,
            billing_period.id AS billing_period_id
           FROM cross_provider_device_history mobility_device_history
             JOIN serviceprovider ON mobility_device_history.service_provider_id = serviceprovider.id
             LEFT JOIN customers ON customers.id = mobility_device_history.customer_id
             LEFT JOIN device_status ON device_status.id = mobility_device_history.device_status_id
             LEFT JOIN revcustomer ON revcustomer.id = customers.rev_customer_id
             LEFT JOIN billing_period ON mobility_device_history.billing_period_id = billing_period.id
             LEFT JOIN integration ON integration.id = serviceprovider.integration_id
             LEFT JOIN mobility_device_tenant ON mobility_device_history.history_id = mobility_device_tenant.mobility_device_id AND mobility_device_history.mobility_device_tenant_id = mobility_device_tenant.id
             LEFT JOIN customerrateplan ON mobility_device_history.customer_rate_plan_id = customerrateplan.id
             LEFT JOIN customer_rate_pool ON mobility_device_history.customer_rate_pool_id = customer_rate_pool.id
          WHERE mobility_device_history.is_active = true AND mobility_device_history.is_deleted = false AND integration.portal_type_id = 2 AND (mobility_device_history.billing_period_id IN ( SELECT mobility_bill_periods.id
                   FROM mobility_bill_periods)) AND (device_status.is_active_status = true OR mobility_device_history.last_activated_date < billing_period.billing_cycle_end_date AND mobility_device_history.last_activated_date > billing_period.billing_cycle_start_date OR mobility_device_history.carrier_cycle_usage >= 0)
        UNION ALL
         SELECT device_history.id AS device_history_id,
            billing_period.billing_cycle_end_date,
            device_history.service_provider_id,
            serviceprovider.display_name AS service_provider_display_name,
            serviceprovider.integration_id,
            device_history.iccid,
            device_history.msisdn,
            device_history.imei,
            device_history.rate_plan AS carrier_rate_plan,
            device_history.carrier_cycle_usage,
                CASE
                    WHEN integration.id = 12 THEN round(COALESCE(device_history.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
                    ELSE round(COALESCE(device_history.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
                END AS data_usage_mb,
            device_history.provider_date_added AS date_added,
            device_history.provider_date_activated AS date_activated,
            customerrateplan.rate_plan_code,
            customerrateplan.rate_plan_name,
            customerrateplan.allows_sim_pooling AS customer_rate_plan_allows_sim_pooling,
            customerrateplan.plan_mb,
            device_history.created_date,
            device_history.created_by,
            device_history.modified_by,
            COALESCE(device_history.modified_date, device_history.created_date) AS modified_date,
            device_history.deleted_by,
            device_history.deleted_date,
            device_history.is_active,
            device_history.is_deleted,
            device_tenant.account_number,
            device_history.carrier_rate_plan_id,
            device_history.status AS status_code,
            device_status.display_name AS status_display_name,
            device_status.status_color,
            device_status.status_color_code,
            device_tenant.tenant_id,
            revcustomer.rev_customer_id,
            customers.customer_name,
            revcustomer.rev_parent_customer_id,
            NULL::character varying AS foundation_account_number,
            NULL::character varying AS billing_account_number,
            NULL::character varying AS service_zip_code,
            NULL::character varying AS rate_plan_soc,
            NULL::character varying AS rate_plan_soc_description,
            NULL::character varying AS data_group_id,
            NULL::character varying AS pool_id,
            NULL::character varying AS device_make,
            NULL::character varying AS device_model,
            NULL::character varying AS contract_status,
            NULL::character varying AS ban_status,
            NULL::integer AS imei_type_id,
            NULL::numeric AS plan_limit_mb,
            device_history.username,
            COALESCE(device_history.ctd_sms_usage, 0::bigint) AS sms_usage,
            device_history.ctd_voice_usage AS minutes_used,
            NULL::character varying AS ip_address,
            customer_rate_pool.name AS customer_rate_pool_name,
            device_history.is_pushed,
            customerrateplan.plan_mb AS customer_data_allocation_mb,
            array_to_string(array_remove(ARRAY[device_history.id::bigint, device_tenant.id::bigint, serviceprovider.id::bigint], NULL::integer::bigint), '-'::text) AS composite_id,
            billing_period.id AS billing_period_id
           FROM cross_provider_device_history device_history
             JOIN device_tenant ON device_history.device_tenant_id = device_tenant.id
             JOIN serviceprovider ON device_history.service_provider_id = serviceprovider.id
             LEFT JOIN customers ON customers.id = device_tenant.customer_id
             LEFT JOIN device_status ON device_status.id = device_history.device_status_id
             LEFT JOIN revcustomer ON revcustomer.id = customers.rev_customer_id
             LEFT JOIN billing_period ON device_history.billing_period_id = billing_period.id
             LEFT JOIN integration ON integration.id = serviceprovider.integration_id
             LEFT JOIN customerrateplan ON device_history.customer_rate_plan_id = customerrateplan.id
             LEFT JOIN customer_rate_pool ON device_history.customer_rate_pool_id = customer_rate_pool.id
          WHERE device_history.is_active = true AND device_history.is_deleted = false AND integration.portal_type_id = 0 AND (device_history.billing_period_id IN ( SELECT m2m_bill_periods.id
                   FROM m2m_bill_periods)) AND (device_status.is_active_status = true OR device_history.last_activated_date < billing_period.billing_cycle_end_date AND device_history.last_activated_date > billing_period.billing_cycle_start_date OR device_history.carrier_cycle_usage >= 0)) t;