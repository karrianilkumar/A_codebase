CREATE OR REPLACE VIEW public.customer_bandwidth_view
 AS
 SELECT bws_customers.id AS customer_pid,
    bws_customers.tenant_name,
    bws_customers.modified_by,
    bws_customers.modified_date,
    t_bandwidth_customers.id AS bandwdith_customers_pid,
    t_bandwidth_customers.bandwidth_customer_name,
    t_bandwidthaccount.id AS bandwdith_account_pid,
    t_bandwidthaccount.global_account_number
   FROM customers bws_customers
     JOIN bandwidth_customers t_bandwidth_customers ON bws_customers.bandwidth_customer_id::integer = t_bandwidth_customers.id
     JOIN bandwidthaccount t_bandwidthaccount ON t_bandwidth_customers.bandwidth_account_id = t_bandwidthaccount.id;

CREATE OR REPLACE VIEW public.bulk_chage_att_telegence_summary
AS
SELECT DISTINCT crp.service_provider_id,
    crp.service_provider,
    crp.rate_plan_code AS carrier_rate_plan_code,
    concat(crp2.name, '-', crp2.id) AS customer_rate_pool_name_id,
    concat(ccp.rate_plan_name, '-', ccp.rate_plan_code) AS customerrateplan_rate_plan_name_code,
    smcp.communication_plan_name
   FROM carrier_rate_plan crp
     LEFT JOIN customer_rate_pool crp2 ON crp.service_provider_id = crp2.service_provider_id
     LEFT JOIN customerrateplan ccp ON crp.service_provider_id = ccp.service_provider_id
     LEFT JOIN sim_management_communication_plan smcp ON crp.service_provider_id = smcp.service_provider_id
WHERE crp.service_provider_id = 1;

CREATE OR REPLACE VIEW public.customers_bandwidth_customer_id_view
AS
SELECT id,
    tenant_id,
    tenant_name,
    subtenant_name,
    customer_id,
    customer_name,
    billing_account_number,
    customer_rate_plans,
    customer_bill_period_end_date,
    customer_bill_period_end_hour,
    customer_bill_period_end_day,
    apt_suite,
    address1,
    address2,
    city,
    state,
    postal_code,
    postal_code_extension,
    country,
    rev_customer_id,
    e911_customer_id,
    bandwidth_customer_id,
    netsapiens_customer_id,
    netsapiens_domain_id,
    created_by,
    created_date,
    deleted_by,
    deleted_date,
    modified_by,
    modified_date,
    is_deleted,
    is_active,
    first_name,
    middle_initial,
    last_name,
    company_name,
    description,
    inactivity_start,
    inactivity_end,
    county_parish_borough,
    netsapiens_type
  FROM customers
WHERE bandwidth_customer_id IS NOT NULL;

CREATE OR REPLACE VIEW public.customers_netsapiens_customer_id_view
 AS
 SELECT id,
    tenant_name,
    customer_name,
    netsapiens_type,
    modified_date,
    modified_by
   FROM customers
  WHERE netsapiens_type IS NOT NULL;

CREATE or replace VIEW vw_sim_management_inventory_list_view AS
SELECT 
    smi.id,
    smi.service_provider_id,
    smi.service_provider,
    smi.iccid,
    smi.msisdn,
    smi.eid,
    COALESCE(dt.customer_id, mdt.customer_id) AS customer_id,  -- Use COALESCE for customer_id
    COALESCE(dt.customer_name, mdt.customer_name) AS customer_name,
    smi.username,
    smi.carrier_cycle_usage,
    smi.customer_cycle_usage,
    COALESCE(dt.customer_rate_pool_id, mdt.customer_rate_pool_id) AS customer_rate_pool_id,  -- Use COALESCE for customer_rate_pool_id
    COALESCE(dt.customer_rate_pool_name, mdt.customer_rate_pool_name) AS customer_rate_pool_name,
    COALESCE(dt.customer_rate_plan_id, mdt.customer_rate_plan_id) AS customer_rate_plan_id, 
    COALESCE(dt.customer_rate_plan_name, mdt.customer_rate_plan_name) AS customer_rate_plan_name,
    smi.carrier_rate_plan_id,
    smi.carrier_rate_plan, 
    smi.device_status_id,
    smi.sim_status,
    smi.date_added,
    smi.date_activated,
    smi.ip_address,
    smi.billing_account_number,
    smi.foundation_account_number,
    smi.modified_by,
    smi.modified_date,
    smi.is_active,
    smi.is_deleted,
    smi.last_usage_date
FROM 
    sim_management_inventory smi
LEFT JOIN 
    device_tenant dt ON smi.device_id = dt.device_id and dt.tenant_id = 1 and dt.is_active is true  -- Moved tenant_id filter to ON clause
LEFT JOIN 
    mobility_device_tenant mdt ON smi.mobility_device_id = mdt.mobility_device_id and mdt.tenant_id = 1 and mdt.is_active is true;

CREATE OR REPLACE VIEW public.rev_assurance_list_view
 AS
 SELECT smi.id,
        CASE
            WHEN s.integration_id = 12 THEN smi.eid
            ELSE
            CASE
                WHEN s.integration_id = 13 THEN smi.iccid
                ELSE COALESCE(smi.msisdn, smi.iccid)
            END
        END AS service_number,
    ds.display_name AS device_status,
    COALESCE(dsh.date_of_change, smi.date_activated) AS carrier_last_status_date,
    ds.should_have_billed_service,
    smi.iccid,
    smi.service_provider_id,
    s.display_name AS service_provider,
    smi.communication_plan,
    rs.activated_date,
    rs.disconnected_date,
    rsp.service_product_id,
        CASE
            WHEN rsp.package_id = 0 THEN NULL::integer
            ELSE rsp.package_id
        END AS package_id,
    rsp.service_id,
    rsp.product_id AS revserviceproduct_product_id,
    rsp.description,
    rsp.rate,
    rsp.status AS rev_io_status,
        CASE
            WHEN rsp.status::text = 'ACTIVE'::text THEN true
            ELSE false
        END AS rev_is_active_status,
    rsp.cost,
    rsp.wholesale_description,
    rsp.quantity,
    rsp.integration_authentication_id,
    COALESCE(r.rev_customer_id, c2.rev_customer_id::text::character varying) AS rev_account_number,
    COALESCE(r.customer_name, c2.customer_name) AS customer_name,
    rp.id AS rev_product_id,
    rp.product_id,
    rp.description AS product_description,
    rst.service_type_id,
    smi.tenant_id,
    smi.last_activated_date AS carrier_activated_date,
    c.rate_plan_name AS customer_rate_plan_name,
    smi.carrier_rate_plan
   FROM sim_management_inventory smi
     JOIN device_status ds ON ds.id = smi.device_status_id
     JOIN serviceprovider s ON s.id = smi.service_provider_id AND s.is_active IS TRUE AND s.is_deleted IS FALSE
     JOIN integration i ON i.id = s.integration_id
     LEFT JOIN rev_service rs ON rs.id = smi.rev_service_id
     LEFT JOIN customerrateplan c ON smi.customer_rate_plan_id = c.id
     LEFT JOIN customers c2 ON smi.customer_id = c2.id AND c2.rev_customer_id IS NOT NULL
     LEFT JOIN revcustomer r ON c2.rev_customer_id = r.id AND r.status::text <> 'CLOSED'::text AND r.is_active IS TRUE AND r.is_deleted IS FALSE
     LEFT JOIN rev_service_product rsp ON rs.rev_service_id = rsp.service_id AND rsp.integration_authentication_id = rs.integration_authentication_id AND rsp.status::text = 'ACTIVE'::text AND rsp.is_active IS TRUE AND rsp.is_deleted IS FALSE
     LEFT JOIN revcustomer r2 ON rsp.customer_id::text = r2.rev_customer_id::text AND rsp.integration_authentication_id = r2.integration_authentication_id AND r2.status::text <> 'CLOSED'::text AND r2.is_active IS TRUE AND r2.is_deleted = false
     LEFT JOIN integration_authentication ia ON r2.integration_authentication_id = ia.id
     LEFT JOIN rev_product rp ON rsp.product_id = rp.product_id AND rsp.integration_authentication_id = rp.integration_authentication_id
     LEFT JOIN rev_service_type rst ON rst.id = rs.rev_service_type_id AND rst.integration_authentication_id = rs.integration_authentication_id
     LEFT JOIN rev_product_type rpt ON rpt.product_type_id = rp.product_type_id AND rpt.integration_authentication_id = rp.integration_authentication_id AND (rpt.product_type_code IS NULL OR rpt.product_type_code::text ~~ 'RECURRING_%'::text)
     LEFT JOIN ( SELECT dsh_1.iccid,
            max(dsh_1.date_of_change) AS date_of_change
           FROM device_status_history dsh_1
          GROUP BY dsh_1.iccid) dsh ON dsh.iccid::text = smi.iccid::text
  WHERE smi.is_deleted IS FALSE;

CREATE OR REPLACE VIEW public.rev_customer_device_summary_view
 AS
 SELECT COALESCE(customer_name, 'Unassigned'::character varying) AS customer_name,
    count(*) AS device_count,
    sum(
        CASE
            WHEN device_status::text = 'Active'::text AND rev_is_active_status = true THEN 1
            ELSE 0
        END) AS charged_devices_count
   FROM rev_assurance_list_view
  GROUP BY (COALESCE(customer_name, 'Unassigned'::character varying))
  ORDER BY (COALESCE(customer_name, 'Unassigned'::character varying));


CREATE OR REPLACE VIEW public.rev_assurance_list_view_with_count
 AS
 SELECT ralv.id,
    ralv.service_number,
    ralv.device_status,
    ralv.carrier_last_status_date,
    ralv.should_have_billed_service,
    ralv.iccid,
    ralv.service_provider_id,
    ralv.service_provider,
    ralv.communication_plan,
    ralv.activated_date,
    ralv.disconnected_date,
    ralv.service_product_id,
    ralv.package_id,
    ralv.service_id,
    ralv.revserviceproduct_product_id,
    ralv.description,
    ralv.rate,
    ralv.rev_io_status,
    ralv.rev_is_active_status,
    ralv.cost,
    ralv.wholesale_description,
    ralv.quantity,
    ralv.integration_authentication_id,
    ralv.rev_account_number,
    ralv.customer_name,
    ralv.rev_product_id,
    ralv.product_id,
    ralv.product_description,
    ralv.service_type_id,
    ralv.tenant_id,
    ralv.carrier_activated_date,
    ralv.customer_rate_plan_name,
    ralv.carrier_rate_plan,
    rcdsv.device_count,
    rcdsv.charged_devices_count
   FROM rev_assurance_list_view ralv
     JOIN rev_customer_device_summary_view rcdsv ON ralv.customer_name::text = rcdsv.customer_name::text;



CREATE OR REPLACE VIEW public.rev_service_list_view
 AS
 SELECT smi.id,
        CASE
            WHEN s.integration_id = 12 THEN smi.eid
            ELSE
            CASE
                WHEN s.integration_id = 13 THEN smi.iccid
                ELSE COALESCE(smi.msisdn, smi.iccid)
            END
        END AS service_number,
    ds.display_name AS device_status,
    COALESCE(dsh.date_of_change, smi.date_activated) AS carrier_last_status_date,
    ds.should_have_billed_service,
    smi.iccid,
    smi.service_provider_id,
    s.display_name AS service_provider,
    smi.communication_plan,
    rs.activated_date,
    rs.disconnected_date,
    rsp.service_product_id,
        CASE
            WHEN rsp.package_id = 0 THEN NULL::integer
            ELSE rsp.package_id
        END AS package_id,
    rsp.service_id,
    rsp.product_id AS rev_service_product_product_id,
    rsp.description,
    rsp.rate,
    rsp.status AS rev_io_status,
        CASE
            WHEN rsp.status::text = 'ACTIVE'::text THEN true
            ELSE false
        END AS rev_is_active_status,
    rsp.cost,
    rsp.wholesale_description,
    rsp.quantity,
    rsp.integration_authentication_id,
    COALESCE(r.rev_customer_id, c2.rev_customer_id::text::character varying) AS rev_account_number,
    COALESCE(r.customer_name, c2.customer_name) AS customer_name,
    rp.id AS rev_product_id,
    rp.product_id,
    rp.description AS product_description,
    rst.service_type_id,
    smi.tenant_id,
    smi.last_activated_date AS carrier_activated_date,
    c.rate_plan_name AS customer_rate_plan_name,
    smi.carrier_rate_plan
   FROM sim_management_inventory smi
     JOIN device_status ds ON ds.id = smi.device_status_id
     JOIN serviceprovider s ON s.id = smi.service_provider_id AND s.is_active IS TRUE AND s.is_deleted IS FALSE
     JOIN integration i ON i.id = s.integration_id
     LEFT JOIN rev_service rs ON rs.id = smi.rev_service_id
     LEFT JOIN customerrateplan c ON smi.customer_rate_plan_id = c.id
     LEFT JOIN customers c2 ON smi.customer_id = c2.id AND c2.rev_customer_id IS NOT NULL
     LEFT JOIN revcustomer r ON c2.rev_customer_id = r.id AND r.status::text <> 'CLOSED'::text AND r.is_active IS TRUE AND r.is_deleted IS FALSE
     LEFT JOIN rev_service_product rsp ON rs.rev_service_id = rsp.service_id AND rsp.integration_authentication_id = rs.integration_authentication_id AND rsp.status::text = 'ACTIVE'::text AND rsp.is_active IS TRUE AND rsp.is_deleted IS FALSE
     LEFT JOIN revcustomer r2 ON rsp.customer_id::text = r2.rev_customer_id::text AND rsp.integration_authentication_id = r2.integration_authentication_id AND r2.status::text <> 'CLOSED'::text AND r2.is_active IS TRUE AND r2.is_deleted = false
     LEFT JOIN integration_authentication ia ON r2.integration_authentication_id = ia.id
     LEFT JOIN rev_product rp ON rsp.product_id = rp.product_id AND rsp.integration_authentication_id = rp.integration_authentication_id
     LEFT JOIN rev_service_type rst ON rst.id = rs.rev_service_type_id AND rst.integration_authentication_id = rs.integration_authentication_id
     LEFT JOIN rev_product_type rpt ON rpt.product_type_id = rp.product_type_id AND rpt.integration_authentication_id = rp.integration_authentication_id AND (rpt.product_type_code IS NULL OR rpt.product_type_code::text ~~ 'RECURRING_%'::text)
     LEFT JOIN ( SELECT dsh_1.iccid,
            max(dsh_1.date_of_change) AS date_of_change
           FROM device_status_history dsh_1
          GROUP BY dsh_1.iccid) dsh ON dsh.iccid::text = smi.iccid::text
  WHERE smi.is_deleted IS FALSE;


CREATE OR REPLACE VIEW public.usp_optimization_customer_charges_count_for_cross_optimization
 AS
 SELECT instance_id,
    sum(charge_count) AS chargecount,
    sum(overage_charge_amount) AS overagechargeamount,
    sum(total_charge_amount) AS totalchargeamount,
    sum(unassigned_device_count) AS unassigneddevicecount,
    sum(sms_charge_total) AS smschargetotal
   FROM ( SELECT oq.instance_id,
            sum(
                CASE
                    WHEN jcust_rp.id IS NOT NULL THEN 1
                    ELSE 0
                END) AS charge_count,
            sum(COALESCE(odr.charge_amt::numeric, 0.0) - COALESCE(jcust_rp.base_rate::numeric, 0.0)) AS overage_charge_amount,
            sum(COALESCE(odr.charge_amt::numeric, 0.0)) AS total_charge_amount,
            sum(
                CASE
                    WHEN jcust_rp.id IS NULL THEN 1
                    ELSE 0
                END) AS unassigned_device_count,
            sum(COALESCE(odr.sms_charge_amount::numeric, 0.0)) AS sms_charge_total
           FROM optimization_smi_result odr
             JOIN optimization_queue oq ON odr.queue_id = oq.id
             JOIN optimization_instance oi ON oq.instance_id = oi.id
             JOIN sim_management_inventory smi ON odr.sim_management_inventory_id = smi.id
             LEFT JOIN customerrateplan jcust_rp ON odr.assigned_customer_rate_plan_id = jcust_rp.id
          GROUP BY oq.instance_id) customer_charges_count
  GROUP BY instance_id;

CREATE OR REPLACE VIEW public.vw_customer_pool_aggregate_usage
 AS
 SELECT crp.id AS customer_rate_pool_id,
    crp.name AS customer_rate_pool_name,
    crp.service_provider_id,
    sp.display_name AS service_provider_name,
    crp.tenant_id,
    COALESCE(sum(smi.carrier_cycle_usage), 0.0) AS data_usage_bytes,
    COALESCE(sum(smi.customer_data_allocation_mb), c.plan_mb) AS customer_data_allocation_mb,
    count(*) AS num_records,
    sp.integration_id
   FROM customer_rate_pool crp
     JOIN sim_management_inventory smi ON smi.customer_pool_id = crp.id
     JOIN serviceprovider sp ON crp.service_provider_id = sp.id
     JOIN customerrateplan c ON smi.customer_rate_plan_id = c.id
  WHERE crp.is_active = true AND crp.is_deleted = false AND smi.is_active = true AND smi.is_deleted = false AND sp.is_active = true AND sp.is_deleted = false AND c.is_active = true AND c.is_deleted = false
  GROUP BY crp.id, crp.name, crp.service_provider_id, sp.display_name, crp.tenant_id, sp.integration_id, c.plan_mb;

CREATE OR REPLACE VIEW public.vw_customer_rate_pool_usage_report
 AS
 SELECT row_number() OVER () AS id,
    customerratepool.customer_rate_pool_id,
    customerratepool.customer_rate_pool_name,
    customerratepool.customer_rate_pool_usage_mb,
    customerratepool.customer_rate_pool_allocated_mb,
    customerratepool.customer_rate_pool_allocated_mb - customerratepool.customer_rate_pool_usage_mb AS customer_rate_pool_data_remaining,
        CASE
            WHEN COALESCE(customerratepool.customer_rate_pool_allocated_mb, 0::numeric) = 0::numeric THEN 0::numeric
            ELSE (customerratepool.customer_rate_pool_usage_mb * 100::numeric / customerratepool.customer_rate_pool_allocated_mb)::numeric(18,2)
        END AS customer_rate_pool_data_usage_percentage,
    customerratepool.customer_rate_pool_device_count,
    customerratepool.customer_rate_pool_tenant_id,
    sp.id AS service_provider_id,
    sp.display_name AS service_provider_name,
    i.portal_type_id,
    smi.msisdn AS subscriber_number,
        CASE
            WHEN i.id = 12 THEN round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 4)::numeric(25,4)
            ELSE round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 4)::numeric(25,4)
        END AS data_usage_mb,
    COALESCE(smi.customer_data_allocation_mb, COALESCE(cpr.plan_mb, 0.0)) AS data_allocation_mb,
    smi.account_number,
    si.tenant_id,
    si.id AS site_id,
    si.parent_customer_id,
    si.customer_name,
    smi.username,
    cpr.rate_plan_name AS customer_rate_plan_name,
    smi.iccid,
    i.id AS integration_id,
    bp.billing_cycle_end_date AS billing_period_end_date,
    bp.billing_cycle_start_date AS billing_period_start_date
   FROM ( SELECT vw_customer_pool_aggregate_usage.customer_rate_pool_id,
            vw_customer_pool_aggregate_usage.customer_rate_pool_name,
                CASE
                    WHEN vw_customer_pool_aggregate_usage.integration_id = 12 THEN round(vw_customer_pool_aggregate_usage.data_usage_bytes / 1000.0 / 1000.0, 4)::numeric(25,4)
                    ELSE round(vw_customer_pool_aggregate_usage.data_usage_bytes / 1024.0 / 1024.0, 4)::numeric(25,4)
                END AS customer_rate_pool_usage_mb,
            vw_customer_pool_aggregate_usage.customer_data_allocation_mb AS customer_rate_pool_allocated_mb,
            vw_customer_pool_aggregate_usage.num_records AS customer_rate_pool_device_count,
            vw_customer_pool_aggregate_usage.tenant_id AS customer_rate_pool_tenant_id,
            vw_customer_pool_aggregate_usage.service_provider_id
           FROM vw_customer_pool_aggregate_usage) customerratepool
     JOIN sim_management_inventory smi ON smi.customer_pool_id = customerratepool.customer_rate_pool_id
     JOIN serviceprovider sp ON customerratepool.service_provider_id = sp.id AND sp.is_active = true AND sp.is_deleted = false
     JOIN integration i ON i.id = sp.integration_id
     JOIN billing_period bp ON bp.id = smi.billing_period_id
     LEFT JOIN customerrateplan cpr ON smi.customer_rate_plan_id = cpr.id
     LEFT JOIN customers si ON smi.customer_id = si.id AND si.is_active = true AND si.is_deleted = false
  WHERE smi.is_active = true AND smi.is_deleted = false AND cpr.is_active = true AND cpr.is_deleted = false;

CREATE OR REPLACE VIEW public.vw_optimization_customer_charges_count
 AS
 SELECT oq.instance_id,
    sum(
        CASE
            WHEN jcust_rp.id IS NOT NULL THEN 1
            ELSE 0
        END) AS chargecount,
    sum(COALESCE(odr.overage_charge_amt, 0.0) + COALESCE(odr.rate_charge_amt, 0.0)) AS overagechargeamount,
    sum(COALESCE(odr.charge_amt, 0.0)) AS totalchargeamount,
    sum(
        CASE
            WHEN jcust_rp.id IS NULL THEN 1
            ELSE 0
        END) AS unassigneddevicecount,
    sum(COALESCE(odr.sms_charge_amount, 0.0)) AS smschargetotal
   FROM optimization_smi_result odr
     JOIN optimization_queue oq ON odr.queue_id = oq.id
     JOIN optimization_instance oi ON oq.instance_id = oi.id
     JOIN sim_management_inventory smi ON odr.sim_management_inventory_id = smi.id
     LEFT JOIN customerrateplan jcust_rp ON odr.assigned_customer_rate_plan_id = jcust_rp.id
  GROUP BY oq.instance_id;

CREATE OR REPLACE VIEW public.vw_optimization_instance
 AS
 SELECT oi.id,
    oi.billing_period_start_date,
    oi.billing_period_end_date,
    oi.run_status_id,
    os.display_name AS run_status,
    oi.run_start_time,
    oi.run_end_time,
    rc.rev_customer_id,
    TRIM(BOTH FROM rc.customer_name) AS customer_name,
    od.device_count,
    ocg.total_cost,
    ocg.total_base_rate_amt,
    ocg.total_rate_charge_amt,
    ocg.total_overage_charge_amt,
    oirf.id AS results_id,
    odrrpq.rate_plan_queue_count,
    odrccq.customer_charge_queue_count,
    oi.service_provider_id,
    sp.display_name AS service_provider,
    oi.tenant_id,
    oi.row_uuid,
    oi.optimization_session_id,
    oss.session_id,
    ot.name AS optimization_type,
    oi.amop_customer_id,
    TRIM(BOTH FROM s.customer_name) AS amop_customer_name,
    oi.service_provider_ids,
    ( SELECT string_agg(sp_1.display_name::text, ', '::text) AS string_agg
           FROM unnest(string_to_array(oi.service_provider_ids, ','::text)) ids(ids)
             LEFT JOIN serviceprovider sp_1 ON sp_1.id = ids.ids::integer) AS display_names
   FROM optimization_instance oi
     JOIN optimization_status os ON oi.run_status_id = os.id
     LEFT JOIN serviceprovider sp ON sp.id = oi.service_provider_id
     JOIN optimization_session oss ON oss.id = oi.optimization_session_id
     JOIN optimization_type ot ON ot.id = oss.optimization_type_id
     LEFT JOIN ( SELECT ocg_1.instance_id,
            sum(oq.total_cost) AS total_cost,
            sum(oq.total_base_rate_amt) AS total_base_rate_amt,
            sum(oq.total_rate_charge_amt) AS total_rate_charge_amt,
            sum(oq.total_overage_charge_amt) AS total_overage_charge_amt
           FROM optimization_comm_group ocg_1
             JOIN ( SELECT oq2.comm_plan_group_id,
                    oq2.total_cost,
                    oq2.total_base_rate_amt,
                    oq2.total_rate_charge_amt,
                    oq2.total_overage_charge_amt
                   FROM ( SELECT optimization_queue.comm_plan_group_id,
                            optimization_queue.total_cost,
                            optimization_queue.total_base_rate_amt,
                            optimization_queue.total_rate_charge_amt,
                            optimization_queue.total_overage_charge_amt,
                            row_number() OVER (PARTITION BY optimization_queue.comm_plan_group_id ORDER BY optimization_queue.total_cost) AS record_number
                           FROM optimization_queue
                          WHERE optimization_queue.total_cost IS NOT NULL) oq2
                  WHERE oq2.record_number = 1) oq ON ocg_1.id = oq.comm_plan_group_id
          GROUP BY ocg_1.instance_id) ocg ON ocg.instance_id = oi.id
     LEFT JOIN ( SELECT device_count_by_type.instance_id,
            sum(device_count_by_type.device_count) AS device_count
           FROM ( SELECT optimization_smi.instance_id,
                    count(1) AS device_count
                   FROM optimization_smi
                  GROUP BY optimization_smi.instance_id) device_count_by_type
          GROUP BY device_count_by_type.instance_id) od ON oi.id = od.instance_id
     LEFT JOIN ( SELECT optimization_instance_result_file.id,
            optimization_instance_result_file.instance_id,
            row_number() OVER (PARTITION BY optimization_instance_result_file.instance_id ORDER BY optimization_instance_result_file.created_date DESC) AS record_number
           FROM optimization_instance_result_file) oirf ON oi.id = oirf.instance_id AND oirf.record_number = 1
     LEFT JOIN revcustomer rc ON rc.id = oi.rev_customer_id
     LEFT JOIN ( SELECT rate_plan_queue_count_by_type.instance_id,
            sum(rate_plan_queue_count_by_type.rate_plan_queue_count) AS rate_plan_queue_count
           FROM ( SELECT oq.instance_id,
                    count(1) AS rate_plan_queue_count
                   FROM optimization_smi_result_rate_plan_queue osrrpq
                     JOIN optimization_smi_result osr ON osr.id = osrrpq.optimization_smi_result_id
                     JOIN optimization_queue oq ON osr.queue_id = oq.id
                  GROUP BY oq.instance_id) rate_plan_queue_count_by_type
          GROUP BY rate_plan_queue_count_by_type.instance_id) odrrpq ON oi.id = odrrpq.instance_id
     LEFT JOIN ( SELECT customer_charge_queue_count_by_type.instance_id,
            sum(customer_charge_queue_count_by_type.customer_charge_queue_count) AS customer_charge_queue_count
           FROM ( SELECT oq4.instance_id,
                    count(1) AS customer_charge_queue_count
                   FROM optimization_smi_result_customer_charge_queue osrccq2
                     JOIN optimization_smi_result osr2 ON osr2.id = osrccq2.optimization_smi_result_id
                     JOIN optimization_queue oq4 ON osr2.queue_id = oq4.id
                  GROUP BY oq4.instance_id) customer_charge_queue_count_by_type
          GROUP BY customer_charge_queue_count_by_type.instance_id) odrccq ON oi.id = odrccq.instance_id
     LEFT JOIN customers s ON oi.amop_customer_id = s.id
  WHERE oi.is_deleted IS FALSE;


CREATE OR REPLACE VIEW public.vw_optimization_session
 AS
 SELECT os.id,
    os.session_id,
    os.billing_period_start_date,
    os.billing_period_end_date,
    os.tenant_id,
    os.service_provider_id,
    sp.display_name AS serviceprovider,
    os.created_date,
    ot.id AS optimization_type_id,
    ot.name AS optimization_type,
    os.is_active,
    os.is_deleted,
    oi2.device_count,
    oi2.total_cost,
    oi2.total_base_rate_amt,
    oi2.total_rate_charge_amt,
    oi2.total_overage_charge_amt,
    oi2.results_count,
    oi2.instance_count,
    oi2.customer_charge_queue_count,
    oi2.completed_instance_count,
    os.service_provider_ids AS serviceproviderids,
    os.customer_id,
    ( SELECT string_agg(sp_1.display_name::text, ', '::text) AS string_agg
           FROM unnest(string_to_array(os.service_provider_ids, ','::text)) ids(ids)
             LEFT JOIN serviceprovider sp_1 ON sp_1.id = ids.ids::integer) AS displaynames
   FROM optimization_session os
     LEFT JOIN serviceprovider sp ON sp.id = os.service_provider_id
     JOIN optimization_type ot ON ot.id = os.optimization_type_id
     LEFT JOIN ( SELECT oi.optimization_session_id,
            sum(COALESCE(ocg.total_cost, 0::numeric)) AS total_cost,
            sum(ocg.total_base_rate_amt) AS total_base_rate_amt,
            sum(ocg.total_rate_charge_amt) AS total_rate_charge_amt,
            sum(ocg.total_overage_charge_amt) AS total_overage_charge_amt,
            sum(COALESCE(od.device_count, 0::bigint)) AS device_count,
            sum(
                CASE
                    WHEN COALESCE(oirf.id, 0::bigint) > 0 THEN 1
                    ELSE 0
                END) AS results_count,
            count(*) AS instance_count,
            sum(odrccq.customer_charge_queue_count) AS customer_charge_queue_count,
            sum(
                CASE
                    WHEN oi.run_status_id >= 6 THEN 1
                    ELSE 0
                END) AS completed_instance_count
           FROM optimization_instance oi
             LEFT JOIN ( SELECT ocg_1.instance_id,
                    sum(oq.total_cost) AS total_cost,
                    sum(oq.total_base_rate_amt) AS total_base_rate_amt,
                    sum(oq.total_rate_charge_amt) AS total_rate_charge_amt,
                    sum(oq.total_overage_charge_amt) AS total_overage_charge_amt
                   FROM optimization_comm_group ocg_1
                     JOIN ( SELECT oq2.comm_plan_group_id,
                            oq2.total_cost,
                            oq2.total_base_rate_amt,
                            oq2.total_rate_charge_amt,
                            oq2.total_overage_charge_amt
                           FROM ( SELECT optimization_queue.comm_plan_group_id,
                                    optimization_queue.total_cost,
                                    optimization_queue.total_base_rate_amt,
                                    optimization_queue.total_rate_charge_amt,
                                    optimization_queue.total_overage_charge_amt,
                                    row_number() OVER (PARTITION BY optimization_queue.comm_plan_group_id ORDER BY optimization_queue.total_cost) AS record_number
                                   FROM optimization_queue
                                  WHERE optimization_queue.total_cost IS NOT NULL) oq2
                          WHERE oq2.record_number = 1) oq ON ocg_1.id = oq.comm_plan_group_id
                  GROUP BY ocg_1.instance_id) ocg ON ocg.instance_id = oi.id
             LEFT JOIN ( SELECT optimization_smi.instance_id,
                    count(1) AS device_count
                   FROM optimization_smi
                  GROUP BY optimization_smi.instance_id) od ON oi.id = od.instance_id
             LEFT JOIN ( SELECT optimization_instance_result_file.id,
                    optimization_instance_result_file.instance_id,
                    row_number() OVER (PARTITION BY optimization_instance_result_file.instance_id ORDER BY optimization_instance_result_file.created_date DESC) AS record_number
                   FROM optimization_instance_result_file) oirf ON oi.id = oirf.instance_id AND oirf.record_number = 1
             LEFT JOIN ( SELECT customer_charge_queue_count_by_type.instance_id,
                    sum(customer_charge_queue_count_by_type.customer_charge_queue_count) AS customer_charge_queue_count
                   FROM ( SELECT oq4.instance_id,
                            count(1) AS customer_charge_queue_count
                           FROM optimization_smi_result_customer_charge_queue osrccq
                             JOIN optimization_smi_result osr ON osr.id = osrccq.optimization_smi_result_id
                             JOIN optimization_queue oq4 ON osr.queue_id = oq4.id
                          GROUP BY oq4.instance_id) customer_charge_queue_count_by_type
                  GROUP BY customer_charge_queue_count_by_type.instance_id) odrccq ON oi.id = odrccq.instance_id
          GROUP BY oi.optimization_session_id) oi2 ON oi2.optimization_session_id = os.id
  WHERE os.created_date < (CURRENT_TIMESTAMP + '35 days'::interval) OR oi2.instance_count > 0;

CREATE OR REPLACE VIEW public.vw_optimization_session_running
 AS
 SELECT row_number() OVER (ORDER BY (( SELECT NULL::text))) AS id,
    optimization_session.id AS optimization_session_id,
    optimization_instance.run_status_id AS optimization_instance_status_id,
    optimization_queue.run_status_id AS optimization_queue_status_id,
    optimization_session.service_provider_id
   FROM optimization_session
     LEFT JOIN optimization_instance ON optimization_session.id = optimization_instance.optimization_session_id
     LEFT JOIN optimization_queue ON optimization_instance.id = optimization_queue.instance_id
  WHERE optimization_instance.run_status_id <> 6 OR optimization_instance.run_status_id IS NULL
  GROUP BY optimization_session.id, optimization_instance.run_status_id, optimization_queue.run_status_id, optimization_session.service_provider_id;

CREATE OR REPLACE VIEW public.vw_optimization_export_device_assignments
 AS
 SELECT oi.id AS instance_id,
    voi.row_uuid,
    voi.session_id,
    voi.rev_customer_id,
    voi.customer_name,
    voi.device_count,
        CASE
            WHEN voi.device_count > 0::numeric THEN oq.total_cost / voi.device_count
            ELSE 0::numeric
        END AS average_cost,
    voi.billing_period_start_date,
    voi.billing_period_end_date,
    voi.billing_period_end_date - voi.billing_period_start_date AS days_in_billing_period,
    oss.iccid,
    oss.cycle_data_usage_mb,
    oss.communication_plan,
    oss.msisdn,
    oss.sms_usage,
    oss.date_activated,
    oss.was_activated_in_this_billing_period,
    oss.days_activated_in_billing_period,
    oss.carrier_rate_plan_id,
    oss.carrier_rate_plan,
    oss.customer_pool_id,
    oss.customer_pool,
    oss.customer_rate_plan_id,
    oss.customer_rate_plan,
    oq.uses_proration,
    oq.total_cost
   FROM vw_optimization_instance voi
     LEFT JOIN optimization_instance oi ON voi.row_uuid::text = oi.row_uuid::text
     LEFT JOIN ( SELECT os.instance_id,
            os.iccid,
            os.cycle_data_usage_mb,
            os.communication_plan,
            os.msisdn,
            os.sms_usage,
            os.date_activated,
            os.was_activated_in_this_billing_period,
            os.days_activated_in_billing_period,
            smi.carrier_rate_plan_id,
            smi.carrier_rate_plan,
            smi.customer_pool_id,
            smi.customer_pool,
            smi.customer_rate_plan_id,
            smi.customer_rate_plan
           FROM optimization_smi os
             LEFT JOIN sim_management_inventory smi ON smi.id = os.sim_management_inventory_id
          WHERE smi.is_active IS TRUE) oss ON oss.instance_id = oi.id
     LEFT JOIN optimization_queue oq ON oq.instance_id = oi.id;

CREATE OR REPLACE VIEW public.vw_optimization_smi_rate_plan_change_count
 AS
 SELECT oq.instance_id,
    count(1) AS total_device_count,
    sum(
        CASE
            WHEN jd.carrier_rate_plan_id <> COALESCE(odr.assigned_carrier_rate_plan_id, odr.assigned_customer_rate_plan_id) THEN 1
            ELSE 0
        END) AS target_device_count
   FROM optimization_smi_result odr
     JOIN sim_management_inventory jd ON odr.sim_management_inventory_id = jd.id
     JOIN ( SELECT oq_group.id,
            oq_group.instance_id
           FROM ( SELECT optimization_queue.id,
                    optimization_queue.instance_id,
                    row_number() OVER (PARTITION BY optimization_queue.comm_plan_group_id ORDER BY optimization_queue.total_cost) AS record_number
                   FROM optimization_queue
                  WHERE optimization_queue.total_cost IS NOT NULL AND optimization_queue.run_end_time IS NOT NULL) oq_group
          WHERE oq_group.record_number = 1) oq ON odr.queue_id = oq.id
  GROUP BY oq.instance_id;

CREATE OR REPLACE VIEW public.vw_optimization_instance_summary
 AS
 SELECT voi.id,
    voi.billing_period_start_date,
    voi.billing_period_end_date,
    voi.run_status_id,
    voi.run_status,
    voi.run_start_time,
    voi.run_end_time,
    voi.rev_customer_id,
    voi.customer_name,
    voi.device_count,
    voi.total_cost,
    voi.total_base_rate_amt,
    voi.total_rate_charge_amt,
    voi.total_overage_charge_amt,
    voi.results_id,
    voi.rate_plan_queue_count,
    voi.customer_charge_queue_count,
    voi.service_provider_id,
    voi.service_provider,
    voi.tenant_id,
    voi.row_uuid,
    voi.optimization_session_id,
    voi.session_id,
    voi.optimization_type,
    voi.amop_customer_id,
    voi.amop_customer_name,
    voi.service_provider_ids,
    voi.display_names,
        CASE
            WHEN vos.results_count > 0 AND vos.completed_instance_count = vos.instance_count THEN true
            ELSE false
        END AS download,
        CASE
            WHEN vos.total_cost > 0::numeric AND vos.customer_charge_queue_count >= vos.device_count THEN true
            ELSE false
        END AS info,
        CASE
            WHEN vos.total_cost > 0::numeric AND vos.customer_charge_queue_count <= vos.instance_count::numeric THEN true
            ELSE false
        END AS upload,
    oi.id AS instance_id,
    osrpcc.total_device_count,
    osrpcc.target_device_count,
    voccc.chargecount AS charge_count,
    voccc.overagechargeamount AS overage_charge_amount,
    voccc.totalchargeamount AS total_charge_amount,
    voccc.unassigneddevicecount AS unassigned_device_count,
    voccc.smschargetotal AS sms_charge_total,
    uocccfco.chargecount AS cross_opt_charge_count,
    uocccfco.overagechargeamount AS cross_opt_overage_charge_amt,
    uocccfco.totalchargeamount AS cross_opt_total_charge_amt,
    uocccfco.unassigneddevicecount AS cross_opt_unassigned_device_count,
    uocccfco.smschargetotal AS cross_opt_sms_charge_total
   FROM vw_optimization_instance voi
     LEFT JOIN vw_optimization_session vos ON voi.session_id = vos.session_id
     LEFT JOIN optimization_instance oi ON oi.row_uuid::text = voi.row_uuid::text
     LEFT JOIN vw_optimization_smi_rate_plan_change_count osrpcc ON osrpcc.instance_id = oi.id
     LEFT JOIN vw_optimization_customer_charges_count voccc ON voccc.instance_id = oi.id
     LEFT JOIN usp_optimization_customer_charges_count_for_cross_optimization uocccfco ON uocccfco.instance_id = oi.id;

CREATE OR REPLACE VIEW public.vw_optimization_smi_result_customer_charge_queue_summary
 AS
 SELECT odr_queue.queue_id,
    odr_queue.device_count,
    odr_queue.processed_count,
    COALESCE(odr_queue.charge_amount, 0.0) AS charge_amount,
    COALESCE(odr_queue.base_charge_amount, 0.0) AS base_charge_amount,
    COALESCE(odr_queue.total_data_charge_amount, 0.0) AS total_data_charge_amount,
    COALESCE(odr_queue.rate_charge_amt, 0.0) AS rate_charge_amt,
    odr_queue.display_rate,
    oi.billing_period_start_date,
    oi.billing_period_end_date,
    rc.rev_customer_id AS rev_account_number,
    rc.customer_name,
    oi.optimization_session_id,
    NULL::integer AS amop_customer_id,
    NULL::character varying AS amop_customer_name,
        CASE
            WHEN odr_queue.error_count > 0 THEN 'Processed With Errors'::text
            WHEN odr_queue.processed_count = odr_queue.device_count THEN 'Processed'::text
            WHEN odr_queue.processed_count = 0 THEN 'Not Started'::text
            ELSE 'Pending'::text
        END AS charge_status,
    oi.tenant_id,
    odr_queue.sms_charge_amount,
    COALESCE(odr_queue.total_data_charge_amount, 0.0) + COALESCE(odr_queue.sms_charge_amount, 0.0) AS totalchargeamount,
    COALESCE(odr_queue.rate_charge_amount, 0.0) AS rate_charge_amount,
    COALESCE(odr_queue.overage_charge_amount, 0.0) AS overage_charge_amount
   FROM ( SELECT odr.queue_id,
            count(1) AS device_count,
            sum(
                CASE
                    WHEN odr_ccq.is_processed::integer = 1 THEN 1
                    ELSE 0
                END) AS processed_count,
            sum(odr_ccq.charge_amount) AS charge_amount,
            sum(odr_ccq.base_charge_amount) AS base_charge_amount,
            sum(odr_ccq.total_charge_amount) AS total_data_charge_amount,
            sum(jcust_rp.rate_charge_amt::numeric) AS rate_charge_amt,
            sum(jcust_rp.display_rate::numeric) AS display_rate,
            sum(odr_ccq.sms_charge_amount) AS sms_charge_amount,
            sum(
                CASE
                    WHEN odr_ccq.has_errors::integer = 1 THEN 1
                    ELSE 0
                END) AS error_count,
            sum(odr_ccq.rate_charge_amt) AS rate_charge_amount,
            sum(odr_ccq.overage_charge_amt) AS overage_charge_amount
           FROM optimization_smi_result_customer_charge_queue odr_ccq
             JOIN optimization_smi_result odr ON odr_ccq.optimization_smi_result_id = odr.id
             LEFT JOIN customerrateplan jcust_rp ON odr.assigned_customer_rate_plan_id = jcust_rp.id
          GROUP BY odr.queue_id) odr_queue
     JOIN optimization_queue oq ON odr_queue.queue_id = oq.id
     JOIN optimization_instance oi ON oq.instance_id = oi.id
     JOIN revcustomer rc ON oi.rev_customer_id = rc.id;

CREATE VIEW vw_Optimization_smi_Result_Customer_Charge_Queue
AS
SELECT customer_charge_queue.id,
       optimization_smi_result.queue_id,
       customer_charge_queue.uploaded_file_id,
       optimization_smi_result.usage_mb,
       optimization_smi_result.assigned_customer_rate_plan_id,
       customerrateplan.rate_plan_code AS rate_plan_code,
       customerrateplan.base_rate,
       customerrateplan.Surcharge_3g,
       customerrateplan.plan_mb,
       is_processed,
       charge_id,
       charge_amount,
       base_charge_amount,
       total_charge_amount,
       customer_charge_queue.created_date,
       customer_charge_queue.created_by,
       customer_charge_queue.modified_date,
       customer_charge_queue.modified_by,
       customerrateplan.rate_plan_name,
       customerrateplan.overage_rate_cost AS overage_rate_cost_per_mb,
       customerrateplan.rate_charge_amt,
       customerrateplan.display_rate,
       optimization_instance.billing_period_start_date,
       optimization_instance.billing_period_end_date,
       revcustomer.rev_customer_id AS rev_account_number,
       revcustomer.customer_name,
       customerrateplan.data_per_overage_charge,
       customerrateplan.overage_rate_cost,
       customer_charge_queue.has_errors,
       customer_charge_queue.error_message,
       sim_management_inventory.iccid,
       sim_management_inventory.msisdn,
       customer_charge_queue.rev_product_type_id,
       customer_charge_queue.rev_service_number,
       customer_charge_queue.billing_start_date,
       customer_charge_queue.billing_end_date,
       customer_charge_queue.description,
       NULL AS cost_center,
       customer_charge_queue.integration_authentication_id,
       integration_authentication.tenant_id,
       customer_charge_queue.sms_rev_product_type_id,
       customer_charge_queue.sms_charge_amount,
       customer_charge_queue.sms_charge_id,
       customerrateplan.sms_rate,
       optimization_smi_result.sms_usage,
       optimization_queue.is_bill_in_advance,
       optimization_instance.optimization_session_id,
       optimization_session.created_date AS session_created_date,
       CAST(NULL AS INT) AS amop_customer_id,
       CAST(NULL AS VARCHAR) AS amop_customer_name,
       customer_charge_queue.rate_charge_amt AS rate_charge_amount,
       customer_charge_queue.overage_charge_amt AS overage_charge_amount,
       customer_charge_queue.base_rate_amt AS base_rate_amount,
       customer_charge_queue.overage_rev_product_type_id,
       sim_management_inventory.service_provider_id,
       customer_charge_queue.rev_product_id,
       customer_charge_queue.sms_rev_product_id,
       customer_charge_queue.overage_rev_product_id,
       optimization_instance.id AS optimization_instance_id
FROM optimization_smi_result_customer_charge_queue customer_charge_queue
         INNER JOIN  optimization_smi_result ON customer_charge_queue.optimization_smi_result_id = optimization_smi_result.id
         INNER JOIN sim_management_inventory ON optimization_smi_result.sim_management_inventory_id = sim_management_inventory.id
         LEFT JOIN customerrateplan ON optimization_smi_result.assigned_customer_rate_plan_id = customerrateplan.id
         INNER JOIN optimization_queue ON optimization_smi_result.queue_id = optimization_queue.id
         INNER JOIN optimization_instance ON optimization_queue.instance_id = optimization_instance.id
         INNER JOIN revcustomer ON optimization_instance.rev_customer_id = revcustomer.id
         INNER JOIN optimization_session ON optimization_session.id = optimization_instance.optimization_session_id
         INNER JOIN integration_authentication ON (customer_charge_queue.integration_authentication_id = integration_authentication.id OR revcustomer.integration_authentication_id = integration_authentication.id);

CREATE OR REPLACE VIEW public.vw_people_revio_customer_list_view
 AS
 SELECT c.id,
    c.tenant_name AS partner,
    ra.agent_name AS agent,
    rc.customer_name AS name,
    rc.rev_customer_id AS account,
    c.customer_bill_period_end_day,
    c.customer_bill_period_end_hour
   FROM revcustomer rc
     LEFT JOIN revagent ra ON ra.rev_agent_id = rc.agent_id
     LEFT JOIN customers c ON c.rev_customer_id = rc.id;

CREATE OR REPLACE VIEW public.vw_automation_rule_log_list_view
 AS
 SELECT autorule.automation_rule_name,
    autorule.service_provider_id,
    serviceprovider.display_name AS service_provider_display_name,
    rulelog.id,
    rulelog.status,
    rulelog.device_updated AS sim,
    td.subscriber_number,
    rulelog.description,
    rulelog.request_body,
    rulelog.response_body,
    rulelog.instance_id,
    rulelog.created_date,
    rulelog.created_by
   FROM automation_rule autorule
     JOIN automation_rule_log rulelog ON autorule.id = rulelog.automation_rule_id
     JOIN serviceprovider serviceprovider ON serviceprovider.id = autorule.service_provider_id
     JOIN telegence_device td ON td.iccid::text = rulelog.device_updated;

CREATE OR REPLACE VIEW public.vw_device_high_usage_scatter_chart
 AS
 SELECT smi.id,
    smi.tenant_id,
        CASE
            WHEN i.id = 12 THEN round(smi.carrier_cycle_usage::numeric / 1000.0 / 1000.0, 3)
            ELSE round(smi.carrier_cycle_usage::numeric / 1024.0 / 1024.0, 3)
        END AS ctd_data_usage_mb,
    smi.ctd_session_count,
    smi.account_number,
    smi.iccid,
    smi.msisdn,
    smi.service_provider_id,
    sp.service_provider_name,
    c.tenant_id AS customer_tenant_id,
    i.portal_type_id,
    c.id AS customer_id,
    c.parent_customer_id,
    c.customer_name
   FROM sim_management_inventory smi
     LEFT JOIN serviceprovider sp ON sp.id = smi.service_provider_id
     LEFT JOIN customers c ON smi.customer_id = c.id
     LEFT JOIN integration i ON i.id = sp.integration_id
  WHERE (smi.sim_status::text = 'activated'::text OR smi.sim_status::text = 'active'::text OR smi.sim_status::text = 'a'::text) AND smi.carrier_cycle_usage > 0 AND smi.is_active = true AND smi.is_deleted = false;


CREATE OR REPLACE VIEW public.vw_device_status_trend_by_month
 AS
 SELECT COALESCE(gen_random_uuid(), '00000000-0000-0000-0000-000000000000'::uuid) AS id,
    jdsa.activated_count,
    jdsa.activation_ready_count,
    jdsa.deactivated_count,
    jdsa.inventory_count,
    jdsa.retired_count,
    jdsa.test_ready_count,
    to_char(jdsa.created_date, 'YYYY-MM-DD'::text) AS created_date,
    jdsa.bill_year,
    jdsa.bill_month,
    jdsa.service_provider_id,
    sp.service_provider_name AS service_provider,
    "int".portal_type_id
   FROM jasper_device_sync_audit jdsa
     JOIN serviceprovider sp ON jdsa.service_provider_id = sp.id
     JOIN ( SELECT jasper_device_sync_audit.bill_year,
            jasper_device_sync_audit.bill_month,
            jasper_device_sync_audit.service_provider_id,
            max(jasper_device_sync_audit.id) AS id
           FROM jasper_device_sync_audit
          GROUP BY jasper_device_sync_audit.bill_year, jasper_device_sync_audit.bill_month, jasper_device_sync_audit.service_provider_id) jdsa_month ON jdsa.id = jdsa_month.id AND jdsa_month.service_provider_id = sp.id
     LEFT JOIN integration "int" ON "int".id = sp.integration_id
UNION
 SELECT COALESCE(gen_random_uuid(), '00000000-0000-0000-0000-000000000000'::uuid) AS id,
    COALESCE(jdsa.active_count, 0) + COALESCE(jdsa.pending_mdn_change_count, 0) + COALESCE(jdsa.pending_prl_update_count, 0) + COALESCE(jdsa.pending_service_plan_change_count, 0) + COALESCE(jdsa.pending_account_update_count, 0) AS activated_count,
    COALESCE(jdsa.pending_resume_count, 0) + COALESCE(jdsa.pending_preactive_count, 0) + COALESCE(jdsa.pending_activation_count, 0) AS activation_ready_count,
    COALESCE(jdsa.deactive_count, 0) + COALESCE(jdsa.suspend_count, 0) + COALESCE(jdsa.pending_deactivation_count, 0) + COALESCE(jdsa.pending_suspend_count, 0) AS deactivated_count,
    0 AS inventory_count,
    0 AS retired_count,
    COALESCE(jdsa.pre_active_count, 0) AS test_ready_count,
    to_char(jdsa.created_date, 'YYYY-MM-DD'::text) AS created_date,
    jdsa.bill_year,
    jdsa.bill_month,
    jdsa.service_provider_id,
    sp.service_provider_name AS service_provider,
    "int".portal_type_id
   FROM thing_space_device_sync_audit jdsa
     JOIN serviceprovider sp ON sp.id = jdsa.service_provider_id
     JOIN ( SELECT thing_space_device_sync_audit.bill_year,
            thing_space_device_sync_audit.bill_month,
            max(thing_space_device_sync_audit.id) AS id
           FROM thing_space_device_sync_audit
          GROUP BY thing_space_device_sync_audit.bill_year, thing_space_device_sync_audit.bill_month) jdsa_month ON jdsa.id = jdsa_month.id
     LEFT JOIN integration "int" ON "int".id = sp.integration_id
UNION
 SELECT COALESCE(gen_random_uuid(), '00000000-0000-0000-0000-000000000000'::uuid) AS id,
    COALESCE(jdsa.active_count, 0) AS activated_count,
    0 AS activation_ready_count,
    COALESCE(jdsa.suspend_count, 0) AS deactivated_count,
    0 AS inventory_count,
    0 AS retired_count,
    0 AS test_ready_count,
    to_char(jdsa.created_date, 'YYYY-MM-DD'::text) AS created_date,
    jdsa.bill_year,
    jdsa.bill_month,
    jdsa.service_provider_id,
    sp.service_provider_name AS service_provider,
    "int".portal_type_id
   FROM telegence_device_sync_audit jdsa
     JOIN serviceprovider sp ON sp.id = jdsa.service_provider_id
     JOIN ( SELECT telegence_device_sync_audit.bill_year,
            telegence_device_sync_audit.bill_month,
            max(telegence_device_sync_audit.id) AS id
           FROM telegence_device_sync_audit
          GROUP BY telegence_device_sync_audit.bill_year, telegence_device_sync_audit.bill_month) jdsa_month ON jdsa.id = jdsa_month.id
     LEFT JOIN integration "int" ON "int".id = sp.integration_id
UNION
 SELECT COALESCE(gen_random_uuid(), '00000000-0000-0000-0000-000000000000'::uuid) AS id,
    COALESCE(jdsa.active_count, 0) AS activated_count,
    0 AS activation_ready_count,
    COALESCE(jdsa.suspend_count, 0) AS deactivated_count,
    0 AS inventory_count,
    0 AS retired_count,
    0 AS test_ready_count,
    to_char(jdsa.created_date, 'YYYY-MM-DD'::text) AS created_date,
    jdsa.bill_year,
    jdsa.bill_month,
    jdsa.service_provider_id,
    sp.service_provider_name AS service_provider,
    "int".portal_type_id
   FROM e_bonding_device_sync_audit jdsa
     JOIN serviceprovider sp ON sp.id = jdsa.service_provider_id
     JOIN ( SELECT e_bonding_device_sync_audit.bill_year,
            e_bonding_device_sync_audit.bill_month,
            max(e_bonding_device_sync_audit.id) AS id
           FROM e_bonding_device_sync_audit
          GROUP BY e_bonding_device_sync_audit.bill_year, e_bonding_device_sync_audit.bill_month) jdsa_month ON jdsa.id = jdsa_month.id
     LEFT JOIN integration "int" ON "int".id = sp.integration_id;


CREATE OR REPLACE VIEW public.vw_device_usage_trend_by_month
 AS
 SELECT service_provider_id,
    service_provider,
    COALESCE(row_number() OVER (ORDER BY bill_year, bill_month, account_number), 0::bigint) AS id,
    bill_year,
    bill_month,
    account_number,
    sum(carrier_cycle_usage) AS total_usage_bytes,
    sum(carrier_cycle_usage_mb) AS total_usage_mb,
    count(1) AS total_cards,
    avg(carrier_cycle_usage) AS avg_usage_per_card_bytes,
    avg(carrier_cycle_usage_mb) AS avg_usage_per_card_mb,
    tenant_id,
    portal_type_id,
    customer_id,
    parent_customer_id,
    customer_name
   FROM ( SELECT smi.service_provider_id,
            sp.service_provider_name AS service_provider,
            jduh.bill_year,
            jduh.bill_month,
            COALESCE(jduh.carrier_cycle_usage::numeric, 0.0) AS carrier_cycle_usage,
                CASE
                    WHEN i.id = 12 THEN COALESCE(jduh.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0
                    ELSE COALESCE(jduh.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0
                END AS carrier_cycle_usage_mb,
            smi.account_number,
            c.tenant_id,
            i.portal_type_id,
            c.id AS customer_id,
            c.parent_customer_id,
            c.customer_name
           FROM sim_management_inventory smi
             JOIN serviceprovider sp ON sp.id = smi.service_provider_id
             JOIN device_status ds ON smi.device_status_id = ds.id
             LEFT JOIN customers c ON smi.customer_id = c.id
             LEFT JOIN ( SELECT dh.smi_id,
                    bp.bill_year,
                    bp.bill_month,
                    dh.iccid,
                    dh.carrier_cycle_usage,
                    dh.msisdn,
                    dh.status,
                    dh.created_date,
                    COALESCE(sp_1.bill_period_end_day::character varying(2), '18'::character varying) AS billing_period_end_day,
                    COALESCE(sp_1.bill_period_end_hour::character varying(2), '18'::character varying) AS billing_period_end_hour,
                    dh.customer_id
                   FROM sim_management_inventory_history dh
                     JOIN device_status st ON st.id = dh.device_status_id
                     JOIN serviceprovider sp_1 ON sp_1.id = dh.service_provider_id
                     JOIN billing_period bp ON bp.id = dh.billing_period_id
                  WHERE st.is_active_status = true OR dh.carrier_cycle_usage > 0 AND dh.status::text <> 'TEST READY'::text) jduh ON smi.id = jduh.smi_id AND smi.customer_id = jduh.customer_id
             LEFT JOIN integration i ON i.id = sp.integration_id
          WHERE smi.is_active = true AND smi.is_deleted = false AND (ds.is_active_status = true OR smi.last_activated_date IS NOT NULL AND smi.last_activated_date > (to_timestamp(((((((jduh.bill_year || '-'::text) || lpad(jduh.bill_month::text, 2, '0'::text)) || '-'::text) || lpad(jduh.billing_period_end_day::text, 2, '0'::text)) || ' '::text) || lpad(jduh.billing_period_end_hour::text, 2, '0'::text)) || ':00'::text, 'YYYY-MM-DD HH24:MI'::text) - '1 mon'::interval))) du_month
  GROUP BY service_provider_id, service_provider, bill_year, bill_month, account_number, tenant_id, portal_type_id, customer_id, parent_customer_id, customer_name;

CREATE OR REPLACE VIEW public.vw_mobility_device_high_usage_scatter_charts
 AS
 SELECT s.mobility_device_id,
        CASE
            WHEN i.id = 12 THEN round(s.carrier_cycle_usage::numeric / 1000.0 / 1000.0, 3)
            ELSE round(s.carrier_cycle_usage::numeric / 1024.0 / 1024.0, 3)
        END AS ctd_data_usage_mb,
    s.ctd_session_count,
    s.account_number,
    s.iccid,
    s.msisdn,
    s.service_provider_id,
    sp.service_provider_name,
    c.tenant_id,
    i.portal_type_id,
    s.plan_limit_mb,
    c.id,
    c.parent_customer_id,
    c.customer_name
   FROM sim_management_inventory s
     JOIN serviceprovider sp ON sp.id = s.service_provider_id
     JOIN device_status dst ON s.device_status_id = dst.id
     LEFT JOIN customers c ON s.customer_id = c.id
     LEFT JOIN integration i ON i.id = sp.integration_id
  WHERE dst.is_active_status = true AND s.carrier_cycle_usage > 0 AND s.is_active = true AND s.is_deleted = false;

CREATE OR REPLACE VIEW public.vw_mobility_usage_by_customer_pools
 AS
 SELECT gen_random_uuid() AS id,
    customer_rate_pool.customer_rate_pool_id,
    customer_rate_pool.customer_rate_pool_name,
    customer_rate_pool.customer_rate_pool_usage_mb,
    customer_rate_pool.customer_rate_pool_allocated_mb,
    customer_rate_pool.customer_rate_pool_allocated_mb - customer_rate_pool.customer_rate_pool_usage_mb AS customer_rate_pool_data_remaining,
        CASE
            WHEN COALESCE(customer_rate_pool.customer_rate_pool_allocated_mb, 0::numeric) = 0::numeric THEN 0::numeric
            ELSE (customer_rate_pool.customer_rate_pool_usage_mb * 100.0 / customer_rate_pool.customer_rate_pool_allocated_mb)::numeric(18,2)
        END AS customer_rate_pool_data_usage_percenatge,
    customer_rate_pool.customer_rate_pool_device_count,
    customer_rate_pool.customer_rate_pool_tenant_id,
    sp.id AS service_provider_id,
    sp.display_name AS service_provider_name,
    i.portal_type_id,
    smi.msisdn AS subscriber_name,
        CASE
            WHEN i.id = 12 THEN round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 4)::numeric(25,4)
            ELSE round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 4)::numeric(25,4)
        END AS data_usage_mb,
    COALESCE(smi.customer_data_allocation_mb, crp.plan_mb, 0.0) AS data_allocation_mb,
    smi.account_number,
    c.tenant_id,
    c.id AS customer_id,
    c.parent_customer_id,
    c.customer_name,
    smi.username,
    crp.rate_plan_name AS customer_rate_plan_name,
    crp.overage_rate_cost::numeric as overage_rate_cost,
    crp.data_per_overage_charge,
    smi.iccid,
    sp.integration_id,
    bp.billing_cycle_end_date AS billing_period_end_date,
    bp.billing_cycle_start_date AS billing_period_start_date
   FROM ( SELECT vw_customer_pool_aggregate_usage.customer_rate_pool_id,
            vw_customer_pool_aggregate_usage.customer_rate_pool_name,
                CASE
                    WHEN vw_customer_pool_aggregate_usage.integration_id = 12 THEN round(vw_customer_pool_aggregate_usage.data_usage_bytes / 1000.0 / 1000.0, 4)::numeric(25,4)
                    ELSE round(vw_customer_pool_aggregate_usage.data_usage_bytes / 1024.0 / 1024.0, 4)::numeric(25,4)
                END AS customer_rate_pool_usage_mb,
            vw_customer_pool_aggregate_usage.customer_data_allocation_mb AS customer_rate_pool_allocated_mb,
            vw_customer_pool_aggregate_usage.num_records AS customer_rate_pool_device_count,
            vw_customer_pool_aggregate_usage.tenant_id AS customer_rate_pool_tenant_id,
            vw_customer_pool_aggregate_usage.service_provider_id
           FROM vw_customer_pool_aggregate_usage) customer_rate_pool
     JOIN sim_management_inventory smi ON smi.customer_pool_id = customer_rate_pool.customer_rate_pool_id
     JOIN serviceprovider sp ON customer_rate_pool.service_provider_id = sp.id AND sp.is_active = true AND sp.is_deleted = false
     JOIN integration i ON i.id = sp.integration_id
     JOIN billing_period bp ON bp.id = smi.billing_period_id
     LEFT JOIN customerrateplan crp ON smi.customer_rate_plan_id = crp.id
     LEFT JOIN customers c ON smi.customer_id = c.id AND c.is_active = true AND c.is_deleted = false
     LEFT JOIN revcustomer rc ON c.rev_customer_id = rc.id AND rc.is_active = true AND rc.is_deleted = false
  WHERE smi.is_active = true AND smi.is_deleted = false AND crp.is_active = true AND crp.is_deleted = false;

CREATE OR REPLACE VIEW public.vw_mobility_usage_by_group_pools
 AS
 SELECT DISTINCT ua.id,
    ua.foundation_account_number,
    ua.billing_account_number,
    ua.data_group_id,
    ua.pool_id,
    ua.data_usage,
    ua.data_total AS plan_limit_bytes,
        CASE
            WHEN COALESCE(ua.data_total, 0::bigint) = 0 THEN NULL::bigint
            ELSE ua.data_total - COALESCE(ua.data_usage, 0::bigint)
        END AS data_remaining,
        CASE
            WHEN COALESCE(ua.data_total, 0::bigint) = 0 THEN NULL::numeric
            ELSE COALESCE(ua.data_usage, 0::bigint)::numeric * 100.0 / ua.data_total::numeric
        END AS data_usage_percentage,
        CASE
            WHEN COALESCE(ua.data_total, 0::bigint) = 0 THEN NULL::numeric
            ELSE (ua.data_total - COALESCE(ua.data_usage, 0::bigint))::numeric * 100.0 / ua.data_total::numeric
        END AS data_remaining_percentage,
    ua.service_provider_id,
    sp.display_name,
    i.portal_type_id,
    s.account_number,
    c.tenant_id,
    c.id AS customer_id,
    c.parent_customer_id,
    c.customer_name,
        CASE
            WHEN COALESCE(ua.pool_id, ''::character varying)::text <> ''::text THEN ( SELECT count(1) AS count
               FROM sim_management_inventory s_1
              WHERE s_1.is_deleted = false AND s_1.pool_id::character varying::text = ua.pool_id::text)
            ELSE 0::bigint
        END AS pool_device_count,
        CASE
            WHEN COALESCE(ua.data_group_id, ''::character varying)::text <> ''::text THEN ( SELECT count(1) AS count
               FROM sim_management_inventory s_1
              WHERE s_1.is_deleted = false AND s_1.data_group_id::text = ua.data_group_id::text)
            ELSE 0::bigint
        END AS data_group_device_count
   FROM mobility_device_usage_aggregate ua
     JOIN serviceprovider sp ON ua.service_provider_id = sp.id
     JOIN integration i ON i.id = sp.integration_id
     LEFT JOIN telegence_device td ON ua.id = td.usage_aggregate_id
     LEFT JOIN e_bonding_device ebd ON ua.id = ebd.usage_aggregate_id
     LEFT JOIN sim_management_inventory s ON td.subscriber_number::text = s.msisdn::text OR ebd.subscriber_number::text = s.msisdn::text
     LEFT JOIN customers c ON s.customer_id = c.id
     LEFT JOIN revcustomer r ON c.rev_customer_id = r.id
  WHERE (COALESCE(ua.data_group_id, ''::character varying)::text <> ''::text OR COALESCE(ua.pool_id, ''::character varying)::text <> ''::text) AND (s.is_active IS NULL OR s.is_active = true) AND (s.is_deleted IS NULL OR s.is_deleted = false);

CREATE OR REPLACE VIEW public.vw_newly_activated_report
 AS
 SELECT iccid,
    msisdn,
    billing_account_number,
    carrier_rate_plan,
    date_activated,
    communication_plan,
    account_number,
    customer_name,
    ip_address,
    service_provider
   FROM sim_management_inventory
  WHERE is_active = true AND date_activated < (now() - '30 days'::interval);

CREATE OR REPLACE VIEW public.vw_pool_group_summary_report
 AS
 SELECT du.foundation_account_number,
    du.billing_account_number,
    du.data_group_id,
    du.pool_id,
    du.data_usage,
    du.data_total AS plan_limit_bytes,
        CASE
            WHEN COALESCE(du.data_total, 0::bigint) = 0 THEN NULL::bigint
            ELSE du.data_total - COALESCE(du.data_usage, 0::bigint)
        END AS data_remaining,
        CASE
            WHEN COALESCE(du.data_total, 0::bigint) = 0 THEN NULL::numeric
            ELSE round(COALESCE(du.data_usage, 0::bigint)::numeric * 100.0 / du.data_total::numeric, 2)
        END AS data_usage_percentage,
        CASE
            WHEN COALESCE(du.data_total, 0::bigint) = 0 THEN NULL::numeric
            ELSE round((du.data_total - COALESCE(du.data_usage, 0::bigint))::numeric * 100.0 / du.data_total::numeric, 2)
        END AS data_remaining_percentage,
    sp.display_name AS service_provider_name,
        CASE
            WHEN COALESCE(du.pool_id, ''::character varying)::text <> ''::text THEN ( SELECT count(1) AS count
               FROM sim_management_inventory m
              WHERE m.is_deleted = false AND m.pool_id::character varying::text = du.pool_id::text)
            ELSE 0::bigint
        END AS pool_device_count,
        CASE
            WHEN COALESCE(du.data_group_id, ''::character varying)::text <> ''::text THEN ( SELECT count(1) AS count
               FROM sim_management_inventory m
              WHERE m.is_deleted = false AND m.data_group_id::character varying::text = du.data_group_id::text)
            ELSE 0::bigint
        END AS data_group_device_count
   FROM mobility_device_usage_aggregate du
     JOIN serviceprovider sp ON du.service_provider_id = sp.id
     JOIN integration i ON sp.integration_id = i.id
  WHERE COALESCE(du.data_group_id, ''::character varying)::text <> ''::text OR COALESCE(du.pool_id, ''::character varying)::text <> ''::text;


CREATE OR REPLACE VIEW public.vw_smi_sim_cards_by_carrier_rate_plan_limit_report
 AS
 SELECT COALESCE(gen_random_uuid(), gen_random_uuid()) AS unique_id,
    smi.service_provider_id,
    sp.service_provider_name,
    smi.account_number,
    count(1) AS sim_count,
    sum(COALESCE(smi.carrier_cycle_usage, 0::bigint)) AS carrier_cycle_usage,
    sum(COALESCE(smi.ctd_session_count, 0::bigint)) AS ctd_session_count,
    c.tenant_id,
    i.portal_type_id,
    crp.plan_mb,
    c.id,
    c.parent_customer_id,
    c.customer_name
   FROM sim_management_inventory smi
     JOIN serviceprovider sp ON smi.service_provider_id = sp.id
     JOIN device_status ds ON smi.device_status_id = ds.id
     LEFT JOIN carrier_rate_plan crp ON crp.id = smi.carrier_rate_plan_id
     LEFT JOIN customers c ON smi.customer_id = c.id
     LEFT JOIN integration i ON i.id = sp.integration_id
  WHERE smi.is_active = true AND smi.is_deleted = false AND ds.is_active_status = true
  GROUP BY smi.service_provider_id, sp.service_provider_name, smi.account_number, c.tenant_id, i.portal_type_id, crp.plan_mb, c.id, c.parent_customer_id, c.customer_name;


CREATE OR REPLACE VIEW public.vw_smi_sim_cards_by_customer_rate_plan_limit_report
 AS
 SELECT COALESCE(gen_random_uuid(), gen_random_uuid()) AS unique_id,
    smi.service_provider_id,
    sp.service_provider_name,
    smi.account_number,
    count(1) AS sim_count,
    sum(COALESCE(smi.carrier_cycle_usage, 0::bigint)) AS carrier_cycle_usage,
    sum(COALESCE(smi.ctd_session_count, 0::bigint)) AS ctd_session_count,
    c.tenant_id,
    i.portal_type_id,
    crp.plan_mb,
    c.id,
    c.parent_customer_id,
    c.customer_name
   FROM sim_management_inventory smi
     JOIN device_status ds ON smi.device_status_id = ds.id
     JOIN serviceprovider sp ON smi.service_provider_id = sp.id
     LEFT JOIN customerrateplan crp ON crp.id = smi.customer_rate_plan_id
     LEFT JOIN customers c ON smi.customer_id = c.id
     LEFT JOIN integration i ON i.id = sp.integration_id
  WHERE smi.is_active = true AND smi.is_deleted = false AND ds.is_active_status = true
  GROUP BY smi.service_provider_id, sp.service_provider_name, smi.account_number, c.tenant_id, i.portal_type_id, crp.plan_mb, c.id, c.parent_customer_id, c.customer_name;

CREATE OR REPLACE VIEW public.vw_status_history_report
 AS
 SELECT dsh.id,
    dsh.iccid,
    dsh.msisdn,
    COALESCE(dsh.previous_status, ( SELECT previous_record.previous_status
           FROM device_status_history previous_record
          WHERE previous_record.sim_management_inventory_id = dsh.sim_management_inventory_id AND (dsh.tenant_id IS NULL OR previous_record.tenant_id = dsh.tenant_id) AND previous_record.date_of_change < dsh.date_of_change
          ORDER BY previous_record.date_of_change DESC
         LIMIT 1)) AS previous_status,
    dsh.current_status,
    dsh.change_event_type,
    dsh.changed_by,
    dsh.is_deleted,
    dsh.service_provider_id,
    dsh.sim_management_inventory_id,
    dsh.bulk_change_id,
    dsh.customer_name,
    dsh.customer_account_number,
    dsh.username,
    dsh.customer_rate_plan,
    dsh.customer_rate_pool,
    COALESCE(dsh.tenant_id, smi.tenant_id) AS tenant_id,
    sp.display_name AS serviceprovidername,
    smi.customer_id,
    smi.account_number
   FROM device_status_history dsh
     JOIN sim_management_inventory smi ON dsh.iccid::text = smi.iccid::text
     JOIN serviceprovider sp ON smi.service_provider_id = sp.id;

CREATE OR REPLACE VIEW public.vw_usage_by_line_report
 AS
 SELECT sm.service_provider,
    bp.billing_cycle_end_date,
    sm.iccid,
    sm.msisdn,
    sm.foundation_account_number,
    sm.billing_account_number,
    sm.customer_pool,
    sm.customer_name,
    sm.username,
    sm.carrier_rate_plan,
    sm.customer_rate_plan,
    sp.integration_id,
        CASE
            WHEN sp.integration_id = 12 THEN round(COALESCE(sm.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(sm.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS datausagemb,
    sm.carrier_cycle_usage,
    sm.sim_status,
    sm.date_activated
   FROM sim_management_inventory sm
     JOIN serviceprovider sp ON sm.id = sp.id
     LEFT JOIN billing_period bp ON sm.id = bp.id;

CREATE OR REPLACE VIEW public.vw_zero_usage_report
 AS
 SELECT iccid,
    msisdn,
    carrier_rate_plan,
    sim_status,
    communication_plan,
    account_number,
    customer_name,
    username,
    service_provider,
    last_usage_date
   FROM sim_management_inventory
  WHERE carrier_cycle_usage = 0;


CREATE OR REPLACE VIEW vw_people_netsapiens_customers_list_view AS
SELECT
    Extent1.id AS id,
    Extent1.tenant_name AS tenant_name,
    Extent1.company_name AS company_name,
    Extent1.description AS description,
    Extent1.inactivity_start AS inactivity_start,
    Extent1.inactivity_end AS inactivity_end,
    Extent1.apt_suite AS apt_suite,
    Extent1.address1 AS address1,
    Extent1.address2 AS address2,
    Extent1.city AS city,
    Extent1.state AS state,
    Extent1.postal_code AS postal_code,
    Extent1.country AS country,
    Extent1.created_date AS created_date,
    Extent1.created_by AS created_by,
    Extent1.modified_date AS modified_date,
    Extent1.modified_by AS modified_by,
    Extent1.deleted_date AS deleted_date,
    Extent1.deleted_by AS deleted_by,
    Extent1.is_deleted AS is_deleted,
    Extent1.is_active AS is_active,
    Extent1.netsapiens_type AS netsapiens_type,
    Extent1.rev_customer_id AS rev_customer_id,
    Extent1.bandwidth_customer_id AS bandwidth_customer_id,
    Extent1.netsapiens_customer_id AS netsapiens_customer_id,
    Extent1.is_system_default AS is_system_default,
    Extent1.e911_customer_id AS e911_customer_id,
    Extent1.netsapiens_domain_id AS netsapiens_domain_id,
    Extent1.customer_rate_plans AS customer_rate_plans,
    Extent1.customer_bill_period_end_hour AS customer_bill_period_end_hour,
    Extent1.customer_bill_period_end_day AS customer_bill_period_end_day
FROM public.customers AS Extent1
WHERE Extent1.is_deleted <> 'true'
    AND Extent1.is_active = 'true'
    AND (Extent1.bandwidth_customer_id IS NOT NULL OR Extent1.is_system_default = true)
ORDER BY Extent1.modified_date DESC, Extent1.company_name ASC;

CREATE OR REPLACE VIEW vw_people_revio_customers AS
WITH distinct_agents AS (
    SELECT DISTINCT 
        ra.rev_agent_id, 
        ra.agent_name
    FROM 
        public.revagent ra
    WHERE 
        ra.is_active = 'true' 
        AND ra.is_deleted = 'false'
)
SELECT
    C.id AS id,
    C.tenant_name AS partner,
    da.agent_name AS agent_name,  
    rc.customer_name AS name,
    rc.rev_customer_id AS account,
    C.customer_bill_period_end_day,
    C.customer_bill_period_end_hour
FROM
    public.revcustomer rc
JOIN
    public.customers c ON rc.id = c.rev_customer_id
LEFT JOIN
    distinct_agents da ON da.rev_agent_id = rc.agent_id
WHERE
    rc.bill_profile_id IN (
        SELECT bill_profile_id
        FROM public.revbillprofile
        WHERE 
            integration_authentication_id IN (
                SELECT id
                FROM public.integration_authentication
                WHERE tenant_id = '1'
            )
            AND is_active = 'true'
            AND is_deleted = 'false'
    )
    AND c.is_active = 'true'
    AND c.is_deleted = 'false'
    AND rc.is_active = 'true'
    AND rc.is_deleted = 'false'
ORDER BY  
    c.modified_date DESC;

CREATE OR REPLACE VIEW vw_people_bandwidth_customers AS
SELECT
    Extent1.id AS id,
    Extent1.tenant_name AS tenant_name,
    Extent1.company_name AS company_name,
    Extent1.description AS description,
    Extent1.inactivity_start AS inactivity_start,
    Extent1.inactivity_end AS inactivity_end,
    Extent1.apt_suite AS apt_suite,
    Extent1.address1 AS address1,
    Extent1.address2 AS address2,
    Extent1.city AS city,
    bws.bandwidth_account_id AS bandwidth_account_id,
    Extent1.state AS state,
    Extent1.postal_code AS postal_code,
    Extent1.country AS country,
    Extent1.created_date AS created_date,
    Extent1.created_by AS created_by,
    Extent1.modified_date AS modified_date,
    Extent1.modified_by AS modified_by,
    Extent1.deleted_date AS deleted_date,
    Extent1.deleted_by AS deleted_by,
    Extent1.is_deleted AS is_deleted,
    Extent1.is_active AS is_active,
    Extent1.rev_customer_id AS rev_customer_id,
    Extent1.bandwidth_customer_id AS bandwidth_customer_id,
    Extent1.netsapiens_customer_id AS netsapiens_customer_id,
    Extent1.is_system_default AS is_system_default,
    Extent1.e911_customer_id AS e911_customer_id,
    Extent1.netsapiens_domain_id AS netsapiens_domain_id,
    Extent1.customer_rate_plans AS customer_rate_plans,
    Extent1.customer_bill_period_end_hour AS customer_bill_period_end_hour,
    Extent1.customer_bill_period_end_day AS customer_bill_period_end_day
FROM 
    public.customers AS Extent1
JOIN 
    bandwidth_customers AS bws
    ON bws.id = CAST(CAST(Extent1.bandwidth_customer_id AS FLOAT) AS INTEGER)
WHERE 
    Extent1.is_deleted <> 'true'
    AND Extent1.is_active = 'true'
    AND (Extent1.bandwidth_customer_id IS NOT NULL OR Extent1.is_system_default = true)
ORDER BY 
    Extent1.modified_date DESC, 
    Extent1.company_name ASC;

CREATE OR REPLACE VIEW vw_daily_usage_report AS
SELECT 
    sm.service_provider,
    bp.billing_cycle_end_date,
    sm.iccid,
    sm.msisdn,
    sm.foundation_account_number,
    sm.billing_account_number,
    sm.customer_pool,
    sm.customer_name,
    sm.username,
    sm.carrier_rate_plan,
    sm.customer_rate_plan,
    sp.integration_id,
    CASE 
        WHEN sp.integration_id = 12 THEN ROUND(COALESCE(sm.carrier_cycle_usage, 0.0) / 1000.0 / 1000.0, 3) 
        ELSE ROUND(COALESCE(sm.carrier_cycle_usage, 0.0) / 1024.0 / 1024.0, 3) 
    END AS DataUsageMB,
    sm.carrier_cycle_usage,
    sm.sim_status,
    sm.date_activated
FROM 
    public.sim_management_inventory AS sm
INNER JOIN 
    public.serviceprovider AS sp ON sm.id = sp.id
LEFT JOIN 
    public.billing_period AS bp ON sm.id = bp.id;


CREATE OR REPLACE VIEW public.vw_m2m_rev_service_products
AS SELECT dt.id,
        CASE
            WHEN s.integration_id = 12 THEN smi.eid
            ELSE
            CASE
                WHEN s.integration_id = 13 THEN smi.iccid
                ELSE COALESCE(smi.msisdn, smi.iccid)
            END
        END AS service_number,
    ds.display_name AS device_status,
    COALESCE(dsh.date_of_change, smi.date_activated) AS carrier_last_status_date,
    COALESCE(
        CASE
            WHEN ds.display_name::text = ANY (ARRAY['RestoredFromArchive'::character varying, 'Restored from archive'::character varying]::text[]) THEN true
            ELSE ds.is_active_status
        END, false) AS is_active_status,
    ds.should_have_billed_service,
    smi.iccid,
    smi.service_provider_id,
    s.display_name AS service_provider,
    smi.communication_plan,
    rs.activated_date,
    rs.disconnected_date,
    rsp.service_product_id,
        CASE
            WHEN rsp.package_id = 0 THEN NULL::integer
            ELSE rsp.package_id
        END AS package_id,
    rsp.service_id,
    rsp.product_id,
    rsp.description,
    rsp.rate,
    rsp.status AS rev_io_status,
        CASE
            WHEN rsp.status::text = 'ACTIVE'::text THEN true
            ELSE false
        END AS rev_is_active_status,
    rsp.cost,
    rsp.wholesale_description,
    rsp.quantity,
    rsp.integration_authentication_id,
    COALESCE(r.rev_customer_id, c2.rev_customer_id::text::character varying) AS rev_account_number,
    COALESCE(r.customer_name, c2.customer_name) AS customer_name,
    rp.id AS rev_product_id,
    rp.product_type_id,
    rp.description AS product_description,
    rst.service_type_id,
    dt.tenant_id,
    smi.last_activated_date AS carrier_activated_date,
    c.rate_plan_name AS customer_rate_plan_name,
    smi.carrier_rate_plan
   FROM device_tenant dt
     JOIN device smi ON dt.device_id = smi.id and smi.is_active is true and smi.is_deleted is false
     JOIN device_status ds ON ds.id = smi.device_status_id
     JOIN serviceprovider s ON s.id = smi.service_provider_id AND s.is_active IS TRUE AND s.is_deleted IS FALSE
     JOIN integration i ON i.id = s.integration_id and i.portal_type_id=0
     LEFT JOIN rev_service rs ON rs.id = dt.rev_service_id
     LEFT JOIN customerrateplan c ON dt.customer_rate_plan_id = c.id
     LEFT JOIN customers c2 ON dt.customer_id = c2.id AND c2.rev_customer_id IS NOT NULL
     LEFT JOIN revcustomer r ON c2.rev_customer_id = r.id AND r.status::text <> 'CLOSED'::text AND r.is_active IS TRUE AND r.is_deleted IS FALSE
     LEFT JOIN rev_service_product rsp ON rs.rev_service_id = rsp.service_id AND rsp.integration_authentication_id = rs.integration_authentication_id AND rsp.status::text = 'ACTIVE'::text AND rsp.is_active IS TRUE AND rsp.is_deleted IS FALSE
     LEFT JOIN revcustomer r2 ON rsp.customer_id::text = r2.rev_customer_id::text AND rsp.integration_authentication_id = r2.integration_authentication_id AND r2.status::text <> 'CLOSED'::text AND r2.is_active IS TRUE AND r2.is_deleted = false
     LEFT JOIN integration_authentication ia ON r2.integration_authentication_id = ia.id
     LEFT JOIN rev_product rp ON rsp.product_id = rp.product_id AND rsp.integration_authentication_id = rp.integration_authentication_id
     LEFT JOIN rev_service_type rst ON rst.id = rs.rev_service_type_id AND rst.integration_authentication_id = rs.integration_authentication_id
     LEFT JOIN rev_product_type rpt ON rpt.product_type_id = rp.product_type_id AND rpt.integration_authentication_id = rp.integration_authentication_id AND (rpt.product_type_code IS NULL OR rpt.product_type_code::text ~~ 'RECURRING_%'::text)
     LEFT JOIN ( SELECT dsh_1.iccid,
            max(dsh_1.date_of_change) AS date_of_change
           FROM device_status_history dsh_1
          GROUP BY dsh_1.iccid) dsh ON dsh.iccid::text = smi.iccid::text
  WHERE dt.is_deleted IS FALSE AND smi.is_deleted IS FALSE AND rst.service_type_id IS NULL OR rst.service_type_id = 18 AND rst.description::text = 'Wireless Service'::text;

CREATE OR REPLACE VIEW public.vw_m2m_revenue_assurance_group AS
SELECT 
    gen_random_uuid() AS id,  
    rsp1a.tenant_id,
    COALESCE(rsp1a.rev_account_number, 'Unassigned') AS rev_customer_id, 
    COALESCE(rsp1a.customer_name, 'Unassigned') AS rev_customer_name, 
    rsp2a.rev_active_count AS rev_active_device_count,
    rsp1a.total_device_count AS rev_total_device_count,
    rsp2a.any_active_count AS carrier_total_device_count,
    rsp2a.variance_count
FROM
(
    SELECT 
        tenant_id, 
        rev_account_number, 
        customer_name, 
        COUNT(1) AS total_device_count
    FROM
    (
        SELECT DISTINCT 
            tenant_id, 
            rev_account_number, 
            customer_name, 
            service_number
        FROM 
            vw_m2m_rev_service_products
    ) rsp1
    GROUP BY 
        tenant_id, 
        rev_account_number, 
        customer_name
) rsp1a
INNER JOIN
(
    SELECT 
        tenant_id, 
        rev_account_number, 
        customer_name, 
        SUM(is_any_active) AS any_active_count, 
        SUM(is_rev_active) AS rev_active_count, 
        SUM(variance) AS variance_count
    FROM
    (
        SELECT DISTINCT 
            tenant_id, 
            rev_account_number, 
            customer_name, 
            service_number, 
            CASE WHEN (is_active_status <> rev_is_active_status) THEN 1 ELSE 0 END AS variance,
            CASE WHEN (is_active_status IS TRUE OR rev_is_active_status IS TRUE) THEN 1 ELSE 0 END AS is_any_active,
            CASE WHEN rev_is_active_status IS TRUE THEN 1 ELSE 0 END AS is_rev_active
        FROM 
            vw_m2m_rev_service_products
    ) rsp2
    GROUP BY 
        tenant_id, 
        rev_account_number, 
        customer_name
) rsp2a ON rsp1a.tenant_id = rsp2a.tenant_id 
AND COALESCE(rsp1a.rev_account_number, '') = COALESCE(rsp2a.rev_account_number, '');

CREATE VIEW vw_mobility_rev_service_products AS
WITH cte_device_status_history AS (
    SELECT date_of_change, mobility_device_id, current_status, previous_status
    FROM device_status_history
    WHERE date_of_change IS NOT NULL
),
cte_device_status_history_cancel_status_to_unknown_status AS (
    SELECT date_of_change, mobility_device_id, current_status, previous_status
    FROM cte_device_status_history
    WHERE LOWER(current_status) = 'c' AND LOWER(previous_status) != 'c'
),
cte_device_status_history_not_cancel_status_to_unknown_status AS (
    SELECT date_of_change, mobility_device_id, current_status, previous_status
    FROM cte_device_status_history
    WHERE LOWER(current_status) = 'unknown' AND LOWER(previous_status) != 'c'
)
SELECT 
    gen_random_uuid() AS id,
    sim_management_inventory.msisdn AS service_number,
    CASE
        WHEN EXISTS (
            SELECT 1
            FROM device_status_history
            WHERE mobility_device_id = sim_management_inventory.mobility_device_id
                AND date_of_change IS NOT NULL
                AND current_status IN (
                    SELECT status 
                    FROM device_status 
                    WHERE serviceprovider.integration_id = device_status.integration_id
                )
            ORDER BY date_of_change DESC
            LIMIT 1
        ) THEN (
            CASE 
                WHEN EXISTS (
                    SELECT 1
                    FROM cte_device_status_history
                    WHERE mobility_device_id = sim_management_inventory.mobility_device_id
                        AND LOWER(current_status) = 'unknown'
                        AND LOWER(previous_status) = 'c'
                ) 
                AND (
                    (SELECT MAX(date_of_change)
                     FROM cte_device_status_history_not_cancel_status_to_unknown_status
                     WHERE mobility_device_id = sim_management_inventory.mobility_device_id) IS NULL 
                    OR (SELECT MAX(date_of_change)
                        FROM cte_device_status_history_not_cancel_status_to_unknown_status
                        WHERE mobility_device_id = sim_management_inventory.mobility_device_id) < 
                       (SELECT MAX(date_of_change)
                        FROM cte_device_status_history_cancel_status_to_unknown_status
                        WHERE mobility_device_id = sim_management_inventory.mobility_device_id)
                )
                OR LOWER((
                    SELECT current_status
                    FROM cte_device_status_history
                    WHERE mobility_device_id = sim_management_inventory.mobility_device_id
                        AND LOWER(current_status) = 'c'
                    ORDER BY date_of_change DESC
                    LIMIT 1
                )) = 'c'
                    THEN 'C'
                ELSE sim_management_inventory.sim_status
            END
        )
        ELSE sim_management_inventory.sim_status
    END AS device_status,
    CASE
        WHEN EXISTS (
            SELECT 1
            FROM device_status_history
            WHERE mobility_device_id = sim_management_inventory.mobility_device_id
                AND date_of_change IS NOT NULL
                AND current_status IN (
                    SELECT status
                    FROM device_status
                    WHERE serviceprovider.integration_id = device_status.integration_id
                )
            ORDER BY date_of_change DESC
            LIMIT 1
        ) THEN (
            CASE 
                WHEN EXISTS (
                    SELECT 1
                    FROM cte_device_status_history
                    WHERE mobility_device_id = sim_management_inventory.mobility_device_id
                        AND LOWER(current_status) = 'unknown'
                        AND LOWER(previous_status) = 'c'
                ) 
                AND (
                    (SELECT MAX(date_of_change)
                     FROM cte_device_status_history_not_cancel_status_to_unknown_status
                     WHERE mobility_device_id = sim_management_inventory.mobility_device_id) IS NULL 
                    OR (SELECT MAX(date_of_change)
                        FROM cte_device_status_history_not_cancel_status_to_unknown_status
                        WHERE mobility_device_id = sim_management_inventory.mobility_device_id) < 
                       (SELECT MAX(date_of_change)
                        FROM cte_device_status_history_cancel_status_to_unknown_status
                        WHERE mobility_device_id = sim_management_inventory.mobility_device_id)
                )
                OR (SELECT current_status
                    FROM cte_device_status_history
                    WHERE mobility_device_id = sim_management_inventory.mobility_device_id
                        AND LOWER(current_status) = 'c'
                    ORDER BY date_of_change DESC
                    LIMIT 1) = 'C'
                    THEN (
                        SELECT date_of_change
                        FROM cte_device_status_history_cancel_status_to_unknown_status
                        WHERE mobility_device_id = sim_management_inventory.mobility_device_id
                        ORDER BY date_of_change DESC
                        LIMIT 1
                    )
                ELSE (
                    SELECT date_of_change
                    FROM cte_device_status_history
                    WHERE mobility_device_id = sim_management_inventory.mobility_device_id
                        AND current_status IN (
                            SELECT status
                            FROM device_status
                            WHERE serviceprovider.integration_id = device_status.integration_id
                        )
                    ORDER BY date_of_change DESC
                    LIMIT 1
                )
            END
        )
        ELSE sim_management_inventory.date_activated
    END AS carrier_last_status_date,
    device_status.is_active_status,
    device_status.should_have_billed_service,
    sim_management_inventory.iccid,
    sim_management_inventory.service_provider_id,
    serviceprovider.display_name AS service_provider,
    rev_service.activated_date,
    rev_service.disconnected_date,
    rev_service_product.service_product_id,
    CASE 
        WHEN rev_service_product.package_id = 0 THEN NULL
        ELSE rev_service_product.package_id
    END AS package_id,
    rev_service_product.service_id,
    rev_service_product.product_id,
    rev_service_product.description,
    rev_service_product.rate,
    rev_service_product.status AS revio_status,
    CASE 
        WHEN rev_service_product.status = 'ACTIVE' THEN TRUE 
        ELSE FALSE 
    END AS rev_is_active_status,
    rev_service_product.cost,
    rev_service_product.wholesale_description,
    rev_service_product.quantity,
    rev_service_product.integration_authentication_id,
    COALESCE(revcustomer.rev_customer_id, site_customer.rev_customer_id) AS rev_account_number,
    COALESCE(revcustomer.customer_name, site_customer.customer_name) AS customer_name,
    rev_product.id AS rev_product_id,
    rev_product.product_type_id,
    rev_product.description AS product_description,
    rev_service_type.service_type_id,
    COALESCE(device_tenant.tenant_id, integration_authentication.tenant_id, serviceprovider.tenant_id) AS tenant_id,
    sim_management_inventory.last_activated_date AS carrier_activated_date,
    customerrateplan.rate_plan_name AS customer_rate_plan,
    sim_management_inventory.carrier_rate_plan AS carrier_rate_plan
FROM sim_management_inventory
INNER JOIN mobility_device_tenant AS device_tenant 
    ON sim_management_inventory.mobility_device_id = device_tenant.mobility_device_id
INNER JOIN device_status 
    ON device_status.id = sim_management_inventory.device_status_id
INNER JOIN serviceprovider 
    ON serviceprovider.id = sim_management_inventory.service_provider_id
INNER JOIN integration 
    ON integration.id = serviceprovider.integration_id
LEFT JOIN customers AS customers 
    ON device_tenant.customer_id = customers.id AND customers.rev_customer_id IS NOT NULL
LEFT JOIN revcustomer AS site_customer 
    ON customers.rev_customer_id = site_customer.id 
    AND site_customer.status <> 'CLOSED' 
    AND site_customer.is_active = TRUE 
    AND site_customer.is_deleted = FALSE
LEFT JOIN rev_service 
    ON device_tenant.rev_service_id = rev_service.id
LEFT JOIN rev_service_product 
    ON rev_service.rev_service_id = rev_service_product.service_id 
    AND rev_service_product.integration_authentication_id = rev_service.integration_authentication_id 
    AND rev_service_product.status = 'ACTIVE'
LEFT JOIN revcustomer 
    ON rev_service_product.customer_id = revcustomer.rev_customer_id 
    AND rev_service_product.integration_authentication_id = revcustomer.integration_authentication_id 
    AND revcustomer.status <> 'CLOSED' 
    AND revcustomer.is_active = TRUE 
    AND revcustomer.is_deleted = FALSE
LEFT JOIN integration_authentication 
    ON revcustomer.integration_authentication_id = integration_authentication.id
LEFT JOIN rev_product 
    ON rev_service_product.product_id = rev_product.product_id 
    AND rev_service_product.integration_authentication_id = rev_product.integration_authentication_id
LEFT JOIN rev_service_type 
    ON rev_service_type.id = rev_service.rev_service_type_id 
    AND rev_service_type.integration_authentication_id = rev_service.integration_authentication_id
LEFT JOIN rev_product_type 
    ON rev_product_type.product_type_id = rev_product.product_type_id 
    AND rev_product_type.integration_authentication_id = rev_product.integration_authentication_id
LEFT OUTER JOIN customerrateplan 
    ON device_tenant.customer_rate_plan_id = customerrateplan.id
WHERE sim_management_inventory.is_deleted = FALSE 
    AND device_tenant.is_deleted = FALSE 
    AND (rev_product_type.product_type_code IS NULL 
         OR rev_product_type.product_type_code LIKE 'RECURRING_%') 
    AND integration.portal_type_id = 2
    AND LOWER(device_status.description) <> 'suspended';

CREATE OR REPLACE VIEW public.vw_mobility_revenue_assurance_group
AS SELECT gen_random_uuid() AS id,
    rsp1a.tenant_id,
    COALESCE(rsp1a.rev_account_number, 'Unassigned'::character varying) AS rev_customer_id,
    COALESCE(rsp1a.customer_name, 'Unassigned'::character varying) AS rev_customer_name,
    rsp2a.rev_active_count AS rev_active_device_count,
    rsp1a.total_device_count AS rev_total_device_count,
    rsp2a.any_active_count AS carrier_total_device_count,
    rsp2a.variance_count
   FROM ( SELECT rsp1.tenant_id,
            rsp1.rev_account_number,
            rsp1.customer_name,
            count(1) AS total_device_count
           FROM ( SELECT DISTINCT vw_mobility_rev_service_products.tenant_id,
                    vw_mobility_rev_service_products.rev_account_number,
                    vw_mobility_rev_service_products.customer_name,
                    vw_mobility_rev_service_products.service_number
                   FROM vw_mobility_rev_service_products) rsp1
          GROUP BY rsp1.tenant_id, rsp1.rev_account_number, rsp1.customer_name) rsp1a
     JOIN ( SELECT rsp2.tenant_id,
            rsp2.rev_account_number,
            rsp2.customer_name,
            sum(rsp2.is_any_active) AS any_active_count,
            sum(rsp2.is_rev_active) AS rev_active_count,
            sum(rsp2.variance) AS variance_count
           FROM ( SELECT DISTINCT vw_mobility_rev_service_products.tenant_id,
                    vw_mobility_rev_service_products.rev_account_number,
                    vw_mobility_rev_service_products.customer_name,
                    vw_mobility_rev_service_products.service_number,
                        CASE
                            WHEN vw_mobility_rev_service_products.is_active_status <> vw_mobility_rev_service_products.rev_is_active_status THEN 1
                            ELSE 0
                        END AS variance,
                        CASE
                            WHEN vw_mobility_rev_service_products.is_active_status = true OR vw_mobility_rev_service_products.rev_is_active_status = true THEN 1
                            ELSE 0
                        END AS is_any_active,
                        CASE
                            WHEN vw_mobility_rev_service_products.rev_is_active_status = true THEN 1
                            ELSE 0
                        END AS is_rev_active
                   FROM vw_mobility_rev_service_products) rsp2
          GROUP BY rsp2.tenant_id, rsp2.rev_account_number, rsp2.customer_name) rsp2a ON rsp1a.tenant_id = rsp2a.tenant_id AND COALESCE(rsp1a.rev_account_number, ''::character varying)::text = COALESCE(rsp2a.rev_account_number, ''::character varying)::text;

CREATE VIEW vw_m2m_device_current_billing_period AS
SELECT 
    device_tenant.device_id,
    current_customer_billing_period.end_date,
    current_customer_billing_period.start_date,
    device_tenant.tenant_id
FROM 
    device_tenant
INNER JOIN 
    customers ON device_tenant.customer_id = customers.id
LEFT JOIN LATERAL 
    get_current_customer_billing_period(customers.customer_bill_period_end_day, customers.customer_bill_period_end_hour) 
    AS current_customer_billing_period ON TRUE
WHERE 
    customers.customer_bill_period_end_day IS NOT NULL
    OR customers.customer_bill_period_end_hour IS NOT NULL;

CREATE VIEW vw_m2m_customer_current_cycle_device_usage AS
SELECT 
    device_usage.m2m_device_id,
    SUM(data_usage) AS customer_cycle_usage_byte,
    MIN(device_usage.start_date) AS start_date,
    device_usage.end_date,
    tenant_id
FROM (
    SELECT 
        device_usage.m2m_device_id,
        data_usage,
        vw_m2m_device_current_billing_period.end_date,
        vw_m2m_device_current_billing_period.start_date,
        device_usage.usage_date,
        vw_m2m_device_current_billing_period.tenant_id
    FROM 
        device_usage
    INNER JOIN 
        vw_m2m_device_current_billing_period 
        ON vw_m2m_device_current_billing_period.device_id = device_usage.m2m_device_id
    WHERE 
        device_usage.m2m_device_id IS NOT NULL
        AND device_usage.usage_date >= vw_m2m_device_current_billing_period.start_date
        AND device_usage.usage_date < vw_m2m_device_current_billing_period.end_date
) AS device_usage
GROUP BY
    device_usage.m2m_device_id,
    device_usage.end_date,
    tenant_id;

CREATE VIEW vw_m2m_device_inventory_export AS
   SELECT 
        d.service_provider_id,
        sp.display_name AS service_provider_display_name,
        COALESCE(dc.date_of_change, d.date_added) AS date_added,
        COALESCE(ac.date_of_change, d.date_activated) AS date_activated,
        d.iccid,
        d.imei,
        d.msisdn,
        d.eid,
        d.carrier_rate_plan,
        crp1.display_rate AS carrier_rate_plan_display_rate,
        d.communication_plan AS comm_plan,
        d.ip_address AS ip_address,
        CASE
            WHEN i.id = 12 THEN TO_CHAR(ROUND(COALESCE(d.carrier_cycle_usage, 0.0) / 1000.0 / 1000.0, 3), 'FM999999999999.0000')
            ELSE TO_CHAR(ROUND(COALESCE(d.carrier_cycle_usage, 0.0) / 1024.0 / 1024.0, 3), 'FM999999999999.0000')
        END AS data_usage_mb,
        crp2.name AS customer_rate_pool_name,
        crp1.rate_plan_name AS customer_rate_plan_name,
        crp1.display_rate AS customer_rate_plan_display_rate,
        ds.display_name AS status_display_name,
        d.cost_center,
        rc.rev_customer_id,
        s.customer_name AS customer_name,
        d.ctd_sms_usage AS sms_count,
        s.tenant_id,
        s.id AS customer_id,
        s.parent_customer_id AS parent_customer_id,
        d.sim_status AS status_code,
        d.carrier_cycle_usage AS data_usage_bytes,
        rc.customer_name as rev_customer_name,
        d.created_date,
        d.created_by,
        d.username,
        TO_CHAR(ROUND(
            CASE 
                WHEN s.customer_bill_period_end_day IS NOT NULL AND s.customer_bill_period_end_hour IS NOT NULL
                    THEN ConvertBytesToMBByIntegrationId(COALESCE(ccdu.customer_cycle_usage_byte::BIGINT, 0), sp.integration_id) 
                ELSE ConvertBytesToMBByIntegrationId(COALESCE(d.carrier_cycle_usage::BIGINT, 0), sp.integration_id)
            END, 3), 'FM999999999999.0000') AS customer_cycle_usage_mb
    FROM device d
    INNER JOIN serviceprovider sp ON d.service_provider_id = sp.id
    INNER JOIN integration i ON i.id = sp.integration_id
    INNER JOIN device_tenant dt ON d.id = dt.device_id
    LEFT JOIN device_status ds ON ds.id = d.device_status_id
    LEFT JOIN customers s ON dt.customer_id = s.id AND s.is_active = TRUE AND s.is_deleted = FALSE
    LEFT JOIN revcustomer rc ON s.rev_customer_id = rc.id AND rc.is_active = TRUE
    LEFT JOIN customerrateplan crp1 ON dt.customer_rate_plan_id = crp1.id
    LEFT JOIN customer_rate_pool crp2 ON crp2.id = dt.customer_rate_pool_id
    LEFT JOIN carrier_rate_plan crp3 ON d.carrier_rate_plan_id = crp3.id
    LEFT JOIN vw_m2m_customer_current_cycle_device_usage ccdu ON ccdu.m2m_device_id = d.id AND ccdu.tenant_id = dt.tenant_id
    LEFT JOIN LATERAL (
        SELECT date_of_change
        FROM device_status_history dsh
        WHERE dsh.iccid = d.iccid 
        AND dsh.current_status IN (SELECT status FROM device_status WHERE sp.integration_id = device_status.integration_id AND device_status.is_active_status = TRUE)
        ORDER BY date_of_change
        LIMIT 1
    ) AS dc ON TRUE
    LEFT JOIN LATERAL (
        SELECT date_of_change
        FROM device_status_history dsh
        WHERE dsh.iccid = d.iccid 
        AND dsh.current_status IN (SELECT status FROM device_status WHERE sp.integration_id = device_status.integration_id)
        ORDER BY date_of_change DESC
        LIMIT 1
    ) AS ac ON TRUE
    WHERE d.is_active = TRUE AND d.is_deleted = FALSE
    AND i.is_active = TRUE AND i.is_deleted = FALSE
    AND i.portal_type_id = 0;

CREATE VIEW vw_mobility_device_current_billing_period AS
    SELECT 
        mobility_device_tenant.mobility_device_id,
        current_customer_billing_period.end_date,
        current_customer_billing_period.start_date,
        mobility_device_tenant.tenant_id
    FROM mobility_device_tenant
    INNER JOIN customers ON mobility_device_tenant.customer_id = customers.id
    CROSS JOIN LATERAL Get_Current_Customer_Billing_Period(customers.customer_bill_period_end_day, customers.customer_bill_period_end_hour) AS current_customer_billing_period
    WHERE customers.customer_bill_period_end_day IS NOT NULL
    OR customers.customer_bill_period_end_hour IS NOT NULL;

CREATE VIEW vw_mobility_customer_current_cycle_device_usage AS
    SELECT 
        device_usage.mobility_device_id,
        SUM(device_usage.data_usage) AS customer_cycle_usage_byte,
        MIN(device_usage.start_date) AS start_date,
        device_usage.end_date,
        device_usage.tenant_id
    FROM (
        SELECT 
            device_usage.mobility_device_id,
            device_usage.data_usage,
            vw_mobility_device_current_billing_period.end_date,
            vw_mobility_device_current_billing_period.start_date,
            device_usage.usage_date,
            vw_mobility_device_current_billing_period.tenant_id
        FROM device_usage
        INNER JOIN vw_mobility_device_current_billing_period 
            ON vw_mobility_device_current_billing_period.mobility_device_id = device_usage.mobility_device_id
        WHERE device_usage.mobility_device_id IS NOT NULL
        AND device_usage.usage_date >= vw_mobility_device_current_billing_period.start_date
        AND device_usage.usage_date < vw_mobility_device_current_billing_period.end_date
    ) AS device_usage
    GROUP BY
        device_usage.mobility_device_id,
        device_usage.end_date,
        device_usage.tenant_id;

CREATE VIEW vw_mobility_device_inventory_export AS
    SELECT
        mobility_device.id,
        mobility_device.service_provider_id,
        serviceprovider.display_name AS service_provider_display_name,
        serviceprovider.integration_id,
        mobility_device.iccid,
        mobility_device.msisdn,
        mobility_device.imei,
        COALESCE(carrier_rate_plan.friendly_name, mobility_device.carrier_rate_plan) AS rate_plan,
        carrier_rate_plan.display_rate AS carrier_rate_plan_display_rate,
        mobility_device.carrier_cycle_usage AS data_usage_bytes,
        CASE
            WHEN integration.id = 12 THEN ROUND(COALESCE(mobility_device.carrier_cycle_usage, 0.0) / 1000.0 / 1000.0, 3)
            ELSE ROUND(COALESCE(mobility_device.carrier_cycle_usage, 0.0) / 1024.0 / 1024.0, 3)
        END AS data_usage_mb,
        mobility_device.date_added AS date_added,
        mobility_device.date_activated AS date_activated,
        mobility_device.created_date,
        mobility_device.created_by,
        mobility_device.modified_by,
        mobility_device.modified_date,
        mobility_device.deleted_by,
        mobility_device.deleted_date,
        mobility_device.is_active,
        mobility_device.is_deleted,
        mobility_device_tenant.account_number,
        mobility_device.carrier_rate_plan_id,
        mobility_device.cost_center,
        mobility_device.sim_status AS status_code,
        device_status.display_name AS status_display_name,
        device_status.status_color,
        device_status.status_color_code,
        mobility_device_tenant.tenant_id,
        serviceprovider.tenant_id AS service_provider_tenant_id,
        revcustomer.rev_customer_id,
        revcustomer.customer_name as rev_customer_name,
        revcustomer.rev_parent_customer_id,
        mobility_device.foundation_account_number AS foundation_account_number,
        mobility_device.billing_account_number AS billing_account_number,
        mobility_device.service_zip_code,
        mobility_device.single_user_code AS rate_plan_soc,
        mobility_device.single_user_code_description AS rate_plan_soc_description,
        mobility_device.data_group_id,
        mobility_device.pool_id,
        mobility_device.next_bill_cycle_date,
        mobility_device.device_make AS device_make,
        mobility_device.device_model AS device_model,
        mobility_device.contract_status,
        mobility_device.ban_status,
        mobility_device.sms_count,
        mobility_device.minutes_used,
        mobility_device.imei_type_id,
        mobility_device.plan_limit_mb,
        customers.id AS customer_id,
        customers.parent_customer_id AS parent_customer_id,
        customers.customer_name AS customer_name,
        customerrateplan.rate_plan_code AS customer_rate_plan_code,
        customerrateplan.rate_plan_name AS customer_rate_plan_name,
        customerrateplan.display_rate AS customer_rate_plan_display_rate,
        mobility_device_tenant.customer_data_allocation_mb AS customer_data_allocation_mb,
        mobility_device.username,
        mobility_device_tenant.customer_rate_pool_id,
        customer_rate_pool.name AS customer_rate_pool_name,
        billing_period.billing_cycle_start_date,
        billing_period.billing_cycle_end_date,
        device_status.is_active_status,
        customerrateplan.plan_mb AS customer_rate_plan_mb,
        customerrateplan.allows_sim_pooling AS customer_rate_plan_allows_sim_pooling,
        carrier_rate_plan.plan_mb AS carrier_rate_plan_mb,
        (SELECT STRING_AGG(CAST(mobility_feature.soc_code AS text), ',')
            FROM telegence_device_mobility_feature
            INNER JOIN mobility_feature ON mobility_feature.id = telegence_device_mobility_feature.mobility_feature_id
            WHERE telegence_device.id IS NOT NULL
            AND telegence_device_mobility_feature.is_deleted = false
            AND telegence_device_mobility_feature.is_active = true
            AND telegence_device_mobility_feature.telegence_device_id = telegence_device.id
            AND mobility_feature.is_deleted = false
            AND mobility_feature.is_active = true
            AND mobility_feature.is_retired = false
        ) AS telegence_feature,
        (SELECT STRING_AGG(CAST(mobility_feature.soc_code AS text), ',')
            FROM e_bonding_device_mobility_feature
            INNER JOIN mobility_feature ON mobility_feature.id = e_bonding_device_mobility_feature.mobility_feature_id
            WHERE e_bonding_device.id IS NOT NULL
            AND e_bonding_device_mobility_feature.is_deleted is false
            AND e_bonding_device_mobility_feature.is_active = true
            AND e_bonding_device_mobility_feature.e_bonding_device_id = e_bonding_device.id
            AND mobility_feature.is_deleted = false
            AND mobility_feature.is_active = true
            AND mobility_feature.is_retired = false
        ) AS ebonding_feature,
        mobility_device.ip_address,
        CASE
            WHEN customers.customer_bill_period_end_day IS NOT NULL AND customers.customer_bill_period_end_hour IS NOT NULL
                THEN ROUND(COALESCE(vw_mobility_customer_current_cycle_device_usage.customer_cycle_usage_byte, 0.0) / 1024.0 / 1024.0, 3)
            ELSE ROUND(COALESCE(mobility_device.carrier_cycle_usage, 0.0) / 1024.0 / 1024.0, 3)
        END AS customer_cycle_usage_mb
    FROM mobility_device
        INNER JOIN mobility_device_tenant ON mobility_device.id = mobility_device_tenant.mobility_device_id
        INNER JOIN serviceprovider ON mobility_device.service_provider_id = serviceprovider.id
        LEFT JOIN device_status ON device_status.id = mobility_device.device_status_id
        LEFT JOIN customers ON mobility_device_tenant.customer_id = customers.id AND customers.is_active is true AND customers.is_deleted is false
        LEFT JOIN revcustomer ON customers.rev_customer_id = revcustomer.id AND revcustomer.is_active is true AND revcustomer.is_deleted is false
        LEFT JOIN integration ON integration.id = serviceprovider.integration_id AND integration.is_active is true AND integration.is_deleted is false
        LEFT JOIN carrier_rate_plan ON mobility_device.carrier_rate_plan_id = carrier_rate_plan.id
        LEFT JOIN customerrateplan ON mobility_device_tenant.customer_rate_plan_id = customerrateplan.id
        LEFT JOIN customer_rate_pool ON customer_rate_pool.id = mobility_device_tenant.customer_rate_pool_id
        LEFT JOIN billing_period ON billing_period.id = mobility_device.billing_period_id
        LEFT JOIN telegence_device ON telegence_device.subscriber_number = mobility_device.msisdn AND telegence_device.service_provider_id = mobility_device.service_provider_id
        LEFT JOIN e_bonding_device ON e_bonding_device.subscriber_number = mobility_device.msisdn AND e_bonding_device.service_provider_id = mobility_device.service_provider_id
        LEFT JOIN vw_mobility_customer_current_cycle_device_usage ON vw_mobility_customer_current_cycle_device_usage.mobility_device_id = mobility_device.id AND vw_mobility_customer_current_cycle_device_usage.tenant_id = mobility_device_tenant.tenant_id
    WHERE mobility_device.is_active is true AND mobility_device.is_deleted is false
        AND integration.portal_type_id = 2;


CREATE VIEW vw_combined_device_inventory_export AS
SELECT
    vmdie.id AS id,
    vmdie.service_provider_id AS service_provider_id,
    vmdie.service_provider_display_name,
    vmdie.integration_id,
    vmdie.iccid,
    vmdie.msisdn,
    vmdie.imei,
    vmdie.rate_plan,
    vmdie.carrier_rate_plan_display_rate,
    vmdie.data_usage_bytes,
    vmdie.data_usage_mb::numeric,
    vmdie.date_added,
    vmdie.date_activated,
    vmdie.created_date,
    vmdie.created_by,
    vmdie.modified_by,
    vmdie.modified_date,
    vmdie.deleted_by,
    vmdie.deleted_date,
    vmdie.is_active,
    vmdie.is_deleted,
    vmdie.account_number,
    vmdie.carrier_rate_plan_id,
    vmdie.cost_center,
    vmdie.status_code,
    vmdie.status_display_name,
    vmdie.status_color,
    vmdie.status_color_code,
    vmdie.tenant_id,
    vmdie.service_provider_tenant_id,
    vmdie.rev_customer_id,
    vmdie.rev_customer_name,
    vmdie.rev_parent_customer_id,
    vmdie.foundation_account_number,
    vmdie.billing_account_number,
    vmdie.service_zip_code,
    vmdie.rate_plan_soc,
    vmdie.rate_plan_soc_description,
    vmdie.data_group_id,
    vmdie.pool_id,
    vmdie.next_bill_cycle_date,
    vmdie.device_make,
    vmdie.device_model,
    vmdie.contract_status,
    vmdie.ban_status,
    vmdie.sms_count,
    vmdie.minutes_used,
    vmdie.imei_type_id,
    vmdie.plan_limit_mb,
    vmdie.customer_id,
    vmdie.parent_customer_id,
    vmdie.customer_name,
    vmdie.customer_rate_plan_code,
    vmdie.customer_rate_plan_name,
    vmdie.customer_rate_plan_display_rate,
    vmdie.customer_data_allocation_mb,
    vmdie.username,
    vmdie.customer_rate_pool_id,
    vmdie.customer_rate_pool_name,
    vmdie.billing_cycle_start_date,
    vmdie.billing_cycle_end_date,
    vmdie.is_active_status,
    vmdie.customer_rate_plan_mb,
    vmdie.telegence_feature,
    vmdie.ebonding_feature,
    vmdie.ip_address,
    vmdie.customer_cycle_usage_mb::numeric
FROM vw_mobility_device_inventory_export vmdie
UNION ALL
SELECT 
    NULL AS id,
    vmmdie.service_provider_id,
    vmmdie.service_provider_display_name,
    NULL AS integration_id,
    vmmdie.iccid,
    vmmdie.msisdn,
    vmmdie.imei,
    vmmdie.carrier_rate_plan AS rate_plan,
    vmmdie.carrier_rate_plan_display_rate,
    vmmdie.data_usage_bytes,
    vmmdie.data_usage_mb::numeric,
    vmmdie.date_added,
    vmmdie.date_activated,
    vmmdie.created_date,
    vmmdie.created_by,
    NULL AS modified_by,
    NULL AS modified_date,
    NULL AS deleted_by,
    NULL AS deleted_date,
    NULL AS is_active,
    NULL AS is_deleted,
    NULL AS account_number,
    NULL AS carrier_rate_plan_id,
    vmmdie.cost_center,
    vmmdie.status_code,
    vmmdie.status_display_name,
    NULL AS status_color,
    NULL AS status_color_code,
    vmmdie.tenant_id,
    NULL AS service_provider_tenant_id,
    vmmdie.rev_customer_id,
    vmmdie.rev_customer_name,
    NULL AS rev_parent_customer_id,
    NULL AS foundation_account_number,
    NULL AS billing_account_number,
    NULL AS service_zip_code,
    NULL AS rate_plan_soc,
    NULL AS rate_plan_soc_description,
    NULL AS data_group_id,
    NULL AS pool_id,
    NULL AS next_bill_cycle_date,
    NULL AS device_make,
    NULL AS device_model,
    NULL AS contract_status,
    NULL AS ban_status,
    vmmdie.sms_count,
    NULL AS minutes_used,
    NULL AS imei_type_id,
    NULL AS plan_limit_mb,
    vmmdie.customer_id,
    vmmdie.parent_customer_id,
    vmmdie.customer_name,
    NULL AS customer_rate_plan_code,
    vmmdie.customer_rate_plan_name,
    vmmdie.customer_rate_plan_display_rate,
    NULL AS customer_data_allocation_mb,
    vmmdie.username,
    NULL AS customer_rate_pool_id,
    vmmdie.customer_rate_pool_name,
    NULL AS billing_cycle_start_date,
    NULL AS billing_cycle_end_date,
    NULL AS is_active_status,
    NULL AS customer_rate_plan_mb,
    NULL AS telegence_feature,
    NULL AS ebonding_feature,
    vmmdie.ip_address,
    vmmdie.customer_cycle_usage_mb::numeric
FROM vw_m2m_device_inventory_export vmmdie;
