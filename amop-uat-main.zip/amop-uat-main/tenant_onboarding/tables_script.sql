CREATE TABLE IF NOT EXISTS public.integration
(
    id serial primary key,
    name character varying(50) ,
    website character varying(250) ,
    created_by character varying(100) ,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    modified_by character varying(100) ,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    is_active boolean,
    is_deleted boolean,
    authentication_type integer,
    has_service_provider boolean,
    portal_type_id integer,
    id_10 integer
);
CREATE INDEX IF NOT EXISTS idx_i_id
    ON public.integration USING btree
    (id ASC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_i_is_active
    ON public.integration USING btree
    (is_active ASC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_integration_portal_type_id
    ON public.integration USING btree
    (portal_type_id ASC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_integration_portal_type_id_active_deleted
    ON public.integration USING btree
    (portal_type_id ASC NULLS LAST, is_active ASC NULLS LAST);

CREATE TABLE IF NOT EXISTS public.serviceprovider
(
    id serial primary key,
    service_provider_name character varying(50)  DEFAULT NULL::character varying,
    display_name character varying(50) ,
    created_by character varying(100)  DEFAULT NULL::character varying,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    integration_id integer,
    bill_period_end_day integer,
    bill_period_end_hour integer,
    device_detail_service_provider_id integer,
    tenant_id integer,
    optimization_start_hour_local_time integer,
    continuous_last_day_optimization_start_hour_local_time integer,
    write_is_enabled boolean,
    register_carrier_service_callback boolean,
    opt_into_carrier_optimization boolean,
    id_10 integer,
    CONSTRAINT unique_id_serviceprovider UNIQUE (id, service_provider_name),
    CONSTRAINT fk_integration_id FOREIGN KEY (integration_id)
        REFERENCES public.integration (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX idx_serviceprovider_id ON public.serviceprovider USING btree (id);
CREATE INDEX idx_serviceprovider_is_active_is_deleted ON public.serviceprovider USING btree (is_active, is_deleted) WHERE ((is_active = true) AND (is_deleted = false));
CREATE INDEX idx_serviceprovider_tenant_id ON public.serviceprovider USING btree (tenant_id);
CREATE INDEX idx_sp_display_name ON public.serviceprovider USING btree (display_name);
CREATE INDEX idx_sp_id ON public.serviceprovider USING btree (id);
CREATE INDEX idx_sp_integration_id ON public.serviceprovider USING btree (integration_id);
CREATE INDEX idx_sp_is_active_deleted ON public.serviceprovider USING btree (is_active, is_deleted);

CREATE TABLE IF NOT EXISTS public.bandwidthaccount
(
    id serial primary key,
    service_provider_id integer,
    account_id character varying(50)  DEFAULT NULL::character varying,
    global_account_number character varying(50)  DEFAULT NULL::character varying,
    associated_catapult_account character varying(50)  DEFAULT NULL::character varying,
    company_name character varying(50)  DEFAULT NULL::character varying,
    account_type character varying(50)  DEFAULT NULL::character varying,
    billing_cycle integer,
    created_by character varying(128)  DEFAULT NULL::character varying,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(128)  DEFAULT NULL::character varying,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(128)  DEFAULT NULL::character varying,
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    tenant_id integer,
    id_10 int NULL,
    tenant_name character varying(80),
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS public.bandwidth_customers
(
    id serial primary key,
    bandwidth_account_id integer,
    customer_id integer,
    bandwidth_customer_name character varying(50) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    sip_peer_count integer,
    created_by character varying(128) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(128) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(128) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
	id_10 int NULL,
    CONSTRAINT fk_bandwidth_account_id FOREIGN KEY (bandwidth_account_id)
        REFERENCES public.bandwidthaccount (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_bandwidth_site_bandwidth_account_id
    ON public.bandwidth_customers USING btree
    (bandwidth_account_id ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE TABLE IF NOT EXISTS public.billing_period_status
(
    id serial primary key,
    display_name character varying(25) COLLATE pg_catalog."default" NOT NULL,
    display_order integer NOT NULL,
    created_by character varying(100) COLLATE pg_catalog."default" NOT NULL DEFAULT 'System'::character varying,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL DEFAULT true,
    is_deleted boolean DEFAULT false NOT NULL,
	id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.billing_period
(
    id serial primary key,
    service_provider_id integer,
    service_provider character varying(100) COLLATE pg_catalog."default",
    bill_year integer,
    bill_month integer,
    billing_cycle_start_date timestamp without time zone,
    billing_cycle_end_date timestamp without time zone,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    billing_period_status_id integer,
    tenant_id integer,
    id_10 int NULL,
    CONSTRAINT fk_billing_period_status_id FOREIGN KEY (billing_period_status_id)
        REFERENCES public.billing_period_status (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX idx_billing_cycle_end_date ON public.billing_period USING btree (billing_cycle_end_date);
CREATE INDEX idx_billing_period_id ON public.billing_period USING btree (id);
CREATE INDEX idx_billing_period_service_provider_id ON public.billing_period USING btree (service_provider_id);


CREATE TABLE IF NOT EXISTS public.bulk_change_popup_screens
(
    id serial primary key,
    service_provider_id integer,
    service_provider character varying(200) COLLATE pg_catalog."default",
    change_type_id integer,
    change_type character varying(255) COLLATE pg_catalog."default",
    screen_names_seq text COLLATE pg_catalog."default",
    dropdown_fields text COLLATE pg_catalog."default"
);

CREATE TABLE IF NOT EXISTS public.carrier_rate_plan
(
    id serial primary key,
    rate_plan_code character varying(255) COLLATE pg_catalog."default",
    base_rate numeric(25,10),
    plan_mb numeric(25,10),
    overage_rate_cost numeric(25,10),
    surcharge_3g numeric(25,10),
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    rate_charge_amt numeric(25,10),
    display_rate numeric(26,10),
    base_rate_per_mb numeric(38,12),
    is_active boolean,
    is_deleted boolean NULL,
    rate_plan_short_name character varying(255) COLLATE pg_catalog."default",
    jasper_rate_plan_id bigint,
    service_provider_id integer,
    data_per_overage_charge numeric(25,10),
    allows_sim_pooling boolean,
    friendly_name character varying(256) COLLATE pg_catalog."default",
    is_retired boolean,
    amount_with_deal_registration numeric(25,10),
    amount_without_deal_registration numeric(25,10),
    family character varying(100) COLLATE pg_catalog."default",
    device_type character varying(250) COLLATE pg_catalog."default",
    imei_type character varying(250) COLLATE pg_catalog."default",
    os character varying(50) COLLATE pg_catalog."default",
    network character varying(50) COLLATE pg_catalog."default",
    description character varying(500) COLLATE pg_catalog."default",
    plan_uuid character varying(50) COLLATE pg_catalog."default",
    is_exclude_from_optimization boolean,
    optimization_rate_plan_type_id integer,
    default_optimization_group_id integer,
    service_provider character varying(80) COLLATE pg_catalog."default",
    assigned boolean NULL,
	id_10 integer NULL,
    CONSTRAINT unique_id_rate_plan_name UNIQUE (id, rate_plan_code),
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_carrier_rate_plan_id
    ON public.carrier_rate_plan USING btree
    (id ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE TABLE IF NOT EXISTS public.customer_rate_pool
(
    id serial primary key,
    name character varying(200) COLLATE pg_catalog."default",
    service_provider_id integer,
    tenant_id integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    is_active boolean,
    is_deleted boolean NULL,
    service_provider_ids text COLLATE pg_catalog."default",
    service_provider_name varchar COLLATE pg_catalog."default",
    projected_usage character varying COLLATE pg_catalog."default",
    id_10 int NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_customer_rate_pool_id
    ON public.customer_rate_pool USING btree
    (id ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE TABLE IF NOT EXISTS public.customerrateplan
(
    id serial primary key,
    rate_plan_code character varying(50) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    plan_mb numeric(25,10) NOT NULL,
    base_rate numeric(25,10) default 0,
    surcharge_3g numeric(25,10),
    min_plan_data_mb numeric(25,10),
    max_plan_data_mb numeric(25,10),
    created_by character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    rate_plan_name character varying(100) COLLATE pg_catalog."default",
    rate_charge_amt numeric(25,10) NOT NULL,
    display_rate numeric(26,10),
    base_rate_per_mb numeric(38,12),
    is_active boolean,
    is_deleted boolean NULL,
    service_provider_id integer,
    data_per_overage_charge numeric(25,10) NOT NULL,
    overage_rate_cost numeric(25,10) NOT NULL,
    allows_sim_pooling boolean,
    tenant_id integer,
    is_billing_advance_eligible boolean,
    sms_rate numeric(25,10) NOT NULL,
    auto_change_rate_plan boolean,
    serviceproviderids text COLLATE pg_catalog."default",
    service_provider_name character varying(500) COLLATE pg_catalog."default",
    automation_rule character varying(255) COLLATE pg_catalog."default",
    optimization_type character varying COLLATE pg_catalog."default",
    active_inactive_status character varying COLLATE pg_catalog."default",
    soc_code varchar NULL,
	no_tns varchar NULL,
	id_10 int NULL,
	projected_usage_data numeric NULL,
	automation_rule_flag boolean NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_customerrateplan_id
    ON public.customerrateplan USING btree
    (id ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE TABLE IF NOT EXISTS public.netsapiens_reseller
(
    id serial primary key,
    territory_id integer,
    territory character varying(256) COLLATE pg_catalog."default",
    description character varying(1024) COLLATE pg_catalog."default",
    entry_status character varying(50) COLLATE pg_catalog."default",
    smtp_host character varying(512) COLLATE pg_catalog."default",
    smtp_port character varying(50) COLLATE pg_catalog."default",
    smtp_uid character varying(256) COLLATE pg_catalog."default",
    smtp_pwd character varying(256) COLLATE pg_catalog."default",
    users integer,
    domains integer,
    count_for_limit integer,
    count_external integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean default true,
    is_deleted boolean default false,
    can_ignore boolean NOT NULL,
    id_10 int NULL,
    tenant_id integer
);

CREATE TABLE IF NOT EXISTS public.e911customers
(
    id serial primary key,
    account_name character varying(256) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    account_id character varying(255) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
	id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.service_provider_setting (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(50) NOT NULL,
    setting_value TEXT NOT NULL,
    data_type_id INT NOT NULL,
    created_by VARCHAR(100) NOT NULL,
    created_date TIMESTAMP NOT NULL,
    modified_by VARCHAR(100),
    modified_date TIMESTAMP,
    deleted_by VARCHAR(100),
    deleted_date TIMESTAMP,
    service_provider_id INT,
    is_active BOOLEAN NOT NULL default true,
    is_deleted boolean NOT NULL default false,
    id_10 int NULL,
    CONSTRAINT fk_service_provider_setting_service_provider
        FOREIGN KEY (service_provider_id) REFERENCES serviceprovider(id)
);

CREATE TABLE IF NOT EXISTS public.integration_authentication
(
    id serial primary key,
    integration_id integer,
    authentication_type integer,
    username character varying(255) COLLATE pg_catalog."default",
    password character varying(255) COLLATE pg_catalog."default",
    oauth2_authorization_url character varying(255) COLLATE pg_catalog."default",
    oauth2_token_url character varying(255) COLLATE pg_catalog."default",
    oauth2_refresh_url character varying(255) COLLATE pg_catalog."default",
    oauth2_authorization_code character varying(255) COLLATE pg_catalog."default",
    oauth2_authorization_header character varying(255) COLLATE pg_catalog."default",
    oauth2_state character varying(255) COLLATE pg_catalog."default",
    oauth2_scope character varying(255) COLLATE pg_catalog."default",
    oauth2_client_id character varying(255) COLLATE pg_catalog."default",
    oauth2_client_secret character varying(255) COLLATE pg_catalog."default",
    oauth2_access_token text COLLATE pg_catalog."default",
    oauth2_refresh_token character varying(1000) COLLATE pg_catalog."default",
    oauth2_access_token_expires bigint,
    oauth2_refresh_token_expires bigint,
    oauth2_custom1 character varying(255) COLLATE pg_catalog."default",
    oauth2_custom2 character varying(255) COLLATE pg_catalog."default",
    oauth2_custom3 character varying(255) COLLATE pg_catalog."default",
    oauth2_custom4 character varying(255) COLLATE pg_catalog."default",
    token_location character varying(10) COLLATE pg_catalog."default",
    token_variable_name character varying(255) COLLATE pg_catalog."default",
    token_value character varying(255) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    is_active boolean,
    is_deleted boolean NULL,
    tenant_id integer,
    realm_id character varying(50) COLLATE pg_catalog."default",
    service_provider_id integer,
    is_child_tenant boolean,
    rev_bill_profile text COLLATE pg_catalog."default",
    id_10 int NULL,
    CONSTRAINT fk_integration_id FOREIGN KEY (integration_id)
        REFERENCES public.integration (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_ia_id
    ON public.integration_authentication USING btree
    (id ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE TABLE IF NOT EXISTS public.revcustomer
(
    id  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    rev_customer_id character varying(50) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    customer_name character varying(250) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    rev_parent_customer_id character varying(50) COLLATE pg_catalog."default",
    parent_customer_id uuid,
    child_count integer,
    integration_authentication_id integer,
    status character varying(50) COLLATE pg_catalog."default",
    activated_date timestamp without time zone,
    close_date timestamp without time zone,
    tax_exempt_enabled boolean,
    tax_exempt_types character varying COLLATE pg_catalog."default",
    bill_profile_id integer,
    agent_id integer,
    tenant_id integer,
    id_10 uuid NULL,
    CONSTRAINT fk_integration_authentication_id FOREIGN KEY (integration_authentication_id)
        REFERENCES public.integration_authentication (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX idx_r_id ON public.revcustomer USING btree (id);
CREATE INDEX idx_r_status_is_active_deleted ON public.revcustomer USING btree (status, is_active, is_deleted);
CREATE INDEX idx_rev_customer_active_deleted ON public.revcustomer USING btree (rev_customer_id, is_active, is_deleted);
CREATE INDEX idx_revcustomer_active ON public.revcustomer USING btree (rev_customer_id) WHERE (((status)::text <> 'CLOSED'::text) AND (is_active = true) AND (is_deleted = false));
CREATE INDEX idx_revcustomer_active_deleted ON public.revcustomer USING btree (is_active, is_deleted);
CREATE INDEX idx_revcustomer_integration_authentication_id ON public.revcustomer USING btree (integration_authentication_id);
CREATE INDEX idx_revcustomer_is_active ON public.revcustomer USING btree (is_active);
CREATE INDEX idx_revcustomer_is_deleted ON public.revcustomer USING btree (is_deleted);
CREATE INDEX idx_revcustomer_rev_customer_id ON public.revcustomer USING btree (rev_customer_id);
CREATE INDEX idx_revcustomer_status ON public.revcustomer USING btree (status);
CREATE INDEX idx_revcustomer_status_is_active_is_deleted ON public.revcustomer USING btree (status, is_active, is_deleted) WHERE (((status)::text <> 'CLOSED'::text) AND (is_active = true) AND (is_deleted = false));

CREATE TABLE IF NOT EXISTS public.customers
(
    id serial primary key,
    tenant_id integer,
    tenant_name character varying(350) COLLATE pg_catalog."default",
    subtenant_name character varying COLLATE pg_catalog."default",
    customer_id integer,
    customer_name character varying(250) COLLATE pg_catalog."default",
    billing_account_number character varying COLLATE pg_catalog."default",
    customer_rate_plans character varying COLLATE pg_catalog."default",
    customer_bill_period_end_date character varying COLLATE pg_catalog."default",
    customer_bill_period_end_hour integer,
    customer_bill_period_end_day integer,
    apt_suite character varying(20) COLLATE pg_catalog."default",
    address1 character varying(150) COLLATE pg_catalog."default",
    address2 character varying(150) COLLATE pg_catalog."default",
    city character varying(50) COLLATE pg_catalog."default",
    state character varying(50) COLLATE pg_catalog."default",
    postal_code character varying(20) COLLATE pg_catalog."default",
    postal_code_extension character varying(20) COLLATE pg_catalog."default",
    country character varying(100) COLLATE pg_catalog."default",
    rev_customer_id uuid,
    bandwidth_customer_id integer,
    netsapiens_customer_id integer,
    e911_customer_id integer,
    netsapiens_domain_id integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    is_deleted boolean NULL,
    is_active boolean,
    first_name character varying COLLATE pg_catalog."default",
    middle_initial character varying COLLATE pg_catalog."default",
    last_name character varying COLLATE pg_catalog."default",
    company_name character varying COLLATE pg_catalog."default",
    description character varying(1000) COLLATE pg_catalog."default",
    inactivity_start character varying COLLATE pg_catalog."default",
    inactivity_end character varying COLLATE pg_catalog."default",
    county_parish_borough character varying(50) COLLATE pg_catalog."default",
    netsapiens_type character varying(50) COLLATE pg_catalog."default",
    parent_customer_id integer,
    is_system_default boolean,
    status character varying COLLATE pg_catalog."default",
    rev_io_account character varying COLLATE pg_catalog."default",
    bill_profile character varying COLLATE pg_catalog."default",
    parent_customer character varying COLLATE pg_catalog."default",
    service_address boolean,
    service_address_first_name character varying COLLATE pg_catalog."default",
    service_address_middle_initial character varying COLLATE pg_catalog."default",
    service_address_last_name character varying COLLATE pg_catalog."default",
    service_address_company_name character varying COLLATE pg_catalog."default",
    service_address_address_line_1 character varying COLLATE pg_catalog."default",
    service_address_address_line_2 character varying COLLATE pg_catalog."default",
    service_address_city character varying COLLATE pg_catalog."default",
    service_address_state character varying COLLATE pg_catalog."default",
    service_address_postal_code character varying COLLATE pg_catalog."default",
    service_address_postal_code_extension character varying COLLATE pg_catalog."default",
    service_address_country_code character varying COLLATE pg_catalog."default",
    billing_address boolean,
    billing_address_first_name character varying COLLATE pg_catalog."default",
    billing_address_middle_initial character varying COLLATE pg_catalog."default",
    billing_address_last_name character varying COLLATE pg_catalog."default",
    billing_address_company_name character varying COLLATE pg_catalog."default",
    billing_address_address_line_1 character varying COLLATE pg_catalog."default",
    billing_address_address_line_2 character varying COLLATE pg_catalog."default",
    billing_address_city character varying COLLATE pg_catalog."default",
    billing_address_state character varying COLLATE pg_catalog."default",
    billing_address_postal_code character varying COLLATE pg_catalog."default",
    billing_address_postal_code_extension character varying COLLATE pg_catalog."default",
    billing_address_country_code character varying COLLATE pg_catalog."default",
    listing_address boolean,
    listing_address_first_name character varying COLLATE pg_catalog."default",
    listing_address_middle_initial character varying COLLATE pg_catalog."default",
    listing_address_last_name character varying COLLATE pg_catalog."default",
    listing_address_company_name character varying COLLATE pg_catalog."default",
    listing_address_address_line_1 character varying COLLATE pg_catalog."default",
    listing_address_address_line_2 character varying COLLATE pg_catalog."default",
    listing_address_city character varying COLLATE pg_catalog."default",
    listing_address_state character varying COLLATE pg_catalog."default",
    listing_address_postal_code character varying COLLATE pg_catalog."default",
    listing_address_postal_code_extension character varying COLLATE pg_catalog."default",
    listing_address_country_code character varying COLLATE pg_catalog."default",
    use_service_address_as_billing_address boolean,
    use_service_address_as_listing_address boolean,
    id_10 int NULL,
    customer_name_with_revio varchar NULL,
    CONSTRAINT uc_customers1 UNIQUE (tenant_id, rev_customer_id, bandwidth_customer_id, netsapiens_customer_id, e911_customer_id, netsapiens_domain_id, customer_name),
    CONSTRAINT fk_bandwidth_customer FOREIGN KEY (bandwidth_customer_id)
        REFERENCES public.bandwidth_customers (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_e911customer FOREIGN KEY (e911_customer_id)
        REFERENCES public.e911customers (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_revcustomer FOREIGN KEY (rev_customer_id)
        REFERENCES public.revcustomer (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX idx_cust_id ON public.customers USING btree (id);
CREATE INDEX idx_cust_rev_customer_id ON public.customers USING btree (rev_customer_id);
CREATE INDEX idx_customers_bill_period_end_day_hour ON public.customers USING btree (customer_bill_period_end_day, customer_bill_period_end_hour);
CREATE INDEX idx_customers_is_active_deleted ON public.customers USING btree (is_active, is_deleted);
CREATE INDEX idx_customers_name ON public.customers USING btree (customer_name);


CREATE TABLE IF NOT EXISTS public.customergroups
(
    id serial primary key,
    name character varying(200) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    customergroup_id integer,
    tenant_id integer,
    tenant_name character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    subtenant_id integer,
    subtenant_name character varying(100) COLLATE pg_catalog."default",
    child_account character varying(100) COLLATE pg_catalog."default",
    billing_account_number character varying(50) COLLATE pg_catalog."default",
    rate_plan_name character varying COLLATE pg_catalog."default",
    feature_codes character varying COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    is_active boolean,
    is_deleted boolean NULL,
    customer_names character varying COLLATE pg_catalog."default",
    id_10 int NULL,
	notification_rules varchar NULL,
    CONSTRAINT unique_customergroup_tenant UNIQUE (name, tenant_id)
);

CREATE TABLE IF NOT EXISTS public.mobility_feature
(
    id serial primary key,
    soc_code character varying(50) COLLATE pg_catalog."default",
    friendly_name character varying(256) COLLATE pg_catalog."default",
    service_provider_id integer,
    is_retired boolean,
    amount_with_deal_registration numeric(25,4),
    amount_without_deal_registration numeric(25,4),
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    family character varying(100) COLLATE pg_catalog."default",
    service_provider_name varchar NULL,
	id_10 int NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX IF NOT EXISTS idx_mobility_feature_active_retired
    ON public.mobility_feature USING btree
    (id ASC NULLS LAST,is_active ASC NULLS LAST, is_retired ASC NULLS LAST);

CREATE TABLE IF NOT EXISTS public.customer_mobility_feature
(
    id serial primary key,
    service_provider_id integer,
    service_provider character varying(100) COLLATE pg_catalog."default",
    customer_id integer,
    customer_name character varying(255) COLLATE pg_catalog."default",
    mobility_feature_id integer,
    mobility_features text COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default" NOT NULL,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
	id_10 int NULL,
    CONSTRAINT fk_mobility_feature_id FOREIGN KEY (mobility_feature_id)
        REFERENCES public.mobility_feature (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS public.customer_rate_plan_jasper_carrier_rate_plan (
    id SERIAL PRIMARY KEY,
    jasper_carrier_rate_plan_id INTEGER NOT NULL,
    customer_rate_plan_id INTEGER NOT NULL,
    created_by VARCHAR(100) NOT NULL,
    created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by VARCHAR(100),
    modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by VARCHAR(100),
    deleted_date TIMESTAMP,
    is_active BOOLEAN NOT NULL,
    id_10 int NULL,
    CONSTRAINT fk_customer_rate_plan FOREIGN KEY (customer_rate_plan_id)
        REFERENCES public.customerrateplan (id)
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_carrier_rate_plan_id_customer_rate_plan FOREIGN KEY (jasper_carrier_rate_plan_id) REFERENCES public.carrier_rate_plan(id)
);


CREATE TABLE IF NOT EXISTS public.device_status
(
    id serial primary key,
    status character varying(50) COLLATE pg_catalog."default",
    description character varying(50) COLLATE pg_catalog."default",
    status_color character varying(50) COLLATE pg_catalog."default",
    status_color_code character varying(8) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    allows_api_update boolean,
    display_name character varying(50) COLLATE pg_catalog."default",
    integration_id integer,
    is_active_status boolean,
    should_have_billed_service boolean,
    is_restorable_from_archive boolean,
    is_apply_for_automation_rule boolean,
    status_alias character varying(100) COLLATE pg_catalog."default",
    id_10 int NULL,
    CONSTRAINT fk_integration_id FOREIGN KEY (integration_id)
        REFERENCES public.integration (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX idx_device_status_composite ON public.device_status USING btree (id, description) WHERE (lower((description)::text) <> 'suspended'::text);
CREATE INDEX idx_device_status_description ON public.device_status USING btree (description);
CREATE INDEX idx_device_status_device_status_id ON public.device_status USING btree (id);
CREATE INDEX idx_device_status_diplay_name ON public.device_status USING btree (display_name);
CREATE INDEX idx_device_status_display_name_active ON public.device_status USING btree (display_name) WHERE ((display_name)::text = ANY (ARRAY[('RestoredFromArchive'::character varying)::text, ('Restored from archive'::character varying)::text]));
CREATE INDEX idx_device_status_id_is_active ON public.device_status USING btree (id, is_active_status);
CREATE INDEX idx_device_status_integration_id ON public.device_status USING btree (integration_id);
CREATE INDEX idx_device_status_is_active_status ON public.device_status USING btree (is_active_status);
CREATE INDEX idx_device_status_should_have_billed_service ON public.device_status USING btree (should_have_billed_service);
CREATE INDEX idx_ds_id ON public.device_status USING btree (id);
CREATE INDEX idx_ds_status ON public.device_status USING btree (status);


CREATE TABLE IF NOT EXISTS public.sim_management_communication_plan
(
    id serial primary key,
    communication_plan_name character varying(250) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    service_provider_id integer,
    alias_name character varying(250) COLLATE pg_catalog."default",
    tenant_id integer,
    tenant_name character varying(80) COLLATE pg_catalog."default",
    carrier_rate_plans text COLLATE pg_catalog."default",
    service_provider_name character varying(100) COLLATE pg_catalog."default",
    id_10 int NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS public.revagent
(
    id serial primary key,
    rev_agent_id integer,
    agent_name character varying(250) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    created_by character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    parent_agent_id integer,
    status character varying(50) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    integration_authentication_id integer,
    id_10 int NULL
);
CREATE INDEX IF NOT EXISTS idx_rev_agent_rev_agent_id
    ON public.revagent USING btree
    (rev_agent_id ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE TABLE IF NOT EXISTS public.revbillprofile
(
    id serial primary key,
    bill_profile_id integer,
    description character varying(1024) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp with time zone,
    is_active boolean,
    is_deleted boolean NULL,
    integration_authentication_id integer,
    tenant_name varchar NULL,
	tenant_id int NULL,
	id_10 int NULL
);
CREATE INDEX IF NOT EXISTS idx_rev_bill_profile_bill_profile_id
    ON public.revbillprofile USING btree
    (bill_profile_id ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE TABLE IF NOT EXISTS public.rev_provider
(
    id serial primary key,
    provider_id integer,
    description character varying(1024) COLLATE pg_catalog."default",
    bill_profile_id integer,
    provider_code character varying(64) COLLATE pg_catalog."default",
    has_cnam_order_type boolean,
    has_conversion_order_type boolean,
    has_deny_order_type boolean,
    has_disconnect_order_type boolean,
    has_e911_order_type boolean,
    has_long_distance_block_order_type boolean,
    has_port_order_type boolean,
    has_restore_order_type boolean,
    has_transfer_order_type boolean,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    integration_authentication_id integer,
    rev_bill_profile_id integer,
    service_provider_id integer,
    service_provider character varying(100) COLLATE pg_catalog."default",
    tenant_id integer,
    id_10 int NULL,
    CONSTRAINT fk_revprovider_integration_authentication FOREIGN KEY (integration_authentication_id)
        REFERENCES public.integration_authentication (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_revprovider_revbillprofile FOREIGN KEY (rev_bill_profile_id)
        REFERENCES public.revbillprofile (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE TABLE IF NOT EXISTS public.rev_service_type
(
    id serial primary key,
    service_type_id integer,
    description character varying(1024) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    integration_authentication_id integer,
    service_provider_id integer,
    service_provider character varying(100) COLLATE pg_catalog."default",
    tenant_id integer,
    id_10 integer NULL,
    CONSTRAINT fk_revservicetype_integrationauthenticationid FOREIGN KEY (integration_authentication_id)
        REFERENCES public.integration_authentication (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX idx_rev_service_type_id ON public.rev_service_type USING btree (id);
CREATE INDEX idx_rev_service_type_id_integration_authentication_id ON public.rev_service_type USING btree (service_type_id, integration_authentication_id);
CREATE INDEX idx_rev_service_type_id_integration_id ON public.rev_service_type USING btree (id, integration_authentication_id);
CREATE INDEX idx_rev_service_type_integration_authentication_id ON public.rev_service_type USING btree (integration_authentication_id);
CREATE INDEX idx_rev_service_type_service_type_id ON public.rev_service_type USING btree (service_type_id);
CREATE INDEX idx_rev_service_type_service_type_id_description ON public.rev_service_type USING btree (service_type_id, description) WHERE ((service_type_id IS NULL) OR (service_type_id = 18));


CREATE TABLE IF NOT EXISTS public.rev_usage_plan_group
(
    id serial primary key,
    usage_plan_group_id integer,
    description character varying(256) COLLATE pg_catalog."default",
    long_description text COLLATE pg_catalog."default",
    rev_active boolean,
    rev_created_by integer,
    rev_created_date timestamp without time zone,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    integration_authentication_id integer,
    id_10 int NULL,
    CONSTRAINT fk_revusageplangroup_integrationauthentication FOREIGN KEY (integration_authentication_id)
        REFERENCES public.integration_authentication (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.rev_service
(
    id serial primary key,
    rev_customer_id uuid,
    "number" character varying(250) COLLATE pg_catalog."default",
    rev_service_id integer,
    rate_plan_code character varying(255) COLLATE pg_catalog."default",
    activated_date character varying(50) COLLATE pg_catalog."default",
    disconnected_date character varying(50) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    integration_authentication_id integer,
    rev_provider_id integer,
    rev_service_type_id integer,
    rev_usage_plan_group_id integer,
    description text COLLATE pg_catalog."default",
    pro_rate boolean,
    id_10 int NULL,
	rev_service_line_status varchar(250) NULL,
	bulk_change_id int NULL,
    CONSTRAINT fk_revservice_integration_authentication FOREIGN KEY (integration_authentication_id)
        REFERENCES public.integration_authentication (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_revservice_revcustomer FOREIGN KEY (rev_customer_id)
        REFERENCES public.revcustomer (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_revservice_revprovider FOREIGN KEY (rev_provider_id)
        REFERENCES public.rev_provider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_revservice_revservicetype FOREIGN KEY (rev_service_type_id)
        REFERENCES public.rev_service_type (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_revservice_revusageplangroup FOREIGN KEY (rev_usage_plan_group_id)
        REFERENCES public.rev_usage_plan_group (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX idx_rev_service_active ON public.rev_service USING btree (rev_service_id) WHERE (is_active = true);
CREATE INDEX idx_rev_service_composite ON public.rev_service USING btree (rev_service_id, integration_authentication_id);
CREATE INDEX idx_rev_service_id ON public.rev_service USING btree (id);
CREATE INDEX idx_rev_service_integration_authentication_id ON public.rev_service USING btree (integration_authentication_id);
CREATE INDEX idx_rev_service_rev_service_type_id ON public.rev_service USING btree (rev_service_type_id);
CREATE INDEX idx_rev_service_service_id_integration_authentication_id ON public.rev_service USING btree (rev_service_id, integration_authentication_id);
CREATE INDEX idx_rs_activated_date ON public.rev_service USING btree (activated_date);
CREATE INDEX idx_rs_rev_service_id ON public.rev_service USING btree (rev_service_id);
CREATE INDEX ix_rev_service_rev_customer_id ON public.rev_service USING btree (rev_customer_id) INCLUDE (disconnected_date, integration_authentication_id, rate_plan_code, rev_service_id);
CREATE INDEX ix_rev_service_rev_service_id ON public.rev_service USING btree (rev_service_id) INCLUDE (number, rev_service_type_id);


CREATE TABLE public.device (
	id serial primary key,
	service_provider_id int4 NOT NULL,
	iccid varchar(50) NOT NULL,
	imsi varchar(150) NULL,
	msisdn varchar(150) NULL,
	imei varchar(150) NULL,
	eid varchar(50) NULL,
	device_status_id int4 NULL,
	sim_status varchar(50) NULL,
	carrier_rate_plan_id int4 NULL,
	carrier_rate_plan varchar(255) NULL,
	communication_plan varchar(255) NULL,
	last_usage_date timestamp NULL,
	apn varchar(250) NULL,
	package varchar(250) NULL,
	billing_cycle_end_date timestamp NULL,
	carrier_cycle_usage int8 NULL,
	ctd_sms_usage int8 NULL,
	ctd_voice_usage int8 NULL,
	ctd_session_count int8 NULL,
	overage_limit_reached bool NULL,
	overage_limit_override varchar(50) NULL,
	created_by varchar(100) NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
	modified_by varchar(100) NULL,
	modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
	last_activated_date timestamp NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_active bool NOT NULL,
	date_added timestamp NULL,
	date_activated timestamp NULL,
	delta_ctd_data_usage int8 NULL,
	cost_center varchar(250) NULL,
	username varchar(250) NULL,
	billing_period_id int4 NULL,
	device_description text NULL,
	ip_address varchar(50) NULL,
	service_provider_name varchar(300) NULL,
	customer_cycle_usage int8 NULL,
	soc varchar NULL,
	id_10 int4 NULL,
	is_deleted bool NULL,
	smi_id int4 NULL,
	updated_from_smi varchar NULL,
	CONSTRAINT fk_billing_period_id FOREIGN KEY (billing_period_id) REFERENCES public.billing_period(id),
	CONSTRAINT fk_carrier_rate_plan_id FOREIGN KEY (carrier_rate_plan_id) REFERENCES public.carrier_rate_plan(id),
	CONSTRAINT fk_device_status_id FOREIGN KEY (device_status_id) REFERENCES public.device_status(id) ON UPDATE CASCADE,
	CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id) REFERENCES public.serviceprovider(id)
);
CREATE INDEX idx1_modified_date ON public.device USING btree (modified_date);
CREATE INDEX idx_device_carrier_cycle_usage ON public.device USING btree (carrier_cycle_usage);
CREATE INDEX idx_device_device_status_id ON public.device USING btree (device_status_id);
CREATE INDEX idx_device_iccid ON public.device USING btree (iccid);
CREATE INDEX idx_device_iccid_msisdn_eid ON public.device USING btree (iccid, msisdn, eid);
CREATE INDEX idx_device_id ON public.device USING btree (id);
CREATE INDEX idx_device_is_active ON public.device USING btree (is_active) WHERE (is_active = true);
CREATE INDEX idx_device_is_active_is_deleted ON public.device USING btree (is_active, is_deleted) WHERE ((is_active = true) AND (is_deleted = false));
CREATE INDEX idx_device_last_activated_date ON public.device USING btree (last_activated_date);
CREATE INDEX idx_device_msisdn ON public.device USING btree (msisdn);
CREATE INDEX idx_device_service_provider_id ON public.device USING btree (service_provider_id);
CREATE INDEX idx_device_status_id ON public.device USING btree (device_status_id);
CREATE INDEX ix_device_serviceprovider_accountnumber_billyear_billmonth_icci ON public.device USING btree (iccid, service_provider_id);
CREATE INDEX ix_device_serviceproviderid_accountnumber ON public.device USING btree (service_provider_id) INCLUDE (communication_plan, created_date, device_status_id, iccid, id, last_activated_date, msisdn);


CREATE TABLE IF NOT EXISTS public.mobility_device
(
    id serial primary key,
    service_provider_id integer,
    foundation_account_number character varying(30) COLLATE pg_catalog."default",
    billing_account_number character varying(30) COLLATE pg_catalog."default",
    iccid character varying(50) COLLATE pg_catalog."default",
    imsi character varying(150) COLLATE pg_catalog."default",
    msisdn character varying(150) COLLATE pg_catalog."default",
    imei character varying(150) COLLATE pg_catalog."default",
    device_status_id integer,
    sim_status character varying(50) COLLATE pg_catalog."default",
    carrier_rate_plan_id integer,
    carrier_rate_plan character varying(200) COLLATE pg_catalog."default",
    last_usage_date timestamp without time zone,
    carrier_cycle_usage bigint,
    ctd_sms_usage bigint,
    ctd_voice_usage bigint,
    ctd_session_count bigint,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    last_activated_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
    date_added timestamp without time zone,
    date_activated timestamp without time zone,
    delta_ctd_data_usage bigint,
    billing_period_id integer,
    single_user_code character varying(200) COLLATE pg_catalog."default",
    single_user_code_description character varying(200) COLLATE pg_catalog."default",
    service_zip_code character varying(50) COLLATE pg_catalog."default",
    next_bill_cycle_date timestamp without time zone,
    sms_count integer,
    minutes_used integer,
    data_group_id character varying(50) COLLATE pg_catalog."default",
    pool_id character varying(50) COLLATE pg_catalog."default",
    device_make character varying(50) COLLATE pg_catalog."default",
    device_model character varying(50) COLLATE pg_catalog."default",
    contract_status character varying(50) COLLATE pg_catalog."default",
    ban_status character varying(50) COLLATE pg_catalog."default",
    imei_type_id integer,
    plan_limit_mb numeric(25,4),
    username character varying(150) COLLATE pg_catalog."default",
    technology_type character varying(50) COLLATE pg_catalog."default",
    ip_address character varying(50) COLLATE pg_catalog."default",
    optimization_group_id integer,
    cost_center_1 character varying(250) COLLATE pg_catalog."default",
    soc character varying COLLATE pg_catalog."default",
    id_10 int NULL,
    rev_vw_device_status varchar NULL,
	smi_id int NULL,
	updated_from_smi boolean NULL,
	amop_username varchar(150) NULL
);
CREATE INDEX ix_mobility_d_iccid ON public.mobility_device USING btree (iccid);
CREATE INDEX ix_mobility_device_carrier_rate_plan_id ON public.mobility_device USING btree (carrier_rate_plan_id);
CREATE INDEX ix_mobility_device_device_status_id ON public.mobility_device USING btree (device_status_id);
CREATE INDEX ix_mobility_device_iccid_service_provider ON public.mobility_device USING btree (iccid, service_provider_id);
CREATE INDEX ix_mobility_device_id ON public.mobility_device USING btree (id);
CREATE INDEX ix_mobility_device_msisdn ON public.mobility_device USING btree (msisdn) INCLUDE (is_active, is_deleted);
CREATE INDEX ix_mobility_device_service_provider_billing_period_iccid ON public.mobility_device USING btree (iccid, service_provider_id, billing_period_id);
CREATE INDEX ix_mobility_device_service_provider_id_includes ON public.mobility_device USING btree (service_provider_id) INCLUDE (created_date, device_status_id, iccid, id, last_activated_date, msisdn);


CREATE TABLE IF NOT EXISTS public.device_tenant
(
    id serial primary key,
    device_id integer NOT NULL,
    tenant_id integer NOT NULL,
    rev_service_id integer,
    customer_rate_plan_id integer,
    customer_data_allocation_mb numeric(25,4),
    customer_rate_pool_id integer,
    account_number character varying(50) COLLATE pg_catalog."default",
    customer_id integer,
    account_number_integration_authentication_id integer,
    created_by character varying(100) default 'system'::character varying COLLATE pg_catalog."default",
    created_date timestamp without time zone default current_timestamp,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
    customer_rate_pool_name character varying(300) COLLATE pg_catalog."default",
    customer_rate_plan_name character varying(300) COLLATE pg_catalog."default",
    customer_name character varying COLLATE pg_catalog."default",
    bulk_change_id int NULL,
	rev_line_status varchar(250) NULL,
    id_10 int NULL,
    CONSTRAINT device_tenant_device_id_tenant_id_key UNIQUE (device_id, tenant_id)
);
CREATE INDEX idx_device_tenant ON public.device_tenant USING btree (tenant_id);
CREATE INDEX idx_device_tenant_customer_id ON public.device_tenant USING btree (customer_id);
CREATE INDEX idx_device_tenant_device_customer ON public.device_tenant USING btree (device_id, customer_id);
CREATE INDEX idx_device_tenant_device_id_tenant_id ON public.device_tenant USING btree (device_id, tenant_id) WHERE (is_active IS TRUE);
CREATE INDEX idx_device_tenant_device_rev_service ON public.device_tenant USING btree (device_id, rev_service_id) WHERE (is_deleted = false);
CREATE INDEX idx_device_tenant_did_deleted_false ON public.device_tenant USING btree (device_id) WHERE (is_deleted = false);
CREATE INDEX idx_device_tenant_is_active ON public.device_tenant USING btree (is_active) WHERE (is_active = true);
CREATE INDEX idx_device_tenant_is_deleted ON public.device_tenant USING btree (is_deleted);
CREATE INDEX idx_device_tenant_rev_service_id ON public.device_tenant USING btree (rev_service_id);
CREATE INDEX idx_device_tenant_tenant_device ON public.device_tenant USING btree (tenant_id, device_id);
CREATE INDEX idx_device_tenant_tenant_id_is_active ON public.device_tenant USING btree (tenant_id, is_active);
CREATE INDEX idx_dt_customer_rate_plan_id ON public.device_tenant USING btree (customer_rate_plan_id);
CREATE INDEX idx_dt_customer_rate_pool_id ON public.device_tenant USING btree (customer_rate_pool_id);
CREATE INDEX ix_device_tenant_customer_rate_plan_id_device_id ON public.device_tenant USING btree (customer_rate_plan_id, device_id);
CREATE INDEX ix_device_tenant_customer_rate_pool_id ON public.device_tenant USING btree (customer_rate_pool_id) INCLUDE (customer_data_allocation_mb, customer_rate_plan_id, device_id);
CREATE INDEX ix_device_tenant_device_id ON public.device_tenant USING btree (device_id) INCLUDE (account_number, customer_rate_plan_id, customer_id);
CREATE INDEX ix_device_tenant_site_id ON public.device_tenant USING btree (customer_id) INCLUDE (account_number, customer_rate_plan_id, device_id);


CREATE TABLE IF NOT EXISTS public.mobility_device_tenant
(
    id serial primary key ,
    mobility_device_id integer NOT NULL,
    tenant_id integer NOT NULL,
    rev_service_id integer,
    customer_rate_plan_id integer,
    customer_data_allocation_mb numeric(25,4),
    customer_rate_pool_id integer,
    account_number character varying(50) ,
    customer_id integer,
	customer_name varchar,
    account_number_integration_authentication_id integer,
    created_by character varying(100) ,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted boolean NOT NULL default false,
    service_provider_name character varying(300) ,
    customer_rate_plan_name character varying(300),
    customer_rate_pool_name character varying(300),
    bulk_change_id int NULL,
	rev_line_status varchar(250) NULL,
    id_10 int NULL
);
CREATE INDEX idx_mobility_device_tenant__plan_id_mobility_device_id_id ON public.mobility_device_tenant USING btree (customer_rate_plan_id, mobility_device_id, id);
CREATE INDEX idx_mobility_device_tenant_customer_id_rate_plan_id ON public.mobility_device_tenant USING btree (customer_id, customer_rate_plan_id);
CREATE INDEX idx_mobility_device_tenant_customer_rate_pool_id ON public.mobility_device_tenant USING btree (customer_rate_pool_id) INCLUDE (customer_data_allocation_mb, customer_rate_plan_id, mobility_device_id);
CREATE INDEX idx_mobility_device_tenant_device_id ON public.mobility_device_tenant USING btree (mobility_device_id);
CREATE INDEX idx_mobility_device_tenant_id ON public.mobility_device_tenant USING btree (mobility_device_id, tenant_id);
CREATE INDEX idx_mobility_device_tenant_is_deleted ON public.mobility_device_tenant USING btree (is_deleted);
CREATE INDEX idx_mobility_device_tenant_rev_service_id ON public.mobility_device_tenant USING btree (rev_service_id);
CREATE INDEX idx_mobility_device_tenant_tenant_id ON public.mobility_device_tenant USING btree (tenant_id);
CREATE INDEX idx_mobility_device_tenant_tenant_id_customer_rate_pool_id ON public.mobility_device_tenant USING btree (tenant_id, customer_rate_pool_id) INCLUDE (customer_data_allocation_mb, customer_rate_plan_id, mobility_device_id);

CREATE TABLE public.sim_management_inventory (
	id serial4 NOT NULL,
	device_id int4 NULL,
	mobility_device_id int4 NULL,
	dt_id int4 NULL,
	mdt_id int4 NULL,
	service_provider_id int4 NULL,
	service_provider_display_name varchar(100) NULL,
	integration_id int4 NULL,
	billing_account_number varchar(30) NULL,
	foundation_account_number varchar(30) NULL,
	iccid varchar(50) NULL,
	imsi varchar(150) NULL,
	msisdn varchar(150) NULL,
	imei varchar(150) NULL,
	eid varchar(50) NULL,
	customer_id int4 NULL,
	customer_name varchar(350) NULL,
	parent_customer_id int4 NULL,
	rev_customer_id varchar(50) NULL,
	rev_customer_name varchar(250) NULL,
	rev_parent_customer_id varchar NULL,
	device_status_id int4 NULL,
	sim_status varchar(50) NULL,
	carrier_cycle_usage_bytes int8 NULL,
	carrier_cycle_usage_mb numeric NULL,
	date_added timestamp NULL,
	date_activated timestamp NULL,
	account_number varchar(50) NULL,
	carrier_rate_plan_id int4 NULL,
	carrier_rate_plan_name varchar(200) NULL,
	communication_plan_id int4 NULL,
	communication_plan varchar(255) NULL,
	customer_cycle_usage_mb numeric NULL,
	customer_rate_pool_id int4 NULL,
	customer_rate_pool_name varchar(200) NULL,
	customer_rate_plan_id int4 NULL,
	customer_rate_plan_name varchar(100) NULL,
	customer_rate_plan_code varchar(50) NULL,
	sms_count int4 NULL,
	minutes_used int4 NULL,
	username varchar(150) NULL,
	is_active_status bool NULL,
	tenant_id int4 NULL,
	ip_address varchar(50) NULL,
	service_zip_code varchar(50) NULL,
	rate_plan_soc varchar(200) NULL,
	rate_plan_soc_description varchar(200) NULL,
	data_group_id varchar(50) NULL,
	pool_id varchar NULL,
	next_bill_cycle_date timestamp NULL,
	device_make varchar(50) NULL,
	device_model varchar(50) NULL,
	contract_status varchar(50) NULL,
	ban_status varchar(50) NULL,
	imei_type_id int4 NULL,
	plan_limit_mb numeric(25, 4) NULL,
	customer_data_allocation_mb numeric(25, 4) NULL,
	billing_cycle_start_date timestamp NULL,
	billing_cycle_end_date timestamp NULL,
	customer_rate_plan_mb int8 NULL,
	customer_rate_plan_allows_sim_pooling bool NULL,
	carrier_rate_plan_mb int8 NULL,
	telegence_features text NULL,
	ebonding_features text NULL,
	effective_date timestamp NULL,
	last_usage_date timestamp NULL,
	created_by varchar(100) NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
	modified_by varchar(100) NULL,
	modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
	last_activated_date timestamp NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_active bool NULL,
	cost_center varchar(255) NULL,
	last_used_date timestamp NULL,
	soc varchar NULL,
	billing_period_id int4 NULL,
	ctd_sms_usage int8 NULL,
	ctd_session_count int8 NULL,
	rev_service_id int4 NULL,
	package varchar NULL,
	overage_limit_reached bool NULL,
	rev_vw_device_status varchar NULL,
	overage_limit_override varchar NULL,
	delta_ctd_data_usage int8 NULL,
	ctd_voice_usage int4 NULL,
	account_number_integration_authentication_id int4 NULL,
	technology_type varchar NULL,
	optimization_group_id int4 NULL,
	device_description text NULL,
	carrier_rate_plan_display_rate numeric NULL,
	tenant_is_active bool NULL,
	is_deleted bool NULL,
	tenant_is_deleted bool NULL,
	rev_line_status varchar NULL,
	bulk_change_id int8 NULL,
	display_rate numeric NULL,
	carrier_cycle_usage_mb_new numeric NULL,
	subscription_id varchar(242) NULL,
	bill_year int4 NULL,
	bill_month int4 NULL,
	sub_tenant_customer_rate_plan_name varchar NULL,
	sub_tenant_carrier_rate_plan_name varchar NULL,
	CONSTRAINT sim_management_inventory_pkey PRIMARY KEY (id),
	CONSTRAINT smi_device_tenant_device_id_tenant_id_key UNIQUE (dt_id, device_id),
	CONSTRAINT smi_mob_device_tenant_device_id_tenant_id_key UNIQUE (mdt_id, mobility_device_id)
);
CREATE INDEX dummy_is_active_modified_date_desc ON public.sim_management_inventory USING btree (tenant_is_active, modified_date DESC);
CREATE INDEX dummy_smi_device_status_id ON public.sim_management_inventory USING btree (device_status_id);
CREATE INDEX dummy_smi_iccid ON public.sim_management_inventory USING btree (iccid);
CREATE INDEX dummy_smi_is_active_is_deleted ON public.sim_management_inventory USING btree (tenant_is_active, tenant_is_deleted);
CREATE INDEX dummy_smi_is_deleted ON public.sim_management_inventory USING btree (tenant_is_deleted);
CREATE INDEX dummy_smi_last_activated_date ON public.sim_management_inventory USING btree (last_activated_date);
CREATE INDEX dummy_smi_mobility_device_id ON public.sim_management_inventory USING btree (mobility_device_id);
CREATE INDEX dummy_smi_msisdn_service_provider ON public.sim_management_inventory USING btree (msisdn, service_provider_id);
CREATE INDEX dummy_smi_service_provider_id ON public.sim_management_inventory USING btree (service_provider_id);
CREATE INDEX in1xdummy_smi_customer_rate_plan_id ON public.sim_management_inventory USING btree (customer_rate_plan_id);
CREATE INDEX ind1x_isactive_dummy ON public.sim_management_inventory USING btree (tenant_is_active);
CREATE INDEX ind1x_sim_management_dummy_composite ON public.sim_management_inventory USING btree (mobility_device_id, service_provider_id, tenant_is_deleted);
CREATE INDEX ind1x_sim_management_dummy_device_iccid ON public.sim_management_inventory USING btree (device_id, iccid);
CREATE INDEX ind1x_sim_management_dummy_last_activated_date ON public.sim_management_inventory USING btree (last_activated_date);
CREATE INDEX ind1x_sim_management_dummy_mid_active ON public.sim_management_inventory USING btree (mobility_device_id) WHERE ((tenant_is_deleted = false) AND (tenant_is_active = true));
CREATE INDEX ind1x_sim_management_dummy_modified_date ON public.sim_management_inventory USING btree (modified_date DESC);
CREATE INDEX ind1x_sim_management_dummy_service_provider_billing_period ON public.sim_management_inventory USING btree (service_provider_id, billing_period_id);
CREATE INDEX ind1x_sim_management_dummy_sim_status ON public.sim_management_inventory USING btree (sim_status);
CREATE INDEX ind1x_sim_mgmt_dummy_date_activated ON public.sim_management_inventory USING btree (date_activated);
CREATE INDEX ind1x_smi_dummy_carrier_rate_plan_id ON public.sim_management_inventory USING btree (carrier_rate_plan_id);
CREATE INDEX indx_is_active_modified_date_desc ON public.sim_management_inventory USING btree (is_active, modified_date DESC);
CREATE INDEX indx_isactive ON public.sim_management_inventory USING btree (is_active);
CREATE INDEX indx_sim_management_inventory_composite ON public.sim_management_inventory USING btree (mobility_device_id, service_provider_id);
CREATE INDEX indx_sim_management_inventory_device_iccid ON public.sim_management_inventory USING btree (device_id, iccid);
CREATE INDEX indx_sim_management_inventory_device_status_id ON public.sim_management_inventory USING btree (device_status_id);
CREATE INDEX indx_sim_management_inventory_iccid ON public.sim_management_inventory USING btree (iccid);
CREATE INDEX indx_sim_management_inventory_last_activated_date ON public.sim_management_inventory USING btree (last_activated_date);
CREATE INDEX indx_sim_management_inventory_mid_active ON public.sim_management_inventory USING btree (mobility_device_id) WHERE (is_active = true);
CREATE INDEX indx_sim_management_inventory_modified_date ON public.sim_management_inventory USING btree (modified_date DESC);
CREATE INDEX indx_sim_management_inventory_service_provider_billing_period ON public.sim_management_inventory USING btree (service_provider_id, billing_period_id);
CREATE INDEX indx_sim_management_inventory_sim_status ON public.sim_management_inventory USING btree (sim_status);
CREATE INDEX indx_sim_mgmt_inventory_date_activated ON public.sim_management_inventory USING btree (date_activated);
CREATE INDEX indx_smi_carrier_rate_plan_id ON public.sim_management_inventory USING btree (carrier_rate_plan_id);
CREATE INDEX indx_smi_customer_rate_plan_id ON public.sim_management_inventory USING btree (customer_rate_plan_id);
CREATE INDEX indx_smi_device_id ON public.sim_management_inventory USING btree (device_id);
CREATE INDEX indx_smi_device_status_id ON public.sim_management_inventory USING btree (device_status_id);
CREATE INDEX indx_smi_iccid ON public.sim_management_inventory USING btree (iccid);
CREATE INDEX indx_smi_is_active ON public.sim_management_inventory USING btree (is_active);
CREATE INDEX indx_smi_last_activated_date ON public.sim_management_inventory USING btree (last_activated_date);
CREATE INDEX indx_smi_mobility_device_id ON public.sim_management_inventory USING btree (mobility_device_id);
CREATE INDEX indx_smi_msisdn_service_provider ON public.sim_management_inventory USING btree (msisdn, service_provider_id);
CREATE INDEX indx_smi_service_provider_id ON public.sim_management_inventory USING btree (service_provider_id);
CREATE INDEX inx_sim_management_dummy_device_id ON public.sim_management_inventory USING btree (device_id);
CREATE INDEX ix_sim_management_inventory_device_id ON public.sim_management_inventory USING btree (device_id);


CREATE TABLE IF NOT EXISTS public.service_provider_tenant_configuration
(
    id serial primary key,
    service_provider_id integer,
    tenant_id integer,
    rev_product_type_id integer,
    created_by character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    sms_rev_product_type_id integer,
    overage_rev_product_type_id integer,
    rev_product_id integer,
    sms_rev_product_id integer,
    overage_rev_product_id integer,
    service_provider_name character varying(80) COLLATE pg_catalog."default",
    id_10 int NULL,
    CONSTRAINT uc_serviceprovidertenantconfiguration_serviceprovider_tenant UNIQUE (service_provider_id, tenant_id),
    CONSTRAINT fk_serviceprovidertenantconfiguration_serviceprovider FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS public.sim_management_bulk_change_type
(
    id serial primary key,
    code character varying(50) COLLATE pg_catalog."default",
    display_name character varying(100) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    id_10 int NULL,
    CONSTRAINT unique_id_sim_management_bulk_change_type UNIQUE (id, display_name)
);

CREATE TABLE public.sim_management_bulk_change (
	id bigserial primary key,
	service_provider_id int4 NULL,
	service_provider varchar(80) NULL,
	tenant_id int4 NULL,
	change_request_type_id int4 NULL,
	change_request_type varchar(255) NULL,
	status varchar(50) NULL,
	uploaded int4 NULL,
	customer_id int4 NULL,
	customer_name varchar(255) NULL,
	app_file_id int4 NULL,
	processed_date timestamp NULL,
	processed_by varchar(50) NULL,
	created_by varchar(100) NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
	modified_by varchar(100) NULL,
	modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_active bool NULL,
	errors int4 NULL,
	success int4 NULL,
	id_10 int4 NULL,
	is_deleted bool NULL,
	error_msg varchar NULL,
	bulk_change_id_10 int8 NULL,
	service_number varchar NULL,
	progress varchar DEFAULT 'Sync Yet To Start'::character varying NULL,
	readme_flag bool NULL,
	live_progress_percentage int4 NULL,
	CONSTRAINT fk_devicebulkchange_changerequesttype FOREIGN KEY (change_request_type_id) REFERENCES public.sim_management_bulk_change_type(id) ON DELETE SET NULL,
	CONSTRAINT fk_devicebulkchange_serviceprovider FOREIGN KEY (service_provider_id) REFERENCES public.serviceprovider(id) ON DELETE SET NULL
);
CREATE INDEX ix_device_bulk_change_change_request ON public.sim_management_bulk_change USING btree (id);
CREATE INDEX ix_device_bulk_change_change_request_type ON public.sim_management_bulk_change USING btree (change_request_type);
CREATE INDEX ix_device_bulk_change_change_request_type_id ON public.sim_management_bulk_change USING btree (change_request_type_id);


CREATE TABLE IF NOT EXISTS public.m2m_device_change
(
    id bigserial primary key,
    bulk_change_id bigint NOT NULL,
    iccid character varying(50) COLLATE pg_catalog."default" NOT NULL,
    msisdn character varying(50) COLLATE pg_catalog."default",
    ip_address character varying(50) COLLATE pg_catalog."default",
    change_request text COLLATE pg_catalog."default",
    device_id integer,
    is_processed boolean NOT NULL,
    has_errors boolean NOT NULL,
    status character varying(50) COLLATE pg_catalog."default" NOT NULL,
    status_details text COLLATE pg_catalog."default",
    processed_date timestamp with time zone,
    processed_by character varying(50) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default" NOT NULL,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp with time zone,
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
    device_change_request_id bigint,
    id_10 int NULL
);
CREATE INDEX IF NOT EXISTS idx_m2m_device_change_bulkchangeid
    ON public.m2m_device_change USING btree
    (bulk_change_id ASC NULLS LAST)
    INCLUDE(device_change_request_id, device_id, iccid, is_processed, status)
    TABLESPACE pg_default;

CREATE TABLE IF NOT EXISTS public.mobility_device_change
(
    id bigserial primary key,
    bulk_change_id bigint NOT NULL,
    subscriber_number character varying(50) COLLATE pg_catalog."default",
    change_request text COLLATE pg_catalog."default",
    device_id integer,
    is_processed boolean NOT NULL,
    has_errors boolean NOT NULL,
    status character varying(50) COLLATE pg_catalog."default" NOT NULL,
    status_details text COLLATE pg_catalog."default",
    processed_date timestamp with time zone,
    processed_by character varying(50) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default" NOT NULL,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp with time zone,
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
    iccid character varying(50) COLLATE pg_catalog."default",
    additional_step_status character varying(50) COLLATE pg_catalog."default",
    additional_step_details text COLLATE pg_catalog."default",
    ip_address character varying(50) COLLATE pg_catalog."default",
    device_change_request_id bigint,
    id_10 int NULL
);
CREATE INDEX IF NOT EXISTS idx_mobility_device_change_bulkchangeid
    ON public.mobility_device_change USING btree
    (bulk_change_id ASC NULLS LAST)
    INCLUDE(device_change_request_id, iccid, is_processed, status, subscriber_number)
    TABLESPACE pg_default;

CREATE TABLE IF NOT EXISTS public.sim_management_bulk_change_request
(
    id bigserial primary key,
    m2m_id integer,
    mobility_id integer,
    bulk_change_id bigint,
    iccid character varying(60) COLLATE pg_catalog."default",
    msisdn character varying(60) COLLATE pg_catalog."default",
    subscriber_number character varying(50) COLLATE pg_catalog."default",
    ip_address character varying(60) COLLATE pg_catalog."default",
    change_request text COLLATE pg_catalog."default",
    device_id integer,
    sim_management_inventory_id integer,
    is_processed boolean,
    has_errors boolean,
    status character varying(50) COLLATE pg_catalog."default",
    status_details text COLLATE pg_catalog."default",
    processed_date timestamp without time zone,
    processed_by character varying(50) COLLATE pg_catalog."default",
    created_by character varying(50) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(50) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    device_change_request_id integer,
    additional_step_status character varying(50) COLLATE pg_catalog."default",
    additional_step_details text COLLATE pg_catalog."default",
    tenant_id integer,
    tenant_name character varying(50) COLLATE pg_catalog."default",
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    uploaded character varying COLLATE pg_catalog."default",
    errors character varying COLLATE pg_catalog."default",
    sucess character varying COLLATE pg_catalog."default",
    id_10 int NULL,
    service_number varchar NULL,
    CONSTRAINT fk_bulk_change_id FOREIGN KEY (bulk_change_id)
        REFERENCES public.sim_management_bulk_change (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX idx_smi_m2m_device_change_bulkchangeid ON public.sim_management_bulk_change_request USING btree (bulk_change_id) INCLUDE (device_change_request_id, device_id, iccid, is_processed, status);
CREATE INDEX idx_smimobility_device_change_bulkchangeid ON public.sim_management_bulk_change_request USING btree (bulk_change_id) INCLUDE (device_change_request_id, iccid, is_processed, status, subscriber_number);


CREATE TABLE IF NOT EXISTS public.sim_management_bulk_change_log
(
    id bigserial primary key,
    bulk_change_id bigint,
    bulk_change_request_id bigint,
    m2m_device_change_id bigint,
    mobility_device_change_id bigint,
    lnp_device_change_id bigint,
    log_entry_description text COLLATE pg_catalog."default",
    request_text text COLLATE pg_catalog."default",
    has_errors boolean,
    response_status character varying(50) COLLATE pg_catalog."default",
    response_text text COLLATE pg_catalog."default",
    error_text text COLLATE pg_catalog."default",
    processed_date timestamp without time zone,
    processed_by character varying(50) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    id_10 int NULL,
    CONSTRAINT fk_bulk_change_id FOREIGN KEY (bulk_change_id)
        REFERENCES public.sim_management_bulk_change (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX ix_device_bulk_change_log_bulk_change_id ON public.sim_management_bulk_change_log USING btree (bulk_change_id);
CREATE INDEX ix_device_bulk_change_log_response_text_md5 ON public.sim_management_bulk_change_log USING btree (md5(response_text));


CREATE TABLE IF NOT EXISTS public.sim_management_bulk_change_type_service_provider
(
    id serial primary key,
    integration_id integer,
    service_provider_id integer,
    service_provider character varying(50) COLLATE pg_catalog."default",
    change_request_type_id integer,
    change_type character varying(100) COLLATE pg_catalog."default",
	is_active boolean null,
    is_deleted boolean NULL,
	id_10 int NULL,
    modified_date timestamp NULL,
	CONSTRAINT fk_service_provider FOREIGN KEY (service_provider_id)
		REFERENCES serviceprovider(id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS public.sim_management_carrier_feature_codes_uat
(
    id serial primary key,
    service_provider_id integer,
    service_provider_name character varying(100) COLLATE pg_catalog."default",
    customer_id integer,
    customer_name character varying(255) COLLATE pg_catalog."default",
    feature_codes text COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    soc_codes text COLLATE pg_catalog."default",
    id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.sim_management_inventory_action_history
(
    id serial primary key,
    service_provider_id integer,
    sim_management_inventory_id integer,
    bulk_change_id bigint,
    uploaded_file_id integer,
    iccid character varying(50) COLLATE pg_catalog."default",
    msisdn character varying(150) COLLATE pg_catalog."default",
    previous_value character varying(250) COLLATE pg_catalog."default",
    current_value character varying(250) COLLATE pg_catalog."default",
    changed_field character varying(250) COLLATE pg_catalog."default",
    change_event_type character varying(250) COLLATE pg_catalog."default",
    date_of_change timestamp without time zone,
    changed_by character varying(100) COLLATE pg_catalog."default",
    username character varying(150) COLLATE pg_catalog."default",
    customer_account_name character varying(500) COLLATE pg_catalog."default",
    customer_account_number character varying(50) COLLATE pg_catalog."default",
    tenant_id integer,
    tenant_name varchar(100) NULL,
    is_active boolean,
    is_deleted boolean NULL,
    service_provider character varying(100) COLLATE pg_catalog."default",
    m2m_device_id int NULL,
    mobility_device_id int NULL,
    id_10 int NULL,
	modified_date timestamp NULL,
    CONSTRAINT fk_bulk_change_id FOREIGN KEY (bulk_change_id)
        REFERENCES public.sim_management_bulk_change (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX idx_deviceactionhistory_m2m_tenant_date1 ON public.sim_management_inventory_action_history USING btree (m2m_device_id, date_of_change DESC) INCLUDE (current_value);
CREATE INDEX idx_deviceactionhistory_mobility_tenant_date1 ON public.sim_management_inventory_action_history USING btree (mobility_device_id, date_of_change DESC) INCLUDE (current_value);
CREATE INDEX idx_iccid ON public.sim_management_inventory_action_history USING btree (iccid);



CREATE TABLE IF NOT EXISTS public.sim_order_form
(
    id serial primary key,
    company character varying(255) COLLATE pg_catalog."default",
    contact_name character varying(255) COLLATE pg_catalog."default",
    email character varying(255) COLLATE pg_catalog."default",
    country character varying(255) COLLATE pg_catalog."default",
    shipping_address character varying(255) COLLATE pg_catalog."default",
    special_instructions text COLLATE pg_catalog."default",
    expedite character varying(255) COLLATE pg_catalog."default",
    sim_info json,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    created_by character varying(255) COLLATE pg_catalog."default",
    static_ip boolean,
    modified_date timestamp NULL
);

CREATE TABLE IF NOT EXISTS public.rev_product_type
(
    id serial primary key,
    product_type_id integer,
    product_type_code character varying(512) COLLATE pg_catalog."default",
    description character varying(1024) COLLATE pg_catalog."default",
    tax_class_id character varying(64) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    integration_authentication_id integer,
    id_10 int NULL,
    CONSTRAINT fk_integration_authentication_id FOREIGN KEY (integration_authentication_id)
        REFERENCES public.integration_authentication (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX idx_rev_product_type_integration_authentication_id ON public.rev_product_type USING btree (integration_authentication_id);
CREATE INDEX idx_rev_product_type_product_type_code ON public.rev_product_type USING btree (product_type_code);
CREATE INDEX idx_rev_product_type_product_type_id ON public.rev_product_type USING btree (product_type_id);
CREATE INDEX idx_rev_product_type_recurring ON public.rev_product_type USING btree (product_type_code) WHERE ((product_type_code)::text ~~ 'RECURRING_%'::text);


CREATE TABLE IF NOT EXISTS public.rev_product
(
    id serial primary key,
    product_id integer,
    product_type_id integer,
    description character varying(1024) COLLATE pg_catalog."default",
    code1 character varying(1024) COLLATE pg_catalog."default",
    code2 character varying(1024) COLLATE pg_catalog."default",
    rate character varying COLLATE pg_catalog."default",
    cost character varying COLLATE pg_catalog."default",
    buy_rate character varying COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    created_by character varying(100) COLLATE pg_catalog."default",
    creates_order boolean,
    provider_id integer,
    bills_in_arrears boolean,
    prorates boolean,
    customer_class character varying(64) COLLATE pg_catalog."default",
    long_description character varying(1024) COLLATE pg_catalog."default",
    ledger_code character varying(64) COLLATE pg_catalog."default",
    free_months integer,
    automatic_expiration_months integer,
    order_completion_billing boolean,
    tax_class_id character varying(64) COLLATE pg_catalog."default",
    wholesale_description character varying(512) COLLATE pg_catalog."default",
    msisdn character varying(150) COLLATE pg_catalog."default",
    iccid character varying(150) COLLATE pg_catalog."default",
    imei character varying(150) COLLATE pg_catalog."default",
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    integration_authentication_id integer,
    rev_provider_id integer,
    tenant_id integer,
    service_provider_id int4 NULL,
	service_provider varchar(100) NULL,
    id_10 int NULL,
    CONSTRAINT fk_revproduct_integration_authentication FOREIGN KEY (integration_authentication_id)
        REFERENCES public.integration_authentication (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL,
    CONSTRAINT fk_revproduct_revprovider FOREIGN KEY (rev_provider_id)
        REFERENCES public.rev_provider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX idx_rev_product_integration_authentication_id ON public.rev_product USING btree (integration_authentication_id);
CREATE INDEX idx_rev_product_product_id ON public.rev_product USING btree (product_id);
CREATE INDEX idx_rev_product_product_id_integration_authentication_id ON public.rev_product USING btree (product_id, integration_authentication_id);


CREATE TABLE IF NOT EXISTS public.rev_package
(
    id serial primary key,
    package_id character varying COLLATE pg_catalog."default",
    provider_id integer,
    currency_code character varying(50) COLLATE pg_catalog."default",
    description character varying(1024) COLLATE pg_catalog."default",
    description_on_bill character varying(1024) COLLATE pg_catalog."default",
    long_description character varying(1024) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    created_by character varying(100) COLLATE pg_catalog."default",
    usage_plan_group_id integer,
    service_type_id integer,
    package_category_id character varying COLLATE pg_catalog."default",
    exempt_from_spiff_commission boolean,
    restrict_class_flag boolean,
    class character varying(64) COLLATE pg_catalog."default",
    restrict_bill_profile_flag boolean,
    bill_profile_id integer,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean DEFAULT true NULL,
    is_deleted boolean DEFAULT false NULL,
    integration_authentication_id integer,
    rev_provider_id integer,
    service_provider_id integer,
    service_provider character varying(100) COLLATE pg_catalog."default",
    tenant_id integer,
    rev_provider_name character varying(255) COLLATE pg_catalog."default",
    id_10 int NULL,
    CONSTRAINT fk_revproduct_integration_authentication FOREIGN KEY (integration_authentication_id)
        REFERENCES public.integration_authentication (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL,
    CONSTRAINT fk_revproduct_revprovider FOREIGN KEY (rev_provider_id)
        REFERENCES public.rev_provider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_type
(
    id bigserial primary key,
    name character varying(100) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
	id_10 int NULL
);
CREATE INDEX idx_optimization_type_id ON public.optimization_type USING btree (id);

CREATE TABLE IF NOT EXISTS public.optimization_status
(
    id serial primary key,
    display_name character varying(50) COLLATE pg_catalog."default",
    display_order integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_deleted boolean DEFAULT false NULL,
	id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.mobility_device_usage_aggregate
(
    id serial primary key,
    service_provider_id integer,
    service_provider character varying(100) COLLATE pg_catalog."default",
    foundation_account_number character varying(50) COLLATE pg_catalog."default" NOT NULL,
    billing_account_number character varying(50) COLLATE pg_catalog."default",
    data_group_id character varying(50) COLLATE pg_catalog."default",
    pool_id character varying(50) COLLATE pg_catalog."default",
    data_usage bigint,
    voice_usage integer,
    sms_usage integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    is_active boolean,
    is_deleted boolean NULL,
    data_total bigint,
    tenant_id integer,
    id_10 int NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS public.imei_master
(
    id serial primary key,
    manufacturer character varying(100) COLLATE pg_catalog."default",
    model character varying(255) COLLATE pg_catalog."default",
    from_imei character varying(60) COLLATE pg_catalog."default",
    to_imei character varying(60) COLLATE pg_catalog."default",
    device_type character varying(250) COLLATE pg_catalog."default",
    sim_type character varying(255) COLLATE pg_catalog."default",
    att_certified boolean,
    device_common_name character varying(255) COLLATE pg_catalog."default",
    device_marketing_name character varying(255) COLLATE pg_catalog."default",
    network_type character varying(100) COLLATE pg_catalog."default",
    ran_type character varying(100) COLLATE pg_catalog."default",
    nsdev boolean,
    volte_capable boolean,
    service_provider_id integer,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(50) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(50) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    tenant_id integer,
    id_10 int NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS public.device_history
(
    device_history_id bigserial primary key,
    changed_date timestamp without time zone,
    id integer,
    service_provider_id integer,
    iccid character varying(50) COLLATE pg_catalog."default",
    imsi character varying(150) COLLATE pg_catalog."default",
    msisdn character varying(150) COLLATE pg_catalog."default",
    imei character varying(150) COLLATE pg_catalog."default",
    device_status_id integer,
    status character varying(50) COLLATE pg_catalog."default",
    carrier_rate_plan_id integer,
    rate_plan character varying(255) COLLATE pg_catalog."default",
    communication_plan character varying(255) COLLATE pg_catalog."default",
    last_usage_date timestamp without time zone,
    apn character varying(250) COLLATE pg_catalog."default",
    "package" character varying(250) COLLATE pg_catalog."default",
    billing_cycle_end_date timestamp without time zone,
    bill_year integer,
    bill_month integer,
    carrier_cycle_usage bigint,
    ctd_sms_usage bigint,
    ctd_voice_usage bigint,
    ctd_session_count bigint,
    overage_limit_reached boolean,
    overage_limit_override character varying(50) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    last_activated_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    account_number character varying(50) COLLATE pg_catalog."default",
    provider_date_added timestamp without time zone,
    provider_date_activated timestamp without time zone,
    old_device_status_id integer,
    old_ctd_data_usage bigint,
    cost_center character varying(250) COLLATE pg_catalog."default",
    username character varying(250) COLLATE pg_catalog."default",
    account_number_integration_authentication_id integer,
    billing_period_id integer,
    customer_id integer,
    customer_rate_plan_id integer,
    customer_rate_pool_id integer,
    device_tenant_id integer,
    tenant_id integer,
    is_pushed boolean,
    customer_data_allocation_mb numeric(25,4),
    id_10 int NULL

);
CREATE INDEX idx_devicehistory_bill_year_bill_month ON public.device_history USING btree (bill_year, bill_month, iccid) INCLUDE (billing_cycle_end_date, changed_date, carrier_cycle_usage, device_status_id, status);
CREATE INDEX idx_devicehistory_billing_period_id ON public.device_history USING btree (billing_period_id) INCLUDE (billing_cycle_end_date, changed_date, carrier_cycle_usage, device_status_id, iccid, last_activated_date, service_provider_id, status);
CREATE INDEX idx_devicehistory_device_status_id ON public.device_history USING btree (device_status_id) INCLUDE (billing_cycle_end_date, billing_period_id, changed_date, carrier_cycle_usage, ctd_sms_usage, device_tenant_id, id, last_activated_date, service_provider_id, status);
CREATE INDEX idx_devicehistory_iccid ON public.device_history USING btree (iccid);
CREATE INDEX idx_devicehistory_id_billing_period_id ON public.device_history USING btree (id, billing_period_id) INCLUDE (billing_cycle_end_date, changed_date, carrier_cycle_usage, ctd_sms_usage, device_status_id, last_activated_date, service_provider_id);
CREATE INDEX idx_mobility_devicehistory_iccid ON public.device_history USING btree (iccid);


CREATE TABLE IF NOT EXISTS public.mobility_device_history
(
    device_history_id bigserial primary key,
    changed_date timestamp without time zone NOT NULL,
    id integer NOT NULL,
    service_provider_id integer NOT NULL,
    foundation_account_number character varying(30) COLLATE pg_catalog."default" NOT NULL,
    billing_account_number character varying(30) COLLATE pg_catalog."default" NOT NULL,
    iccid character varying(50) COLLATE pg_catalog."default" NOT NULL,
    imsi character varying(150) COLLATE pg_catalog."default",
    msisdn character varying(150) COLLATE pg_catalog."default",
    imei character varying(150) COLLATE pg_catalog."default",
    device_status_id integer,
    status character varying(50) COLLATE pg_catalog."default",
    carrier_rate_plan_id integer,
    rate_plan character varying(200) COLLATE pg_catalog."default",
    last_usage_date timestamp without time zone,
    carrier_cycle_usage bigint,
    ctd_sms_usage bigint,
    ctd_voice_usage bigint,
    ctd_session_count bigint,
    created_by character varying(100) COLLATE pg_catalog."default" NOT NULL,
    created_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    last_activated_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
    account_number character varying(50) COLLATE pg_catalog."default",
    provider_date_added timestamp without time zone,
    provider_date_activated timestamp without time zone,
    old_device_status_id integer,
    old_ctd_data_usage bigint,
    account_number_integration_authentication_id integer,
    billing_period_id integer,
    customer_id integer,
    single_user_code character varying(200) COLLATE pg_catalog."default",
    single_user_code_description character varying(200) COLLATE pg_catalog."default",
    service_zip_code character varying(50) COLLATE pg_catalog."default",
    data_group_id character varying(50) COLLATE pg_catalog."default",
    pool_id character varying(50) COLLATE pg_catalog."default",
    device_make character varying(50) COLLATE pg_catalog."default",
    device_model character varying(50) COLLATE pg_catalog."default",
    contract_status character varying(50) COLLATE pg_catalog."default",
    ban_status character varying(50) COLLATE pg_catalog."default",
    imei_type_id integer,
    plan_limit_mb numeric(25,4),
    customer_rate_plan_id integer,
    customer_data_allocation_mb numeric(25,4),
    username character varying(150) COLLATE pg_catalog."default",
    customer_rate_pool_id integer,
    mobility_device_tenant_id integer,
    tenant_id integer,
    ip_address character varying(50) COLLATE pg_catalog."default",
    is_pushed boolean NOT NULL,
    id_10 int NULL
);
CREATE INDEX idx_mobility_billing_period_service_provider ON public.mobility_device_history USING btree (billing_period_id, service_provider_id);
CREATE INDEX idx_mobility_created_deleted ON public.mobility_device_history USING btree (created_date, deleted_date);
CREATE INDEX idx_mobility_customer_device_status ON public.mobility_device_history USING btree (customer_id, device_status_id, modified_date DESC);
CREATE INDEX idx_mobility_device_history_customer ON public.mobility_device_history USING btree (customer_id);
CREATE INDEX idx_mobility_device_history_dates ON public.mobility_device_history USING btree (created_date, modified_date, deleted_date, last_activated_date);
CREATE INDEX idx_mobility_device_history_device_history_id ON public.mobility_device_history USING btree (device_history_id);
CREATE INDEX idx_mobility_device_history_device_status ON public.mobility_device_history USING btree (device_status_id);
CREATE INDEX idx_mobility_device_history_iccid ON public.mobility_device_history USING btree (iccid);
CREATE INDEX idx_mobility_device_history_imei ON public.mobility_device_history USING btree (imei);
CREATE INDEX idx_mobility_device_history_modified_date ON public.mobility_device_history USING btree (modified_date DESC);
CREATE INDEX idx_mobility_device_history_msisdn ON public.mobility_device_history USING btree (msisdn);


CREATE TABLE IF NOT EXISTS public.sim_management_inventory_history
(
    device_history_id serial primary key,
    id integer,
    changed_date timestamp without time zone NOT NULL,
    d_device_history_id integer,
    m_device_history_id integer,
    service_provider_id integer NOT NULL,
    iccid character varying(50) COLLATE pg_catalog."default" NOT NULL,
    imsi character varying(150) COLLATE pg_catalog."default",
    msisdn character varying(150) COLLATE pg_catalog."default",
    imei character varying(150) COLLATE pg_catalog."default",
    device_status_id integer,
    status character varying(50) COLLATE pg_catalog."default",
    carrier_rate_plan_id integer,
    rate_plan character varying(255) COLLATE pg_catalog."default",
    last_usage_date timestamp without time zone,
    apn character varying(250) COLLATE pg_catalog."default",
    carrier_cycle_usage bigint,
    ctd_sms_usage bigint,
    ctd_voice_usage bigint,
    ctd_session_count bigint,
    created_by character varying(100) COLLATE pg_catalog."default" NOT NULL,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    last_activated_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
    account_number character varying(50) COLLATE pg_catalog."default",
    provider_date_added timestamp without time zone,
    provider_date_activated timestamp without time zone,
    old_device_status_id integer,
    old_ctd_data_usage bigint,
    account_number_integration_authentication_id integer,
    billing_period_id integer,
    customer_id integer,
    single_user_code character varying(200) COLLATE pg_catalog."default",
    single_user_code_description character varying(200) COLLATE pg_catalog."default",
    service_zip_code character varying(50) COLLATE pg_catalog."default",
    data_group_id character varying(50) COLLATE pg_catalog."default",
    pool_id character varying(50) COLLATE pg_catalog."default",
    device_make character varying(50) COLLATE pg_catalog."default",
    device_model character varying(50) COLLATE pg_catalog."default",
    contract_status character varying(50) COLLATE pg_catalog."default",
    ban_status character varying(50) COLLATE pg_catalog."default",
    imei_type_id integer,
    plan_limit_mb numeric(25,4),
    customer_rate_pool_id integer,
    mobility_device_tenant_id integer,
    tenant_id integer,
    "package" character varying(250) COLLATE pg_catalog."default",
    ip_address character varying(50) COLLATE pg_catalog."default",
    is_pushed boolean NOT NULL,
    billing_account_number character varying(30) COLLATE pg_catalog."default",
    foundation_account_number character varying(30) COLLATE pg_catalog."default",
    customer_rate_plan_id integer,
    customer_data_allocation_mb numeric(25,4),
    username character varying(150) COLLATE pg_catalog."default",
    billing_cycle_end_date timestamp without time zone,
    bill_year integer,
    bill_month integer,
    overage_limit_reached boolean,
    overage_limit_override character varying(50) COLLATE pg_catalog."default",
    cost_center character varying(250) COLLATE pg_catalog."default",
    device_tenant_id integer,
    smi_id bigint,
    communication_plan varchar null,
    service_provider_display_name varchar(250) NULL,
    CONSTRAINT fk_sim_management_inventory_id FOREIGN KEY (smi_id)
        REFERENCES public.sim_management_inventory (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX idx_iccid_billing_period_id ON public.sim_management_inventory_history USING btree (iccid, billing_period_id);
CREATE INDEX idx_service_provider_id_ ON public.sim_management_inventory_history USING btree (service_provider_id);
CREATE INDEX idx_service_provider_id_active_deleted ON public.sim_management_inventory_history USING btree (service_provider_id, is_active, is_deleted);
CREATE INDEX idx_smih_is_active_deleted ON public.sim_management_inventory_history USING btree (is_active, is_deleted);
CREATE INDEX idx_smih_smi_id ON public.sim_management_inventory_history USING btree (smi_id);
CREATE INDEX index_devicehistory_bill_year_bill_month ON public.sim_management_inventory_history USING btree (bill_year, bill_month, iccid) INCLUDE (billing_cycle_end_date, changed_date, carrier_cycle_usage, device_status_id, status);
CREATE INDEX index_devicehistory_billing_period_id ON public.sim_management_inventory_history USING btree (billing_period_id) INCLUDE (billing_cycle_end_date, changed_date, carrier_cycle_usage, device_status_id, iccid, last_activated_date, service_provider_id, status);
CREATE INDEX index_devicehistory_device_status_id ON public.sim_management_inventory_history USING btree (device_status_id) INCLUDE (billing_cycle_end_date, billing_period_id, changed_date, carrier_cycle_usage, ctd_sms_usage, device_tenant_id, id, last_activated_date, service_provider_id, status);
CREATE INDEX index_devicehistory_iccid ON public.sim_management_inventory_history USING btree (iccid);
CREATE INDEX index_devicehistory_id_billing_period_id ON public.sim_management_inventory_history USING btree (id, billing_period_id) INCLUDE (billing_cycle_end_date, changed_date, carrier_cycle_usage, ctd_sms_usage, device_status_id, last_activated_date, service_provider_id);
CREATE INDEX index_mobility_devicehistory_iccid ON public.sim_management_inventory_history USING btree (iccid);


CREATE TABLE IF NOT EXISTS public.device_status_history
(
    id bigserial primary key,
    sim_management_inventory_id integer,
    iccid character varying(50) COLLATE pg_catalog."default",
    msisdn character varying(50) COLLATE pg_catalog."default",
    username character varying(150) COLLATE pg_catalog."default",
    previous_status character varying(50) COLLATE pg_catalog."default",
    current_status character varying(50) COLLATE pg_catalog."default",
    change_event_type character varying(250) COLLATE pg_catalog."default",
    date_of_change timestamp without time zone,
    changed_by character varying(100) COLLATE pg_catalog."default",
    is_deleted bool NULL default false,
    service_provider_id integer,
    device_id integer,
    mobility_device_id integer,
    uploaded_file_id integer,
    bulk_change_id bigint,
    customer_name character varying(500) COLLATE pg_catalog."default",
    customer_account_number character varying(50) COLLATE pg_catalog."default",
    customer_rate_plan character varying(50) COLLATE pg_catalog."default",
    customer_rate_pool character varying(200) COLLATE pg_catalog."default",
    tenant_id integer,
    modified_date timestamp NULL,
	service_provider_display_name varchar NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	id_10 int4 NULL,
	customer_name_with_revio varchar NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX idx_device_status_history_current_status ON public.device_status_history USING btree (current_status);
CREATE INDEX idx_device_status_history_date_and_status ON public.device_status_history USING btree (mobility_device_id, date_of_change DESC, current_status);
CREATE INDEX idx_device_status_history_date_of_change ON public.device_status_history USING btree (date_of_change);
CREATE INDEX idx_device_status_history_date_of_change_desc ON public.device_status_history USING btree (mobility_device_id, date_of_change DESC);
CREATE INDEX idx_device_status_history_device_id ON public.device_status_history USING btree (device_id) INCLUDE (bulk_change_id, changed_by, change_event_type, current_status, customer_account_number, customer_name, customer_rate_plan, customer_rate_pool, date_of_change, iccid, is_deleted, msisdn, previous_status, service_provider_id, username);
CREATE INDEX idx_device_status_history_device_tenant_date ON public.device_status_history USING btree (device_id, tenant_id, date_of_change DESC) INCLUDE (current_status);
CREATE INDEX idx_device_status_history_iccid ON public.device_status_history USING btree (iccid);
CREATE INDEX idx_device_status_history_iccid_date_of_change ON public.device_status_history USING btree (iccid, date_of_change);
CREATE INDEX idx_device_status_history_iccid_date_status ON public.device_status_history USING btree (iccid, date_of_change DESC, current_status);
CREATE INDEX idx_device_status_history_iccid_status ON public.device_status_history USING btree (iccid, current_status, date_of_change DESC);
CREATE INDEX idx_device_status_history_id ON public.device_status_history USING btree (id);
CREATE INDEX idx_device_status_history_lower_current_status ON public.device_status_history USING btree (lower((current_status)::text), lower((previous_status)::text));
CREATE INDEX idx_device_status_history_mobility_device ON public.device_status_history USING btree (mobility_device_id) INCLUDE (bulk_change_id, changed_by, change_event_type, current_status, customer_account_number, customer_name, customer_rate_plan, customer_rate_pool, date_of_change, iccid, is_deleted, msisdn, previous_status, service_provider_id, username);
CREATE INDEX idx_device_status_history_mobility_device_id_date_of_change ON public.device_status_history USING btree (mobility_device_id, date_of_change);
CREATE INDEX idx_device_status_history_msisdn_deleted_date ON public.device_status_history USING btree (msisdn, is_deleted, date_of_change DESC) INCLUDE (current_status, previous_status);
CREATE INDEX idx_device_status_history_previous_status ON public.device_status_history USING btree (previous_status);
CREATE INDEX idx_device_status_history_sim_management_inventory_id_tenant_id ON public.device_status_history USING btree (sim_management_inventory_id, tenant_id);
CREATE INDEX idx_device_status_history_tenant ON public.device_status_history USING btree (tenant_id);
CREATE INDEX idx_device_status_history_tenant_iccid_sim_inventory ON public.device_status_history USING btree (tenant_id, iccid, sim_management_inventory_id);
CREATE INDEX idx_device_status_history_tenant_id ON public.device_status_history USING btree (tenant_id);
CREATE INDEX idx_device_status_history_tenant_null ON public.device_status_history USING btree (device_id) WHERE (tenant_id IS NULL);
CREATE INDEX idx_service_provider_id ON public.device_status_history USING btree (service_provider_id);
CREATE INDEX idx_sim_management_inventory_id ON public.device_status_history USING btree (sim_management_inventory_id);
CREATE INDEX ix_device_status_history_mobility_device_id_tenant_id_date_of_c ON public.device_status_history USING btree (mobility_device_id, tenant_id, date_of_change DESC) INCLUDE (current_status);

CREATE TABLE public.mobility_device_status_history (
	id bigserial primary key,
	sim_management_inventory_id int NULL,
	iccid varchar(50) NULL,
	msisdn varchar(50) NULL,
	username varchar(150) NULL,
	previous_status varchar(50) NULL,
	current_status varchar(50) NULL,
	change_event_type varchar(250) NULL,
	date_of_change timestamp NULL,
	changed_by varchar(100) NULL,
	is_deleted bool NULL,
	service_provider_id int NULL,
	device_id int NULL,
	mobility_device_id int NULL,
	uploaded_file_id int NULL,
	bulk_change_id int NULL,
	customer_name varchar(500) NULL,
	customer_account_number varchar(50) NULL,
	customer_rate_plan varchar(50) NULL,
	customer_rate_pool varchar(200) NULL,
	tenant_id int NULL,
	service_provider_display_name varchar NULL,
	id_10 int NULL,
	modified_date timestamp NULL
);
CREATE INDEX idx_mobility_device_status_history_date_of_change ON public.mobility_device_status_history USING btree (date_of_change);
CREATE INDEX idx_mobility_device_status_history_device_id_date_of_change ON public.mobility_device_status_history USING btree (mobility_device_id, date_of_change);
CREATE INDEX idx_mobility_device_status_history_lower_current_status ON public.mobility_device_status_history USING btree (lower((current_status)::text));
CREATE INDEX idx_mobility_device_status_history_lower_previous_status ON public.mobility_device_status_history USING btree (lower((previous_status)::text));
CREATE INDEX mobility_device_status_histor_device_id_bulk_change_id_chan_idx ON public.mobility_device_status_history USING btree (device_id) INCLUDE (bulk_change_id, changed_by, change_event_type, current_status, customer_account_number, customer_name, customer_rate_plan, customer_rate_pool, date_of_change, iccid, is_deleted, msisdn, previous_status, service_provider_id, username);
CREATE INDEX mobility_device_status_histor_device_id_tenant_id_date_of_c_idx ON public.mobility_device_status_history USING btree (device_id, tenant_id, date_of_change DESC) INCLUDE (current_status);
CREATE INDEX mobility_device_status_histor_iccid_current_status_date_of__idx ON public.mobility_device_status_history USING btree (iccid, current_status, date_of_change DESC);
CREATE INDEX mobility_device_status_histor_iccid_date_of_change_current__idx ON public.mobility_device_status_history USING btree (iccid, date_of_change DESC, current_status);
CREATE INDEX mobility_device_status_histor_mobility_device_id_bulk_chang_idx ON public.mobility_device_status_history USING btree (mobility_device_id) INCLUDE (bulk_change_id, changed_by, change_event_type, current_status, customer_account_number, customer_name, customer_rate_plan, customer_rate_pool, date_of_change, iccid, is_deleted, msisdn, previous_status, service_provider_id, username);
CREATE INDEX mobility_device_status_histor_mobility_device_id_date_of_c_idx1 ON public.mobility_device_status_history USING btree (mobility_device_id, date_of_change DESC);
CREATE INDEX mobility_device_status_histor_mobility_device_id_date_of_c_idx2 ON public.mobility_device_status_history USING btree (mobility_device_id, date_of_change);
CREATE INDEX mobility_device_status_histor_mobility_device_id_date_of_c_idx3 ON public.mobility_device_status_history USING btree (mobility_device_id, date_of_change DESC, current_status, previous_status);
CREATE INDEX mobility_device_status_histor_mobility_device_id_date_of_ch_idx ON public.mobility_device_status_history USING btree (mobility_device_id, date_of_change DESC, current_status);
CREATE INDEX mobility_device_status_histor_mobility_device_id_tenant_id__idx ON public.mobility_device_status_history USING btree (mobility_device_id, tenant_id, date_of_change DESC) INCLUDE (current_status);
CREATE INDEX mobility_device_status_histor_msisdn_is_deleted_date_of_cha_idx ON public.mobility_device_status_history USING btree (msisdn, is_deleted, date_of_change DESC) INCLUDE (current_status, previous_status);
CREATE INDEX mobility_device_status_histor_sim_management_inventory_id_t_idx ON public.mobility_device_status_history USING btree (sim_management_inventory_id, tenant_id);
CREATE INDEX mobility_device_status_histor_tenant_id_iccid_sim_managemen_idx ON public.mobility_device_status_history USING btree (tenant_id, iccid, sim_management_inventory_id);
CREATE INDEX mobility_device_status_history_current_status_idx ON public.mobility_device_status_history USING btree (current_status);
CREATE INDEX mobility_device_status_history_date_of_change_idx ON public.mobility_device_status_history USING btree (date_of_change);
CREATE INDEX mobility_device_status_history_device_id_idx ON public.mobility_device_status_history USING btree (device_id) WHERE (tenant_id IS NULL);
CREATE INDEX mobility_device_status_history_iccid_date_of_change_idx ON public.mobility_device_status_history USING btree (iccid, date_of_change);
CREATE INDEX mobility_device_status_history_iccid_idx ON public.mobility_device_status_history USING btree (iccid);
CREATE INDEX mobility_device_status_history_id_idx ON public.mobility_device_status_history USING btree (id);
CREATE INDEX mobility_device_status_history_lower_lower1_idx ON public.mobility_device_status_history USING btree (lower((current_status)::text), lower((previous_status)::text));
CREATE INDEX mobility_device_status_history_previous_status_idx ON public.mobility_device_status_history USING btree (previous_status);
CREATE INDEX mobility_device_status_history_service_provider_id_idx ON public.mobility_device_status_history USING btree (service_provider_id);
CREATE INDEX mobility_device_status_history_sim_management_inventory_id_idx ON public.mobility_device_status_history USING btree (sim_management_inventory_id);
CREATE INDEX mobility_device_status_history_tenant_id_idx ON public.mobility_device_status_history USING btree (tenant_id);
CREATE INDEX mobility_device_status_history_tenant_id_idx1 ON public.mobility_device_status_history USING btree (tenant_id);

CREATE TABLE IF NOT EXISTS public.device_status_reason_code
(
    id serial primary key,
    device_status_id integer,
    device_status character varying(255) COLLATE pg_catalog."default",
    reason_code character varying(50) COLLATE pg_catalog."default",
    description character varying(100) COLLATE pg_catalog."default",
    service_provider_id integer,
    service_provider character varying(100) COLLATE pg_catalog."default",
    tenant_id integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
	id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.device_usage
(
    id bigserial primary key,
    sim_management_inventory_id integer,
    m2m_device_id integer,
    mobility_device_id integer,
    data_usage bigint,
    sms_usage bigint,
    voice_usage bigint,
    usage_date timestamp without time zone,
    device_status_id integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_date timestamp NULL,
    modified_by varchar NULL,
    id_10 bigint NULL
);
CREATE INDEX idx_device_usage_customer_bill_period ON public.device_usage USING btree (data_usage, usage_date);
CREATE INDEX idx_device_usage_m2m_device_id ON public.device_usage USING btree (m2m_device_id) INCLUDE (data_usage, usage_date);
CREATE INDEX idx_device_usage_mobility_device_id ON public.device_usage USING btree (mobility_device_id) INCLUDE (data_usage, usage_date);
CREATE INDEX idx_du_mobility_device_id ON public.device_usage USING btree (mobility_device_id);

CREATE TABLE IF NOT EXISTS public.netsapiens_device
(
    id serial primary key,
    subscriber_domain character varying(256) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    subscriber_name character varying(256) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    aor character varying(256) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    mode character varying(256) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    user_agent character varying(512) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    received_from character varying(128) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    contact character varying(128) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    registration_time timestamp without time zone,
    authentication_key character varying(50) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    call_processing_rule character varying(50) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    registration_expires_time timestamp without time zone,
    expires character varying(50) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    callid_emgr character varying(128) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    sub_fullname character varying(128) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    sub_login character varying(128) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    aor_user character varying(50) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    sub_scope character varying(128) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    nd_perror character varying(3000) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    server character varying(1024) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    auth_user character varying(1024) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    auth_pass character varying(1024) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    mac character varying(128) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    model character varying(128) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    transport character varying(50) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    line character varying(50) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    created_by character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default" DEFAULT NULL::character varying,
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    can_ignore boolean,
    id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_session
(
    id bigserial primary key,
    session_id uuid,
    billing_period_start_date timestamp without time zone,
    billing_period_end_date timestamp without time zone,
    tenant_id integer,
    service_provider_id integer,
    service_provider_ids text COLLATE pg_catalog."default",
    customer_id integer,
    optimization_type_id bigint,
    integration_id integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    progress varchar null,
    optimization_run_time_error varchar(100) null,
    optimization_run_status varchar(255) NULL,
	optimization_run_start_date timestamp NULL,
	optimization_run_end_time timestamp NULL,
	optimization_status_syncs text NULL,
	id_10 bigint NULL,
	push_charges_processed_count int NULL,
	push_charges_not_processed_count int NULL,
	push_charge_page bool NULL,
	carrier_assignments_queued varchar NULL,
	device_count_20 numeric NULL,
	total_charges_20 numeric NULL,
	total_usage_charges_20 numeric NULL,
	total_sms_charges_20 numeric NULL,
    flag_20 boolean null,
    CONSTRAINT fk_optimizationsession_integration FOREIGN KEY (integration_id)
        REFERENCES public.integration (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_optimizationsession_optimizationtype FOREIGN KEY (optimization_type_id)
        REFERENCES public.optimization_type (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_optimizationsession_serviceprovider FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX idx_opt_sess_modified_date ON public.optimization_session USING btree (modified_date);
CREATE INDEX idx_optimization_is_active ON public.optimization_session USING btree (is_active);
CREATE INDEX idx_optimization_session_created_date ON public.optimization_session USING btree (created_date DESC);
CREATE INDEX idx_optimization_session_created_date_is_active ON public.optimization_session USING btree (created_date DESC, is_active);
CREATE INDEX idx_optimization_session_customer_id ON public.optimization_session USING btree (customer_id);
CREATE INDEX idx_optimization_session_id ON public.optimization_session USING btree (id DESC);
CREATE INDEX idx_optimization_session_optimization_type_active ON public.optimization_session USING btree (optimization_type_id, is_active);
CREATE INDEX idx_optimization_session_optimization_type_id ON public.optimization_session USING btree (optimization_type_id);
CREATE INDEX idx_optimization_session_run_date ON public.optimization_session USING btree (optimization_run_start_date DESC);
CREATE INDEX idx_optimization_session_service_provider_id ON public.optimization_session USING btree (service_provider_id);
CREATE INDEX idx_optimization_session_sessionid ON public.optimization_session USING btree (session_id);


CREATE TABLE IF NOT EXISTS public.optimization_instance
(
    id bigserial primary key,
    billing_period_start_date timestamp without time zone,
    billing_period_end_date timestamp without time zone,
    run_status_id integer,
    run_start_time timestamp without time zone,
    run_end_time timestamp without time zone,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_deleted boolean NULL,
    sqs_message_id character varying(50) COLLATE pg_catalog."default",
    rev_customer_id uuid,
    service_provider_id integer,
    integration_authentication_id integer,
    tenant_id integer,
    portal_type_id integer,
    row_uuid character varying(50) COLLATE pg_catalog."default",
    integration_id integer,
    optimization_session_id bigint,
    optimization_billing_period_id integer,
    use_bill_in_advance boolean,
    bill_in_advance_billing_period_id integer,
    amop_customer_id integer,
    customer_billing_period_id integer,
    customer_bill_in_advance_billing_period_id integer,
    service_provider_ids text COLLATE pg_catalog."default",
    id_10 bigint NULL,
    CONSTRAINT fk_customers_amopcustomerid FOREIGN KEY (amop_customer_id)
        REFERENCES public.customers (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_optimizationinstance_billinadvancebillingperiod FOREIGN KEY (bill_in_advance_billing_period_id)
        REFERENCES public.billing_period (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_optimizationinstance_optimizationbillingperiod FOREIGN KEY (optimization_billing_period_id)
        REFERENCES public.billing_period (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_optimizationinstance_optimizationsession FOREIGN KEY (optimization_session_id)
        REFERENCES public.optimization_session (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_optimizationinstance_optimizationstatus FOREIGN KEY (run_status_id)
        REFERENCES public.optimization_status (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_optimizationinstance_serviceprovider FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX idx_optimization_instance_created_date ON public.optimization_instance USING btree (created_date);
CREATE INDEX idx_optimization_instance_id ON public.optimization_instance USING btree (id);
CREATE INDEX idx_optimization_instance_row_uuid ON public.optimization_instance USING btree (row_uuid);
CREATE INDEX idx_optimization_instance_run_status_id ON public.optimization_instance USING btree (run_status_id);


CREATE TABLE IF NOT EXISTS public.optimization_comm_group
(
    id bigserial primary key,
    instance_id bigint,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_deleted bool NULL default false,
    row_uuid character varying(50) COLLATE pg_catalog."default",
    id_10 bigint NULL,
    CONSTRAINT fk_optimizationcommgroup_optimizationinstance FOREIGN KEY (instance_id)
        REFERENCES public.optimization_instance (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.optimization_group
(
    id serial primary key,
    optimization_group_name character varying(250) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    service_provider_id integer,
    service_provider_name character varying(100) COLLATE pg_catalog."default",
    alias_name character varying(250) COLLATE pg_catalog."default",
    tenant_id integer,
    rate_plans_list text COLLATE pg_catalog."default",
    id_10 int NULL,
    CONSTRAINT unique_id_optimization_group UNIQUE (id, optimization_group_name),
    CONSTRAINT fk_optimizationgroup_serviceprovider FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.optimization_customer_processing
(
    id bigserial primary key,
    service_provider_id integer,
    service_provider character varying(100) COLLATE pg_catalog."default",
    customer_id integer,
    customer_name character varying(255) COLLATE pg_catalog."default",
    amop_customer_id integer,
    amop_customer_name character varying(255) COLLATE pg_catalog."default",
    device_count integer,
    is_processed boolean,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    instance_id bigint,
    session_id bigint,
    error_message text COLLATE pg_catalog."default",
    tenant_id integer,
    modified_date timestamp NULL,
    id_10 bigint NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_group_carrier_rate_plan
(
    id serial primary key,
    optimization_group_id integer,
    optimization_group_name character varying(80) COLLATE pg_catalog."default",
    rate_plan_id integer,
    rate_plan_code character varying(100) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default" NOT NULL,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_deleted boolean NULL,
    is_active bool NULL,
    tenant_id integer,
    id_10 int NULL,
    CONSTRAINT fk_optimizationgroup_carrierrateplan_jaspercarrierrateplan FOREIGN KEY (rate_plan_id)
        REFERENCES public.carrier_rate_plan (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_optimizationgroup_carrierrateplan_optimizationgroup FOREIGN KEY (optimization_group_id)
        REFERENCES public.optimization_group (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.optimization_instance_result_file
(
    id bigserial primary key,
    instance_id bigint,
    stat_file_bytes bytea,
    assignment_file_bytes bytea,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_deleted bool DEFAULT false NULL,
    assignment_xlsx_bytes bytea,
    id_10 bigint NULL,
    CONSTRAINT fk_optimizationinstance FOREIGN KEY (instance_id)
        REFERENCES public.optimization_instance (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);

CREATE TABLE public.optimization_instance_result_file_data (
	id bigserial primary key,
	instance_id int8 NULL,
	stat_file_bytes text NULL,
	assignment_file_bytes text NULL,
	created_by varchar(100) NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NOT NULL,
	modified_by varchar(100) NULL,
	modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_deleted bool DEFAULT false NULL,
	assignment_xlsx_bytes text NULL,
	id_10 int4 NULL

);

CREATE TABLE IF NOT EXISTS public.optimization_queue
(
    id bigserial primary key,
    instance_id bigint,
    comm_plan_group_id bigint,
    run_status_id integer NOT NULL,
    run_start_time timestamp without time zone,
    run_end_time timestamp without time zone,
    total_cost numeric(25,4),
    sqs_message_id character varying(50) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default" DEFAULT 'System'::character varying,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_deleted bool DEFAULT false NULL,
    service_provider_id integer,
    row_uuid uuid DEFAULT gen_random_uuid(),
    uses_proration boolean DEFAULT false,
    is_bill_in_advance boolean DEFAULT false,
    total_base_rate_amt numeric(25,4),
    total_rate_charge_amt numeric(25,4),
    total_overage_charge_amt numeric(25,4),
    id_10 bigint NULL,
    CONSTRAINT fk_optimizationqueue_optimizationcommgroup FOREIGN KEY (comm_plan_group_id)
        REFERENCES public.optimization_comm_group (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_optimizationqueue_optimizationinstance FOREIGN KEY (instance_id)
        REFERENCES public.optimization_instance (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_optimizationqueue_optimizationstatus FOREIGN KEY (run_status_id)
        REFERENCES public.optimization_status (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX idx_optimization_queue_dummy_comm_plan_group_id ON public.optimization_queue USING btree (comm_plan_group_id);
CREATE INDEX idx_optimization_queue_dummy_instance_id ON public.optimization_queue USING btree (instance_id);
CREATE INDEX ix_optimization_queue_dummy_comm_plan_group_id ON public.optimization_queue USING btree (comm_plan_group_id);
CREATE INDEX ix_optimization_queue_dummy_run_end_time ON public.optimization_queue USING btree (run_end_time);
CREATE INDEX ix_optimization_queue_dummy_total_cost ON public.optimization_queue USING btree (total_cost) INCLUDE (comm_plan_group_id, total_base_rate_amt, total_overage_charge_amt, total_rate_charge_amt);

CREATE TABLE IF NOT EXISTS public.optimization_rate_plan_type
(
    id serial primary key,
    rate_plan_type_name character varying(250) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    service_provider_id integer,
    service_provider_name character varying(100) COLLATE pg_catalog."default",
    tenant_id integer,
    id_10 int NULL,
    CONSTRAINT fk_optimizationrateplantype_serviceprovider FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.optimization_device
(
    id bigserial primary key,
    instance_id bigint,
    device_id integer,
    cycle_data_usage_mb numeric(25,4),
    projected_data_usage_mb numeric(25,4),
    communication_plan character varying(50) COLLATE pg_catalog."default",
    msisdn character varying(150) COLLATE pg_catalog."default",
    iccid character varying(50) COLLATE pg_catalog."default",
    usage_date timestamp without time zone,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    amop_device_id integer,
    service_provider_id integer,
    date_activated timestamp without time zone,
    was_activated_in_this_billing_period boolean,
    days_activated_in_billing_period integer,
    sms_usage bigint,
    auto_change_rate_plan boolean,
    optimization_comm_group_id bigint,
    modified_date timestamp NULL,
    id_10 bigint NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_mobility_device
(
    id bigserial primary key,
    instance_id bigint,
    device_id integer,
    cycle_data_usage_mb numeric(25,4),
    projected_data_usage_mb numeric(25,4),
    communication_plan character varying(50) COLLATE pg_catalog."default",
    msisdn character varying(150) COLLATE pg_catalog."default",
    iccid character varying(50) COLLATE pg_catalog."default",
    usage_date timestamp without time zone,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone,
    amop_device_id integer,
    service_provider_id integer,
    date_activated timestamp without time zone,
    was_activated_in_this_billing_period boolean,
    days_activated_in_billing_period integer,
    sms_usage bigint,
    optimization_rate_plan_type_id integer,
    optimization_group_id integer,
    auto_change_rate_plan boolean,
    optimization_comm_group_id bigint,
    modified_date timestamp NULL,
    id_10 bigint NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_smi
(
    id bigserial primary key,
    instance_id bigint,
    device_id integer,
    cycle_data_usage_mb numeric(25,4),
    projected_data_usage_mb numeric(25,4),
    communication_plan character varying(50) COLLATE pg_catalog."default",
    msisdn character varying(150) COLLATE pg_catalog."default",
    iccid character varying(50) COLLATE pg_catalog."default",
    usage_date timestamp without time zone,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone,
    amop_device_id integer,
    service_provider_id integer,
    date_activated timestamp without time zone,
    was_activated_in_this_billing_period boolean,
    days_activated_in_billing_period integer,
    sms_usage bigint,
    optimization_comm_group_id bigint,
    optimization_rate_plan_type_id integer,
    optimization_group_id integer,
    auto_change_rate_plan boolean,
    did bigint,
    mid bigint,
    sim_management_inventory_id bigint,
    uses_proration boolean DEFAULT false NULL,
	total_cost numeric(25, 4) NULL,
	id_10 bigint NULL,
	modified_date timestamp NULL,
    CONSTRAINT fk_optimizationgroupname FOREIGN KEY (optimization_group_id)
        REFERENCES public.optimization_group (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL,
    CONSTRAINT fk_optimizationinstance FOREIGN KEY (instance_id)
        REFERENCES public.optimization_instance (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL,
    CONSTRAINT fk_optimizationrateplantype FOREIGN KEY (optimization_rate_plan_type_id)
        REFERENCES public.optimization_rate_plan_type (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL,
    CONSTRAINT fk_sim_management_inventory_id FOREIGN KEY (sim_management_inventory_id)
        REFERENCES public.sim_management_inventory (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
);
CREATE INDEX idx_optimization_device_instance_id ON public.optimization_smi USING btree (instance_id);
CREATE INDEX idx_optimization_device_instance_id_service_provider_id ON public.optimization_smi USING btree (instance_id, service_provider_id) INCLUDE (amop_device_id, communication_plan, created_by, created_date, cycle_data_usage_mb, date_activated, iccid, msisdn, projected_data_usage_mb, sms_usage, usage_date);
CREATE INDEX idx_optimization_smi_did ON public.optimization_smi USING btree (did);
CREATE INDEX idx_optimization_smi_iccid ON public.optimization_smi USING btree (iccid);
CREATE INDEX idx_optimization_smi_iccid_msisdn ON public.optimization_smi USING btree (iccid, msisdn);
CREATE INDEX idx_optimization_smi_msisdn ON public.optimization_smi USING btree (msisdn);
CREATE INDEX index_instance_id_iccid_misisdn ON public.optimization_smi USING btree (instance_id) INCLUDE (msisdn, iccid);
CREATE INDEX ioptimization_comm_group_id ON public.optimization_smi USING btree (optimization_comm_group_id);


CREATE TABLE IF NOT EXISTS public.optimization_device_result
(
    id bigserial primary key,
    queue_id bigint,
    device_id integer,
    usage_mb numeric(25,4),
    assigned_carrier_rate_plan_id integer,
    assigned_customer_rate_plan_id integer,
    customer_rate_pool_id integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    amop_device_id integer,
    charge_amt numeric(25,4),
    billing_period_id integer,
    sms_usage bigint,
    sms_charge_amount numeric(25,4),
    base_rate_amt numeric(25,4),
    rate_charge_amt numeric(25,4),
    overage_charge_amt numeric(25,4),
    id_10 bigint NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_mobility_device_result
(
    id bigserial primary key,
    queue_id bigint,
    device_id integer,
    usage_mb numeric(25,4),
    assigned_carrier_rate_plan_id integer,
    assigned_customer_rate_plan_id integer,
    customer_rate_pool_id integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    amop_device_id integer,
    charge_amt numeric(25,4),
    billing_period_id integer,
    sms_usage bigint,
    sms_charge_amount numeric(25,4),
    base_rate_amt numeric(25,4),
    rate_charge_amt numeric(25,4),
    overage_charge_amt numeric(25,4),
    modified_date timestamp NULL,
    id_10 bigint NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_smi_result
(
    id bigserial primary key,
    queue_id bigint,
    device_id integer,
    usage_mb numeric(25,4),
    assigned_carrier_rate_plan_id integer,
    assigned_customer_rate_plan_id integer,
    customer_rate_pool_id integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    amop_device_id integer,
    charge_amt numeric(25,4),
    billing_period_id integer,
    sms_usage bigint,
    sms_charge_amount numeric(25,4),
    base_rate_amt numeric(25,4),
    rate_charge_amt numeric(25,4),
    overage_charge_amt numeric(25,4),
    did bigint,
    mid bigint,
    sim_management_inventory_id bigint,
    id_10 bigint NULL,
	instance_id bigint NULL,
	modified_date timestamp NULL,
    CONSTRAINT fk_carrierrateplan FOREIGN KEY (assigned_carrier_rate_plan_id)
        REFERENCES public.carrier_rate_plan (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_customerrateplan FOREIGN KEY (assigned_customer_rate_plan_id)
        REFERENCES public.customerrateplan (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_customerratepool FOREIGN KEY (customer_rate_pool_id)
        REFERENCES public.customer_rate_pool (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX idx_optimizati1on_smi_result_queue_id ON public.optimization_smi_result USING btree (queue_id);
CREATE INDEX idx_optimizati1on_smi_resultsms_charge_amount ON public.optimization_smi_result USING btree (sms_charge_amount);
CREATE INDEX idx_optimization_smi_result_queue_id ON public.optimization_smi_result USING btree (queue_id) INCLUDE (amop_device_id, assigned_carrier_rate_plan_id, assigned_customer_rate_plan_id, charge_amt, id, sms_charge_amount, usage_mb);
CREATE INDEX idx_sms_charge_instance_id ON public.optimization_smi_result USING btree (instance_id);

CREATE TABLE IF NOT EXISTS public.optimization_device_result_customer_charge_queue
(
    id bigserial primary key,
    optimization_device_result_id bigint,
    is_processed boolean,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    charge_amount numeric(25,4),
    charge_id integer,
    base_charge_amount numeric(25,4),
    total_charge_amount numeric(25,4),
    has_errors boolean,
    error_message character varying(1000) COLLATE pg_catalog."default",
    rev_service_number character varying(250) COLLATE pg_catalog."default",
    rev_product_type_id integer,
    uploaded_file_id integer,
    billing_start_date timestamp without time zone,
    billing_end_date timestamp without time zone,
    description character varying(250) COLLATE pg_catalog."default",
    integration_authentication_id integer,
    billing_period_id integer,
    sms_rev_product_type_id integer,
    sms_charge_amount numeric(25,4),
    sms_charge_id integer,
    rate_charge_amt numeric(25,4),
    overage_charge_amt numeric(25,4),
    base_rate_amt numeric(25,4),
    overage_rev_product_type_id integer,
    rev_product_id integer,
    sms_rev_product_id integer,
    overage_rev_product_id integer,
    id_10 bigint NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_mobility_device_result_customer_charge_queue
(
    id bigserial primary key,
    optimization_mobility_device_result_id bigint,
    is_processed boolean,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    charge_amount numeric(25,4),
    charge_id integer,
    base_charge_amount numeric(25,4),
    total_charge_amount numeric(25,4),
    has_errors boolean,
    error_message character varying(1000) COLLATE pg_catalog."default",
    rev_service_number character varying(250) COLLATE pg_catalog."default",
    rev_product_type_id integer,
    uploaded_file_id integer,
    billing_start_date timestamp without time zone,
    billing_end_date timestamp without time zone,
    description character varying(250) COLLATE pg_catalog."default",
    integration_authentication_id integer,
    billing_period_id integer,
    sms_rev_product_type_id integer,
    sms_charge_amount numeric(25,4),
    sms_charge_id integer,
    rate_charge_amt numeric(25,4),
    overage_charge_amt numeric(25,4),
    base_rate_amt numeric(25,4),
    overage_rev_product_type_id integer,
    rev_product_id integer,
    sms_rev_product_id integer,
    overage_rev_product_id integer,
    id_10 bigint NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_smi_result_customer_charge_queue
(
    id bigserial primary key,
    optimization_device_result_id bigint,
    optimization_mobility_device_result_id bigint,
    is_processed boolean,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    charge_amount numeric(25,4),
    charge_id integer,
    base_charge_amount numeric(25,4),
    total_charge_amount numeric(25,4),
    has_errors boolean,
    error_message character varying(1000) COLLATE pg_catalog."default",
    rev_service_number character varying(250) COLLATE pg_catalog."default",
    rev_product_type_id integer,
    uploaded_file_id integer,
    billing_start_date timestamp without time zone,
    billing_end_date timestamp without time zone,
    description character varying(250) COLLATE pg_catalog."default",
    integration_authentication_id integer,
    billing_period_id integer,
    sms_rev_product_type_id integer,
    sms_charge_amount numeric(25,4),
    sms_charge_id integer,
    rate_charge_amt numeric(25,4),
    overage_charge_amt numeric(25,4),
    base_rate_amt numeric(25,4),
    overage_rev_product_type_id integer,
    rev_product_id integer,
    sms_rev_product_id integer,
    overage_rev_product_id integer,
    did bigint,
    mid bigint,
    optimization_smi_result_id bigint,
    id_10 bigint NULL,
    CONSTRAINT fk_billingperiod FOREIGN KEY (billing_period_id)
        REFERENCES public.billing_period (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_optimizationsmiresult FOREIGN KEY (optimization_smi_result_id)
        REFERENCES public.optimization_smi_result (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX idx_is_processed_charge_queue_instance_id ON public.optimization_smi_result_customer_charge_queue USING btree (is_processed);
CREATE INDEX idx_optimization_smi_result_customer_charge_queue_instance_id ON public.optimization_smi_result_customer_charge_queue USING btree (optimization_smi_result_id);
CREATE INDEX idx_vw_optimization_smi_result_customer_charge_queue_session_pr ON public.optimization_smi_result_customer_charge_queue USING btree (is_processed);


CREATE TABLE IF NOT EXISTS public.optimization_device_result_rate_plan_queue
(
    id bigserial primary key,
    optimization_device_result_id bigint NOT NULL,
    is_processed boolean NOT NULL,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    group_number integer NOT NULL,
    has_errors boolean NOT NULL,
    error_message text COLLATE pg_catalog."default",
    id_10 bigint NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_mobility_device_result_rate_plan_queue
(
    id bigserial primary key,
    optimization_mobility_device_result_id bigint NOT NULL,
    is_processed boolean NOT NULL,
    created_by character varying(100) COLLATE pg_catalog."default" NOT NULL,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    group_number integer NOT NULL,
    has_errors boolean NOT NULL,
    error_message text COLLATE pg_catalog."default",
    id_10 bigint NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_smi_result_rate_plan_queue
(
    id bigserial primary key,
    mid integer,
    did integer,
    optimization_mobility_device_result_id bigint,
    is_processed boolean,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    group_number integer,
    has_errors boolean,
    error_message text COLLATE pg_catalog."default",
    optimization_device_result_id bigint,
    optimization_smi_result_id bigint,
    id_10 bigint NULL,
    CONSTRAINT fk_optimizationsmiresult FOREIGN KEY (optimization_smi_result_id)
        REFERENCES public.optimization_smi_result (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.rev_service_product
(
    id serial primary key,
    service_product_id integer,
    customer_id character varying(50) COLLATE pg_catalog."default",
    product_id integer,
    package_id integer,
    service_id integer,
    description character varying(1024) COLLATE pg_catalog."default",
    code1 character varying(1024) COLLATE pg_catalog."default",
    code2 character varying(1024) COLLATE pg_catalog."default",
    rate numeric(25,4),
    billed_through_date timestamp without time zone,
    canceled_date timestamp without time zone,
    status character varying(150) COLLATE pg_catalog."default",
    status_date timestamp without time zone,
    status_user_id integer,
    activated_date timestamp without time zone,
    cost numeric(25,4),
    wholesale_description character varying(512) COLLATE pg_catalog."default",
    free_start_date timestamp without time zone,
    free_end_date timestamp without time zone,
    quantity integer,
    contract_start_date timestamp without time zone,
    contract_end_date timestamp without time zone,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    tax_included boolean,
    group_on_bill boolean,
    itemized boolean,
    created_by character varying(100) COLLATE pg_catalog."default",
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean,
    is_deleted boolean NULL,
    integration_authentication_id integer,
    pro_rate boolean,
    id_10 int NULL,
    CONSTRAINT fk_integration_authentication FOREIGN KEY (integration_authentication_id)
        REFERENCES public.integration_authentication (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX idx_rev_service_product_active ON public.rev_service_product USING btree (service_id) WHERE ((status)::text = 'ACTIVE'::text);
CREATE INDEX idx_rev_service_product_customer_id ON public.rev_service_product USING btree (customer_id);
CREATE INDEX idx_rev_service_product_integration_authentication_id ON public.rev_service_product USING btree (integration_authentication_id);
CREATE INDEX idx_rev_service_product_product_id ON public.rev_service_product USING btree (product_id);
CREATE INDEX idx_rev_service_product_product_id_service_id ON public.rev_service_product USING btree (product_id, service_id) WHERE (((status)::text = 'ACTIVE'::text) AND (is_active = true) AND (is_deleted = false));
CREATE INDEX idx_rev_service_product_service_id ON public.rev_service_product USING btree (service_id);
CREATE INDEX idx_rev_service_product_service_id_status_is_active_is_deleted ON public.rev_service_product USING btree (service_id, status, is_active, is_deleted) WHERE (((status)::text = 'ACTIVE'::text) AND (is_active = true) AND (is_deleted = false));
CREATE INDEX idx_rev_service_product_service_integration_id ON public.rev_service_product USING btree (service_id, integration_authentication_id);
CREATE INDEX idx_rev_service_product_status ON public.rev_service_product USING btree (status);
CREATE INDEX idx_rev_service_product_status_is_active_is_deleted ON public.rev_service_product USING btree (status, is_active, is_deleted);


CREATE TABLE IF NOT EXISTS public.automation_rule
(
    id serial primary key,
    automation_rule_name character varying(255) COLLATE pg_catalog."default",
    service_provider_id integer NOT NULL,
    description character varying(255) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    service_provider_name character varying(250) COLLATE pg_catalog."default",
    id_10 int NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id) REFERENCES public.serviceprovider(id)
);
CREATE INDEX IF NOT EXISTS idx_automation_rule_service_provider_id
    ON public.automation_rule USING btree
    (service_provider_id ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE TABLE IF NOT EXISTS public.app_file
(
    id serial primary key,
    amazon_file_name character varying(50) COLLATE pg_catalog."default",
    file_name character varying(500) COLLATE pg_catalog."default",
    tenant_id integer NOT NULL,
    created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    created_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
	id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.automation_get_usage_by_rate_plan
(
    id serial primary key,
    carrier_rate_plan_code character varying(50) COLLATE pg_catalog."default",
    tenant_id integer NOT NULL,
    service_provider_id integer NOT NULL,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone,
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp with time zone,
    is_active boolean NOT NULL default true,
    id_10 int NULL,
    CONSTRAINT fk_service_provider_id FOREIGN KEY (service_provider_id) REFERENCES public.serviceprovider(id)
);

CREATE TABLE IF NOT EXISTS public.automation_rule_type
(
    id serial primary key ,
    type_name character varying(50) ,
    created_by character varying(100) ,
    created_date timestamp with time zone NOT NULL,
    modified_by character varying(100) ,
    modified_date timestamp with time zone,
    deleted_by character varying(100) ,
    deleted_date timestamp with time zone,
    is_active boolean NOT NULL default true,
    id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.automation_rule_action
(
    id serial primary key,
    automation_rule_action_name character varying(255) COLLATE pg_catalog."default",
    automation_rule_action_code character varying(255) COLLATE pg_catalog."default",
    automation_rule_type integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    id_10 int NULL,
    CONSTRAINT fk_rule_automation_rule_type FOREIGN KEY (automation_rule_type) REFERENCES public.automation_rule_type(id) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE IF NOT EXISTS public.automation_rule_condition
(
    id serial primary key,
    automation_rule_condition_name character varying(255) COLLATE pg_catalog."default",
    automation_rule_type integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    id_10 int NULL,
    CONSTRAINT fk_automationrule_condition_automationrule_type FOREIGN KEY (automation_rule_type) REFERENCES public.automation_rule_type(id)
);

CREATE TABLE IF NOT EXISTS public.automation_rule_customer_rate_plan
(
    id serial primary key,
    automation_rule_id integer NOT NULL,
    customer_rate_plan_id integer NOT NULL,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    id_10 int NULL,
    CONSTRAINT fk_automation_rule FOREIGN KEY (automation_rule_id)
        REFERENCES public.automation_rule (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_customer_rate_plan FOREIGN KEY (customer_rate_plan_id)
        REFERENCES public.customerrateplan (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.automation_rule_customer_rate_plan_to_process
(
    id serial primary key,
    automation_rule_customer_rate_plan_id integer NOT NULL,
    group_number integer NOT NULL,
    created_by character varying(50) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modifed_date timestamp NULL,
    id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.automation_rule_followup_effective_date_type
(
    id serial primary key,
    name character varying(50) COLLATE pg_catalog."default",
    description character varying(255) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.automation_rule_followup
(
    id serial primary key,
    description character varying(100) COLLATE pg_catalog."default",
    rule_followup_effective_date_type_id integer NOT NULL,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    id_10 int NULL,
    CONSTRAINT fk_rule_followup_effective_date_type FOREIGN KEY (rule_followup_effective_date_type_id)
        REFERENCES public.automation_rule_followup_effective_date_type (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION

);

CREATE TABLE IF NOT EXISTS public.automation_rule_detail
(
    id serial primary key,
    automation_rule_id integer NOT NULL,
    rule_condition_id integer NOT NULL,
    rule_condition_value character varying(255) COLLATE pg_catalog."default",
    rule_action_id integer NOT NULL,
    rule_action_value character varying(255) COLLATE pg_catalog."default",
    condition_step integer,
    rule_followup_id integer,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    id_10 int NULL,
    CONSTRAINT fk_automation_rule FOREIGN KEY (automation_rule_id)
        REFERENCES public.automation_rule (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_automation_rule_action FOREIGN KEY (rule_action_id)
        REFERENCES public.automation_rule_action (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_automation_rule_condition FOREIGN KEY (rule_condition_id)
        REFERENCES public.automation_rule_condition (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_automation_rule_followup FOREIGN KEY (rule_followup_id)
        REFERENCES public.automation_rule_followup (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.automation_rule_followup_detail
(
    id serial primary key,
    rule_followup_id integer NOT NULL,
    rule_action_id integer NOT NULL,
    rule_action_value character varying(255) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    id_10 int NULL,
    CONSTRAINT fk_rule_action FOREIGN KEY (rule_action_id)
        REFERENCES public.automation_rule_action (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_rule_followup FOREIGN KEY (rule_followup_id)
        REFERENCES public.automation_rule_followup (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.automation_rule_log
(
    id serial primary key ,
    automation_rule_id integer NOT NULL,
    rule_condition_id integer NOT NULL,
    rule_action_id integer,
    status character varying(50) ,
    request_body text ,
    device_updated text ,
    response_body text ,
    description text ,
    file_name character varying(100) ,
    follow_up_action_id integer,
    created_by character varying(100),
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL,
    rule_detail_id integer,
    rule_follow_up_detail_id integer,
    instance_id character varying(50),
    id_10 int NULL,
    CONSTRAINT fk_automationrule_log_automationrule FOREIGN KEY (automation_rule_id) REFERENCES public.automation_rule(id),
	CONSTRAINT fk_automationrule_log_automationrule_action FOREIGN KEY (rule_action_id) REFERENCES public.automation_rule_action(id),
	CONSTRAINT fk_automationrule_log_automationrule_condition FOREIGN KEY (rule_condition_id) REFERENCES public.automation_rule_condition(id),
	CONSTRAINT fk_automationrule_log_automationrule_ruledetail FOREIGN KEY (rule_detail_id) REFERENCES public.automation_rule_detail(id),
	CONSTRAINT fk_automationrule_log_automationrule_rulefollowupdetail FOREIGN KEY (rule_follow_up_detail_id) REFERENCES public.automation_rule_followup_detail(id)
);





CREATE TABLE IF NOT EXISTS public.device_status_uploaded_file_detail
(
    id serial primary key ,
    uploaded_file_id integer NOT NULL,
    iccid character varying(50) ,
    status character varying(50) ,
    upload_status character varying(50),
    processed_date timestamp without time zone,
    processed_by character varying(50) ,
    created_by character varying(100) ,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone,
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL,
    is_deleted boolean not null default false,
    device_status_id integer,
    mdn_zip_code character varying(50) ,
    rate_plan_code character varying(50) ,
    additional_details_json text ,
    id_10 int NULL,
    CONSTRAINT fk_device_status_uploaded_file_detail_device_status FOREIGN KEY (device_status_id)
        REFERENCES public.device_status (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX idx_device_status_uploaded_file_detail_status_iccid_created_dat
ON public.device_status_uploaded_file_detail (status ASC, iccid ASC, created_date ASC)
INCLUDE (additional_details_json);

CREATE TABLE IF NOT EXISTS public.e_bonding_device
(
    id serial primary key ,
    service_provider_id integer NOT NULL,
    foundation_account_number character varying(30) ,
    billing_account_number character varying(30) ,
    billing_account_name character varying(100) ,
    subscriber_number character varying(20) ,
    subscriber_activated_date date NOT NULL,
    subscriber_status character varying(20) ,
    subscriber_status_effective_date date NOT NULL,
    subscriber_full_name character varying(50) ,
    device_make character varying(50) ,
    device_model character varying(50) ,
    imei character varying(30) ,
    contract_start_date date,
    contract_end_date date,
    device_effective_date date NOT NULL,
    service_type character varying(10)  NOT NULL,
    iccid character varying(50)  NOT NULL,
    rate_plan_name character varying(200) ,
    user_defined_label1 character varying(50),
    user_defined_label2 character varying(50) ,
    user_defined_label3 character varying(50) ,
    user_defined_label4 character varying(50) ,
    os_version character varying(50) ,
    imeisv character varying(50) ,
    technology_type character varying(50) ,
    created_by character varying(100)  NOT NULL,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL,
    device_sku character varying(50) ,
    rate_plan_friendly_name character varying(200),
    rate_plan_effective_date date,
    rate_plan_sku character varying(50) ,
    billing_address character varying(150) ,
    billing_city character varying(100) ,
    billing_state character varying(50) ,
    billing_zip_code character varying(25) ,
    ctd_data_usage bigint,
    old_ctd_data_usage bigint,
    plan_limit_mb numeric(25,4),
    data_group_id character varying(50) ,
    pool_id character varying(50) ,
    sms_count integer,
    old_sms_count integer,
    minutes_used integer,
    old_minutes_used integer,
    usage_record_count integer NOT NULL,
    last_usage_date timestamp without time zone,
    bill_year integer,
    bill_month integer,
    usage_aggregate_id integer,
    bill_cycle_end_date timestamp without time zone,
    rate_plan_short_name character varying(50),
    id_10 int NULL
);
CREATE INDEX idx_e_bonding_device_subscriber_number
ON e_bonding_device (subscriber_number ASC);
CREATE INDEX idx_e_bonding_usage_aggregate_id ON public.e_bonding_device USING btree (usage_aggregate_id);



CREATE TABLE IF NOT EXISTS public.e_bonding_device_sync_audit
(
    id serial primary key ,
    last_sync_date timestamp without time zone NOT NULL,
    active_count integer,
    suspend_count integer,
    created_by character varying(100) ,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL,
    is_deleted bool NOT NULL,
    bill_year integer,
    bill_month integer,
    service_provider_id integer,
    id_10 int NULL
);


CREATE TABLE IF NOT EXISTS public.jasper_device_sync_audit
(
    id serial primary key,
    last_sync_date timestamp without time zone NOT NULL,
    activated_count integer,
    activation_ready_count integer,
    deactivated_count integer,
    inventory_count integer,
    retired_count integer,
    test_ready_count integer,
    created_by character varying(100) ,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
    bill_year integer,
    bill_month integer,
    service_provider_id integer,
    id_10 int NULL
);


CREATE TABLE IF NOT EXISTS public.telegence_device
(
    id serial primary key ,
    service_provider_id integer NOT NULL,
    foundation_account_number character varying(50) ,
    billing_account_number character varying(50) ,
    subscriber_number character varying(50) ,
    subscriber_activated_date timestamp without time zone,
    subscriber_number_status character varying(10) ,
    refresh_timestamp timestamp without time zone,
    single_user_code character varying(50) ,
    single_user_code_description character varying(100) ,
    service_zip_code character varying(50),
    next_bill_cycle_date timestamp without time zone,
    iccid character varying(50) ,
    imei character varying(50) ,
    bill_year integer,
    bill_month integer,
    device_status_id integer,
    old_device_status_id integer,
    rate_plan_name character varying(50) ,
    ctd_data_usage bigint,
    old_ctd_data_usage bigint,
    plan_limit_mb numeric(25,4),
    data_group_id character varying(50) ,
    pool_id character varying(50) ,
    created_by character varying(100) ,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    last_activated_date timestamp without time zone,
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted boolean NOT NULL default false,
    account_number character varying(50) ,
    last_usage_date timestamp without time zone,
    usage_record_count integer NOT NULL,
    device_make character varying(50) ,
    device_model character varying(50),
    contract_status character varying(50) ,
    ban_status character varying(50) ,
    sms_count integer,
    old_sms_count integer,
    minutes_used integer,
    old_minutes_used integer,
    imei_type_id integer,
    usage_aggregate_id integer,
    contact_name character varying(150) ,
    billing_period_id integer,
    device_technology_type character varying(50) ,
    ip_address character varying(50)  ,
    id_10 int NULL,
    CONSTRAINT telegence_device_usage_aggregate_id_fkey FOREIGN KEY (usage_aggregate_id)
        REFERENCES public.mobility_device_usage_aggregate (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX idx_telegence_device_bill_year_bill_month ON public.telegence_device USING btree (bill_year, bill_month) INCLUDE (next_bill_cycle_date, service_provider_id);
CREATE INDEX idx_telegence_device_billing_period_id ON public.telegence_device USING btree (billing_period_id);
CREATE INDEX idx_telegence_device_pool_id_single_user_code ON public.telegence_device USING btree (pool_id, single_user_code) INCLUDE (billing_account_number);
CREATE INDEX idx_telegence_device_service_provider_id_bill_year_bill_month ON public.telegence_device USING btree (service_provider_id, bill_year, bill_month) INCLUDE (next_bill_cycle_date);
CREATE INDEX idx_telegence_device_subscriber_number ON public.telegence_device USING btree (subscriber_number);
CREATE INDEX idx_telegence_usage_aggregate_id ON public.telegence_device USING btree (usage_aggregate_id);


CREATE TABLE IF NOT EXISTS public.telegence_device_mobility_feature
(
    id serial primary key ,
    telegence_device_id integer NOT NULL,
    mobility_feature_id integer NOT NULL,
    created_by character varying(100) ,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone,
    last_activated_date timestamp without time zone,
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
	id_10 int NULL,
    CONSTRAINT telegence_device_mobility_feature_mobility_feature_id_fkey FOREIGN KEY (mobility_feature_id)
        REFERENCES public.mobility_feature (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT telegence_device_mobility_feature_telegence_device_id_fkey FOREIGN KEY (telegence_device_id)
        REFERENCES public.telegence_device (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX idx_telegence_device_mobility_feature ON public.telegence_device_mobility_feature USING btree (telegence_device_id, is_active, is_deleted);
CREATE INDEX idx_telegence_device_mobility_feature_telegence_device_id ON public.telegence_device_mobility_feature USING btree (telegence_device_id);



CREATE TABLE IF NOT EXISTS public.telegence_device_sync_audit
(
    id integer ,
    last_sync_date timestamp without time zone NOT NULL,
    active_count integer,
    suspend_count integer,
    created_by character varying(100) ,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
    bill_year integer,
    bill_month integer,
    service_provider_id integer,
    id_10 int NULL,
    CONSTRAINT telegence_device_sync_audit_pkey PRIMARY KEY (id)
);


CREATE TABLE IF NOT EXISTS public.thing_space_device_sync_audit
(
    id serial primary key ,
    last_sync_date timestamp without time zone NOT NULL,
    pre_active_count integer,
    active_count integer,
    deactive_count integer,
    suspend_count integer,
    pending_resume_count integer,
    pending_mdn_change_count integer,
    pending_prl_update_count integer,
    pending_preactive_count integer,
    pending_activation_count integer,
    pending_deactivation_count integer,
    pending_suspend_count integer,
    pending_service_plan_change_count integer,
    pending_esn_meid_change_count integer,
    pending_account_update_count integer,
    created_by character varying(100) ,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
    bill_year integer,
    bill_month integer,
    service_provider_id integer,
    id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.customer_billing_period
(
    id serial primary key,
    bill_year integer NOT NULL,
    bill_month integer NOT NULL,
    created_by character varying(100) ,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
    id_10 int NULL
);
CREATE INDEX idx_customer_billing_period_id ON public.customer_billing_period USING btree (id);
CREATE INDEX idx_customer_billing_period_year_month ON public.customer_billing_period USING btree (bill_year, bill_month);


CREATE TABLE IF NOT EXISTS public.imei_type
(
    id serial primary key,
    name character varying(50) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted boolean NOT NULL default false,
    id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.integration_connection
(
    id serial primary key,
    integration_id integer NOT NULL,
    production_url character varying(250)  NOT NULL,
    sandbox_url character varying(250) ,
    header_content text ,
    http_version_id integer NOT NULL,
    client_id text ,
    client_secret text ,
    created_by character varying(100) ,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    modified_by character varying(100) ,
    modified_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted boolean NOT NULL default false,
    auth_test_url text ,
    id_10 int NULL,
    CONSTRAINT integration_connection_integration_id_fkey FOREIGN KEY (integration_id)
        REFERENCES public.integration (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);


CREATE TABLE IF NOT EXISTS public.lnp_device_change
(
    id bigserial primary key,
    bulk_change_id bigint NOT NULL,
    phone_number character varying(50) COLLATE pg_catalog."default" NOT NULL,
    change_request text COLLATE pg_catalog."default",
    bandwidth_telephone_number_id integer,
    is_processed boolean NOT NULL,
    has_errors boolean NOT NULL,
    status character varying(50) COLLATE pg_catalog."default" NOT NULL,
    status_details text COLLATE pg_catalog."default",
    processed_date timestamp without time zone,
    processed_by character varying(50) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default" NOT NULL,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted boolean NOT NULL default false,
    device_change_request_id bigint,
    id_10 int NULL
);
CREATE INDEX idx_lnp_device_change_bulkchangeid_processed ON public.lnp_device_change USING btree (bulk_change_id);
CREATE INDEX idx_lnp_device_change_change_request_device_change_request_id_i ON public.lnp_device_change USING btree (device_change_request_id, id);
CREATE INDEX idx_lnp_device_change_is_active ON public.lnp_device_change USING btree (is_active);
CREATE INDEX idx_lnp_device_change_is_processed_bulkchangeid ON public.lnp_device_change USING btree (is_processed, bulk_change_id);
CREATE INDEX idx_lnp_device_change_phone_number_status ON public.lnp_device_change USING btree (phone_number, status);

CREATE TABLE IF NOT EXISTS public.device_status_uploaded_file
(
    id serial primary key,
    service_provider_id integer NOT NULL,
    file_name character varying(255)  NOT NULL,
    status character varying(50)  NOT NULL,
    description character varying(50) ,
    processed_date timestamp without time zone,
    processed_by character varying(50) ,
    created_by character varying(100)  NOT NULL,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) ,
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) ,
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL DEFAULT true,
    is_deleted boolean NOT NULL DEFAULT false,
    retired_count integer NOT NULL,
    card_count integer NOT NULL,
    processed_count integer NOT NULL,
    error_count integer NOT NULL,
    rev_customer_id character varying(50) ,
    tenant_id integer,
    app_file_id integer,
    customer_id integer,
    id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.smi_change_type_integration
(
    id serial primary key,
    change_request_type_id integer,
    change_request_type character varying(100),
    integration_id integer,
    modified_date timestamp NULL,
    id_10 int NULL
);

CREATE TABLE IF NOT EXISTS public.qualification
(
    id bigserial primary key,
    qualification_id character varying(50) COLLATE pg_catalog."default",
    is_qualified boolean NOT NULL,
    site_id character varying(50) COLLATE pg_catalog."default",
    service_line_id character varying(50) COLLATE pg_catalog."default",
    address_line character varying(100) COLLATE pg_catalog."default",
    city character varying(50) COLLATE pg_catalog."default",
    state character varying(50) COLLATE pg_catalog."default",
    country character varying(50) COLLATE pg_catalog."default",
    postal_code character varying(50) COLLATE pg_catalog."default",
    device_bulk_change_id bigint,
    tenant_id integer NOT NULL,
    status character varying(50) COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default" NOT NULL,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp with time zone,
    is_active boolean NOT NULL default true,
    is_deleted bool NOT NULL default false,
    id_10 bigint NULL
);

CREATE TABLE IF NOT EXISTS public.qualification_address (
    id BIGSERIAL PRIMARY KEY,
    qualification_id BIGINT NOT NULL,
    qualification_token VARCHAR(100),
    is_qualified BOOLEAN NOT NULL DEFAULT FALSE,
    customer_id VARCHAR(100),
    street_number VARCHAR(100),
    street_name VARCHAR(100),
    city VARCHAR(100),
    state VARCHAR(100),
    zip_code VARCHAR(100),
    country VARCHAR(100),
    created_by VARCHAR(100) NOT NULL,
    created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by VARCHAR(100),
    modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by VARCHAR(100),
    deleted_date TIMESTAMPTZ,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_deleted bool DEFAULT false NOT NULL,
    is_activated_by_service BOOLEAN NOT NULL DEFAULT FALSE,
    status VARCHAR(100),
    id_10 bigint NULL
);

CREATE TABLE IF NOT EXISTS public.qualification_log
(
    id bigserial primary key,
    qualification_id bigint NOT NULL,
    qualification_address_id bigint,
    level character varying(50) COLLATE pg_catalog."default" NOT NULL,
    message text COLLATE pg_catalog."default" NOT NULL,
    request text COLLATE pg_catalog."default" NOT NULL,
    response text COLLATE pg_catalog."default" NOT NULL,
    created_by character varying(100) COLLATE pg_catalog."default" NOT NULL,
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    id_10 bigint NULL,
    modified_date timestamp NULL,
	is_deleted bool NULL,
    CONSTRAINT fk_qualificationlog_qualificationaddresses FOREIGN KEY (qualification_address_id) REFERENCES public.qualification_address(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS public.e_bonding_device_mobility_feature
(
    id serial primary key,
    e_bonding_device_id integer NOT NULL,
    mobility_feature_id integer NOT NULL,
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    last_activated_date timestamp without time zone,
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_active boolean NOT NULL default true,
    is_deleted boolean NOT NULL default false,
    id_10 int NULL,
    CONSTRAINT fk_ebondingdevice FOREIGN KEY (e_bonding_device_id)
        REFERENCES public.e_bonding_device (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_mobility_feature FOREIGN KEY (mobility_feature_id)
        REFERENCES public.mobility_feature (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
CREATE INDEX IF NOT EXISTS idx_ebonding_device_mobility_feature_ebonding_device_id
    ON public.e_bonding_device_mobility_feature USING btree
    (e_bonding_device_id ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE TABLE IF NOT EXISTS public.awsdms_ddl_audit
(
    c_key bigserial primary key,
    c_time timestamp without time zone,
    c_user character varying(64) COLLATE pg_catalog."default",
    c_txn character varying(16) COLLATE pg_catalog."default",
    c_tag character varying(24) COLLATE pg_catalog."default",
    c_oid integer,
    c_name character varying(64) COLLATE pg_catalog."default",
    c_schema character varying(64) COLLATE pg_catalog."default",
    c_ddlqry text COLLATE pg_catalog."default"
);


CREATE TABLE IF NOT EXISTS public.smi_communication_plan_carrier_rate_plan
(
    id serial primary key,
    communication_plan_id integer,
    communication_plan_name character varying COLLATE pg_catalog."default",
    rate_plan_id integer,
    carrier_rate_plan_name character varying COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by character varying(100) COLLATE pg_catalog."default",
    modified_date timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by character varying(100) COLLATE pg_catalog."default",
    deleted_date timestamp without time zone,
    is_deleted bool NULL default false,
    rate_plan_code character varying(256) COLLATE pg_catalog."default",
    id_10 int NULL,
    CONSTRAINT fk_communication_plan FOREIGN KEY (communication_plan_id)
        REFERENCES public.sim_management_communication_plan (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_rate_plan FOREIGN KEY (rate_plan_id)
        REFERENCES public.carrier_rate_plan (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.inventory_actions_urls (
    id SERIAL PRIMARY KEY,
    service_provider_id VARCHAR,
    action VARCHAR,
    main_url VARCHAR,
    session_url VARCHAR,
    token_url VARCHAR,
    queue_url VARCHAR
);

CREATE TABLE IF NOT EXISTS public.mobility_configuration_change_queue (
    id SERIAL PRIMARY KEY,
    device_id INTEGER,
    mobility_device_id INTEGER,
    service_provider_id INTEGER NOT NULL,
    mobility_configuration_change_details TEXT NOT NULL,
    is_processed BOOLEAN NOT NULL,
    created_by VARCHAR(100) NOT NULL,
    created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by VARCHAR(100),
    modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    last_activated_date TIMESTAMP,
    deleted_by VARCHAR(100),
    deleted_date TIMESTAMP,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_deleted bool NOT NULL default false,
    tenant_id INTEGER,
    id_10 int NULL,
    CONSTRAINT fk_mobility_device FOREIGN KEY (mobility_device_id)
        REFERENCES public.mobility_device (id)
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_service_provider FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id)
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.open_search_index (
    id SERIAL PRIMARY KEY,
    search_module VARCHAR(100),
    search_tables VARCHAR(100),
    search_cols varchar,
    relations varchar,
    index_search_type VARCHAR(50),
    db_name VARCHAR,
    module_name VARCHAR
);

CREATE TABLE public.open_search_sync_flags (
	id SERIAL PRIMARY KEY,
	view_name text NOT NULL,
	flag bool DEFAULT false NOT NULL,
	last_updated_time timestamp NULL,
	rev_sync_update bool DEFAULT true NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_details (
    id SERIAL PRIMARY KEY,
    optimization_session_id VARCHAR,
    progress VARCHAR,
    error_message VARCHAR,
    customer_id VARCHAR,
    session_id uuid,
    id_10 int4 NULL,
	optimization_type_id int4 NULL,
	modified_date timestamp NULL
);

CREATE TABLE IF NOT EXISTS public.optimization_setting_ (
    id SERIAL PRIMARY KEY,
    auto_update_rateplans BOOLEAN,
    carrier_optimization_email_subject TEXT,
    carrier_optimization_from_email_address TEXT,
    carrier_optimization_ou TEXT,
    carrier_optimization_to_email_address TEXT,
    customer_optimization_email_subject TEXT,
    customer_optimization_from_email_address TEXT,
    customer_optimization_to_email_address TEXT,
    go_for_rateplan_update_email_subject TEXT,
    linux_timezone TEXT,
    no_go_for_rate_plan_update_email_subject TEXT,
    optimization_bcc_email_address TEXT,
    optimization_sync_device_error_email_subject TEXT,
    optino_continous_last_day_optimization BOOLEAN,
    optino_cross_providercustomer_optimization BOOLEAN,
    using_new_process_in_customer_charge BOOLEAN,
    windows_timezone TEXT,
    tenant_id INTEGER,
    modified_by VARCHAR(100),
    created_by VARCHAR(100),
    created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC')
);

CREATE TABLE if not exists public.optimization_setting (
	id serial primary key,
	auto_update_rateplans bool NULL,
	carrier_optimization_email_subject text NULL,
	carrier_optimization_from_email_address text NULL,
	carrier_optimization_ou text NULL,
	carrier_optimization_to_email_address text NULL,
	customer_optimization_email_subject text NULL,
	customer_optimization_from_email_address text NULL,
	customer_optimization_to_email_address text NULL,
	go_for_rateplan_update_email_subject text NULL,
	linux_timezone text NULL,
	no_go_for_rate_plan_update_email_subject text NULL,
	optimization_bcc_email_address text NULL,
	optimization_sync_device_error_email_subject text NULL,
	optino_continous_last_day_optimization bool NULL,
	optino_cross_providercustomer_optimization bool NULL,
	using_new_process_in_customer_charge bool NULL,
	windows_timezone text NULL,
	tenant_id int4 NULL,
	modified_by varchar(100) NULL,
	created_by varchar(100) NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
	modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
	id_10 int4 NULL,
	some_key1 varchar NULL,
	some_key2 varchar NULL,
	rev_io_push_customer_charge_type text NULL,
	revio_ftp_host varchar NULL,
	revio_ftp_password varchar NULL,
	rev_io_ftp_path varchar NULL,
	revio_ftp_username varchar NULL
);

CREATE TABLE IF NOT EXISTS public.rule_rule_definition (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    object_type_id UUID NOT NULL,
    rule_id VARCHAR(100),
    name VARCHAR(100) NOT NULL,
    priority INT NOT NULL DEFAULT 1,
    subject_line VARCHAR(250),
    display_message VARCHAR(250) NOT NULL,
    notes VARCHAR(500),
    order_of_execution INT NOT NULL DEFAULT 1,
    created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    created_by VARCHAR(100) NULL,
    modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by VARCHAR(100),
    deleted_date TIMESTAMP,
    deleted_by VARCHAR(100),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_deleted boolean DEFAULT false NOT NULL,
    send_to_carrier BOOLEAN NOT NULL DEFAULT TRUE,
    send_to_customer BOOLEAN NOT NULL DEFAULT FALSE,
    should_show_projected_usage_cost BOOLEAN NOT NULL DEFAULT TRUE,
    version_no VARCHAR,
    version_update_purpose VARCHAR,
    rule_id_1_0 UUID,
    rule_def_id VARCHAR,
    service_provider VARCHAR,
    customers_list TEXT,
    expression_ids TEXT,
    expression_names TEXT,
    id_10 uuid null
);
CREATE INDEX idx_rule_rule_definition_created_date ON public.rule_rule_definition USING btree (created_date);
CREATE INDEX idx_rule_rule_definition_id ON public.rule_rule_definition USING btree (id);

CREATE TABLE IF NOT EXISTS public.thing_space_device (
    id SERIAL PRIMARY KEY,
    iccid VARCHAR(50),
    imei VARCHAR(50) ,
    status VARCHAR(50) ,
    rate_plan VARCHAR(50) ,
    communication_plan VARCHAR(50) ,
    last_usage_date TIMESTAMP WITHOUT TIME ZONE,
    primary_place_of_use_first_name VARCHAR(50) ,
    primary_place_of_use_middle_name VARCHAR(50) ,
    primary_place_of_use_last_name VARCHAR(50),
    thing_space_ppu TEXT,
    created_by VARCHAR(100),
    created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by VARCHAR(100) ,
    modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    last_activated_date TIMESTAMP WITHOUT TIME ZONE,
    deleted_by VARCHAR(100) ,
    deleted_date TIMESTAMP WITHOUT TIME ZONE,
    is_active BOOLEAN NOT NULL default true,
    is_deleted boolean NOT NULL default false,
    device_status_id INTEGER,
    ip_address VARCHAR(50) ,
    service_provider_id INTEGER NOT NULL,
    id_10 int NULL,
    CONSTRAINT fk_thingspace_device_service_provider FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.thing_space_device_detail
(
    id SERIAL PRIMARY KEY,
    iccid VARCHAR(50) NOT NULL,
    apn VARCHAR(250),
    "package" VARCHAR(250),
    bill_year INTEGER,
    bill_month INTEGER,
    created_by VARCHAR(100) NOT NULL,
    created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by VARCHAR(100),
    modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    last_activated_date TIMESTAMP WITHOUT TIME ZONE,
    deleted_by VARCHAR(100),
    deleted_date TIMESTAMP WITHOUT TIME ZONE,
    is_active BOOLEAN NOT NULL default true,
    is_deleted bool NOT NULL default false,
    account_number VARCHAR(50),
    thing_space_date_added TIMESTAMP WITHOUT TIME ZONE,
    thing_space_date_activated TIMESTAMP WITHOUT TIME ZONE,
    billing_cycle_end_date TIMESTAMP WITHOUT TIME ZONE,
    service_provider_id INTEGER,
    id_10 int NULL,
    CONSTRAINT fk_thingspace_device_detail_service_provider FOREIGN KEY (service_provider_id)
        REFERENCES public.serviceprovider (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.thing_space_device_usage
(
    id SERIAL PRIMARY KEY,
    iccid VARCHAR(150),
    imsi VARCHAR(150),
    msisdn VARCHAR(150),
    imei VARCHAR(150),
    status VARCHAR(150),
    rate_plan VARCHAR(150),
    communication_plan VARCHAR(255),
    ctd_data_usage BIGINT,
    ctd_sms_usage BIGINT,
    ctd_voice_usage BIGINT,
    ctd_session_count INTEGER,
    overage_limit_reached BOOLEAN,
    overage_limit_override VARCHAR(50),
    bill_year INTEGER,
    bill_month INTEGER,
    created_by VARCHAR(100) NOT NULL,
    created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    modified_by VARCHAR(100),
    modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
    deleted_by VARCHAR(100),
    deleted_date TIMESTAMP WITHOUT TIME ZONE,
    is_active BOOLEAN NOT NULL default true,
    is_deleted boolean NOT NULL default false,
    device_status_id INTEGER,
    old_ctd_data_usage BIGINT,
    old_device_status_id INTEGER,
    service_provider_id INTEGER,
    id_10 int NULL,
    CONSTRAINT fk_thingspace_device_usage_device_status FOREIGN KEY (device_status_id)
        REFERENCES public.device_status (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE if not exists public.view_schedule_data (
	id serial primary key,
	tenant_name varchar NULL,
	"view" varchar NULL
);

CREATE TABLE if not exists public.rule_expression (
    id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    rule_definition_id uuid NULL,
    expression_type_id uuid NOT NULL,
    field_id uuid NULL,
    constant_type_id uuid NULL,
    constant_data_type_id int4 NULL,
    constant_value varchar(250) COLLATE "en_US" NULL,
    left_hand_expression_id uuid NULL,
    operator_id uuid NULL,
    right_hand_expression_id uuid NULL,
    ordinal int4 DEFAULT 1 NOT NULL,
    indent_level int4 DEFAULT 0 NOT NULL,
    created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NOT NULL,
    created_by varchar(100) COLLATE "en_US" NOT NULL,
    modified_date timestamp NULL,
    modified_by varchar(100) COLLATE "en_US" NULL,
    deleted_date timestamp NULL,
    deleted_by varchar(100) COLLATE "en_US" NULL,
    is_deleted bool DEFAULT false NOT NULL,
    is_active bool DEFAULT true NOT NULL,
    version_id uuid NULL,
    id_10 uuid NULL
);

CREATE TABLE public.rule_expression_type (
	id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
	"name" varchar(50) COLLATE "en_US" NOT NULL,
	value int4 NOT NULL,
	created_by varchar(100) COLLATE "en_US" NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	modified_by varchar(100) COLLATE "en_US" NULL,
	modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	deleted_by varchar(100) COLLATE "en_US" NULL,
	deleted_date timestamp NULL,
	is_deleted bool DEFAULT false NOT NULL,
	is_active bool DEFAULT true NOT NULL,
	id_10 uuid NULL
);

CREATE TABLE public.rule_field (
	id uuid DEFAULT gen_random_uuid() NOT NULL primary key,
	field_name varchar(100) NOT NULL,
	object_type_id uuid NOT NULL,
	data_type_id int4 NOT NULL,
	display_name varchar(100) NULL,
	is_nullable bool DEFAULT false NOT NULL,
	created_by varchar(100) NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NOT NULL,
	modified_by varchar(100) NULL,
	modified_date timestamp NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_deleted bool DEFAULT false NOT NULL,
	is_active bool DEFAULT true NOT NULL,
	id_10 uuid NULL
);

CREATE TABLE public.rule_object_type (
	id uuid DEFAULT gen_random_uuid() NOT NULL primary key,
	"name" varchar(50) NOT NULL,
	value int4 NOT NULL,
	db_object_name varchar(100) NOT NULL,
	is_target_type bool DEFAULT false NOT NULL,
	created_by varchar(100) NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	modified_by varchar(100) NULL,
	modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamptz NULL,
	is_deleted bool DEFAULT false NOT NULL,
	is_active bool DEFAULT true NOT NULL,
	id_10 uuid NULL
);


CREATE TABLE public.rule_operator_type (
	id uuid DEFAULT gen_random_uuid() NOT NULL primary key,
	"name" varchar(50) NOT NULL,
	value int4 NOT NULL,
	description varchar(250) NULL,
	has_left_hand_expr bool NOT NULL,
	has_right_hand_expr bool NOT NULL,
	is_concat_operator bool NOT NULL,
	is_case_operator bool NOT NULL,
	created_by varchar(100) NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	modified_by varchar(100) NULL,
	modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamptz NULL,
	is_deleted bool NOT NULL,
	is_active bool NOT NULL,
	id_10 uuid NULL
);

CREATE TABLE public.optimization_commgroup_commplan (
	id bigserial primary key,
	instance_id int8 NOT NULL,
	commgroup_id int8 NOT NULL,
	commplan_id int4 NOT NULL,
	communication_plan_name varchar(250) NULL,
	created_by varchar(100) DEFAULT 'System'::character varying NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	modified_by varchar(100) NULL,
	modified_date timestamptz NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamptz NULL,
	is_deleted bool DEFAULT false NOT NULL,
    id_10 bigint null
);

CREATE TABLE public.optimization_commgroup_optimization_group (
	id bigserial primary key,
	instance_id int8 NOT NULL,
	commgroup_id int8 NOT NULL,
	optimization_group_id int4 NOT NULL,
	optimization_group_name varchar(250) NULL,
	created_by varchar(100) DEFAULT 'System'::character varying NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	modified_by varchar(100) NULL,
	modified_date timestamptz NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamptz NULL,
	is_deleted bool DEFAULT false NOT NULL,
    id_10 bigint null
);

CREATE TABLE public.optimization_queue_rate_plan (
	id bigserial primary key,
	queue_id int8 NOT NULL,
	commgroup_rate_plan_id int8 NOT NULL,
	sequence_order int4 NOT NULL,
	created_by varchar(100) NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	modified_by varchar(100) NULL,
	modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamptz NULL,
	is_deleted bool DEFAULT false NOT NULL,
    id_10 bigint null
);

CREATE TABLE public.cross_provider_device_history (
    id bigSERIAL PRIMARY KEY,
    m2m_device_id INT NULL,
    mobility_device_id INT NULL,
    service_provider_id INT NOT NULL,
    iccid VARCHAR(50) NOT NULL,
    msisdn VARCHAR(150) NULL,
    imsi VARCHAR(150) NULL,
    imei VARCHAR(150) NULL,
    foundation_account_number VARCHAR(30) NULL,
    billing_account_number VARCHAR(30) NULL,
    carrier_rate_plan_id INT NULL,
    created_by VARCHAR(100)  NULL,
    created_date TIMESTAMP without time zone default current_timestamp,
    modified_by VARCHAR(100) NULL,
    modified_date TIMESTAMP without time zone NULL,
    deleted_by VARCHAR(100) NULL,
    deleted_date TIMESTAMP NULL,
    is_active BOOLEAN NOT NULL,
    is_deleted BOOLEAN NOT NULL,
    account_number VARCHAR(50) NULL,
    account_number_integration_authentication_id INT NULL,
    customer_billing_period_id INT NULL,
    customer_id INT NULL,
    customer_rate_plan_id INT NULL,
    customer_rate_pool_id INT NULL,
    tenant_id INT NULL,
    customer_data_allocation_mb NUMERIC(25, 4) NULL,
    provider_date_added TIMESTAMP NULL,
    provider_date_activated TIMESTAMP NULL,
    username VARCHAR(250) NULL,
    id_10 int null,
    changed_date timestamp NULL,
	device_status_id int4 NULL,
	status varchar(50) NULL,
	rate_plan varchar(255) NULL,
	last_usage_date timestamp NULL,
	apn varchar(250) NULL,
	carrier_cycle_usage int8 NULL,
	ctd_sms_usage int8 NULL,
	ctd_voice_usage int8 NULL,
	ctd_session_count int8 NULL,
	last_activated_date timestamp NULL,
	old_device_status_id int4 NULL,
	old_ctd_data_usage int8 NULL,
	billing_period_id int4 NULL,
	single_user_code varchar(200) NULL,
	single_user_code_description varchar(200) NULL,
	service_zip_code varchar(50) NULL,
	data_group_id varchar(50) NULL,
	pool_id varchar(50) NULL,
	device_make varchar(50) NULL,
	device_model varchar(50) NULL,
	contract_status varchar(50) NULL,
	ban_status varchar(50) NULL,
	imei_type_id int4 NULL,
	plan_limit_mb numeric(25, 4) NULL,
	mobility_device_tenant_id int4 NULL,
	package varchar(250) NULL,
	ip_address varchar(50) NULL,
	is_pushed bool NULL,
	billing_cycle_end_date timestamp NULL,
	bill_year int4 NULL,
	bill_month int4 NULL,
	overage_limit_reached bool NULL,
	overage_limit_override varchar(50) NULL,
	cost_center varchar(250) NULL,
	device_tenant_id int4 NULL,
	communication_plan varchar(255) NULL,
	service_provider_display_name varchar(250) NULL,
	dh_id_col int4 NULL,
	mdh_id_col int4 NULL,
	history_id int4 NULL,
	m2m_hid int4 NULL,
	mob_hid int4 NULL,
    CONSTRAINT fk_cross_provider_device_history_carrier_rate_plan FOREIGN KEY (carrier_rate_plan_id)
        REFERENCES public.carrier_rate_plan(id),
    CONSTRAINT fk_cross_provider_device_history_customer_billing_period FOREIGN KEY (customer_billing_period_id)
        REFERENCES public.customer_billing_period(id),
    CONSTRAINT fk_cross_provider_device_history_customer_rate_plan FOREIGN KEY (customer_rate_plan_id)
        REFERENCES public.customerrateplan(id),
    CONSTRAINT fk_cross_provider_device_history_customer_rate_pool FOREIGN KEY (customer_rate_pool_id)
        REFERENCES public.customer_rate_pool(id)
);
CREATE INDEX idx_cpdh_customer_billing_period_id ON public.cross_provider_device_history USING btree (customer_billing_period_id, customer_id);
CREATE INDEX idx_cross_provider_device_history_carrier_rate_plan_id ON public.cross_provider_device_history USING btree (carrier_rate_plan_id);
CREATE INDEX idx_cross_provider_device_history_customer_id ON public.cross_provider_device_history USING btree (customer_id);
CREATE INDEX idx_cross_provider_device_history_customer_rate_plan_id ON public.cross_provider_device_history USING btree (customer_rate_plan_id);
CREATE INDEX idx_cross_provider_device_history_customer_rate_pool_id ON public.cross_provider_device_history USING btree (customer_rate_pool_id);
CREATE INDEX idx_cross_provider_device_history_id ON public.cross_provider_device_history USING btree (id);
CREATE INDEX idx_cross_provider_device_history_is_active ON public.cross_provider_device_history USING btree (is_active);
CREATE INDEX idx_cross_provider_device_history_is_active_is_deleted ON public.cross_provider_device_history USING btree (is_active, is_deleted);
CREATE INDEX idx_cross_provider_device_history_modified_date ON public.cross_provider_device_history USING btree (modified_date);
CREATE INDEX idx_cross_provider_device_history_service_provider_id ON public.cross_provider_device_history USING btree (service_provider_id);
CREATE INDEX idx_cross_provider_device_history_tenant_id ON public.cross_provider_device_history USING btree (tenant_id);

CREATE TABLE public.rev_service_false (
	id serial primary key,
	rev_service_ids jsonb NULL,
	status varchar NULL,
	view_name jsonb NULL,
	linked_cols jsonb NULL,
	module_name varchar(50) NULL,
	modified_date timestamp NULL,
    error_msg varchar NULL
);

CREATE TABLE public.trigger_error_logs (
	id serial primary key,
	trigger_name text NULL,
	error_msg text NULL,
	error_id int8 NULL,
	error_iccid text NULL,
	error_timestamp TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	trigger_table varchar NULL,
    error_query text NULL
);

CREATE TABLE public.rev_package_product (
	id serial primary key,
	package_product_id int4 NOT NULL,
	product_id int4 NULL,
	package_id int4 NULL,
	description varchar(1024) NULL,
	code1 varchar(1024) NULL,
	code2 varchar(1024) NULL,
	rate numeric(25, 4) NULL,
	"cost" numeric(25, 4) NULL,
	buy_rate numeric(25, 4) NULL,
	quantity int4 NULL,
	tax_included bool NULL,
	group_on_bill bool NULL,
	itemized bool NULL,
	credit bool NULL,
	created_by varchar(100) NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	modified_by varchar(100) NULL,
	modified_date timestamp NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_deleted bool DEFAULT false NOT NULL,
	is_active bool DEFAULT true NOT NULL,
	integration_authentication_id int4 NULL,
	rev_product_id int4 NULL,
	rev_package_id int4 NULL,
	id_10 int4 NULL,
	CONSTRAINT fk_rev_package_product_integration_authentication FOREIGN KEY (integration_authentication_id) REFERENCES public.integration_authentication(id),
	CONSTRAINT fk_rev_package_product_rev_package FOREIGN KEY (rev_package_id) REFERENCES public.rev_package(id),
	CONSTRAINT fk_rev_package_product_rev_product FOREIGN KEY (rev_product_id) REFERENCES public.rev_product(id)
);

CREATE TABLE public.telegence_device_status_reason_code (
	id serial primary key,
	device_status_id int4 NOT NULL,
	reason_code varchar(50) COLLATE "C" NULL,
	description varchar(100) COLLATE "C" NULL,
	created_by varchar(100) NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	modified_by varchar(100) NULL,
	modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_active bool NOT NULL,
	is_deleted bool NOT NULL,
	id_10 int4 NULL
);

CREATE TABLE public.bill_charge_overview (
	id serial primary key,
	account_number varchar(40) NULL,
	bill_id varchar(46) NULL,
	bill_basic_details jsonb NULL,
	usage_details jsonb NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	modified_date timestamp NULL,
	created_by varchar NULL
);

CREATE TABLE public.bill_charge_services (
	id serial primary key,
	account_number varchar(40) NULL,
	bill_id varchar(46) NULL,
	service_id varchar(255) NULL,
	package varchar(255) NULL,
	account varchar(255) NULL,
	taxes numeric(10, 2) NULL,
	total numeric(10, 2) NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	modified_date timestamp NULL,
	created_by varchar NULL
);

CREATE TABLE public.data_type (
	id serial primary key,
	data_type_name varchar(50) NOT NULL,
	id_10 int4 NULL
);

CREATE TABLE public."datatype" (
	id serial primary key,
	datatypename varchar(50) NOT NULL
);

CREATE TABLE public.notification_rule_recipient (
	id uuid DEFAULT gen_random_uuid() NOT NULL,
	rule_id uuid NOT NULL,
	customer_id int4 NULL,
	customer_group_id int4 NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	created_by varchar(100) NOT NULL,
	modified_date timestamp NULL,
	modified_by varchar(100) NULL,
	deleted_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	deleted_by varchar(100) NULL,
	is_deleted bool DEFAULT false NOT NULL,
	is_active bool DEFAULT true NOT NULL,
	id_10 uuid NULL,
	CONSTRAINT notification_rule_recipient_pkey PRIMARY KEY (id)
);

CREATE TABLE public.open_search_sync (
	id serial primary key,
	view_name varchar(350) NULL,
	end_sync_date timestamp NULL,
	last_executed_date timestamp NULL
);

CREATE TABLE public.opensearch_lambda_status (
	id serial primary key,
	view_name varchar(255) NOT NULL,
	db_name varchar(255) NOT NULL,
	flag bool NOT NULL
);


CREATE TABLE public.rule_version (
	id uuid DEFAULT gen_random_uuid() NOT NULL,
    rule_id uuid NOT NULL,
	version_number int4 DEFAULT 1 NOT NULL,
	object_type_id uuid NOT NULL,
	"name" varchar(100) NOT NULL,
	priority int4 NOT NULL,
	subject_line varchar(250) NULL,
	display_message varchar(250) NOT NULL,
	notes varchar(500) NULL,
	order_of_execution int4 NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NOT NULL,
	created_by varchar(100) NOT NULL,
	modified_date timestamp NULL,
	modified_by varchar(100) NULL,
	deleted_date timestamp NULL,
	deleted_by varchar(100) NULL,
	is_deleted bool DEFAULT false NOT NULL,
	is_active bool DEFAULT true NOT NULL,
	send_to_carrier bool DEFAULT true NOT NULL,
	send_to_customer bool DEFAULT false NOT NULL,
	should_show_projected_usage_cost bool DEFAULT true NOT NULL,
	reason varchar(500) NULL,
	id_10 uuid NULL,
	CONSTRAINT rule_version_pkey PRIMARY KEY (id),
	CONSTRAINT fk_rule_version_rule_object_type FOREIGN KEY (object_type_id) REFERENCES public.rule_object_type(id),
	CONSTRAINT fk_rule_version_rule_rule_definition FOREIGN KEY (rule_id) REFERENCES public.rule_rule_definition(id)
);

CREATE TABLE public.telegence_device_mobility_deleted_feature (
	id serial primary key,
	telegence_mobility_feature_id int4 NOT NULL,
	telegence_device_id int4 NOT NULL,
	mobility_feature_id int4 NOT NULL,
	created_by varchar(100) NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NOT NULL,
	modified_by varchar(100) NULL,
	modified_date timestamp NULL,
	last_activated_date timestamp NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_active bool NULL,
	is_deleted bool NULL
);

CREATE TABLE public.telegence_device_usage (
	id serial PRIMARY KEY,
	service_provider_id int4 NOT NULL,
	billing_account_number varchar(50) NOT NULL,
	subscriber_number varchar(50) NOT NULL,
	data_group_id varchar(50) NULL,
	pool_id varchar(50) NULL,
	rate_plan_name varchar(50) NULL,
	data_usage_bytes int8 NULL,
	old_ctd_data_usage int8 NULL,
	plan_limit_mb numeric(25, 4) NULL,
	bill_year int4 NULL,
	bill_month int4 NULL,
	created_by varchar(100) NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NOT NULL,
	modified_by varchar(100) NULL,
	modified_date timestamp NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_active bool DEFAULT true NOT NULL,
	is_deleted bool DEFAULT false NOT NULL,
	contract_status varchar(50) NULL,
	ban_status varchar(50) NULL,
	sms_count int4 NULL,
	plan_limit_sms int4 NULL,
	old_sms_count int4 NULL,
	minutes_used int4 NULL,
	plan_limit_minutes int4 NULL,
	old_minutes_used int4 NULL
);

CREATE TABLE public.rev_service_false_test (
	id serial primary key,
	rev_service_ids jsonb NULL,
	status varchar NULL,
	view_name jsonb NULL,
	modified_date timestamp NULL
);

CREATE TABLE public.device_history_crossprovider (
	device_history_id bigserial primary key,
	changed_date timestamp DEFAULT (now() AT TIME ZONE 'UTC'::text) NOT NULL,
	id int4 NULL,
	service_provider_id int4 NULL,
	iccid varchar(50) NULL,
	imsi varchar(150) NULL,
	msisdn varchar(150) NULL,
	imei varchar(150) NULL,
	device_status_id int4 NULL,
	status varchar(50) NULL,
	carrier_rate_plan_id int4 NULL,
	rate_plan varchar(255) NULL,
	communication_plan varchar(255) NULL,
	last_usage_date timestamp NULL,
	apn varchar(250) NULL,
	package varchar(250) NULL,
	billing_cycle_end_date timestamp NULL,
	bill_year int4 NULL,
	bill_month int4 NULL,
	carrier_cycle_usage int8 NULL,
	ctd_sms_usage int8 NULL,
	ctd_voice_usage int8 NULL,
	ctd_session_count int8 NULL,
	overage_limit_reached bool NULL,
	overage_limit_override varchar(50) NULL,
	created_by varchar(100) NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	modified_by varchar(100) NULL,
	modified_date timestamp NULL,
	last_activated_date timestamp NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_active bool DEFAULT true NULL,
	is_deleted bool DEFAULT false NULL,
	account_number varchar(50) NULL,
	provider_date_added timestamp NULL,
	provider_date_activated timestamp NULL,
	old_device_status_id int4 NULL,
	old_ctd_data_usage int8 NULL,
	cost_center varchar(250) NULL,
	username varchar(250) NULL,
	account_number_integration_authentication_id int4 NULL,
	billing_period_id int4 NULL,
	customer_id int4 NULL,
	customer_rate_plan_id int4 NULL,
	customer_rate_pool_id int4 NULL,
	device_tenant_id int4 NULL,
	tenant_id int4 NULL,
	is_pushed bool DEFAULT false NULL,
	customer_data_allocation_mb numeric(25, 4) NULL,
	id_10 int8 NULL

);

CREATE TABLE public.mobility_device_history_crossprovider (
	device_history_id bigserial primary key,
	changed_date timestamp NOT NULL,
	id int4 NOT NULL,
	service_provider_id int4 NOT NULL,
	foundation_account_number varchar(30) NOT NULL,
	billing_account_number varchar(30) NOT NULL,
	iccid varchar(50) NOT NULL,
	imsi varchar(150) NULL,
	msisdn varchar(150) NULL,
	imei varchar(150) NULL,
	device_status_id int4 NULL,
	status varchar(50) NULL,
	carrier_rate_plan_id int4 NULL,
	rate_plan varchar(200) NULL,
	last_usage_date timestamp NULL,
	carrier_cycle_usage int8 NULL,
	ctd_sms_usage int8 NULL,
	ctd_voice_usage int8 NULL,
	ctd_session_count int8 NULL,
	created_by varchar(100) NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC') NULL,
	modified_by varchar(100) NULL,
	modified_date timestamp NULL,
	last_activated_date timestamp NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_active bool NOT NULL,
	is_deleted bool NOT NULL,
	account_number varchar(50) NULL,
	provider_date_added timestamp NULL,
	provider_date_activated timestamp NULL,
	old_device_status_id int4 NULL,
	old_ctd_data_usage int8 NULL,
	account_number_integration_authentication_id int4 NULL,
	billing_period_id int4 NULL,
	customer_id int4 NULL,
	single_user_code varchar(200) NULL,
	single_user_code_description varchar(200) NULL,
	service_zip_code varchar(50) NULL,
	data_group_id varchar(50) NULL,
	pool_id varchar(50) NULL,
	device_make varchar(50) NULL,
	device_model varchar(50) NULL,
	contract_status varchar(50) NULL,
	ban_status varchar(50) NULL,
	imei_type_id int4 NULL,
	plan_limit_mb numeric(25, 4) NULL,
	customer_rate_plan_id int4 NULL,
	customer_data_allocation_mb numeric(25, 4) NULL,
	username varchar(150) NULL,
	customer_rate_pool_id int4 NULL,
	mobility_device_tenant_id int4 NULL,
	tenant_id int4 NULL,
	ip_address varchar(50) NULL,
	is_pushed bool NOT NULL,
	id_10 int8 NULL
);

 CREATE TABLE service_type_mapping (
    id serial PRIMARY KEY,
    service_type_id INT,
    service_provider TEXT,
    service_type_description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_date TIMESTAMP WITHOUT TIME ZONE DEFAULT (now() AT TIME ZONE 'UTC'),
    created_by VARCHAR(200),
    modified_date TIMESTAMP WITHOUT TIME ZONE,
    modified_by VARCHAR(200)
);

CREATE TABLE public.customer_group_customer (
	id serial primary key,
	customer_group_id int4 NOT NULL,
	customer_id int4 NOT NULL,
	is_active bool DEFAULT true NULL,
	is_deleted bool DEFAULT false NULL,
	modified_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
	id_10 int4 NULL,
	modified_by varchar NULL,
	CONSTRAINT uc_sitegroup_customer_id UNIQUE (customer_group_id, customer_id),
	CONSTRAINT fk_customer_group FOREIGN KEY (customer_group_id) REFERENCES public.customergroups(id) ON UPDATE CASCADE
);

CREATE TABLE public.customer_group_customer_rate_plan (
	id serial primary key,
	customer_group_id int4 NOT NULL,
	customer_rate_plan_id int4 NOT NULL,
	is_active bool DEFAULT true NULL,
	is_deleted bool DEFAULT false NULL,
	modified_date TIMESTAMP WITHOUT TIME ZONE DEFAULT (now() AT TIME ZONE 'UTC'),
	id_10 int4 NULL,
	modified_by varchar NULL,
	CONSTRAINT uc_sitegroup_customerrateplan UNIQUE (customer_group_id, customer_rate_plan_id),
	CONSTRAINT fk_customer_group FOREIGN KEY (customer_group_id) REFERENCES public.customergroups(id) ON UPDATE CASCADE
);

CREATE TABLE public.customer_group_mobility_feature (
	id serial primary key,
	customer_group_id int4 NOT NULL,
	mobility_feature_id int4 NOT NULL,
	is_active bool DEFAULT true NULL,
	is_deleted bool DEFAULT false NULL,
	created_by varchar DEFAULT 'System'::character varying NULL,
	created_date TIMESTAMP WITHOUT TIME ZONE DEFAULT (now() AT TIME ZONE 'UTC'),
	modified_date TIMESTAMP WITHOUT TIME ZONE DEFAULT (now() AT TIME ZONE 'UTC'),
	id_10 int4 NULL,
	modified_by varchar NULL,
	CONSTRAINT uc_sitegroup_mobility_feature_id UNIQUE (customer_group_id, mobility_feature_id),
	CONSTRAINT fk_customer_group FOREIGN KEY (customer_group_id) REFERENCES public.customergroups(id) ON UPDATE CASCADE
);

CREATE TABLE public.optimization_setting_tenant_override (
    id serial primary key,
	tenant_id int4 NOT NULL,
	setting_value text NULL,
	created_by varchar(100) DEFAULT 'System'::character varying NOT NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
	modified_by varchar(100) NULL,
	modified_date timestamp NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_active bool DEFAULT true NOT NULL,
	is_deleted bool DEFAULT false NOT NULL,
	optino_cross_providercustomer_optimization bool NULL,
	CONSTRAINT uq_optimization_setting_tenant_override UNIQUE (tenant_id)
);

CREATE TABLE public.soc_list (
	id serial PRIMARY KEY,
	product_family varchar(250) DEFAULT NULL::character varying NULL,
	rate_plan_or_feature varchar(255) DEFAULT NULL::character varying NULL,
	soc_code varchar(255) DEFAULT NULL::character varying NULL,
	friendly_name varchar(1028) DEFAULT NULL::character varying NULL,
	description text NULL,
	monthly_charge numeric(15, 3) DEFAULT NULL::numeric NULL,
	data_in_gb numeric(15, 3) DEFAULT NULL::numeric NULL,
	device_type varchar(255) DEFAULT NULL::character varying NULL,
	os varchar(255) DEFAULT NULL::character varying NULL,
	network varchar(255) DEFAULT NULL::character varying NULL,
	imei_type text NULL,
	refreshed_timestamp timestamp NULL,
	created_date TIMESTAMP DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
	created_by varchar(255) DEFAULT 'System'::character varying NULL,
	modified_date timestamp NULL,
	modified_by varchar(255) DEFAULT NULL::character varying NULL,
	is_active bool DEFAULT true NULL,
	is_deleted bool DEFAULT false NULL
);

CREATE TABLE public.thingspace_device_status_reason_code (
	id serial primary key,
	device_status_id int4 NOT NULL,
	reason_code varchar(50) NULL,
	description varchar(100) NULL,
	created_by varchar(100) NOT NULL,
	created_date timestamp NOT NULL,
	modified_by varchar(100) NULL,
	modified_date timestamp NULL,
	deleted_by varchar(100) NULL,
	deleted_date timestamp NULL,
	is_active bool NOT NULL,
	is_deleted bool NOT NULL,
	id_10 int4 NULL,
	CONSTRAINT fk_thingspace_device_status_reason_code_device_status FOREIGN KEY (device_status_id) REFERENCES public.device_status(id)
);