"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil .N
Created Date: 21-06-24
"""

# Importing the necessary Libraries
import re
import requests
import os
import pandas as pd
from datetime import time
import time
from io import BytesIO
import json
import base64
import zipfile
import io
import pytds
import base64
from pytz import timezone
import boto3
import concurrent.futures
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.email_trigger import send_email

logging = Logging(name="service_qualification")


def db_config_maker(user, db_config_making):

    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_making)

    query = f"select customers,service_provider from users where username ='{user}'"
    filters = common_utils_database.execute_query(query, True)
    try:
        customer = tuple(json.loads(filters["customers"].to_list()[0]))
    except:
        customer = None
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
    except:
        service_provider = None

    db_config_making["customers"] = customer
    db_config_making["service_providers"] = service_provider

    return db_config_making


def funtion_caller(data, path):
    global db_config

    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

    user = data.get("username")
    if not user:
        user = data.get("user_name")

    db_config_making = db_config_maker(user, db_config)
    db_config = db_config_making
    logging.info(f"db_config created is : {db_config}")

    if path == "/get_service_qualification_features":
        result = get_service_qualification_features(data)
    else:
        result = {"error": "Invalid path or method"}
        logging.warning("Invalid path or method requested: %s", path)

    return result


def get_service_qualification_features(data):
    """
    Description: The  function retrieves and organizes field mappings,headers,and module features
    based on the provided module_list, role, user, and other parameters.
    It connects to a database, fetches relevant data, categorizes fields,and
    compiles features into a structured dictionary for each module.
    """
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_database = data.get("db_name", "altaworx_central")
    database = DB(tenant_database, **db_config)
    parent_module_name = data.get("parent_module_name", "")
    feature_module_name = data.get("feature_module_name", "")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")
    role = data.get("role", "")
    try:
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]
    except Exception as e:
        logging.exception(f"Getting exception at fetching tenant id {e}")
    ret_out = {}

    try:
        final_features = []

        # Fetch all features for the 'super admin' role
        if role.lower() == "super admin":
            all_features = common_utils_database.get_data(
                "module_features",
                {
                    "module": feature_module_name,
                    "parent_module_name": parent_module_name,
                },
                ["features"],
            )["features"].to_list()
            if all_features:
                final_features = json.loads(all_features[0])
        else:
            final_features = get_features_by_feature_name(
                user_name,
                tenant_id,
                feature_module_name,
                common_utils_database,
                parent_module_name,
            )
            logging.info(
                "Fetched features for user '%s': %s", user_name, final_features
            )
            try:
                audit_data_user_actions = {
                    "service_name": "Service Qualification",
                    "created_date": data.get("request_received_at"),
                    "created_by": data.get("username", ""),
                    "status": "True",
                    "session_id": data.get("session_id", ""),
                    "tenant_name": data.get("tenant_name", ""),
                    "comments": "get_service_qualification_features",
                    "module_name": "get_service_qualification_features",
                    "request_received_at": data.get("request_received_at"),
                }
                database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"Failed to log error to database: {logging_error}")

    except Exception as e:
        error_type = type(e).__name__
        try:
            error_data = {
                "service_name": "Service Qualification",
                "created_date": data.get("request_received_at"),
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "",
                "module_name": "get_service_qualification_features",
                "request_received_at": data.get("request_received_at"),
            }
            database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(f"Failed to log error to database: {logging_error}")
    response = {
        "flag": True,
        "module_features": final_features,
        "message": "Features Fetched Successfully",
    }
    return response


def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name
):
    # Fetch user features from the database
    user_features_raw = common_utils_database.get_data(
        "user_module_tenant_mapping",
        {"user_name": user_name, "tenant_id": tenant_id},
        ["module_features"],
    )["module_features"].to_list()

    logging.info("Raw user features fetched: %s", user_features_raw)

    # Parse the JSON string to a dictionary
    user_features = json.loads(
        user_features_raw[0]
    )  # Assuming it's a list with one JSON string

    # Initialize a list to hold features for the specified feature name
    features_list = []

    # Check by parent_module_name first
    for module, features in user_features.items():
        if module == parent_module_name and feature_name in features:
            features_list.extend(features[feature_name])

    # If no features found by parent_module_name, check other modules
    if not features_list:
        for module, features in user_features.items():
            if feature_name in features:
                features_list.extend(features[feature_name])

    logging.info("Retrieved features: %s", features_list)
    return features_list
