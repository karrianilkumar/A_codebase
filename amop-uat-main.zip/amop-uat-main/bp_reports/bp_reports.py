"""
@Author1 : Srikanth R
Created Date: 27-12-2024
"""

# Importing the necessary Libraries
import ast
import boto3
import requests
import os
# from bp_email_trigger import send_email_without_template
import pandas as pd
from common_utils.email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import datetime
from datetime import time
from datetime import datetime, timedelta,date
import time
from io import BytesIO
from common_utils.data_transfer_main import DataTransfer
import json
import base64
import re
import pytds
from pytz import timezone
import numpy as np
from collections import defaultdict
#download template dependencies
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
from io import StringIO
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
import csv
from openpyxl import load_workbook
from openpyxl import Workbook
from pytz import UnknownTimeZoneError, timezone
import pandas as pd
import psycopg2
import random
import string
from datetime import datetime
from dateutil import parser

# Dictionary to store database configuration settings retrieved from environment variables.
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema":False
}
logging = Logging(name="sim_management")


def get_headers_mapping(tenant_database, module_list, role, user, tenant_id, sub_parent_module, parent_module, data,):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.

    This function:
    - Connects to the database.
    - Fetches field mappings and categorizes them into pop-ups, general fields, and table fields.
    - Retrieves and processes module features based on user roles.
    - Returns a structured dictionary containing headers and features for each module.

    Parameters:
        tenant_database (str): The database name of the tenant.
        module_list (list): List of module names to fetch field mappings for.
        role (str): The role of the user (e.g., 'Super Admin').
        user (str): The username of the user.
        tenant_id (int): The ID of the tenant.
        sub_parent_module (str): The name of the sub-parent module.
        parent_module (str): The name of the parent module.
        data (dict): Additional input data, which may contain:
            - feature_module_name (str): The feature module name.
            - username/user_name/user (str): The username.
            - tenant_name/tenant (str): The tenant name.

    Returns:
        dict: A dictionary where each module name maps to its corresponding headers and features.
    """
    # Establish database connections
    database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    billing_platform_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    
    # Extract relevant details from the input data dictionary
    main_module_name=data.get("main_module_name", "Customer Profiles")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")
    parent_module_name = data.get("parent_module", "Billing Platform")

    try:
        tenant_id_query = database.get_data(
        "tenant", {"tenant_name": tenant_name},["id"]
        )
        tenant_id = tenant_id_query["id"].to_list()[0]
    except Exception as e:
        logging.warning(f"Getting exception at fetching tenant id {e}")
    
    ret_out = {}
    
    # Iterate over each module name in the provided module list
    for module_name in module_list:
        out = billing_platform_database.get_data(
            "field_column_mapping", {"module_name": module_name}
        ).to_dict(orient="records")
        pop_up = []
        general_fields = []
        table_fileds = {}
        # Categorize the fetched data based on field types
        for data in out:
            if data["pop_col"]:
                pop_up.append(data)
            elif data["table_col"]:
                table_fileds.update(
                    {
                        data["db_column_name"]: [
                            data["display_name"],
                            data["table_header_order"],
                        ]
                    }
                )
            else:
                general_fields.append(data)
        # Create a dictionary to store categorized fields
        headers = {}
        headers["general_fields"] = general_fields
        pop_up = sorted(pop_up, key=lambda x: x['id'])
        headers["pop_up"] = pop_up
        headers["header_map"] = table_fileds
        try:
            final_features = []

            # Fetch all features for the 'super admin' role
            if role.lower() == "super admin":
                all_features = database.get_data(
                    "module_features", {"module": main_module_name}, ["features"]
                )["features"].to_list()
                if all_features:
                    final_features = json.loads(all_features[0])
            else:
                final_features = get_features_by_feature_name(
                    user_name, tenant_id, main_module_name, database, parent_module_name,role
                )

        except Exception as e:
            logging.exception(f"there is some error {e}")
            pass
        # Add the final features to the headers dictionary
        headers["module_features"] = final_features
        if module_name in ["Customer Services Carrier","Customer Services Customer"]:
            module_name = "Customer Services"
        ret_out[module_name] = headers

    return ret_out



def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name, role
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        logging.debug("Raw user features fetched: %s", user_features_raw)

        if not user_features_raw or user_features_raw[0] is None:
            query=f'''select module_features from role_module where role='{role}'
            '''
            user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
        
        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  
        
        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        print(
            "Retrieved features: %s", features_list
        )  

    except Exception as e:
        # Catch any exceptions and log a warning
        logging.warning("There was an error while fetching features: %s", e)

    return features_list  # Return the list of retrieved features

def data_update_db(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            # Perform the update operation
            db.update_dict(table_name, update_data, {"id": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def convert_timestamp(df_dict, tenant_time_zone):
    """
    Convert timestamp columns in the provided dictionary list to the tenant's timezone.

    Parameters:
        df_dict (list of dict): A list of dictionaries where each dictionary represents a record
                                containing timestamp fields.
        tenant_time_zone (str): The timezone to which the timestamps should be converted.

    Returns:
        list of dict: The updated list of dictionaries with timestamps converted to the tenant's timezone.
    """
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at','billed_through_date','activation_date']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y %H:%M:%S')  # Ensure it's a string
    return df_dict

def serialize_data(data):
    """Recursively convert pandas and datetime objects to JSON serializable types."""
    
    # Ensure the type check is valid
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    
    # Handle both pandas and native Python timestamps
    elif isinstance(data, (pd.Timestamp, datetime)):  
        return data.strftime('%m-%d-%Y %H:%M:%S')  
    
    elif isinstance(data,date):  
        return data.strftime('%m-%d-%Y %H:%M:%S')  

    # Return other types as they are
    else:
        return data

def get_export_status(data):
    """
    The get_export_status function retrieves the export status of a specific module from a database.
    It queries the export_status table based on the given module name and returns the corresponding status data.
    """
    try:
        common_utils_database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
        database = DB(os.environ['BILLING_PLATFORM'], **db_config)
        report_id=data.get("report_id","")
        request_received_at = data.get("request_received_at", None)
        module_name=data.get("module_name","")    
        export_status_query = (
            f"select * from export_status where module_name='{module_name}'"
        )
        export_status_data = common_utils_database.execute_query(
            export_status_query, True
        ).to_dict(orient="records")
        # updating the report status
        return {"flag": True, "export_status_data": export_status_data[0]}
    except Exception as e:
        logging.exception(f"Exception is {e}")
        return {"flag": False, "export_status_data": []}

def export_to_s3_bucket_(data):
    """
    Export combined query results for all billing periods into a single Excel file
    and upload it to an Amazon S3 bucket.

    Args:
        data (dict): Input data with necessary details.

    Returns:
        dict: Operation result containing flag, message, and optionally download_url.
    """
    S3_BUCKET_NAME = "searchexceluat"

    # Extract input parameters
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    user_name = data.get("user_name", "")
    session_id = data.get("session_id", "")
    service_provider = data.get("service_provider", "")
    billing_cycle_period = data.get("billing_cycle_period", "")
    end_date = data.get('end_date', '')
    start_date = data.get('start_date', '')
    tenant_database = data.get("db_name", "")
    data_frames = data.get("dfs", {})  # Expecting a dict {"Sheet1": df1, "Sheet2": df2}
    report_name=data.get("report_name","")
    username=data.get("username","")
    database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    start_time = time.time()

    if module_name == 'SimManagement Inventory':
        file_name = f"exports/uat/{module_name_snake_case}/SimManagement/Inventory.xlsx"
    else:
        file_name = f"exports/uat/{module_name_snake_case}/{module_name}.xlsx"

    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"


    # Update export status to 'Waiting'
    db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name},
    )

    try:
        if not data_frames :
            db.update_dict(
                "export_status",
                {"status_flag": "No Data Found for export", "url": ""},
                {"module_name": module_name},
            )
            return {"flag": False, "message": "No data found for export."}

        excel_buffer = BytesIO()
        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
            for sheet_name, df in data_frames.items():
                logging.info(f"Columns: {list(df.columns)}")
                if df.empty:
                    df = pd.DataFrame(columns=df.columns)

                # Format column names
                acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "SIM", "ID", "MRC", "NRC"}
                special_replacements = {"Att": "AT&T", "And": "and", "Gl": "G/L", "Isparent": "IsParent", "Ischild": "IsChild", "Prevmrc": "PrevMRC", "Currmrc": "CurrMRC", "Netmrc": "NetMRC", "Prevnrc": "PrevNRC", "Currnrc": "CurrNRC", "Netnrc": "NetNRC"}

                df.columns = [
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in str(col).split("_")
                    )
                    for col in df.columns
                ]
                df.columns = [
                    " ".join([special_replacements.get(word, word) for word in col.split(" ")]) for col in df.columns
                ]
                logging.info(f'df-----------{df}')
                logging.info(f"Columns: {list(df.columns)}")
                if module_name == "Billed Through Date Report":
                    df.rename(columns={"Tn": "TN"}, inplace=True)
                df.to_excel(writer, index=False, sheet_name=sheet_name)

                # Apply styles
                workbook = writer.book
                sheet = workbook[sheet_name]

                header_font = Font(bold=True)
                for cell in sheet[1]:
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                    cell.font = header_font

                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        excel_buffer.seek(0)

        s3_client = boto3.client("s3")
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=excel_buffer.getvalue(),
            ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

        db.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": module_name},
        )
        return {"flag": True, "download_url": download_url}

    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name}
        )
        db.log_error_to_db(
            {
                "service_name": "export_to_s3_bucket_",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": str(e),
                "module_name": module_name,
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error: {str(e)}"}

def transcation_analysis_report_list_view(data):
    """
    Retrieves transaction report data for display with filtering, sorting, pagination, and dropdown options.

    Args:
        data (dict): A dictionary containing request parameters:
            - db_name (str, optional): Tenant database name. Default: 'altaworx_central'.
            - role_name (str): Role name for header mapping and permission checks.
            - tenant_name (str): Tenant identifier used to determine timezone.
            - mod_pages (dict): Pagination control with keys 'start' and 'end'.
            - col_sort (dict, optional): Sorting preferences with column and direction.
            - start_date (str, optional): Start of date range filter (YYYY-MM-DD).
            - end_date (str, optional): End of date range filter (YYYY-MM-DD).
            - table_name (str, optional): Table name for dropdown population. Default: 'customer_charges'.

    Returns:
        dict: API response containing:
            - flag (bool): Indicates success or failure.
            - message (str): Descriptive message of the operation result.
            - data (dict): Serialized transaction report data.
            - header_map (dict): Header mapping for UI table rendering.
            - dropdown (dict): Dropdown values for filters including product, service types, GL codes, and locations.
            - pages (dict): Pagination metadata including start, end, and total record count.
    """
    # Database connections
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    start_time = time.time()
    # Extract relevant details from the input data dictionary
    table_name = data.get('table_name','customer_charges')
    col_sort = data.get("col_sort", '')
    tenant_name =data.get('tenant_name','')
    role_name = data.get('role_name', '')
    start_date=data.get('start_date', '')
    end_date=data.get('end_date', '')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1
    if end_date:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
        except Exception as e:
            logging.warning(f"Error {e}")
    
    # user selected data
    
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    limit = end - start
    offset = start  

    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly


    # Get total customer charges count
    try:
        if start_date:
            base_query="""select amount from transaction_analysis_view where tenant_id = %s AND to_date(split_part(bill_range, ' - ', 1), 'MM-DD-YYYY') <= %s AND to_date(split_part(bill_range, ' - ', 2), 'MM-DD-YYYY') >= %s"""
            params=[tenant_id,start_date,end_date]
        else:
            base_query='select amount from transaction_analysis_view where tenant_id = %s'
            params=[tenant_id]
        total_count_result = killbill_database.execute_query(base_query, params=params)  # Get the DataFrame directly
        total_count_result = total_count_result.to_dict(orient="records")
        total_count=len(total_count_result)


        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }
        if start_date:
            base_query="""select account_number,customer_name, iccid, description,gl_code, product_id, bill_range, category, amount,nrc, mrc, calculated_cost, sms_cost, tax_name,products,modified_date from transaction_analysis_view where tenant_id = %s AND to_date(split_part(bill_range, ' - ', 1), 'MM-DD-YYYY') <= %s AND to_date(split_part(bill_range, ' - ', 2), 'MM-DD-YYYY') >= %s"""
            params=[tenant_id,start_date,end_date]
        else:
            base_query='select account_number,customer_name, iccid, description,gl_code, product_id, bill_range, category, amount,nrc, mrc, calculated_cost, sms_cost, tax_name, products,modified_date from transaction_analysis_view where tenant_id = %s and is_active=false and is_deleted=false'
            params=[tenant_id]

        if col_sort:
            order={k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]  # Extract column name
            order_direction = order[order_by].lower()  # Convert to lowercase
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY modified_date desc"  # Default sorting

        base_query += " LIMIT %s OFFSET %s"
        params.append(limit)
        params.append(offset)
        df = killbill_database.execute_query(base_query, params=params)  # Get the DataFrame directly
        df_dict = df.to_dict(orient="records")

        final_df_dict = convert_timestamp(df_dict, tenant_time_zone)
        
        header_map = get_headers_mapping(killbill_database,["Transaction Report"],role_name, '', '', '', '',data)
        
        data_dict_all = {"transaction_report": serialize_data(final_df_dict)}

        # Construct success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "dropdown": {},
            "pages": pages_data
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "transcation_analysis_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully fetched Transaction Report',
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        return response

    except Exception as e:
        logging.info(f"Exception occurred: {e}")
        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching Reports list",
            "data": {}  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "transcation_analysis_report_list_view",
                "error_message": message,
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message,
                "module_name": "Reports",
                "request_received_at": data.get("request_received_at", None),
            }
            database.log_error_to_db(error_data, "error_log_table")
        except:
            pass
        return response

def altaworx_billing_report_list_view(data):
    """
    Retrieves Altaworx billing report data with pagination, date-range filtering, timezone conversion, 
    sorting, and dynamic header mapping.

    Args:
        data (dict): Dictionary of input parameters including:
            - db_name (str, optional): Tenant database name. Default is from environment.
            - role_name (str): Role used for UI header permissions.
            - tenant_name (str): Tenant identifier used to fetch timezone.
            - table_name (str, optional): View/table to query. Default: 'billing_report_view'.
            - col_sort (dict, optional): Sorting preferences in the form {column: direction}.
            - mod_pages (dict): Pagination settings with 'start' and 'end'.
            - report_flag (str, optional): Additional flag for report-specific logic.
            - changed_data (dict, optional): Includes 'date_range' (list of two date strings).

    Returns:
        dict: API response with:
            - flag (bool): Indicates success or failure.
            - message (str): Descriptive status message.
            - data (dict): Serialized billing report data.
            - header_map (dict): Header configuration for UI table rendering.
            - pages (dict): Pagination metadata including start, end, and total record count.
    """
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    start_time = time.time()
    table_name = data.get('table_name','billing_report_view')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    role_name = data.get('role_name', '')
    report_flag=data.get('report_flag', '')
    changed_data=data.get('changed_data', {})
    date_range=changed_data.get('date_range', {})
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1

    
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    limit = end - start
    offset = start 

    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')
    
    try:
        total_count_result_query = f"Select count(id) from billing_report_view where tenant_id = {tenant_id}"
        total_count_df = killbill_database.execute_query(total_count_result_query, True)
        total_count = total_count_df.iloc[0, 0] 
        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": int(total_count)
        }
        query = f"Select * from {table_name} where tenant_id = {tenant_id}"
        if col_sort:
            order={k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]  # Extract column name
            order_direction = order[order_by].lower()  # Convert to lowercase
            query += f" ORDER BY {order_by} {order_direction}"
        else:
            query += " ORDER BY bill_id desc"  # Default sorting
            
        query += " LIMIT %s OFFSET %s"
        df_dict = killbill_database.execute_query(query, params=[limit,offset])
        df_dict = df_dict.to_dict(orient="records")
        final_df_dict = df_dict
        for i in range(len(final_df_dict)):
            item = final_df_dict[i]
            final_df_dict[i] = {
                "account_number": item["account_number"],
                "account_type": item["account_type"],
                "customer_name": item["customer_name"],
                "bill_id": item["bill_id"],
                "created_date": item["created_date"],
                "sales_person": item["sales_person"],
                "secondary_sales_person": "No",
                "bill_cycle_start_date": item["bill_cycle_start_date"],
                "amount_due": item["amount_due"],
                "mrc": item["mrc"],
                "nrc": item["nrc"],
                "network_access_fee": item["network_access_fee"],
                "cost_recovery_fee": item["cost_recovery_fee"],
                "taxes": item["taxes"],
                "total": item["total"],
                "payments": item["payments"],
                "bill_due_date": item["bill_due_date"],
                "account_balance": item["account_balance"],
                "state": item["state"],
                "timezone": tenant_time_zone,
                "city" : item["city"],
                "country": item["country"]
            }
        
        final_df_dict = convert_timestamp(final_df_dict, tenant_time_zone)
        # Fetch mapped headers
        header_map = get_headers_mapping(killbill_database,["Altaworx Billing Report"],role_name, '', '', '', '',data)
        data_dict_all = {"altaworx_billing_report": serialize_data(final_df_dict)}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "altaworx_billing_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully fetched Altaworx Billing Report',
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        return response

    except Exception as e:
        logging.info(f"Exception occurred: {e}")
        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching Reoprts list",
            "data": {}  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "altaworx_billing_report_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response

def unposted_items_report_list_view(data):
    """
    Retrieves a list of Reports for display, including pagination, filtering, and dropdown options.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): Tenant database name (default: 'altaworx_central').
            - role_name (str): User's role for permissions.
            - tenant_name (str): Tenant name for fetching timezone.
            - mod_pages (dict): Pagination details {start, end}.
            - col_sort (dict, optional): Sorting preferences.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - data (dict): Customer profiles with pagination.
            - header_map (dict): Mapped headers for UI display.
            - dropdown (dict): Dropdown values for filters.
            - pages (dict): Pagination details.
    """
    # Database connections
    start_time = time.time()
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

    # Extract relevant details from the input data dictionary
    #table_name = data.get('unposted_items_view','unposted_items_view')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    role_name = data.get('role_name', '')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1

    # Set default pagination if not provided
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)

    limit = end - start
    offset = start

    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly
    
    
    # Get total customer charges count
    try:
        base_query='select customer_id from unposted_items_view where tenant_id = %s'
        total_count_result = killbill_database.execute_query(base_query, params=[tenant_id])  # Get the DataFrame directly
        total_count_result = total_count_result.to_dict(orient="records")
        total_count=len(total_count_result)

        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }

        # Sort order handling (ensure valid keys)
        if col_sort:
            order =  {k: v.lower() for k, v in col_sort.items()}
        else:
            order= {"id":"desc"}
        
        base_query=f'select customer_id, description, amount, mrc, start_date, end_date, created_date, tn, line_id, product_id, product_type_id,calculated_cost, sms_cost, tax_name  from unposted_items_view where  tenant_id = {tenant_id}'

        if col_sort:
            order={k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]  # Extract column name
            order_direction = order[order_by].lower()  # Convert to lowercase
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY created_date desc"  # Default sorting

        base_query += " LIMIT %s OFFSET %s"

        df = killbill_database.execute_query(base_query, params=[limit,offset])  # Get the DataFrame directly
        df["start_date"] = pd.to_datetime(df["start_date"]).dt.strftime("%m-%d-%Y")
        df["end_date"] = pd.to_datetime(df["end_date"]).dt.strftime("%m-%d-%Y")
        df_dict = df.to_dict(orient="records")
        
        # Convert timestamps to the tenant's timezone
        final_df_dict = convert_timestamp(df_dict, tenant_time_zone)
        df = pd.DataFrame(final_df_dict)
        df["created_date"] = pd.to_datetime(df["created_date"]).dt.strftime("%m-%d-%Y")
        final_df_dict = df.to_dict(orient="records")
        # Fetch mapped headers
        header_map = get_headers_mapping(killbill_database,["Unposted Items"],role_name, '', '', '', '',data)

        # Serialize customer profiles
        data_dict_all = {"unposted_items": serialize_data(final_df_dict)}

        # Construct success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "unposted_items_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully fetched Unposted Items Report',
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")

        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching Reports list",
            "data": {}  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "unposted_items_report_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response
    
def payment_details_report_list_view(data):
    """
    Retrieves a paginated and filtered list of payment history records along with dropdown options
    and header mapping for frontend display.

    Args:
        data (dict): Input parameters including:
            - db_name (str, optional): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): Role used to fetch permitted headers.
            - tenant_name (str): Used to determine tenant's timezone.
            - mod_pages (dict): Pagination details with 'start' and 'end' indices.
            - col_sort (dict, optional): Sorting configuration as {column: direction}.
            - report_flag (str, optional): If set to 'download', disables pagination.
            - changed_data (dict, optional): Filtering criteria such as:
    Returns:
        dict: API response with:
            - flag (bool): True on success, False on failure.
            - message (str): Status message.
            - data (dict): Contains 'reports_data', a serialized list of payments.
            - header_map (dict): UI table header mapping.
            - dropdown (dict): Dropdown filter values (e.g., 'method', 'created_by').
            - pages (dict): Pagination metadata with 'start', 'end', and 'total'.
    """
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

    start_time = time.time()
    # Extract relevant details from the input data dictionary
    table_name = data.get('table_name','vw_payment_history')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    role_name = data.get('role_name', '')
    report_flag=data.get('report_flag', '')
    changed_data=data.get('changed_data', {})
    start_date=data.get('start_date', '')
    end_date=data.get('end_date', '')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1
    date_flag = True
    if start_date == 'Invalid Date' or end_date == 'Invalid Date':
        date_flag = False
    if end_date and date_flag:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
        except Exception as e:
            logging.warning(f"Error {e}")
    # Set default pagination if not provided
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    limit = end - start
    offset = start  
    tenant_time_zone = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name},["time_zone"]
        )["time_zone"].to_list()[0]

    if tenant_time_zone is None:
            raise ValueError("No valid timezone found for tenant.")
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly 

    try:
        total_count_query = """SELECT COUNT(*) AS total FROM vw_payment_history where tenant_id = %s"""
        params = [tenant_id]

        base_query = f"""
            SELECT customer_id, customer_name, agent, amount, method, date, ref, created_date
            FROM {table_name}
            WHERE 1=1 AND tenant_id = {tenant_id}
        """
        changed_data = {k: (None if v in ["null", None] else v) for k, v in changed_data.items()}

        # Handle date_range separately (check if both start and end dates are null)
        if "date_range" in changed_data:
            start_date, end_date = changed_data["date_range"]
            if start_date in ["null", None] and end_date in ["null", None]:
                changed_data.pop("date_range")  # Remove if both are null

        changed_data = {k: v for k, v in changed_data.items() if v not in [None, "", [], {}, False]}
        params = []
        if 'evaluate_using' in changed_data:
            if changed_data.get('evaluate_using') == 'Created Date' and 'date_range' in changed_data:
                base_query += " AND created_date BETWEEN %s AND %s"
                params.extend(changed_data["date_range"])
            elif changed_data.get('evaluate_using') == 'Received Date' and 'date_range' in changed_data:
                base_query += " AND date BETWEEN %s AND %s"
                params.extend(changed_data["date_range"])
            else:
                pass
        if start_date and end_date and date_flag:
            base_query += " AND date BETWEEN %s AND %s"
            params.extend([start_date, end_date])
        if "method" in changed_data:
            base_query += " AND method = %s"
            params.append(changed_data["method"])

        if "last_4" in changed_data:
            base_query += " AND RIGHT(method, 4) = %s"
            params.append(changed_data["last_4"])

        if "min_amount" in changed_data:
            base_query += " AND amount >= %s"
            params.append(int(changed_data["min_amount"]))  # Convert to integer

        if "created_by" in changed_data:
            base_query += " AND created_by = %s"
            params.append(changed_data["created_by"])

        if "agent" in changed_data:
            base_query += " AND agent = %s"
            params.append(changed_data["agent"])

        # Handle sorting if order is provided
        if col_sort:
            order={k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]  # Extract column name
            order_direction = order[order_by].lower()  # Convert to lowercase
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY date desc"  # Default sorting

        total_count_result = killbill_database.execute_query(base_query, params = params, flag=True)
        count_dict = total_count_result.to_dict(orient="records")
        total_count=len(count_dict)
        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }
        # Add LIMIT and OFFSET
        if report_flag!='download':
            base_query += " LIMIT %s OFFSET %s"

        params.append(limit)
        params.append(offset)
        df = killbill_database.execute_query(base_query, params=params)  # Get the DataFrame directly
        df_dict = df.to_dict(orient="records")  # Convert to dictionary for processing
        df_dict = convert_timestamp(df_dict, tenant_time_zone)
        # to view in ui

        try:
            method_df = killbill_database.get_data("payment_history", {}, ["method"])
            method = list(set(method_df['method'].tolist())) if not method_df.empty else []
        except Exception as db_error:
            logging.info(f"Database Error: {db_error}")  # Logging the error
            method = []

        created_by = []  # Initialize before try block
        try:
            created_by_df = killbill_database.get_data("customer_bills", {}, ["created_by"])
            created_by = list(set(created_by_df['created_by'].tolist()))  # Remove duplicates
        except Exception as db_error:
            logging.info(f"Database error: {db_error}")  # Optional logging
        
        dropdown = {
            "method": method,
            "created_by": created_by
        }
        header_map = get_headers_mapping(killbill_database,["Payment History Report"],role_name, '', '', '', '',data)
        data_dict_all = {"reports_data": serialize_data(df_dict)}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "dropdown":dropdown
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "payment_details_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully fetched Payment History Report',
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching Reoprts list",
            "data": {}  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "payment_details_report_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response

def ar_aging_report_list_view(data):
    """
    Retrieves AR Aging Report data with optional date filtering, sorting, pagination, timezone conversion,
    header mapping, and dropdown metadata for UI filtering.

    Args:
        data (dict): Input parameters including:
            - table_name (str, optional): The name of the database view or table. Default: 'ar_aging_view'.
            - col_sort (dict, optional): Sorting configuration in the format {column_name: direction}.
            - module_name (str, optional): Module name for header mapping. Default: 'AR Aging Report'.
            - tenant_name (str): Tenant name used to retrieve timezone.
            - role_name (str): Role name for header mapping.
            - start_date (str, optional): Start of due date filter in 'YYYY-MM-DD' format.
            - end_date (str, optional): End of due date filter in 'YYYY-MM-DD' format.
            - mod_pages (dict): Pagination info containing 'start' and 'end' indices.

    Returns:
        dict: API response with the following keys:
            - flag (bool): Indicates success (True) or failure (False).
            - message (str): Status message for the operation.
            - data (dict): Dictionary containing:
                - 'reports_data': Serialized records of AR aging data.
            - header_map (dict): Header mapping for frontend table generation.
            - pages (dict): Contains pagination metadata ('start', 'end', 'total').
            - dropdown (dict): Dropdown filter options for frontend filtering, including:
                - agent (list): List of sales agents.
                - customer_status (list): List of customer statuses.
                - format (list): Available report formats.
                - charge_date, credit_date, payment_date (list): Date filtering options.
    """
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    start_time = time.time()
    table_name = data.get("table_name", "ar_aging_view")
    if not table_name:
        table_name='ar_aging_view'
    col_sort = data.get("col_sort", "")
    module_name=data.get('module_name','AR Aging Report')
    tenant_name = data.get('tenant_name', '')
    role_name = data.get('role_name', '')
    start_date=data.get('start_date', '')
    end_date=data.get('end_date', '')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1
    date_flag = True
    if start_date == 'Invalid Date' or end_date == 'Invalid Date':
        date_flag = False
    if end_date and date_flag:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
        except Exception as e:
            logging.warning(f"Error {e}")
    # user selected data
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    limit = end - start
    offset = start  
    
    tenant_time_zone = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["time_zone"]
    )["time_zone"].to_list()[0]
    
    if not tenant_time_zone:
        raise ValueError("No valid timezone found for tenant.")
    
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')
    
    try:
        base_query = f"""
            SELECT * FROM {table_name}
            WHERE 1=1 and tenant_id = {tenant_id}
        """
        params = []
        # Sort order handling (ensure valid keys)
        if start_date and end_date and date_flag:
            base_query += " AND due_date_of_this_bill BETWEEN %s AND %s"
            params.extend([start_date, end_date])
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]
            order_direction = order[order_by].lower()
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY due_date_of_this_bill DESC"
        count_df = killbill_database.execute_query(base_query, params=params)
        count_df_dict = count_df.to_dict(orient="records")  
        total_pages_count = len(count_df_dict)
        pages_data = {
            "start": start,
            "end": end,
            "total": total_pages_count
        }
        base_query += " LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        df = killbill_database.execute_query(base_query, params=params)
        df_dict = df.to_dict(orient="records")  
        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        dropdown={}
        agent_list=[]
        try:
            agent_list_df= killbill_database.get_data(table_name="customer_profiles",condition=None,columns=["sales_person"])["sales_person"].to_list()
            agent_list=list(set(agent_list_df))
        except Exception as e:
            logging.info(f'exception------{e}')
            agent_list=[]
        customer_status=["Open"]
        format=["Detailed","Summary by Agent","Summary by Bill Profile","Summary by Collection Assignee","Summary by Cycle Day","Summary by Status"]
        charge_date=["Charge Created Date","Bill Created Date","Bill Due Date","Cycle Date"]
        credit_date=["Credit Created Date","Bill Created Date","Bill Due Date","Cycle Date"]
        payment_date=["Payment Created Date","Bill Created Date","Bill Due Date","Cycle Date","Recevied Date"]
        dropdown['agent']=agent_list
        dropdown['customer_status']=customer_status
        dropdown['format']=format
        dropdown['charge_date']=charge_date
        dropdown['credit_date']=credit_date
        dropdown['payment_date']=payment_date        
        
        header_map = get_headers_mapping(killbill_database, [module_name], role_name, '', '', '', '', data)
        data_dict_all = {"reports_data": serialize_data(df_dict)}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "dropdown":dropdown
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "ar_aging_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully fetched AR Aging Report',
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        return response
    
    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        response = {"flag": False, "message": "Something went wrong fetching reports list", "data": {}}
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "ar_aging_report_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response

def export_ar_aging_report(data):
    """
    Generates and exports the A/R Aging Report to an S3 bucket based on applied filters and sorting.

    Args:
        data (dict): Dictionary containing parameters for report generation. Expected keys:
            - tenant_name (str): Tenant identifier used to fetch timezone.
            - role_name (str): User's role for permission and header mapping.
            - table_name (str, optional): Source view/table name. Defaults to 'ar_aging_view'.
            - report_flag (str): Flag to indicate view/download mode (currently unused in logic).
            - start_date (str, optional): Filter for bill due date range start (format: 'YYYY-MM-DD').
            - end_date (str, optional): Filter for bill due date range end (format: 'YYYY-MM-DD').
            - col_sort (dict, optional): Sorting order in the format {column_name: "ASC" or "DESC"}.
            - changed_data (dict, optional): Additional filters such as:
                - customer_status (str)
                - agent (str)
                - date (str)
                - minimum_balance (float)
            - mod_pages (dict, optional): Pagination settings (not used in export).

    Returns:
        dict: On success, returns the response from `export_to_s3_bucket_`:
            - flag (bool): Whether the export was successful.
            - message (str): Description of the outcome.
            - data (dict): Exported file details, such as the S3 link.
        If no data is found, returns an empty report with predefined columns.
    """
    start_time = time.time()
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    
    # table_name = data.get('table_name','ar_aging_view')
    table_name = data.get("table_name", "ar_aging_view")
    if not table_name:
        table_name='ar_aging_view'
    col_sort = data.get("col_sort", "")
    tenant_name = data.get('tenant_name', '')
    role_name = data.get('role_name', '')
    report_flag = data.get('report_flag', '')
    changed_data = data.get('changed_data', {})
    start_date=data.get('start_date', '')
    end_date=data.get('end_date', '')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1
    date_flag = True
    if start_date == 'Invalid Date' or end_date == 'Invalid Date':
        date_flag = False
    if end_date and date_flag:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
        except Exception as e:
            logging.warning(f"Error {e}")
    base_query = f"""
        SELECT * FROM {table_name}
        WHERE 1=1 and tenant_id = {tenant_id}
    """
    # Set default pagination if not provided
    tenant_time_zone = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name},["time_zone"]
        )["time_zone"].to_list()[0]

    if tenant_time_zone is None:
            raise ValueError("No valid timezone found for tenant.")
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly 
    try:
        params = []
        changed_data = {k: (None if v in ["null", None] else v) for k, v in changed_data.items()}
        changed_data = {k: v for k, v in changed_data.items() if v not in [None, "", [], {}, False]}
        if start_date and end_date and date_flag:
            base_query += " AND due_date_of_this_bill BETWEEN %s AND %s"
            params.extend([start_date, end_date])
        if "customer_status" in changed_data:
            base_query += " AND status = %s"
            params.append(changed_data["customer_status"])
        
        if "minimum_balance" in changed_data:
            base_query += " AND total >= %s"
            params.append(float(changed_data["minimum_balance"]))
        
        if "agent" in changed_data:
            base_query += " AND agent = %s"
            params.append(changed_data["agent"])
        if "date" in changed_data:
            base_query += " AND due_date_of_this_bill <= %s"
            params.append(changed_data["date"])
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]
            order_direction = order[order_by].lower()
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY due_date_of_this_bill DESC" 
        df = killbill_database.execute_query(base_query, params=params)
        df_dict = df.to_dict(orient="records")
        dict_keys = ['id', 'customer_profile_id', 'modified_date']
        # Loop over each dictionary and remove keys if they exist in dict_keys
        for d in df_dict:
            for key in dict_keys:
                d.pop(key, None)  # Removes the key if it exists, does nothing if not
    
        df_dict = convert_timestamp(df_dict, tenant_time_zone)
        if not df_dict:
            columns = ["customer_id","account_number","customer_name","email","current","0-30","31-60","61-90","91-120","120+","total","agent","contact","status","parent_account_number","parent_name", "template_description", "step_description", "day"]
            df = pd.DataFrame(columns=columns)  # Create empty DataFrame with columns
        else:
            df = pd.DataFrame(df_dict).fillna('')        
            df = df.drop(columns=['tenant_id', 'collection_step'])
            df = df.rename(columns={
                'template_description': 'Collection Template',
                'step_description': 'Collection Step'
            })
            logging.info(f"Columns: {list(df.columns)}")
            data["dfs"] = {"AR Aging": df}
            data['module_name'] = 'AR Aging Report'
            response = export_to_s3_bucket_(data)
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "export_ar_aging_report",
                "created_by": data.get("username", ""),
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": 'Successfully Exported AR Aging',
                "module_name": "BP Reports",
                "request_received_at": data.get("request_received_at", None)
            }
            database.update_audit(audit_data_user_actions, "audit_user_actions")
    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong Exporting Ar aging",
            "data": {}  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_ar_aging_report",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response

def export_payment_details_report(data):
    """
    Generates and exports the Payment History Report to an S3 bucket based on optional filters and date range.

    Args:
        data (dict): Input dictionary containing filtering, timezone, and export parameters. Keys include:
            - table_name (str, optional): Database view/table name to query. Defaults to 'vw_payment_history'.
            - tenant_name (str): Name of the tenant, used to fetch timezone.
            - start_date (str, optional): Start date for payment date filter (format: 'YYYY-MM-DD').
            - end_date (str, optional): End date for payment date filter (format: 'YYYY-MM-DD').
            - changed_data (dict, optional): Additional filters for future use (currently unused).
            - mod_pages (dict, optional): Pagination information (not used in this export).

    Returns:
        dict: On successful export, returns the response from `export_to_s3_bucket_`:
            - flag (bool): Whether the export succeeded.
            - message (str): Success or failure message.
            - data (dict): Exported file metadata such as S3 link.
        If no records are found, returns an empty DataFrame with expected columns.
    """
    start_time = time.time()
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

    # Extract relevant details from the input data dictionary
    table_name = data.get('table_name','vw_payment_history')
    tenant_name =data.get('tenant_name','')
    changed_data=data.get('changed_data', {})
    start_date=data.get('start_date', '')
    end_date=data.get('end_date', '')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1
    date_flag = True
    if start_date == 'Invalid Date' or end_date == 'Invalid Date':
        date_flag = False
    if end_date and date_flag:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
        except Exception as e:
            logging.warning(f"Error {e}")
    # Set default pagination if not provided
    tenant_time_zone = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name},["time_zone"]
        )["time_zone"].to_list()[0]

    if tenant_time_zone is None:
            raise ValueError("No valid timezone found for tenant.")
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly 

    # Query to get the total number of rows for pagination
    params = []

    try:
        # base_query = "SELECT * FROM vw_payment_history WHERE 1=1 "
        base_query = f"""
            SELECT customer_id, customer_name, agent, amount, method, date, ref
            FROM {table_name}
            WHERE 1=1 AND tenant_id = {tenant_id}
        """
        if start_date and end_date and date_flag:
            base_query += " AND date BETWEEN %s AND %s"
            params.extend([start_date, end_date])
        base_query += " ORDER BY date desc"  # Default sorting
        df = killbill_database.execute_query(base_query, params=params)  # Get the DataFrame directly
        df_dict = df.to_dict(orient="records")  # Convert to dictionary for processing
        df_dict = convert_timestamp(df_dict, tenant_time_zone)
        
        if not df_dict:
            columns = ["customer_id","customer_name","agent","amount","method","date","created_date","ref"]
            df = pd.DataFrame(columns=columns)  # Create empty DataFrame with columns
        else:
            df = pd.DataFrame(df_dict)

            df = df.fillna('')
            data["dfs"]={
                "Payment Details":df
            }
            data['module_name']='Payment History Report'
            response = export_to_s3_bucket_(data)
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "export_payment_details_report",
                "created_by": data.get("username", ""),
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": 'Successfully Exported Payment Details',
                "module_name": "BP Reports",
                "request_received_at": data.get("request_received_at", None)
            }
            database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong Exporting Payment Details",
            "data": {}
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_payment_details_report",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response

def export_unposted_items_report(data):
    """
    Retrieves a list of Reports for display, including pagination, filtering, and dropdown options.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): Tenant database name (default: 'altaworx_central').
            - role_name (str): User's role for permissions.
            - tenant_name (str): Tenant name for fetching timezone.
            - mod_pages (dict): Pagination details {start, end}.
            - col_sort (dict, optional): Sorting preferences.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - data (dict): Customer profiles with pagination.
            - header_map (dict): Mapped headers for UI display.
            - dropdown (dict): Dropdown values for filters.
            - pages (dict): Pagination details.
    """
    start_time = time.time()
    # Database connections
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    
    # Extract relevant details from the input data dictionary
    table_name = data.get('table_name','reports')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    role_name = data.get('role_name', '')
    # report_flag=data.get('report_flag', '')
    changed_data=data.get('changed_data', {})
    account_number=changed_data.get('column_value', '')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1
    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

    try:
        # query to get the data 
        base_query='select customer_id, description, amount, mrc,calculated_cost, sms_cost, tax_name, start_date, end_date, created_date, tn, line_id, product_id from unposted_items_view where tenant_id = %s ORDER BY created_date desc'
        df = killbill_database.execute_query(base_query, params=[tenant_id])  # Get the DataFrame directly
        df = df.rename(columns={
            "customer_id": "customer_ID",
            "mrc": "MRC",
            "calculated_cost": "usage",
            "sms_cost": "SMS",
            "tax_name": "tax",
            "line_id":"line_ID",
            "product_id": "product_ID"})
        df_dict = df.to_dict(orient="records")
        
        # Convert timestamps to the tenant's timezone
        final_df_dict = convert_timestamp(df_dict, tenant_time_zone)
        # Fetch mapped headers
        header_map = get_headers_mapping(killbill_database,["Unposted Items"],role_name, '', '', '', '',data)
        in_header_map=header_map["Unposted Items"]["header_map"]
        
        if not final_df_dict:
            columns=[]
            for key in in_header_map:
                columns.append(key)
            df = pd.DataFrame(columns=columns)
        else:
            df = pd.DataFrame(final_df_dict)
            df = df.fillna('')
        data["dfs"]={
            "Unposted Items by Customer":df
        }
        data["module_name"]='Unposted Items'
        response = export_to_s3_bucket_(data)
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "export_unposted_items_report",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully Exported Unposted Items',
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong Exporting Unposted Items",
            "data": {}
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_unposted_items_report",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response

def export_transcation_analysis_report(data):
    """
    Generates and exports the Unposted Items report for a tenant, applying timezone localization 
    and header mapping based on user role.

    Args:
        data (dict): Dictionary containing the following keys:
            - table_name (str, optional): Name of the database view/table to query. Defaults to 'reports'.
            - tenant_name (str): Name of the tenant for timezone resolution.
            - role_name (str): Role of the user to fetch UI-specific header mappings.
            - col_sort (dict, optional): Column sorting preferences (currently unused).
            - changed_data (dict, optional): Filtering inputs (e.g., column_value for account filtering — currently unused).
            - mod_pages (dict, optional): Pagination settings (not used in export).
            - report_flag (str, optional): Export flag (unused).

    Returns:
        dict: Result of export with the following keys:
            - flag (bool): Status of the export operation.
            - message (str): Status message.
            - data (dict): Metadata about the exported file.
            - Other keys as returned from `export_to_s3_bucket_`.
    """
    start_time = time.time()
    # Database connections
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    
    # Extract relevant details from the input data dictionary
    tenant_name =data.get('tenant_name','')
    role_name = data.get('role_name', '')
    start_date=data.get('start_date', '')
    end_date=data.get('end_date', '')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1
    if end_date:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
        except Exception as e:
            logging.warning(f"Error {e}")


    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

    # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

    try:
        if start_date:
            base_query="""select account_number,customer_name, iccid, description,gl_code, product_id, bill_range, category, amount, mrc, calculated_cost as usage, sms_cost as sms, tax_name as tax,modified_date from transaction_analysis_view where tenant_id = %s AND to_date(split_part(bill_range, ' - ', 1), 'MM-DD-YYYY') <= %s AND to_date(split_part(bill_range, ' - ', 2), 'MM-DD-YYYY') >= %s"""
            params=[tenant_id,start_date,end_date]
        else:
            base_query='select account_number,customer_name, iccid, description,gl_code, product_id, bill_range, category, amount, mrc, calculated_cost as usage, sms_cost as sms, tax_name as tax,modified_date from transaction_analysis_view where tenant_id = %s'
            params=[tenant_id]
        
        df = killbill_database.execute_query(base_query, params=params)  # Get the DataFrame directly
        df_dict = df.to_dict(orient="records")

        df = pd.DataFrame(df_dict)

        #Reorder so that 'gl_code' comes right after 'description'
        cols = list(df.columns)
        if "description" in cols and "gl_code" in cols:
            cols.remove("gl_code")
            desc_index = cols.index("description")
            cols.insert(desc_index + 1, "gl_code")
            df = df[cols]

        # Convert back to list of dicts
        df_dict = df.to_dict(orient="records")
        
        final_df_dict = convert_timestamp(df_dict, tenant_time_zone)

        
        # Fetch mapped headers
        header_map = get_headers_mapping(killbill_database,["Transaction Report"],role_name, '', '', '', '',data)
        in_header_map=header_map["Transaction Report"]["header_map"]

        if not final_df_dict:
            columns=[]
            for key in in_header_map:
                columns.append(key)
            df = pd.DataFrame(columns=columns)
        else:
            df = pd.DataFrame(final_df_dict)
            df = df.fillna('')
        data["dfs"]={
            "Transaction Report":df
        }
        data["module_name"]='Transaction Report'
        response = export_to_s3_bucket_(data)
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "export_transcation_analysis_report",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully Exported Transaction Analysis',
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong Exporting Unposted Items",
            "data": {}
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_transcation_analysis_report",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response

def export_altaworx_billing_report(data):
    """
    Generates and exports the Altaworx Billing Report for a given tenant, 
    including pagination, date filtering, role-based header mapping, and timezone localization.

    Args:
        data (dict): Input configuration with the following optional and required keys:
            - table_name (str, optional): Name of the database view/table. Defaults to 'billing_report_view'.
            - tenant_name (str): Name of the tenant for resolving timezone and data scope.
            - role_name (str): User role for permission-based header mapping.
            - report_flag (str, optional): Optional flag to indicate export behavior.
            - changed_data (dict, optional): Filtering details. Expects 'date_range' as [start_date, end_date].
            - col_sort (dict, optional): Dictionary indicating sort order (e.g., {"id": "desc"}).
            - mod_pages (dict, optional): Pagination details. Contains:
                - start (int): Start index for records.
                - end (int): End index for records.

    Returns:
        dict: A dictionary containing the result of the export operation with keys:
            - flag (bool): Indicates if export was successful.
            - message (str): Success or error message.
            - data (dict): Metadata about the exported report and file.
            - Other keys depending on the response from `export_to_s3_bucket_`.
    """
    start_time = time.time()
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

    table_name = data.get('table_name','billing_report_view')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    role_name = data.get('role_name', '')
    report_flag=data.get('report_flag', '')
    changed_data=data.get('changed_data', {})
    date_range=changed_data.get('date_range', {})
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1
    if len(date_range) >= 2:  # Ensure date_range has at least two values
        start_date = date_range[0].replace("Z", "")  # Remove 'Z'
        end_date = date_range[1].replace("Z", "")
    else:
        start_date = None
        end_date = None

    # user selected data
    
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    limit = end - start
    offset = start 

    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')
    try:
        if start_date and end_date:
            total_count_result_query = f"Select count(id) from billing_report_view where bill_cycle_start_date between '{start_date}' and '{end_date}'"
        else:
            total_count_result_query = "Select count(id) from billing_report_view"
        total_count_df = killbill_database.execute_query(total_count_result_query, True)
        total_count = total_count_df.iloc[0, 0] 
        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": int(total_count)
        }

        # Sort order handling (ensure valid keys)
        if col_sort:
            order =  {k: v.lower() for k, v in col_sort.items()}
        else:
            order= {"bill_id":"desc"}
        
        if start_date and end_date:
            query = f"Select * from billing_report_view where between '{start_date}' and '{end_date}' and tenant_id = {tenant_id} order by bill_id desc"
        else:
            query = f"Select * from {table_name} where tenant_id = {tenant_id} order by bill_id desc"
        df_dict = killbill_database.execute_query(query,True)
        df_dict = df_dict.to_dict(orient="records")

        final_df_dict = df_dict
        for i in range(len(final_df_dict)):
            item = final_df_dict[i]
            final_df_dict[i] = {
                "account_number": item["account_number"],
                "account_type": item["account_type"],
                "customer_name": item["customer_name"],
                "bill_id": item["bill_id"],
                "agent": item["sales_person"],
                "secondary_agent": "No",
                "statement_date": item["bill_cycle_start_date"],
                "balance_forward": item["amount_due"],
                "mrc": item["mrc"],
                "nrc": item["nrc"],
                "network_access_fee": item["network_access_fee"],
                "admin_recovery_tax": item["cost_recovery_fee"],
                "other_taxes": item["taxes"],
                "total": item["total"],
                "payments": item["payments"],
                "payment_date": item["bill_due_date"],
                "balance": item["account_balance"],
                "timezone": tenant_time_zone,
                "state": item["state"],
                "city": item["city"],
                "country": item["country"]
            }
        
        final_df_dict = convert_timestamp(final_df_dict, tenant_time_zone)
        if not final_df_dict:
            columns = ["account_number", "account_type", "customer_name","address", "bill_id","statement_date",
                    "sales_person", "secondary_sales_person", "bill_cycle_start_date",
                    "balance_forward", "mrc", "nrc", "network_access_fee","admin_recovery_tax",
                    "other_taxes", "total", "payments", "bill_due_date", "account_balance",
                    "state", "timezone"]
            df = pd.DataFrame(columns=columns)  # Create empty DataFrame with columns
        else:
            df = pd.DataFrame(final_df_dict)
        #df = pd.DataFrame(final_df_dict)

        df = df.fillna('')
        # data["dfs"]={
        #     "Altaworx Billing report":df
        # }
        data["dfs"] = {
            "Altaworx Billing Report": df  # Convert to list of dictionaries
        }
        data["module_name"]='Altaworx Billing Report'
        response = export_to_s3_bucket_(data)
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "export_altaworx_billing_report",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully Exported Altaworx Billing',
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong Exporting Unposted Items",
            "data": {}
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_altaworx_billing_report",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response


def collections_steps_list_view(data):
    """
    Fetches applicable collection steps for a bill based on its due date and template.

    Calculates days overdue, retrieves matching steps from the database, highlights the
    latest applicable step, and returns step data with header mappings for UI display.
    """
    start_time = time.time()
    # Database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    killbill_database = DB(os.environ["BILLING_PLATFORM"], **db_config)

    # Extract relevant details from input data
    table_name = data.get('table_name', 'customer_profiles')
    role_name = data.get('role_name', '')
    tenant_name = data.get('tenant_name', '')
    module_name = data.get('module_name', '')
    changed_data = data.get('changed_data', {})
    template_id = changed_data.get('collection_step', '')
    bill_due_date = changed_data.get('due_date_of_this_bill', '')
    logging.info(f'###bill_due_date {bill_due_date}')

    if isinstance(bill_due_date, str):
        bill_due_date = bill_due_date.strip()
        if not bill_due_date:
            return {
                "flag": False,
                "message": "Bill due date is mandatory"
            }  # No valid date provided
        bill_due_date = parser.parse(bill_due_date).date()
    else:
        bill_due_date = bill_due_date.date() if isinstance(bill_due_date, datetime) else bill_due_date

    # Calculate days overdue (like in SQL)
    days_overdue = (datetime.now().date() - bill_due_date).days

    if days_overdue < 0:
        # Bill is not yet due
        return None

    if template_id:
        #get collection_steps data from collection_steps data
        collection_steps_data = killbill_database.get_data(
            "collection_steps",
            {"template_id": template_id},
            ["id","step_type","step_description", "grace_period", "day"]
        ).to_dict(orient="records")
        logging.info(f'###collection_steps_data {collection_steps_data}')
        valid_steps = [step for step in collection_steps_data if int(step.get("day", 0)) <= days_overdue]

        if not valid_steps:
            return None

        # Pick the step with the highest day (latest applicable step)
        highlighted_row_id = max(valid_steps, key=lambda s: int(s.get("day", 0)))
    else:
        collection_steps_data = []
    try:
        # Fetch mapped headers
        header_map = get_headers_mapping(killbill_database, [module_name], role_name, '', '', '', '', data)
        steps_data = {"collection_steps": serialize_data(collection_steps_data)}


        # Construct success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": steps_data,
            "header_map": header_map,
            "highlighted_row_id":highlighted_row_id
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "collections_steps_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully Collection Steps Data',
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        return response

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Collections list",
            "data": {}  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "collections_steps_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    
    return response

def export_cycle_date_list_view(data):
    start_time = time.time()
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    killbill_database = DB(os.environ["BILLING_PLATFORM"], **db_config)
    module_name=data.get('module_name','Export Cycle Date')
    tenant_name = data.get('tenant_name', '')
    role_name = data.get('role_name', '')
    tenant_id = data.get('tenant_id', '')
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    col_sort = data.get("col_sort", "")
    limit = end - start
    offset = start
    mode=os.getenv('ENV','UAT')
    if mode=='UAT' and tenant_name == 'Altaworx Test':
        tenant_name = 'Altaworx'
        tenant_id = 1

    try:
        total_count_query = """
            SELECT COUNT(id) AS total_count 
            FROM vw_export_cycle_date 
            WHERE tenant_id = %s
        """
        total_count_result = killbill_database.execute_query(total_count_query, params = [tenant_id])
        total_count = int(total_count_result["total_count"].iloc[0])

        order = {k: v.lower() for k, v in col_sort.items()} if col_sort else {"bill_cycle_start_date": "desc"}
        order_by_clause = ", ".join([f"{col} {direction}" for col, direction in order.items()])
        
        account_details_query = f"""
            SELECT * 
            FROM vw_export_cycle_date 
            WHERE tenant_id = %s 
            ORDER BY {order_by_clause}
            LIMIT %s OFFSET %s
        """
        account_details = killbill_database.execute_query(
            account_details_query,
            params=[tenant_id, limit, offset]
        ).to_dict(orient='records')
        
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }
        
        header_map = get_headers_mapping(killbill_database, [module_name], role_name, '', '', '', '', data)
        
        data_dict_all = {"reports_data": serialize_data(account_details)}
        
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        end_time = time.time()
        return response
    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Export Cycle Date list",
            "data": {}  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_cycle_date_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response

def export_export_cycle_date(data):
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

    table_name = data.get('table_name','billing_report_view')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT' and tenant_name == 'Altaworx Test':
        tenant_name = 'Altaworx'
        tenant_id = 1

    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')
    
    try:
        account_details_query = f"""
                SELECT sales_person as agent_name, account_number as account_number,
                customer_id as customer_id,customer_name, cycle_day, bill_cycle_start_date as current_cycle_date,
                status, parent_account as isparent_account, child_account as ischild_account, time_zone
                FROM vw_export_cycle_date 
                WHERE tenant_id = %s 
            """
        account_details = killbill_database.execute_query(
            account_details_query,
            params=[tenant_id]
        ).to_dict(orient='records')
        account_details = convert_timestamp(account_details, tenant_time_zone)
        df = pd.DataFrame(account_details)
        df = df.fillna('')
        data["dfs"]={
            "Export Cycle Date":df
        }
        data["module_name"]='Export Cycle Date'
        return export_to_s3_bucket_(data)
    
    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Export Cycle Date list",
            "data": {}  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_export_cycle_date",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response

def billed_through_date_report_list_view(data):
    """
    Retrieves and formats billed through date report data with pagination support.
    
    Args:
        data (dict): Request data containing pagination, sorting, and filter parameters
        
    Returns:
        dict: Response containing report data, headers, pagination info, and status
    """
    
    # Initialize database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    killbill_database = DB(os.environ["BILLING_PLATFORM"], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    
    # Extract request parameters with defaults
    module_name = data.get('module_name', 'Billed Through Date Report')
    role_name = data.get('role_name', '')
    tenant_id = data.get('tenant_id', '')
    
    # Extract pagination parameters
    pagination = data.get('mod_pages', {})
    start = pagination.get('start', 0)
    end = pagination.get('end', 100)
    limit = end - start
    offset = start
    
    # Extract sorting parameters
    col_sort = data.get("col_sort", "")
    
    # Handle tenant ID validation - default to 1 if empty or 212
    environment_mode = os.getenv('ENV', 'UAT')
    if environment_mode == 'UAT':
        if tenant_id in [212, '212']:
            tenant_id = 1
            tenant_name = 'Altaworx'

    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')

    try:
        # Get total count for pagination
        total_count_query = "SELECT count(*) FROM billed_through_date_view WHERE tenant_id = %s"
        total_count_df = killbill_database.execute_query(total_count_query, params=[tenant_id])
        total_count = int(total_count_df.iloc[0, 0])
        
        # Prepare pagination metadata
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }

        # Process sorting parameters - convert to lowercase for consistency
        order = {k: v.lower() for k, v in col_sort.items()} if col_sort else {"modified_date": "desc"}

        # Fetch paginated report data
        # Note: ORDER BY clause should be added based on the order dictionary
        report_data_query = """
            SELECT * FROM billed_through_date_view 
            WHERE tenant_id = %s 
            LIMIT %s OFFSET %s
        """
        
        report_data_df = killbill_database.execute_query(
            report_data_query, 
            params=[tenant_id, limit, offset]
        )
        
        # Convert DataFrame to list of dictionaries for JSON serialization
        report_records = report_data_df.to_dict(orient='records')
        report_records = convert_timestamp(report_records, tenant_time_zone)

        for record in report_records:
            record['activation_date'] = datetime.strptime(record['activation_date'], "%m-%d-%Y %H:%M:%S").strftime("%m-%d-%Y")
            record['billed_through_date'] = datetime.strptime(record['billed_through_date'], "%m-%d-%Y %H:%M:%S").strftime("%m-%d-%Y")
        
        # Get header mappings for the report display
        header_map = get_headers_mapping(
            killbill_database, 
            [module_name], 
            role_name, 
            '', '', '', '', 
            data
        )
        
        # Prepare response data structure
        response_data = {
            "reports_data": serialize_data(report_records)
        }
        
        print(f"###billed_through_date_report_list_view Response data prepared: {response_data}")
        
        # Build success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": response_data,
            "header_map": header_map,
            "pages": pages_data
        }
        
        return response
        
    except Exception as e:
        # Log the exception for debugging
        logging.error(f"###billed_through_date_report_list_view Exception in billed_through_date_report_list_view: {e}")
        
        # Prepare error response
        error_response = {
            "flag": False,
            "message": "Something went wrong fetching Billed Through Date list",
            "data": {}
        }
        
        # Log error details to database for monitoring
        error_data = {
            "service_name": "billed_through_date_report_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        
        database.log_error_to_db(error_data, "error_log_table")
        
        return error_response


def billed_through_date_report_export(data):
    """
    Exports billed through date report data to S3 bucket in Excel format.
    
    Args:
        data (dict): Request data containing tenant information and export parameters
        
    Returns:
        dict: Response from S3 export function or error response
    """
    
    try:
        # Initialize database connections
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        
        
        tenant_name = data.get('tenant_name', '')
        tenant_id = data.get('tenant_id', '')
        # Handle environment-specific tenant mapping
        environment_mode = os.getenv('ENV', 'UAT')
        if environment_mode == 'UAT':
            # Map test tenant to production tenant for UAT environment
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        
        # Extract tenant information from request
        tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

            # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
                raise ValueError("No valid timezone found for tenant.")

        tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')

        # Query to retrieve billed through date report data
        # Ordered by modified_date descending to get latest records first
        export_data_query = """
            SELECT customer_id, line_id, tn, product_id, description, 
                   activation_date, billed_through_date, time_zone 
            FROM billed_through_date_view 
            WHERE tenant_id = %s 
            ORDER BY modified_date DESC
        """
        
        # Execute query and get DataFrame
        report_dataframe = killbill_database.execute_query(export_data_query, params=[tenant_id])
        
        # Convert DataFrame to dictionary format for processing
        report_records = report_dataframe.to_dict(orient="records")
        report_records = convert_timestamp(report_records, tenant_time_zone)
        for record in report_records:
            record['activation_date'] = datetime.strptime(record['activation_date'], "%m-%d-%Y %H:%M:%S").strftime("%m-%d-%Y")
            record['billed_through_date'] = datetime.strptime(record['billed_through_date'], "%m-%d-%Y %H:%M:%S").strftime("%m-%d-%Y")
        
        # Create DataFrame from records and handle null values
        processed_dataframe = pd.DataFrame(report_records)
        processed_dataframe = processed_dataframe.fillna('')
        
        # Prepare data structure for S3 export
        # The key will be used as the sheet name in the Excel file
        data["dfs"] = {
            "Billed Through Date": processed_dataframe
        }
        # Export processed data to S3 bucket
        return export_to_s3_bucket_(data)
        
    except Exception as e:
        # Log the exception for debugging purposes
        logging.error(f"###billed_through_date_report_export Exception in billed_through_date_report_export: {e}")
        
        # Prepare error response for client
        error_response = {
            "flag": False,
            "message": "Something went wrong fetching Billed Through Date Report",
            "data": {}
        }
        
        # Prepare error details for database logging
        error_details = {
            "service_name": "billed_through_date_report_export",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        
        # Log error to database for monitoring and troubleshooting
        database.log_error_to_db(error_details, "error_log_table")
        
        return error_response

def export_variance_billing_list_view(data):
    start_time = time.time()
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    killbill_database = DB(os.environ["BILLING_PLATFORM"], **db_config)
    
    
    module_name=data.get('module_name','Export Variance Billing')
    tenant_name = data.get('tenant_name', '')
    role_name = data.get('role_name', '')
    tenant_id = data.get('tenant_id', '')
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    col_sort = data.get("col_sort", "")
    limit = end - start
    offset = start
    mode=os.getenv('ENV','UAT')
    if mode=='UAT' and tenant_name == 'Altaworx Test':
        tenant_name = 'Altaworx'
        tenant_id = 1

    try:
        total_count_query = """
            SELECT COUNT(id) AS total_count 
            FROM vw_export_variance_billing_report 
            WHERE tenant_id = %s
        """
        total_count_result = killbill_database.execute_query(total_count_query, params = [tenant_id])
        total_count = int(total_count_result["total_count"].iloc[0])

        order = {k: v.lower() for k, v in col_sort.items()} if col_sort else {"modified_date": "desc"}
        order_by_clause = ", ".join([f"{col} {direction}" for col, direction in order.items()])
        
        account_details_query = f"""
            SELECT * 
            FROM vw_export_variance_billing_report 
            WHERE tenant_id = %s 
            ORDER BY {order_by_clause}
            LIMIT %s OFFSET %s
        """
        account_details = killbill_database.execute_query(
            account_details_query,
            params=[tenant_id, limit, offset]
        ).to_dict(orient='records')
        
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }
        
        header_map = get_headers_mapping(killbill_database, [module_name], role_name, '', '', '', '', data)
        
        data_dict_all = {"reports_data": serialize_data(account_details)}
        
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        end_time = time.time()
        return response
    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Export Cycle Date list",
            "data": {}  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_variance_billing_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response

def export_export_variance_billing(data):
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

    table_name = data.get('table_name','')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT' and tenant_name == 'Altaworx Test':
        tenant_name = 'Altaworx'
        tenant_id = 1

    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')
    
    try:
        account_details_query = f"""
                SELECT account_number as customer_id, customer_name as customer,
                status, prev_mrc as prevmrc, mrc as currmrc, diff_mrc as netmrc,
                prev_nrc as prevnrc, nrc as currnrc, diff_nrc as netnrc
                FROM vw_export_variance_billing_report 
                WHERE tenant_id = %s 
            """
        account_details = killbill_database.execute_query(
            account_details_query,
            params=[tenant_id]
        ).to_dict(orient='records')
        account_details = convert_timestamp(account_details, tenant_time_zone)
        df = pd.DataFrame(account_details)
        df = df.fillna('')
        data["dfs"]={
            "Export Variance Billing":df
        }
        data["module_name"]='Export Variance Billing'
        return export_to_s3_bucket_(data)
    
    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Export Variance Billing",
            "data": {}  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_export_variance_billing",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response



def altaworx_billing_report_by_day_report_list_view(data):
    """
    Retrieves and formats billed through date report data with pagination support.
    
    Args:
        data (dict): Request data containing pagination, sorting, and filter parameters
        
    Returns:
        dict: Response containing report data, headers, pagination info, and status
    """
    
    # Initialize database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    killbill_database = DB(os.environ["BILLING_PLATFORM"], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    
    # Extract request parameters with defaults
    module_name = data.get('module_name', 'Altaworx Billing Report By Day')
    role_name = data.get('role_name', '')
    tenant_id = data.get('tenant_id', '')
    date_range = data.get('date_range', {})
    start_date=data.get('start_date', '')
    end_date=data.get('end_date', '')

    
    # Extract pagination parameters
    pagination = data.get('mod_pages', {})
    start = pagination.get('start', 0)
    end = pagination.get('end', 100)
    limit = end - start
    offset = start
    
    # Extract sorting parameters
    col_sort = data.get("col_sort", "")
    
    # Handle tenant ID validation - default to 1 if empty or 212
    environment_mode = os.getenv('ENV', 'UAT')
    if environment_mode == 'UAT':
        if tenant_id in [212, '212']:
            tenant_id = 1
            tenant_name = 'Altaworx'

    tenant_name = data.get('tenant_name', '')
    try:
        # Get total count for pagination
        total_count_query = "SELECT count(*) FROM altaworx_billing_report_by_day WHERE tenant_id = %s"
        if start_date:
            total_count_query+=f" and date BETWEEN '{start_date}' AND '{start_date}';"
        total_count_df = killbill_database.execute_query(total_count_query, params=[tenant_id])
        total_count = int(total_count_df.iloc[0, 0])
        
        # Prepare pagination metadata
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }


        # Process sorting parameters - convert to lowercase for consistency
        order = {k: v.lower() for k, v in col_sort.items()} if col_sort else {"raw_date": "desc"}

        # Fetch paginated report data
        # Note: ORDER BY clause should be added based on the order dictionary
        report_data_query = """
            SELECT * FROM altaworx_billing_report_by_day 
            WHERE tenant_id = %s"""
        if start_date:
            report_data_query += f" AND raw_date BETWEEN '{start_date}' AND '{end_date}' "
        if order:
            order_clause = ", ".join([f"{col} {direction.upper()}" for col, direction in order.items()])
            report_data_query += f" ORDER BY {order_clause} "
        report_data_query += " LIMIT %s OFFSET %s;"
        
        report_data_df = killbill_database.execute_query(
            report_data_query, 
            params=[tenant_id, limit, offset]
        )
        
        # Convert DataFrame to list of dictionaries for JSON serialization
        report_records = report_data_df.to_dict(orient='records')
        
        # Get header mappings for the report display
        header_map = get_headers_mapping(
            killbill_database, 
            [module_name], 
            role_name, 
            '', '', '', '', 
            data
        )
        
        # Prepare response data structure
        response_data = {
            "reports_data": serialize_data(report_records)
        }
        
        print(f"###altaworx_billing_report_by_day_report_list_view Response data prepared: {response_data}")
        
        # Build success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": response_data,
            "header_map": header_map,
            "pages": pages_data
        }
        
        return response
        
    except Exception as e:
        # Log the exception for debugging
        logging.error(f"###altaworx_billing_report_by_day_report_list_view Exception in altaworx_billing_report_by_day_report_list_view: {e}")
        
        # Prepare error response
        error_response = {
            "flag": False,
            "message": "Something went wrong fetching Altaworx Billing Report By Day",
            "data": {}
        }
        
        # Log error details to database for monitoring
        error_data = {
            "service_name": "altaworx_billing_report_by_day_report_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        
        database.log_error_to_db(error_data, "error_log_table")
        
        return error_response

def altaworx_billing_report_by_day_report_export(data):
    """
    Exports billed through date report data to S3 bucket in Excel format.
    
    Args:
        data (dict): Request data containing tenant information and export parameters
        
    Returns:
        dict: Response from S3 export function or error response
    """
    
    try:
        # Initialize database connections
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        start_date = data.get('start_date', '')
        end_date = data.get('end_date', '')

        
        
        tenant_name = data.get('tenant_name', '')
        tenant_id = data.get('tenant_id', '')
        # Handle environment-specific tenant mapping
        environment_mode = os.getenv('ENV', 'UAT')
        if environment_mode == 'UAT':
            # Map test tenant to production tenant for UAT environment
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1

        # Query to retrieve billed through date report data
        # Ordered by modified_date descending to get latest records first
        export_data_query = """
            SELECT total_mrc_billed,total_nrc_billed,total_network_access_tax_billed,total_admin_recovery_tax_billed,total_other_tax_billed
            ,total_payments,total_billed_amount,date
            FROM altaworx_billing_report_by_day 
            WHERE tenant_id = %s 
        """
        if start_date:
            export_data_query += f" AND raw_date BETWEEN '{start_date}' AND '{end_date}' "
        export_data_query += " ORDER BY raw_date DESC;"
        
        # Execute query and get DataFrame
        report_dataframe = killbill_database.execute_query(export_data_query, params=[tenant_id])
        
        # Convert DataFrame to dictionary format for processing
        report_records = report_dataframe.to_dict(orient="records")

        # Create DataFrame from records and handle null values
        processed_dataframe = pd.DataFrame(report_records)
        processed_dataframe = processed_dataframe.fillna('')
        
        # Prepare data structure for S3 export
        # The key will be used as the sheet name in the Excel file
        data["dfs"] = {
            "Altaworx Billing Report By Day": processed_dataframe
        }
        # Export processed data to S3 bucket
        return export_to_s3_bucket_(data)
        
    except Exception as e:
        # Log the exception for debugging purposes
        logging.error(f"###altaworx_billing_report_by_day_report_export Exception in altaworx_billing_report_by_day_report_export: {e}")
        
        # Prepare error response for client
        error_response = {
            "flag": False,
            "message": "Something went wrong fetching Altaworx Billing Report By Day",
            "data": {}
        }
        
        # Prepare error details for database logging
        error_details = {
            "service_name": "altaworx_billing_report_by_day_report_export",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        
        # Log error to database for monitoring and troubleshooting
        database.log_error_to_db(error_details, "error_log_table")
        
        return error_response

def total_mrc_bill_profiles_list_view(data):
    start_time = time.time()
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    killbill_database = DB(os.environ["BILLING_PLATFORM"], **db_config)
    
    
    module_name=data.get('module_name','Total MRC For Bill Profiles')
    tenant_name = data.get('tenant_name', '')
    role_name = data.get('role_name', '')
    tenant_id = data.get('tenant_id', '')
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    col_sort = data.get("col_sort", "")
    limit = end - start
    offset = start
    mode=os.getenv('ENV','UAT')
    if mode=='UAT' and tenant_name == 'Altaworx Test':
        tenant_name = 'Altaworx'
        tenant_id = 1

    try:
        total_count_query = """
            SELECT COUNT(bill_id) AS total_count 
            FROM vw_total_mrc_for_bill_proile_report 
            WHERE tenant_id = %s
        """
        total_count_result = killbill_database.execute_query(total_count_query, params = [tenant_id])
        total_count = int(total_count_result["total_count"].iloc[0])

        order = {k: v.lower() for k, v in col_sort.items()} if col_sort else {"modified_date": "desc"}
        order_by_clause = ", ".join([f"{col} {direction}" for col, direction in order.items()])
        
        account_details_query = f"""
            SELECT * 
            FROM vw_total_mrc_for_bill_proile_report 
            WHERE tenant_id = %s 
            ORDER BY {order_by_clause}
            LIMIT %s OFFSET %s
        """
        account_details = killbill_database.execute_query(
            account_details_query,
            params=[tenant_id, limit, offset]
        ).to_dict(orient='records')
        
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }
        
        header_map = get_headers_mapping(killbill_database, [module_name], role_name, '', '', '', '', data)
        
        data_dict_all = {"reports_data": serialize_data(account_details)}
        
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        end_time = time.time()
        return response
    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Total MRC for Bill Profiles list",
            "data": {}  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "total_mrc_bill_profiles_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response


def export_total_mrc_bill_profiles(data):
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

    table_name = data.get('table_name','')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT' and tenant_name == 'Altaworx Test':
        tenant_name = 'Altaworx'
        tenant_id = 1

    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')
    
    try:
        account_details_query = f"""
                SELECT account_number as customer_id, customer_name as name,
                sales_person as agent, contract_start_date as contract_signed_date,
                customer_creation_date as customer_created_date, customer_activation_date as customer_activation_date,
                bill_id as statement_id, bill_generation_date as statement_created_date, 
                due_date_of_this_bill as due_date, mrc, usage, time_zone
                FROM vw_total_mrc_for_bill_proile_report 
                WHERE tenant_id = %s 
            """
        account_details = killbill_database.execute_query(
            account_details_query,
            params=[tenant_id]
        ).to_dict(orient='records')
        account_details = convert_timestamp(account_details, tenant_time_zone)
        df = pd.DataFrame(account_details)
        df = df.fillna('')
        data["dfs"]={
            "Total MRC For Bill Profiles":df
        }
        data["module_name"]='Total MRC For Bill Profiles'
        return export_to_s3_bucket_(data)
    
    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Total MRC For Bill Profiles",
            "data": {}  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_total_mrc_bill_profiles",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response