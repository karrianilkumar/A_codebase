"""
@Author : Phaneendra. Y
Created Date: 21-06-24
"""

# Standard Library Imports
import base64
import concurrent.futures
import io
import json
import os
import re
import time
import zipfile
from datetime import datetime
from io import BytesIO
import threading

# Third-Party Imports
import boto3
import pandas as pd
import pytds
import requests
from pytz import timezone
import re
import pandas as pd
from pytz import timezone
import numpy as np


# Local Application/Custom Imports
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import *

import openpyxl
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
from openpyxl import load_workbook
from openpyxl import Workbook
from openpyxl.styles.numbers import BUILTIN_FORMATS

# AWS S3 client
s3_client = boto3.client("s3")
# Retrieve the S3 bucket name from an environment variable
S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME")

logging = Logging(name="optimization")


def db_config_maker(user, db_config_making):

    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_making)

    query = f"select customers,service_provider from users where username ='{user}'"
    filters = common_utils_database.execute_query(query, True)
    try:
        customer = tuple(json.loads(filters["customers"].to_list()[0]))
    except:
        customer = None
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
    except:
        service_provider = None

    db_config_making["customers"] = customer
    db_config_making["service_providers"] = service_provider

    return db_config_making


def funtion_caller(data, path):
    if "data" in data:
        data = data.get("data")
    global db_config

    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

    user = data.get("username")
    if not user:
        user = data.get("user_name")

    db_config_making = db_config_maker(user, db_config)
    db_config = db_config_making
    logging.info(f"db_config created is : {db_config}")

    if path == "/optimization_dropdown_data":
        result = optimization_dropdown_data(data)
    elif path == "/get_optimization_data":
        result = get_optimization_data(data)
    elif path == "/export_optimization_data_zip":
        result = export_optimization_data_zip(data)
    elif path == "/start_optimization":
        result = start_optimization(data)
    elif path == "/get_optimization_pop_up_data":
        result = get_optimization_pop_up_data(data)
    elif path == "/push_charges_submit":
        result = push_charges_submit(data)
    elif path == "/get_optimization_row_details":
        result = get_optimization_row_details(data)
    elif path == "/get_optimization_details_reports_data":
        result = get_optimization_details_reports_data(data)
    elif path == "/get_optimization_push_charges_data":
        result = get_optimization_push_charges_data(data)
    elif path == "/get_assign_rate_plan_optimization_dropdown_data":
        result = get_assign_rate_plan_optimization_dropdown_data(data)
    elif path == "/update_optimization_actions_data":
        result = update_optimization_actions_data(data)
    elif path == "/update_push_charges_data_optimization":
        result = update_push_charges_data_optimization(data)
    elif path == "/get_export_status":
        result = get_export_status(data)
    elif path == "/get_optimization_progress_bar_data":
        result = get_optimization_progress_bar_data(data)
    elif path == "/get_optimization_error_details_data":
        result = get_optimization_error_details_data(data)
    elif path == "/optimize_button_status":
        result = optimize_button_status(data)
    elif path == "/get_push_charges_status":
        result = get_push_charges_status(data)
    elif path == "/get_push_charges_count":
        result = get_push_charges_count(data)
    elif path == "/rate_plan_progress":
        result = rate_plan_progress(data)
    elif path == "/get_rate_plan_upload_pop_up_values":
        result = get_rate_plan_upload_pop_up_values(data)
    elif path == "/rate_plan_upload":
        result = rate_plan_upload(data)

    else:
        result = {"error": "Invalid path or method"}
        logging.warning("Invalid path or method requested: %s", path)

    return result


def get_optimization_data(data):
    """
    This function retrieves optimization data by executing a query based
    on the provided module name and parameters,
    converting the results into a dictionary format.
    It logs the audit and error details to the database
    and returns the optimization data along with a success flag.
    """
    logging.info("Request Recieved")
    # Record the start time for performance measurement
    start_time = time.time()
    module_name = data.get("module_name", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", None)
    Partner = data.get("Partner", "")
    mod_pages = data.get("mod_pages", {})
    role_name = data.get("role_name", "")
    # Set the limit for the number of records to retrieve per request
    limit = 100
    offset = mod_pages.get("start", 0)
    end = mod_pages.get("end", 0)
    table = data.get("table_name", "")
    tenant_name = data.get("tenant_name", "")
    optimization_type = data.get("optimization_type", "")
    logging.info("Optimization Type is: %s", optimization_type)
    # Check if optimization_type is empty or None and return a response
    if not optimization_type:
        logging.warning("Optimization type is missing from the data.")
        return {
            "flag": False,
            "message": "Optimization type is required but not provided.",
        }
    # Database connection
    tenant_database = data.get("db_name", "")
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    return_json_data = {}
    # Initialize pagination dictionary
    pages = {"start": offset, "end": end}

    tenant_timezone = None
    try:
        count_params = [table]
        if optimization_type == "Customer":
            count_query = f"SELECT COUNT(*) FROM vw_customer_optimization "
        else:
            count_query = f"SELECT COUNT(*) FROM vw_carrier_optimization"
        # count_start_time = time.time()
        count_result = database.execute_query(count_query, count_params).iloc[0, 0]
        # Set total pages count
        pages["total"] = int(count_result)
        # Retrieve the module query from the 'module_view_queries' table
        module_query_df = common_utils_database.get_data(
            "module_view_queries", {"module_name": optimization_type}
        )
        if module_query_df.empty:
            raise ValueError(f"No query found for module name: {optimization_type}")
        query = module_query_df.iloc[0]["module_query"]
        if not query:
            raise ValueError(f"Unknown module name: {optimization_type}")
        params = [offset, limit]
        # main_query_start_time = time.time()
        optimization_dataframe = database.execute_query(query, params=params)
        # # Fetch the tenant's timezone
        # tenant_time_zone = fetch_tenant_timezone(common_utils_database,data)
        # optimization_dataframe = convert_timestamp_data(
        #     optimization_dataframe, tenant_time_zone
        # )
        optimization_dict = optimization_dataframe.to_dict(orient="records")
        print("entered hereeeeeeeeeeeeeee for tenant timezone")
        if optimization_dict:
            tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
            optimization_dict = convert_timestamp_data(
                optimization_dict, tenant_time_zone
            )
        print("entered hereeeeeeeeeeeeeee for after time zone conversion timezone")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database,
            [optimization_type],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )
        # Query for billing period information
        billing_period_query = """
                SELECT service_provider,
                (TO_CHAR(billing_cycle_start_date, 'MM/DD/YYYY') || ' - ' || TO_CHAR(billing_cycle_end_date, 'MM/DD/YYYY')) AS billing_cycle_start_date
                    FROM billing_period
                    WHERE is_active = 'true'
                    ORDER BY
                        CASE
                            WHEN CURRENT_DATE BETWEEN billing_cycle_start_date
                            AND billing_cycle_end_date THEN 0
                            ELSE 1
                        END,
                        billing_cycle_end_date DESC
            """
        billing_period_dates = database.execute_query(
            billing_period_query, True
        ).to_dict(orient="records")
        # Extract only the service_provider values
        service_providers = [row["service_provider"] for row in billing_period_dates]

        # Create a dictionary where the key is service_provider and
        # the value is a list of billing_cycle_end_dates
        service_provider_dict = {}

        for row in billing_period_dates:
            if row["service_provider"] in service_provider_dict:
                service_provider_dict[row["service_provider"]].append(
                    row["billing_cycle_start_date"]
                )
            else:
                service_provider_dict[row["service_provider"]] = [
                    row["billing_cycle_start_date"]
                ]

        # Optionally, remove duplicates
        unique_service_providers = sorted(list(set(service_providers)))
        # Add "All" to the list of unique service providers
        unique_service_providers.insert(0, "All service providers")
        try:
            # Attempt to retrieve the value from the 'tenant' table
            result = common_utils_database.get_data(
                "tenant",
                {"tenant_name": tenant_name},
                ["cross_provider_customer_optimization"],
            )

            # Check if the result is not empty and extract the value safely
            cross_carrier_optimization = result[
                "cross_provider_customer_optimization"
            ].to_list()
            if cross_carrier_optimization:
                cross_carrier_optimization = cross_carrier_optimization[0]
            else:
                cross_carrier_optimization = False
        except Exception as e:
            logging.exception(f"Failed to get the cross_carrier_optimization{e}")
            cross_carrier_optimization = False
        # Preparing the response data
        return_json_data.update(
            {
                "message": "Successfully Fetched the optimization data",
                "flag": True,
                "service_providers": unique_service_providers,
                "billing_period_dates": serialize_data(service_provider_dict),
                "headers_map": headers_map,
                "data": optimization_dict,
                "pages": pages,
                "cross_carrier_optimization": False,
            }
        )
        # End time and audit logging
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "Optimization",
            "created_date": request_received_at,
            "created_by": username,
            "status": str(return_json_data["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "optimization data",
            "module_name": optimization_type,
            "request_received_at": request_received_at,
        }
        common_utils_database.update_audit(
            audit_data_user_actions, "audit_user_actions"
        )
        return return_json_data
    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database,
            [module_name],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )
        message = f"Unable to fetch the Optimization data{e}"
        return_json_data = {
            "flag": True,
            "message": message,
            "headers_map": headers_map,
            "data": [],
            "cross_carrier_optimization": False,
        }
        error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "Optimization",
            "created_date": request_received_at,
            "error_message": message,
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "Failed to get Optimization data",
            "module_name": optimization_type,
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")

        return return_json_data


# Helper function to fetch the tenant's timezone
# def fetch_tenant_timezone(common_utils_database,data):
#     tenant_name = data.get("tenant_name", "")
#     tenant_timezone_query = (
#         """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
#     )
#     # tenant_timezone_start_time = time.time()
#     tenant_timezone = common_utils_database.execute_query(
#         tenant_timezone_query, params=[tenant_name]
#     )
#     # tenant_timezone_duration = time.time() - tenant_timezone_start_time
#     if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
#         raise ValueError("No valid timezone found for tenant.")
#     tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
#     if not re.match(r"^[A-Za-z]+/[A-Za-z_]+$", tenant_time_zone):
#         raise ValueError(f"Invalid timezone format: {tenant_time_zone}")


# return tenant_time_zone

# def convert_timestamp_data(df_dict, tenant_time_zone, timestamp_columns=None):
#     print('entered hereeeeeeeeeeeeeeee for convert_timestamp_data')
#     if timestamp_columns is None:
#         timestamp_columns = [
#         "created_date",
#         "modified_date",
#         "deleted_date","run_start_time","optimization_run_end_time"
#     ]
#     target_timezone = timezone(tenant_time_zone)
#     utc_timezone = timezone("UTC")

#     def process_record(record):
#         for col in timestamp_columns:
#             if col in record and record[col]:  # Ensure column exists and is truthy
#                 try:
#                     # Parse timestamp and assume it's in UTC
#                     timestamp = pd.to_datetime(record[col], errors="coerce")
#                     if timestamp is not pd.NaT:
#                         if timestamp.tz is None:
#                             # Localize naive timestamps to UTC
#                             timestamp = timestamp.tz_localize(utc_timezone)
#                         # Convert to the target timezone
#                         record[col] = timestamp.tz_convert(target_timezone).strftime("%m-%d-%Y %H:%M:%S")
#                 except Exception as e:
#                     print(f"Error processing column '{col}': {record[col]} - {e}")
#         return record

#     def traverse_data(data):
#         if isinstance(data, list):  # Process each item if data is a list
#             return [traverse_data(item) for item in data]
#         elif isinstance(data, dict):  # Process each key-value pair if data is a dictionary
#             return process_record(data)
#         return data  # Return data as-is for non-dict/non-list

#     return traverse_data(df_dict)


# def serialize_data(data):
#     """Recursively convert pandas objects in the data structure to serializable types."""
#     if isinstance(data, list):
#         return [serialize_data(item) for item in data]
#     elif isinstance(data, dict):
#         return {key: serialize_data(value) for key, value in data.items()}
#     elif isinstance(data, pd.Timestamp):
#         # Handle pd.Timestamp and NaT
#         return data.strftime("%m-%d-%Y %H:%M:%S") if pd.notna(data) else None
#     elif data is pd.NaT:  # Directly check for pd.NaT
#         return None
#     elif isinstance(data, np.datetime64):  # Handle numpy datetime64
#         return str(data) if pd.notna(data) else None
#     elif pd.api.types.is_integer(data):  # Check explicitly for integers
#         return int(data)
#     elif pd.api.types.is_float(data):  # Check explicitly for floats
#         return float(data)
#     elif pd.isna(data):  # Handle NaN or missing values
#         return None
#     else:
#         return data  # Return as is for other types


def get_headers_mapping(
    tenant_database,
    module_list,
    role,
    user,
    tenant_id,
    sub_parent_module,
    parent_module,
    data,
    common_utils_database,
):
    """
    Description: The  function retrieves and organizes field mappings,headers,and module features
    based on the provided module_list, role, user, and other parameters.
    It connects to a database, fetches relevant data, categorizes fields,and
    compiles features into a structured dictionary for each module.
    """
    ##Database connection
    ret_out = {}
    try:
        logging.info(f"Module name is :{module_list} and role is {role}")
        # common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        feature_module_name = data.get("feature_module_name", "")
        user_name = data.get("username") or data.get("user_name") or data.get("user")
        tenant_name = data.get("tenant_name") or data.get("tenant")
        parent_module_name = data.get("parent_module_name") or data.get("parent_module")
        if parent_module_name == "Sim Management":
            parent_module_name = "Sim Management"
        try:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            logging.info(f"tenant_id  is :{tenant_id}")
        except Exception as e:
            logging.exception(f"Getting exception at fetching tenant id {e}")
        # Iterate over each module name in the provided module list
        for module_name in module_list:
            out = common_utils_database.get_data(
                "field_column_mapping", {"module_name": module_name}
            ).to_dict(orient="records")
            pop_up = []
            general_fields = []
            table_fileds = {}
            # Categorize the fetched data based on field types
            for data in out:
                if data["pop_col"]:
                    pop_up.append(data)
                elif data["table_col"]:
                    table_fileds.update(
                        {
                            data["db_column_name"]: [
                                data["display_name"],
                                data["table_header_order"],
                            ]
                        }
                    )
                else:
                    general_fields.append(data)
            # Create a dictionary to store categorized fields
            headers = {}
            headers["general_fields"] = general_fields
            headers["pop_up"] = pop_up
            headers["header_map"] = table_fileds
            logging.info(f"Got the header map here")
            try:
                final_features = []

                # Fetch all features for the 'super admin' role
                if role.lower() == "super admin":
                    all_features = common_utils_database.get_data(
                        "module_features",
                        {
                            "module": feature_module_name,
                            "parent_module_name": parent_module_name,
                        },
                        ["features"],
                    )["features"].to_list()
                    if all_features:
                        final_features = json.loads(all_features[0])
                else:
                    final_features = get_features_by_feature_name(
                        user_name,
                        tenant_id,
                        feature_module_name,
                        common_utils_database,
                        role,
                        parent_module_name,
                    )

            except Exception as e:
                logging.warning(f"there is some error {e}")
                pass
            # Add the final features to the headers dictionary
            headers["module_features"] = final_features
            ret_out[module_name] = headers
    except Exception as e:
        logging.warning("there is some error %s", e)

    return ret_out


def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, role, parent_module
):
    """
    Description:
        This function retrieves a list of features associated with a specific
        feature name for a user within a tenant.
        It fetches user-module-tenant mapping data, processes the features,
        and extracts relevant features
        linked to the specified feature name.

    Parameters:
    ----------
    user_name : str
        The name or identifier of the user for whom the features are being fetched.
    tenant_id : str
        The tenant ID associated with the user.
    feature_name : str
        The specific feature name for which features need to be extracted.
    common_utils_database : object
        Utility database object to query data from the required tables.

    Returns:
    -------
    list
        A list of features associated with the specified feature name for the user.
    """

    # Fetch user features from the database based on user name and tenant ID
    user_features_raw = common_utils_database.get_data(
        "user_module_tenant_mapping",
        {"user_name": user_name, "tenant_id": tenant_id},
        ["module_features"],
    )["module_features"].to_list()
    logging.info("Raw user features fetched: %s", user_features_raw)

    # Parse the JSON string to a dictionary
    try:
        features = json.loads(
            user_features_raw[0]
        )  # Assuming it's a list with one JSON string
    except:
        features = {}

    if not features:
        features = common_utils_database.get_data(
            "role_module",
            {"role": role},
            ["module_features"],
        )["module_features"].to_list()
        features = json.loads(features[0])

    # Initialize a list to hold features for the specified feature name
    features_list = []

    # Loop through all modules to find the specified feature name and collect its features
    for par_module, modules in features.items():
        if parent_module == par_module:
            for module, features_l in modules.items():
                if module == feature_name:
                    features_list = features_l

    # Log the retrieved features for debugging purposes
    logging.info("Retrieved features: %s", features_list)

    # Return the list of features associated with the specified feature name
    return features_list


def format_column_names(columns):
    """
    This function formats column names by removing underscores and capitalizing each word.
    Example: 'session_id' becomes 'Session ID'
    """
    formatted_columns = []
    for col in columns:
        formatted_col = col.replace(
            "_", " "
        ).title()  # Replaces underscores and capitalizes each word
        formatted_columns.append(formatted_col)
    return formatted_columns


def export_optimization_data_zip(data):
    """
    The export_optimization_data_zip function generates a ZIP file containing
    Excel files grouped by session IDs based on query results retrieved from a
    database. It processes optimization data using provided filters, encodes the
    ZIP as a base64 string, and stores it in an S3 bucket, returning the URL for download.
    If no data is found, an empty ZIP with an empty Excel sheet is returned.
    """
    logging.info("Request Data Received")
    request_received_at = data.get("request_received_at", "")
    # module_name = data.get("module_name", "Optimization")
    optimization_type = data.get("optimization_type", "")
    if optimization_type == "Carrier":
        module_name = "Carrier Optimization"
    else:
        module_name = "Customer Optimization"

    service_provider = data.get("service_provider", "")
    billing_period_start_date = data.get("billing_period_start_date", "")
    billing_period_end_date = data.get("billing_period_end_date", "")
    Partner = data.get("Partner", "")
    username = data.get("username", "")
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    common_utils_database.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": "Export Optimization"},
    )

    try:

        # Convert input dates to match database format
        if billing_period_start_date:
            billing_period_start_date = datetime.strptime(
                billing_period_start_date, "%m/%d/%Y"
            ).strftime("%m-%d-%Y %H:%M:%S")
        if billing_period_end_date:
            billing_period_end_date = datetime.strptime(
                billing_period_end_date, "%m/%d/%Y"
            ).strftime("%m-%d-%Y 23:59:59")

        print(billing_period_start_date, billing_period_end_date, "22222222")

        # Fetch the query from the database based on the module name
        module_query_df = common_utils_database.get_data(
            "export_queries", {"module_name": module_name}
        )
        query = module_query_df.iloc[0]["module_query"]
        # Prepare the WHERE clause with necessary filters
        base_query = query.split("where")[0].strip()
        where_clause = ""
        params = []

        if service_provider:
            where_clause += " WHERE serviceprovider = %s AND billing_period_start_date >= %s AND billing_period_end_date <= %s"
            # params.append(service_provider)
            params = [
                service_provider,
                billing_period_start_date,
                billing_period_end_date,
            ]

        final_query = f"{base_query} {where_clause}"

        # Executing the query and fetching data
        data_frame = database.execute_query(final_query, params=params)
        # Function to format column names: remove underscores and capitalize each word
        # Create a new ZIP file buffer
        zip_buffer = io.BytesIO()
        zip_filename = "Optimization_session.zip"

        # If the data frame is empty, create an empty DataFrame with headers only
        if data_frame.empty:
            logging.info("No data found, creating an empty Excel file.")
            empty_df = pd.DataFrame(columns=["S.NO", "Session ID", "Other Columns"])
            with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zipf:
                excel_buffer = io.BytesIO()
                with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                    empty_df.to_excel(writer, index=False)
                    # Access the workbook and sheet after writing to Excel
                    workbook = writer.book
                    sheet = workbook.active

                    # Apply styles to the header row
                    for cell in sheet[1]:
                        # Center align the header cells
                        cell.alignment = Alignment(
                            horizontal="center", vertical="center"
                        )
                        # Set grey background for header cells
                        cell.fill = PatternFill(
                            start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                        )

                    # Adjust column widths based on content
                    for col_idx, col_cells in enumerate(sheet.columns, 1):
                        max_length = max(
                            len(str(cell.value or "")) for cell in col_cells
                        )
                        sheet.column_dimensions[get_column_letter(col_idx)].width = (
                            max_length + 2
                        )

                excel_buffer.seek(0)
                zipf.writestr("Empty_Optimization_Data.xlsx", excel_buffer.read())
        else:
            with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zipf:
                grouped = data_frame.groupby("session_id")
                for session_id, group in grouped:
                    folder_name = f"{session_id}/"
                    zipf.writestr(folder_name, "")

                    excel_buffer = io.BytesIO()
                    group.columns = format_column_names(group.columns)
                    with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                        group.to_excel(writer, index=False)
                        # Access the workbook and sheet after writing to Excel
                        workbook = writer.book
                        sheet = workbook.active

                        # Apply styles to the header row
                        for cell in sheet[1]:
                            # Center align the header cells
                            cell.alignment = Alignment(
                                horizontal="center", vertical="center"
                            )
                            # Set grey background for header cells
                            cell.fill = PatternFill(
                                start_color="D3D3D3",
                                end_color="D3D3D3",
                                fill_type="solid",
                            )

                        # Adjust column widths based on content
                        for col_idx, col_cells in enumerate(sheet.columns, 1):
                            max_length = max(
                                len(str(cell.value or "")) for cell in col_cells
                            )
                            sheet.column_dimensions[
                                get_column_letter(col_idx)
                            ].width = (max_length + 2)

                    excel_buffer.seek(0)
                    zipf.writestr(
                        f"{folder_name}{session_id}.xlsx", excel_buffer.read()
                    )

        # Upload the ZIP file to S3
        zip_buffer.seek(0)
        s3_client = boto3.client("s3")
        s3_key = f"exports/optimization/{zip_filename}"
        S3_BUCKET_NAME = os.environ[
            "S3_BUCKET_NAME"
        ]  # Ensure this environment variable is set

        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=s3_key,
            Body=zip_buffer.getvalue(),
            ContentType="application/zip",
        )

        # Generate download URL
        download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{s3_key}"
        logging.info("File uploaded to S3 successfully.")

        # Log success and return response
        response = {
            "flag": True,
            "message": "Export successful",
            "download_url": download_url,
        }
        common_utils_database.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": "Export Optimization"},
        )

        return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        message = "Failed to process the data export"
        error_data = {
            "service_name": "optimization",
            "created_date": request_received_at,
            "error_message": message,
            "error_type": str(e),
            "user": username,
            "tenant_name": Partner,
            "comments": message,
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_table")
        common_utils_database.update_dict(
            "export_status",
            {"status_flag": "Failure", "url": ""},
            {"module_name": "Export Optimization"},
        )

        return {"flag": False, "error": str(e)}


def optimization_dropdown_data(data):
    """
    The optimization_dropdown_data function fetches dropdown data
    for service providers, including unique customer names and their
    corresponding billing periods, based on active service providers
    from the database. It structures the response into two parts:
    service_provider_customers and service_provider_billing_periods,
    handling errors and returning appropriate fallback data in case of an issue.
    """
    logging.info("Request Data Received")
    tenant_database = data.get("db_name", "")
    try:
        # Database connection
        database = DB(tenant_database, **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    try:
        # List of service provider names with their IDs
        serviceproviders = database.get_data(
            "serviceprovider",
            {"is_active": True, "service_provider_name": "not Null"},
            ["id", "service_provider_name"],
        )
        service_provider_list = serviceproviders.to_dict(
            orient="records"
        )  # List of dicts containing both id and service_provider_name
        service_provider_list = sorted(
            service_provider_list, key=lambda x: x["service_provider_name"]
        )
        logging.info(f"Successfully fetched the service providers")

        # Initialize dictionaries to store separate data
        service_provider_customers = {}
        service_provider_billing_periods = {}

        # Iterate over each service provider
        for service_provider in service_provider_list:
            service_provider_id = service_provider["id"]
            service_provider_name = service_provider["service_provider_name"]

            # Get customer data (including possible duplicates)
            query_customers = f"""SELECT DISTINCT customer_name, customer_id
              FROM optimization_customer_processing where service_provider='{service_provider_name}'
              """
            customers = database.execute_query(query_customers, True)

            # Create a set to filter unique customer names
            unique_customers = set()
            customer_list = []

            # Loop through each customer and add unique ones to the list
            for row in customers.to_dict(orient="records"):
                customer_name = row["customer_name"]
                if (
                    customer_name not in unique_customers
                ):  # Check if the customer is already added
                    unique_customers.add(customer_name)
                    customer_list.append(
                        {
                            "customer_id": row["customer_id"],
                            "customer_name": customer_name,
                        }
                    )

            # Get billing period data including start date, end date, and ID
            billing_periods = database.get_data(
                "billing_period",
                {"service_provider": service_provider_name, "is_active": True},
                ["id", "billing_cycle_start_date", "billing_cycle_end_date"],
                order={"billing_cycle_end_date": "desc"},
            )

            # Check and handle missing or invalid values in the billing_cycle_end_date column
            billing_periods["billing_cycle_end_date"] = pd.to_datetime(
                billing_periods["billing_cycle_end_date"], errors="coerce"
            )
            billing_periods["billing_cycle_end_date"] = billing_periods[
                "billing_cycle_end_date"
            ].apply(
                lambda date: (
                    (date - pd.Timedelta(days=1)).replace(hour=23, minute=59, second=59)
                    if pd.notna(date) and date.time() == pd.Timestamp("00:00:00").time()
                    else date
                )
            )

            # Filter out rows with NaT in billing_cycle_end_date
            billing_periods = billing_periods.dropna(subset=["billing_cycle_end_date"])

            # Initialize a list to hold the formatted billing periods
            formatted_billing_periods = []
            for period in billing_periods.to_dict(orient="records"):
                formatted_period = {
                    "id": period["id"],
                    "billing_period_start_date": format_timestamp(
                        period["billing_cycle_start_date"]
                    ),
                    "billing_period_end_date": format_timestamp(
                        period["billing_cycle_end_date"]
                    ),
                }
                formatted_billing_periods.append(formatted_period)

            # Add the service provider's ID, customer list, and formatted
            # billing periods to the dictionary
            service_provider_customers[service_provider_name] = {
                "id": service_provider_id,
                "customers": customer_list,
            }
            service_provider_billing_periods[service_provider_name] = (
                formatted_billing_periods
            )

        # Prepare the response
        response = {
            "flag": True,
            "service_provider_customers": service_provider_customers,
            "service_provider_billing_periods": service_provider_billing_periods,
        }
        return response

    except Exception as e:
        logging.exception(f"Exception occurred while fetching the data: {e}")
        message = f"Exception: {e}"
        # Prepare the response in case of an exception
        response = {
            "flag": False,
            "service_provider_customers": {},
            "service_provider_billing_periods": {},
            "message": message,
        }
        return response


def format_timestamp(ts):
    # Check if the timestamp is not None
    if ts is not None and pd.notna(ts):
        # Convert a Timestamp or datetime object to the desired string format
        return ts.strftime("%b %d, %Y, %I:%M %p")
    else:
        # Return a placeholder or empty string if the timestamp is None
        return "N/A"


##to get the pop up details in the optimize button
def get_optimization_pop_up_data(data):
    logging.info(f"Request Data in recieved in get_optimization_pop_up_data")
    ##database connection
    tenant_database = data.get("db_name", "")
    # database Connection
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    ServiceProviderId = data.get("ServiceProviderId", "")
    try:
        optimization_type = data.get("optimization_type", "")

        if optimization_type == "Customer":
            """Rate Plan Count"""
            try:
                # Call function to get rate plans count by customer
                results = rate_plans_by_customer_count(
                    data, database, common_utils_database
                )
                rate_plan_count = int(
                    results[0][0]
                )  # Ensure conversion to standard int
            except Exception as e:
                logging.exception("rate_plan_count", e)
                rate_plan_count = 0
            logging.info(f"rate_plan_count is {rate_plan_count}")

            """Sim cards to Optimize"""
            try:
                # Call function to get SIM cards to optimize
                sim_cards_to_optimize = sim_cards_to_optimize_count(
                    data, database, common_utils_database
                )
                if sim_cards_to_optimize is None:
                    sim_cards_to_optimize = 0
                sim_cards_to_optimize = int(
                    sim_cards_to_optimize
                )  # Ensure conversion to standard int
            except Exception as e:
                logging.warning("sim_cards_to_optimize", e)
                sim_cards_to_optimize = 0

            """Total Sim cards"""
            rev_customer_id = str(data.get("customer_id", ""))
            total_sim_cards_count = int(
                get_customer_total_sim_cards_count(rev_customer_id, database)
            )  # Ensure conversion to standard int

            response = {
                "flag": True,
                "rate_plan_count": rate_plan_count,
                "sim_cards_to_optimize": sim_cards_to_optimize,
                "total_sim_cards_count": total_sim_cards_count,
            }
            return response

        else:
            """Rate Plan Count"""
            params = [ServiceProviderId]
            logging.info(ServiceProviderId, "ServiceProviderId")
            rate_plan_count_query = """SELECT count(*) FROM public.carrier_rate_plan
            where service_provider_id=%s
            """
            rate_plan_count = int(
                database.execute_query(rate_plan_count_query, params=params).iloc[0, 0]
            )  # Ensure conversion to standard int
            logging.info(rate_plan_count, "rate_plan_count")

            """Sim cards to Optimize"""
            try:
                sim_cards_to_optimize = sim_cards_to_optimize_count(
                    data, database, common_utils_database
                )
                if sim_cards_to_optimize is None:
                    sim_cards_to_optimize = 0
                sim_cards_to_optimize = int(
                    sim_cards_to_optimize
                )  # Ensure conversion to standard int
            except Exception as e:
                logging.exception("sim_cards_to_optimize", e)
                sim_cards_to_optimize = 0

            """Total Sim cards"""
            params = [ServiceProviderId]
            total_sim_cards_count_query = """SELECT count(*) FROM public.sim_management_inventory
              where service_provider_id=%s
              """
            total_sim_cards_count = int(
                database.execute_query(total_sim_cards_count_query, params=params).iloc[
                    0, 0
                ]
            )  # Ensure conversion to standard int

            response = {
                "flag": True,
                "rate_plan_count": rate_plan_count,
                "sim_cards_to_optimize": sim_cards_to_optimize,
                "total_sim_cards_count": total_sim_cards_count,
            }
            return response

    except Exception as e:
        logging.exception("Error in connection or execution:", e)


def start_optimization(data):
    """
    The start_optimization function initiates an optimization process
    by sending a POST request with tenant and user-specific details to
    1.0 Controller. It retrieves the tenant ID from the database, sets
    necessary headers, and sends the request body as JSON, returning the
    API's response or error details in case of failure.
    """
    logging.info(f"Request Data Received")
    # Start time  and date calculation
    start_time = time.time()
    database = DB("altaworx_test", **db_config)
    common_utils_database = DB("common_utils", **db_config)
    template = data.get("template", "")
    request_received_at = data.get("request_received_at", "")
    role = data.get("role_name", "")
    body = data.get("body", {})
    ui_session_id = data.get("sessionID", "")
    try:
        if body.get("optimizationType") == 1:
            optimization_mail = database.get_data(
                "optimization_setting", {}, ["customer_optimization_to_email_address"]
            )["customer_optimization_to_email_address"].to_list()[0]
        else:
            optimization_mail = database.get_data(
                "optimization_setting", {}, ["carrier_optimization_to_email_address"]
            )["carrier_optimization_to_email_address"].to_list()[0]
        common_utils_database.update_dict(
            "email_templates",
            {"body": template},
            {"template_name": "Start Optimization"},
        )
        try:
            common_utils_database.update_dict(
                "email_templates",
                {
                    "last_email_triggered_at": request_received_at,
                    "to_mail": optimization_mail,
                },
                {"template_name": "Start Optimization"},
            )
            # Call send_email and assign the result to 'result'
            result = send_email("Start Optimization", user_mail=optimization_mail)
            # Check the result and handle accordingly
            if isinstance(result, dict) and result.get("flag") is False:
                logging.info(result)
            else:
                # Continue with other logic if needed
                (
                    to_emails,
                    cc_emails,
                    subject,
                    bodyy,
                    from_email,
                    partner_name,
                ) = result
                common_utils_database.update_dict(
                    "email_templates",
                    {"last_email_triggered_at": request_received_at},
                    {"template_name": "Start Optimization"},
                )
                query = """
                    SELECT parents_module_name, sub_module_name,
                        child_module_name, partner_name
                    FROM email_templates
                    WHERE template_name = %s
                """

                params = ["Start Optimization"]
                # Execute the query with template_name as the parameter
                email_template_data = common_utils_database.execute_query(
                    query, params=params
                )
                if not email_template_data.empty:
                    # Unpack the results
                    (
                        parents_module_name,
                        sub_module_name,
                        child_module_name,
                        partner_name,
                    ) = email_template_data.iloc[0]
                else:
                    # If no data is found, assign default values or log an error
                    parents_module_name = ""
                    sub_module_name = ""
                    child_module_name = ""
                    partner_name = ""

                try:
                    ##email audit
                    email_audit_data = {
                        "template_name": "Start Optimization",
                        "email_type": "Application",
                        "partner_name": partner_name,
                        "email_status": "success",
                        "from_email": from_email,
                        "to_email": to_emails,
                        "cc_email": cc_emails,
                        "comments": "update inventory data",
                        "subject": subject,
                        "body": bodyy,
                        "role": role,
                        "action": "Email triggered",
                        "parents_module_name": parents_module_name,
                        "sub_module_name": sub_module_name,
                        "child_module_name": child_module_name,
                    }
                    common_utils_database.update_audit(email_audit_data, "email_audit")
                except Exception as e:
                    logging.error(f"Failed to update the email audit table")
        except Exception as e:
            logging.warning(f"Failed to send the email")
    except Exception as e:
        logging.warning(
            f"Failed to get the optimization data from settings and  failed to trigger the mail{e}"
        )
    try:
        body = data.get("body", {})
        print(body, "bodybodybodybodybodybodybodybody")
        # Check if optimizationType is 1, then replace the siteId as described
        if body.get("optimizationType") == 1 and body.get("siteId") != 0:
            site_id_from_params = body.get("siteId")

            # Database Connection to fetch rev_status
            # common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
            rev_status = common_utils_database.get_data(
                "tenant_module", {"module_name": "Rev.IO"}, ["is_active"]
            )["is_active"].to_list()[0]

            if rev_status:  # If Rev.IO module is active
                # Execute the queries to get the new siteId
                rev_io_query = """
                    SELECT id FROM public.integration
                    WHERE name='Rev.IO'
                """
                rev_io_id = database.execute_query(rev_io_query, True)["id"].to_list()[
                    0
                ]

                integration_authentication_id_query = f"""
                    SELECT id FROM public.integration_authentication
                    WHERE integration_id={rev_io_id} AND tenant_id=1 AND is_active=True
                """
                integration_authentication_id = database.execute_query(
                    integration_authentication_id_query, True
                )["id"].to_list()[0]

                site_id_query = f"""
                    SELECT c.id FROM public.revcustomer rc
                    JOIN customers c ON rc.id=c.rev_customer_id
                    WHERE rc.rev_customer_id='{site_id_from_params}'
                    AND rc.is_active=True AND rc.tenant_id=1
                    AND rc.integration_authentication_id={integration_authentication_id}
                """
                siteId = database.execute_query(site_id_query, True)["id"].to_list()[0]

                # Replace the siteId in the body with the new value
                body["siteId"] = siteId
                logging.info(f"Updated siteId to {siteId}")

        # If siteId is 0, set it to 'null' as before
        if body["siteId"] == 0:
            body["siteId"] = "null"

        # Take the first item in the serviceProviderId list if it exists
        if (
            "serviceProviderId" in body
            and isinstance(body["serviceProviderId"], list)
            and body["serviceProviderId"]
        ):
            body["serviceProviderId"] = body["serviceProviderId"][0]

        username = data.get("username", "")
        tenant_name = data.get("tenant_name", "")
        logging.info(f"body of the start optimization is :{body}")
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": "Altaworx"}, ["id"]
        )["id"].to_list()[0]
        tenant_id = str(tenant_id)
        url = os.getenv("OPTIMIZATIONAPI", " ")
        username = "amop-core"
        password = "uDLD4AK3vOnqAjpn2DVRhwlrcbTLB6EY"
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode("utf-8")).decode(
            "utf-8"
        )
        authorization_header = f"Basic {encoded_credentials}"

        # Define the headers
        headers = {
            "Authorization": authorization_header,
            "user-name": "lohitha.v@algonox.com",
            "x-tenant-id": tenant_id,
            "Content-Type": "application/json",  # Specify content type for JSON
        }
        # Send the POST request
        response = requests.post(url, headers=headers, data=json.dumps(body))
        response_data = {
            "flag": True,
            "status code": response.status_code,
            "message": response.json(),
        }
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "Optimization",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response_data["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": "Optimization Run started",
                "module_name": "Start Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"Exception is {e}")

        # Return the status code and response JSON
        return response_data

    except Exception as e:
        logging.exception(f"Error fetching data: {e}")
        message = f"exception is {e}"
        response_data = {"flag": False, "message": message}
        # Return the status code and response JSON
        return response_data


def rate_plans_by_customer_count(data, database, common_utils_database):
    """
    The rate_plans_by_customer_count function retrieves customer rate plan
    counts by executing stored procedures based on the portal type (portal_id)
    and other input parameters like ServiceProviderId, BillingPeriodId, and tenant_name.
    It dynamically determines customer IDs (RevCustomerIds or AMOPCustomerIds), connects
    to a database, and processes data through specific stored procedures.
    The function handles different portal types and logs errors if exceptions occur.
    """
    logging.info(f"Request Data Recieved")
    ServiceProviderId = data.get("ServiceProviderId", "")
    BillingPeriodId = data.get("BillingPeriodId", "")
    tenant_name = data.get("tenant_name", "")
    TenantId = common_utils_database.get_data(
        "tenant", {"tenant_name": "Altaworx"}, ["id"]
    )["id"].to_list()[0]
    customer_name = data.get("customer_name", "")
    # Fetch integration_id and portal_id using database queries
    integration_id = database.get_data(
        "serviceprovider", {"id": ServiceProviderId}, ["integration_id"]
    )["integration_id"].to_list()[0]
    portal_id = database.get_data(
        "integration", {"id": integration_id}, ["portal_type_id"]
    )["portal_type_id"].to_list()[0]
    # If portal_id is 0, proceed with M2M connection and stored procedure execution
    if portal_id == 0:
        # Define database connection parameters
        server = "altaworx-test.cd98i7zb3ml3.us-east-1.rds.amazonaws.com"
        database_name = "AltaworxCentral_Test"
        username = "ALGONOX-Vyshnavi"
        password = "cs!Vtqe49gM32FDi"
        rev_customer_data = database.get_data(
            "customers", {"customer_name": customer_name}, ["rev_customer_id"]
        )["rev_customer_id"].to_list()
        # Check if rev_customer_id data is available
        if rev_customer_data:
            RevCustomerIds = ",".join([str(id) for id in rev_customer_data])
            AMOPCustomerIds = ""
            SiteType = 1
        else:
            # If rev_customer_id is None or empty, get customer_id data
            AMOPCustomerIds = ",".join(
                [
                    str(id)
                    for id in database.get_data(
                        "customers", {"customer_name": customer_name}, ["customer_id"]
                    )["customer_id"].to_list()
                ]
            )
            RevCustomerIds = ""
            SiteType = 0
        # Try connecting to the database and executing the stored procedure
        try:
            with pytds.connect(
                server=server, database=database_name, user=username, password=password
            ) as conn:
                with conn.cursor() as cursor:
                    # Define the stored procedure name
                    stored_procedure_name = "AltaworxCentral_Test.dbo.usp_OptimizationRatePlansByCustomerCount"

                    # Execute the stored procedure
                    cursor.callproc(
                        stored_procedure_name,
                        (
                            RevCustomerIds,
                            ServiceProviderId,
                            TenantId,
                            SiteType,
                            AMOPCustomerIds,
                            BillingPeriodId,
                        ),
                    )

                    # Fetch and return the results
                    results = cursor.fetchall()
                    return results

        except Exception as e:
            logging.exception("Error in connection or execution:", e)
            return None
    elif portal_id == 2:
        # Define database connection parameters
        server = "altaworx-test.cd98i7zb3ml3.us-east-1.rds.amazonaws.com"
        database_name = "AltaworxCentral_Test"
        username = "ALGONOX-Vyshnavi"
        password = "cs!Vtqe49gM32FDi"
        rev_customer_data = database.get_data(
            "customers", {"customer_name": customer_name}, ["rev_customer_id"]
        )["rev_customer_id"].to_list()
        # working for mobility rate plan count
        # Define your connection parameters
        with pytds.connect(
            server=server, database=database, user=username, password=password
        ) as conn:
            with conn.cursor() as cursor:
                stored_procedure_name = (
                    "dbo.usp_OptimizationMobilityRatePlansByCustomerCount"
                )
                # Check if rev_customer_id data is available
                if rev_customer_data:
                    RevCustomerIds = ",".join([str(id) for id in rev_customer_data])
                    AMOPCustomerIds = ""
                    SiteType = 1
                else:
                    # If rev_customer_id is None or empty, get customer_id data
                    AMOPCustomerIds = ",".join(
                        [
                            str(id)
                            for id in database.get_data(
                                "customers",
                                {"customer_name": customer_name},
                                ["customer_id"],
                            )["customer_id"].to_list()
                        ]
                    )
                    RevCustomerIds = ""
                    SiteType = 0
                output_param = pytds.output(value=None, param_type=int)
                return_value = cursor.callproc(
                    stored_procedure_name,
                    (
                        RevCustomerIds,
                        ServiceProviderId,
                        TenantId,
                        SiteType,
                        AMOPCustomerIds,
                        BillingPeriodId,
                        output_param,
                    ),
                )  # Placeholder for output parameter
                output_value = return_value[-1]
                return output_value


def sim_cards_to_optimize_count(data, database, common_utils_database):
    """
    The sim_cards_to_optimize_count function calculates the number of
    SIM cards eligible for optimization based on the provided filters
    like ServiceProviderId, BillingPeriodId, tenant_name, and optimization_type.
    It retrieves the relevant data by executing a stored procedure on a remote database,
    either summing up SIM card counts across customers or targeting a specific customer.
    Errors are logged if database connection or execution fails.
    """
    logging.info(f"Request Data Recieved")
    ServiceProviderIds = data.get("ServiceProviderId", "")
    query = f"select id from serviceprovider where id={ServiceProviderIds}"
    ServiceProviderId = database.execute_query(query, True)["id"].to_list()[0]
    logging.info(f"ServiceProviderId is {ServiceProviderId}")
    BillingPeriodId = data.get("BillingPeriodId", "")
    customer_name = data.get("customer_name", "")
    tenant_name = data.get("tenant_name", "")
    TenantId = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id"]
    )["id"].to_list()[0]
    optimization_type = data.get("optimization_type", "")
    # Define your connection parameters
    server = "altaworx-test.cd98i7zb3ml3.us-east-1.rds.amazonaws.com"
    database = "AltaworxCentral_Test"
    username = "ALGONOX-Vyshnavi"
    password = "cs!Vtqe49gM32FDi"
    sim_cards_to_optimize = 0  # Ensure default initialization
    if optimization_type == "Customer":
        # customer_name='Easy Shop Supermarket (300007343)'
        # Create a connection to the database
        try:
            with pytds.connect(
                server=server, database=database, user=username, password=password
            ) as conn:
                with conn.cursor() as cursor:
                    # Define the stored procedure name
                    stored_procedure_name = (
                        "AltaworxCentral_Test.dbo.[usp_OptimizationCustomersGet]"
                    )
                    # Optional: Define any parameters to pass to the stored procedure
                    # RevCustomerIds = '6B32A900-5E87-4BBD-BD53-28BD86FD6192,
                    # 94F8BE71-ACCC-47EB-A0DF-78D3AAF093FA
                    # ,95599FFC-6F67-40AC-8518-D180B929C430,45519C0F-BFC4-4CB4-8468-F4420E9AE0CC'
                    # ServiceProviderId = 1
                    # TenantId = 1
                    # # SiteType = 1
                    # # AMOPCustomerIds = ''
                    # BillingPeriodId = 412
                    # Execute the stored procedure
                    cursor.callproc(
                        stored_procedure_name,
                        (ServiceProviderId, TenantId, BillingPeriodId),
                    )

                    # Fetch results if the stored procedure returns any
                    results = cursor.fetchall()
                    for row in results:
                        if row[1] == customer_name:
                            sim_cards_to_optimize = row[-1]
                            break
                    return sim_cards_to_optimize

        except Exception as e:
            logging.exception("Error in connection or execution:", e)
    else:
        # Create a connection to the database
        try:
            with pytds.connect(
                server=server, database=database, user=username, password=password
            ) as conn:
                with conn.cursor() as cursor:
                    # Define the stored procedure name
                    stored_procedure_name = (
                        "AltaworxCentral_Test.dbo.[usp_OptimizationCustomersGet]"
                    )
                    # Optional: Define any parameters to pass to the stored procedure
                    # RevCustomerIds = '6B32A900-5E87-4BBD-BD53-28BD86FD6192
                    # ,94F8BE71-ACCC-47EB-A0DF-78D3AAF093FA,95599FFC-6F67-40AC-8518-D180B929C430,
                    # 45519C0F-BFC4-4CB4-8468-F4420E9AE0CC'
                    # ServiceProviderId = 1
                    # TenantId = 1
                    # # SiteType = 1
                    # # AMOPCustomerIds = ''
                    # BillingPeriodId = 412
                    # Execute the stored procedure
                    cursor.callproc(
                        stored_procedure_name,
                        (ServiceProviderId, TenantId, BillingPeriodId),
                    )
                    # sim_cards_to_optimize = 0
                    # Fetch results if the stored procedure returns any
                    results = cursor.fetchall()
                    for row in results:
                        last_item = row[-1]
                        sim_cards_to_optimize += last_item

                    return sim_cards_to_optimize

        except Exception as e:
            logging.exception("Error in connection or execution:", e)


def get_customer_total_sim_cards_count(rev_customer_id, database):
    """
    The get_customer_total_sim_cards_count function calculates the total number
    of SIM cards associated with a specific rev_customer_id. It retrieves the
    related customer IDs from the customers table and then counts the
    corresponding SIM cards in the sim_management_inventory table.
    The function uses dynamic SQL queries and handles exceptions by
    logging errors if any issues arise during execution.
    """
    logging.info(f"Request Data Recieved")
    try:
        # database = DB('altaworx_central', **db_config)
        rev_customer_ids = database.get_data(
            "revcustomer", {"rev_customer_id": rev_customer_id}, ["id"]
        )["id"].to_list()
        customer_ids_query = f"""
                SELECT id FROM customers
                WHERE rev_customer_id IN ({', '.join(f"'{id}'" for id in rev_customer_ids)})
                """

        # Step 4: Execute the query to get the customer IDs
        customer_ids_dataframe = database.execute_query(customer_ids_query, True)
        # Step 5: Extract customer IDs from the DataFrame
        customer_ids = customer_ids_dataframe["id"].tolist()

        # Step 6: Query to count records in sim_management_inventory based on customer IDs
        if customer_ids:  # Check if there are any customer IDs
            customer_ids_tuple = ", ".join(
                map(str, customer_ids)
            )  # Convert list to tuple string for SQL
            count_query = f"""
            SELECT count(*) FROM public.sim_management_inventory
            WHERE customer_id IN ({customer_ids_tuple})
            """

            # Step 7: Execute the count query
            final_count = database.execute_query(count_query, True)
            count_value = final_count["count"][
                0
            ]  # Assuming the result is returned as a DataFrame
        return count_value
    except Exception as e:
        logging.exception(f"Exception is {e}")


##second point
def get_optimization_row_details(data):
    """
    The get_optimization_row_details function retrieves and paginates
    optimization data for a given session, fetching high-usage customer
    details and/or error-related records based on the fetch_type.
    It dynamically constructs queries, supports pagination, and handles
    errors gracefully, returning structured responses with total counts and data.
    """
    session_id = data.get("session_id")
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    # Pagination parameters
    start = data.get("start", 0)
    end = data.get("end", 10)  # Default to 10 if no end parameter provided
    limit = 10
    params = [start, limit]
    pages = {"start": start, "end": end}
    total_count = 0
    error_details_count = 0
    high_usage_customers_data = []
    error_details = []
    optimization_type = data.get("optimization_type", "")
    if optimization_type == "Customer":
        error_view = "vw_optimization_error_details_customer"
    else:
        error_view = "vw_optimization_error_details_carrier"

    try:
        count_params = [session_id]
        # Query to get instance IDs
        try:
            instance_ids_query = f"""
                SELECT instance_id
                FROM
                    public.vw_optimization_high_usage_customers
                WHERE
                    session_id = '{session_id}'
            """
            instance_ids = database.execute_query(instance_ids_query, True)[
                "instance_id"
            ].to_list()
        except Exception as e:
            instance_ids = (
                []
            )  # If the instance IDs query fails, we'll set it to an empty list
            logging.exception(f"Exception is: {e}")

        # Check if we're fetching high usage customers, error details, or both
        fetch_type = data.get("fetch_type", "both")  # Default to 'both'

        if fetch_type == "both" or fetch_type == "high_usage":
            # Count query to get total count of high usage customers
            count_query = f"""
                SELECT COUNT(customer_name)
                FROM public.vw_optimization_high_usage_customers
                WHERE  session_id = '{session_id}'
            """

            total_count = database.execute_query(count_query, count_params).iloc[0, 0]

            # Query for high usage customers
            query = f"""
                SELECT instance_id,
                customer_name,rev_customer_id,sms_charge_total,
                device_count,
                TO_CHAR(total_charges, 'FM$999,999,999,999.00') AS total_charges,
                TO_CHAR(total_charge_amount, 'FM$999,999,999,999.00') AS total_charge_amount
            FROM
                public.vw_optimization_high_usage_customers
            WHERE
                session_id = '{session_id}'
            ORDER BY CAST(total_charge_amount AS NUMERIC) DESC NULLS LAST
                OFFSET %s LIMIT %s;
            """

            high_usage_customers_data = database.execute_query(
                query, params=params
            ).to_dict(orient="records")

            # Add total count to the pages dictionary for pagination
            pages["high_usage_total"] = int(total_count)

        if fetch_type == "both" or fetch_type == "error_details":
            # Count query to get total count of error details
            error_details_count_query = f"""
                select count(*) from {error_view} where session_id='{session_id}' and error_message is not null

            """

            error_details_count = database.execute_query(
                error_details_count_query, True
            ).iloc[0, 0]

            # Error details query
            error_details_query = f"""
                select rev_customer_id,iccid,msisdn,customer_name,
                error_message from {error_view} where session_id='{session_id}' and error_message is not null
                offset %s limit %s
            """

            error_details = database.execute_query(
                error_details_query, params=params
            ).to_dict(orient="records")

            # Add total count to the pages dictionary for pagination
            pages["error_details_total"] = int(error_details_count)

        # Build response
        response = {"flag": True, "pages": pages, "instance_ids": instance_ids}

        if fetch_type == "both" or fetch_type == "high_usage":
            response["high_usage_customers_data"] = high_usage_customers_data
        if fetch_type == "both" or fetch_type == "error_details":
            response["error_details"] = error_details

        return response

    except Exception as e:
        # Handle any exceptions and provide default empty data
        response = {
            "flag": False,
            "high_usage_customers_data": [],
            "error_details": [],
            "pages": pages,
            "instance_ids": [],
            "error_message": str(e),
        }
        return response


def generate_report_to_excel(
    report_name, query, database, optimization_type, session_id
):
    """Function to execute query and generate Excel data"""
    acronyms = {
        "SMS",
        "IMEI",
        "IP",
        "BAN",
        "URL",
        "UID",
        "MAC",
        "EID",
        "MSISDN",
        "MB",
        "CCID",
        "ICCID",
        "SIM",
    }
    special_replacements = {"Att": "AT&T", "And": "and", "mb": "MB"}
    # Execute the main query to fetch data
    df = database.execute_query(query, True)
    # # Format column names
    # df.columns = [
    #     " ".join(
    #         part.upper() if part.upper() in acronyms else part.capitalize()
    #         for part in col.split("_")
    #     )
    #     for col in df.columns
    # ]

    # # Apply special replacements (e.g., Att -> AT&T, And -> and)
    # df.columns = [
    #     " ".join([special_replacements.get(word, word) for word in col.split(" ")])
    #     for col in df.columns
    # ]
    df.columns = [
        " ".join(
            part.upper() if part.upper() in acronyms else part.capitalize()
            for part in col.replace("_", " ").split(
                " "
            )  # Replace underscores and split
        )
        for col in df.columns
    ]

    # Apply any special replacements
    df.columns = [
        " ".join([special_replacements.get(word, word) for word in col.split(" ")])
        for col in df.columns
    ]

    # Handle NaN values, numeric types, and date formatting
    def format_value(val):
        if pd.isna(val):
            return ""  # Replace NaN with empty string
        if isinstance(val, (int, float)):
            return val  # Numeric values should remain as numeric types
        if isinstance(val, pd.Timestamp):
            return val.strftime(
                "%Y-%m-%d %H:%M:%S"
            )  # Format date columns as YYYY-MM-DD
        return str(val)  # For all other values, convert to string

    # Apply formatting to all values in the dataframe
    df = df.applymap(format_value)

    # Function to truncate to two decimals
    def truncate_to_two_decimals(value):
        try:
            # Remove commas, convert to float, truncate to 2 decimals
            value = float(str(value).replace(",", ""))
            return f"{int(value * 100) / 100:.2f}"
        except (ValueError, TypeError):
            return "0.00"  # Default for invalid entries

    # Check if the DataFrame is empty
    if df.empty:
        excel_buffer = io.BytesIO()
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            empty_df = pd.DataFrame(columns=df.columns)
            empty_df.to_excel(writer, index=False, sheet_name="Empty Report")
        return excel_buffer.getvalue()

    # Handle specific reports
    if (
        report_name == "Device Assignments By Customer Report"
        and optimization_type == "Customer"
    ):
        binary_query = """
            SELECT r.results_id, r.customer_name, r.rev_customer_id as customer_account_number, f.assignment_xlsx_bytes
            FROM public.vw_optimization_instance r
            JOIN optimization_instance_result_file f ON r.results_id = f.id
            WHERE r.session_id = %s
        """
        params = [session_id]
        customer_report_data = database.execute_query(binary_query, params=params)

        excel_buffer = io.BytesIO()

        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            sheet_created = False  # Track if at least one sheet is created

            # Iterate through customer report data
            for _, row in customer_report_data.iterrows():
                assignment_xlsx_binary = row["assignment_xlsx_bytes"]
                customer_name = row["customer_name"]
                customer_account_number = row["customer_account_number"]

                if assignment_xlsx_binary:
                    assignment_file = io.BytesIO(assignment_xlsx_binary)
                    assignment_df = pd.read_excel(assignment_file)
                    assignment_df = assignment_df.loc[
                        :, ~assignment_df.columns.str.contains("^Unnamed")
                    ]
                    assignment_df.columns = assignment_df.columns.str.replace(
                        r"\.\d+$", "", regex=True
                    )
                    # Clean up column names
                    assignment_df.columns = (
                        assignment_df.columns.str.strip()
                        .str.lower()
                        .str.replace(" ", "_")
                    )
                    df.columns = (
                        df.columns.str.strip().str.lower().str.replace(" ", "_")
                    )
                    try:
                        # Define columns to merge
                        columns_to_merge = ["iccid", "usage_cost"]

                        # Merge assignment_df with df on 'iccid' and 'usage_cost'
                        assignment_df = assignment_df.merge(
                            df[columns_to_merge],
                            on="iccid",
                            how="left",
                            suffixes=(
                                "",
                                "_y",
                            ),  # Add suffix to avoid column name clashes
                        )

                        # Drop any duplicate columns that may have been created during the merge
                        assignment_df = assignment_df.loc[
                            :, ~assignment_df.columns.str.endswith("_y")
                        ]

                        # Check if 'usage_cost' exists and handle accordingly
                        if "usage_cost" in assignment_df.columns:
                            # Convert 'Usage Cost' to numeric and apply formatting
                            assignment_df["usage_cost"] = (
                                assignment_df["usage_cost"]
                                .replace(r"[$,]", "", regex=True)
                                .astype(float)
                            )
                            # assignment_df["Usage Cost"] = assignment_df["usage_cost"].apply(lambda x: f"${x:.2f}" if not pd.isnull(x) else "$.00")
                        # Apply truncation and formatting to float columns (if any)
                    except Exception as e:
                        logging.exception(f"Error in merging dataframes: {e}")
                    columns_to_format = [
                        "usage_cost",
                        "cycle_data_usage(mb)",
                        "average_usage(mb)",
                        "average_cost",
                        "total_usage",
                        "total_cost",
                    ]
                    for col in columns_to_format:
                        if col in assignment_df.columns:
                            # Apply truncation only to rows with valid numeric values
                            assignment_df[col] = assignment_df[col].apply(
                                lambda x: (
                                    truncate_to_two_decimals(x)
                                    if isinstance(x, (int, float)) and not pd.isna(x)
                                    else x
                                )
                            )

                    # Apply formatting to all values in the dataframe
                    assignment_df = assignment_df.applymap(
                        lambda val: (
                            format_value(val)
                            if not isinstance(val, (int, float))
                            else val
                        )
                    )

                    # assignment_df = assignment_df.applymap(lambda val: format_value(val) if not isinstance(val, (int, float)) else val)
                    # Format column names
                    assignment_df.columns = [
                        " ".join(
                            (
                                part.upper()
                                if part.upper() in acronyms
                                else part.capitalize()
                            )
                            for part in col.replace("_", " ").split(
                                " "
                            )  # Replace underscores and split
                        )
                        for col in assignment_df.columns
                    ]

                    # Apply any special replacements
                    assignment_df.columns = [
                        " ".join(
                            [
                                special_replacements.get(word, word)
                                for word in col.split(" ")
                            ]
                        )
                        for col in assignment_df.columns
                    ]
                    # assignment_df.columns = [
                    #     " ".join(
                    #         part.upper() if part.upper() in acronyms else part.capitalize()
                    #         for part in col.split("_")
                    #     )
                    #     for col in assignment_df.columns
                    # ]

                    # # Apply special replacements (e.g., Att -> AT&T, And -> and)
                    # assignment_df.columns = [
                    #     " ".join([special_replacements.get(word, word) for word in col.split(" ")])
                    #     for col in assignment_df.columns
                    # ]
                    # Replace NaN with empty strings immediately after reading
                    assignment_df = assignment_df.applymap(format_value)
                    # Specify the index of the column to format (5th column has index 4 in zero-based indexing)

                    # Add customer-specific columns
                    assignment_df.insert(0, "Customer Name", customer_name)
                    assignment_df.insert(
                        1, "Customer Account Number", customer_account_number
                    )

                    # Adjust the DataFrame to show 'Customer Name' and 'Customer Account Number' only once per group
                    assignment_df.loc[1:, "Customer Name"] = ""
                    assignment_df.loc[1:, "Customer Account Number"] = ""
                    try:
                        # Split the DataFrame into two parts: before and after the 12th column (index 11)
                        part1 = assignment_df.iloc[
                            :, :6
                        ]  # Columns before the 12th position
                        part2 = assignment_df.iloc[
                            :, 6:
                        ]  # Columns after the 12th position
                        # Drop 'Usage Cost' column only if it exists
                        if "Usage Cost" in part2.columns:
                            part2 = part2.drop(columns=["Usage Cost"])

                        # Concatenate the parts together with 'Usage Cost' in the middle
                        assignment_df = pd.concat(
                            [part1, assignment_df[["Usage Cost"]], part2], axis=1
                        )
                    except Exception as e:
                        logging.exception(f"Error in splitting DataFrame: {e}")

                    if "Cycle Data Usage(mb)" in assignment_df.columns:
                        # Apply truncation only to rows with valid numeric values
                        assignment_df["Cycle Data Usage(mb)"] = (
                            assignment_df["Cycle Data Usage(mb)"]
                            .replace({",": ""}, regex=True)  # Remove commas if present
                            .replace(
                                {"": None}
                            )  # Replace empty strings with None (which will become NaN)
                            .astype(float)  # Convert to float
                            .apply(
                                lambda x: int(x * 100) / 100.0 if pd.notna(x) else x
                            )  # Truncate to 2 decimal places
                            .apply(
                                lambda x: f"{x:.2f}" if pd.notna(x) else x
                            )  # Format as string with 2 decimals (e.g., '0.00')
                        )
                    if "Usage Cost" in assignment_df.columns:
                        # Add $ symbol to numeric values
                        assignment_df["Usage Cost"] = assignment_df["Usage Cost"].apply(
                            lambda x: (
                                f"${x}" if str(x).replace(".", "", 1).isdigit() else x
                            )
                        )
                    # Use a sanitized sheet name
                    sanitized_sheet_name = sanitize_sheet_name(
                        customer_name.replace("_", " ")
                    )
                    # Write to the Excel workbook
                    assignment_df.to_excel(
                        writer, index=False, sheet_name=sanitized_sheet_name
                    )
                    sheet_created = True  # Mark that a sheet has been created

            if not sheet_created:
                # Ensure at least one sheet is visible
                empty_df = pd.DataFrame(columns=["No Data"])
                empty_df.to_excel(writer, index=False, sheet_name="Empty Report")

            # Apply formatting to all sheets
            workbook = writer.book
            for sheet_name in workbook.sheetnames:
                sheet = workbook[sheet_name]

                # Adjust column widths
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = (
                        max_length + 2
                    )

                # Ensure consistent number formatting
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    for cell in col_cells:
                        if isinstance(cell.value, (int, float)):
                            cell.number_format = (
                                "0"  # Format as an integer without decimal points
                            )
                        elif isinstance(cell.value, float):
                            cell.number_format = (
                                "0.00"  # Format as float with 2 decimal places
                            )

                # Format header row
                for cell in sheet[1]:
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(
                        start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                    )
                    cell.font = Font(bold=True)

            # Reorder sheets by name in ascending order
            workbook._sheets.sort(key=lambda ws: ws.title)

            # Reorder sheets by name in ascending order
            workbook._sheets.sort(key=lambda ws: ws.title)

        return excel_buffer.getvalue()
    elif report_name == "Device Assignments" and optimization_type == "Carrier":
        carrier_query = """
            SELECT r.results_id, r.customer_name, r.rev_customer_id as customer_account_number, f.assignment_xlsx_bytes
            FROM public.vw_optimization_instance r
            JOIN optimization_instance_result_file f ON r.results_id = f.id
            WHERE r.session_id = %s
        """
        params = [session_id]
        carrier_data = database.execute_query(carrier_query, params=params)

        # Create an Excel buffer
        excel_buffer = io.BytesIO()

        # Check if the query returned any data
        if carrier_data.empty:
            # If no data is available, add a "No Data Available" sheet
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                empty_df = pd.DataFrame(columns=["No Data Available"])
                empty_df.to_excel(writer, index=False, sheet_name="Carrier Report")
            return excel_buffer.getvalue()

        # Process the first row, assuming a single result
        row = carrier_data.iloc[0]
        assignment_xlsx_binary = row.get("assignment_xlsx_bytes")

        if pd.isna(assignment_xlsx_binary) or not assignment_xlsx_binary:
            # If no valid Excel data exists, add a "No Data Available" sheet
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                empty_df = pd.DataFrame(columns=["No Data Available"])
                empty_df.to_excel(writer, index=False, sheet_name="Carrier Report")
            return excel_buffer.getvalue()

        # Process the Excel binary data
        assignment_file = io.BytesIO(assignment_xlsx_binary)
        try:
            assignment_df = pd.read_excel(assignment_file)
        except Exception as e:
            # Handle errors reading the Excel file
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                empty_df = pd.DataFrame(columns=["Error Reading Data"])
                empty_df.to_excel(writer, index=False, sheet_name="Carrier Report")
            return excel_buffer.getvalue()

        # Clean and format the DataFrame
        assignment_df = assignment_df.loc[
            :, ~assignment_df.columns.str.contains("^Unnamed")
        ]
        assignment_df.columns = assignment_df.columns.str.replace(
            r"\.\d+$", "", regex=True
        )
        # assignment_df.columns = [
        #     " ".join(
        #         part.upper() if part.upper() in acronyms else part.capitalize()
        #         for part in col.split("_")
        #     )
        #     for col in assignment_df.columns
        # ]
        # assignment_df.columns = [
        #     " ".join([special_replacements.get(word, word) for word in col.split(" ")])
        #     for col in assignment_df.columns
        # ]
        assignment_df.columns = [
            " ".join(
                part.upper() if part.upper() in acronyms else part.capitalize()
                for part in col.replace("_", " ").split(
                    " "
                )  # Replace underscores and split
            )
            for col in assignment_df.columns
        ]

        # Apply any special replacements
        assignment_df.columns = [
            " ".join([special_replacements.get(word, word) for word in col.split(" ")])
            for col in assignment_df.columns
        ]
        assignment_df.columns = [
            col.replace(" mb", " (MB)").replace(" Mb", " (MB)")
            for col in assignment_df.columns
        ]
        assignment_df = assignment_df.map(format_value)  # Updated to use `map`
        columns_to_format = [
            "Cycle Data Usage(mb)",
            "Average Usage(mb)",
            "Total Usage",
            "Total Cost",
        ]
        # Apply truncation to specified columns
        for col in columns_to_format:
            assignment_df[col] = assignment_df[col].apply(truncate_to_two_decimals)
        # Split the DataFrame at the 13th column (index 12)
        df1 = assignment_df.iloc[:, :11]  # Columns from 0 to 12 (13th column)
        df2 = assignment_df.iloc[:, 11:]  # Columns from 13 to the end
        subtotal_index = df2[
            df2["Rate Plan"].str.contains("Sub-Total", case=False, na=False)
        ].index

        if not subtotal_index.empty:
            subtotal_index = subtotal_index[0]  # Get the first "Sub-Total" row index

            # Remove all rows after the "Sub-Total" row (including the "Sub-Total" row)
            df2 = df2.iloc[: subtotal_index + 1]

            # Replace the "Sub-Total" row with "Grand Total"
            df2.at[subtotal_index, "Rate Plan"] = "Total"
        assignment_df = pd.concat([df1, df2], axis=1)
        # Write the cleaned data to Excel
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            assignment_df.to_excel(writer, index=False, sheet_name="Carrier Report")

            # Format the workbook
            workbook = writer.book
            sheet = workbook.active

            # Format header row
            for cell in sheet[1]:
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.fill = PatternFill(
                    start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                )
                cell.font = Font(bold=True)
            # Ensure consistent number formatting (e.g., remove unnecessary decimal points for whole numbers)
            for col_idx, col_cells in enumerate(sheet.columns, 1):
                for cell in col_cells:
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = (
                            "0"  # Format as an integer without decimal points
                        )
                    elif isinstance(cell.value, float):
                        cell.number_format = (
                            "0.00"  # Format as float with 2 decimal places
                        )

            # Adjust column widths
            for col_idx, col_cells in enumerate(sheet.columns, 1):
                max_length = max(len(str(cell.value or "")) for cell in col_cells)
                sheet.column_dimensions[get_column_letter(col_idx)].width = (
                    max_length + 2
                )

        return excel_buffer.getvalue()
    else:
        # Handle general reports
        excel_buffer = io.BytesIO()
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            # Convert all values to string before writing, while handling NaN, numeric and date
            df = df.applymap(format_value)

            if (
                report_name == "Session Device Assignments Report"
                and optimization_type == "Customer"
            ):
                df.to_excel(writer, index=False, sheet_name="Session Device Assignment")
            else:
                df.to_excel(writer, index=False, sheet_name=report_name)
            workbook = writer.book
            sheet = workbook.active

            for cell in sheet[1]:  # Format header row
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.fill = PatternFill(
                    start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                )
                cell.font = Font(bold=True)

            for col_idx, col_cells in enumerate(
                sheet.columns, 1
            ):  # Adjust column widths
                max_length = max(len(str(cell.value or "")) for cell in col_cells)
                sheet.column_dimensions[get_column_letter(col_idx)].width = (
                    max_length + 2
                )

            # Ensure consistent number formatting (e.g., remove unnecessary decimal points for whole numbers)
            for col_idx, col_cells in enumerate(sheet.columns, 1):
                for cell in col_cells:
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = (
                            "0"  # Format as an integer without decimal points
                        )
                    elif isinstance(cell.value, float):
                        cell.number_format = (
                            "0.00"  # Format as float with 2 decimal places
                        )

        return excel_buffer.getvalue()


def sanitize_sheet_name(name):
    """Sanitize sheet name to remove invalid characters and enforce length limit."""
    invalid_chars = [
        "/",
        "\\",
        "?",
        "*",
        "[",
        "]",
        ":",
        "#",
    ]  # Adding '#' to invalid chars if needed
    # Replace invalid characters with underscore
    for char in invalid_chars:
        name = name.replace(char, "_")
    # Ensure sheet name doesn't exceed 31 characters
    name = name[:31]
    # Replace spaces with underscores for consistency
    name = name.replace(" ", "_")
    # Optionally remove any other unwanted characters
    name = "".join(e for e in name if e.isalnum() or e == "_")
    return name


def get_optimization_details_reports_data(data):
    """
    The get_optimization_details_reports_data function generates various optimization-related
    reports (e.g., client list, device management, charge breakdown) based on a specified report
    type and session ID. It executes queries for each report type, generates corresponding Excel
    files, and zips them.
    """
    report_type = data.get("report_type")
    session_id = data.get("session_id")
    optimization_type = data.get("optimization_type")
    tenant_database = data.get("db_name", "")
    # Normalize pushed_charges and errors to boolean values
    pushed_charges = (
        data.get("pushed_charges", "").lower() == "true"
        if isinstance(data.get("pushed_charges"), str)
        else bool(data.get("pushed_charges"))
    )
    errors = (
        data.get("errors", "").lower() == "true"
        if isinstance(data.get("errors"), str)
        else bool(data.get("errors"))
    )
    db = DB("common_utils", **db_config)
    # Database Connection
    database = DB(tenant_database, **db_config)
    db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": optimization_type},
    )
    # Queries for different report types
    if optimization_type == "Customer":
        # Define the queries and their respective report types
        queries = {
            "optimization_summary_report": f"""
                SELECT session_id,
                       service_provider,
                       run_start_time,
                       run_end_time,
                       device_count,
                       TO_CHAR(TRUNC(total_cost, 2), 'FM$999,999,999,999.00') AS total_charges,
                       TO_CHAR(TRUNC(total_charge_amount, 2), 'FM$999,999,999,999.00') AS charges_pushing_from_amop,
                       rev_customer_id,
                       customer_name,
                       billing_period_start_date,
                       billing_period_end_date,
                       run_status
                FROM public.vw_optimization_instance_summary
                WHERE session_id = '{session_id}'
            """,
            "device_assignments_by_customer_report": f"""
                SELECT customer_name,
                    iccid,service_provider,
                    customer_pool,
                    carrier_rate_plan,
                    cycle_data_usage_mb,
                    TO_CHAR(TRUNC(usage_cost, 2), 'FM$999,999,999,999.00') AS usage_cost,
                    communication_plan,
                    msisdn,
                    uses_proration,
                    date_activated,
                    EXTRACT(DAY FROM (billing_period_end_date - billing_period_start_date))
                    AS billing_period_duration,
                    days_activated_in_billing_period,
                    EXTRACT(DAY FROM (days_in_billing_period)) AS days_in_billing_period,
                    device_count,
                    average_cost,
                    TO_CHAR(total_cost, 'FM$999,999,999,999.00') AS total_cost
                FROM public.vw_optimization_export_device_assignments
                WHERE session_id = '{session_id}'
            """,
            "session_device_assignments_report": f"""
                SELECT customer_name,rev_customer_id as customer_account_number,
                    iccid,service_provider,
                    customer_pool,
                    carrier_rate_plan,
                    TO_CHAR(TRUNC(cycle_data_usage_mb, 2), 'FM$999,999,999,999.00') AS cycle_data_usage_mb,
                    TO_CHAR(TRUNC(usage_cost, 2), 'FM$999,999,999,999.00') AS usage_cost,
                    communication_plan,
                    msisdn,
                    uses_proration,
                    date_activated,
                    EXTRACT(DAY FROM (billing_period_end_date - billing_period_start_date))
                    AS billing_period_duration,
                    days_activated_in_billing_period,
                    EXTRACT(DAY FROM (days_in_billing_period)) AS days_in_billing_period
                FROM public.vw_optimization_export_device_assignments
                WHERE session_id = '{session_id}'
            """,
            "customer_charge_breakdown_report": f"""
                SELECT
                    rev_account_number,
                    customer_name,
                    EXTRACT(DAY FROM (billing_period_end_date - billing_period_start_date))
                    AS billing_period_duration,
                    billing_period_end_date,
                    billing_period_start_date,
                    usage_mb,
                    base_charge_amount,
                    rate_charge_amt,
                    overage_charge_amount,
                    (base_charge_amount+rate_charge_amt+overage_charge_amount)
                    as total_data_charge_amount,
                    is_processed,
                    error_message,
                    iccid,
                    msisdn,
                    sms_usage,
                    sms_charge_amount,
                    total_charge_amount
                FROM
                    public.vw_optimization_smi_result_customer_charge_queue
                WHERE session_id = '{session_id}'
            """,
            "error_breakdown_report": f"""
                select rev_customer_id as rev_account_number,iccid,msisdn,customer_name,
                error_message from vw_optimization_error_details_customer where session_id='{session_id}' and error_message is not null

            """,
        }
    else:
        # Define the queries and their respective report types
        queries = {
            "device_assignments": f"""
                SELECT
                    iccid,service_provider,
                    customer_pool,
                    carrier_rate_plan,
                    TO_CHAR(TRUNC(cycle_data_usage_mb, 2), 'FM$999,999,999,999.00') AS cycle_data_usage_mb,
                    communication_plan,
                    msisdn,
                    uses_proration,
                    date_activated,
                    EXTRACT(DAY FROM (billing_period_end_date - billing_period_start_date))
                    AS billing_period_duration,
                    days_activated_in_billing_period,
                    EXTRACT(DAY FROM (days_in_billing_period)) AS days_in_billing_period,
                    device_count as sim_count,
                    average_cost,
                    total_cost
                FROM public.vw_optimization_export_device_assignments
                WHERE session_id = '{session_id}'
            """,
            "error_breakdown_report": f"""
                select iccid,msisdn,
                error_message from vw_optimization_error_details_carrier where session_id='{session_id}' and error_message is not null

            """,
        }

    # Initialize a buffer for the zip file
    zip_buffer = io.BytesIO()

    try:
        # Process reports sequentially
        if report_type == "All Reports":
            if not pushed_charges:
                print("Removing customer_charge_breakdown_report")
                queries.pop("customer_charge_breakdown_report", None)
            if not errors:
                print("Removing error_breakdown_report")
                queries.pop("error_breakdown_report", None)
            for report_key, query in queries.items():
                # Ensure report_name is assigned here
                report_name = " ".join(
                    word.capitalize() for word in report_key.replace("_", " ").split()
                )
                excel_data = generate_report_to_excel(
                    report_name, query, database, optimization_type, session_id
                )

                # Write the Excel data to the zip file
                with zipfile.ZipFile(zip_buffer, "a", zipfile.ZIP_DEFLATED) as zip_file:
                    zip_file.writestr(f"{report_name}.xlsx", excel_data)
        elif report_type in queries:
            # Ensure report_name is assigned here
            report_name = " ".join(
                word.capitalize() for word in report_type.replace("_", " ").split()
            )
            excel_data = generate_report_to_excel(
                report_name,
                queries[report_type],
                database,
                optimization_type,
                session_id,
            )

            # Write the Excel data to the zip file
            with zipfile.ZipFile(zip_buffer, "a", zipfile.ZIP_DEFLATED) as zip_file:
                zip_file.writestr(f"{report_name}.xlsx", excel_data)

        # Now upload the zip buffer to S3
        file_name = f"optimization_module_uat/{optimization_type}/details/Optimization.zip"  # Adjust file path as necessary
        zip_buffer.seek(0)  # Reset the buffer to the beginning
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=zip_buffer.getvalue(),
            ContentType="application/zip",
        )

        # Generate the download URL
        download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

        # Assuming `db.update_dict` is updating the database with the download URL
        db.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": optimization_type},
        )

        # Return the download URL as the response
        response = {
            "flag": True,
            "file_url": download_url,
        }

        print(f"File successfully uploaded to S3. Download URL: {download_url}")
        return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        db.update_dict(
            "export_status",
            {"status_flag": "Failure", "url": ""},
            {"module_name": optimization_type},
        )
        message = f"Exception is {e}"
        response = {
            "flag": False,
            "file_url": "",  # Return empty URL in case of error,
            "message": message,
        }
        return response


##third point
def get_optimization_push_charges_data(data):
    """
    The get_optimization_push_charges_data function retrieves data for push charges
    based on the provided session ID and pagination parameters (start, end, limit).
    It first counts the total number of rows that match the session ID and then fetches
    the corresponding push charges data. If data exists, it returns the data in a
    paginated format; otherwise, it returns a message indicating no data was found.
    The function also handles errors gracefully by logging exceptions and returning an
    error response with a message.
    """
    session_id = data.get("session_id")
    tenant_database = data.get("db_name", "")
    # database Connection
    database = DB(tenant_database, **db_config)
    start = data.get("start", 0)
    end = data.get("end", 10)  # Default to 10 if no 'end' parameter provided
    limit = 10
    params = [start, end]
    pages = {"start": start, "end": end}
    total_count = 0

    try:
        try:
            instance_ids_query = f"""
            SELECT DISTINCT ON (instance_id)
                        instance_id, iccid
            FROM public.vw_optimization_push_charges_error
            WHERE session_id ='{session_id}'
            """

            # Execute the query and get the result
            instance_ids_data = database.execute_query(instance_ids_query, True)

            # Extract instance_id and iccid into separate lists
            instance_ids = instance_ids_data["instance_id"].to_list()
            iccid_list = instance_ids_data["iccid"].to_list()
        except Exception as e:
            instance_ids = []
            iccid_list = []
        # Query to get the total count of rows
        error_details_count_query = """
           SELECT COUNT(DISTINCT instance_id)
            FROM public.vw_optimization_push_charges_error
            WHERE session_id = %s;
        """
        total_count_result = database.execute_query(
            error_details_count_query, params=[session_id]
        ).iloc[0, 0]
        pages["total_count"] = int(total_count_result)

        # Query to get the data for push charges
        push_charges_dataquery = """
            SELECT DISTINCT ON (instance_id)
                instance_id, iccid, service_provider_id, service_provider,
                rev_customer_id, customer_name, msisdn, total_charge_amount, error_message
            FROM public.vw_optimization_push_charges_error
            WHERE session_id = %s
            OFFSET %s LIMIT %s;
        """

        push_charges_data = database.execute_query(
            push_charges_dataquery, params=[session_id, start, limit]
        )
        # push_charges_data = push_charges_data.astype(str)
        # Check if data is empty
        if push_charges_data.empty:
            # If no data, create an empty list with column names as keys
            columns = [
                "rev_customer_id",
                "customer_name",
                "iccid",
                "msisdn",
                "run_status",
                "instance_id",
                "error_message",
                "total_charge_amount",
            ]
            # Return an empty list of data with the column names in the response
            push_charges_data = []
            response = {
                "flag": True,
                "message": "No data found for the given parameters",
                "pages": pages,
                "push_charges_data": push_charges_data,
                "columns": columns,
                "instance_ids": instance_ids,
                "iccids": iccid_list,
            }
        else:
            # If data exists, convert to list of dictionaries
            push_charges_data = push_charges_data.to_dict(orient="records")

            response = {
                "flag": True,
                "pages": pages,
                "push_charges_data": push_charges_data,
                "instance_ids": instance_ids,
                "iccids": iccid_list,
            }

        # Ensure everything is JSON serializable
        return response

    except Exception as e:
        # Log the exception and return a failure response
        logging.exception(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "error": str(e),
            "message": "An error occurred while fetching the data",
        }
        # Ensure error response is also JSON serializable
        return response


##update button for rate plans and other updates
def update_optimization_actions_data(data):
    """
    The update_optimization_actions_data function updates the rate plans and
    other relevant data for a specific ICCID in the sim_management_inventory table.
    It takes the changed_data (the data to be updated) and the iccid
    (identifier for the SIM) from the request.
    The function attempts to update the record and returns a success message
    if the update is successful. If an exception occurs during the update process,
    it logs the exception and continues.
    """
    # Database connection
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    changed_data = data.get("changed_data", "")
    action = data.get("action", "push_charges_update")
    iccid = str(data.get("iccid"))
    # Check if iccid is provided and is not an empty string
    if not iccid or iccid == "0":
        return {"flag": False, "message": "ICCID is required and cannot be empty. "}
    ##updation in 2.0 for sim_management_inventory table
    try:
        database.update_dict("sim_management_inventory", changed_data, {"iccid": iccid})
    except Exception as e:
        logging.exception(f"Exception is {e}")
        return {"flag": False, "message": "Failed to Update in 2.0!!!"}
    ##updation in 1.0 for Device and Mobility Device  tables
    try:
        onepointorelated_query = f"""SELECT distinct service_provider_id,device_id,mobility_device_id
        FROM sim_management_inventory WHERE iccid = '{iccid}'
        """
        onepointorelated_dataframe = database.execute_query(
            onepointorelated_query, True
        )
        row = onepointorelated_dataframe.iloc[0]  # Get the 0th row
        # Extract values
        service_provider_id = row["service_provider_id"]
        device_id = row["device_id"]
        mobility_device_id = row["mobility_device_id"]
        customer_rate_plan_name = changed_data.get("customer_rate_plan_name", "")
        customer_rate_pool_name = changed_data.get("customer_rate_pool_name", "")
        if customer_rate_plan_name:
            customer_rate_plan_id = database.get_data(
                "customerrateplan",
                {"service_provider_id": str(service_provider_id)},
                ["id"],
            )["id"].to_list()[0]
        else:
            customer_rate_plan_id = None

        if customer_rate_pool_name:
            customer_rate_pool_id = database.get_data(
                "customer_rate_pool",
                {"service_provider_id": str(service_provider_id)},
                ["id"],
            )["id"].to_list()[0]
        else:
            customer_rate_pool_id = None
        optimizations_actions_update_in_10(
            service_provider_id,
            customer_rate_pool_id,
            customer_rate_plan_id,
            device_id,
            mobility_device_id,
            iccid,
            action,
        )
        return {"flag": True, "message": "Updated Successfully"}
    except Exception as e:
        logging.exception(f"Exception is {e}")
        return {"flag": False, "message": "Failed to Update in 1.0!!!"}


def optimizations_actions_update_in_10(
    service_provider_id,
    customer_rate_pool_id,
    customer_rate_plan_id,
    device_id,
    mobility_device_id,
    iccid,
    action,
):
    server = "altaworx-test.cd98i7zb3ml3.us-east-1.rds.amazonaws.com"
    database = "AltaworxCentral_Test"
    username = "ALGONOX-Vyshnavi"
    password = "cs!Vtqe49gM32FDi"
    mobility_flag = False
    if customer_rate_pool_id is not None:
        customer_rate_pool_id = int(customer_rate_pool_id)
    if customer_rate_plan_id is not None:
        customer_rate_plan_id = int(customer_rate_plan_id)
    if str(service_provider_id) in ["6", "20"]:
        mobility_flag = True
        table_name = "AltaworxCentral_Test.dbo.MobilityDevice_Tenant"
        where_col = "MobilityDeviceId"
        if mobility_device_id is not None:
            where_val = int(mobility_device_id)

    else:
        table_name = "AltaworxCentral_Test.dbo.Device_Tenant"
        where_col = "DeviceId"
        if device_id is not None:
            device_id = int(device_id)
    if action == "Assign Rate Plan":
        # Construct query with parameterized values
        query = f"""
        UPDATE {table_name}
        SET CustomerRatePlanId = %s
        WHERE {where_col} = %s
        """
        print(f"Query: {query}")
        # Establishing connection and executing the query
        with pytds.connect(
            server=server, database=database, user=username, password=password
        ) as conn:
            cursor = conn.cursor()
            if mobility_flag:
                cursor.execute(query, (customer_rate_plan_id, mobility_device_id))
            else:
                print(
                    customer_rate_plan_id,
                    customer_rate_pool_id,
                    device_id,
                    "input params",
                )
                cursor.execute(query, (customer_rate_plan_id, device_id))

            conn.commit()

    else:
        # Construct query with parameterized values
        query = f"""
        UPDATE {table_name}
        SET CustomerRatePlanId = %s, CustomerRatePoolId = %s
        WHERE {where_col} = %s
        """
        print(f"Query: {query}")

        # Establishing connection and executing the query
        with pytds.connect(
            server=server, database=database, user=username, password=password
        ) as conn:
            cursor = conn.cursor()
            if mobility_flag:
                cursor.execute(
                    query,
                    (customer_rate_plan_id, customer_rate_pool_id, mobility_device_id),
                )
            else:
                print(
                    customer_rate_plan_id,
                    customer_rate_pool_id,
                    device_id,
                    "input params",
                )
                cursor.execute(
                    query, (customer_rate_plan_id, customer_rate_pool_id, device_id)
                )

            conn.commit()


# Function to fetch both service providers and their rate plans
def get_assign_rate_plan_optimization_dropdown_data(data):
    """
    The get_assign_rate_plan_optimization_dropdown_data function fetches
    the rate plans for a specified service provider, based on the
    optimization type (either "Customer" or "Carrier)
    """
    logging.info(f"Request Data: {data}")
    # Start time  and date calculation
    start_time = time.time()
    service_provider = data.get("service_provider")
    optimization_type = data.get("optimization_type", "Customer")
    username = data.get("username", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("SessionID", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    try:
        tenant_database = data.get("db_name", "")
        # database Connection
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    try:
        # based on the optimization type the rate plans will be fetched
        if optimization_type == "Customer":
            rate_plan_list_data = database.get_data(
                "customerrateplan",
                {"service_provider_name": service_provider, "is_active": True},
                ["rate_plan_name"],
                order={"rate_plan_name": "asc"},  # Rate plan column
            )["rate_plan_name"].to_list()
        else:
            rate_plan_list_data = database.get_data(
                "carrier_rate_plan",
                {"service_provider": service_provider, "is_active": True},
                ["rate_plan_code"],  # Rate plan column
            )["rate_plan_code"].to_list()
        # Remove duplicates by converting to a set and back to a list
        rate_plan_list_data = list(set(rate_plan_list_data))
        # Sort the list alphabetically (or numerically based on the content)
        rate_plan_list_data.sort()

        response = {
            "flag": True,
            "message": "assign rate plan data fetched successfully",
            "rate_plan_list_data": rate_plan_list_data,
        }
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "Optimization",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": "Get Rate plans by service provider",
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"Exception is {e}")
        # Return the data as a JSON response,
        return response

    except Exception as e:
        message = "Something went wrong while fetching the  rate plans"
        response = {
            "flag": True,
            "message": "unable to fetch the assign rate plan data",
            "rate_plan_list_data": [],
        }
        logging.exception(f"Something went wrong {e}")

        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "Optimization",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        return response


def charges_upload_status_mail(
    common_utils_database, username, template_name, database, session_id
):
    """
    The charges_upload_status_mail function is responsible for sending an email notification
    regarding the status of a charges upload process. It queries the database for charge
    details based on a specific session ID and attaches the results as an Excel file.
    Depending on the upload status, it sends either a success or failure email,
    while also updating the email audit with relevant details such as the email's subject,
    recipient, and status.
    """
    if template_name == "Charges Upload Completed":
        query = f"""
            SELECT
                customer_name,session_id,
                msisdn,
                charge_id,
                charge_amount,
                sms_charge_amount,
                billing_period_end_date,
                billing_period_start_date, error_message
            FROM vw_optimization_smi_result_customer_charge_queue
            where session_id='{session_id}'
        """
        result_df = database.execute_query(query, True)
        # Generate an Excel file from the result DataFrame
        blob_data = dataframe_to_blob(result_df)
        # Prepare the email content
        subject = f"Charges Uploaded Successfully"

        # Send the email with Excel file attached
        result = send_email(
            template_name=template_name,
            username=username,
            subject=subject,
            attachments=blob_data,  # Pass the blob_data as attachment
        )
    else:
        query = f"""
            SELECT
                customer_name,session_id,
                msisdn,
                charge_id,
                charge_amount,
                sms_charge_amount,
                billing_period_end_date,
                billing_period_start_date, error_message
            FROM vw_optimization_smi_result_customer_charge_queue
            where session_id='{session_id}'
        """
        result_df = database.execute_query(query, True)
        # Generate an Excel file from the result DataFrame
        blob_data = dataframe_to_blob(result_df)
        # Prepare the email content
        subject = f"Charges Uploaded Failed!!"
        # Send the email with Excel file attached
        result = send_email(
            template_name=template_name,
            username=username,
            subject=subject,
            attachments=blob_data,  # Pass the blob_data as attachment
        )

        # Handle email sending result and update audit
        if isinstance(result, dict) and result.get("flag") is False:
            to_emails = result.get("to_emails")
            cc_emails = result.get("cc_emails")
            subject = result.get("subject")
            from_email = result.get("from_email")
            partner_name = result.get("partner_name")

            # Email failed - log failure in email audit
            email_audit_data = {
                "template_name": template_name,
                "email_type": "Application",
                "partner_name": partner_name,
                "email_status": "failure",
                "from_email": from_email,
                "to_email": to_emails,
                "cc_email": cc_emails,
                "action": "Email sending failed",
                "comments": "Email sending failed",
                "subject": subject,
                "body": body,
            }
            common_utils_database.update_audit(email_audit_data, "email_audit")
            logging.exception(f"Failed to send email: {email_audit_data}")
        else:
            to_emails, cc_emails, subject, from_email, body, partner_name = result

            query = """
                        SELECT parents_module_name, sub_module_name, child_module_name,
                          partner_name
                        FROM email_templates
                        WHERE template_name = %s
                    """

            params = [template_name]
            # Execute the query with template_name as the parameter
            email_template_data = common_utils_database.execute_query(
                query, params=params
            )
            parents_module_name, sub_module_name, child_module_name, partner_name = (
                email_template_data[0]
            )

            # Email success - log success in email audit
            email_audit_data = {
                "template_name": template_name,
                "email_type": "Application",
                "partner_name": partner_name,
                "email_status": "success",
                "from_email": from_email,
                "to_email": to_emails,
                "cc_email": cc_emails,
                "comments": "Report Email sent successfully",
                "subject": subject,
                "body": body,
                "action": "Email triggered",
                "parents_module_name": parents_module_name,
                "sub_module_name": sub_module_name,
                "child_module_name": child_module_name,
            }
            common_utils_database.update_audit(email_audit_data, "email_audit")
            logging.info(f"Email sent successfully: {email_audit_data}")
    return {"flag": True}


def push_charges_submit(data):
    """
    The push_charges_submit function handles the submission of customer charges
    for a specific session. It builds a POST request payload with session details
    (SessionId, selectedInstances, selectedUsageInstances, and pushType) and sends
    it to the configured API endpoint for processing. The function dynamically retrieves
    the tenant_id and uses it in the headers. It returns the API response,
    including status code and message, while logging errors in case of failure.
    """
    logging.info(f"Request data Recieved")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    session_id = data.get("SessionId", "")
    selected_instances = data.get(
        "selectedInstances", ""
    )  # Placeholder, needs to be discussed
    selected_usage_instances = data.get(
        "selectedUsageInstances", ""
    )  # Placeholder, needs to be discussed
    push_type = data.get("pushType", "")
    # Convert `selectedInstances` to a comma-separated string
    if isinstance(selected_instances, list):
        selected_instances = ",".join(map(str, selected_instances))
    # Convert `selectedUsageInstances` to an empty string if it is None
    if isinstance(selected_usage_instances, list):
        selected_usage_instances = ",".join(map(str, selected_usage_instances))
    elif selected_usage_instances is None:
        selected_usage_instances = ""  # If None, set to an empty string
    # Connect to the database to get tenant_id
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    optimization_list_view_id = data.get("optimization_list_view_id", "")
    try:
        instance_ids = data[
            "selectedInstances"
        ]  # Assuming data is the provided dictionary
        instance_ids_str = ",".join(
            map(str, instance_ids)
        )  # Convert list to comma-separated string

        # Update the query to include the instance_ids
        number_of_charges_to_push_query = f"""
        select sum(device_count)
        from vw_optimization_high_usage_customers
        where instance_id in ({instance_ids_str})
        """

        # Execute the query
        device_count = int(
            database.execute_query(number_of_charges_to_push_query, True)[
                "sum"
            ].to_list()[0]
        )
        database.update_dict(
            "optimization_session",
            {
                "optimization_status_syncs": device_count,
            },
            {"id": optimization_list_view_id},
        )
    except Exception as e:
        logging.warning(f"Exception is {e}")
    service_provider_id = data.get("service_provider_id", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        username = "amop-core"
        password = "uDLD4AK3vOnqAjpn2DVRhwlrcbTLB6EY"
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode("utf-8")).decode(
            "utf-8"
        )
        authorization_header = f"Basic {encoded_credentials}"

        # Retrieve tenant_id once
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": "Altaworx"}, ["id"]
        )["id"].to_list()[0]

        # Define the URL for customer charges upload
        url = os.getenv("OPTIMIZATIONAPI_CREATECOMFIRM_SESSION", "")
        headers = {
            "Authorization": authorization_header,
            "user-name": "lohitha.v@algonox.com",
            "x-tenant-id": str(tenant_id),
            "Content-Type": "application/json",
        }

        # Create the request body dynamically
        body = {
            "SessionId": session_id,
            "selectedInstances": selected_instances,
            "selectedUsageInstances": selected_usage_instances,
            "pushType": push_type,
        }

        # Send the POST request to the main API
        response = requests.post(
            url, headers=headers, data=json.dumps(body), timeout=60
        )

        # Async send sync API request in a separate thread
        # Send the POST request to the synchronization API
        sync_url = "https://demo-api.amop.services/optimization_sync_lambda_uat/push_charges_sync"
        sync_payload = {
            "data": {
                "path": "/push_charges_sync",
                "key_name": "optimization_sync_push_charges",
                "session_id": optimization_list_view_id,
                "service_provider_id": service_provider_id,
            }
        }

        try:
            sync_response = requests.post(sync_url, json=sync_payload)
            print("successfully called")
            if sync_response.status_code == 200:
                current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                logging.info(
                    f"API call successful. Data sync completed at {current_timestamp}"
                )
            else:
                logging.error(
                    f"API sync call failed with status code: {sync_response.status_code}"
                )
        except Exception as sync_exception:
            logging.error(
                f"Error occurred while calling the sync API: {sync_exception}"
            )

        # Prepare the response data
        response_data = {
            "flag": True,
            "status code": response.status_code,
            "message": response.json() if response.content else "No Content",
        }

        # Async email sending
        def send_mail():
            try:
                charges_upload_status_mail(
                    common_utils_database,
                    username,
                    "Charges Upload Completed",
                    database,
                    session_id,
                )
            except Exception as e:
                logging.exception(f"Failed to send the mail: {e}")

        threading.Thread(target=send_mail).start()

        return response_data

    except Exception as e:
        logging.exception(f"Error uploading customer charges data: {e}")

        # Async failure email
        def send_failure_mail():
            try:
                charges_upload_status_mail(
                    common_utils_database,
                    username,
                    "Charges Upload Failure",
                    database,
                    session_id,
                )
            except Exception as e:
                logging.exception(f"Failed to send the mail: {e}")

        threading.Thread(target=send_failure_mail).start()
        return {"flag": False, "error": str(e)}


# def push_charges_submit(data):
#     """
#     The push_charges_submit function handles the submission of customer charges
#     for a specific session. It builds a POST request payload with session details
#     (SessionId, selectedInstances, selectedUsageInstances, and pushType) and sends
#     it to the configured API endpoint for processing. The function dynamically retrieves
#     the tenant_id and uses it in the headers. It returns the API response,
#     including status code and message, while logging errors in case of failure.
#     """
#     logging.info(f"Request data Recieved")
#     username = data.get("username", "")
#     tenant_name = data.get("tenant_name", "")
#     session_id = data.get("SessionId", "")
#     selected_instances = data.get(
#         "selectedInstances", ""
#     )  # Placeholder, needs to be discussed
#     selected_usage_instances = data.get(
#         "selectedUsageInstances", ""
#     )  # Placeholder, needs to be discussed
#     push_type = data.get("pushType", "")
#     # Convert `selectedInstances` to a comma-separated string
#     if isinstance(selected_instances, list):
#         selected_instances = ",".join(map(str, selected_instances))
#     # Convert `selectedUsageInstances` to an empty string if it is None
#     if isinstance(selected_usage_instances, list):
#         selected_usage_instances = ",".join(map(str, selected_usage_instances))
#     elif selected_usage_instances is None:
#         selected_usage_instances = ""  # If None, set to an empty string
#     # Connect to the database to get tenant_id
#     tenant_database = data.get("db_name", "")
#     database = DB(tenant_database, **db_config)
#     optimization_list_view_id=data.get('optimization_list_view_id','')
#     service_provider_id=data.get('service_provider_id','')
#     common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
#     try:
#         username = "amop-core"
#         password = "uDLD4AK3vOnqAjpn2DVRhwlrcbTLB6EY"
#         credentials = f"{username}:{password}"
#         encoded_credentials = base64.b64encode(credentials.encode("utf-8")).decode("utf-8")
#         authorization_header = f"Basic {encoded_credentials}"

#         # Retrieve tenant_id once
#         tenant_id = common_utils_database.get_data(
#             "tenant", {"tenant_name": 'Altaworx'}, ["id"]
#         )["id"].to_list()[0]

#         # Define the URL for customer charges upload
#         url = os.getenv("OPTIMIZATIONAPI_CREATECOMFIRM_SESSION", "")
#         headers = {
#             "Authorization": authorization_header,
#             "user-name": "lohitha.v@algonox.com",
#             "x-tenant-id": str(tenant_id),
#             "Content-Type": "application/json",
#         }

#         # Create the request body dynamically
#         body = {
#             "SessionId": session_id,
#             "selectedInstances": selected_instances,
#             "selectedUsageInstances": selected_usage_instances,
#             "pushType": push_type,
#         }

#         # Send the POST request to the main API
#         response = requests.post(url, headers=headers, data=json.dumps(body), timeout=60)

#         # Async send sync API request in a separate thread
#         # Send the POST request to the synchronization API
#         sync_url = "https://demo-api.amop.services/optimization_sync_lambda_uat/push_charges_sync"
#         sync_payload = {
#                         "data": {
#               "path": "/push_charges_sync",
#               "key_name": "optimization_sync_push_charges",
#               "session_id": optimization_list_view_id,
#               "service_provider_id":service_provider_id
#             }
#         }

#         try:
#             sync_response = requests.post(sync_url, json=sync_payload)
#             print('successfully called')
#             if sync_response.status_code == 200:
#                 current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
#                 logging.info(f"API call successful. Data sync completed at {current_timestamp}")
#             else:
#                 logging.error(f"API sync call failed with status code: {sync_response.status_code}")
#         except Exception as sync_exception:
#             logging.error(f"Error occurred while calling the sync API: {sync_exception}")


#         # Prepare the response data
#         response_data = {
#             "flag": True,
#             "status code": response.status_code,
#             "message": response.json() if response.content else "No Content",
#         }

#         # Async email sending
#         def send_mail():
#             try:
#                 charges_upload_status_mail(
#                     common_utils_database,
#                     username,
#                     "Charges Upload Completed",
#                     database,
#                     session_id,
#                 )
#             except Exception as e:
#                 logging.exception(f"Failed to send the mail: {e}")

#         threading.Thread(target=send_mail).start()

#         return response_data

#     except Exception as e:
#         logging.exception(f"Error uploading customer charges data: {e}")

#         # Async failure email
#         def send_failure_mail():
#             try:
#                 charges_upload_status_mail(
#                     common_utils_database,
#                     username,
#                     "Charges Upload Failure",
#                     database,
#                     session_id,
#                 )
#             except Exception as e:
#                 logging.exception(f"Failed to send the mail: {e}")

#         threading.Thread(target=send_failure_mail).start()
#         return {"flag": False, "error": str(e)}


def update_push_charges_data_optimization(data):
    tenant_name = data.get("tenant_name", "Altaworx")
    database = DB("altaworx_central", **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]
        submit_data = data.get("changed_data", "")
        submit_data["tenant_id"] = tenant_id
        bulkchangeid = database.insert_data(submit_data, "sim_management_bulk_change")
        response = {"flag": True, "message": "Push charges data updated Successfully!!"}
        return response
    except Exception as e:
        logging.exception(f"Exception is {e}")
        response = {"flag": False, "message": "Push charges data updation failed!!"}
        return response


def dataframe_to_blob(data_frame):
    """
    Description:The Function is used to convert the dataframe to blob
    """
    # Create a BytesIO buffer
    bio = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        data_frame.to_excel(writer, index=False)

    # Get the value from the buffer
    bio.seek(0)
    blob_data = base64.b64encode(bio.read())
    return blob_data


def get_export_status(data):
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        module_name = data.get("module_name")
        export_status_query = (
            f"select * from export_status where module_name='{module_name}'"
        )
        export_status_data = common_utils_database.execute_query(
            export_status_query, True
        ).to_dict(orient="records")
        return {"flag": True, "export_status_data": export_status_data[0]}
    except Exception as e:
        logging.exception(f"Exception is {e}")
        return {"flag": False, "export_status_data": []}


def get_optimization_progress_bar_data(data):
    print(data, "dataaaaaaaaaaaaaaaaaaaaaaa")
    logging.info("optimization progress bar function started")

    job_name = data.get("job_name", "")
    optimization_session_id = data.get("SessionId", "")
    progress = data.get("Progress", "")
    error_message = data.get("ErrorMessage", "")
    customer_id = data.get("CustomerId", "")
    session_id = data.get("OptimizationSessionGuid")

    # Database Connection
    tenant_database = data.get("db_name", "")
    database = DB("altaworx_test", **db_config)

    updated_data = {
        "optimization_session_id": optimization_session_id,
        "progress": progress,
        "error_message": error_message,
        "customer_id": customer_id,
        "session_id": session_id,
    }

    try:
        if job_name == "ErrorMessage":
            insert_id = database.insert_data(updated_data, "optimization_details")
            response = {"flag": True, "message": "Call Successful"}
            return response
        else:

            # Check if details_id exists
            details_data = database.get_data(
                "optimization_details",
                {"optimization_session_id": optimization_session_id},
                ["optimization_session_id"],
            )
            if progress != 50:
                if not details_data.empty:
                    details_id = details_data["optimization_session_id"].to_list()[0]
                    updated_data.pop(
                        "optimization_session_id"
                    )  # Remove the key before updating
                    database.update_dict(
                        "optimization_details",
                        updated_data,
                        {"optimization_session_id": details_id},
                    )
                    optimization_session_update_data = {"progress": progress}
                    database.update_dict(
                        "optimization_session",
                        optimization_session_update_data,
                        {"session_id": session_id},
                    )
                else:
                    details_id = None
                    # Check if 'AdditionalJson' exists and parse it safely
                    if "AdditionalJson" in data and data["AdditionalJson"] is not None:
                        try:
                            additional_json_data = json.loads(data["AdditionalJson"])

                            if "data" in additional_json_data and isinstance(
                                additional_json_data["data"], dict
                            ):
                                service_provider_id = additional_json_data["data"].get(
                                    "ServiceProviderId"
                                )
                                optimization_type = additional_json_data["data"].get(
                                    "OptimizationType"
                                )

                                if (
                                    service_provider_id is None
                                    or optimization_type is None
                                ):
                                    logging.warning(
                                        "ServiceProviderId or OptimizationType is missing in AdditionalJson"
                                    )
                                else:
                                    if optimization_type == "Carrier":
                                        optimization_type_id = 0
                                    else:
                                        optimization_type_id = 1

                                    # Prepare data for optimization session
                                    optimization_session_data = {
                                        "session_id": session_id,
                                        "is_active": True,
                                        "optimization_type_id": optimization_type_id,
                                        "service_provider_id": service_provider_id,
                                        "is_deleted": False,
                                        "progress": progress,
                                        "optimization_run_start_date": datetime.now(),  # Current timestamp
                                    }
                                    # Add optimization_type_id to updated_data dictionary
                                    updated_data["optimization_type_id"] = (
                                        optimization_type_id
                                    )
                                    try:
                                        insert_id = database.insert_data(
                                            updated_data, "optimization_details"
                                        )
                                    except Exception as e:
                                        logging.exception(
                                            f"Exception is coming while updating optimization details"
                                        )
                                    optimization_id = database.insert_data(
                                        optimization_session_data,
                                        "optimization_session",
                                    )
                                    optimization_instance_data = {
                                        "run_status_id": 6,
                                        "service_provider_id": service_provider_id,
                                        "optimization_session_id": optimization_id,
                                        "is_deleted": False,
                                    }
                                    optimization_instance_id = database.insert_data(
                                        optimization_instance_data,
                                        "optimization_instance",
                                    )
                            else:
                                logging.warning(
                                    "The 'data' subfield within 'AdditionalJson' is not found or is not a dictionary."
                                )
                        except (json.JSONDecodeError, TypeError) as e:
                            logging.warning(f"Failed to parse 'AdditionalJson': {e}")
                    else:
                        logging.warning(
                            "The 'AdditionalJson' field is not found or is None."
                        )
            # Check if progress is 100, if so, hit the API
            else:
                # Prepare the data to send in the API request
                api_url = "https://8x5f1gkyk7.execute-api.us-east-1.amazonaws.com/uat/optimization_sync_lambda_uat"
                api_payload = {
                    "data": {
                        "path": "/lambda_sync_jobs_",
                        "key_name": "optimization_sync",
                        "session_id": session_id,
                    }
                }

                # Send the POST request
                try:
                    response = requests.post(api_url, json=api_payload)

                    if response.status_code == 200:
                        # Get the current timestamp
                        current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                        # Log the message with the timestamp
                        logging.info(
                            f"API call successful. Data sync call is successfully done at {current_timestamp}"
                        )
                        # logging.info("API call successful.Data synn call is succssefully done ")
                    else:
                        logging.error(
                            f"API call failed with statudafdfadsfs code: {response.status_code}"
                        )
                except Exception as e:
                    logging.error(f"Error occurred while calling the API: {e}")

            response = {"flag": True, "message": "Call Successful"}
            return response
    except Exception as e:
        logging.exception(f"Exception is {e}")
        response = {"flag": False, "message": f"Call Failed {e}"}
        return response


def get_optimization_error_details_data(data):
    logging.info("optimization progress bar function started")

    job_name = data.get("job_name", "")
    optimization_session_id = data.get("SessionId", "")
    error_message = data.get("ErrorMessage", "")
    customer_id = data.get("CustomerId", "")
    # Database Connection
    tenant_database = data.get("db_name", "")
    database = DB("altaworx_test", **db_config)
    optimization_type_id = database.get_data(
        "optimization_details",
        {"optimization_session_id": optimization_session_id},
        ["optimization_type_id"],
    )["optimization_type_id"].to_list()[0]
    updated_data = {
        "optimization_session_id": optimization_session_id,
        "error_message": error_message,
        "customer_id": customer_id,
        "optimization_type_id": optimization_type_id,
    }
    try:
        if not customer_id:
            updated_data.pop(
                "optimization_session_id"
            )  # Remove the key before updating
            updated_data.pop("customer_id")  # Remove the key before updating
            updated_data.pop("optimization_type_id")  # Remove the key before updating
            database.update_dict(
                "optimization_details",
                updated_data,
                {"optimization_session_id": optimization_session_id},
            )

        else:
            # Check if details_id exists
            details_data = database.get_data(
                "optimization_details",
                {"customer_id": customer_id},
                ["customer_id", "session_id"],
            )
            if not details_data.empty:
                details_id = details_data["customer_id"].to_list()[0]
                updated_data.pop(
                    "optimization_session_id"
                )  # Remove the key before updating
                updated_data.pop("customer_id")  # Remove the key before updating
                updated_data.pop(
                    "optimization_type_id"
                )  # Remove the key before updating
                database.update_dict(
                    "optimization_details", updated_data, {"customer_id": customer_id}
                )
            else:
                insert_id = database.insert_data(updated_data, "optimization_details")

        response = {"flag": True, "message": "Call Successfull"}
        return response
    except Exception as e:
        logging.exception(f"Exception is {e}")
        message = f"call failed{e}"
        response = {"flag": False, "message": message}
        return response


# Function to get optimization sessions by tenant ID
def get_optimization_sessions_by_tenant_id(tenant_id, optimization_type, filter_str):
    server = "altaworx-test.cd98i7zb3ml3.us-east-1.rds.amazonaws.com"
    database = "AltaworxCentral_Test"
    username = "ALGONOX-Vyshnavi"
    password = "cs!Vtqe49gM32FDi"
    query = ""
    if optimization_type == "All":
        query = f"""
            SELECT *
            FROM vwOptimizationSession
            WHERE TenantId = {tenant_id}
            AND IsActive = 1
            AND IsDeleted = 0
            ORDER BY CreatedDate DESC
        """
    else:
        query = f"""
            SELECT *
            FROM vwOptimizationSession
            WHERE TenantId = {tenant_id}
            AND OptimizationTypeId = {int(optimization_type)}
            AND IsActive = 1
            AND IsDeleted = 0
            ORDER BY CreatedDate DESC
        """

    # Connect to the database and execute the query
    with pytds.connect(
        server=server, database=database, user=username, password=password
    ) as conn:
        cursor = conn.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()

        # Apply filter if provided
        if filter_str:
            filter_str = filter_str.lower()
            rows = [
                row
                for row in rows
                if (row.service_provider and filter_str in row.service_provider.lower())
                or (
                    row.billing_period_end_date
                    and filter_str in str(row.billing_period_end_date)
                )
            ]

        return rows


# Function to get running optimization sessions
def get_optimization_running():
    server = "altaworx-test.cd98i7zb3ml3.us-east-1.rds.amazonaws.com"
    database = "AltaworxCentral_Test"
    username = "ALGONOX-Vyshnavi"
    password = "cs!Vtqe49gM32FDi"
    query = """
        SELECT *
        FROM vwOptimizationSessionRunning
        ORDER BY OptimizationSessionId DESC
    """

    with pytds.connect(
        server=server, database=database, user=username, password=password
    ) as conn:
        cursor = conn.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        columns = [column[0] for column in cursor.description]
        return [dict(zip(columns, row)) for row in rows]


# Function to check if optimization is running
def check_optimization_is_running(tenant_id):
    # Get the list of optimization sessions
    optimization_session_list = get_optimization_sessions_by_tenant_id(
        tenant_id, "All", ""
    )
    if not optimization_session_list:
        return False

    # Get the list of running optimization sessions
    optimization_session_running_list = get_optimization_running()
    if not optimization_session_running_list:
        return False

    # Assuming the first column in the tuple from optimization_session_list is the 'id'
    optimization_session_id = optimization_session_list[0][
        0
    ]  # Access the 'id' (first element of the tuple)

    # Check if the session is running using dictionary keys for the optimization_session_running_list
    opt_running = [
        x
        for x in optimization_session_running_list
        if x["OptimizationSessionId"] == optimization_session_id
    ]

    if opt_running:
        # Assuming '1' is 'COMPLETE_WITH_ERROR' for OptimizationQueueStatusId and OptimizationInstanceStatusId
        return not any(
            x["OptimizationQueueStatusId"] == 7
            or x["OptimizationInstanceStatusId"] == 7
            for x in opt_running
        )

    return False


# Main function to check optimize button status
def optimize_button_status(data):
    # Database connection parameters

    tenant_id = data.get("tenant_id", 1)

    # Get the status of the optimization button
    optimize_button = check_optimization_is_running(tenant_id)
    return {"flag": True, "optimize_button_status": optimize_button}


def get_push_charges_status(data):
    session_id = data.get("session_id", "")
    database = DB("altaworx_test", **db_config)
    # Define the query to check push charges status
    push_charges_status_query = f"""
    SELECT run_status
    FROM vw_optimization_push_charges_data
    WHERE session_id='{session_id}'
    AND run_status IN ('Pending', 'Not Started')
    """

    try:
        # Execute the query to check for any results
        push_charges_status = database.execute_query(push_charges_status_query, True)

        # If the query returns any data, set push_charges_button_status to False
        if push_charges_status.empty:  # Check if any rows are returned
            push_charges_button_status = True
        else:
            push_charges_button_status = False

        # Prepare the response with the button status
        response = {
            "flag": True,
            "push_charges_button_status": push_charges_button_status,
        }
        return response

    except Exception as e:
        logging.exception(f"Error occurred: {e}")
        response = {
            "flag": True,
            "push_charges_button_status": False,
        }  # Default to True on error
        return response


def get_push_charges_count(data):
    logging.info("get_push_charges_count Function started")
    try:
        # Extract optimization session ID from input data
        optimization_session_id = data.get("optimization_session_id", "")
        if not optimization_session_id:
            return {
                "flag": False,
                "error": "Missing Parameters (optimization_session_id)",
            }

        # Extract tenant database name
        tenant_database = data.get("db_name", "")
        if not tenant_database:
            return {"flag": False, "error": "Missing Parameters (db_name)"}

        # Establish database connection
        try:
            database = DB(tenant_database, **db_config)
        except Exception as db_exception:
            logging.error("Failed to connect to the database: %s", str(db_exception))
            return {
                "flag": False,
                "error": "Database connection failed.",
                "details": str(db_exception),
            }
        try:
            query = f"""SELECT optimization_status_syncs, push_charges_not_processed_count
                        FROM optimization_session WHERE id='{optimization_session_id}' """
            session_result = database.execute_query(query, True)
        except Exception as query_exception:
            logging.error("Failed to fetch session data: %s", str(query_exception))
            return {
                "flag": False,
                "error": "Failed to fetch session data.",
                "details": str(query_exception),
            }

        # Check if session_result is valid
        if not isinstance(session_result, pd.DataFrame):
            logging.error(
                "Expected a DataFrame but got %s", type(session_result).__name__
            )
            return {
                "flag": False,
                "error": "Invalid data returned from database query.",
            }

        if session_result.empty:
            return {"flag": False, "error": "Optimization session not found."}

        # Extract values from the DataFrame
        try:
            no_of_charges_to_push = int(
                session_result.iloc[0]["optimization_status_syncs"] or 0
            )
            charges_remaining_to_push = int(
                session_result.iloc[0]["push_charges_not_processed_count"] or 0
            )
        except KeyError as key_error:
            logging.error(
                "Missing expected columns in session result: %s", str(key_error)
            )
            return {
                "flag": False,
                "error": "Invalid data structure in session result.",
                "details": str(key_error),
            }
        except ValueError as value_error:
            logging.error("Invalid data type in session result: %s", str(value_error))
            return {
                "flag": False,
                "error": "Invalid data values in session result.",
                "details": str(value_error),
            }

        # Prepare the success message
        message = "Successfully fetched the count."
        return {
            "flag": True,
            "no_of_charges_to_push": no_of_charges_to_push,
            "remaining_push_charges_count": charges_remaining_to_push,
            "message": message,
        }

    except Exception as e:
        logging.exception("Exception occurred in get_push_charges_count: %s", str(e))
        message = "Failed to get the count"
        return {
            "flag": True,
            "no_of_charges_to_push": 0,
            "remaining_push_charges_count": 0,
            "message": message,
        }


# def get_push_charges_count(data):
#     logging.info("get_push_charges_count Function started")
#     try:
#         # Extract optimization session ID from input data
#         optimization_session_id = data.get("optimization_session_id", "")
#         if not optimization_session_id:
#             return {"flag": False, "error": "Missing Parameters (optimization_session_id)"}

#         # Extract tenant database name
#         tenant_database = data.get("db_name", "")
#         if not tenant_database:
#             return {"flag": False, "error": "Missing Parameters (db_name)"}

#         # Establish database connection
#         try:
#             database = DB(tenant_database, **db_config)
#         except Exception as db_exception:
#             logging.error("Failed to connect to the database: %s", str(db_exception))
#             return {"flag": False, "error": "Database connection failed.", "details": str(db_exception)}

#         # Fetch data for the optimization session
#         query_conditions = {"id": optimization_session_id}
#         query_fields = ["optimization_status_syncs", "push_charges_not_processed_count"]
#         #query_fields=["progress"]

#         try:
#             session_result = database.get_data("optimization_session", query_conditions, query_fields)
#         except Exception as query_exception:
#             logging.error("Failed to fetch session data: %s", str(query_exception))
#             return {"flag": False, "error": "Failed to fetch session data.", "details": str(query_exception)}

#         # Check if session_result is valid
#         if not isinstance(session_result, pd.DataFrame):
#             logging.error("Expected a DataFrame but got %s", type(session_result).__name__)
#             return {"flag": False, "error": "Invalid data returned from database query."}

#         if session_result.empty:
#             return {"flag": False, "error": "Optimization session not found."}

#         # Extract values from the DataFrame
#         try:
#             no_of_charges_to_push = int(session_result.iloc[0]["optimization_status_syncs"])
#             charges_remaining_to_push = int(session_result.iloc[0]["push_charges_not_processed_count"])
#         except KeyError as key_error:
#             logging.error("Missing expected columns in session result: %s", str(key_error))
#             return {"flag": False, "error": "Invalid data structure in session result.", "details": str(key_error)}
#         except ValueError as value_error:
#             logging.error("Invalid data type in session result: %s", str(value_error))
#             return {"flag": False, "error": "Invalid data values in session result.", "details": str(value_error)}

#         # Prepare the success message
#         message = "Successfully fetched the count."
#         return {
#             "flag": True,
#             "no_of_charges_to_push": no_of_charges_to_push,
#             "remaining_push_charges_count": charges_remaining_to_push,
#             "message": message,
#         }

#     except Exception as e:
#         logging.exception("Exception occurred in get_push_charges_count: %s", str(e))
#         message="Failed to get the count"
#         return {
#             "flag": True,
#             "no_of_charges_to_push": 0,
#             "remaining_push_charges_count": 0,
#             "message": message,
#         }


##Rate Plan Progress
def rate_plan_progress(data):
    """
    Fetch rate plan progress for a given service provider and instance ID.

    Parameters:
    - data (dict): A dictionary containing 'service_provider_id' and 'instance_id'.

    Returns:
    - tuple: (assignments_queued, assignments_pushed_to_carrier)
    """
    # Connection details
    server = "altaworx-test.cd98i7zb3ml3.us-east-1.rds.amazonaws.com"
    database_name = "AltaworxCentral_Test"
    username = "ALGONOX-Vyshnavi"
    password = "cs!Vtqe49gM32FDi"

    # Extract parameters from the data dictionary
    service_provider_id = data.get("service_provider_id", 0)
    instance_id = data.get("instance_id", 0)

    # Default values for output
    assignments_queued = 0
    assignments_pushed_to_carrier = 0

    try:
        with pytds.connect(
            server=server, database=database_name, user=username, password=password
        ) as conn:
            with conn.cursor() as cursor:
                # Determine the stored procedure based on service_provider_id
                if service_provider_id in (20,):  # Corrected to a tuple
                    stored_procedure_name = (
                        "dbo.usp_Optimization_Mobility_RatePlanChangeProgress"
                    )
                else:
                    stored_procedure_name = (
                        "dbo.usp_Optimization_RatePlanChangeProgress"
                    )

                # Execute the stored procedure
                cursor.callproc(stored_procedure_name, (instance_id,))
                print("Successfully called the stored procedure.")

                # Fetch and assign results
                results = cursor.fetchall()
                if results:
                    assignments_queued, assignments_pushed_to_carrier = results[0]
                message = f"Rate Plan Progress data fetched successfully"
                response = {
                    "flag": "True",
                    "assignments_queued": assignments_queued,
                    "assignments_pushed_to_carrier": assignments_pushed_to_carrier,
                    "message": message,
                }
                return response

    except Exception as e:
        logging.exception("An error occurred:", e)
        message = f"Failed to get the Rate Plan Progress data"
        response = {
            "flag": "True",
            "assignments_queued": 0,
            "assignments_pushed_to_carrier": 0,
            "message": message,
        }
        return response


##get rate plan pop up values
def get_rate_plan_upload_pop_up_values(data):
    instance_id = data.get("instance_id", "")
    service_provider_id = data.get("service_provider_id", "")
    try:
        # service_provider_id = 36
        # Connection details
        server = "altaworx-test.cd98i7zb3ml3.us-east-1.rds.amazonaws.com"
        database_name = "AltaworxCentral_Test"
        username = "ALGONOX-Vyshnavi"
        password = "cs!Vtqe49gM32FDi"

        # Parameters for the stored procedure
        # instance_id = 29510  # Replace this with your desired instance ID

        # Default values for variables
        instance_id_out = 0
        total_sim_cards_to_optimize = 0
        sim_cards_to_change = 0

        with pytds.connect(
            server=server, database=database_name, user=username, password=password
        ) as conn:
            with conn.cursor() as cursor:
                if service_provider_id in (20,):  # Corrected to a tuple
                    # Define the stored procedure name
                    stored_procedure_name = (
                        "dbo.usp_Optimization_Mobility_RatePlanChangeCount"
                    )
                else:
                    # Define the stored procedure name
                    stored_procedure_name = "dbo.usp_Optimization_RatePlanChangeCount"

                # Execute the stored procedure with the instance ID
                cursor.callproc(stored_procedure_name, (instance_id,))
                logging.info("Successfully called the stored procedure.")

                # Fetch and assign results to variables
                results = cursor.fetchall()
                if results:
                    (
                        instance_id_out,
                        total_sim_cards_to_optimize,
                        sim_cards_to_change,
                    ) = results[0]
                message = f"Rate Plan pop up data fetched successfully"
                response = {
                    "flag": "True",
                    "instance_id_out": instance_id_out,
                    "total_sim_cards_to_optimize": total_sim_cards_to_optimize,
                    "sim_cards_to_change": sim_cards_to_change,
                    "message": message,
                }
                return response

    except Exception as e:
        # Assign default values in case of an error
        instance_id_out = 0
        total_sim_cards_to_optimize = 0
        sim_cards_to_change = 0
        message = f"Failed to get the response"
        response = {
            "flag": "True",
            "instance_id_out": instance_id_out,
            "total_sim_cards_to_optimize": total_sim_cards_to_optimize,
            "sim_cards_to_change": sim_cards_to_change,
            "message": message,
        }
        return response


##Carrier rate Plan upload
def rate_plan_upload(data):
    """
    The push_charges_submit function handles the submission of customer charges
    for a specific session. It builds a POST request payload with session details
    (SessionId, selectedInstances, selectedUsageInstances, and pushType) and sends
    it to the configured API endpoint for processing. The function dynamically retrieves
    the tenant_id and uses it in the headers. It returns the API response,
    including status code and message, while logging errors in case of failure.
    """
    logging.info(f"Request data Recieved")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    ids = data.get("instance_id", [])
    service_provider_id = data.get("service_provider_id", "")
    common_utils_database = DB("common_utils", **db_config)
    try:
        username = "amop-core"
        password = "uDLD4AK3vOnqAjpn2DVRhwlrcbTLB6EY"
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode("utf-8")).decode(
            "utf-8"
        )
        authorization_header = f"Basic {encoded_credentials}"

        # Retrieve tenant_id once
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": "Altaworx"}, ["id"]
        )["id"].to_list()[0]

        # Define the URL for customer charges upload
        url = (
            "https://sandbox.amop.services/api/OptimizationApi/Queue-Rate-Plan-Changes"
        )
        headers = {
            "Authorization": authorization_header,
            "user-name": "lohitha.v@algonox.com",
            "x-tenant-id": str(tenant_id),
            "Content-Type": "application/json",
        }

        # Create the request body dynamically
        body = {"ids": ids}
        print("body", body, "headers", headers)
        # Send the POST request to the main API
        response = requests.post(
            url, headers=headers, data=json.dumps(body), timeout=60
        )
        ##API CALL to sync the data
        # Prepare the data to send in the API request
        api_url = "https://8x5f1gkyk7.execute-api.us-east-1.amazonaws.com/uat/optimization_sync_lambda_uat"
        api_payload = {
            "data": {
                "path": "/lambda_sync_jobs_",
                "key_name": "optimization_rate_plans_sync",
            }
        }
        # Send the POST request
        try:
            responses = requests.post(api_url, json=api_payload)

            if responses.status_code == 200:
                # Get the current timestamp
                current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                # Log the message with the timestamp
                logging.info(
                    f"API call successful. Data sync call is successfully done at {current_timestamp}"
                )
                # logging.info("API call successful.Data synn call is succssefully done ")
            else:
                logging.error(
                    f"API call failed with statudafdfadsfs code: {response.status_code}"
                )
        except Exception as e:
            logging.error(f"Error occurred while calling the API: {e}")
        # Prepare the response data
        response_data = {
            "flag": True,
            "status code": response.status_code,
            "message": response.json() if response.content else "No Content",
        }
        return response_data

    except Exception as e:
        logging.exception(f"Error uploading rate plan  data: {e}")
        return {"flag": False, "error": str(e)}
