"""
@Author : Nikhil .N
@Author : Phaneendra.Y
Created Date: 21-06-24
"""

# Importing necessary libraries
import time
import math
import datetime
import base64
import json
import boto3
import os
import re
from datetime import date,timedelta
from pandas import Timestamp
import pytz
import numpy as np
import threading
import requests
import hashlib
import ast
import pandas as pd
from io import BytesIO
from dateutil.relativedelta import relativedelta
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
from openpyxl import Workbook
from pytz import UnknownTimeZoneError, timezone
from sqlalchemy import text
import xml.etree.ElementTree as ET
from collections import defaultdict
from openpyxl.utils import column_index_from_string

from common_utils.kore import get_access_token 
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.email_trigger import send_email
from common_utils.timezone_conversion import serialize_data ,fetch_tenant_timezone  
from common_utils.permission_manager import PermissionManager


logging = Logging(name="module_api")

db_config_withoutfilter = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema": False
    }

##to fetch the service providers ids for each tenants separately used to get the serviceprovider ids in generic way
def load_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_serviceproviders.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"### load_json Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### load_json Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### load_json Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs

def load_integration_authentication_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_integration_authentication_id.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"### load_integration_authentication_json Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### load_integration_authentication_json Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### load_integration_authentication_json Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs


def get_integration_authentication_id_by_unique_name(json_data, tenant_name):
    """
    Retrieves the integration authentication ID for a given tenant from the provided JSON data.

    Args:
        json_data (dict): A dictionary containing tenant-specific authentication data,
        tenant_name (str): The name of the tenant whose authentication ID needs to be fetched.

    Returns:
        str or None: The value of 'INTEGRATION_AUTHENTICATION_ID' if found; otherwise, None.
    """
    logging.info(f"### get_integration_authentication_id_by_unique_name, Tenant Name: {tenant_name}")
    return json_data.get(tenant_name, {}).get("INTEGRATION_AUTHENTICATION_ID", None)



##helper function to remove the hardcodes using the
def get_provider_ids(json_data, tenant_name, provider_names):
    """
    Retrieves a list of provider IDs for the specified provider names under a given tenant.

    Args:
        json_data (dict): A dictionary structured as:
                          {
                              "tenant_1": {
                                  "provider_name_1": {"id": 1, ...},
                                  "provider_name_2": {"id": 2, ...},
                                  ...
                              },
                              ...
                          }
        tenant_name (str): The name of the tenant whose providers are to be queried.
        provider_names (list): A list of provider names to filter and extract IDs for.

    Returns:
        list: A list of integers representing the provider IDs that matched the given names.
    """
    return [
        details["id"]
        for provider_name, details in json_data.get(tenant_name, {}).items()
        if provider_name in provider_names
    ]

def get_integration_id_by_unique_name(json_data, tenant_name, unique_name):
    """
    Retrieves the integration ID of a provider using its unique name for a given tenant.

    Args:
        json_data (dict): A dictionary structured as:
                          {
                              "tenant_1": {
                                  "unique_name_1": {
                                      "integration_id": "abc123",
                                      ...
                                  },
                                  ...
                              },
                              ...
                          }
        tenant_name (str): The name of the tenant for which the lookup is to be performed.
        unique_name (str): The unique name identifier of the provider.

    Returns:
        str or None: The integration ID if found, otherwise None.
    """
    return json_data.get(tenant_name, {}).get(unique_name, {}).get("integration_id", None)




def clean_tuple(tpl):
    """
    Cleans and formats a tuple input into a string representation for SQL queries.

    This function handles different cases for tuple inputs:
    - If the input is `None` or not a tuple, it returns an empty tuple.
    - If it's a single-element tuple, it returns a string formatted as "('value')".
    - Otherwise, it returns the tuple as a string (e.g., "('a', 'b')").

    Args:
        tpl (tuple or any): The input to be cleaned and converted. Can be a tuple or None.

    Returns:
        str or tuple: A string representation of the tuple for use in SQL queries, 
                      or an empty tuple if the input is invalid.
    """
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        logging.info(f"### clean_tuple Exception while converting : {e}")
        return ()

def db_config_maker(user, db_config_making, tenant_database, tenant_name,role_name,readme_flag):
    """
    Generates and returns tenant-specific DB configuration enriched with customer and service provider data.

    This function dynamically updates the DB configuration with customer details, service providers,
    customer rate plans, and feature codes based on the user’s role and tenant context.

    Args:
        user (str): Username making the request.
        db_config_making (dict): The initial DB config dictionary to be enriched.
        tenant_database (str): Target tenant database name.
        tenant_name (str): Name of the tenant.
        role_name (str): Role of the user (e.g., 'Super Admin', etc.).
        readme_flag (bool): Indicates whether to use `client_id` or `user_name` for filtering access.

    Returns:
        dict: Updated db_config_making dictionary with:
            - customers (tuple): Cleaned list of accessible customers.
            - service_providers (tuple): Original service provider names.
            - service_provider_id (tuple): IDs of service providers from DB.
            - customer_rate_plan_name (tuple): Rate plans accessible to the user.
            - feature_codes (tuple): Optional features tied to customer groups.
            - billing_account_number (None): Placeholder (currently not populated).

    """
    if role_name in ('Super Admin'):
        return db_config_making
    common_utils_database = DB('common_utils', **db_config_making)
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )

    tenant_id = tenant_data["id"].to_list()[0]
    if tenant_id:
        tenant_id=int(tenant_id)
    if readme_flag:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where client_id ='{user}' and tenant_id={tenant_id}"
        filters = common_utils_database.execute_query(query, True)
        # Fallback if DataFrame is empty
        if filters.empty:
            query = f"""
                SELECT customers, service_provider, customer_group 
                FROM user_module_tenant_mapping 
                WHERE user_name = '{user}' AND tenant_id = {tenant_id}
            """
            filters = common_utils_database.execute_query(query, True)
    else:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"
        filters = common_utils_database.execute_query(query, True)

    try:
        database = DB(tenant_database, **db_config)
    except Exception as e:
        logging.info(f"### db_config_maker exception tenant_database : {e}")
        database = DB('altaworx_central', **db_config)
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except Exception as e:
        logging.info(f"### db_config_maker customer_group exception  : {e}")
        customer_group = None

    customer_group_data = None
    # billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception(f"### db_config_maker Error extracting rate_plan_name: {e}")
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception(f"### db_config_maker Error extracting rate_plan_name: {e}")
                customer_names=None

            # try:
            #     billing_data = customer_group_data["billing_account_number"].to_list()[0]
            #     if billing_data:
            #         billing_account_number = (billing_data,)  # Wrap int in a tuple
            #     else:
            #         billing_account_number=None


            # except Exception as e:
            #     logging.exception(f"db_config_maker Error extracting billing_account_number: {e}")
            #     billing_account_number=None

            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception(f"### db_config_maker Error extracting feature_codes: {e}")
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except Exception as e:
            logging.exception(f"### db_config_maker Error extracting customer_names: {e}")
            customer = None
    else:
        customer=customer_names
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            formatted_values = "', '".join(service_provider)
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except Exception as e:
        logging.exception(f"### db_config_maker Error extracting service_provider: {e}")
        service_provider = None
        service_provider_id = None
    #customer=clean_tuple(customer)
    try:
        customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customers_df=database.execute_query(customers_query,True)
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                fixed_customer_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer, str):
                    customer_list = [customer]
                elif isinstance(customer_rate_plan_name, tuple):
                    customer_list = list(customer)
                else:
                    customer_list = customer  # Already a list

                fixed_customer_list = customer_list.copy() # Remove extra quotes and commas
                logging.info(f'### db_config_maker customer_list before extend: {fixed_customer_list}')

                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info(f'### db_config_maker customer_list after extend: {fixed_customer_list}')

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                #customer=clean_tuple(customer)
                logging.info(f'### db_config_maker final customer tuple: {customer}')

    except Exception as e:
        logging.exception(f"### db_config_maker Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    try:
        customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                fixed_customer_rate_plan_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_list = [customer_rate_plan_name]
                elif isinstance(customer_rate_plan_name, tuple):
                    customer_rate_plan_list = list(customer_rate_plan_name)
                else:
                    customer_rate_plan_list = customer_rate_plan_name  # Already a list

                fixed_customer_rate_plan_list = customer_rate_plan_list.copy()  # Remove extra quotes and commas
                logging.info(f'### db_config_maker customer rate plan_list before extend: {customer_rate_plan_list}')

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info(f'### customer rate plan list after extend: {fixed_customer_rate_plan_list}')

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info(f'### final customer rate plan tuple: {customer_rate_plan_name}')

    except Exception as e:
        logging.exception(f"### Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    customer=clean_tuple(customer)
    customer_rate_plan_name=clean_tuple(customer_rate_plan_name)
    db_config_making["customers"] = customer
    db_config_making["service_providers"] = service_provider
    db_config_making["service_provider_id"] = service_provider_id
    db_config_making["customer_rate_plan_name"] = customer_rate_plan_name
    db_config_making["feature_codes"] = feature_codes
    db_config_making["billing_account_number"] = None
    return db_config_making




def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes requests.

    This function:
    1. Initializes database configuration from environment variables.
    2. Determines user and tenant-specific configuration (including service account/token logic).
    3. Routes the request to the appropriate handler function based on the path.

    Args:
        data (dict): Request data containing user/tenant information.
        path (str): API endpoint path being invoked.

    Returns:
        dict: Result of the invoked handler function or an error message for an invalid path.
    """
    global db_config

    # Step 1: Base DB config
    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema": False
    }

    user = data.get("username") or data.get("user_name")
    tenant_database = data.get("db_name", "altaworx_central")
    tenant_name = data.get("tenant_name") or data.get("tenant") or data.get("Partner") or "Altaworx"
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    z_access_token = data.get("z_access_token")
    killbill_flag = data.get("killbill_flag", False)

    if z_access_token:
        logging.info("### db_config will be created for service accounts")
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        user = data.get("client_id", "")
        service_data = common_utils_database.get_data("service_accounts", {"client_id": user})

        if service_data.empty:
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        role_name = service_data["role"].to_list()[0]
        tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name})
        tenant_database = tenant_data["db_name"].to_list()[0]
        readme_flag = True
        db_config = db_config_maker(user, db_config, tenant_database, tenant_name, role_name, readme_flag)
    else:
        readme_flag = False
        role_name = data.get("role_name") or data.get("role") or "Super Admin"
        role_to_pass = "Super Admin" if killbill_flag else role_name
        db_config = db_config_maker(user, db_config, tenant_database, tenant_name, role_to_pass, readme_flag)

    logging.info("### db_config is created")

    # Step 2: Map paths to their handler functions
    path_function_map = {
        "/get_modules": get_modules,
        "/get_module_data": get_module_data,
        "/get_partner_info": get_partner_info,
        "/update_partner_info": update_partner_info,
        "/export": export,
        "/get_user_module_map": get_user_module_map,
        "/get_status_history": get_status_history,
        "/customers_dropdown_data": customers_dropdown_data,
        "/user_data": user_data,
        "/reports_data": reports_data,
        "/rate_plan_dropdown_data": rate_plan_dropdown_data,
        "/rate_plan_dropdown_data_optimization_groups": rate_plan_dropdown_data_optimization_groups,
        "/service_provider_list_view": service_provider_list_view,
        "/submit_update_edit_service_provider": submit_update_service_provider,
        "/export_to_s3_bucket": export_to_s3_bucket,
        "/get_export_status": get_export_status,
        "/reports_data_with_date_filter": reports_data_with_date_filter,
        "/reports_dropdown_data_export": reports_dropdown_data_export,
        "/get_optimization_setting_details": get_optimization_setting_details,
        "/update_optimization_setting_details": update_optimization_setting_details,
        "/get_integration_data": get_integration_data,
        "/save_integration_details": save_integration_details,
        "/get_service_provider_config": get_service_provider_config,
        "/save_service_provider_config": save_service_provider_config,
        "/get_cross_provider_optimization_status": get_cross_provider_optimization_status,
        "/get_submit_customer_group_dropdown_details": get_submit_customer_group_dropdown_details,
        "/get_cross_carrier_optimization": get_cross_carrier_optimization,
        "/customer_info_details": customer_info_details,
        "/update_tenant_based_partner_admin_filters": update_tenant_based_partner_admin_filters,
        "/customer_group_info_dropdown": customer_group_info_dropdown,
        "/serviceprovider_info_dropdown": serviceprovider_info_dropdown,
        "/customer_info_dropdown": customer_info_dropdown,
        "/update_customer_info_tenant_based": update_customer_info_tenant_based,
        "/get_user_info_details": get_user_info_details,
        "/get_customer_user_by_line_report_view_data": get_customer_user_by_line_report_view_data,
        "/customer_rate_pool_usage": lambda d: reports_readme(d, module_name="Customer Rate Pool Usage Report"),
        "/newly_activated_report": lambda d: reports_readme(d, module_name="Newly Activated Report"),
        "/pool_group_summary_report": lambda d: reports_readme(d, module_name="Pool Group Summary Report"),
        "/zero_usage_report": lambda d: reports_readme(d, module_name="Zero Usage Report"),
        "/sim_management_inventory_export": sim_management_inventory_export,
        "/daily_usage_report": daily_usage_report,
        "/status_history_report": status_history_report,
        "/usage_by_line_report": usage_by_line_report,
        "/get_service_account_info_details": get_service_account_info_details,
        "/update_service_account_info_tenant_based": update_service_account_info_tenant_based,
        "/bp_settings_list_view": bp_settings_list_view,
        "/update_carrier_suspend_status": update_carrier_suspend_status,
        "/enabling_billing_platform": enabling_billing_platform,
        "/update_service_line_description": update_service_line_description,
        "/get_update_service_type_mapping":get_update_service_type_mapping,
        "/glcode_list_view":glcode_list_view,
        "/add_glcode":add_glcode,
        "/update_glcode":update_glcode,
        "/deactivate_glcode":deactivate_glcode,
        "/export_active_lines_list":get_status_active_lines_list,
        "/update_device_history_tables":update_device_history_tables,
        "/bp_service_providers_list_view":bp_service_providers_list_view,
        "/add_bp_service_provider":add_bp_service_provider,
        "/update_bp_service_provider":update_bp_service_provider,
        "/deactivate_bp_service_provider":deactivate_bp_service_provider,
        "/update_version_flag":update_version_flag,
    }

    # Step 3: Route the request to the correct function
    handler = path_function_map.get(path)
    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result

logging = Logging(name="module_api")


def get_headers_mapping(
    tenant_database,
    module_list,
    role,
    user,
    tenant_id,
    sub_parent_module,
    parent_module,
    data,
    common_utils_database,
):
    """
    Retrieves structured header mappings and feature configurations for a given list of modules.

    This function connects to the `common_utils` database to extract:
    - Field mapping details (e.g., popup fields, table headers, general fields)
    - Module-specific features based on user role and permissions

    Parameters:
        tenant_database (str): Name of the target tenant database (not directly used in logic).
        module_list (list): List of module names to fetch headers for.
        role (str): User's role (e.g., 'Super Admin', 'Partner Admin', etc.).
        user (str): Username of the requesting user (not directly used; `data` used instead).
        tenant_id (str or int): Tenant ID (can be overwritten if fetched from DB).
        sub_parent_module (str): Optional sub-parent module context (not directly used here).
        parent_module (str): Name of the parent module (overridden by `data` if present).
        data (dict): Request metadata containing:
            - `feature_module_name` (str): Module name for feature lookup.
            - `username` / `user_name` / `user` (str): User identifier.
            - `tenant_name` / `tenant` (str): Name of the tenant.
            - `parent_module_name` / `parent_module` (str): Parent module context.


    Returns:
        dict: A dictionary where each key is a module name, and the value is a dictionary with:
            - `general_fields` (list): Non-popup, non-table UI fields with metadata.
            - `pop_up` (list): Fields flagged for popup display.
            - `header_map` (dict): Table column mappings with display names and header order.
            - `module_features` (list): List of feature strings enabled for the user/module.
    """
    ##Database connection
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    ret_out = {}
    try:
        logging.info(f"### get_headers_mapping Module name is :{module_list} and role is {role}")
        # common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        feature_module_name = data.get("feature_module_name", "")
        user_name = data.get("username") or data.get("user_name") or data.get("user")
        tenant_name = data.get("tenant_name") or data.get("tenant")
        parent_module_name = data.get("parent_module_name") or data.get("parent_module")
        if parent_module_name == "Sim Management":
            parent_module_name = "Sim Management"
        try:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
        except Exception as e:
            logging.exception(f"### get_headers_mapping Getting exception at fetching tenant id {e}")
        # Iterate over each module name in the provided module list
        for module_name in module_list:
            out = common_utils_database.get_data(
                "field_column_mapping", {"module_name": module_name}
            ).to_dict(orient="records")
            pop_up = []
            general_fields = []
            table_fileds = {}
            # Categorize the fetched data based on field types
            for data in out:
                if data["pop_col"]:
                    pop_up.append(data)
                elif data["table_col"]:
                    table_fileds.update(
                        {
                            data["db_column_name"]: [
                                data["display_name"],
                                data["table_header_order"],
                            ]
                        }
                    )
                else:
                    general_fields.append(data)
            # Create a dictionary to store categorized fields
            headers = {}
            headers["general_fields"] = general_fields
            headers["pop_up"] = pop_up
            headers["header_map"] = table_fileds
            try:
                final_features = []

                # Fetch all features for the 'super admin' role
                if role.lower() == "super admin":
                    all_features = common_utils_database.get_data(
                        "module_features",
                        {
                            "module": feature_module_name,
                            "parent_module_name": parent_module_name,
                        },
                        ["features"],
                    )["features"].to_list()
                    if all_features:
                        final_features = json.loads(all_features[0])
                else:
                    final_features = get_features_by_feature_name(
                        user_name,
                        tenant_id,
                        feature_module_name,
                        common_utils_database,
                        role,
                        parent_module_name,
                    )

            except Exception as e:
                logging.warning(f"### get_headers_mapping there is some error {e}")
                pass
            # Add the final features to the headers dictionary
            headers["module_features"] = final_features
            ret_out[module_name] = headers
    except Exception as e:
        logging.warning(f"### get_headers_mapping there is some error {e}")

    return ret_out


def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, role, parent_module
):
    """
    Description:
        This function retrieves a list of features associated with a specific
        feature name for a user within a tenant.
        It fetches user-module-tenant mapping data, processes the features,
        and extracts relevant features
        linked to the specified feature name.

    Parameters:
    ----------
    user_name : str
        The name or identifier of the user for whom the features are being fetched.
    tenant_id : str
        The tenant ID associated with the user.
    feature_name : str
        The specific feature name for which features need to be extracted.
    common_utils_database : object
        Utility database object to query data from the required tables.

    Returns:
    -------
    list
        A list of features associated with the specified feature name for the user.
    """
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    # Fetch user features from the database based on user name and tenant ID
    user_features_raw = common_utils_database.get_data(
        "user_module_tenant_mapping",
        {"user_name": user_name, "tenant_id": tenant_id},
        ["module_features"],
    )["module_features"].to_list()
    logging.info(f"### Raw user features fetched: {user_features_raw}")
    if not user_features_raw or user_features_raw[0] is None:
        query=f'''select module_features from role_module where role='{role}'
        '''
        user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
    # Parse the JSON string to a dictionary
    try:
        features = json.loads(
            user_features_raw[0]
        )  # Assuming it's a list with one JSON string
    except Exception as e:
        logging.exception(f"### get_features_by_feature_name features json exception : {e}")
        features = {}

    if not features:
        features = common_utils_database.get_data(
            "role_module",
            {"role": role},
            ["module_features"],
        )["module_features"].to_list()
        features = json.loads(features[0])

    # Initialize a list to hold features for the specified feature name
    features_list = []

    # Loop through all modules to find the specified feature name and collect its features
    for par_module, modules in features.items():
        if parent_module == par_module:
            for module, features_l in modules.items():
                if module == feature_name:
                    features_list = features_l

    # Log the retrieved features for debugging purposes
    logging.info(f"### Retrieved features: {features_list}")

    # Return the list of features associated with the specified feature name
    return features_list


def form_modules_dict(data, sub_modules, tenant_modules, role_name):
    """
    Description:
        The form_modules_dict function constructs a nested dictionary that maps parent modules
        to their respective submodules and child modules. It filters and organizes modules based on
        the user's role, tenant permissions, and specified submodules.

    Parameters:
    ----------
    data : list of dict
        List of dictionaries representing modules and submodules, where each dictionary contains
        details such as module name, submodule name, and parent module name.
    sub_modules : list of str
        List of submodule names that are relevant to the user or tenant.
    tenant_modules : list of str
        List of modules assigned to the tenant.
    role_name : str
        The role of the user, which influences module access and visibility.

    Returns:
    -------
    dict
        A nested dictionary where parent modules map to submodules and child modules, organized
        based on user role and permissions.
    """
    logging.info("### Starting to form modules dictionary.")

    # Initialize an empty dictionary to store the output
    out = {}

    # Iterate through the list of modules in the data
    for item in data:
        parent_module = item["parent_module_name"]
        logging.info("### Processing parent module: %s", parent_module)

        # Skip modules not assigned to the tenant unless the role is 'super admin'
        if (
            parent_module not in tenant_modules and parent_module
        ) and role_name.lower() != "super admin":
            continue

        # If there's no parent module, initialize an empty dictionary for the module
        if not parent_module:
            out[item["module_name"]] = {}
            continue
        else:
            out[item["parent_module_name"]] = {}

        # Iterate through the data again to find related modules and submodules
        for module in data:
            temp = {}

            # Skip modules not in the specified submodules unless the role is 'super admin'
            if (
                module["module_name"] not in sub_modules
                and module["submodule_name"] not in sub_modules
            ) and role_name.lower() != "super admin":
                logging.info(f"### Skipping parent module: {parent_module} (not in tenant modules)")
                continue

            # Handle modules without submodules and create a list for them
            if (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and not module["submodule_name"]
            ):
                temp = {module["module_name"]: []}

            # Handle modules with submodules and map them accordingly
            elif (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and module["submodule_name"]
            ):
                temp = {module["submodule_name"]: [module["module_name"]]}

            # Update the output dictionary with the constructed module mapping
            if temp:
                for key, value in temp.items():
                    if key in out[item["parent_module_name"]]:
                        out[item["parent_module_name"]][key].append(value[0])
                    elif temp:
                        out[item["parent_module_name"]].update(temp)

    # Return the final dictionary containing the module mappings
    logging.info(f"### Finished forming modules dictionary: {out}")

    return out


def transform_structure(input_data):
    """
    Description:
        The transform_structure function transforms a nested dictionary of modules into a list of
        structured dictionaries, each with a queue_order to maintain the order of parent modules,
        child modules, and sub-children. The transformation ensures the proper hierarchical
        structure
        with an explicit ordering mechanism for all levels of modules.

    Parameters:
    ----------
    input_data : dict
        A nested dictionary where the keys represent parent modules, and the values
        represent dictionaries
        of child modules. Each child module contains a list of sub-children.

    Returns:
    -------
    list of dict
        A list of dictionaries representing the structured transformation of the input data,
        where each dictionary contains the parent module, child module, sub-children, and
        their corresponding queue orders.
    """

    logging.info("### Starting transformation of input data.")

    # Initialize an empty list to store the transformed data
    transformed_data = []

    # Initialize the queue order for parent modules
    queue_order = 1

    # Iterate over each parent module and its children in the input data
    for parent_module, children in input_data.items():
        transformed_children = []
        child_queue_order = 1

        # Iterate over each child module and its sub-children
        for child_module, sub_children in children.items():
            transformed_sub_children = []
            sub_child_queue_order = 1

            # Iterate over each sub-child module
            for sub_child in sub_children:
                transformed_sub_children.append(
                    {
                        "sub_child_module_name": sub_child,
                        "queue_order": sub_child_queue_order,
                        "sub_children": [],
                    }
                )
                sub_child_queue_order += 1

            # Append the transformed child module with its sub-children
            transformed_children.append(
                {
                    "child_module_name": child_module,
                    "queue_order": child_queue_order,
                    "sub_children": transformed_sub_children,
                }
            )
            child_queue_order += 1

        # Append the transformed parent module with its children
        transformed_data.append(
            {
                "parent_module_name": parent_module,
                "queue_order": queue_order,
                "children": transformed_children,
            }
        )
        queue_order += 1

    # Return the list of transformed data
    return transformed_data


def convert_timestamp_datadict(df_dict, tenant_time_zone, timestamp_columns=None):
    """
    Converts UTC timestamp strings in a nested data dictionary to the specified tenant's local time zone.

    This function traverses the input dictionary (which may contain nested lists and dictionaries),
    identifies specified timestamp fields, converts them from UTC to the provided time zone,
    and formats them into a readable string format: `MM-DD-YYYY HH:MM:SS AM/PM`.

    Parameters:
        df_dict (dict): Nested dictionary (typically from a JSON or database response) containing timestamp fields.
        tenant_time_zone (str): The IANA timezone string (e.g., "Asia/Kolkata") to which the timestamps should be converted.

    Returns:
        dict: A new dictionary with the same structure as `df_dict`, but with timestamps converted
              to the tenant's timezone and formatted as strings. Invalid or missing timestamps are set to `None`.
    """
    logging.info("### Started converting timestamps...")

    try:
        if timestamp_columns is None:
            timestamp_columns = [
                "created_date",
                "modified_date",
                "deleted_date",
                "processed_date",
                "last_login",
                "date_added",
                "date_activated",
                "run_start_time",
                "session_created_date",
            ]

        target_timezone = timezone(tenant_time_zone)
        utc_timezone = timezone("UTC")

        def process_record(record):
            for col in timestamp_columns:
                if col in record:  # Ensure column exists
                    try:
                        # Handle 'None' or invalid strings gracefully
                        if record[col] in ["None", None, ""]:
                            record[col] = None
                            continue

                        # Parse timestamp string to datetime
                        timestamp = pd.to_datetime(record[col], errors="coerce")

                        if pd.notna(timestamp):  # Check if parsing was successful
                            if timestamp.tzinfo is None:
                                # Localize naive timestamps to UTC
                                timestamp = timestamp.tz_localize(utc_timezone)
                            # Convert to the target timezone
                            timestamp = timestamp.tz_convert(target_timezone)

                            # Format the datetime to include AM/PM
                            record[col] = timestamp.strftime("%m-%d-%Y %I:%M:%S %p")
                            # logging.info(f"### Updated {col}: {record[col]}")
                        else:
                            logging.info(
                                f"### Column '{col}' could not be parsed or is invalid: {record[col]}"
                            )
                    except Exception as e:
                        logging.warning(
                            f"### Error processing column '{col}': {record[col]} - {e}"
                        )
            return record

        def traverse_data(data):
            if isinstance(data, list):  # Process each item if data is a list
                return [traverse_data(item) for item in data]
            elif isinstance(
                data, dict
            ):  # Process each key-value pair if data is a dictionary
                for key, value in data.items():
                    if isinstance(value, list):  # Handle lists under dictionary keys
                        data[key] = [process_record(item) for item in value]
                    elif isinstance(value, dict):  # Handle nested dictionaries
                        data[key] = traverse_data(value)
                return data
            return data  # Return data as-is for non-dict/non-list

        # Process the data and return the result
        processed_data = traverse_data(df_dict)
        return processed_data

    except Exception as e:
        logging.exception(f"### Error in conversion process:{e}")


def get_module_data(
    data,
    flag=False,
):
    """
    Retrieves module data for a specified module by checking user and tenant
    to get the features by querying the database for column mappings and view
    names.

    It constructs and executes a SQL query to fetch data from the
    appropriate view, handles errors, and logs relevant information.

    Args:
    - data (dict): A dictionary containing various parameters like 'request_received_at',
      'session_id', 'username', 'tenant_name', 'role_name', etc.
    - flag (bool, optional): A flag to control the flow of response. Default is False.

    Returns:
    - dict: A dictionary containing the fetched data along with the status and any errors.
    """
    # Start time  and date calculation
    start_time = time.time()
    logging.info(f"### Request Data: {data}")
    # Extract  fields from Request Data
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", None)
    tenant_name = data.get("tenant_name", None)
    role = data.get("role_name", None)
    module_name = data.get("module_name", None)
    session_id = data.get("session_id", None)
    sub_parent_module = data.get("sub_parent_module", None)
    parent_module = data.get("parent_module", None)
    col_sort = data.get("col_sort", "")
    Partner = data.get("Partner", "")
    tenant_database = data.get("db_name", "")

    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    database = DB(tenant_database, **db_config_withoutfilter)

    if module_name == "Bulk Change" or module_name == "Sim Order Form":
        query = (
            f"select customers,service_provider from users where username ='{username}'"
        )
        filters = db.execute_query(query, True)
        try:
            customer = filters["customers"].to_list()[0]
        except Exception as e:
            logging.exception(f"### get_module_data customer exception : {e}")
            customer = None

        users = None
        if customer:
            if module_name == "Bulk Change":
                query = "select CONCAT(first_name, ' ', last_name) AS full_name from users where customers = %s"
                filters = db.execute_query(query, params=[customer])
                users = filters["full_name"].to_list()
                logging.info(f"### users are {users}")
            if module_name == "Sim Order Form":
                query = "select username from users where customers = %s"
                filters = db.execute_query(query, params=[customer])
                users = filters["username"].to_list()
                logging.info(f"### users are {users}")
    users = None
    customer = None

    # # Get tenant's timezone
    tenant_name = data.get("tenant_name", "")
    tenant_timezone_query = """SELECT time_zone,id FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = db.execute_query(tenant_timezone_query, params=[tenant_name])

    if tenant_name == "Altaworx Test":
        tenant_id = 1
    else:
        tenant_id = tenant_timezone["id"].to_list()[0]

    tenant_time_zone = fetch_tenant_timezone(db, data)

    try:
        data_list = {}
        pages = {}
        features = []
        # query to find the column mapping for the module
        module_mappings_df = db.get_data(
            "module_column_mappings",
            {"module_name": module_name},
            [
                "columns_mapped",
                "master_data_flag",
                "tables_mapped",
                "view_name",
                "condition",
                "drop_down_col",
                "main_update_table",
                "order_by",
                "tenant_filter",
                "combine",
            ],
        )
        columns_data = module_mappings_df["columns_mapped"].to_list()[0]
        main_update_table = module_mappings_df["main_update_table"].to_list()[0]
        tenant_filter = module_mappings_df["tenant_filter"].to_list()[0]
        try:
            tenant_filter = json.loads(tenant_filter)
        except Exception as e:
            logging.exception(f"### get_module_data tenant_filter exception : {e}")
            tenant_filter = []
        try:
            columns_data = json.loads(columns_data)
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        # logging.info('master_data_flag',master_data_flag)
        tables_list = module_mappings_df["tables_mapped"].to_list()[0]
        try:
            tables_list = json.loads(tables_list)
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        # logging.info('view_name',view_name)
        condition = module_mappings_df["condition"].to_list()[0]
        try:
            condition = json.loads(condition)
        except Exception as e:
            logging.exception(f"### get_module_data condition json exception : {e}")
            condition = {}

        drop_down_col = module_mappings_df["drop_down_col"].to_list()[0]
        try:
            drop_down_col = json.loads(drop_down_col)
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        order_by = module_mappings_df["order_by"].to_list()[0]
        try:
            order_by = json.loads(order_by)
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        combine_all = module_mappings_df["combine"].to_list()[0]
        try:
            combine_all = json.loads(combine_all)
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        # Check if tables_list is not empty
        if tables_list:
            for table in tables_list:

                if (
                    (module_name == "Bulk Change" or module_name == "Sim Order Form")
                    and customer
                    and (
                        table == "sim_management_bulk_change"
                        or table == "sim_order_form"
                    )
                ):
                    if table not in condition:
                        condition[table] = {}
                    condition[table]["created_by"] = users

                # if table is 'tenant' or 'users'
                if table in [
                    "tenant",
                    "roles",
                    "users",
                    "amop_apis",
                    "role_module",
                    "carrier_apis",
                    "mapping_table",
                    "master_amop_apis",
                    "master_carrier_apis",
                    "master_roles",
                    "module",
                    "tenant_module",
                    "module_features",
                ]:
                    current_db = db  # Use common_utils connection
                else:
                    current_db = database  # Use tenant-specific connection
                # Use order_by if current table is main_update_table
                if table == main_update_table:
                    if col_sort:
                        # Extract the single key-value pair
                        key, value = list(col_sort.items())[
                            0
                        ]  # Get the first and only pair
                        # Construct the ORDER BY clause
                        if table == "optimization_group" and key == "rate_plans_list":
                            # Modify the ordering logic for 'rate_plans_list'
                            order = {text("length(rate_plans_list)"): value.lower()}
                        else:
                            # Construct the ORDER BY clause for other columns
                            order = {key: value.lower()}
                    else:
                        order = order_by
                else:
                    order = None

                if tenant_filter:
                    temp = {}
                    if table in tenant_filter:
                        temp["tenant_id"] = str(tenant_id)
                        if table not in condition:
                            condition[table] = {}
                        condition[table].update(temp)

                if combine_all and table in combine_all:
                    combine = combine_all[table]
                else:
                    combine = []
                if (
                    drop_down_col
                    and columns_data
                    and table in drop_down_col
                    and table in columns_data
                ):
                    mod_pages = None
                else:
                    # Get pagination details from data
                    mod_pages = data.get("mod_pages", {})
                    logging.info("### mod_pages : {mod_pages}")
                # Fetch data based on table, condition, and columns
                if columns_data and table in columns_data and condition:
                    if table in condition:
                        ##fetching the data for the table using conditions
                        data_dataframe = current_db.get_data(
                            table,
                            condition[table],
                            columns_data[table],
                            order,
                            combine,
                            None,
                            mod_pages,
                        )
                    else:
                        ##fetching the data for the table using conditions
                        data_dataframe = current_db.get_data(
                            table,
                            {},
                            columns_data[table],
                            order,
                            combine,
                            None,
                            mod_pages,
                        )
                elif columns_data and table in columns_data:
                    ##fetching the data for the table using conditions
                    data_dataframe = current_db.get_data(
                        table, {}, columns_data[table], order, combine, None, mod_pages
                    )
                elif condition and table in condition and columns_data:
                    if table in columns_data:
                        ##fetching the data for the table using conditions
                        data_dataframe = current_db.get_data(
                            table,
                            condition[table],
                            columns_data[table],
                            order,
                            combine,
                            None,
                            mod_pages,
                        )
                    else:
                        ##fetching the data for the table using conditions
                        data_dataframe = current_db.get_data(
                            table,
                            condition[table],
                            None,
                            order,
                            combine,
                            None,
                            mod_pages,
                        )
                else:
                    ##fetching the data for the table using conditions
                    if table not in condition:
                        if table=='users' and role !='Super Admin':
                            data_dataframe = current_db.get_data(
                                table, {"tenant_id":tenant_id}, None, order, combine, None, mod_pages
                            )
                            def normalize_tenant_names(value):
                                if pd.isna(value) or value in ("None", None, ""):
                                    return []
                                try:
                                    # Try to parse if it's a JSON-style list string
                                    if isinstance(value, str) and value.strip().startswith("["):
                                        return json.loads(value)
                                    # Otherwise wrap single string into list
                                    return [value]
                                except Exception:
                                    return [str(value)]

                            # Apply normalization
                            # if username == "ajay2":
                            #     data_dataframe["tenant_name"] = data_dataframe["tenant_name"].apply(normalize_tenant_names)
                        else:
                            data_dataframe = current_db.get_data(
                                table, {}, None, order, combine, None, mod_pages
                            )
                    else:
                        data_dataframe = current_db.get_data(
                            table,
                            condition[table],
                            None,
                            order,
                            combine,
                            None,
                            mod_pages,
                        )
                # Handle dropdown columns differently
                if (
                    drop_down_col
                    and columns_data
                    and table in drop_down_col
                    and table in columns_data
                ):
                    for col in columns_data[table]:
                        # data_list[col]=data_dataframe[col].to_list()
                        data_list[col] = list(set(data_dataframe[col].tolist()))
                else:
                    if (
                        module_name == "Bulk Change"
                        and table == "sim_management_bulk_change"
                    ):
                        if "id" in data_dataframe.columns:
                            data_dataframe["bulk_change_id"] = data_dataframe["id"]
                    ##converting the dataframe to dict
                    df = data_dataframe.to_dict(orient="records")
                    if parent_module.lower() not in ("people"):
                        if "mod_pages" in data and table == main_update_table:
                            # Calculate pages
                            pages["start"] = data["mod_pages"]["start"]
                            pages["end"] = data["mod_pages"]["end"]
                            count_params = [table]
                            if module_name in (
                                "Sim Order Form",
                                "Feature Codes",
                                "Customer Rate Plan",
                            ):
                                count_query = "SELECT COUNT(*) FROM %s" % table
                            elif module_name=='Partner users' and role !='Super Admin':
                                count_query = f"SELECT COUNT(*) FROM %s where tenant_id={tenant_id}" % table

                            else:
                                count_query = (
                                    "SELECT COUNT(*) FROM %s where is_active=True"
                                    % table
                                )

                            count_result = current_db.execute_query(
                                count_query, count_params
                            ).iloc[0, 0]
                            pages["total"] = int(count_result)
                    # Add fetched data to data_list
                    data_list[table] = df
        message = "Data fetched successfully"

        new_data = {
            table: (
                values
                if values and isinstance(values[0], str)
                else [
                    {
                        key: (
                            str(value).split(".")[0]
                            if key == "modified_date"
                            else str(value)
                        )
                        for key, value in item.items()
                    }
                    for item in values
                ]
            )
            for table, values in data_list.items()
        }
        if module_name=='Communication plans':
            serviceprovider = database.get_data(
                    "serviceprovider",
                    {"is_active": True},
                    ["id", "service_provider_name"],order={"service_provider_name": "asc"}
                ).to_dict(orient="records")
            new_data["serviceprovider"] = serviceprovider

        if module_name == "Customer Rate Plan":
            # If columns are correct, select them as follows:
            try:
                json_data = load_json()
                telegence_ids = get_provider_ids(json_data, tenant_name, ["Telegence"])
                telegence_id = telegence_ids[0] if telegence_ids else None
                df = database.execute_query(
                    f"SELECT rate_plan_short_name,friendly_name FROM carrier_rate_plan WHERE is_active=True AND is_deleted=False AND service_provider_id={telegence_id} ORDER BY rate_plan_short_name, friendly_name",
                    True,
                ).to_dict(orient="records")

                # Check if the result is empty
                if not df:
                    new_data["soc_code"] = []
                else:
                    # Combine the required fields into a single string for each record
                    combined_list = [
                        f"{record['friendly_name']} - {record['rate_plan_short_name']}"
                        for record in df
                        if all(
                            key in record
                            for key in ["friendly_name", "rate_plan_short_name"]
                        )  # Ensure keys exist
                    ]

                    # Assign the list to 'soc_combined'
                    new_data["soc_code"] = combined_list

            except Exception as e:
                logging.warning(f"### Failed to fetch automation_rule data: {e}")
            try:
                df = database.get_data(
                    "customerrateplan",
                    {"is_active": True},
                    ["rate_plan_code", "service_provider_name"],
                ).drop_duplicates(subset=["rate_plan_code", "service_provider_name"])
                new_data["soc_list"] = (
                    df[["rate_plan_code", "service_provider_name"]]
                    .to_records(index=False)
                    .tolist()
                )
            except Exception as e:
                logging.warning(f"### Failed to fetch automation_rule data: {e}")
            try:
                automation_rule_list = database.get_data(
                    "automation_rule", {"is_active": True}, ["automation_rule_name"]
                )["automation_rule_name"].to_list()
                new_data["automation_rule"] = automation_rule_list
                service_provider_mapping = database.get_data(
                    "serviceprovider",
                    {"is_active": True},
                    ["id", "service_provider_name"],
                ).to_dict(orient="records")
                service_provider_mapping = {
                    item["service_provider_name"]: item["id"]
                    for item in service_provider_mapping
                }
                new_data["service_provider_mapping"] = service_provider_mapping
            except Exception as e:
                logging.warning(f"### Failed to fetch automation_rule data: {e}")
            # List of keys that need rounding
            keys_to_round = {
                "surcharge_3g",
                "base_rate",
                "rate_charge_amt",
                "sms_rate",
            }
            keys_with_dollar_symbol = {
                "base_rate",
                "rate_charge_amt",
                "sms_rate",
                "display_rate",
            }

            # Use a single loop for rounding and formatting
            for records in new_data.values():
                if isinstance(records, list):
                    for record in records:
                        if isinstance(record, dict):
                            for key in keys_to_round & record.keys():
                                value = record[key]
                                if isinstance(value, (int, float)):
                                    rounded_value = round(value, 2)
                                    record[key] = (
                                        f"${rounded_value}"
                                        if key in keys_with_dollar_symbol
                                        else rounded_value
                                    )
                                elif isinstance(value, str):
                                    try:
                                        rounded_value = round(float(value), 2)
                                        record[key] = (
                                            f"${rounded_value}"
                                            if key in keys_with_dollar_symbol
                                            else rounded_value
                                        )
                                    except ValueError:
                                        logging.warning(
                                            f"### Cannot round non-numeric string: {value}"
                                        )
        if module_name == "Active Customer Rate Plan":
            # If columns are correct, select them as follows:

            try:
                json_data = load_json()
                telegence_ids = get_provider_ids(json_data, tenant_name, ["Telegence"])
                telegence_id = telegence_ids[0] if telegence_ids else None
                df = database.execute_query(
                    f"SELECT rate_plan_short_name,friendly_name FROM carrier_rate_plan WHERE is_active=True AND is_deleted=False AND service_provider_id={telegence_id} ORDER BY rate_plan_short_name, friendly_name",
                    True,
                ).to_dict(orient="records")

                # Check if the result is empty
                if not df:
                    new_data["soc_code"] = []
                else:
                    # Combine the required fields into a single string for each record
                    combined_list = [
                        f"{record['friendly_name']} - {record['rate_plan_short_name']}"
                        for record in df
                        if all(
                            key in record
                            for key in ["friendly_name", "rate_plan_short_name"]
                        )  # Ensure keys exist
                    ]

                    # Assign the list to 'soc_combined'
                    new_data["soc_code"] = combined_list
            except Exception as e:
                logging.warning(f"### Failed to fetch automation_rule data: {e}")
            try:
                df = database.get_data(
                    "customerrateplan",
                    {"is_active": True},
                    ["rate_plan_code", "service_provider_name"],
                ).drop_duplicates(subset=["rate_plan_code", "service_provider_name"])
                new_data["soc_list"] = (
                    df[["rate_plan_code", "service_provider_name"]]
                    .to_records(index=False)
                    .tolist()
                )
            except Exception as e:
                logging.warning(f"### Failed to fetch automation_rule data: {e}")
            try:
                automation_rule_list = database.get_data(
                    "automation_rule", {"is_active": True}, ["automation_rule_name"]
                )["automation_rule_name"].to_list()
                new_data["automation_rule"] = sorted(automation_rule_list)
                service_provider_mapping = database.get_data(
                    "serviceprovider",
                    {"is_active": True},
                    ["id", "service_provider_name"],
                ).to_dict(orient="records")
                service_provider_mapping = {
                    item["service_provider_name"]: item["id"]
                    for item in service_provider_mapping
                }
                new_data["service_provider_mapping"] = service_provider_mapping
            except Exception as e:
                logging.warning(f"### Failed to fetch automation_rule data: {e}")
            # List of keys that need rounding
            keys_to_round = {
                "surcharge_3g",
                "base_rate",
                "rate_charge_amt",
                "sms_rate",
                "overage_rate_cost",
            }
            keys_with_dollar_symbol = {
                "base_rate",
                "rate_charge_amt",
                "sms_rate",
                "overage_rate_cost",
                "display_rate",
            }

            # Use a single loop for rounding and formatting
            for records in new_data.values():
                if isinstance(records, list):
                    for record in records:
                        if isinstance(record, dict):
                            for key in keys_to_round & record.keys():
                                value = record[key]
                                if isinstance(value, (int, float)):
                                    rounded_value = round(value, 2)
                                    record[key] = (
                                        f"${rounded_value}"
                                        if key in keys_with_dollar_symbol
                                        else rounded_value
                                    )
                                elif isinstance(value, str):
                                    try:
                                        rounded_value = round(float(value), 2)
                                        record[key] = (
                                            f"${rounded_value}"
                                            if key in keys_with_dollar_symbol
                                            else rounded_value
                                        )
                                    except ValueError:
                                        logging.warning(
                                            f"### Cannot round non-numeric string: {value}"
                                        )
        if module_name == "Bulk Change":
            new_data = {
                table: [
                    {
                        **{
                            key: (
                                int(float(value))
                                if key in ["errors", "uploaded", "success"]
                                and value.replace(".", "", 1).isdigit()
                                and not value.endswith(".")
                                else value
                            )
                            for key, value in item.items()
                        }
                    }
                    for item in values
                ]
                for table, values in new_data.items()
            }

        if not flag:
            # calling get header to get headers mapping
            headers_map = get_headers_mapping(
                tenant_database,
                [module_name],
                role,
                username,
                tenant_id,
                sub_parent_module,
                parent_module,
                data,
                db,
            )
            # Convert timestamps to string format before returning
            new_data = convert_timestamp_datadict(new_data, tenant_time_zone)
            try:
                # Attempt to retrieve the value from the 'tenant' table
                cross_carrier_optimization = database.get_data(
                    "optimization_setting",
                    {"tenant_id":tenant_id},
                    ["optino_cross_providercustomer_optimization"],
                )["optino_cross_providercustomer_optimization"].to_list()[0]
            except Exception as e:
                logging.exception(f"### Failed to get the cross_carrier_optimization{e}")
                cross_carrier_optimization = False
            response = {
                "flag": True,
                "message": message,
                "data": serialize_data(new_data),
                "pages": pages,
                "features": features,
                "headers_map": headers_map,
                "cross_carrier_optimization":cross_carrier_optimization
            }
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            try:
                audit_data_user_actions = {
                    "service_name": "get_module_data",
                    "created_by": username,
                    "status": str(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "session_id": session_id,
                    "tenant_name": Partner,
                    "comments": "module data fetched successfully",
                    "module_name": "Module Management",
                    "request_received_at": request_received_at,
                }
                db.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### Exception is : {e}")
            return response
        else:
            return serialize_data(new_data), pages
    except Exception as e:
        logging.warning(f"### Something went wrong while fetching module data and error is : {e}")
        message = "Something went wrong while fetching module data"
        # response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_module_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "Module Managament",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Exception is : {e}")
        # calling get header to get headers mapping
        headers_map = get_headers_mapping(
            tenant_database, [module_name], role, username, "", "", "", data, db
        )
        response = {
            "flag": True,
            "message": message,
            "data": {},
            "pages": {},
            "features": {},
            "headers_map": headers_map,
        }
        return response


def user_data(data):
    """
    Retrieves user-specific module access and role-module mappings from the database.

    Args:
        data (dict): A dictionary containing:
            - user_name (str): The username to fetch user-specific module access for.
            - user_tenant_name (str): The tenant name associated with the user.
            - role_name (str, optional): Role name; defaults to "Agent".
            - username (str, optional): Used in audit logging.
            - tenant_name (str, optional): Used in audit logging and error tracking.

    Returns:
        dict: A dictionary with:
            - flag (bool): True if the data was fetched successfully (even if empty).
            - user_specific_data (list): List of dicts containing sub_module, module_names,
              and module_features parsed from DB. Empty if not found.
            - role_module (list): Role-based module access configuration from DB.
            - message (str, optional): Message indicating status or error (only on failure).
    """
    logging.info("### Starting to retrieve user data.")
    try:
        try:
            del db_config['customers']
            del db_config['service_providers']
            del db_config['billing_account_number']
            del db_config['feature_codes']
            del db_config['tenant_ids']
        except Exception as e:
            logging.info(f'### Exception is : {e}')

        # Extracting parameters from the input data
        user_name = data.get("user_name", None)
        user_tenant_name=data.get("user_tenant_name","")
        # tenant_database = data.get("db_name", None)
        # database = DB(tenant_database, **db_config)  # Connect to tenant database
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **db_config
        )  # Connect to common utils database
        user_tenant_id=common_utils_database.get_data("tenant",{"tenant_name":user_tenant_name},['id'])['id'].to_list()[0]
        user_tenant_id=int(user_tenant_id)
        role_name = data.get(
            "role_name", "Agent"
        )  # Default to 'Agent' if no role_name provided
        logging.info(f"### Fetching role modules for role: {role_name}")

        # Fetch role modules from the tenant database
        role_module = common_utils_database.get_data(
            "role_module", {"role": role_name}
        ).to_dict(orient="records")

        logging.info(f"### Retrieved role modules : {role_module}")

        # Fetch user-specific data from the common utils database
        logging.info(f"### Fetching user-specific data for user: {user_name}")
        user_specific_data = common_utils_database.get_data(
            "user_module_tenant_mapping",
            {"user_name": user_name,"tenant_id":user_tenant_id},
            ["sub_module", "module_names", "module_features"],
        ).to_dict(orient="records")
        logging.info(f"### Retrieved user-specific data: {user_specific_data} ")

        # Check if user_specific_data is empty and return role module if so
        if not user_specific_data:
            logging.warning(f"### No user-specific data found for user: {user_name}")
            response = {
                "flag": True,
                "user_specific_data": [],  # Empty list if no data found
                "role_module": role_module,  # Include the role_module data
            }
            return response

        # Process the JSON fields in the user-specific data
        for item in user_specific_data:
            item["sub_module"] = json.loads(item["sub_module"]) if isinstance(item.get("sub_module"), str) else {}
            item["module_names"] = json.loads(item["module_names"]) if isinstance(item.get("module_names"), str) else []
            item["module_features"] = json.loads(item["module_features"]) if isinstance(item.get("module_features"), str) else []


        # Prepare the final response
        response = {
            "flag": True,  # Indicate that the operation was successful
            "user_specific_data": user_specific_data,
            "role_module": role_module,
        }
        logging.info("### Final response data prepared successfully.")
        try:
            audit_data_user_actions = {
                "service_name": "user_data",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "module_name": "Module management",
                "comments": "user data fetched successfully",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
             logging.warning(f"### Audit logging exception: {e}")
        return response

    except Exception as e:
        # Handle exceptions by logging the error and returning a default response
        logging.exception(f"### Exception is when fetching the user data: {e}")
        response = {
            "flag": True,  # Indicate failure due to exception
            "user_specific_data": [],  # Empty list if an error occurred
            "role_module": [],  # Empty list if an error occurred
        }
        message = "Something went wrong while fetching Partner info"
        response = {"flag": True, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "user_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": message,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}")
        return response



def customers_dropdown_data(data):
    """
    Retrieves customer dropdown data for active service providers and available feature codes.

    Args:
        data (dict): A dictionary containing:
            - db_name (str, optional): Name of the target tenant database.
            - username (str, optional): Name of the user requesting data.
            - sessionID (str, optional): Session ID for audit logging.
            - tenant_name (str, optional): Tenant name for audit logging.

    Returns:
        dict: A dictionary with:
            - flag (bool): True if data retrieval was successful, False otherwise.
            - service_provider_customers (dict): Mapping of service provider names to lists of customer names.
            - feature_codes (list): List of unused, unique feature codes.
    """
    # Set the default database name to 'altaworx_central' if not provided
    tenant_database = data.get("db_name", "altaworx_central")
    database = DB(tenant_database, **db_config)  # Connect to the tenant database
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    logging.info(f"### customers_dropdown_data Request Received : {data}")

    try:
        # Fetch all active service providers with their IDs (only AT&T - Telegence - UAT ONLY)
        env=os.environ["ENV"]
        if env=='PROD':
            service_provider_names = "AT&T - Telegence"
        else:
            service_provider_names = "AT&T - Telegence - UAT ONLY"
        service_providers_df = database.get_data(
            "serviceprovider",
            {"is_active": True, "service_provider_name": service_provider_names},
            ["id", "service_provider_name"],
        )
        # Extract service provider IDs and names
        service_provider_ids = service_providers_df["id"].to_list()
        service_provider_names = service_providers_df["service_provider_name"].to_list()

        # Fetch all tenant configurations for the active service providers
        tenant_ids_df = database.get_data(
            "service_provider_tenant_configuration",
            {
                "service_provider_id": service_provider_ids
            },  # Batch query for relevant service provider IDs
            ["service_provider_id", "tenant_id"],
        )

        # Fetch all customers for the retrieved tenant IDs
        tenant_ids = tenant_ids_df["tenant_id"].to_list()
        customers_df = database.get_data(
            "customers",
            {"tenant_id": tenant_ids, "is_active": True},  # Only active customers
            ["tenant_id", "customer_name"],
        )

        # Initialize a dictionary to map service providers to their customers
        service_provider_customers = {}
        for index, row in customers_df.iterrows():
            tenant_id = row["tenant_id"]
            customer_name = row["customer_name"]
            # Find the associated service provider ID for the customer
            service_provider_id = tenant_ids_df[
                tenant_ids_df["tenant_id"] == tenant_id
            ]["service_provider_id"].to_list()

            if service_provider_id:
                service_provider_id = service_provider_id[
                    0
                ]  # Assuming a one-to-one mapping between service provider and tenant
                service_provider_name = service_provider_names[
                    service_provider_ids.index(service_provider_id)
                ]

                # Append the customer to the respective service provider's list
                if service_provider_name not in service_provider_customers:
                    service_provider_customers[service_provider_name] = []
                service_provider_customers[service_provider_name].append(customer_name)

        # Fetch feature codes (if required)
        feature_codes = database.get_data("mobility_feature", {"is_active": True}, ["soc_code"])[
            "soc_code"
        ].to_list()
        feature_codes = list(set(feature_codes))
        used_feature_codes = database.get_data(
            "sim_management_carrier_feature_codes_uat",
            {"is_active": True},
            ["feature_codes"],
        )["feature_codes"].to_list()
        # Prepare the final response with unique feature codes

        final_feature_codes = [
            item for item in feature_codes if item not in used_feature_codes
        ]

        response = {
            "flag": True,
            "service_provider_customers": service_provider_customers,
            "feature_codes": list(
                set(final_feature_codes)
            ),  # Ensure feature codes are unique
        }
        try:
            audit_data_user_actions = {
                "service_name": "customer_dropdown_data",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "module_name": "Module management",
                "comments": "fetched customers dropdown data successfully",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
        return response

    except Exception as e:
        # Log exception and return a response indicating failure
        logging.exception(f"### Exception occurred while fetching customer dropdown data: {e}")
        message = "Something went wrong while fetching customer dropdown data"
        response = {"flag": True, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "customer_dropdown_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": message,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Exception is : {e}")
        return {"flag": False, "service_provider_customers": {}, "feature_codes": []}


def rate_plan_dropdown_data(data):
    """
    Retrieves active carrier rate plan dropdown values grouped by service provider.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Name of the tenant database.
            - username (str, optional): Name of the user requesting the data.
            - tenant_name (str, optional): Tenant name for audit and error records.

    Returns:
        dict: A dictionary with the following structure:
            - flag (bool): True if rate plans are fetched successfully, False otherwise.
            - carrier_rate_plans (dict): 
                Mapping of service provider names to lists of formatted strings 
                (e.g., "Friendly Name -- RP123") for dropdown use.
            - carrier_rate_plan_codes (dict): 
                Mapping of service provider names to raw rate plan codes.
    """
    try:
        # Get the tenant database name from input data
        tenant_database = data.get("db_name", None)
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **db_config
        )  # Connect to common utils database
        database = DB(tenant_database, **db_config)  # Connect to the tenant database

        # Fetch all unique active service provider names
        serviceproviders = database.get_data(
            "serviceprovider", {"is_active": True}, ["service_provider_name"]
        )["service_provider_name"].to_list()

        # Ensure uniqueness by converting to a set and back to a list
        service_provider_names = list(set(serviceproviders))

        # Initialize an empty dictionary to store rate plans for each service provider
        rate_plans_list = {}
        rate_plan_code_dict = {}

        # Iterate over each service provider name
        for service_provider_name in service_provider_names:
            # Fetch the active rate plan codes for the current service provider
            carrier_data_query = f'''
                    select friendly_name,rate_plan_code from carrier_rate_plan
                    where service_provider='{service_provider_name}' and is_active=True
                    order by friendly_name asc
                '''
            carrier_data = database.execute_query(carrier_data_query, True)
            
            
            # Handle null values in friendly_name by combining with rate_plan_code
            carrier_data['temp_name'] = carrier_data['friendly_name'].fillna('') + ' -- ' + carrier_data['rate_plan_code'].fillna('')
            
            # Ensure the list is not empty and contains valid entries
            rate_plan_items = carrier_data['temp_name'].to_list()
            carrier_rate_plan_code = carrier_data["rate_plan_code"].to_list()

            # Add the rate plans to the dictionary under the respective service provider
            rate_plans_list[service_provider_name] = rate_plan_items
            rate_plan_code_dict[service_provider_name] = carrier_rate_plan_code

        # Return the final dictionary containing service providers and their rate plans
        response = {"flag": True, "carrier_rate_plans": rate_plans_list,"carrier_rate_plan_codes":rate_plan_code_dict}
        try:
            audit_data_user_actions = {
                "service_name": "rate_plan_dropdown_data",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "module_name": "Module management",
                "comments": "fetched rate plan dropdown data successfully",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
        return response 
    except Exception as e:
        message = "Something went wrong while fetching rate plan dropdown data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "rate_plan_dropdown_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
        return {"flag": False, "carrier_rate_plans": []}


def form_Partner_module_access(tenant_id, module_data):
    """
    Description:
    Forms access information for a specific tenant by filtering and organizing modules.

    This function processes tenant-specific module data and structures it
    for use in the system.

    Args:
    - tenant_id (str or int): The tenant ID for which module access is being processed.
    - module_data (dict): The module data containing 'tenant_module' and 'module' information.

    Returns:
    - dict: A modified dictionary with tenant-specific module access details.
    """
    # Extract 'tenant_module' from module_data, which contains information on the modules
    tenant_module = module_data.get("tenant_module", [])

    # Initialize a list to store the module names assigned to the specified tenant
    modules_names = []

    # Filter modules for the specific tenant_id and store module names in the list
    for data_item in tenant_module:
        if str(data_item["tenant_id"]) == str(tenant_id):
            modules_names.append(data_item["module_name"])
            logging.info(f"### Matched tenant_id: {tenant_id} with module_name: {data_item['module_name']}")


    # Extract 'module' data which contains details about the parent-child module structure
    modules_data = module_data.get("module", [])

    # Initialize lists and dictionaries to structure the modules
    return_modules = []
    modules = {}
    logging.info(f"### Filtered modules names for tenant_id {tenant_id}: {modules_names}")

    # Organize modules by their parent module and filter out the "Super admin" module
    for data_item in modules_data:
        parent_module_name = data_item.get("parent_module_name", None)

        # Skip items with no parent module name or with 'None' as the parent
        if not parent_module_name or parent_module_name == "None":
            continue

        # Add parent module name to return_modules if not already added
        if parent_module_name not in return_modules:
            return_modules.append(parent_module_name)

        # Initialize an empty list for each parent module in the 'modules' dictionary
        if parent_module_name not in modules:
            modules[parent_module_name] = []

        # Append the module name under its parent module in the dictionary
        modules[parent_module_name].append(data_item["module_name"])

    # List of modules to remove from the final response (e.g., "Super admin")
    modules_to_remove = {"Super admin"}

    # Remove "Super admin" from return_modules if it exists
    return_modules = [
        module for module in return_modules if module not in modules_to_remove
    ]

    # Remove "Super admin" from the 'modules' dictionary if it exists
    if "Super admin" in modules:
        del modules["Super admin"]

    # Update module_data with the processed modules
    module_data["tenant_module"] = return_modules
    module_data["module"] = modules_dict()

    # Log the final structure of module_data
    logging.info(f"### Final module_data structure: {module_data}")

    # Return the modified module_data containing the tenant-specific access information
    return module_data


def modules_dict():
    """
    Retrieves and structures module mappings from the 'common_utils' database.

    This function:
    - Queries the `module` table to extract `parent_module_name`, `module_name`, and `submodule_name`.
    - Organizes them into a hierarchical dictionary grouped by `parent_module_name`.
    - Adds `submodule_name` if present, otherwise includes `module_name`.
    - Falls back to including the `parent_module_name` itself if both are absent.

    Returns:
        dict: A dictionary where:
            - Keys are `parent_module_name`s.
            - Values are lists of `submodule_name`s or `module_name`s belonging to that parent.

    """
    logging.info("### Starting the retrieval of module mappings.")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    # Step 1: Retrieve the data
    module_mappings_df = common_utils_database.get_data(
        "module", {}, ["parent_module_name", "module_name", "submodule_name"], {"order_by": "asc"}
    )
    logging.info(f"### Retrieved module mappings data: {module_mappings_df}")

    # Step 2: Create the desired output format
    result = {}

    for _, row in module_mappings_df.iterrows():
        parent = row["parent_module_name"]
        module = row["module_name"]
        submodule = row["submodule_name"]

        # Initialize the list for the parent module if it doesn't exist
        if parent not in result:
            result[parent] = []
            logging.info(f"### Initialized list for parent module: {parent}")

        # Include submodule_name if it exists, otherwise include module_name
        if submodule and submodule not in result[parent]:
            result[parent].append(submodule)
            logging.info(f"### Added submodule: {submodule} to parent module: {parent}")

        elif not submodule and module and module not in result[parent]:
            result[parent].append(module)
            logging.info(f"### Added module: {module} to parent module: {parent}")

        # If both module_name and submodule_name are absent, add parent_module_name
        elif not module and not submodule and parent not in result[parent]:
            result[parent].append(parent)
            logging.info(f"### Added parent module name: %s to itself : {parent}")

    formatted_result_json = result
    logging.info(f"###Successfully formatted the result:  {formatted_result_json}")

    return formatted_result_json


def get_user_module_map(data):
    """
    Description:
    This function retrieves the module mapping for a user based on their role
    and tenant information. It first checks if a user-specific mapping exists
    in the database. If not, it falls back to role-based mappings.

    Parameters:
    - data (dict): A dictionary containing the user's information:
      - 'username' (str): The username of the user.
      - 'role' (str): The role assigned to the user.
      - 'tenant_name' (str): The tenant name under which the user operates.
      - 'db_name' (str): The name of the tenant-specific database.

    Returns:
    - dict: A dictionary containing the result of the operation:
      - 'flag' (bool): Indicates if the operation was successful (True) or failed (False).
      - 'data' (dict): The module mapping data, which can either be user-specific or role-based.
    """
    logging.info(f"### Request Data: {data}")
    try:
        # Extract username, role, and tenant_name from the input data dictionary
        username = data.get("username", None)
        role = data.get("role", None)
        tenant_name = data.get("tenant_name", None)
        # Initialize the database connection
        tenant_database = data.get("db_name", None)
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        return_dict = {}
        # Retrieve tenant_id based on tenant_name
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]
        flag = False
        # Fetch the user-module mapping from the database
        user_map = database.get_data(
            "user_module_tenant_mapping",
            {"user_name": username, "tenant_id": tenant_id},
            ["module_names", "sub_module", "module_features"],
        ).to_dict(orient="records")
        # Check if a user-specific module map exists
        if user_map:
            user_map = user_map[0]
            logging.info(f"### User map found: {user_map}")
            for key, value in user_map.items():
                if value:
                    flag = True
                    break
            if flag:
                # Rename 'module_names' to 'module'
                return_dict = user_map
                return_dict["module"] = user_map["module_names"]
                return_dict.pop("module_names")
                logging.info(f"### Returning user-specific module mapping: {return_dict}")
            else:
                # If the user map is empty, fall back to role-based mapping
                return_dict = common_utils_database.get_data(
                    "role_module",
                    {"role": role},
                    ["module", "sub_module", "module_features"],
                ).to_dict(orient="records")
                logging.info(f"### User map is empty; falling back to role-based mapping: {return_dict}")
        else:
            # If no user-specific map is found, retrieve the role-based module map
            return_dict = common_utils_database.get_data(
                "role_module",
                {"role": role},
                ["module", "sub_module", "module_features"],
            ).to_dict(orient="records")
            logging.info(f"### No user-specific map found; retrieved role-based mapping: {return_dict}")

        response = {"flag": True, "data": return_dict}    
        try:
            audit_data_user_actions = {
                "service_name": "get_user_module_map",
                "created_by": username,  
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "module_name": "Module management",
                "comments": "fetched user module map successfully",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
        return response

    except Exception as e:
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error in fetching user module map data : {e}")
        message = "Something went wrong while fetching user module map data "
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_user_module_map",
                "error_message":str(e),
                "error_type": error_type,
                "users": username,
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
 
        response = {"flag": False, "data": {}}
        return response


def get_partner_info(data):
    """
    Retrieves and returns partner-related information based on the user's role, modules list, and tenant details.

    This function handles role-based module data collection, partner/tenant metadata,
    customer groups, users, module access, authentication info, and more. It also logs audit and error data for tracking.

    Parameters:
    ----------
    data : dict
        Dictionary containing the input parameters. Expected keys include:
        - tenant_name (str): Current tenant's name
        - db_name (str): Database name for tenant-specific operations
        - role_name (str): User's role (e.g., 'Super Admin')
        - modules_list (list): List of modules to fetch data for (e.g., 'Partner info', 'Customer groups')
        - pages (dict): Module-wise pagination info (optional)
        - parent_module, sub_parent_module: Module hierarchy (optional)
        - firstLastName (str): Full name of user (used for filtering customergroups)

    Returns:
    -------
    dict
        A dictionary containing:
        - flag (bool): True if data was fetched successfully, False otherwise
        - data (dict): Serialized partner/module data structured by module name
        - headers_map (dict): Column header mapping for UI display
        - message (str): Informational message
    """
    # Start time  and date calculation
    start_time = time.time()
    # logging.info(f"Request Data: {data}")
    ##Restriction Check for the Amop API's
    try:
        # Create an instance of the PermissionManager class
        permission_manager_instance = PermissionManager(db_config)

        # Call the permission_manager method with the data dictionary and validation=True
        result = permission_manager_instance.permission_manager(data, validation=True)

        # Check the result and handle accordingly
        if isinstance(result, dict) and result.get("flag") is False:
            return result
        else:
            # Continue with other logic if needed
            pass
    except Exception:
        logging.warning("### got exception in the restriction")

    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    Partner = data.get("Partner", "")
    ##database connection
    tenant_database = data.get("db_name", None)
    database = DB(tenant_database, **db_config_withoutfilter)
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    username = data.get("username", None)
    tenant_name = data.get("tenant_name", None)
    session_id = data.get("session_id", None)
    col_sort = data.get("col_sort", "")
    # role = data.get('role_name', None)
    role = data.get("role_name") or data.get("role") or "Super Admin"
    modules_list = data.get("modules_list", None)
    parent_module = data.get("parent_module", None)
    sub_parent_module = data.get("sub_parent_module", None)

    # # Get tenant's timezone
    tenant_time_zone = fetch_tenant_timezone(db, data)

    try:
        counts = {}
        returning_partner_module_data = {}
        partner = tenant_name
        sub_partner = ""
        tenant_df = db.get_data(
            "tenant",
            {"tenant_name": tenant_name},
            [
                "parent_tenant_id",
                "id",
                "email_ids",
                "logo",
                "dark_mode_collapsed_logo",
                "dark_mode_logo",
                "collapsed_logo",
                "service_provider_to",
                "service_provider_status",
                "billing_platform_flag"
            ],
        )
        parent_tenant_id = tenant_df["parent_tenant_id"].to_list()[0]
        tenant_id = tenant_df["id"].to_list()[0]
        email_id = tenant_df["email_ids"].to_list()[0]
        service_provider_to = tenant_df["service_provider_to"].to_list()[0]
        service_provider_status = tenant_df["service_provider_status"].to_list()[0]
        logo = tenant_df["logo"].to_list()[0]
        dark_mode_logo = tenant_df["dark_mode_logo"].to_list()[0]
        collapsed_logo = tenant_df["collapsed_logo"].to_list()[0]
        dark_mode_collapsed_logo= tenant_df["dark_mode_collapsed_logo"].to_list()[0]
        billing_platform_flag = tenant_df["billing_platform_flag"].to_list()[0]
        if parent_tenant_id:
            sub_partner = tenant_name
            partner = db.get_data("tenant", {"id": parent_tenant_id}, ["tenant_name"])[
                "tenant_name"
            ].to_list()[0]

        # formating data for partner info
        if "Partner info" in modules_list:
            try:
                # Load email_id if it's a JSON string
                email_id = json.loads(email_id)
            except Exception as e:
                logging.warning(f"### Exception is : {e}")

            if col_sort:
                # Extract the single key-value pair
                key, value = list(col_sort.items())[0]  # Get the first and only pair
                # Construct the ORDER BY clause
                order_condition = f"ORDER BY {key} {value.upper()}"
            else:
                # If users is None or empty, we skip the WHERE clause entirely
                order_condition = ""

            # Fetch the required tenant information including addresses
            query = f"""
                SELECT
                    billing_address_1,
                    billing_address_2,
                    billing_city,
                    billing_state,
                    billing_zip_code,
                    billing_notes,
                    cross_provider_customer_optimization,
                    physical_address_1,
                    physical_addresss_2,
                    physical_apt_or_suite,
                    physical_city,
                    physical_state,
                    physical_zip_code,
                    physical_country,
                    physical_county,
                    sendgrid_api,
                    from_email,
                    time_zone,
                    change_phone_number_frequency_setting

                FROM
                    tenant
                WHERE
                    tenant_name = '{tenant_name}'
                    {order_condition}
                """
            # params = [tenant_name]

            # Execute the query with the tenant_name as a parameter
            tenant_info = db.execute_query(query, True)

            # Convert the result to a dictionary (assuming tenant_info is a DataFrame)
            tenant_info_dict = (
                tenant_info.to_dict(orient="records")[0]
                if not tenant_info.empty
                else {}
            )

            # Prepare the tenant names list
            tenant_names = db.get_data("tenant", {"is_active": True}, ["tenant_name"])[
                "tenant_name"
            ].to_list()

            # Add partner info along with addresses
            returning_partner_module_data["Partner info"] = {
                "partner": partner,
                "sub_partner": sub_partner,
                "email_id": email_id,
                "logo": logo,
                "dark_mode_logo": dark_mode_logo,
                "collapsed_logo": collapsed_logo,
                "dark_mode_collapsed_logo": dark_mode_collapsed_logo,
                "service_provider_to": service_provider_to,
                "service_provider_status": service_provider_status,
                **tenant_info_dict,  # Merge tenant info dictionary into the partner info
                "tenant_names": tenant_names,
                "billing_platform_flag": billing_platform_flag
            }

            # Remove "Partner info" from modules_list to avoid redundant processing
            modules_list.remove("Partner info")

        # formating data for athentication
        if "Partner authentication" in modules_list:
            returning_partner_module_data["Partner authentication"] = {}
            modules_list.remove("Partner authentication")
            try:
                db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
                query = """SELECT * FROM partner_authentication"""
                partner_auth_data = db.execute_query(query, True)

                # Convert the result to a list of dictionaries (key-value pairs)
                partner_auth_dict_list = partner_auth_data.to_dict(orient="records")

                # Ensure the data is sent as an object (not a list)
                if partner_auth_dict_list:
                    partner_auth_dict = partner_auth_dict_list[
                        0
                    ]  # Extract the first dictionary (object)
                else:
                    partner_auth_dict = {}

                # Add the partner authentication data to the response dictionary as an object
                returning_partner_module_data["Partner authentication"] = (
                    partner_auth_dict
                )

                # Add the partner authentication data to the response dictionary
                returning_partner_module_data["Partner authentication"] = (
                    partner_auth_dict
                )

                # Remove "Partner authentication" from modules_list to avoid redundant processing
                modules_list.remove("Partner authentication")

            except Exception as e:
                logging.warning(f"### Failed to fetch Partner authentication data: {e}")

        for module in modules_list:
            data["module_name"] = module
            if module in data["pages"]:
                data["mod_pages"] = data["pages"][module]
            module_data, pages = get_module_data(data, True)
            if pages:
                counts[module] = {
                    "start": pages["start"],
                    "end": pages["end"],
                    "total": pages["total"],
                }
            # formating data for Partner module Access
            if module == "Partner module access":
                module_data = form_Partner_module_access(tenant_id, module_data)
                filtered_roles = [
                    role for role in module_data["role_name"] if role != "Super Admin"
                ]
                role_df = db.get_data(
                    "roles", {"tenant_id": tenant_id, "is_active": True}, ["role_name"]
                )
                # Filter role_df to include only roles in filtered_roles
                filtered_role_df = role_df[role_df["role_name"].isin(filtered_roles)]
                # Update module_data with unique role names from the filtered roles
                module_data["role_name"] = list(set(filtered_role_df["role_name"]))
                try:
                    role_module_query = "select * from role_module"
                    role_module_dataframe = db.execute_query(
                        role_module_query, True
                    ).to_dict(orient="records")
                    module_data["role_module"] = role_module_dataframe
                except Exception as e:
                    logging.warning(f"### Exception in fetching role_module: {e}")
                    pass
                tenant_modules = db.get_data(
                    table_name="tenant_module",
                    condition={"tenant_name": tenant_name, "is_active": True},
                    columns=["tenant_id", "module_name"],
                    order={"id": "asc"},
                ).to_dict(orient="records")
                # Extract module names into a list
                module_list = [module["module_name"] for module in tenant_modules]
                module_list = [
                    module for module in module_list if module != "Super admin"
                ]
                module_data["tenant_module"] = module_list
            # formating data for Customer groups
            if module == "Customer groups":
                module_data_new = {}
                module_data_new["customer_names"] = []
                module_data_new["billing_account_number"] = []

                if col_sort:
                    # Extract the single key-value pair
                    key, value = list(col_sort.items())[
                        0
                    ]  # Get the first and only pair
                    # Construct the ORDER BY clause
                    order_condition = f"ORDER BY {key} {value.upper()}"
                else:
                    # If col_sort is None or empty, skip the WHERE clause entirely
                    order_condition = ""
                # Loop through each dictionary in the list
                for dic in module_data["customers"]:
                    # Create new dictionaries for each key-value pair
                    first_key, first_value = list(dic.items())[0]
                    second_key, second_value = list(dic.items())[1]
                    if first_key == "billing_account_number":
                        if first_value and first_value != "None":
                            module_data_new["billing_account_number"].append(
                                first_value
                            )
                        if second_value and second_value != "None":
                            module_data_new["customer_names"].append(second_value)
                    else:
                        if first_value and first_value != "None":
                            module_data_new["customer_names"].append(first_value)
                        if second_value and second_value != "None":
                            module_data_new["billing_account_number"].append(
                                second_value
                            )
                module_data.update(module_data_new)
                module_data.pop("customers")
                tenant_data = db.get_data(
                "tenant", {"tenant_name": tenant_name},
                ["id","parent_tenant_id"]
                )

                tenant_id = tenant_data["id"].to_list()[0]
                parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
                if tenant_id:
                    tenant_id=int(tenant_id)
                logging.info(f"### parent_tenant_idparent_tenant_idparent_tenant_id : {parent_tenant_id}")
                if parent_tenant_id and role  in ("Super Admin"):
                    customergroupquery='''select id,name,CASE
                                            WHEN parent_tenant_name IS NOT NULL THEN parent_tenant_name
                                            ELSE tenant_name
                                        END AS tenant_name,
                                        CASE
                                            WHEN parent_tenant_name IS NOT NULL THEN tenant_name
                                            ELSE NULL
                                        END AS sub_tenant_name,customergroup_id,tenant_id,subtenant_id,
                                        subtenant_name,child_account,billing_account_number,rate_plan_name,
                                        feature_codes,created_by,created_date,deleted_by,deleted_date,modified_by,
                                        modified_date,is_active,is_deleted,customer_names,id_10,notification_rules 
                                        from customergroups where  is_active=True order by name asc limit 100
                    '''
                    customergroups=database.execute_query(customergroupquery,True).to_dict(orient='records')
                elif parent_tenant_id and role not  in ("Super Admin"):
                    user_first_last_name = data.get('firstLastName',None)
                    ##user customergroups
                    user_customer_group_query = f"""
                        SELECT customer_group
                        FROM user_module_tenant_mapping
                        WHERE user_name = '{username}'
                        AND tenant_id = {tenant_id}
                    """
                    user_customer_group = db.execute_query(
                        user_customer_group_query, True
                    )['customer_group'].to_list()

                    ##created customer groups
                    created_customer_groups_query = f"""
                        SELECT name AS customer_group
                        FROM customergroups
                        WHERE created_by = '{user_first_last_name}'
                    """
                    created_customer_groups = database.execute_query(
                        created_customer_groups_query, True
                    )['customer_group'].to_list()

                    # Append the two lists
                    user_customer_group.extend(created_customer_groups)
                    # Now build the query using the combined list
                    # We'll use a Python-safe way to format the IN clause:
                    placeholders = ', '.join(f"'{cg}'" for cg in user_customer_group)
                    customergroupquery=f'''select id,name,CASE
                                            WHEN parent_tenant_name IS NOT NULL THEN parent_tenant_name
                                            ELSE tenant_name
                                        END AS tenant_name,
                                        CASE
                                            WHEN parent_tenant_name IS NOT NULL THEN tenant_name
                                            ELSE NULL
                                        END AS sub_tenant_name,customergroup_id,tenant_id,subtenant_id,
                                        subtenant_name,child_account,billing_account_number,rate_plan_name,
                                        feature_codes,created_by,created_date,deleted_by,deleted_date,modified_by,
                                        modified_date,is_active,is_deleted,customer_names,id_10,notification_rules  from customergroups where tenant_id='{tenant_id}' and name IN ({placeholders})and is_active=True order by name asc limit 100'''
                    customergroups=database.execute_query(customergroupquery,True).to_dict(orient='records')
                else:
                    customergroupquery='''select id,name,CASE
                                            WHEN parent_tenant_name IS NOT NULL THEN parent_tenant_name
                                            ELSE tenant_name
                                        END AS tenant_name,
                                        CASE
                                            WHEN parent_tenant_name IS NOT NULL THEN tenant_name
                                            ELSE NULL
                                        END AS sub_tenant_name,customergroup_id,tenant_id,subtenant_id,
                                        subtenant_name,child_account,billing_account_number,rate_plan_name,
                                        feature_codes,created_by,created_date,deleted_by,deleted_date,modified_by,
                                        modified_date,is_active,is_deleted,customer_names,id_10,notification_rules  from customergroups where  is_active=True order by name asc limit 100'''
                    customergroups=database.execute_query(customergroupquery,True).to_dict(orient='records')
                module_data["customergroups"] = customergroups
                soc_codes_pop_up_query = """SELECT distinct(soc_code) FROM public.mobility_feature
                where soc_code is not null
                """
                soc_codes_pop_up_values = database.execute_query(
                    soc_codes_pop_up_query, True
                )["soc_code"].to_list()
                # Add SOC codes to the module_data
                module_data["feature_codes"] = soc_codes_pop_up_values
                customers_data_query = """SELECT distinct customer_name FROM public.customers where is_active=True  order by customer_name asc
                """
                customer_names = database.execute_query(
                    customers_data_query, True
                )["customer_name"].to_list()
                module_data["customer_names"] = customer_names
                notifications_data_query = """SELECT distinct name FROM public.rule_rule_definition where is_active=True order by name asc
                """
                notification_rules = database.execute_query(
                    notifications_data_query, True
                )["name"].to_list()
                module_data["notification_rules"] = notification_rules
                billing_account_numbers = database.get_data(
                    "sim_management_inventory",
                    {"billing_account_number": "not Null", "is_active": True},
                    ["billing_account_number"],
                )["billing_account_number"].to_list()
                # Remove duplicates
                billing_account_numbers = list(set(billing_account_numbers))
                module_data["billing_account_number"] = billing_account_numbers
                module_data["tenant_name"] = sorted(module_data["tenant_name"])
                tenant_data = db.get_data("tenant", {"is_active": True}, ["id", "tenant_name"]).to_dict(orient="records")
                # Convert list of dictionaries to desired format
                tenant_id_map = {item["tenant_name"]: item["id"] for item in tenant_data}

                # Assign the transformed data to module_data
                module_data["tenant_id_map"] = tenant_id_map
            # formating data for Partner users
            if module == "Partner users":
                result_dict = {}

                roles = db.get_data(
                    "roles", {"is_active": "True"}, ["role_name", "tenant_id"]
                ).to_dict(orient="records")
                tenants_df = db.get_data(
                    "tenant", {"is_active": "True"}, ["tenant_name", "id"]
                ).to_dict(orient="records")
                tenants = {}
                for tenant in tenants_df:
                    tenants[tenant["id"]] = tenant["tenant_name"]
                out_roles = {}
                for role_item in roles:
                    if role_item["tenant_id"] in tenants:
                        if tenants[role_item["tenant_id"]] not in out_roles:
                            out_roles[tenants[role_item["tenant_id"]]] = []
                        out_roles[tenants[role_item["tenant_id"]]].append(
                            role_item["role_name"]
                        )
                module_data["role_name"] = out_roles

                # Sort module_data['tenant'] by tenant_name
                sorted_tenants = sorted(
                    module_data["tenant"], key=lambda x: x["tenant_name"]
                )

                if tenant_name != "Altaworx Test":
                    user_df = db.get_data(
                        "users", {"tenant_name": tenant_name}, ["is_active", "migrated"]
                    ).to_dict(orient="records")
                else:
                    user_df = db.get_data(
                        "users", {"tenant_name": "Altaworx"}, ["is_active", "migrated"]
                    ).to_dict(orient="records")

                for d in sorted_tenants:
                    tenant_id = d["id"]
                    tenant_name = d["tenant_name"]
                    parent_id = d["parent_tenant_id"]
                    sub_temp = []
                    if parent_id == "None":
                        for di in sorted_tenants:
                            if di["parent_tenant_id"] != "None" and float(
                                di["parent_tenant_id"]
                            ) == float(tenant_id):
                                sub_temp.append(di["tenant_name"])
                        # Sort sub_temp in alphabetical order
                        result_dict[tenant_name] = sorted(sub_temp)
                # Update module_data with the sorted result_dict
                module_data["tenant"] = result_dict

                total_count = len(user_df)
                active_user_count = 0
                migrated_count = 0
                for user in user_df:
                    if user["is_active"]:
                        active_user_count = active_user_count + 1
                    if user["migrated"]:
                        migrated_count = migrated_count + 1
                module_data["total_count"] = total_count
                module_data["active_user_count"] = active_user_count
                module_data["migrated_count"] = migrated_count

            # final addition of modules data into the retuting dict
            returning_partner_module_data[module] = convert_timestamp_data(
                module_data, tenant_time_zone
            )
            returning_partner_module_data["pages"] = counts
            # returning_partner_module_data = convert_timestamp_data_dictionary(returning_partner_module_data, tenant_time_zone=tenant_time_zone)

        # calling get header to get headers mapping
        headers_map = get_headers_mapping(
            tenant_database,
            modules_list,
            role,
            username,
            tenant_id,
            sub_parent_module,
            parent_module,
            data,
            db,
        )
        message = "partner data fetched successfully"
        # if "Customer groups" in modules_list:
        #     returning_partner_module_data = convert_timestamp_datadict(returning_partner_module_data, tenant_time_zone=tenant_time_zone)
        if "Partner users" in modules_list:
            returning_partner_module_data = convert_timestamp_data_dictionary(
                returning_partner_module_data, tenant_time_zone=tenant_time_zone
            )
        response = {
            "flag": True,
            "data": serialize_data(returning_partner_module_data),
            "headers_map": headers_map,
            "message": message,
        }
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "get_partner_info",
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            db.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
        return response
    except Exception as e:
        logging.exception(f"### Exception occurred in fetching Partner info : {e}")
        message = "Something went wrong while fetching Partner info"
        response = {"flag": True, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_partner_info",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message ,
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
 
        return response

def convert_timestamp_data_dictionary(
    df_dict, tenant_time_zone, timestamp_columns=None
):
    """
    Converts UTC timestamp fields in a nested dictionary structure to the tenant's local timezone.


    Args:
        df_dict (dict or list): The dictionary or list of dictionaries to process.
        tenant_time_zone (str): The default timezone string for the tenant (e.g., "America/Chicago").
        timestamp_columns (list, optional): List of timestamp column names to convert.
            If not provided, defaults to common timestamp fields like:
            - created_date, modified_date, deleted_date, processed_date,
              last_login, date_added, date_activated, run_start_time,
              session_created_date.

    Returns:
        dict or list: The input dictionary/list with timestamp fields converted to the target timezone format
                      as strings in "MM-DD-YYYY HH:MM:SS AM/PM" format.

    """
    logging.info("### Started converting timestamps...")

    try:
        if timestamp_columns is None:
            timestamp_columns = [
                "created_date",
                "modified_date",
                "deleted_date",
                "processed_date",
                "last_login",
                "date_added",
                "date_activated",
                "run_start_time",
                "session_created_date",
            ]

        utc_timezone = timezone("UTC")

        def process_record(record):
            if isinstance(record, dict):
                # Extract timezone from the user data or use tenant_time_zone as fallback
                user_timezone = record.get("timezone", tenant_time_zone)
                try:
                    if user_timezone:
                        target_timezone = timezone(user_timezone)
                    else:
                        target_timezone = timezone(tenant_time_zone)
                except UnknownTimeZoneError:
                    # Handle unknown timezones by falling back to the tenant's default timezone
                    logging.exception(
                        f"### Unknown timezone '{user_timezone}', falling back to tenant timezone."
                    )
                    target_timezone = timezone(tenant_time_zone)

                for col in timestamp_columns:
                    if col in record:
                        try:
                            if record[col] in ["None", None, ""]:
                                record[col] = None
                                continue

                            # Parse timestamp string to datetime
                            timestamp = pd.to_datetime(record[col], errors="coerce")

                            if pd.notna(timestamp):
                                if timestamp.tzinfo is None:
                                    timestamp = timestamp.tz_localize(utc_timezone)
                                timestamp = timestamp.tz_convert(target_timezone)
                                record[col] = timestamp.strftime("%m-%d-%Y %I:%M:%S %p")
                            else:
                                logging.info(
                                    f"### Column '{col}' could not be parsed or is invalid: {record[col]}"
                                )
                        except Exception as e:
                            logging.exception(
                                f"### Error processing column '{col}': {record[col]} - {e}"
                            )
            return record

        def traverse_data(data):
            if isinstance(data, list):
                return [traverse_data(item) for item in data]
            elif isinstance(data, dict):
                for key, value in data.items():
                    if isinstance(value, list):
                        data[key] = [process_record(item) for item in value]
                    elif isinstance(value, dict):
                        data[key] = traverse_data(value)
                return data
            return data

        processed_data = traverse_data(df_dict)
        return processed_data

    except Exception as e:
        logging.exception(f"### Error in conversion process: {e}")


def create_module_access_info(data):
    """
    Processes role-based access data to generate structured module, submodule, and feature mappings.

    Args:
        data (dict): A dictionary containing:
            - Role names (str) as keys.
            - For each role, a nested dictionary with:
                - "Module" (list): List of submodules under a main module.
                - "Feature" (dict): Dictionary of submodule-feature mappings.

    Returns:
        dict: A dictionary where:
            - Each key is a role name (str).
            - Each value is another dictionary with:
                - "module" (str): JSON-encoded list of main modules.
                - "sub_module" (str): JSON-encoded dict mapping main modules to submodules.
                - "module_features" (str): JSON-encoded dict mapping submodules to features.
    """
    return_dict = {}
    modules_list = []
    submodules_list = {}
    features_dict = {}
    # Iterate over each role and its associated features
    for role, user_features in data.items():
        logging.info(f"### Processing role: {role}")
        for main_module, content in user_features.items():
            logging.info(f"### Main module: {main_module}, Content: {content}")
            modules_list.append(main_module)
            submodules_list[main_module] = content["Module"]
            # Initialize the features dictionary for the current main module
            features_dict[main_module] = {}
            features = content["Feature"]
            # Iterate over each submodule of the main module
            for submodule in content["Module"]:
                if submodule in features:
                    features_dict[main_module][submodule] = features[submodule]
        # Store the processed data for the current role
        return_dict[role] = {
            "module": json.dumps(modules_list),
            "sub_module": json.dumps(submodules_list),
            "module_features": json.dumps(features_dict),
        }
    logging.info(f"### Final return dictionary:  {return_dict}")
    # Return the final dictionary with role-based access information
    return return_dict


def generate_hash(password, salt):
    """
    Generates a hash for the given password and salt using SHA1.
    The encoding is designed to match C# Unicode encoding.
    """
    combined = (password + salt).encode("utf-16-le")
    hash_object = hashlib.sha1(combined)
    return base64.b64encode(hash_object.digest()).decode("utf-8")


def create_human_user_zitadel(db_user_update,password):
    """
    Constructs a ZITADEL human user creation payload using values from `user_update` dict,
    then sends it via POST to ZITADEL's deprecated /v2beta/users/human endpoint.
    """

    # Build payload using user_update.get(...) as specified
    payload = {
    "username": db_user_update.get("username", ""),
    "profile": {
        "givenName": db_user_update.get("first_name", ""),
        "familyName": db_user_update.get("last_name", ""),
        "displayName": db_user_update.get("username", ""),
        "prefferedLanguage": "en",
        "gender": "GENDER_UNSPECIFIED"
    },
    "email": {
        "email": db_user_update.get("email", ""),
        "isVerified": True
    },
    "phone": {
        "phone": db_user_update.get("phone", ""),
        "isVerified": True
    },
    "password": {
        "password": password,
        "changeRequired": False
    }
}

    base_url = os.getenv("ZITADEL_API_BASE_URL")

    token = os.getenv("ZITADEL_TOKEN",None)
    url = f"{base_url.rstrip('/')}/v2beta/users/human"
    if not url or not token:
        logging.info("Missing ZITADEL_API_BASE_URL or ZITADEL_ADMIN_SERVICE_ACCOUNT_ID")
        return {"flag": False, "message": "ZITADEL configuration missing"}
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    try:
        logging.info("Creating human user with payload: %s", payload)
        response = requests.post(url, json=payload, headers=headers)
        logging.info("ZITADEL response: %s", response.text)

        if response.status_code in (200, 201):
            return {"flag": True, "message": "User created successfully", "data": response.json()}
        else:
            try:
                error_data = response.json()
            except ValueError:
                error_data = response.text
            return {"flag": False, "message": f"Failed ({response.status_code})", "error": error_data}
    except Exception as e:
        logging.exception("Exception during user creation")
        return {"flag": False, "message": "Exception occurred", "error": str(e)}


# def add_username(username, password):
#     """
#     Authenticates a user by sending a POST request to the authentication endpoint with the username and password.
#     """
#     try:
#         # url = 'https://sandbox-device-api.amop.services/api/auth/update-password'
#         url = os.getenv("ZITADEL_USERNAME", " ")
#         data = {"username": username, "password": password}
#         headers = {
#             "x-api-key": "IiI1IV82XAsdkfPFQpqWFLLvQAiWR0xB",
#         }
#         response = requests.post(url, json=data, headers=headers)
#         logging.info(f"### authenticating user response.status_code : {response.status_code} and response is {response.text}")
#     except Exception as e:
#         logging.exception(f"### Exception is  : {e}")
#         return {
#             "flag": False,
#             "message": "Something went wrong fetching sessionid and sessiontoken using Zitadel",
#         }

def update_group_table(database,table_name,group_column,item_column,group_id,new_ids,created_by = None):
    """
    Updates a group mapping table by deactivating existing links and inserting/updating new ones.

    This function performs a full refresh of the item mappings for a given group:
    - Deactivates all existing records (marks as deleted).
    - Inserts new records for IDs not previously present.
    - Reactivates existing records for IDs already present.

    Args:
        database: Database connection object with required query methods.
        table_name (str): Name of the group mapping table to update.
        group_column (str): Column name representing the group identifier (e.g., group_id).
        item_column (str): Column name representing the individual items linked to the group.
        group_id (str): Identifier of the group whose mappings are to be updated.
        new_ids (list): List of new item IDs to be associated with the group.

    Returns:
        None: Function returns nothing. Logs errors if exceptions occur.

    """
    try:
        if not group_id or not new_ids:
            return
        existing_df = database.get_data(table_name, {group_column: group_id}, [item_column])
        existing_ids = set(existing_df[item_column].to_list())

        # Disable all existing links
        database.update_dict(table_name,{"is_active": False, "is_deleted": True}, {group_column: group_id})
        new_ids_set = set(new_ids)
        to_insert = new_ids_set - existing_ids
        to_update = new_ids_set & existing_ids

        #insert new reocrds
        if to_insert:
            insert_data = [
                {
                    group_column: group_id,
                    item_column: item_id,
                    "is_active": True,
                    "is_deleted": False
                } for item_id in to_insert
            ]
            # if  table is notification_rule_recipient the add created_by to insert data
            if table_name == "notification_rule_recipient":
                for data in insert_data:
                    data["created_by"] = created_by
            database.insert_data(insert_data, table_name)
        #update existing records
        if to_update:
            database.update_dict(
                table_name,
                {"is_active":True, "is_deleted":False},
                and_conditions={group_column: group_id},
                in_conditions={item_column: list(to_update)}
            )
    except Exception as e:
        logging.exception(f"### update_group_table Exception is : {e}")
        return



def update_partner_info(data):
    """
    Updates partner-related information in the database based on the provided input.

    This function performs permission validation and handles create, update, or delete operations
    across various modules such as partner info, partner module access, customer groups, and partner users.
    It also triggers email notifications, logs audit information, and manages user-tenant mappings.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): Name of the tenant-specific database.
            - tenant_name (str): Name of the tenant.
            - changed_data (dict): Dictionary of changed fields and values.
            - where_dict (dict): Dictionary used for conditional updates.
            - role_name (str): Role of the user (e.g., "Admin", "User").
            - action (str): Type of action to perform ("create", "update", "delete").
            - module_name (str): Module on which the action is to be performed.
            - list_view_id (str): ID of the selected user (for user module).
            - sub_partner_names (list, optional): Sub-partners to map user to.
            - changed_tenant (str, optional): Tenant previously mapped to the user.
            - template_name (str, optional): Email template to use.
            - template (str, optional): Email body content.

    Returns:
        dict: A dictionary with:
            - flag (bool): True if operation is successful, False otherwise.
            - message (str): Status message describing the result.
    """
    logging.info(f"### Request Data: {data}")
    Partner = data.get("Partner", "")
    ##Restriction Check for the Amop API's
    try:
        # Create an instance of the PermissionManager class
        permission_manager_instance = PermissionManager(db_config)

        # Call the permission_manager method with the data dictionary and validation=True
        result = permission_manager_instance.permission_manager(data, validation=True)

        # Check the result and handle accordingly
        if isinstance(result, dict) and result.get("flag") is False:
            logging.warning(f"### Permission check failed:  {result}")
            return result
        else:
            # Continue with other logic if needed
            pass
    except Exception:
        logging.warning("### got exception in the restriction")

    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    ##database connection
    # Start time  and date calculation
    start_time = time.time()
    username = data.get("username", None)
    tenant_name = data.get("tenant_name", None)
    updated_data_ui = data.get("changed_data", [])
    session_id = data.get("session_id", None)
    where_dict = data.get("where_dict", {})
    role = data.get("role_name", None)
    action = data.get("action", None)
    module_name = data.get("module_name", None)
    list_view_id = data.get("list_view_id", "")
    module_name = module_name.lower()
    template_name = data.get("template_name", "Create User")
    # database Connection
    tenant_database = data.get("db_name", None)
    database = DB(tenant_database, **db_config)
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        # Fetch tenant ID based on tenant name
        #tenant_name = "Altaworx" if tenant_name == "Altaworx Test" else tenant_name
        tenant_id = db.get_data("tenant", {"tenant_name": tenant_name}, ["id"])[
            "id"
        ].to_list()[0]
        # Prepare updated data for database operations
        updated_data = {}
        for key, value in updated_data_ui.items():
            if type(value) is not str:
                updated_data[key] = json.dumps(value)
            elif value == "None" or value == "":
                updated_data[key] = None
            else:
                updated_data[key] = value
        # Remove 'id' field if present and module_name is not 'customer groups'
        if "id" in updated_data and module_name != "customer groups":
            updated_data.pop("id")
        # Perform database operations based on the module_name and action
        if module_name == "partner info":
            where_dict = {"tenant_name": tenant_name}
            if action in ("update", "delete"):
                db.update_dict("tenant", updated_data, where_dict)
            elif action == "create":
                tenant_id = db.insert_data(updated_data, "tenant")

        if module_name == "partner module access":
            if action in ("update", "delete"):
                role_module_acess = create_module_access_info(updated_data_ui)
                for role, value_dict in role_module_acess.items():
                    where_dict = {"role": role}
                    db.update_dict("role_module", value_dict, where_dict)
            elif action == "create":
                role_module_acess = create_module_access_info(updated_data_ui)
                for role, value_dict in role_module_acess.items():
                    value_dict["role"] = role
                    db.insert_data(value_dict, "role_module")

        if module_name == "customer groups":
            if action == "update" or action == "delete":
                update = data.get("changed_data", [])
                if "id_10" in update:
                    update.pop("id_10")
                where_dict = {"id": update["id"]}
                update.pop("id")
                list_keys = ["customer_names", "rate_plan_name", "feature_codes", "notification_rules"]
                for key in list_keys:
                    if key in update:
                        value = update[key]
                        if isinstance(value, str):
                            try:
                                update[key] = json.loads(value)  # Parse JSON string into list
                            except Exception as e:
                                logging.exception(f"### update_partner_info Error parsing key {key}: {e}")
                        elif isinstance(value, list):
                            pass  # Already a list, good
                        elif isinstance(value, set):
                            update[key] = list(value)  # If it somehow became a set, convert to list

                # Before updating, convert lists into JSON strings
                for key in list_keys:
                    if key in update and isinstance(update[key], list):
                        update[key] = json.dumps(update[key])  # Make it a JSON string!
                database.update_dict("customergroups", update, where_dict)
                logging.info(f"### Updated customer group with data: {update} and where_dict: {where_dict}")
                customer_group_id = where_dict.get("id", None)

                # map customer names to customer_group_customer table
                customer_names = update.get("customer_names", [])
                if isinstance(customer_names, str):
                    customer_names = json.loads(customer_names)
                customer_id_df = database.get_data("customers", 
                                    {"customer_name": customer_names,
                                    "tenant_id": tenant_id,
                                    "is_active":True}, 
                                    ["id"]
                                )
                if not customer_id_df.empty:
                    customer_ids = customer_id_df["id"].to_list()
                    update_group_table(
                        database=database,
                        table_name="customer_group_customer",
                        group_column="customer_group_id",
                        item_column="customer_id",
                        group_id=customer_group_id,
                        new_ids=customer_ids
                    )

                # map rate plans to customer_group_customer_rate_plan table
                rate_plan_names = update.get("rate_plan_name", [])
                if isinstance(rate_plan_names, str):
                    rate_plan_names = json.loads(rate_plan_names)
                rate_plan_id_df = database.get_data(
                    "customerrateplan", 
                    {"rate_plan_name": rate_plan_names,
                    "tenant_id": tenant_id,
                    "is_active":True}, 
                    ["id"])
                if not rate_plan_id_df.empty:
                    rate_plan_ids = rate_plan_id_df["id"].to_list()
                    update_group_table(
                        database=database,
                        table_name="customer_group_customer_rate_plan",
                        group_column="customer_group_id",
                        item_column="customer_rate_plan_id",
                        group_id=customer_group_id,
                        new_ids=rate_plan_ids
                    )
                
                #map feature codes to customer_group_mobility_feature table
                feature_codes = update.get("feature_codes", [])
                if isinstance(feature_codes, str):
                    feature_codes = json.loads(feature_codes)
                feature_codes_df = database.get_data(
                    "mobility_feature",
                    {"soc_code":feature_codes, "is_active": True},
                    ["id"]
                )
                if not feature_codes_df.empty:
                    feature_codes_ids = feature_codes_df["id"].to_list()
                    update_group_table(
                        database=database,
                        table_name="customer_group_mobility_feature",
                        group_column="customer_group_id",
                        item_column="mobility_feature_id",
                        group_id=customer_group_id,
                        new_ids=feature_codes_ids,
                    )

                # map notification rules to notification_rule_recipient table
                notification_rules = update.get("notification_rules", [])
                if isinstance(notification_rules, str):
                    notification_rules = json.loads(notification_rules)
                notification_rules_df = database.get_data(
                    "rule_rule_definition",
                    {"name":notification_rules, "is_active": True},
                    ["id"]
                )
                if not notification_rules_df.empty:
                    notification_rules_ids = notification_rules_df["id"].to_list()
                    update_group_table(
                        database=database,
                        table_name="notification_rule_recipient",
                        group_column="customer_group_id",
                        item_column="rule_id",
                        group_id=customer_group_id,
                        new_ids=notification_rules_ids,
                        created_by=username
                    )

            elif action == "create":
                if "id" in updated_data:
                    updated_data.pop("id")

                #update tenent name if tenant id is present
                if "tenant_id" in updated_data and not updated_data.get("tenant_name"):
                    updated_data["tenant_id"] = 1 if updated_data["tenant_id"] == 212 else updated_data["tenant_id"]
                    tenant_data = db.get_data("tenant", {"id": updated_data["tenant_id"]}, ["tenant_name"])
                    if not tenant_data.empty:
                        updated_data["tenant_name"] = tenant_data["tenant_name"].iloc[0]
                # Remove the incorrect key if it exists
                sub_tanant_id = updated_data.pop("sub_tanant", None)
                # If sub_tanant_id is valid and subtenant_name is missing, fetch and set it
                if sub_tanant_id and not updated_data.get("subtenant_name"):
                    subtenant_data = db.get_data("tenant", {"id": sub_tanant_id}, ["tenant_name"])
                    if not subtenant_data.empty:
                        updated_data["subtenant_name"] = subtenant_data["tenant_name"].iloc[0]

                # Ensure subtenant_id is set correctly if sub_tanant was provided
                if sub_tanant_id:
                    updated_data["subtenant_id"] = sub_tanant_id

                if "modified_date" in updated_data:
                    updated_data.pop("modified_date")
                customer_group_id = database.insert_data(updated_data, "customergroups")

                # map customer names to customer_group_customer table
                customer_names = updated_data.get("customer_names", [])
                if isinstance(customer_names, str):
                    customer_names = json.loads(customer_names)
                customer_id_df = database.get_data("customers", 
                                    {"customer_name": customer_names,
                                    "tenant_id": tenant_id,
                                    "is_active":True}, 
                                    ["id"]
                                )
                if not customer_id_df.empty:
                    customer_ids = customer_id_df["id"].to_list()
                    update_group_table(
                        database=database,
                        table_name="customer_group_customer",
                        group_column="customer_group_id",
                        item_column="customer_id",
                        group_id=customer_group_id,
                        new_ids=customer_ids
                    )

                # map rate plans to customer_group_customer_rate_plan table
                rate_plan_names = updated_data.get("rate_plan_name", [])
                if isinstance(rate_plan_names, str):
                    rate_plan_names = json.loads(rate_plan_names)
                rate_plan_id_df = database.get_data(
                    "customerrateplan", 
                    {"rate_plan_name": rate_plan_names,
                    "tenant_id": tenant_id,
                    "is_active":True}, 
                    ["id"])
                if not rate_plan_id_df.empty:
                    rate_plan_ids = rate_plan_id_df["id"].to_list()
                    update_group_table(
                        database=database,
                        table_name="customer_group_customer_rate_plan",
                        group_column="customer_group_id",
                        item_column="customer_rate_plan_id",
                        group_id=customer_group_id,
                        new_ids=rate_plan_ids
                    )
                
                #map feature codes to customer_group_mobility_feature table
                feature_codes = updated_data.get("feature_codes", [])
                if isinstance(feature_codes, str):
                    feature_codes = json.loads(feature_codes)
                feature_codes_df = database.get_data(
                    "mobility_feature",
                    {"soc_code":feature_codes, "is_active": True},
                    ["id"]
                )
                if not feature_codes_df.empty:
                    feature_codes_ids = feature_codes_df["id"].to_list()
                    update_group_table(
                        database=database,
                        table_name="customer_group_mobility_feature",
                        group_column="customer_group_id",
                        item_column="mobility_feature_id",
                        group_id=customer_group_id,
                        new_ids=feature_codes_ids,
                    )

                # map notification rules to notification_rule_recipient table
                notification_rules = updated_data.get("notification_rules", [])
                if isinstance(notification_rules, str):
                    notification_rules = json.loads(notification_rules)
                notification_rules_df = database.get_data(
                    "rule_rule_definition",
                    {"name":notification_rules, "is_active": True},
                    ["id"]
                )
                if not notification_rules_df.empty:
                    notification_rules_ids = notification_rules_df["id"].to_list()
                    update_group_table(
                        database=database,
                        table_name="notification_rule_recipient",
                        group_column="customer_group_id",
                        item_column="rule_id",
                        group_id=customer_group_id,
                        new_ids=notification_rules_ids,
                        created_by=username
                    )

        if module_name == "partner users":
            if "tenant_id" in updated_data and updated_data["tenant_id"]:
                updated_data["tenant_id"] = str(int(float(updated_data["tenant_id"])))

            if action == "delete":
                keys_to_keep = ['modified_by', 'is_active', 'is_deleted','username']
                updated_data = {k: updated_data[k] for k in keys_to_keep if k in updated_data}
                db.update_dict(
                    "users", updated_data, {"username": updated_data["username"]}
                )
            elif action == "delete_":
                db.delete_data(
                    "users", and_conditions={"id": updated_data_ui.get("id")}
                )

            elif action == "update":
                customer_info = updated_data.get("customer_info")
                try:
                    customer_info = json.loads(customer_info)
                except Exception as e:
                    logging.warning(f"### Exception is : {e}")

                if customer_info:
                    db_customer_info = {}

                    for key, value in customer_info.items():
                        if type(value) is not str:
                            db_customer_info[key] = json.dumps(value)
                        elif value == "None":
                            db_customer_info[key] = None
                        elif value == "true":
                            db_customer_info[key] = True
                        elif value == "false":
                            db_customer_info[key] = False
                        else:
                            db_customer_info[key] = value
                    username_to_update = db_customer_info.get("username")
                    db.update_dict(
                        "users",
                        db_customer_info,
                        {"username": username_to_update},
                    )

                user_update = updated_data.get("user_info")
                try:
                    user_update = json.loads(user_update)
                except Exception as e:
                    logging.warning(f"### Exception is : {e}")
                if user_update:
                    user_update["email"] = user_update.get("email", "").strip()
                    user_update["username"] = user_update.get("username", "").strip()
                    db_user_update = {}
                    for key, value in user_update.items():
                        if type(value) is not str:
                            db_user_update[key] = json.dumps(value)
                        elif value == "None":
                            db_user_update[key] = None
                        elif str(value).lower() == "true":
                            db_user_update[key] = True
                        elif str(value).lower() == "false":
                            db_user_update[key] = False
                        else:
                            db_user_update[key] = value
                    try:
                        tenant_name_update=db_user_update['tenant_name']
                        previous_tenant=data.get('changed_tenant','')

                        # Normalize into lists
                        def normalize_tenants(value):
                            if not value:
                                return []
                            try:
                                # if it's a JSON list string
                                tenants = json.loads(value) if isinstance(value, str) and value.strip().startswith("[") else value
                            except Exception:
                                tenants = value

                            # Ensure list
                            if isinstance(tenants, str):
                                tenants = [tenants]
                            return tenants
                        
                        tenant_names_update = normalize_tenants(tenant_name_update)
                        previous_tenants = normalize_tenants(previous_tenant)

                        user_name_update=db_user_update['username']

                        # Fetch user_name using list_view_id
                        user_name = db.get_data(
                            "users",
                            {"id": int(list_view_id)},
                            ["username"],
                        )["username"].to_list()[0]

                        changed_tenant_ids = db.get_data('tenant', {'tenant_name': previous_tenants,"is_active":True}, ['id'])['id'].to_list()
                        tenant_ids_update = db.get_data('tenant', {'tenant_name': tenant_names_update, "is_active":True}, ['id'])['id'].to_list()
                        logging.info(f"### previous tenant: {previous_tenants}, previous_tenant_id: {changed_tenant_ids}")

                        # Find tenants to add and remove
                        tenant_ids_to_add = [tid for tid in tenant_ids_update if tid not in changed_tenant_ids]
                        tenant_ids_to_remove = [tid for tid in changed_tenant_ids if tid not in tenant_ids_update]

                        if tenant_ids_to_remove:
                            logging.info(f"### Removing tenant IDs {tenant_ids_to_remove} for user {user_name}")
                            db.delete_data(
                                "user_module_tenant_mapping",
                                and_conditions={"user_name": user_name},
                                in_conditions={"tenant_id": tenant_ids_to_remove}
                            )

                        db.update_dict(
                                "user_module_tenant_mapping",
                                {"user_name": user_name_update},
                                {"user_name": user_name},
                            )
                        
                        user_data_to_add = []
                        for tenant_id in tenant_ids_to_add:
                            user_data_to_add.append({
                                "user_name": user_name_update,
                                "tenant_id": tenant_id
                            })
                        if user_data_to_add:
                            logging.info(f"### Adding tenant IDs {tenant_ids_to_add} for user {user_name}")
                            db.insert_data(user_data_to_add, "user_module_tenant_mapping")
                    except Exception as e:
                        logging.warning(f"### Exception while updating user_module_tenant_mapping : {e}")
                    try:
                        sub_partner_names=data.get('sub_partner_names',[])
                        user_name_insert=db_user_update['username']
                        if sub_partner_names:
                            logging.info(f"### sub_partner_names : {sub_partner_names}")
                            # Handle single-item tuples correctly
                            sub_partner_names_tuple = f"({', '.join(map(repr, sub_partner_names))})" if len(sub_partner_names) > 1 else f"('{sub_partner_names[0]}')"

                            sub_partner_ids_query = f'''SELECT id FROM tenant WHERE tenant_name IN {sub_partner_names_tuple}'''
                            logging.info(f"### Executing Query: {sub_partner_ids_query}")  # Debugging

                            # Execute query to get tenant IDs
                            sub_partner_ids = db.execute_query(sub_partner_ids_query, True)

                            # Convert DataFrame to list of dictionaries if needed
                            if hasattr(sub_partner_ids, "to_dict"):
                                sub_partner_ids = sub_partner_ids.to_dict(orient="records")

                            if isinstance(sub_partner_ids, list) and all(isinstance(row, dict) for row in sub_partner_ids):
                                tenant_ids = [row['id'] for row in sub_partner_ids]

                                # Ensure correct formatting for SQL (avoid single-element tuple issues)
                                if tenant_ids:
                                    tenant_ids_tuple = f"({', '.join(map(str, tenant_ids))})"

                                    # Query to get already existing tenant IDs
                                    sub_tenant_query = f'''SELECT tenant_id FROM user_module_tenant_mapping WHERE tenant_id IN {tenant_ids_tuple} and user_name='{user_name_insert}'
                                    '''
                                    existing_tenant_ids_result = db.execute_query(sub_tenant_query,True)
                                    logging.info(f"### existing_tenant_ids_result : {existing_tenant_ids_result}")
                                    # Convert DataFrame to list of dictionaries if needed
                                    if hasattr(existing_tenant_ids_result, "to_dict"):
                                        existing_tenant_ids_result = existing_tenant_ids_result.to_dict(orient="records")

                                    existing_tenant_ids = [row['tenant_id'] for row in existing_tenant_ids_result] if isinstance(existing_tenant_ids_result, list) else []

                                    # Filter out exissting tenant IDs
                                    new_tenant_ids = [tid for tid in tenant_ids if tid not in existing_tenant_ids]
                                    logging.info(f"### new_tenant_ids : {new_tenant_ids}")
                                    for tenant_id in new_tenant_ids:
                                        sub_tenant_data = {
                                            "tenant_id": tenant_id,
                                            "user_name": user_name_insert,
                                        }
                                        try:
                                            db.insert_data(sub_tenant_data, "user_module_tenant_mapping")
                                        except Exception as e:
                                            logging.exception(f"### update_partner_info Error inserting data: {e}")

                                    if not new_tenant_ids:
                                        logging.info("### All tenant IDs already exist in user_module_tenant_mapping. No new inserts.")
                                else:
                                    logging.info("### No valid tenant IDs found.")
                            else:
                                logging.info(f"### Unexpected query result format: {sub_partner_ids}")
                        else:
                            logging.info("### No sub-partner names provided.")
                    except Exception as e:
                        logging.info(f"### Exception while inserting user_module_tenant_mapping : {e}")


                    db.update_dict(
                        "users",
                        db_user_update,
                        {"id": int(list_view_id)},
                    )

                user_modules_update = updated_data.get("data")
                try:
                    user_modules_update = json.loads(user_modules_update)
                except Exception as e:
                    logging.warning(f"### Exception is : {e}")
                if user_modules_update:
                    tenant_id = db.get_data(
                        "tenant",
                        {"tenant_name": updated_data["Selected Partner"]},
                        ["id"],
                    )["id"].to_list()[0]
                    user_module_acess = create_module_access_info(user_modules_update)
                    db.update_dict(
                        "users",
                        {"modified_by": username},
                        {"user_name": updated_data["Username"]},
                    )
                    for user, value_dict in user_module_acess.items():
                        value_dict["module_names"] = value_dict["module"]
                        value_dict.pop("module")
                        db.update_dict(
                            "user_module_tenant_mapping",
                            value_dict,
                            {
                                "tenant_id": tenant_id,
                                "user_name": updated_data["Username"],
                            },
                        )

            elif action == "create":
                user_update = updated_data.get("user_info")

                try:
                    user_update = json.loads(user_update)
                    user_update["email"] = user_update.get("email", "").strip()
                    user_update["username"] = user_update.get("username", "").strip()
                    tenant = user_update.get("tenant_name")
                    tenant_id = db.get_data("tenant", {"tenant_name": tenant}, ["id"])[
                        "id"
                    ].to_list()[0]
                except Exception as e:
                    logging.warning(f"### Exception is : {e}")

                user = user_update["username"]
                out = db.get_data("users", {"username": user}, ["username"])
                if not out.empty:
                    return {
                        "flag": False,
                        "error_type": "Warning",
                        "message": "Username is already taken, Please Update Username",
                    }

                email = user_update.get("email", "")
                email_username = user_update.get("username", "")
                # Ensure tenants_list is always a list
                tenant_value = user_update["tenant_name"]
                if isinstance(tenant_value, list):
                    tenants_list = tenant_value
                else:
                    tenants_list = [tenant_value]

                for tenant_name in tenants_list:
                    tenant_id = db.get_data(
                        "tenant", {"tenant_name": tenant_name}, ["id"]
                    )["id"].to_list()[0]
                    db_user = {
                        "tenant_id": tenant_id,
                        "user_name": user_update["username"],
                    }
                    db.insert_data(db_user, "user_module_tenant_mapping")
                try:
                    sub_partner_names=data.get('sub_partner_names',[])
                    user_name_insert=user_update.get("username", "")
                    if sub_partner_names:
                        # Handle single-item tuples correctly
                        sub_partner_names_tuple = tuple(sub_partner_names) if len(sub_partner_names) > 1 else f"('{sub_partner_names[0]}')"

                        sub_partner_ids_query = f'''SELECT distinct id FROM tenant WHERE tenant_name IN {sub_partner_names_tuple} and is_active=True'''
                        logging.info(f"### Executing Query: {sub_partner_ids_query}")  # Debugging

                        # Execute query
                        sub_partner_ids = db.execute_query(sub_partner_ids_query, True)

                        # Check if it's a DataFrame-like object (common case)
                        if hasattr(sub_partner_ids, "to_dict"):
                            sub_partner_ids = sub_partner_ids.to_dict(orient="records")  # Convert to list of dicts

                        # Ensure result is a list of dictionaries
                        if isinstance(sub_partner_ids, list) and all(isinstance(row, dict) for row in sub_partner_ids):
                            tenant_ids = [row['id'] for row in sub_partner_ids]  # Extract IDs safely

                            for tenant_id in tenant_ids:
                                sub_tenant_data = {
                                    "tenant_id": tenant_id,
                                    "user_name": user_name_insert,
                                }
                                db.insert_data(sub_tenant_data, "user_module_tenant_mapping")
                        else:
                            logging.info(f"### Unexpected query result format: {sub_partner_ids}")
                    else:
                        logging.info("### No sub-partner names provided.")
                except Exception as e:
                    logging.info(f"### Exception while inserting user_module_tenant_mapping : {e}")
                if user_update:

                    db_user_update = {}
                    for key, value in user_update.items():
                        if key == "password":
                            salt = os.urandom(16).hex()
                            hashed_password = generate_hash(value, salt)
                            db_user_update[key] = hashed_password
                            db_user_update["salt"] = salt
                        elif type(value) is not str:
                            db_user_update[key] = json.dumps(value)
                        elif value == "None":
                            db_user_update[key] = None
                        else:
                            db_user_update[key] = value
                    logging.info(f"### db_user_update : {db_user_update}, password is {user_update['password']}")
                    response=create_human_user_zitadel(
                        db_user_update,user_update["password"]
                    )
                    if response.get("flag"):
                        user_id = response.get("data", {}).get("userId")
                        if user_id:
                            logging.info(f"Successfully created user with userId: {user_id}")
                            db_user_update["user_id"] = user_id  # Add user_id to db_user_update
                            # You can now use user_id as needed
                        else:
                            logging.info("Response flag is True but 'userId' is missing in response data.")
                    else:
                        logging.info(f"Failed to create user: {response.get('message')} — {response.get('error')}")


                    db_user_update["tenant_id"] = tenant_id
                    user_id=db.insert_data(db_user_update, "users")
                    to_email = db.get_data("users", {"id": user_id}, ["email"])[
                        "email"
                    ].to_list()[0]
                    '''
                        This Block is used to update the dynamic cols of the user when user logins for the first time
                    '''
                    try:
                        # Step 1: Get field-column mappings
                        field_cols_query = '''
                            SELECT module_name, db_column_name
                            FROM field_column_mapping
                            WHERE module_name IS NOT NULL
                            AND db_column_name IS NOT NULL
                        '''
                        field_col_dataframe = db.execute_query(field_cols_query, True)

                        # Step 2: Build module -> column map
                        module_column_map = {}
                        for _, row in field_col_dataframe.iterrows():
                            module = row['module_name']
                            column = row['db_column_name']
                            module_column_map.setdefault(module, []).append(column)

                        formatted_json = json.dumps(module_column_map, indent=2)

                        # Step 3: Version flag JSON
                        module_query = """
                            SELECT parent_module_name,
                                module_name,
                                MIN(id) AS first_id
                            FROM module
                            WHERE is_active = TRUE
                            GROUP BY parent_module_name, module_name
                            ORDER BY first_id ASC;
                        """
                        module_data_df = db.execute_query(module_query, True)

                        json_data = {}
                        for _, row in module_data_df.iterrows():
                            combined_key = f"{row['parent_module_name']}-{row['module_name']}"
                            json_data[combined_key] = False

                        version_flag_json = json.dumps(json_data)

                        # Step 4: Dashboard dynamic cols
                        dashboard_features_query = f"""
                            SELECT module_features
                            FROM role_module
                            WHERE role = '{role}';
                        """
                        dashboard_df = db.execute_query(dashboard_features_query, True)

                        dashboard_dynamic_list = []
                        if not dashboard_df.empty:
                            module_features_raw = dashboard_df.iloc[0]['module_features']

                            if isinstance(module_features_raw, str):
                                module_features = json.loads(module_features_raw)  # parse JSON string
                            else:
                                module_features = module_features_raw

                            # Safely get Dashboard -> Dashboard features
                            dashboard_features = (
                                module_features.get("Dashboard", {})
                                .get("Dashboard", [])
                            )

                            for feature in dashboard_features:
                                if '-' in feature:
                                    name, tab = feature.rsplit('-', 1)
                                    dashboard_dynamic_list.append({
                                        "tab": tab.strip(),
                                        "name": name.strip()
                                    })

                        dashboard_dynamic_cols = json.dumps(dashboard_dynamic_list, indent=2)

                        # Step 5: Update users table
                        update_data = {
                            "dynamic_cols": formatted_json,
                            "switch_user_20_modules_json": version_flag_json,
                            "dashboard_dynamic_cols": dashboard_dynamic_cols
                        }
                        db.update_dict("users", update_data, {"id": user_id})

                    except Exception as e:
                        logging.info(f"### Exception while adding dynamic cols to the user: {e}")

                    try:
                        template=data.get("template",'')
                        db.update_dict(
                            "email_templates",
                            {
                                "last_email_triggered_at": request_received_at,"body":template,
                                "to_mail": email,
                            },
                            {"template_name": template_name},
                        )
                        # Call send_email and assign the result to 'result'
                        result = send_email(
                            template_name,
                            username=email_username,
                            user_mail=to_email,
                            is_html=True,
                        )
                    except Exception as e:
                        logging.info(f"### Exception while updating email_templates : {e}")
                        pass

                    # Check the result and handle accordingly
                    if isinstance(result, dict) and result.get("flag") is False:
                        logging.info(f"### result :{result}")
                    else:
                        # Continue with other logic if needed
                        (
                            to_emails,
                            cc_emails,
                            subject,
                            body,
                            from_email,
                            partner_name,
                        ) = result
                        # to_emails,cc_emails,subject,body,from_email,partner_name=
                        # send_email(template_name,username=username,user_mail=to_email)
                        db.update_dict(
                            "email_templates",
                            {"last_email_triggered_at": request_received_at},
                            {"template_name": template_name},
                        )
                        query = """
                            SELECT parents_module_name, sub_module_name,
                              child_module_name, partner_name
                            FROM email_templates
                            WHERE template_name = %s
                        """

                        params = [template_name]
                        # Execute the query with template_name as the parameter
                        email_template_data = db.execute_query(query, params=params)
                        if not email_template_data.empty:
                            # Unpack the results
                            (
                                parents_module_name,
                                sub_module_name,
                                child_module_name,
                                partner_name,
                            ) = email_template_data.iloc[0]
                        else:
                            # If no data is found, assign default values or log an error
                            parents_module_name = ""
                            sub_module_name = ""
                            child_module_name = ""
                            partner_name = ""

                        try:
                            ##email audit
                            email_audit_data = {
                                "template_name": template_name,
                                "email_type": "Application",
                                "partner_name": partner_name,
                                "email_status": "success",
                                "from_email": from_email,
                                "to_email": to_emails,
                                "cc_email": cc_emails,
                                "comments": "update inventory data",
                                "subject": subject,
                                "body": body,
                                "role": role,
                                "action": "Email triggered",
                                "parents_module_name": parents_module_name,
                                "sub_module_name": sub_module_name,
                                "child_module_name": child_module_name,
                            }
                            db.update_audit(email_audit_data, "email_audit")
                        except Exception as e:
                            logging.info(f"### update_partner_info Exception email_audit : {e}")
                            pass
                    message = "mail sent sucessfully"
                    # End time calculation
                    end_time = time.time()
                    time_consumed = end_time - start_time
                    try:
                        # Email audit
                        email_audit_data = {
                            "template_name": template_name,
                            "email_type": "Send Grid",
                            "partner_name": partner_name,
                            "email_status": "success",
                            "from_email": from_email,
                            "to_email": to_emails,
                            "cc_email": cc_emails,
                            "comments": "Account creation confirmation",
                            "subject": subject,
                            "body": body,
                            "role": role,
                            "action_performed": "account creation confirmation",
                        }
                        db.update_audit(email_audit_data, "email_audit")
                    except Exception as e:
                        logging.warning(f"### Exception during audit logging: {e}")
        message = "Updated sucessfully"
        response = {"flag": True, "message": message}
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "update_partner_info",
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": json.dumps(updated_data_ui),
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            db.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception is : {e}")
        return response
    except Exception as e:
        logging.exception(f"### Error occurred while updating Partner info : {e}")
        message = "Something went wrong while updating Partner info"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "update_partner_info",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Exception is : {e}")
        return response




# Function to convert Timestamps to strings
def convert_timestamps(obj):
    """
    Recursively converts pandas Timestamp objects within a nested structure 
    (e.g., dictionary, list) into human-readable string format 'MM-DD-YYYY HH:MM:SS'.

    Args:
        obj (any): The input object which may contain pandas.Timestamp objects.
                   Can be of type dict, list, pd.Timestamp, or any other data type.

    Returns:
        any: The processed object with all pandas.Timestamp instances converted
             to strings in 'MM-DD-YYYY HH:MM:SS' format.
    """
    logging.info(f"### Converting timestamps in the object: {obj}")
    if isinstance(obj, dict):
        logging.info("### Processing a dictionary.")
        return {k: convert_timestamps(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        logging.info(f"### Processing a list with {len(obj)} elements." )
        return [convert_timestamps(elem) for elem in obj]
    elif isinstance(obj, pd.Timestamp):
        logging.info(f"### Converting pandas Timestamp: {obj} ")
        return obj.strftime("%m-%d-%Y %H:%M:%S")
    logging.info(f"### No conversion applied for object: {obj}")
    return obj


def dataframe_to_blob(data_frame):
    """
    Converts a pandas DataFrame into a base64-encoded Excel binary (blob).

    This function performs the following:
    - Converts the given DataFrame to an Excel file in memory using `BytesIO`.
    - Applies center alignment and grey background styling to header cells.
    - Adjusts column widths dynamically based on content length.
    - Encodes the Excel file content into base64 format suitable for blob storage or API response.

    Args:
        data_frame (pd.DataFrame): The DataFrame to be converted into a blob.

    Returns:
        bytes: Base64-encoded Excel blob representing the DataFrame.
    """
    logging.info("### Converting DataFrame to blob.")
    # Create a BytesIO buffer
    bio = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        logging.info("### Writing DataFrame to Excel.")
        data_frame.to_excel(writer, index=False)

        # Apply styles to the header row
        sheet = writer.sheets["Sheet1"]
        for cell in sheet[1]:
            cell.alignment = Alignment(
                horizontal="center", vertical="center"
            )  # Center align
            cell.fill = PatternFill(
                start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
            )  # Grey background

        # Adjust column widths based on content
        for col_idx, col_cells in enumerate(sheet.columns, 1):
            max_length = max(len(str(cell.value or "")) for cell in col_cells)
            sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        logging.info("### DataFrame written to Excel successfully.")

    # Get the value from the buffer
    bio.seek(0)
    blob_data = base64.b64encode(bio.read())
    logging.info("### DataFrame converted to blob successfully.")

    return blob_data


def export(data, max_rows=500):
    """
    Exports data from a database module to a base64-encoded Excel file (blob).

    Args:
        data (dict): Input parameters containing:
            - Partner (str): Name of the tenant or client..
            - module_name (str): Name of the module for which data is to be exported.
            - user_name (str): User requesting the export.
            - db_name (str): Tenant-specific database name.
            - ids (str or list): List or string of IDs for certain modules.

        max_rows (int, optional): The maximum number of rows allowed for export. 
                                  Defaults to 500.

    Returns:
        dict: A dictionary with:
            - flag (bool): True if export succeeded, False otherwise.
            - blob (str, optional): Base64-encoded string of Excel file if successful.
            - message (str, optional): Description of the outcome or error message.
    """
    logging.info(f"### Request Data: {data}")
    ### Extract parameters from the Request Data
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    user_name = data.get("user_name", "")
    session_id = data.get("session_id", "")
    tenant_database = data.get("db_name", "")
    ids = data.get("ids", "")
    ##database connection for common utilss
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    logging.info(f"### Fetching export query for module: {module_name}")
    # Start time  and date calculation
    start_time = time.time()
    try:
        ##databse connenction
        database = DB(tenant_database, **db_config)
        # Fetch the query from the database based on the module name
        module_query_df = db.get_data("export_queries", {"module_name": module_name})
        ##checking the dataframe is empty or not
        if module_query_df.empty:
            return {
                "flag": False,
                "message": f"No query found for module name: {module_name}",
            }
        # Extract the query string from the DataFrame
        query = module_query_df.iloc[0]["module_query"]
        if not query:
            logging.warning(f"### Unknown module name: {module_name}")
            return {"flag": False, "message": f"Unknown module name: {module_name}"}
        ##params for the specific module
        if module_name in ("inventory status history", "bulkchange status history"):
            params = [ids]
        else:
            params = [start_date, end_date]
        if module_name == "Users":
            data_frame = db.execute_query(query, params=params)
        else:
            data_frame = database.execute_query(query, params=params)
        # Check the number of rows in the DataFrame
        row_count = data_frame.shape[0]
        ##checking the max_rows count
        if row_count > max_rows:
            return {
                "flag": False,
                "message": f"Cannot export more than {max_rows} rows.",
            }
        if module_name == "NetSapiens Customers":
            data_frame["NetSapiensType"] = "Reseller"
        # Capitalize each word and add spaces
        data_frame.columns = [
            col.replace("_", " ").capitalize() for col in data_frame.columns
        ]
        data_frame["S.No"] = range(1, len(data_frame) + 1)
        # Reorder columns dynamically to put S.NO at the first position
        columns = ["S.No"] + [col for col in data_frame.columns if col != "S.No"]

        # Format specific columns with dollar symbol for "Rate Plan Socs" module
        if module_name == "Rate Plan Socs":
            if "Overage dollar mb" in data_frame.columns:
                data_frame["Overage dollar mb"] = data_frame["Overage dollar mb"].apply(
                    lambda x: f"${x}"
                )
            if "Base rate" in data_frame.columns:
                data_frame["Base rate"] = data_frame["Base rate"].apply(
                    lambda x: f"${x}"
                )

        if module_name == "Customer Rate Plan":
            # Check if "Id" column exists in data_frame
            if "Id" in data_frame.columns:
                try:
                    # Convert all "Id" values into a list for a single query
                    ids_list = data_frame["Id"].tolist()

                    # Use a single SQL query to get the counts for each ID at once
                    count_query = """
                        SELECT customer_rate_plan_id, COUNT(*) AS count
                        FROM sim_management_inventory
                        WHERE customer_rate_plan_id IN %s
                        GROUP BY customer_rate_plan_id
                    """

                    # Execute the single query with the list of IDs
                    count_results = database.execute_query(
                        count_query, params=(tuple(ids_list),)
                    )

                    # Convert the count results to a dictionary for quick lookup
                    tn_counts_dict = {
                        int(row["customer_rate_plan_id"]): row["count"]
                        for _, row in count_results.iterrows()
                    }

                    # Map counts back to the DataFrame
                    data_frame["# of TNs"] = (
                        data_frame["Id"]
                        .map(tn_counts_dict)
                        .fillna(0)
                        .astype(int)
                        .astype(str)
                    )
                    columns.append("# of TNs")
                    columns.remove("Id")

                except Exception as e:
                    logging.exception(
                        f"### Failed to retrieve count for Customer Rate Plan: {e}"
                    )
                    return {
                        "flag": False,
                        "message": f"An error occurred while fetching count for Rate Plan: {e}",
                    }

        data_frame = data_frame[columns]
        # Proceed with the export if row count is within the allowed limit
        data_frame = data_frame.astype(str)
        data_frame.replace(to_replace="None", value="", inplace=True)
        logging.info("### Converting DataFrame to blob.")

        blob_data = dataframe_to_blob(data_frame)
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))

        # Return JSON response
        response = {"flag": True, "blob": blob_data.decode("utf-8")}
        audit_data_user_actions = {
            "service_name": "export",
            "created_by": user_name,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "Exports data from a database into an Excel file",
            "module_name": "Module Management",
            "request_received_at": request_received_at,
        }
        db.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("### Auditing user actions.")
        return response
    except Exception as e:
        error_type = str(type(e).__name__)
        logging.exception(f"### An error occurred  while Exporting data from a database into an Excel file : {e}")
        message = "something went wrong while Exporting data from a database into an Excel file"
        response = {"flag": False, "message": message}
        try:
            # Log error to database
            error_data = {
                "service_name": "export",
                "error_message": str(e),
                "error_type": error_type,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Exception is : {e}")
        return response


def rate_plan_dropdown_data_optimization_groups(data):
    """
    Retrieves active rate plan dropdown data grouped by service provider for optimization groups.

    Args:
        data (dict): Dictionary containing:
            - db_name (str): Name of the tenant-specific database.
            - username (str, optional): User who made the request.
            - sessionID (str, optional): Session identifier for auditing.
            - Partner (str, optional): Tenant name for auditing.
            - request_received_at (str, optional): Request timestamp for auditing.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Indicates if the operation was successful.
            - rate_plans_list (dict): Keys are service provider names, values are lists of
              strings formatted as "friendly_name -- rate_plan_code".
            - rate_plan_codes (dict): Keys are service provider names, values are lists of
              raw rate_plan_code strings.
    """

    logging.info(f"### Request Data is : {data}")
    tenant_database = data.get("db_name", None)
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try : 
        env=os.environ["ENV"]
        if env=='PROD':
            service_provider_names = ["AT&T - Telegence"]
        else:
            service_provider_names = ["AT&T - Telegence - UAT ONLY"]
        # Initialize an empty dictionary to store the results
        rate_plans_list = {}
        rate_plan_code_dict = {}
        # Iterate over each service provider name
        for service_provider_name in service_provider_names:
            # Get the rate plan codes for the current service provider name
            carrier_data_query = f'''
                    select friendly_name,rate_plan_code from carrier_rate_plan
                    where service_provider='{service_provider_name}' and is_active=True
                    order by friendly_name asc
                '''
            carrier_data = database.execute_query(carrier_data_query, True)
            carrier_data['temp_name'] = carrier_data['friendly_name'].combine_first(carrier_data['rate_plan_code'])
            rate_plan_items = (carrier_data['temp_name'] + ' -- ' + carrier_data['rate_plan_code'].fillna("")).to_list()
            carrier_rate_plan_code = carrier_data["rate_plan_code"].to_list()
            # Add the result to the dictionary
            rate_plans_list[service_provider_name] = rate_plan_items
            rate_plan_code_dict[service_provider_name] = carrier_rate_plan_code
            
        response =  {"flag": True, "rate_plans_list": rate_plans_list, "rate_plan_codes": rate_plan_code_dict}
        try:
            audit_data_user_actions = {
                "service_name": "rate_plan_dropdown_data_optimization_groups",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module_management",
                "comments": "fetched optimization groups rate plan dropdown data successfully",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
             logging.warning(f"### Audit logging exception: {e}")

        return response  

    except Exception as e:
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error in getting optimization groups rate plan dropdown data : {e}")
        message = "Something went wrong while fetching optimization groups rate plan dropdown data "
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "rate_plan_dropdown_data_optimization_groups",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
 
        response =  {
            "flag": False,
            "rate_plans_list": {},
            "rate_plan_codes": {},
            "message": message
            }
        return response  
    


def get_status_history(data):
    """
    Fetches the status history of a SIM record from the tenant database.


    Args:
        data (dict): A dictionary containing:
            - list_view_data_id (int or str): ID of the SIM list view data.
            - username (str): Username making the request.
            - Partner (str): Tenant name or partner name.
            - role_name (str): Role of the user.
            - iccid (str): ICCID of the SIM for which history is being fetched.
            - db_name (str): Name of the tenant database (defaults to "altaworx_central").

    Returns:
        dict: A dictionary with:
            - flag (bool): True if data is found or successfully processed, False otherwise.
            - status_history_data (list): List of status change records (can be empty).
            - header_map (dict): Header mapping used by the front end for display.
            - message (str): Description of success or failure of the operation.
    """
    # Start time  and date calculation
    start_time = time.time()
    ##fetching the request data
    list_view_data_id = data.get("list_view_data_id", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    Partner = data.get("Partner", "")
    role_name = data.get("role_name", "")
    list_view_data_id = int(list_view_data_id)
    iccid = data.get("iccid", "")
    request_received_at = data.get("request_received_at", None)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_database = data.get("db_name", "altaworx_central")
    logging.info(f"### Received request to get status history for ID: {list_view_data_id}")
    try:
        ##Database connection
        database = DB(tenant_database, **db_config)
        # Fetch status history data from the database
        sim_management_inventory_action_history_dict = database.get_data(
            "sim_management_inventory_action_history",
            {"iccid": iccid},
            [
                "service_provider",
                "iccid",
                "msisdn",
                "customer_account_number",
                "customer_account_name",
                "previous_value",
                "current_value",
                "date_of_change",
                "change_event_type",
                "changed_by",
            ],
        ).to_dict(orient="records")
        logging.info(
            f"""### Fetched {len(sim_management_inventory_action_history_dict)}
            records for ID: {list_view_data_id}
            """
        )
        # Handle case where no data is returned
        if not sim_management_inventory_action_history_dict:
            ##Fetching the header map for the inventory status history
            headers_map = get_headers_mapping(
                tenant_database,
                ["inventory status history"],
                role_name,
                "username",
                "main_tenant_id",
                "sub_parent_module",
                "parent_module",
                data,
                common_utils_database,
            )
            logging.info("### Status history data fetched successfully.")
            message = "No status history data found for the provided SIM management inventory ID."
            response = {
                "flag": True,
                "status_history_data": [],
                "header_map": headers_map,
                "message": message,
            }
            return response

        # Helper function to serialize datetime objects to strings
        def serialize_dates(data):
            for key, value in data.items():
                if isinstance(value, datetime):
                    data[key] = value.strftime("%m-%d-%Y %H:%M:%S")
            return data

        # Apply date serialization to each record
        sim_management_inventory_action_history_dict = [
            serialize_dates(record)
            for record in sim_management_inventory_action_history_dict
        ]
        ##Fetching the header map for the inventory status history
        headers_map = get_headers_mapping(
            tenant_database,
            ["inventory status history"],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )
        message = "Status History data Fetched Successfully"
        # Prepare success response
        response = {
            "flag": True,
            "status_history_data": sim_management_inventory_action_history_dict,
            "header_map": headers_map,
            "message": message,
        }
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "get_status_history",
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f"fetched status history for: {list_view_data_id}",
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"### exception is: {e}")
        return response
    except Exception as e:
        logging.exception(f"### An error occurred while fetching the status history data: {e}")
        message = "Unable to fetch the status history data"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_status_history",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message ,
                "module_name": "Module Managament",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### exception is {e}")
        return response

def reports_data(data):
    """
    Retrieves report data for a given module, applies filters and formatting, and logs actions or errors.

    Args:
        data (dict): A dictionary containing:
            - module_name (str): Name of the report module (e.g., 'Usage By Line Report').
            - username (str): Name of the user making the request.
            - Partner (str): Partner/tenant display name for logging.
            - mod_pages (dict): Pagination dictionary containing "start" and page size.
            - role_name (str): User's role (e.g., 'Partner Admin', 'Super Admin').
            - col_sort (dict): Dictionary with one key-value pair for sorting, e.g., {"date_activated": "desc"}.
            - tenant_name (str): Name of the tenant requesting the report.
            - db_name (str): Database name specific to the tenant.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if report generation succeeded, otherwise False.
            - message (str): Success or failure message.
            - headers_map (dict): Column headers mapping for frontend display.
            - data (list): List of records returned from the report query (empty if failed).
            - pages (dict): (Reserved) Pagination details if implemented in frontend.
    """
    # Start time and date calculation
    start_time = time.time()
    module_name = data.get("module_name", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", None)
    Partner = data.get("Partner", "")
    mod_pages = data.get("mod_pages", {})
    role_name = data.get("role_name", "")
    col_sort = data.get("col_sort", "")
    limit = mod_pages.get("", 100)
    offset = mod_pages.get("start", 0)
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    tenant_database = data.get("db_name", "")
    try:
        if db_config and "customer_rate_plan_name" in db_config:
            del db_config["customer_rate_plan_name"]
    except Exception as e:
        logging.exception(f"### Exception is : {e}")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    return_json_data = {}
    pages = {}
    optimization_setting_table='optimization_setting'
    try:
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]
        try:
            parent_tenant_query=f'''select parent_tenant_id from tenant where tenant_name='{tenant_name}'
            '''
            parent_tenant_id_df=common_utils_database.execute_query(parent_tenant_query,True)
            if not parent_tenant_id_df.empty:
                parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

                if parent_tenant_id is not None:
                    optimization_setting_table='optimization_setting_tenant_override'
                else:
                    optimization_setting_table='optimization_setting'
        except Exception as e:
            logging.exception(f"### Exception is : {e}")
        p = database.get_data(
                optimization_setting_table,
                {"tenant_id":tenant_id},
                ["optino_cross_providercustomer_optimization"],
            ).iloc[0, 0]
        if (
            db_config.get("customers") or db_config.get("service_providers")
        ) and module_name in ["Usage By Line Report"]:
            try:
                customers_raw = db_config["customers"]
                customers_eval = ast.literal_eval(customers_raw)
                # Handle cases where the parsed result is a single string
                logging.info(f"### customers_eval : {customers_eval}")
                # Handle cases where the parsed result is a single string
                if isinstance(customers_eval, str):
                    customers_list = [customers_eval]  # Wrap single string in a list
                elif isinstance(customers_eval, (tuple, list)):
                    customers_list = list(customers_eval)  # Convert tuple to list if needed
                else:
                    customers_list = []
                # Properly format for SQL ARRAY
                logging.info(f"### customers_list : {customers_list}")
                cutomers = [customer.strip() for customer in customers_list]
            except Exception:
                cutomers = []
                logging.exception("### Exception while fetching customers")
            try:
                service_provider_ids = list(db_config["service_provider_id"])
                service_provider_ids = [str(i) for i in service_provider_ids]
            except Exception as e:
                service_provider_ids = []
                logging.exception(f"### reports_data Exception while fetching service provider ids : {e}")

            logging.info(f"### cutomers : {cutomers} service_provider_ids : {service_provider_ids}")
            if not p:
                if cutomers and service_provider_ids:
                    query = f"""SELECT * FROM public.fetch_usage_by_service_provider_for_mul(ARRAY{service_provider_ids},ARRAY{cutomers},100,{offset},{tenant_id});"""
                elif cutomers:
                    query = f"""SELECT * FROM public.fetch_usage_by_service_provider_for_mul(NULL,ARRAY{cutomers},100,{offset},{tenant_id});"""
                else:
                    query = f"""SELECT * FROM public.fetch_usage_by_service_provider_for_mul(ARRAY{service_provider_ids},NULL,100,{offset},{tenant_id});"""
            else:
                if cutomers and service_provider_ids:
                    query = f"""SELECT * FROM public.fetch_usage_by_service_provider_for_mul_cross_provider(ARRAY{service_provider_ids},ARRAY{cutomers},100,{offset},{tenant_id});"""
                elif cutomers:
                    query = f"""SELECT * FROM public.fetch_usage_by_service_provider_for_mul_cross_provider(NULL,ARRAY{cutomers},100,{offset},{tenant_id});"""
                else:
                    query = f"""SELECT * FROM public.fetch_usage_by_service_provider_for_mul_cross_provider(ARRAY{service_provider_ids},NULL,100,{offset},{tenant_id});"""
            df = database.execute_query(query, flag=True, no_filter_append=True)

        else:
            module_query_df = common_utils_database.get_data(
                "export_queries", {"module_name": module_name}
            )
            if module_query_df.empty:
                raise ValueError(f"No query found for module name: {module_name}")
            if module_name == "Usage By Line Report":
                p = database.get_data(
                optimization_setting_table,
                {"tenant_id":tenant_id},
                ["optino_cross_providercustomer_optimization"],
            ).iloc[0, 0]
                if not p:
                    query = """
                            SELECT service_provider_display_name,billing_cycle_end_date,iccid,msisdn,foundation_account_number,billing_account_number,customer_rate_pool_name,customer_name,username,carrier_rate_plan,rate_plan_name,integration_id,data_usage_mb,status_display_name,date_activated,tenant_id FROM public.vw_usage_by_line_report where tenant_id = %s   LIMIT %s OFFSET %s
                            """
                else:
                    query = """
                            select service_provider_display_name,billing_cycle_end_date,customer_cycle_end_date,iccid,msisdn,foundation_account_number,billing_account_number,customer_rate_pool_name,customer_name,username,carrier_rate_plan,rate_plan_name,integration_id,data_usage_mb,status_display_name,date_activated,tenant_id from usp_report_customer_usage_by_line where tenant_id = %s   LIMIT %s OFFSET %s
                            """
            else:
                query = module_query_df.iloc[0]["module_query"]
            if not query:
                raise ValueError(f"Unknown module name: {module_name}")

            if module_name in [
                "Usage By Line Report",
                "Customer Rate Pool Usage Report",
                "Zero Usage Report",
                "Newly Activated Report",
                "Active Lines Reports",
                "Device Logs Report"
            ]:
                params = [tenant_id, limit, offset]

            elif module_name in [

                "Automation rule verification report",

            ]:
                params = [limit, offset]
            elif module_name in [

                "Status History Report",

            ]:

                params = [tenant_id, offset]
            else:
                params = [tenant_id, limit, offset]
            # Modify query handling for ORDER BY
            # Modify query handling for ORDER BY
            if col_sort:
                # Remove existing ORDER BY clause
                order_by_pattern = r"\sORDER\s+BY\s+[^)]+(?=\s*LIMIT)"
                query = re.sub(order_by_pattern, "", query, flags=re.IGNORECASE)

                # Extract the single key-value pair
                key, value = list(col_sort.items())[0]
                if key in ("billing_cycle_end_date" "date_activated", "date_of_change"):
                    custom_order_by = f"{key}::TIMESTAMP {value.upper()}"
                else:
                    # Default single-column ORDER BY clause
                    custom_order_by = f"{key} {value.upper()}"

                # Ensure ORDER BY comes before LIMIT and OFFSET
                limit_offset_match = re.search(
                    r"(LIMIT\s+%s\s+OFFSET\s+%s)", query, re.IGNORECASE
                )

                if limit_offset_match:
                    # Replace LIMIT and OFFSET with ORDER BY correctly placed
                    limit_offset_clause = limit_offset_match.group(1)
                    query = query.replace(
                        limit_offset_clause,
                        f"ORDER BY {custom_order_by} {limit_offset_clause}",
                    )
                else:
                    # Append ORDER BY at the end if no LIMIT and OFFSET found
                    query += f" ORDER BY {custom_order_by}"
            logging.info(f"### Query to info easily : {query}")
            df = database.execute_query(query, params=params)
            # print("query =====================>",query)
            # print("df =======================>",df)

        # Adjust dates for specific modules
        if module_name in [
            "Usage By Line Report",
            "Newly Activated Report",
            "Customer Rate Pool Usage Report",
            "Zero Usage Report",
        ]:
            column_name = (
                "billing_cycle_end_date"
                if module_name != "Customer Rate Pool Usage Report"
                else "billing_period_end_date"
            )
            if column_name in df.columns:
                df[column_name] = pd.to_datetime(df[column_name])

                df[column_name] = df[column_name].apply(
                    lambda date: (
                        (date - pd.Timedelta(days=1)).replace(
                            hour=23, minute=59, second=59
                        )
                        if pd.notna(date)
                        and date.time() == pd.Timestamp("00:00:00").time()
                        else date
                    )
                )

        tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)

        # Convert data and map headers
        df_dict = df.to_dict(orient="records")

        try:
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
        except Exception as e:
            logging.exception(f"### reports_data Failed to convert the timezone : {e}")
        headers_map = get_headers_mapping(
            tenant_database,
            [module_name],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )

        # Prepare response data
        return_json_data.update(
            {
                "message": "Successfully generated the report",
                "flag": True,
                "headers_map": headers_map,
                "data": serialize_data(df_dict),
                "pages": pages,
            }
        )

        # End time and audit logging
        end_time = time.time()
        time_consumed = int(end_time - start_time)
        audit_data_user_actions = {
            "service_name": "reports_data",
            "created_by": username,
            "status": str(return_json_data["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": f"fetches Reports data - {module_name}",
            "module_name": "Module Management",
            "request_received_at": request_received_at,
        }
        common_utils_database.update_audit(
            audit_data_user_actions, "audit_user_actions"
        )
        return return_json_data

    except Exception as e:
        logging.exception(f"### An error occurred while fetching the reports data: {e}")
        message = "Unable to fetch the reports data"
        headers_map = get_headers_mapping(
            tenant_database,
            [module_name],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )
        response = {"flag": True, "message": message,"headers_map": headers_map}

        error_type = str(type(e).__name__)
        try:
            error_data = {
                "service_name": "reports_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Exception while logging error: {e}")
        return response
       
def convert_booleans(data):
    """
    Recursively converts string boolean values ("true"/"false") to Python booleans in a dictionary.

    Args:
        data (dict): A dictionary possibly containing string representations of booleans.

    Returns:
        dict: A dictionary with all string boolean values converted to actual Python booleans.
    """
    logging.info(f"### Initial data for conversion: {data}")
    for key, value in data.items():
        if isinstance(value, str) and value.lower() == "true":
            data[key] = True
            logging.info(f"### Converted '{key}' from string 'true' to boolean True")
        elif isinstance(value, str) and value.lower() == "false":
            data[key] = False
            logging.info(f"### Converted '{key}' from string 'false' to boolean False")
        elif isinstance(value, dict):  # Recursively process nested dictionaries
            logging.info(
                f"### Found nested dictionary at key '{key}', processing recursively."
            )
            convert_booleans(value)
    return data  # Return the modified dictionary


# def get_modules(data):
#     """
#     Retrieves and formats modules and sub-modules for a tenant and user based on roles, permissions,
#     and configurations in the database.

#     Args:
#         data (dict): Input data containing the following keys:
#             - username (str): Username of the user.
#             - tenant_name (str): Name of the tenant.
#             - session_id (str, optional): Session ID of the user (not used in processing).
#             - role_name (str): Role of the user (e.g., "Super Admin").
#             - db_name (str, optional): Name of the database (default is empty string).

#     Returns:
#         dict: A response dictionary containing the following keys:
#             - flag (bool): Indicates success of the operation.
#             - message (str): Success message.
#             - Modules (list): List of formatted module data with parent modules, child modules,
#               and sub-children.
#             - logo (str): Logo of the tenant.
#     """
#     # start_time = time.time()
#     try:
#         del db_config['customers']
#         del db_config['service_providers']
#         del db_config['billing_account_number']
#         del db_config['feature_codes']
#         del db_config['tenant_ids']
#     except Exception as e:
#         logging.info(f'Exception is {e}')
#     username = data.get("username", None)
#     tenant_name = data.get("tenant_name", None)
#     data.get("session_id", None)
#     role_name = data.get("role_name", None)
#     data.get("db_name", "")
#     db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
#     tenant_id = db.get_data("tenant", {"tenant_name": tenant_name}, ["id"])[
#         "id"
#     ].to_list()[0]
#     # Step 1: Fetch tenant modules
#     tenant_module_query_params = [tenant_name]
#     tenant_module_query = """SELECT module_name
#                              FROM tenant_module
#                              WHERE tenant_name = %s AND is_active = TRUE order by id asc;"""
#     tenant_module_dataframe = db.execute_query(
#         tenant_module_query, params=tenant_module_query_params
#     )

#     main_tenant_modules = tenant_module_dataframe["module_name"].to_list()
#     logging.info(f"Tenant modules fetched: {main_tenant_modules}")
#     user_module_df = db.get_data(
#         "user_module_tenant_mapping",
#         {"user_name": username, "tenant_id": tenant_id},
#         ["module_names", "sub_module"],
#     ).to_dict(orient="records")
#     logging.info(f'user_module_df is {user_module_df}')
#     # Step 2: Handle modules based on role
#     if (role_name.lower() == "super admin") and (
#         not user_module_df or not user_module_df[0].get("module_names")
#     ):
#         # For Super Admin, get all tenant modules
#         final_modules = [
#             {"module": mod, "sub_module": []} for mod in main_tenant_modules
#         ]  # Ensure final_modules is a list of dicts
#         logging.info(f'final_modules----{final_modules}')
#     else:
#         # Fetch role modules for non-super admin
#         role_module_data = db.get_data(
#             "role_module", {"role": role_name}, ["module", "sub_module"]
#         ).to_dict(orient="records")
#         # role_module_query=f"select module,sub_module from role_module"
#         # role_module_data=db.execute_query(role_module_query,True).to_dict(
#         #         orient="records"
#         #             )
#         # Step 2.1: Deserialize the JSON-like strings if needed
#         if role_module_data:
#             for item in role_module_data:
#                 item["module"] = json.loads(
#                     item["module"]
#                 )  # Convert module string to list
#                 item["sub_module"] = json.loads(
#                     item["sub_module"]
#                 )  # Convert sub_module string to dict

#         # Step 3: Filter role modules by tenant modules
#         filtered_modules = []
#         for module in role_module_data:
#             # Iterate over the list of modules
#             for mod in module["module"]:
#                 if mod in main_tenant_modules:
#                     filtered_modules.append(
#                         {
#                             "module": mod,
#                             "sub_module": module["sub_module"].get(
#                                 mod, []
#                             ),  # Get sub_modules or empty list if not found
#                         }
#                     )

#         # Step 4: Add filtered modules to final_modules
#         final_modules = filtered_modules
#         logging.info(f"Final modules after filtering: {final_modules}")
#     # Fetch the data from the database
#     result = db.get_data(
#         "tenant", {"tenant_name": tenant_name}, ["logo", "id", "db_name","collapsed_logo","billing_platform_flag"]
#     )
#     billing_platform_flag = result["billing_platform_flag"].to_list()[0]
#     if not user_module_df or not user_module_df[0].get("module_names"):
#         # If no user-specific modules are found, use final_modules as is
#         logging.info("No user-specific modules found, using final modules.")
#         # Now `final_modules` contains either the filtered data or the entire modules
#         # if no filtering was applied.
#         logging.info(final_modules, "ghbjklhjgvbjkhvhjlhvbjhb")
#         # Transforming the keys
#         transformed_data = [
#             {"parent_module_name": item["module"], "module_name": item["sub_module"]}
#             for item in final_modules  # Use final_modules instead of data
#         ]

#         # logging.info the transformed data
#         logging.info("transformed_data", transformed_data)
#         module_table_df = db.get_data(
#             "module",
#             {"is_active": True},
#             ["module_name", "parent_module_name", "submodule_name"],
#             {"id": "asc"},
#         ).to_dict(orient="records")

#         # Process the data
#         formatted_data = format_module_data(
#             transformed_data, main_tenant_modules, module_table_df, role_name
#         )

#         # Output the formatted data
#         logging.info(formatted_data)
#     else:
#         # Convert module_names to a list
#         module_names_list = json.loads(user_module_df[0]["module_names"])

#         # Convert sub_module JSON string to a dictionary
#         sub_module_dict = json.loads(user_module_df[0]["sub_module"])

#         # Prepare the output data
#         filtered_output = []

#         # Iterate through the module names to filter based on the user data
#         for module_name in module_names_list:
#             # Get the corresponding sub_modules
#             valid_sub_modules = []
#             for sub_module in sub_module_dict.get(module_name, []):
#                 # You can apply any further logic if needed for filtering sub_modules
#                 valid_sub_modules.append(sub_module)

#             # Append valid module and sub_modules to the output
#             if valid_sub_modules:
#                 filtered_output.append(
#                     {
#                         "parent_module_name": module_name,
#                         "module_name": valid_sub_modules,
#                     }
#                 )

#         # Final output
#         filter_data = filtered_output
#         modules = []
#         module_data = db.get_data(
#             "module", {}, ["id", "parent_module_name", "module_name", "submodule_name"],order={"order_by": "asc"}
#         ).to_dict(orient="records")

#         # Initialize lists to store filtered results
#         filtered_results = []

#         # Loop through the filter data
#         for filter_item in filter_data:
#             parent_name = filter_item["parent_module_name"]
#             module_names = filter_item["module_name"]

#             # Check the module_data for matching parent and module names
#             for module_item in module_data:
#                 # Check if the parent_module_name matches
#                 if module_item["parent_module_name"] == parent_name:
#                     # Now, only add if the module_name or submodule_name exists in filter data
#                     if (
#                         module_item["module_name"] in module_names
#                         or module_item["submodule_name"] in module_names
#                     ):
#                         filtered_results.append(module_item)
#                     elif (
#                         not module_item["module_name"]
#                         and not module_item["submodule_name"]
#                     ):
#                         filtered_results.append(module_item)

#         # Create structured output for modules with IDs
#         modules = []  # Resetting modules to gather results
#         logging.info(f"filtered_results is {filtered_results}")
#         for item in filtered_results:
#             module_entry = {
#                 "id": item["id"],  # Use the existing ID from module_data
#                 "parent_module_name": item["parent_module_name"],
#                 "module_name": item["module_name"],
#                 "submodule_name": item["submodule_name"],
#             }
#             modules.append(module_entry)

#         # logging.info the structured modules list
#         my_dict = modules
#         # Initialize the output structure
#         output_structure = []

#         # Group by parent_module_name
#         logging.info(f'my_dict is {my_dict}')
#         for item in my_dict:
#             parent_name = item["parent_module_name"]
#             # Check if the parent entry already exists
#             parent_entry = next(
#                 (
#                     entry
#                     for entry in output_structure
#                     if entry["parent_module_name"] == parent_name
#                 ),
#                 None,
#             )
#             if not parent_entry:
#                 parent_entry = {
#                     "parent_module_name": parent_name,
#                     "queue_order": item["id"],  # Use id as queue_order for parent
#                     "children": [],
#                 }
#                 output_structure.append(parent_entry)

#             # Only add a child if module_name is not None
#             if item["module_name"] is not None:
#                 # Check if the child module already exists
#                 child_entry = next(
#                     (
#                         child
#                         for child in parent_entry["children"]
#                         if child["child_module_name"] == item["module_name"]
#                     ),
#                     None,
#                 )

#                 if not child_entry:
#                     child_entry = {
#                         "child_module_name": item["module_name"],
#                         "queue_order": len(parent_entry["children"])
#                         + 1,  # Position-based queue_order for children
#                         "sub_children": [],  # Always include sub_children key
#                     }
#                     parent_entry["children"].append(child_entry)

#                 # If there is a submodule, add it to sub_children
#                 if item["submodule_name"]:
#                     sub_child_entry = {
#                         "sub_child_module_name": item["submodule_name"],
#                         "queue_order": len(child_entry["sub_children"])
#                         + 1,  # Position-based queue_order for sub-children
#                         "sub_children": [],  # Always include sub_children key for sub-modules
#                     }
#                     child_entry["sub_children"].append(sub_child_entry)
#         try:
#             output_structure = filter_modules_by_flag(output_structure, billing_platform_flag)
#         except Exception as e:
#             logging.info(f'Exception while removing billing platform modules{e}')
#         logging.info(f'output_structure---------{output_structure}')
#         formatted_data = output_structure
    

#     # ordring modules
#     parent_module_order_query = (
#         "select parent_module_name,parent_module_order from module"
#     )
#     parent_module_order = db.execute_query(parent_module_order_query, True).to_dict(
#         orient="records"
#     )

#     module_order = {}
#     for mod in parent_module_order:
#         module_order[mod["parent_module_name"]] = mod["parent_module_order"]

#     new_formated_data = []
#     logging.info(f"formatted_data is {formatted_data}")
#     for modules in formatted_data:
#         temp = modules
#         if modules["parent_module_name"] in module_order:
#             temp["queue_order"] = int(module_order[modules["parent_module_name"]])
#         new_formated_data.append(temp)

#     logging.info(f"new_formated_data is {new_formated_data}")
#     new_formated_data = sorted(new_formated_data, key=lambda x: x["queue_order"])

#     # Extract 'logo' and 'id' separately
#     logo = result["logo"].to_list()[0]  # Assuming the result contains a column 'logo'
#     tenant_id = result["id"].to_list()[0]  # Assuming the result contains a column 'id'
#     db_name = result["db_name"].to_list()[
#         0
#     ]  # Assuming the result contains a column 'id'
#     collapsed_logo = result["collapsed_logo"].to_list()[0]
    
#     message = "Module data sent sucessfully"
#     response = {
#         "flag": True,
#         "message": message,
#         "Modules": new_formated_data,
#         "logo": logo,
#         "billing_platform_flag":billing_platform_flag,
#         "collapsed_logo":collapsed_logo,
#         "tenant_id": tenant_id,
#         "db_name": db_name,
#     }
#     logging.info("get_modules function executed successfully")
#     try:
#         audit_data_user_actions = {
#             "service_name":"get_modules",
#             "created_date": data.get("request_received_at", ""),
#             "created_by": username,
#             "status": "Success",
#             "session_id": data.get("sessionID", ""),
#             "tenant_name": tenant_name,
#             "module_name": "Module management",
#             "comments": "fetch modules data",
#             "request_received_at": data.get("request_received_at", ""),
#         }

#         db.update_audit(audit_data_user_actions, "audit_user_actions")
#     except Exception as e:
#         logging.warning(f"Exception is {e}")
#     return response

def get_modules(data):
    """
    Retrieves and formats modules and sub-modules for a tenant and user based on roles, permissions,
    and configurations in the database.

    Args:
        data (dict): Input data containing the following keys:
            - username (str): Username of the user.
            - tenant_name (str): Name of the tenant.
            - session_id (str, optional): Session ID of the user (not used in processing).
            - role_name (str): Role of the user (e.g., "Super Admin").
            - db_name (str, optional): Name of the database (default is empty string).

    Returns:
        dict: A response dictionary containing the following keys:
            - flag (bool): Indicates success of the operation.
            - message (str): Success message.
            - Modules (list): List of formatted module data with parent modules, child modules,
              and sub-children.
            - logo (str): Logo of the tenant.
    """
    # start_time = time.time()
    try:
        del db_config['customers']
        del db_config['service_providers']
        del db_config['billing_account_number']
        del db_config['feature_codes']
        del db_config['tenant_ids']
    except Exception as e:
        logging.info(f'### Exception is : {e}')
    ### try block added here 
    logging.info(f"### get_modules data {data}")
    try :     
        username = data.get("username", None)
        tenant_name = data.get("tenant_name", None)
        data.get("session_id", None)
        ui_timeout=None
        role_name = data.get("role_name", None)
        data.get("db_name", "")
        db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        tenant_id = db.get_data("tenant", {"tenant_name": tenant_name}, ["id"])[
            "id"
        ].to_list()[0]
        # Step 1: Fetch tenant modules
        tenant_module_query_params = [tenant_name]
        tenant_module_query = """SELECT module_name
                                FROM tenant_module
                                WHERE tenant_name = %s AND is_active = TRUE order by id asc;"""
        tenant_module_dataframe = db.execute_query(
            tenant_module_query, params=tenant_module_query_params
        )

        main_tenant_modules = tenant_module_dataframe["module_name"].to_list()
        logging.info(f"### Tenant modules fetched: {main_tenant_modules}")
        user_module_df = db.get_data(
            "user_module_tenant_mapping",
            {"user_name": username, "tenant_id": tenant_id},
            ["module_names", "sub_module"],
        ).to_dict(orient="records")
        logging.info(f'### user_module_df is : {user_module_df}')
        # Step 2: Handle modules based on role
        if (role_name.lower() == "super admin") and (
            not user_module_df or not user_module_df[0].get("module_names")
        ):
            # For Super Admin, get all tenant modules
            final_modules = [
                {"module": mod, "sub_module": []} for mod in main_tenant_modules
            ]  # Ensure final_modules is a list of dicts
            logging.info(f'### final_modules----{final_modules}')
        else:
            # Fetch role modules for non-super admin
            role_module_data = db.get_data(
                "role_module", {"role": role_name}, ["module", "sub_module"]
            ).to_dict(orient="records")
            # role_module_query=f"select module,sub_module from role_module"
            # role_module_data=db.execute_query(role_module_query,True).to_dict(
            #         orient="records"
            #             )
            # Step 2.1: Deserialize the JSON-like strings if needed
            if role_module_data:
                for item in role_module_data:
                    item["module"] = json.loads(
                        item["module"]
                    )  # Convert module string to list
                    item["sub_module"] = json.loads(
                        item["sub_module"]
                    )  # Convert sub_module string to dict

            # Step 3: Filter role modules by tenant modules
            filtered_modules = []
            for module in role_module_data:
                # Iterate over the list of modules
                for mod in module["module"]:
                    if mod in main_tenant_modules:
                        filtered_modules.append(
                            {
                                "module": mod,
                                "sub_module": module["sub_module"].get(
                                    mod, []
                                ),  # Get sub_modules or empty list if not found
                            }
                        )

            # Step 4: Add filtered modules to final_modules
            final_modules = filtered_modules
            logging.info(f"### Final modules after filtering: {final_modules}")
        # Fetch the data from the database
        result = db.get_data(
            "tenant", {"tenant_name": tenant_name}, ["logo", "id", "db_name","collapsed_logo","billing_platform_flag","dark_mode_logo","dark_mode_collapsed_logo"]
        )
        billing_platform_flag = result["billing_platform_flag"].to_list()[0]
        if not user_module_df or not user_module_df[0].get("module_names"):
            # If no user-specific modules are found, use final_modules as is
            logging.info("### No user-specific modules found, using final modules.")
            # Now `final_modules` contains either the filtered data or the entire modules
            # if no filtering was applied.
            logging.info(f"### final_modules : {final_modules}")
            # Transforming the keys
            transformed_data = [
                {"parent_module_name": item["module"], "module_name": item["sub_module"]}
                for item in final_modules  # Use final_modules instead of data
            ]

            logging.info(f"### transformed_data : {transformed_data}")
            module_table_df = db.get_data(
                "module",
                {"is_active": True},
                ["module_name", "parent_module_name", "submodule_name"],
                {"id": "asc"},
            ).to_dict(orient="records")

            # Process the data
            formatted_data = format_module_data(
                transformed_data, main_tenant_modules, module_table_df, role_name
            )

            # Output the formatted data
            logging.info(f"### formatted_data : {formatted_data}")
        else:
            # Convert module_names to a list
            module_names_list = json.loads(user_module_df[0]["module_names"])

            # Convert sub_module JSON string to a dictionary
            sub_module_dict = json.loads(user_module_df[0]["sub_module"])

            # Prepare the output data
            filtered_output = []

            # Iterate through the module names to filter based on the user data
            for module_name in module_names_list:
                # Get the corresponding sub_modules
                valid_sub_modules = []
                for sub_module in sub_module_dict.get(module_name, []):
                    # You can apply any further logic if needed for filtering sub_modules
                    valid_sub_modules.append(sub_module)

                # Append valid module and sub_modules to the output
                if valid_sub_modules:
                    filtered_output.append(
                        {
                            "parent_module_name": module_name,
                            "module_name": valid_sub_modules,
                        }
                    )

            # Final output
            filter_data = filtered_output
            modules = []
            module_data = db.get_data(
                "module", {}, ["id", "parent_module_name", "module_name", "submodule_name"],order={"order_by": "asc"}
            ).to_dict(orient="records")

            # Initialize lists to store filtered results
            filtered_results = []

            # Loop through the filter data
            for filter_item in filter_data:
                parent_name = filter_item["parent_module_name"]
                module_names = filter_item["module_name"]

                # Check the module_data for matching parent and module names
                for module_item in module_data:
                    # Check if the parent_module_name matches
                    if module_item["parent_module_name"] == parent_name:
                        # Now, only add if the module_name or submodule_name exists in filter data
                        if (
                            module_item["module_name"] in module_names
                            or module_item["submodule_name"] in module_names
                        ):
                            filtered_results.append(module_item)
                        elif (
                            not module_item["module_name"]
                            and not module_item["submodule_name"]
                        ):
                            filtered_results.append(module_item)

            # Create structured output for modules with IDs
            modules = []  # Resetting modules to gather results
            logging.info(f"### filtered_results is : {filtered_results}")
            for item in filtered_results:
                module_entry = {
                    "id": item["id"],  # Use the existing ID from module_data
                    "parent_module_name": item["parent_module_name"],
                    "module_name": item["module_name"],
                    "submodule_name": item["submodule_name"],
                }
                modules.append(module_entry)

            my_dict = modules
            # Initialize the output structure
            output_structure = []

            # Group by parent_module_name
            logging.info(f'### my_dict is : {my_dict}')
            for item in my_dict:
                parent_name = item["parent_module_name"]
                # Check if the parent entry already exists
                parent_entry = next(
                    (
                        entry
                        for entry in output_structure
                        if entry["parent_module_name"] == parent_name
                    ),
                    None,
                )
                if not parent_entry:
                    parent_entry = {
                        "parent_module_name": parent_name,
                        "queue_order": item["id"],  # Use id as queue_order for parent
                        "children": [],
                    }
                    output_structure.append(parent_entry)

                # Only add a child if module_name is not None
                if item["module_name"] is not None:
                    # Check if the child module already exists
                    child_entry = next(
                        (
                            child
                            for child in parent_entry["children"]
                            if child["child_module_name"] == item["module_name"]
                        ),
                        None,
                    )

                    if not child_entry:
                        child_entry = {
                            "child_module_name": item["module_name"],
                            "queue_order": len(parent_entry["children"])
                            + 1,  # Position-based queue_order for children
                            "sub_children": [],  # Always include sub_children key
                        }
                        parent_entry["children"].append(child_entry)

                    # If there is a submodule, add it to sub_children
                    if item["submodule_name"]:
                        sub_child_entry = {
                            "sub_child_module_name": item["submodule_name"],
                            "queue_order": len(child_entry["sub_children"])
                            + 1,  # Position-based queue_order for sub-children
                            "sub_children": [],  # Always include sub_children key for sub-modules
                        }
                        child_entry["sub_children"].append(sub_child_entry)
            try:
                output_structure = filter_modules_by_flag(output_structure, billing_platform_flag)
            except Exception as e:
                logging.info(f'### Exception while removing billing platform modules :{e}')
            logging.info(f'### output_structure---------{output_structure}')
            formatted_data = output_structure
        

        # ordring modules
        parent_module_order_query = (
            "select parent_module_name,parent_module_order from module"
        )
        parent_module_order = db.execute_query(parent_module_order_query, True).to_dict(
            orient="records"
        )

        module_order = {}
        for mod in parent_module_order:
            module_order[mod["parent_module_name"]] = mod["parent_module_order"]

        new_formated_data = []
        logging.info(f"### formatted_data is : {formatted_data}")
        for modules in formatted_data:
            temp = modules
            if modules["parent_module_name"] in module_order:
                temp["queue_order"] = int(module_order[modules["parent_module_name"]])
            new_formated_data.append(temp)

        logging.info(f"### new_formated_data is : {new_formated_data}")
        new_formated_data = sorted(new_formated_data, key=lambda x: x["queue_order"])

        # Extract 'logo' and 'id' separately
        logo = result["logo"].to_list()[0]  # Assuming the result contains a column 'logo'
        collapsed_logo = result["collapsed_logo"].to_list()[0]
        dark_mode_logo = result["dark_mode_logo"].to_list()[0]
        dark_mode_collapsed_logo= result["dark_mode_collapsed_logo"].to_list()[0]
        tenant_id = result["id"].to_list()[0]  # Assuming the result contains a column 'id'
        db_name = result["db_name"].to_list()[
            0
        ]  # Assuming the result contains a column 'id'
        # Retrieve user-specific timeout
        user_timeout = db.get_data('users', {
            "username": username,
            "is_active": True
        }, ['ui_timeout'])

        if not user_timeout.empty:
            # User found — use their UI timeout
            ui_timeout = user_timeout['ui_timeout'].iloc[0]
        else:
            # No user setting found — check role defaults
            role_timeout = db.get_data('role', {
                "role_name": role_name,
                "tenant_id": tenant_id,
                "is_active": True
            }, ['ui_timeout'])

            if not role_timeout.empty:
                ui_timeout = role_timeout['ui_timeout'].iloc[0]
            else:
                # Neither user nor role has a setting — fallback to default
                ui_timeout = 15
        
        message = "Module data sent sucessfully"
        response = {
            "flag": True,
            "message": message,
            "Modules": new_formated_data,
            "logo": logo,
            "dark_mode_logo": dark_mode_logo,
            "collapsed_logo":collapsed_logo,
            "dark_mode_collapsed_logo":dark_mode_collapsed_logo,
            "billing_platform_flag":billing_platform_flag,
            "collapsed_logo":collapsed_logo,
            "tenant_id": tenant_id,
            "db_name": db_name,
            "ui_timeout":int(ui_timeout)
        }
        logging.info("### get_modules function executed successfully")
        try:
            audit_data_user_actions = {
                "service_name":"get_modules",
                "created_by": username,
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "module_name": "Module management",
                "comments": "fetched modules data",
                "request_received_at": data.get("request_received_at", ""),
            }

            db.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
        return response

    except Exception as e:
        logging.warning(f"### Something went wrong while fetching modules data and error is : {e}")
        message = "Something went wrong while fetching modules data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_modules",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "comments": message ,
                "module_name": "Module Managament",
                "request_received_at": data.get("request_received_at", ""),
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.warning(f"### Audit logging exception in error case : {e}")
        response = {
                "flag": False,
                "message": "Something went wrong while fetching modules data",
                "Modules": [],
                "logo": "",
                "dark_mode_logo": "",
                "dark_mode_collapsed_logo": "",
                "collapsed_logo": "",
                "billing_platform_flag": False,
                "collapsed_logo": "",
                "tenant_id": "",
                "db_name": data.get("db_name", "") ,
            }


        return response 

def filter_modules_by_flag(modules, billing_platform_flag):
    """
    Filters out modules related to the 'Billing Platform' based on a boolean flag.

    This function:
    - Removes modules whose 'parent_module_name' is "Billing Platform" if the flag is False.
    - Returns the original module list if the flag is True.

    Args:
        modules (list): A list of dictionaries representing module metadata.
        billing_platform_flag (bool): Flag to include or exclude Billing Platform modules.

    Returns:
        list: A filtered list of modules based on the billing_platform_flag.
    """
    if not billing_platform_flag:
        modules = [m for m in modules if m.get("parent_module_name") != "Billing Platform"]
    return modules


def format_module_data(transformed_data, tenant_modules, module_table_df, role_name):
    """
    Formats module data into a structured hierarchy of parent, child, and sub-child modules.

    This function:
    - Builds a hierarchy of modules starting from parent modules.
    - Adds child modules and sub-children based on provided definitions.
    - Sets queue order for parent, child, and sub-child levels.
    - Filters modules based on user access and role (e.g., hides inaccessible modules for non-super admins).

    Args:
        transformed_data (list): List of dictionaries with initial module access info (parent and module names).
        tenant_modules (list): List of module names accessible by the tenant.
        module_table_df (list): Full module configuration, including parent, child, and submodule names.
        role_name (str): Role of the user (e.g., "Super Admin", "Partner Admin") to apply access logic.

    Returns:
        list: A structured list of parent modules, each with child modules and nested sub-children,
              including queue order at each level for display or sorting.
    """
    logging.info("### Starting format_module_data function")
    # Step 1: Create a mapping for transformed_data to find parent modules easily
    parent_module_map = {
        item["parent_module_name"]: {
            "parent_module_name": item["parent_module_name"],
            "queue_order": 0,  # Placeholder for queue order
            "children": [],
        }
        for item in transformed_data
    }
    logging.info(
        f"### Parent module map initialized with  {len(parent_module_map)} entries"
    )

    # Step 2: Populate the parent_module_map with child and sub-child modules
    for module in module_table_df:
        parent_name = module["parent_module_name"]
        module_name = module["module_name"]
        submodule_name = module.get("submodule_name")
        module_access = True
        logging.info(f"### Processing module: {module_name} under parent: {parent_name}")
        if not module_name:
            continue
        # Check if the parent module name exists in the transformed_data
        if (
            parent_name in parent_module_map and parent_name in tenant_modules
        ):  # Ensure module_name is not None or empty
            # Check if the child already exists in the parent's children list
            for item in transformed_data:
                if item["parent_module_name"] == parent_name:
                    if submodule_name:
                        if submodule_name not in item["module_name"]:
                            module_access = False
                            break
                    else:
                        if module_name not in item["module_name"]:
                            module_access = False
                            break

            if not module_access and (role_name.lower() != "super admin"):
                continue

            child_module = next(
                (
                    child
                    for child in parent_module_map[parent_name]["children"]
                    if child["child_module_name"] == module_name
                ),
                None,
            )

            if not child_module:
                # If the child module doesn't exist, create a new one
                child_module = {
                    "child_module_name": module_name,
                    "queue_order": len(parent_module_map[parent_name]["children"]) + 1,
                    "sub_children": [],
                }
                # Append the child module to the parent's children
                parent_module_map[parent_name]["children"].append(child_module)
                logging.info(
                    f"""### Added child module: {module_name} with
                    queue order {child_module['queue_order']}
                    """
                )

            # If submodule_name exists, add it to sub_children
            if submodule_name:
                sub_child_module = {
                    "sub_child_module_name": submodule_name,
                    "queue_order": len(child_module["sub_children"]) + 1,
                    "sub_children": [],
                }
                child_module["sub_children"].append(sub_child_module)
                logging.info(
                    f"""### Added sub-child module: {submodule_name} with
                      queue order {sub_child_module['queue_order']}
                      """
                )
        else:
            if parent_name in parent_module_map:
                parent_module_map.pop(parent_name)
    # Step 3: Convert parent_module_map to a list
    structured_data = []

    for index, (parent_name, parent_data) in enumerate(parent_module_map.items()):
        parent_data["queue_order"] = index + 1  # Set queue_order based on the index
        structured_data.append(parent_data)  # Include even if no children
        logging.info(
            f"### Set queue order {parent_data['queue_order']} for parent module: {parent_name}"
        )

    logging.info("### Successfully formatted module data")
    return structured_data


def form_modules_dictionary(data, sub_modules, tenant_modules):
    """
    Constructs a nested dictionary mapping parent modules to their respective submodules and child modules.

    Args:
        data (list): List of dictionaries containing module details such as:
                     - parent_module_name (str)
                     - module_name (str)
                     - submodule_name (str)
        sub_modules (list): List of allowed submodules (used for filtering).
        tenant_modules (list): List of parent modules assigned to the current tenant.

    Returns:
        dict: A nested dictionary in the format:
              {
                  "ParentModule1": {
                      "SubModule1": ["ChildModule1", "ChildModule2"],
                      "SubModule2": ["ChildModule3"]
                  },
                  "TopLevelModule": {}
              }
    """
    logging.info("### Starting form_modules_dictionary function")
    # Initialize an empty dictionary to store the output
    out = {}

    # Iterate through the list of modules in the data
    for item in data:
        parent_module = item["parent_module_name"]
        logging.info(f"### Processing parent module: {parent_module}")

        # Skip modules not assigned to the tenant
        if parent_module not in tenant_modules and parent_module:
            logging.info(
                f"### Skipping parent module {parent_module} - not in tenant_modules"
            )
            continue

        # If there's no parent module, initialize an empty dictionary for the module
        if not parent_module:
            logging.info(f"### Adding top-level module: {item['module_name']}")
            out[item["module_name"]] = {}
            continue
        else:
            logging.info(
                f"### Initializing empty dictionary for parent module {parent_module}"
            )
            out[item["parent_module_name"]] = {}

        # Iterate through the data again to find related modules and submodules
        for module in data:
            temp = {}

            # Skip modules not in the specified submodules
            if (
                module["module_name"] not in sub_modules
                and module["submodule_name"] not in sub_modules
            ):
                logging.info(
                    f"""### Skipping module {module['module_name']} or
                    submodule {module['submodule_name']} - not in sub_modules
                    """
                )
                continue

            # Handle modules without submodules and create a list for them
            if (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and not module["submodule_name"]
            ):
                logging.info(
                    f"### Adding module without submodule: {module['module_name']} under {parent_module}"
                )
                temp = {module["module_name"]: []}
            # Handle modules with submodules and map them accordingly
            elif (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and module["submodule_name"]
            ):
                logging.info(
                    f"""### Mapping submodule {module['submodule_name']} to
                      module {module['module_name']} under {parent_module}
                      """
                )
                temp = {module["submodule_name"]: [module["module_name"]]}

            # Update the output dictionary with the constructed module mapping
            if temp:
                for key, value in temp.items():
                    if key in out[item["parent_module_name"]]:
                        out[item["parent_module_name"]][key].append(value[0])
                        logging.info(
                            f"### Appending {value[0]} to existing submodule {key} in {parent_module}"
                        )
                    else:
                        out[item["parent_module_name"]].update(temp)
                        logging.info(f"### dding new submodule {key} to {parent_module}")

    logging.info("### Module dictionary formed successfully")
    # Return the final dictionary containing the module mappings
    return out


def transform_structure_data_values(input_data):
    """
    Transforms a nested dictionary of module hierarchy into a list of structured dictionaries with queue orders.

    Args:
        input_data (dict): Nested dictionary in the format:
            {
                "ParentModule1": {
                    "ChildModule1": ["SubChild1", "SubChild2"],
                    "ChildModule2": []
                },
                "ParentModule2": {}
            }

    Returns:
        list: A list of dictionaries with structured module hierarchy and queue orders, in the format:
            [
                {
                    "parent_module_name": str,
                    "queue_order": int,
                    "children": [
                        {
                            "child_module_name": str,
                            "queue_order": int,
                            "sub_children": [
                                {
                                    "sub_child_module_name": str,
                                    "queue_order": int,
                                    "sub_children": []
                                }
                            ]
                        }
                    ]
                }
            ]
    """
    logging.info("### Starting transform_structure_data_values function")
    # Initialize an empty list to store the transformed data
    transformed_data = []
    # Initialize the queue order for parent modules
    queue_order = 1

    # Iterate over each parent module and its children in the input data
    for parent_module, children in input_data.items():
        logging.info(
            f"### Processing parent module: {parent_module} with queue_order {queue_order}"
        )
        transformed_children = []
        child_queue_order = 1
        # Iterate over each child module and its sub-children
        for child_module, sub_children in children.items():
            logging.info(
                f"### Processing child module: {child_module} with queue_order {child_queue_order}"
            )
            transformed_sub_children = []
            sub_child_queue_order = 1

            # Iterate over each sub-child module
            for sub_child in sub_children:
                logging.info(
                    f"### Adding sub-child module: {sub_child} with queue_order {sub_child_queue_order}"
                )
                transformed_sub_children.append(
                    {
                        "sub_child_module_name": sub_child,
                        "queue_order": sub_child_queue_order,
                        "sub_children": [],
                    }
                )
                sub_child_queue_order += 1
            # Append the transformed child module with its sub-children
            transformed_children.append(
                {
                    "child_module_name": child_module,
                    "queue_order": child_queue_order,
                    "sub_children": transformed_sub_children,
                }
            )
            child_queue_order += 1

        # Append the transformed parent module with its children
        transformed_data.append(
            {
                "parent_module_name": parent_module,
                "queue_order": queue_order,
                "children": transformed_children,
            }
        )
        queue_order += 1
    logging.info("### Transformation completed successfully")

    # Return the list of transformed data
    return transformed_data


def convert_timestamp(data):
    """
    Recursively converts all pandas Timestamp objects in a dictionary or list to formatted strings.

    This function:
    - Formats `pd.Timestamp` objects into a readable string format: "MM-DD-YYYY HH:MM:SS".
    - Recursively processes nested dictionaries and lists to ensure all timestamps are converted.
    - Returns the data structure with timestamps as formatted strings.

    Args:
        data (any): Input data which may be a pandas Timestamp, dictionary, list, or any nested structure.

    Returns:
        any: Data with all `pd.Timestamp` instances converted to string format.
    """
    logging.info(f"### Converting data: {data}")
    if isinstance(data, pd.Timestamp):
        logging.info(f"### Converting pd.Timestamp: {data}")
        return data.strftime("%m-%d-%Y %H:%M:%S")
    elif isinstance(data, dict):
        logging.info("### Processing dictionary in convert_timestamp")
        return {k: convert_timestamp(v) for k, v in data.items()}
    elif isinstance(data, list):
        logging.info("### Processing list in convert_timestamp")
        return [convert_timestamp(v) for v in data]
    else:
        logging.info(f"### No conversion needed for type: {type(data)}")
        return data


def convert_timestamp_data(df_dict, tenant_time_zone):
    """
    Converts specific timestamp fields in a list of dictionaries to a given tenant's timezone.

    This function:
    - Identifies and converts columns like `created_date`, `modified_date`, and `deleted_date`.
    - Handles both timezone-aware and naive datetime values.
    - Localizes naive timestamps to UTC and then converts them to the specified tenant timezone.
    - Formats all converted timestamps to the string format: "MM-DD-YYYY HH:MM:SS".

    Args:
        df_dict (list): A list of dictionaries representing rows of data, each potentially containing timestamps.
        tenant_time_zone (str): Timezone name (e.g., "America/Chicago") to which timestamps should be converted.

    Returns:
        list: A list of dictionaries with specified timestamp fields converted to strings in the target timezone.
    """
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = [
        "created_date",
        "modified_date",
        "deleted_date",
    ]  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors="coerce")
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize("UTC")
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime(
                    "%m-%d-%Y %H:%M:%S"
                )  # Ensure it's a string
    return df_dict


# import numpy as np

# def serialize_data(data):
#     """Recursively convert pandas objects in the data structure to serializable types."""
#     if isinstance(data, list):
#         return [serialize_data(item) for item in data]
#     elif isinstance(data, dict):
#         return {key: serialize_data(value) for key, value in data.items()}
#     elif isinstance(data, pd.Timestamp):
#         # Handle pd.Timestamp and NaT
#         return data.strftime("%m-%d-%Y %H:%M:%S") if pd.notna(data) else None
#     elif data is pd.NaT:  # Directly check for pd.NaT
#         return None
#     elif isinstance(data, np.datetime64):  # Handle numpy datetime64
#         return str(data) if pd.notna(data) else None
#     elif pd.api.types.is_integer(data):  # Check explicitly for integers
#         return int(data)
#     elif pd.api.types.is_float(data):  # Check explicitly for floats
#         return float(data)
#     elif pd.isna(data):  # Handle NaN or missing values
#         return None
#     else:
#         return data  # Return as is for other types


def service_provider_list_view(data):
    """
    Description:
        Retrieves service provider data in list view format from the database.
        The function validates the access token and logs the request. It fetches the
        service provider data along with related information such as integrations,
        service provider settings, and pagination details. The response is formatted
        with the retrieved data, which includes service provider details, integration
        lists, settings, and headers mapping.

    Args:
        data (dict): A dictionary containing the request data. Expected keys include:
            - 'db_name' (str, optional): The database name to query (default: 'altaworx_central').
            - 'role_name' (str, optional): The role name for data access (default: '').
            - 'tenant_name' (str, optional): The tenant name to fetch the timezone (default: '').
            - 'pages' (dict, optional): Pagination information including 'start' and '
               end' (default: {'start': 0, 'end': 100}).

    Returns:
        dict: A dictionary containing the formatted response data, which includes:
            - 'flag' (bool): Indicates whether the data was fetched successfully.
            - 'message' (str): A message describing the result of the operation.
            - 'data' (list): The list of service provider data.
            - 'integration_list' (list): The list of integration details.
            - 'service_provider_setting_list' (list): The list of service provider settings.
            - 'headers_map' (dict): The mapping of headers for the service provider data.
            - 'pages' (dict): Pagination information with 'start', 'end', and 'total' values.
    """
    logging.info(f"### service_provider_list_view Request Data Received : {data}")

    # database Connection
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_db_name = data.get("db_name", "")
    dbs = DB(tenant_db_name, **db_config)

    role_name = data.get("role_name", "")
    tenant_database = data.get("db_name", "")

    try:
        return_json_data = {}
        start_page = data.get("pages", {}).get("start", 0)
        end_page = data.get("pages", {}).get("end", 100)

        # Query to get total number of rows for pagination
        total_count_query = """SELECT COUNT(*) AS total FROM serviceprovider"""
        total_count_result = dbs.execute_query(total_count_query, flag=True)
        total_count = int(total_count_result.iloc[0]["total"])

        # Pagination pages info
        pages = {"start": start_page, "end": end_page, "total": total_count}

        # SQL query to get all columns from the templates table with pagination
        # query = """SELECT SP.*, I.name FROM serviceprovider SP
        #     left join integration I on I.id = SP.integration_id
        #     WHERE SP.is_active = 'true' OR
        #             SP.is_deleted = 'false' ORDER BY SP.modified_date DESC, SP.created_date LIMIT 100 OFFSET %s"""

        # Fetch integrations
        integration_query = """
        SELECT id, name FROM integration
        WHERE is_active='true'
        """
        integrations = database.execute_query(integration_query, True)
        integration_map = dict(zip(integrations["id"], integrations["name"]))

        # Fetch service providers
        sp_query = """
        SELECT * FROM serviceprovider SP
        WHERE SP.is_active = 'true' OR SP.is_deleted = 'false'
        ORDER BY SP.modified_date DESC, SP.created_date
        LIMIT 100 OFFSET %s
        """

        # params = [start_page]
        result = dbs.execute_query(sp_query, params=[start_page])

        result["integration_name"] = result["integration_id"].map(integration_map)

        integration_query = "SELECT id, name FROM integration WHERE is_active='true'"
        df = dbs.execute_query(integration_query, True)
        df = df.sort_values(by="name", ascending=True)

        # Convert the 'role_name' column to a list
        integration_list = [{row["name"]: row["id"]} for _, row in df.iterrows()]

        service_provider_setting = """SELECT service_provider_id, setting_key, setting_value
                FROM service_provider_setting WHERE is_active='true'
          """
        service_provider_setting = dbs.execute_query(service_provider_setting, True)
        service_provider_setting_list = service_provider_setting.to_dict(
            orient="records"
        )

        # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(database, data)

        # Execute the query using the existing execute_query function
        # result = dbs.execute_query(query, params=params)
        headers_map = get_headers_mapping(
            tenant_database,
            ["Service Provider"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            database,
        )

        if not result.empty:
            df_dict = result.to_dict(orient="records")
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            return_json_data["flag"] = True
            return_json_data["message"] = "Data fetched successfully"
            return_json_data["data"] = serialize_data(df_dict)
            return_json_data["integration_list"] = integration_list
            return_json_data["service_provider_setting_list"] = (
                service_provider_setting_list
            )
            return_json_data["headers_map"] = headers_map
            return_json_data["pages"] = pages
            return return_json_data
        else:
            logging.info("### service_provider_list_view No data found.")
            return_json_data["flag"] = True
            return_json_data["data"] = []
            return_json_data["integration_list"] = integration_list
            return_json_data["message"] = "No data found!"
        try:
            audit_data_user_actions = {
                "service_name": "service_provider_list_view",
                "created_by": data.get("username", ""),
                "status": "True",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module management",
                "comments": "fetches service providers list",
                "request_received_at": data.get("request_received_at", ""),
            }

            database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### service_provider_list_view Exception is : {e}")
        return return_json_data
    
    except Exception as e:
        logging.exception(f"### service_provider_list_view Error occurred: {str(e)}")
        return_json_data["flag"] = True
        headers_map = get_headers_mapping(
            tenant_database,
            ["Service Provider"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            database,
        )
        return_json_data["message"] = "Failed to Fetch data! or No data found!"
        return_json_data["integration_list"] = []
        return_json_data["data"] = []
        return_json_data["headers_map"] = headers_map
        message = "Something went wrong while fetching service provider list view data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "service_provider_list_view",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### service_provider_list_view Exception is : {e}")
        return return_json_data


def update_tenant_service_provider_data():
    """
    Fetches active tenant and service provider data from the database and updates a shared JSON file.

    This function performs the following operations:
    - Connects to the common utilities database to retrieve all active tenants.
    - For each active tenant:
        - Connects to the tenant's respective database.
        - Retrieves all active service providers linked to the tenant.
        - Updates a shared JSON file with service provider names mapped to their IDs,
          grouped under their respective tenant names.

    File:
        - Path: /opt/python/lib/python3.9/site-packages/common_utils/tenant_service_providers.json
        - If the file exists, it loads and updates the existing data.
        - If not, it creates a new file with the fetched data.

    Returns:
        None
    """

    FILE_PATH = "/opt/python/lib/python3.9/site-packages/common_utils/tenant_service_providers.json"

    """Fetch data from the database and update the JSON file."""
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        # Fetch all active tenants
        tenants = common_utils_database.execute_query(
            "SELECT id, tenant_name, db_name FROM tenant WHERE is_active = true", True
        ).to_dict(orient="records")
        logging.info(f"### update_tenant_service_provider_data tenants : {tenants}")

        # Load existing data if file exists
        existing_data = {}
        if os.path.exists(FILE_PATH):
            with open(FILE_PATH, "r") as file:
                existing_data = json.load(file)

        # Process each tenant
        for tenant in tenants:
            tenant_id, tenant_name, db_name = (
                int(tenant["id"]),
                tenant["tenant_name"],
                tenant["db_name"],
            )
            logging.info(f"### update_tenant_service_provider_data Processing Tenant : {tenant}")

            # Ensure tenant exists in the JSON file
            if tenant_name not in existing_data:
                existing_data[tenant_name] = {}

            # Skip tenants with missing `db_name`
            if not db_name:
                logging.info(
                    f"### update_tenant_service_provider_data Skipping tenant '{tenant_name}' due to missing database name."
                )
                continue

            try:
                # Attempt to connect to the tenant's database
                database = DB(db_name, **db_config)

                # Fetch active service providers for the tenant
                service_providers = database.execute_query(
                    f"SELECT id, service_provider_name FROM serviceprovider WHERE is_active = true AND tenant_id = {tenant_id}",
                    True,
                ).to_dict(orient="records")

                # Update JSON structure
                for sp in service_providers:
                    existing_data[tenant_name][sp["service_provider_name"]] = sp["id"]

            except Exception as db_error:
                logging.exception(f"### update_tenant_service_provider_data Skipping '{tenant_name}' due to database error: {db_error}")
                continue  # Move to the next tenant

        # Save updated data back to file
        os.makedirs(os.path.dirname(FILE_PATH), exist_ok=True)
        with open(FILE_PATH, "w") as file:
            json.dump(existing_data, file, indent=4)

        logging.info(f"### update_tenant_service_provider_data Data successfully updated in : {FILE_PATH}")

    except Exception as e:
        logging.addFilter(f"### update_tenant_service_provider_data Error updating tenant-service provider data: {e}")


def submit_update_service_provider(data):
    """
    Updates or creates service provider data, manages custom fields, and handles deletion
    operations.
    This function allows for the creation, updating, and deletion of service provider
    records in the database.It processes the incoming data, performs the necessary database
    operations, and logs the user actions for auditing.
    The function also ensures that any changes to custom fields are handled properly,
    preventing duplicates and ensuring data integrity.

    Parameters:
        data (dict): A dictionary containing the following keys:
            - 'changed_data': The data to be updated.
            - 'custom_fields': Custom fields to be added or updated.
            - 'new_data': New data to be inserted.
            - 'delete_data': Data indicating what records need to be deleted.
            - 'action': The action to perform ('create', 'update', or 'delete').
            - 'username': The username of the person performing the action.
            - 'tenant_name': The tenant associated with the service provider.
            - 'request_received_at': Timestamp of when the request was received.
            - 'db_name': The tenant database name.
            - 'table_name': The table name where the data should be updated.

    Returns:
        dict: A dictionary containing the result of the operation:
            - 'flag': A boolean indicating whether the operation was successful.
            - 'message': A message indicating success or failure.
    """

    # Convert boolean values in the input data to their respective types
    data = convert_booleans(data)
    start_time = time.time()  # Start the timer for performance measurement
    changed_data = data.get("changed_data", {})
    custom_fields = data.get("custom_fields", {})
    new_data = {k: v for k, v in data.get("new_data", {}).items() if v}
    delete_data = data.get("delete_data", {})
    unique_id = changed_data.get("id")
    table_name = data.get("table_name", "")
    action = data.get("action", "")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    session_id = data.get("sessionID")

    # Database connection setup
    tenant_database = data.get("db_name", "altaworx_central")
    dbs = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    audit_comment_data = (
            json.dumps(delete_data) if action == "delete" 
            else json.dumps(new_data) if action == "create" 
            else json.dumps(changed_data)
        )

    try:
        if action == "create":
            # Prepare new data for insertion by ensuring no empty values are included
            new_data = {k: v for k, v in new_data.items() if v not in [None, "None"]}
            for k, v in new_data.items():
                if isinstance(v, list):
                    if all(isinstance(item, dict) for item in v):
                        new_data[k] = json.dumps(
                            v
                        )  # Convert list of dicts to JSON string
                    else:
                        new_data[k] = ", ".join(
                            str(item) for item in v if item is not None
                        )  # Convert other types to strings
            if new_data:
                # dbs.insert_data(new_data, table_name)
                tenant_id = common_utils_database.get_data(
                    "tenant", {"tenant_name": tenant_name}, ["id"]
                ).to_dict(orient="records")[0]["id"]
                new_data["tenant_id"] = tenant_id
                new_data["is_deleted"] = False
                service_provider_id = dbs.insert_data(new_data, table_name)
                # integration_dataframe = common_utils_database.get_data(
                #     "integration",
                #     {"id": new_data["integration_id"]},
                #     ["id", "authentication_type"],
                # )
                # integration_id = integration_dataframe["id"].to_list()[0]
                # authentication_type = integration_dataframe[
                #     "authentication_type"
                # ].to_list()[0]
                # service_provider_setting_data = {
                #     "integration_id": integration_id,
                #     "service_provider_id": service_provider_id,
                #     "tenant_id": tenant_id,
                #     "authentication_type": authentication_type,
                #     "is_active": True,
                #     "created_by": username,
                #     "is_deleted": False,
                # }
                # integration_authentication_id = common_utils_database.insert_data(
                #     service_provider_setting_data, "integration_authentication"
                # )
                # Call function to update JSON file
                logging.info("### Data insertion was successful.")
                threading.Thread(target=update_tenant_service_provider_data, daemon=True).start()
                logging.info("### Data insertion was successful.")
        elif action == "update":
            if unique_id is not None:
                # Prepare the data for update by filtering out None values
                changed_data = {
                    k: v for k, v in changed_data.items() if v not in [None, "None"]
                }
                update_data = {
                    key: value for key, value in changed_data.items() if key != "id"
                }
                # Handle custom fields
                custom_fields = [
                    {k: v for k, v in custom_field.items() if v not in [None, "None"]}
                    for custom_field in custom_fields
                ]
                for k, v in new_data.items():
                    if isinstance(v, list):
                        if all(isinstance(item, dict) for item in v):
                            new_data[k] = json.dumps(
                                v
                            )  # Convert list of dicts to JSON string
                        else:
                            new_data[k] = ", ".join(
                                str(item) for item in v if item is not None
                            )  # Convert other types to strings

                if update_data:
                    dbs.update_dict(table_name, update_data, {"id": unique_id})
                if custom_fields:
                    for custom_field in custom_fields:
                        # Check if the record already exists in the database
                        setting_value = custom_field.get("setting_value")
                        service_provider_id = custom_field.get("service_provider_id")
                        setting_key = custom_field.get("setting_key")

                        # Fetch all active records for the service provider
                        dbs.get_data(
                            "service_provider_setting",
                            {
                                "service_provider_id": service_provider_id,
                                "is_active": True,
                            },
                            ["setting_key", "setting_value"],
                        ).to_dict(orient="records")

                        # Check if the setting_key and setting_value already exist
                        # record_exists = any(
                        #     record["setting_key"] == setting_key
                        #     and record["setting_value"] == setting_value
                        #     for record in active_records
                        # )

                        dbs.update_dict("service_provider_setting",
                                                            {"setting_value": setting_value},
                                                {"setting_key": setting_key, "service_provider_id": service_provider_id})

                            # Call function to update JSON file
                        update_tenant_service_provider_data()
        elif action == "delete":
            # Clean up delete data by removing None values
            delete_data = {
                k: v for k, v in delete_data.items() if v not in [None, "None"]
            }
            if delete_data:
                dbs.update_dict(table_name, delete_data, {"id": unique_id})
                logging.info("### Data deletion was successful.")
            # Call function to update JSON file
            logging.info("### Data deletion was successful.")
            threading.Thread(target=update_tenant_service_provider_data, daemon=True).start()

        # Prepare the response data
        response_data = {"flag": True, "message": f"{action} successfully"}

        logging.info(f"### json.dumps(new_data) -- {json.dumps(new_data)}")
        

        try:
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            # Log the user action in the audit table
            audit_data_user_actions = {
                "service_name": "submit_update_service_provider",
                "created_by": username,
                "status": "True",
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": audit_comment_data,
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
            logging.info("### Audit log recorded successfully")
        except Exception as e:
            logging.exception(f"### Exception during audit log: {e}")

        return response_data
    except Exception as e:
        logging.exception(f"### An error occurred while updating the service provider data : {e}")
        message = "Failed to update the service provider data"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)

        try:
            # Log error to database
            error_data = {
                "service_name": "submit_update_service_provider",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
            logging.info("### Error details logged successfully")
        except Exception as e:
            logging.exception(f"### Exception during error auditing: {e}")

        return response


# AWS S3 client
s3_client = boto3.client("s3")
S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME", " ")


def format_header(header):
    """
    Formats a header string by capitalizing words and preserving acronyms.

    This function is typically used to convert snake_case headers (e.g., 'imei_number', 'sms_status')
    into more readable labels (e.g., 'IMEI Number', 'SMS Status') for display purposes such as UI tables or logs.

    Args:
        header (str): A string representing a header in snake_case format.

    Returns:
        str: A formatted string where:
             - Acronyms like 'IMEI', 'SMS', etc., remain uppercase.
             - Other words are capitalized and separated by spaces.
    """
    # Define acronyms to preserve uppercase
    acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN"}

    # Split by underscores and format each part
    parts = header.split("_")
    formatted_parts = [
        part if part.upper() in acronyms else part.capitalize()  # Preserve acronym case
        for part in parts
    ]

    # Join the parts back together
    return " ".join(formatted_parts)

def convert_timestamp_dataframe(df, tenant_time_zone):
    """
    Converts specific timestamp columns in a DataFrame to a given tenant's timezone.

    This function processes columns such as 'created_date', 'modified_date',
    'deleted_date', and 'processed_date' (if present in the DataFrame) and:
    - Converts them to datetime format.
    - Localizes them to UTC if they are naive timestamps.
    - Converts them to the tenant's timezone.
    - Formats the timestamps as strings in "MM-DD-YYYY HH:MM:SS AM/PM" format.

    Args:
        df (pd.DataFrame): The input DataFrame that may contain timestamp columns.
        tenant_time_zone (str): A string representing the target timezone (e.g., 'Asia/Kolkata').

    Returns:
        pd.DataFrame: The updated DataFrame with formatted date-time strings
                      in the specified tenant timezone.
    """
    # Define the columns to process
    timestamp_columns = ["created_date", "modified_date", "deleted_date","processed_date","date_added"]

    # Create a timezone object
    target_timezone = pytz.timezone(tenant_time_zone)

    # Convert only the specified timestamp columns
    for col in timestamp_columns:
        if col in df.columns:  # Ensure column exists
            try:
                # Convert to datetime, handling invalid values as NaT
                df[col] = pd.to_datetime(df[col], errors="coerce")

                # Localize naive timestamps to UTC
                df[col] = df[col].apply(lambda x: x.tz_localize("UTC") if pd.notna(x) and x.tz is None else x)

                # Convert to tenant's timezone
                df[col] = df[col].apply(lambda x: x.tz_convert(target_timezone) if pd.notna(x) else x)

                # Format as string with AM/PM
                df[col] = df[col].dt.strftime("%m-%d-%Y %I:%M:%S %p")

            except Exception as e:
                logging.info(f"### Error processing column {col}: {e}")

    return df




def modify_query(query,tenant_id):
    """
    Modifies a SQL SELECT query by adding a tenant filter condition.

    This function ensures the query includes `tenant_id = <tenant_id>` in the WHERE clause.
    - If the query already has a WHERE clause, it appends the tenant condition using AND.
    - If no WHERE clause exists, it creates one with the tenant condition.
    - ORDER BY clause (if present) is preserved and appended to the modified query.

    Args:
        query (str): Original SQL SELECT query as a string.
        tenant_id (int): The tenant ID to be included as a filter.

    Returns:
        str: Modified SQL query string with the tenant filter added appropriately.
    """
    # Split the query into the main part and the ORDER BY part
    order_by_parts = re.split(r'\s+ORDER\s+BY\s+', query, flags=re.IGNORECASE)
    main_part = order_by_parts[0]
    order_by_part = order_by_parts[1] if len(order_by_parts) > 1 else None

    # Process the main part to handle the WHERE clause
    where_parts = re.split(r'\s+WHERE\s+', main_part, flags=re.IGNORECASE)
    if len(where_parts) > 1:
        #new_main_part = where_parts[0] + f''' WHERE tenant_id = {tenant_id}'''
        new_main_part = main_part + ' AND ' + f'''tenant_id = {tenant_id}'''
    else:
        new_main_part = main_part + f''' WHERE tenant_id = {tenant_id}'''

    # Reconstruct the full query with ORDER BY if it existed
    modified_query = new_main_part
    if order_by_part is not None:
        modified_query += ' ORDER BY ' + order_by_part

    return modified_query

def to_sql_in_clause(values):
    """
    Converts a list of values into a valid SQL IN clause tuple format.

    This function helps generate a string that can be directly used in SQL queries
    for filtering using the `IN` clause.

    Args:
        values (list or tuple): A list or tuple of values to include in the IN clause.

    Returns:
        str or None: A string representing the values in SQL tuple format:
            - Returns "('value')" if only one item is provided (note: no trailing comma).
            - Returns "('val1', 'val2', ...)" for multiple items.
            - Returns None if the input is None or empty.
    """
    if values is None or len(values) == 0:
        return None
    if len(values) == 1:
        return f"('{values[0]}')"  # single element tuple without comma
    return str(tuple(values))  # normal tuple

def fetch_and_pivot_daily_device_usage(df, device_table, device_id_field, billing_cycle_start, cycle_end_date, billing_cycle_dates, database):
    """
    Fetches and pivots daily device usage data for the given billing cycle, using ICCID or MSISDN as identifiers.

    Args:
        df (pd.DataFrame): Input DataFrame containing at least 'ICCID' and/or 'MSISDN' columns.
        device_table (str): Name of the table storing device information.
        device_id_field (str): Column name in the usage table referencing device ID.
        billing_cycle_start (str): Start date of the billing cycle (YYYY-MM-DD format).
        cycle_end_date (str): End date of the billing cycle (YYYY-MM-DD format).
        billing_cycle_dates (list): List of dates (strings) for the billing cycle used as columns in the pivoted result.
        database (object): Database connection object with an `execute_query(query: str, return_df: bool)` method.

    Returns:
        pd.DataFrame: Original DataFrame joined with daily usage values for each device, one column per billing date.

    """
    if df.empty:
        return pd.DataFrame()
    try:
        # Split into ICCID-valid and fallback-to-MSISDN
        iccid_valid_df = df[df["ICCID"].notna() & (df["ICCID"].astype(str).str.strip() != "")]
        msisdn_fallback_df = df[df["ICCID"].isna() | (df["ICCID"].astype(str).str.strip() == "")]

        unique_iccids = iccid_valid_df["ICCID"].dropna().unique()
        unique_msisdns = msisdn_fallback_df["MSISDN"].dropna().unique()

        iccid_in_clause = to_sql_in_clause(unique_iccids)
        msisdn_in_clause = to_sql_in_clause(unique_msisdns)

        iccid_df = pd.DataFrame()
        msisdn_df = pd.DataFrame()
        iccid_list = []
        msisdn_list = []

        if iccid_in_clause:
            iccid_query = f"""
                SELECT id, iccid FROM {device_table}
                WHERE iccid IN {iccid_in_clause} AND is_active = 'true'
            """
            iccid_df = database.execute_query(iccid_query, True).drop_duplicates()
            iccid_list = iccid_df["id"].drop_duplicates().tolist()

        if msisdn_in_clause:
            msisdn_query = f"""
                SELECT id, msisdn FROM {device_table}
                WHERE msisdn IN {msisdn_in_clause} AND is_active = 'true'
            """
            msisdn_df = database.execute_query(msisdn_query, True).drop_duplicates()
            msisdn_list = msisdn_df["id"].drop_duplicates().tolist()

        combined_id_list = list(set(iccid_list + msisdn_list))

        usage_query = f"""
            SELECT {device_id_field} AS mobility_device_id, usage_date, data_usage
            FROM device_usage
            WHERE {device_id_field} IN {tuple(combined_id_list)} 
            AND usage_date BETWEEN '{billing_cycle_start}' AND '{cycle_end_date}'
        """
        device_usage_df = database.execute_query(usage_query, True)
        if device_usage_df.empty:
            return pd.DataFrame()

        device_usage_df["usage_date"] = pd.to_datetime(device_usage_df["usage_date"]).dt.strftime("%Y-%m-%d")
        grouped_usage_df = device_usage_df.groupby(["mobility_device_id", "usage_date"], as_index=False).sum()
        grouped_usage_df = grouped_usage_df.rename(columns={"mobility_device_id": "device_id"})

        # Prepare mapping DataFrames safely
        if not iccid_df.empty:
            iccid_mapping = iccid_df[["id", "iccid"]].rename(columns={"id": "device_id", "iccid": "ICCID"})
        else:
            iccid_mapping = pd.DataFrame(columns=["device_id", "ICCID"])

        if not msisdn_df.empty:
            msisdn_mapping = msisdn_df[["id", "msisdn"]].rename(columns={"id": "device_id", "msisdn": "MSISDN"})
        else:
            msisdn_mapping = pd.DataFrame(columns=["device_id", "MSISDN"])

        # Merge usage with both mapping sources
        usage_iccid = pd.merge(grouped_usage_df, iccid_mapping, on="device_id", how="inner")
        usage_msisdn = pd.merge(grouped_usage_df, msisdn_mapping, on="device_id", how="inner")

        # Pivot both
        iccid_pivot = usage_iccid.pivot_table(index="ICCID", columns="usage_date", values="data_usage", aggfunc="sum")
        msisdn_pivot = usage_msisdn.pivot_table(index="MSISDN", columns="usage_date", values="data_usage", aggfunc="sum")

        # Align columns
        iccid_pivot_df = iccid_pivot.reindex(columns=billing_cycle_dates, fill_value='-')
        msisdn_pivot_df = msisdn_pivot.reindex(columns=billing_cycle_dates, fill_value='-')

        # Merge into one result for return
        df_with_iccid = pd.merge(df, iccid_pivot_df, on="ICCID", how="left")
        df_with_both = pd.merge(df_with_iccid, msisdn_pivot_df, on="MSISDN", how="left", suffixes=('', '_msisdn'))

        # Combine columns
        for col in billing_cycle_dates:
            df_with_both[col] = df_with_both[col].combine_first(df_with_both[f"{col}_msisdn"])
            df_with_both.drop(columns=[f"{col}_msisdn"], inplace=True)

        return df_with_both.drop_duplicates()

    except Exception as e:
        logging.exception(f"### fetch_and_pivot_daily_device_usage Error : {e}")
        return pd.DataFrame()


def export_to_s3_bucket(data):
    """
    Exports data to an Excel file and uploads it to an Amazon S3 bucket based on the specified module.

    This function handles various report types and modules with specific logic for:
    - SimManagement Inventory
    - Usage reports (Usage By Line, Daily Usage, etc.)
    - Customer data exports (Rate Plans, Pool Usage, etc.)
    - System reports (Notifications, Automation logs, etc.)
    
    The function performs database queries, formats data into Excel, and manages S3 uploads with proper error handling.

    Args:
        data (dict): A dictionary containing:
            - Partner (str): Partner/tenant name
            - tenant_name (str): Tenant name
            - role_name (str): User's role
            - module_name (str): Name of module/report to export
            - user_name (str): Username performing export
            - service_provider (str): Service provider name (for some reports)
            - billing_cycle_period (str/list): Billing period(s) for reports
            - killbill_flag (bool): Flag for Killbill database
            - db_name (str): Database name
            - list_view_data_id (str): ID for list view data (Bulk Change History)

    Returns:
        dict: A dictionary with:
            - flag (bool): True if export succeeded, False otherwise
            - message (str): Status message
            - download_url (str, optional): S3 download URL if successful
    """
    logging.info(f"###export_to_s3_bucket Request Data is {data}")
    S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME", " ")
    # Extract input parameters
    Partner = data.get("Partner", "")
    tenant_name=data.get('tenant_name','')
    role = data.get("role_name", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    user_name = data.get("user_name", "")
    session_id = data.get("session_id", "")
    username=data.get('username','')
    service_provider = data.get("service_provider", "")
    module_name = "Usage By Line Report" if module_name == "Usage By Line Report View" else module_name
    if module_name == "Usage By Line Report":
        billing_cycle_period = data.get("billing_cycle_period", [])
    else:
        billing_cycle_period = data.get("billing_cycle_period", "")
    # if module_name == "Usage By Line Report":
    #     billing_cycle_period = data.get("billing_cycle_period", "")
    #     # Convert string date to proper format if needed
    #     if isinstance(billing_cycle_period, str):
    #         try:
    #             billing_cycle_period = datetime.strptime(billing_cycle_period, "%m-%d-%Y").date()
    #         except ValueError:
    #             return {"flag": False, "message": "Invalid billing cycle format. Use MM-DD-YYYY"}
    # else:
    #     billing_cycle_period = data.get("billing_cycle_period", "")

    end_date = data.get("end_date", "")
    killbill_flag = data.get("killbill_flag", "")
    try:
        killbill_db = DB("billing_platform", **db_config)
    except Exception as e:
        logging.exception(f"### Exception is {e}")
    start_date = data.get("start_date", "")
    tenant_database = data.get("db_name", "")
    export_base_path = os.getenv("EXPORT_BASE_PATH")
    
    #find the billing platform flag
    if tenant_database == 'altaworx_test':
        tenant_name = 'Altaworx'
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id","billing_platform_flag"])
    tenant_id = tenant_data["id"].to_list()[0]
    billing_platform_flag = tenant_data["billing_platform_flag"].to_list()[0]
    if module_name in ("Active Customer Rate Plan","Customer Rate Plan") and billing_platform_flag:
        module_name = module_name + " Billing Platform"

    parent_tenant_id=None
    if module_name == "SimManagement Inventory":
        file_name = (
            f"{export_base_path}/{module_name_snake_case}/SimManagement/Inventory.xlsx"
        )
    else:
        file_name = f"{export_base_path}/{module_name_snake_case}/{module_name}.xlsx"
    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"
    list_view_data_id = data.get("list_view_data_id", "3394")
    if module_name in ("SimManagement Inventory" ,"Zero Usage Report Export",
            "Automation rule verification report Export",
            "Status History Report Export",
            "Customer Rate Pool Usage Report Export",
            "Pool Group Summary Report Export",
            "Usage By Line Report",
            "Newly Activated Report Export",
            "Active Lines Report",
            "Active Lines Report Export",
            "Daily usage report Export"):
        if db_config and "customer_rate_plan_name" in db_config:
            del db_config["customer_rate_plan_name"]
        if db_config and "feature_codes" in db_config:
            del db_config["feature_codes"]
        database = DB(tenant_database, **db_config)
    else:
        database = DB(tenant_database, **db_config)
    if module_name in ("Active Customer Rate Plan","Customer Rate Plan","Active Customer Rate Plan Billing Platform","Customer Rate Plan Billing Platform"):
        if db_config and "feature_codes" in db_config:
            del db_config["feature_codes"]
        database = DB(tenant_database, **db_config)
    else:
        database = DB(tenant_database, **db_config)
    database_con_withoutfilter=database = DB(tenant_database, **db_config_withoutfilter)
    if module_name in ("Rev assurance","Rev assurance variance"):
        try:
            for key in ["tenant_ids", "feature_codes", "customer_rate_plan_name", "billing_account_number"]:
                try:
                    del db_config[key]
                except KeyError:
                    pass

        except Exception as e:
            logging.warning(
                f"### add_service_line_data function: Exception deleting tenant_ids from db_config: {e}"
            )
        database = DB(tenant_database, **db_config)
    else:
        database = DB(tenant_database, **db_config)
    if module_name == "Centralized Bulk Change View":
        database = DB(tenant_database,multi_schema=False,**db_config)
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_name=data.get("tenant_name","")
    optimization_setting_table='optimization_setting'
    if tenant_name == "Altaworx Test":
            tenant_id = 1  # Include the hardcoded ID
            tenant_name='Altaworx'
    else:
        # Default case: fetch only from the database
        tenant_id = db.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]

    try:
        parent_tenant_query=f'''select parent_tenant_id from tenant where tenant_name='{tenant_name}'
        '''
        parent_tenant_id_df=db.execute_query(parent_tenant_query,True)
        if not parent_tenant_id_df.empty:
            parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]
            if parent_tenant_id is not None:
                optimization_setting_table='optimization_setting_tenant_override'
            else:
                optimization_setting_table='optimization_setting'

    except Exception as e:
        logging.exception(f"### Exception is : {e}")
    # Update export status to 'Waiting'
    db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name},
    )

    # Fetch the query for the module
    if parent_tenant_id is not None and module_name=='SimManagement Inventory':
        # Fetch the query for the module
        module_query_df = db.get_data("export_queries", {"module_name": 'SimManagement Inventory Sub Tenant'})
    else:
        module_query_df = db.get_data("export_queries", {"module_name": module_name})

    if module_query_df.empty:
        return {
            "flag": False,
            "message": f"No query found for module name: {module_name}",
        }

    query = module_query_df.iloc[0]["module_query"]
    if not query:
        return {"flag": False, "message": f"Unknown module name: {module_name}"}

    try:
        if module_name == "SimManagement Inventory":
            logging.info("### Handling SimManagement Inventory module")

            p = database.get_data(
                optimization_setting_table,
                {"tenant_id":tenant_id},
                ["optino_cross_providercustomer_optimization"],
            ).iloc[0, 0]
            if p:
                insert_position = query.index("sms_count")
                new_columns = 'carrier_cycle_usage_mb AS "carrier_cycle_usage",\n    customer_cycle_usage_mb AS "customer_cycle_usage",\n    '
                query = query[:insert_position] + new_columns + query[insert_position:]
            else:
                insert_position = query.index(
                    "sms_count"
                )  # Find where to insert the new column
                query = (
                    query[:insert_position]
                    + 'carrier_cycle_usage_mb AS "data_usage_mb",\n    '
                    + query[insert_position:]
                )

            result_frames = []
            params=[tenant_id]
            query += f""" and tenant_id = {tenant_id}"""
            df = database.execute_query(query, True)
            if role != "Super Admin":
                df = df.drop(columns=["foundation_account_number", "billing_account_number"], errors="ignore")
            if not df.empty:

                def truncate_to_2_decimal(x):
                    if x is None:
                        return None  # Handle None values gracefully
                    return math.floor(x * 100) / 100

                # Check if the columns exist, then apply truncation
                if "data_usage_mb" in df.columns:
                    df["data_usage_mb"] = df["data_usage_mb"].apply(
                        truncate_to_2_decimal
                    )
                    df["data_usage_mb"] = df["data_usage_mb"].apply(
                        lambda x: f"{x:.2f}"
                    )

                if "carrier_cycle_usage" in df.columns:
                    df["carrier_cycle_usage"] = df["carrier_cycle_usage"].apply(
                        truncate_to_2_decimal
                    )
                    # Ensure formatting with 2 decimal places
                    df["carrier_cycle_usage"] = df["carrier_cycle_usage"].apply(
                        lambda x: f"{x:.2f}"
                    )
                result_frames.append(df)

            if result_frames:
                combined_df = pd.concat(result_frames, ignore_index=True)

                # Fetch optimization setting for `p`
                p = database.get_data(
                    optimization_setting_table,
                    {"tenant_id":tenant_id},
                    ["optino_cross_providercustomer_optimization"],
                ).iloc[0, 0]

                # Conditionally modify DataFrame based on `p`
                if (
                    not p
                ):  # If `p == False`, drop `customer_cycle_usage_mb` and rename `carrier_cycle_usage_mb` to `data_usage_mB`
                    if "customer_cycle_usage_mb" in combined_df.columns:
                        combined_df = combined_df.drop(
                            columns=["customer_cycle_usage_mb"]
                        )
                    if "carrier_cycle_usage_mb" in combined_df.columns:
                        combined_df = combined_df.rename(
                            columns={"carrier_cycle_usage_mb": "data_usage_mB"}
                        )
                # combined_df.columns = [
                #     # col.replace("_", " ").capitalize() for col in combined_df.columns
                #     " ".join(word.capitalize() for word in col.split("_")) for col in combined_df.columns
                # ]
                acronyms = {
                    "SMS",
                    "IMEI",
                    "IP",
                    "BAN",
                    "URL",
                    "UID",
                    "MAC",
                    "EID",
                    "MSISDN",
                    "MB",
                    "CCID",
                    "ICCID",
                    "MSISDN",
                    "IP",
                    "SIM",
                }

                # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
                special_replacements = {"Att": "AT&T", "And": "and"}
                # Format column names
                combined_df.columns = [
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in col.split("_")
                    )
                    for col in combined_df.columns
                ]

                # Apply special replacements (Att -> AT&T, And -> and)
                combined_df.columns = [
                    " ".join(
                        [
                            special_replacements.get(word, word)
                            for word in col.split(" ")
                        ]
                    )
                    for col in combined_df.columns
                ]

                # Remove columns if role is not Super Admin
                if role not in ("Super Admin", "Partner Admin"):
                    columns_to_remove = [
                        "Rate Plan",
                        "Communication Plan",
                        "Carrire Data Allocation MB",
                        "Carrier Rate Plan Cost"
                    ]
                    combined_df = combined_df.drop(columns=columns_to_remove, errors='ignore')
                logging.info(f"### Data successfully combined. Rows: {len(combined_df)}")
            else:

                column = [
                    "Service provider",
                    "IMEI",
                    "SMS count",
                    "Cost center",
                    "Account number",
                    "Customer name",
                    "Date added",
                    "ICCID",
                    "MSISDN",
                    "EID",
                    "Username",
                    "Carrier cycle usage bytes",
                    "Customer rate pool name",
                    "Customer rate plan name",
                    "SIM status",
                    "Date activated",
                    "IP address",
                    "Communication plan",
                    "Pool ID",
                    "Feature codes",
                    "Customer data allocation MB",
                    "Service zip code",
                    "Device make",
                    "Device model",
                    "Next bill cycle date",
                    "Billing account number",
                    "Foundation account number",
                    "BAN status",
                    "Minutes used",
                    "Modified by",
                    "Modified date",
                ]
                combined_df = pd.DataFrame(columns=column)

            # Create an Excel file using OpenPyXL
            workbook = Workbook()
            sheet = workbook.active
            sheet.title = "Sheet1"

            # Write headers to the Excel sheet
            header_font = Font(bold=True)  # Define a bold font for the headers
            for col_idx, header in enumerate(combined_df.columns, start=1):
                cell = sheet.cell(row=1, column=col_idx, value=header)
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.fill = PatternFill(
                    start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                )
                cell.font = header_font

            # Write data to the Excel sheet
            for row_idx, row in combined_df.iterrows():
                for col_idx, value in enumerate(row, start=1):
                    sheet.cell(row=row_idx + 2, column=col_idx, value=value)

            # Adjust column widths
            for col_idx, col_cells in enumerate(sheet.columns, start=1):
                max_length = max(len(str(cell.value or "")) for cell in col_cells)
                sheet.column_dimensions[get_column_letter(col_idx)].width = (
                    max_length + 2
                )

            # Save the workbook to a buffer
            excel_buffer = BytesIO()
            workbook.save(excel_buffer)

            excel_buffer.seek(0)

            s3_client = boto3.client("s3")
            logging.info("### Uploading file to S3 bucket")
            try:
                s3_client.put_object(
                    Bucket=S3_BUCKET_NAME,
                    Key=file_name,
                    Body=excel_buffer.getvalue(),
                    ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                )
                logging.info(
                    f"### File successfully uploaded to : {S3_BUCKET_NAME}/{file_name}"
                )
            except Exception as e:
                logging.exception(f"### export_to_s3 Failed to upload file: {e}")

        elif module_name in (
            "Zero Usage Report Export",
            "Automation rule verification report Export",
            "Status History Report Export",
            "Customer Rate Pool Usage Report Export",
            "Pool Group Summary Report Export",
            "Usage By Line Report",
            "Newly Activated Report Export",
            "Daily usage report Export",
        ):

            if module_name == "Usage By Line Report":
                # Process billing_cycle_period for this specific module
                billing_cycle_period_all = (
                    tuple(map(str, billing_cycle_period))
                    if isinstance(billing_cycle_period, list)
                    else billing_cycle_period
                )
                # Define params for this module
                params = [service_provider, billing_cycle_period]
            elif module_name == "Status History Report Export":
                # Fetch service provider ID and set params
                service_provider_data = database.get_data(
                    "serviceprovider",
                    {"service_provider_name": service_provider, "is_active": True},
                    ["id"],
                )
                service_provider_id = service_provider_data["id"].to_list()[0]
                params = [service_provider_id, tenant_id, billing_cycle_period]
            else:
                # Handle other modules in the list
                params = [service_provider, billing_cycle_period]
            if not service_provider and not billing_cycle_period:
                logging.info("### No service provider or billing cycle period provided.")
                if module_name == "Usage By Line Report":
                    p = database.get_data(
                            optimization_setting_table,
                            {"tenant_id":tenant_id},
                            ["optino_cross_providercustomer_optimization"],
                        ).iloc[0, 0]
                    if not p:
                        # Step 1: Fetch the latest billing cycle end date for each service provider
                        billing_period_query = """
                        SELECT DISTINCT ON (service_provider)
                                service_provider,
                                billing_cycle_end_date
                            FROM billing_period
                            WHERE is_active = 'true'
                            ORDER BY
                                service_provider,
                                id DESC;
                        """

                        billing_dates_df = database.execute_query(
                            billing_period_query, True
                        )

                        # Ensure 'billing_cycle_end_date' is in datetime format
                        billing_dates_df["billing_cycle_end_date"] = pd.to_datetime(
                            billing_dates_df["billing_cycle_end_date"]
                        )

                        # Convert to MM/DD/YYYY HH:MM:SS format
                        billing_dates_df["formatted_date"] = billing_dates_df[
                            "billing_cycle_end_date"
                        ].dt.strftime("%m/%d/%Y %H:%M:%S")

                        # Step 2: Prepare the query for fetching usage data
                        query_main = """
                        SELECT
                                billing_cycle_end_date,
                                service_provider_name as service_provider,
                                iccid,
                                msisdn,
                                foundation_account_number,
                                billing_account_number,
                                customer_rate_pool_name as customer_pool,
                                customer_name,
                                username,
                                carrier_rate_plan,
                                rate_plan_name as customer_rate_plan,
                                data_usage_mb,
                                sms_usage,
                                status_display_name as sim_status,
                                date_activated
                                FROM public.vw_usage_by_line_from_devices
                                WHERE tenant_id = %s and is_active=True
                                AND service_provider_name = %s
                                AND TO_CHAR(billing_cycle_end_date, 'MM/DD/YYYY HH24:MI:SS') = %s
                        """
                        # Step 3: Fetch data for each service provider & billing cycle, then combine
                        final_df = pd.DataFrame()  # Empty DataFrame to store final results

                        for _, row in billing_dates_df.iterrows():
                            service_provider = row["service_provider"]
                            billing_cycle_date = row["formatted_date"]

                            # Execute query for the specific service provider & billing cycle
                            data = database.execute_query(
                                query_main, params=[tenant_id,service_provider, billing_cycle_date]
                            )
                            df = pd.DataFrame(data)

                            if not df.empty:
                                # Convert 'billing_cycle_end_date' to MM/DD/YYYY format for consistency
                                df["billing_cycle_end_date"] = pd.to_datetime(
                                    df["billing_cycle_end_date"]
                                ).dt.strftime("%m/%d/%Y")

                                # Append to final DataFrame
                                final_df = pd.concat([final_df, df], ignore_index=True)
                        # count_dict = final_df["service_provider"].value_counts().to_dict()
                        data_frame = final_df
                    else:
                        # billing_period_query = """
                            #         WITH billing_data AS (
                            #                 SELECT
                            #                     c.id AS customer_id,
                            #                     c.customer_name,
                            #                     bp.id AS billing_period_id,
                            #                     bp.bill_month,
                            #                     bp.bill_year,
                            #                     COALESCE(bp.customer_bill_period_end_day, 1) AS customer_bill_period_end_day,
                            #                     COALESCE(bp.customer_bill_period_end_hour, 0) AS customer_bill_period_end_hour,
                            #                     ROW_NUMBER() OVER (PARTITION BY c.id ORDER BY bp.bill_year DESC, bp.bill_month DESC) AS row_num
                            #                 FROM
                            #                     public.customers c
                            #                 JOIN LATERAL
                            #                     usp_get_customer_billing_period_by_siteid(c.id) bp ON true
                            #                 WHERE
                            #                     c.is_active = true
                            #             )
                            #             SELECT
                            #                 customer_name,
                            #                 CONCAT(
                            #                     LPAD(bill_month::TEXT, 2, '0'), '-',
                            #                     LPAD(customer_bill_period_end_day::TEXT, 2, '0'), '-',
                            #                     bill_year::TEXT, ' ',
                            #                     LPAD(customer_bill_period_end_hour::TEXT, 2, '0'), ':00:00'
                            #                 ) AS billing_cycle_end_date
                            #             FROM
                            #                 billing_data
                            #             WHERE
                            #                 row_num = 1
                            #             ORDER BY
                            #                 customer_name;
                            #     """

                            # billing_dates_df = database.execute_query(
                            #     billing_period_query, True
                            # )

                            # # Ensure 'billing_cycle_end_date' is in datetime format
                            # billing_dates_df["billing_cycle_end_date"] = pd.to_datetime(
                            #     billing_dates_df["billing_cycle_end_date"]
                            # )

                            # # Convert to MM/DD/YYYY HH:MM:SS format
                            # billing_dates_df["formatted_date"] = billing_dates_df[
                            #     "billing_cycle_end_date"
                            # ].dt.strftime("%m/%d/%Y %H:%M:%S")


                            query_main = f"""
                            select
                            service_provider_display_name,
                            customer_cycle_end_date,
                            iccid,msisdn,
                            foundation_account_number,
                            billing_account_number,
                            customer_rate_pool_name,
                            customer_name,
                            username,
                            carrier_rate_plan,
                            rate_plan_name,
                            integration_id,
                            data_usage_mb,
                            sms_usage,
                            status_display_name,
                            date_activated,
                            tenant_id
                            from usp_report_customer_usage_by_line
                            WHERE tenant_id = {tenant_id}  and is_active=True

                            """

                            final_df = pd.DataFrame()



                            # Execute query for the specific service provider & billing cycle

                            data = database.execute_query(
                                query_main, True
                            )
                            df = pd.DataFrame(data)

                            if not df.empty:


                                # Append to final DataFrame
                                final_df = pd.concat([final_df, df], ignore_index=True)
                            data_frame = final_df
                elif module_name == "Daily usage report Export" and start_date and end_date:
                    query = "select * from fn_vw_daily_usage_report_export(%s,%s,%s,%s)"
                    params = [tenant_id, None, start_date, end_date]
                    data_frame = database.execute_query(query, params=params)
                else:
                    logging.info("### export_to_s3 No service provider or billing cycle period provided.else condition")
                    query = query.split("WHERE")[0].strip()
                    # Add LIMIT 100000 if not already present
                    if "LIMIT" not in query.upper():
                        if module_name == "Automation rule verification report Export":
                            query += ""

                        elif module_name == "Status History Report Export":
                            query += f""" WHERE tenant_id = {tenant_id} and modified_date >= CURRENT_DATE - INTERVAL '30 days'"""
                        elif module_name == "Notifications":
                            logging.info(f"### inside notification module, query : {query}")
                            query = query
                        elif module_name == "Pool Group Summary Report Export":
                            query += f""" WHERE tenant_id = {tenant_id}"""
                        else:
                            query += f""" WHERE tenant_id = {tenant_id}"""



                    if module_name == "Pool Group Summary Report Export":
                        query += f""" WHERE tenant_id = {tenant_id}"""

                    data_frame = database.execute_query(query, True)

            else:
                # Add LIMIT 100000 if not already present
                if "LIMIT" not in query.upper():
                    query += ""
                if module_name == "Usage By Line Report":
                    logging.info("Usage by line report query executions")
                    p = database.get_data(
                            optimization_setting_table,
                            {"tenant_id":tenant_id},
                            ["optino_cross_providercustomer_optimization"],
                        ).iloc[0, 0]
                    if not p:
                        logging.info("if cross provider is off then this will run")
                        # Fetch full data for the first billing cycle
                        primary_billing_period = billing_cycle_period[0]

                        main_data = """
                        SELECT
                                billing_cycle_end_date,
                                service_provider_name as service_provider,
                                iccid,
                                msisdn,
                                foundation_account_number,
                                billing_account_number,
                                customer_rate_pool_name as customer_pool,
                                customer_name,
                                username,
                                carrier_rate_plan,
                                rate_plan_name as customer_rate_plan,
                                data_usage_mb,
                                sms_usage,
                                status_display_name as sim_status,
                                date_activated
                                FROM public.vw_usage_by_line_from_devices
                                WHERE tenant_id = %s and is_active=True
                                AND service_provider_name = %s
                                AND billing_cycle_end_date = %s
                        """

                        # Query for device history data
                        secondary_data = """
                                            SELECT
                                                    billing_cycle_end_date,
                                                    service_provider_display_name as service_provider,
                                                    iccid,
                                                    msisdn,
                                                    foundation_account_number,
                                                    billing_account_number,
                                                    customer_rate_pool_name as customer_pool,
                                                    customer_name,
                                                    username,
                                                    carrier_rate_plan,
                                                    rate_plan_name as customer_rate_plan,
                                                    data_usage_mb,
                                                    sms_usage,
                                                    status_display_name as sim_status,
                                                    date_activated
                                                    FROM public.vw_usage_by_line_report
                                                    WHERE tenant_id = %s and is_active=True
                                                    AND service_provider_display_name = %s
                                                    AND billing_cycle_end_date IN %s
                                            """

                        # Fetch primary billing cycle data from both sources
                        primary_billing_period = billing_cycle_period_all[0]

                        # Get usage report data
                        main_data = database.execute_query(
                            main_data, params=[tenant_id,service_provider, primary_billing_period]
                        )
                        df_main = pd.DataFrame(main_data)



                        # Get device history data
                        secondary_data = database.execute_query(
                            secondary_data, params=[tenant_id,service_provider, billing_cycle_period_all]
                        )
                        df_secondary = pd.DataFrame(secondary_data)

                        # Instead of grouping and summing duplicates, create a unique identifier
                        if 'duplicate_records' in df_secondary.columns:
                            df_secondary = df_secondary.sort_values('data_usage_mb', ascending=False)
                        else:
                            # Create a sequence number for each iccid+billing_cycle combination
                            df_secondary['record_seq'] = df_secondary.groupby(['iccid', 'billing_cycle_end_date']).cumcount() + 1

                            # Create unique pivot column by combining billing cycle with sequence number
                            df_secondary['pivot_column'] = df_secondary['billing_cycle_end_date'].astype(str) + '_' + df_secondary['record_seq'].astype(str)

                            # Now pivot using the unique pivot column
                            df_pivot = df_secondary.pivot(index='iccid', columns='pivot_column', values='data_usage_mb').reset_index()

                            # Merge pivoted data with main data using 'iccid'
                            # Merge pivoted data with main data using 'iccid'
                            if df_main.empty:
                                # Get first record per iccid from df_secondary (non-pivoted data)
                                df_base = df_secondary.sort_values('billing_cycle_end_date').groupby('iccid').first().reset_index()

                                # Drop potential duplicates or temp columns if they exist
                                df_base = df_base.drop(columns=['record_seq', 'pivot_column'], errors='ignore')

                                # Merge base info with pivoted usage
                                df_final = df_base.merge(df_pivot, on='iccid', how='left')
                            else:
                                df_final = df_main.merge(df_pivot, on='iccid', how='outer')

                            # Rename the columns for readability
                            rename_dict = {}
                            for col in df_pivot.columns:
                                if col != 'iccid':
                                    date_part = col.split('_')[0]
                                    seq_part = col.split('_')[1]
                                    rename_dict[col] = f"{date_part}_record{seq_part}"

                            df_final = df_final.rename(columns=rename_dict)

                            # Clean up temporary columns in the original dataframe
                            if 'record_seq' in df_secondary.columns:
                                df_secondary = df_secondary.drop(columns=['record_seq', 'pivot_column'])

                            # If any other temporary columns were added to the final dataframe that need removal
                            # df_final = df_final.drop(columns=['any_other_temp_column'])

                            data_frame = df_final

                    else:
                        logging.info("if cross provider is on then this will run")
                        if not billing_cycle_period:
                            query_main = """
                                select
                                        service_provider_display_name,
                                        customer_cycle_end_date,
                                        iccid,msisdn,
                                        foundation_account_number,
                                        billing_account_number,
                                        customer_rate_pool_name,
                                        customer_name,
                                        customer_id,
                                        username,
                                        carrier_rate_plan,
                                        rate_plan_name,
                                        data_usage_mb,
                                        sms_usage,
                                        status_display_name,
                                        date_activated
                                        from usp_report_customer_usage_by_line
                                        WHERE tenant_id = %s and is_active=True
                                        and customer_id = %s
                                """
                            params = [tenant_id,service_provider]
                            data_frame = database.execute_query(query_main, params=params)
                        else:

                            logging.info("customer billing period retrieval")
                            query_main = """
                            select
                                service_provider_display_name,
                                customer_cycle_end_date,
                                iccid,
                                msisdn,
                                foundation_account_number,
                                billing_account_number,
                                customer_rate_pool_name,
                                customer_name,username,
                                carrier_rate_plan,
                                rate_plan_name,
                                sms_usage,
                                integration_id,
                                data_usage_mb,
                                status_display_name,
                                date_activated,
                                tenant_id
                                from usp_report_customer_historyusagebyline_rmf(%s,%s,%s )
                                """

                            params = [service_provider,tenant_id,billing_cycle_period ]
                            data_frame = database.execute_query(query_main, params=params)


                else:
                    try:
                        if module_name == "Daily usage report Export" and service_provider:
                            if billing_cycle_period:
                                logging.info(f"### service_provider_Daily usage report Export billing_cycle_period : {billing_cycle_period}")
                                # Parse datetime
                                end_date_dt = datetime.datetime.strptime(billing_cycle_period, "%m-%d-%Y %H:%M:%S")

                                # Subtract 1 month, then add 1 day → start of billing cycle
                                start_date_dt = (end_date_dt - relativedelta(months=1)) + timedelta(days=1)
                                # Convert to strings (only date part, no time)
                                start_date = start_date_dt.strftime("%Y-%m-%d")
                                end_date = end_date_dt.strftime("%Y-%m-%d")

                                logging.info(f'Daily usage report Export Start Date: {start_date}')
                                logging.info(f'Daily usage report Export End Date: {end_date}')
                            logging.info(f"### service_provider_Daily usage report Export : {service_provider} {start_date} {end_date}")
                            # select distinct billing_cycle_end_date of service provider
                            # service_provider_id from serviceprovider table
                            service_provider_data = database.get_data(
                                "serviceprovider",
                                {"service_provider_name": service_provider, "is_active": True},
                                ["id"],
                            )
                            service_provider_id = service_provider_data["id"].to_list()[0]
                            query = "select * from fn_vw_daily_usage_report_export(%s,%s,%s,%s)"
                            params = [tenant_id, service_provider_id, start_date, end_date]
                    except Exception as e:
                        logging.error(f"### Error while processing billing cycle dates: {e}")

                    if module_name not in ["Status History Report Export","Daily usage report Export"]:
                        query = modify_query(query,tenant_id)
                    data_frame = database.execute_query(query, params=params)
                    
            logging.info(f"### export_to_s3 query executed: {query} with params: {params}")
            if data_frame.empty:
                db.update_dict(
                    "export_status",
                    {"status_flag": "No Data Found for export", "url": ""},
                    {"module_name": module_name},
                )
                return {"flag": False, "message": "No data found for export_1."}

            # data_frame.columns = [
            #     # col.replace("_", " ").capitalize() for col in data_frame.columns
            #     " ".join(word.capitalize() for word in col.split("_")) for col in data_frame.columns
            # ]
            acronyms = {
                "SMS",
                "IMEI",
                "IP",
                "BAN",
                "URL",
                "UID",
                "MAC",
                "EID",
                "MSISDN",
                "MB",
                "CCID",
                "ICCID",
                "MSISDN",
                "IP",
                "SIM",
            }

            # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
            special_replacements = {"Att": "AT&T", "And": "and"}
            # Format column names
            data_frame.columns = [
                # Handle timestamp or date-like columns separately
                (
                    col
                    if isinstance(col, pd.Timestamp)
                    or bool(re.match(r"\d{2}[-/]\d{2}[-/]\d{4}", str(col)))
                    else
                    # Process string column names
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in str(col).split("_")
                    )
                )
                for col in data_frame.columns
            ]

            # Apply special replacements (Att -> AT&T, And -> and)
            data_frame.columns = [
                (
                    " ".join(
                        [
                            special_replacements.get(word, word)
                            for word in str(col).split(" ")
                        ]
                    )
                    if isinstance(col, str)
                    else col
                )  # Only apply replacements to string columns
                for col in data_frame.columns
            ]

            # Remove columns if role is not Super Admin
            if role not in ("Super Admin", "Partner Admin"):
                columns_to_remove = [
                    "Carrier Rate Plan",
                    "Communication Plan",
                    "Carrire Data Allocation MB",
                    "Carrier Rate Plan Cost"
                ]
                data_frame = data_frame.drop(columns=columns_to_remove, errors='ignore')

            cols_to_remove = ["Integration Id","Tenant Id","Is Active","Id"]
            data_frame = data_frame.drop(columns=cols_to_remove, errors='ignore')

            if module_name == "Daily usage report Export" and "Usage Date" in data_frame.columns:
                # Convert 'Billing Cycle End Date' to datetime and extract only date
                try:
                    df_pivot = data_frame.pivot_table(
                        index = ["Service Provider","ICCID","MSISDN"],
                        columns="Usage Date",                  # pivot on usage_date
                        values="Carrier Cycle Usage",
                        aggfunc="first"
                    ).reset_index()
                    # Optional: Flatten the column names
                    df_pivot.columns.name = None
                    # Merge back all other columns (deduplicated)
                    final_df = data_frame.drop(columns=["Carrier Cycle Usage", "Usage Date", "Created Date", "Modified Date"],errors="ignore").drop_duplicates()
                    data_frame = final_df.merge(df_pivot, on=["Service Provider","ICCID","MSISDN"], how="left")
                except Exception as e:
                    logging.error(f"### Error while pivoting Daily usage report Export: {e}")

            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                data_frame.to_excel(writer, index=False, sheet_name="Sheet1")

                # Get the workbook and the sheet
                workbook = writer.book
                sheet = workbook["Sheet1"]

                # Apply styles to the header row
                header_font = Font(bold=True)  # Define a bold font for the headers
                for cell in sheet[1]:
                    cell.alignment = Alignment(
                        horizontal="center", vertical="center"
                    )  # Center align
                    cell.fill = PatternFill(
                        start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                    )  # Grey background
                    cell.font = header_font
                # Adjust column widths based on content
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = (
                        max_length + 2
                    )

            excel_buffer.seek(0)

            s3_client = boto3.client("s3")
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=file_name,
                Body=excel_buffer.getvalue(),
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        elif module_name in ("Automation rule log Export","Actions History Report Export",):
            role = data.get("role_name", "")
            params = [start_date, end_date]

            data_frame = database.execute_query(query, params=params)

            if data_frame.empty:
                db.update_dict(
                    "export_status",
                    {"status_flag": "No Data Found for export", "url": ""},
                    {"module_name": module_name},
                )
                return {"flag": False, "message": "No data found for export_2."}

            # data_frame.columns = [
            #     # col.replace("_", " ").capitalize() for col in data_frame.columns
            #     " ".join(word.capitalize() for word in col.split("_")) for col in data_frame.columns
            # ]
            acronyms = {
                "SMS",
                "IMEI",
                "IP",
                "BAN",
                "URL",
                "UID",
                "MAC",
                "EID",
                "MSISDN",
                "MB",
                "CCID",
                "ICCID",
                "MSISDN",
                "IP",
                "SIM",
            }

            # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
            special_replacements = {"Att": "AT&T", "And": "and"}
            # Format column names
            data_frame.columns = [
                " ".join(
                    part.upper() if part.upper() in acronyms else part.capitalize()
                    for part in col.split("_")
                )
                for col in data_frame.columns
            ]

            # Apply special replacements (Att -> AT&T, And -> and)
            data_frame.columns = [
                " ".join(
                    [special_replacements.get(word, word) for word in col.split(" ")]
                )
                for col in data_frame.columns
            ]
            # Remove columns if role is not Super Admin
            if role not in ("Super Admin", "Partner Admin"):
                columns_to_remove = [
                    "Carrier Rate Plan",
                    "Communication Plan",
                    "Carrire Data Allocation MB",
                    "Carrier Rate Plan Cost"
                ]
                data_frame  = data_frame.drop(columns=columns_to_remove, errors='ignore')
                
            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                data_frame.to_excel(writer, index=False, sheet_name="Sheet1")

                # Get the workbook and the sheet
                workbook = writer.book
                sheet = workbook["Sheet1"]

                # Apply styles to the header row
                header_font = Font(bold=True)  # Define a bold font for the headers
                for cell in sheet[1]:
                    cell.alignment = Alignment(
                        horizontal="center", vertical="center"
                    )  # Center align
                    cell.fill = PatternFill(
                        start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                    )  # Grey background
                    cell.font = header_font
                # Adjust column widths based on content
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = (
                        max_length + 2
                    )

            excel_buffer.seek(0)

            s3_client = boto3.client("s3")
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=file_name,
                Body=excel_buffer.getvalue(),
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        elif module_name=='Bulk Change History':
            params = [list_view_data_id]
            #query = modify_query(query,tenant_id)
            data_frame = database.execute_query(query, params=params)
            tenant_time_zone = fetch_tenant_timezone(db, data)
            data_frame = convert_timestamp_dataframe(data_frame, tenant_time_zone)
            if data_frame.empty:
                db.update_dict(
                    "export_status",
                    {"status_flag": "No Data Found for export", "url": ""},
                    {"module_name": module_name},
                )
                return {"flag": False, "message": "No data found for export_3."}

            # data_frame.columns = [
            #     # col.replace("_", " ").capitalize() for col in data_frame.columns
            #     " ".join(word.capitalize() for word in col.split("_")) for col in data_frame.columns
            # ]
            acronyms = {
                "SMS",
                "IMEI",
                "IP",
                "BAN",
                "URL",
                "UID",
                "MAC",
                "EID",
                "MSISDN",
                "MB",
                "CCID",
                "ICCID",
                "MSISDN",
                "IP",
                "SIM",
            }

            # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
            special_replacements = {"Att": "AT&T", "And": "and"}
            # Format column names
            data_frame.columns = [
                " ".join(
                    part.upper() if part.upper() in acronyms else part.capitalize()
                    for part in col.split("_")
                )
                for col in data_frame.columns
            ]

            # Apply special replacements (Att -> AT&T, And -> and)
            data_frame.columns = [
                " ".join(
                    [special_replacements.get(word, word) for word in col.split(" ")]
                )
                for col in data_frame.columns
            ]
            # Remove columns if role is not Super Admin
            if role not in ("Super Admin", "Partner Admin"):
                columns_to_remove = [
                    "Carrier Rate Plan",
                    "Communication Plan",
                    "Carrire Data Allocation MB",
                    "Carrier Rate Plan Cost"
                ]
                data_frame = data_frame.drop(columns=columns_to_remove, errors='ignore')

            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                data_frame.to_excel(writer, index=False, sheet_name="Sheet1")

                # Get the workbook and the sheet
                workbook = writer.book
                sheet = workbook["Sheet1"]

                # Apply styles to the header row
                header_font = Font(bold=True)  # Define a bold font for the headers
                for cell in sheet[1]:
                    cell.alignment = Alignment(
                        horizontal="center", vertical="center"
                    )  # Center align
                    cell.fill = PatternFill(
                        start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                    )  # Grey background
                    cell.font = header_font
                # Adjust column widths based on content
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = (
                        max_length + 2
                    )

            excel_buffer.seek(0)

            s3_client = boto3.client("s3")
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=file_name,
                Body=excel_buffer.getvalue(),
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        elif module_name == 'Notifications':
            #query = modify_query(query,tenant_id)
            data_frame = db.execute_query(query, True)
            data_frame.columns = [col.replace("_", " ").title() for col in data_frame.columns]
            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                data_frame.to_excel(writer, index=False, sheet_name="Sheet1")

                # Get the workbook and the sheet
                workbook = writer.book
                sheet = workbook["Sheet1"]
                # Style header row
                header_font = Font(bold=True)
                for cell in sheet[1]:
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                    cell.font = header_font

                # Adjust column widths based on content
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    col_letter = get_column_letter(col_idx)
                    if col_letter == "I":
                        sheet.column_dimensions[col_letter].width = 40  # or adjust as needed
                    else:
                        max_length = max(len(str(cell.value or "")) for cell in col_cells)
                        sheet.column_dimensions[col_letter].width = max_length + 2

                column_to_wrap = column_index_from_string("I") 
                # Apply text wrapping + top alignment to a specific column (e.g., column B)
                for row in sheet.iter_rows(min_row=2, min_col=column_to_wrap, max_col=column_to_wrap):
                    for cell in row:
                        cell.alignment = Alignment(wrap_text=True, vertical="top")

            # Upload to S3
            excel_buffer.seek(0)
            s3_client = boto3.client("s3")
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=file_name,
                Body=excel_buffer.getvalue(),
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        else:
            # Custom logic for "customer groups" module
            if module_name.lower() == "customer groups":
                if parent_tenant_id and role in ('Super Admin','Partner Admin'):
                    customergroupquery = """select name,
                        CASE
                            WHEN parent_tenant_name IS NOT NULL THEN tenant_name
                            ELSE NULL
                        END AS "Sub_Partner",modified_by AS last_modified_by,TO_CHAR(modified_date, 'MM-DD-YYYY HH24:MI:SS') AS last_modified_date_time from customergroups where  is_active=True order by name asc"""

                    data_frame = database_con_withoutfilter.execute_query(customergroupquery, True)
                elif parent_tenant_id and role not in ("Super Admin", "Partner Admin"):
                    user_first_last_name = data.get('firstLastName',None)
                    user_customer_group_query = f"""
                        SELECT customer_group
                        FROM user_module_tenant_mapping
                        WHERE user_name = '{username}'
                        AND tenant_id = {tenant_id}
                    """
                    user_customer_group = common_utils_database.execute_query(
                        user_customer_group_query, True
                    )['customer_group'].to_list()

                    ##created customergroups
                    created_customer_groups_query = f"""
                        SELECT name AS customer_group
                        FROM customergroups
                        WHERE created_by = '{user_first_last_name}'
                    """
                    created_customer_groups = database_con_withoutfilter.execute_query(
                        created_customer_groups_query, True
                    )['customer_group'].to_list()

                    # Append the two lists
                    user_customer_group.extend(created_customer_groups)
                    # Now build the query using the combined list
                    # We'll use a Python-safe way to format the IN clause:
                    placeholders = ', '.join(f"'{cg}'" for cg in user_customer_group)
                    customergroupquery = f"""select name,
                        modified_by AS last_modified_by,TO_CHAR(modified_date, 'MM-DD-YYYY HH24:MI:SS') AS last_modified_date_time from customergroups where tenant_id='{tenant_id}' and name IN ({placeholders}) and is_active=True order by name asc"""

                    data_frame = database_con_withoutfilter.execute_query(customergroupquery, True)
                else:
                    customergroupquery = """select name,
                        CASE
                            WHEN parent_tenant_name IS NOT NULL THEN tenant_name
                            ELSE NULL
                        END AS "Sub_Partner",modified_by AS last_modified_by,TO_CHAR(modified_date, 'MM-DD-YYYY HH24:MI:SS') AS last_modified_date_time from customergroups where  is_active=True order by name asc"""

                    data_frame = database_con_withoutfilter.execute_query(customergroupquery, True)
            elif killbill_flag == True or killbill_flag == "True":
                logging.info(f"### export_to_s3 query {query}")
                query = modify_query(query,tenant_id)
                data_frame = killbill_db.execute_query(query, True)
            else:
                if module_name == "Users":
                    query = modify_query(query,tenant_id)
                    data_frame = db.execute_query(query, True)
                elif module_name in ("Tenant Based Banners logs"):
                    data_frame = db.execute_query(query, True)
                elif module_name in  ("E911 Customers", "people_rev_io_customers"):
                    if role not in ("Super Admin", "Partner Admin"):
                        # Parameterized query to prevent SQL injection
                        user_query = F"""
                            SELECT CONCAT(first_name, ' ', last_name) AS full_name
                            FROM users
                            WHERE username = '{data.get("username")}'
                        """
                        user_result = db.execute_query(user_query, True)

                        users = []
                        if user_result is not None and not user_result.empty:
                            users = user_result["full_name"].tolist()


                        if module_name  == "E911 Customers":
                            users_condition = (
                                f""" created_by IN ({','.join(f"'{user}'" for user in users)}) """
                                f"""OR modified_by IN ({','.join(f"'{user}'" for user in users)}) """
                                f"""OR deleted_by IN ({','.join(f"'{user}'" for user in users)})"""
                            )
                            query = query.split("WHERE")[0].strip()
                            query += f""" WHERE is_active = 'true' AND is_deleted = 'false' and {users_condition} ORDER BY id ASC """
                        elif module_name == "people_rev_io_customers":
                            users_condition = (
                                f""" created_by IN ({','.join(f"'{user}'" for user in users)}) """
                                f"""OR modified_by IN ({','.join(f"'{user}'" for user in users)}) """
                            )
                            query = query.split("ORDER")[0].strip()
                            query += f""" WHERE {users_condition} ORDER BY id ASC """
                            query = modify_query(query,tenant_id)
                        data_frame = database.execute_query(query, True)
                    else:
                        query = modify_query(query,tenant_id)
                        # Admins get all records
                        data_frame = database.execute_query(query, True)
                elif module_name in ("Active Customer Rate Plan","Active Customer Rate Plan Billing Platform",'Rev assurance','Rev assurance variance'):
                    params=[tenant_id]
                    data_frame = database.execute_query(query, params=params)
                    if "optimization_type" in data_frame.columns:
                        data_frame["optimization_type"] = data_frame["optimization_type"].replace(
                            {"Cross customer pooling": "Cross Customer Pooling"}
                        )
                    if "status" in data_frame.columns:
                        data_frame["status"] = data_frame["status"].map({True: "Active", False: "Inactive", "True": "Active", "False": "Inactive"})
                    data_frame = data_frame.drop(columns=["product_id"], errors='ignore')
                    def fix_leading_dot_float(x):
                        if isinstance(x, str) and x.startswith('.'):
                            return float(f"0{x}")
                        try:
                            return float(x)
                        except Exception:
                            return x
                    float_columns = [
                        "base_rate",
                        "rate_charge",
                        "overage_rate_cost",
                        "total_charge",
                        "sms_rate",
                        "data_per_overage_charge",
                        "mb_included",
                        "min_plan_mb",
                        "max_plan_mb"
                    ]
                    try:
                        for col in float_columns:
                            if col in data_frame.columns:
                                data_frame[col] = data_frame[col].apply(fix_leading_dot_float)
                                # Remove decimals for Min Plan MB and Max Plan MB
                                if col in ["min_plan_mb", "max_plan_mb","data_per_overage_charge"]:
                                    # Fill NaN with pd.NA for Int64, round floats, then cast
                                    data_frame[col] = (
                                        data_frame[col]
                                        .apply(lambda x: int(x) if pd.notnull(x) and float(x).is_integer() else pd.NA)
                                        .astype("Int64")
                                    )
                                elif col in ["base_rate","rate_charge","overage_rate_cost","total_charge","sms_rate"]:
                                    data_frame[col] = data_frame[col].map(
                                        lambda x: (
                                            "" if pd.isnull(x)
                                            else f"{int(x)}" if float(x).is_integer()
                                            else f"{x:.2f}"
                                        )
                                    )
                    except Exception as e:
                        logging.info(f"### export_to_s3 columns fomrat change exception : {e}")
                else:


                    if module_name not in ('Automation rule Export', 'Automation rule log Export', 'Feature Codes', 'Rate Plan Socs Export','Centralized Bulk Change View'):

                        # Decide the tenant_id condition string with alias if needed
                        tenant_condition = f"tenant_id = {tenant_id}"
                        if module_name == 'Customer Rate Pool':
                            tenant_condition = f"crp.tenant_id = {tenant_id}"

                        # Check if tenant_id condition already exists (with or without alias)
                        if re.search(r'\b(?:\w+\.)?tenant_id\s*=', query) is None:
                            # tenant_id condition NOT present - insert it
                            if re.search(r'\bWHERE\b', query, flags=re.IGNORECASE):
                                # Insert after WHERE clause with AND
                                # Use regex to safely insert after the WHERE keyword
                                query = re.sub(
                                    r'(\bWHERE\b)',
                                    r'\1 ' + tenant_condition + ' AND ',
                                    query,
                                    flags=re.IGNORECASE
                                )
                            else:
                                # No WHERE clause, add one with tenant condition
                                query = query.strip()
                                if query.endswith(';'):
                                    query = query[:-1]  # Remove trailing semicolon to append WHERE safely
                                query += f" WHERE {tenant_condition}"

                    data_frame = database.execute_query(query, True)

            if data_frame.empty:
                db.update_dict(
                    "export_status",
                    {"status_flag": "No Data Found for export", "url": ""},
                    {"module_name": module_name},
                )
                return {"flag": False, "message": "No data found for export_4."}

            # data_frame.columns = [
            #     # col.replace("_", " ").capitalize() for col in data_frame.columns
            #     # " ".join(word.capitalize() for word in col.split("_")) for col in data_frame.columns
            #     # " ".join(word if word.isupper() else word.capitalize() for word in col.split("_")) for col in data_frame.columns
            #     [format_header(col) for col in data_frame.columns]
            # ]
            acronyms = {
                "SMS",
                "IMEI",
                "IP",
                "BAN",
                "URL",
                "UID",
                "MAC",
                "EID",
                "MSISDN",
                "MB",
                "CCID",
                "ICCID",
                "MSISDN",
                "IP",
                "SIM",
            }

            # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
            special_replacements = {"Att": "AT&T", "And": "and"}
            # Format column names
            data_frame.columns = [
                " ".join(
                    part.upper() if part.upper() in acronyms else part.capitalize()
                    for part in col.split("_")
                )
                for col in data_frame.columns
            ]

            # Apply special replacements (Att -> AT&T, And -> and)
            data_frame.columns = [
                " ".join(
                    [special_replacements.get(word, word) for word in col.split(" ")]
                )
                for col in data_frame.columns
            ]
            # Remove columns if role is not Super Admin
            if role not in ("Super Admin", "Partner Admin"):
                columns_to_remove = [
                    "Carrier Rate Plan",
                    "Communication Plan",
                    "Carrire Data Allocation MB",
                    "Carrier Rate Plan Cost"
                ]
                data_frame = data_frame.drop(columns=columns_to_remove, errors='ignore')

            data_frame = data_frame.rename(columns={"Soc Code": "SOC","Product Id":"Product ID"})
            # Ensure column order is preserved
            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                data_frame.to_excel(writer, index=False, sheet_name="Sheet1")

                # Get the workbook and the sheet
                workbook = writer.book
                sheet = workbook["Sheet1"]

                # Apply styles to the header row
                header_font = Font(bold=True)  # Define a bold font for the headers
                for cell in sheet[1]:
                    cell.alignment = Alignment(
                        horizontal="center", vertical="center"
                    )  # Center align
                    cell.fill = PatternFill(
                        start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                    )  # Grey background
                    cell.font = header_font
                # Adjust column widths based on content
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    col_letter = get_column_letter(col_idx)
                    header_value = col_cells[0].value
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    if header_value in ["Provider","Rate Plan Code","Automation Rule","Package"]:
                        sheet.column_dimensions[col_letter].width = 40  # Fixed width
                        for cell in col_cells[1:]:  # Skip header
                            cell.alignment = Alignment(wrap_text=True, vertical="top")
                    elif header_value in ["SOC", "SOC Code"]:
                        sheet.column_dimensions[col_letter].width = 20  # Fixed width
                        for cell in col_cells[1:]:  # Skip header
                            cell.alignment = Alignment(wrap_text=True, vertical="top")
                    else:
                        sheet.column_dimensions[col_letter].width = max_length + 2
                    # max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    # sheet.column_dimensions[get_column_letter(col_idx)].width = (
                    #     max_length + 2
                    # )

            excel_buffer.seek(0)

            s3_client = boto3.client("s3")
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=file_name,
                Body=excel_buffer.getvalue(),
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )

        db.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": module_name},
        )
        try:
            audit_data_user_actions = {
                "service_name": "export_to_s3_bucket",
                "created_by": data.get("username", ""),
                "status": "True",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": f"file exported to s3 bucket - {module_name}",
                "request_received_at": data.get("request_received_at", ""),
                 
            }
            db.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception is :  {e}")
        return {"flag": True, "download_url": download_url}
    except Exception as e:
        logging.exception(f"### An error occurred: {e}")
        message = "file failed to export to s3 bucket"
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name}
        )
        db.log_error_to_db(
            {
                "service_name": "Module Management",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message ,
                "module_name": "export",
                "request_received_at": request_received_at ,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error: {str(e)}"}




def get_export_status(data):
    """
    Retrieves the export status of a report module for a given tenant.

    Args:
        data (dict): A dictionary containing:
            - module_name (str): Name of the module whose export status is requested.
            - tenant_name (str): Name of the tenant.
            - username (str): User performing the request.
            - sessionID (str): Session identifier.
            - Partner (str): Partner or tenant name for audit logging.
            - request_received_at (str): Timestamp when the request was received.

    Returns:
        dict: A dictionary with:
            - flag (bool): True if export status was successfully fetched, False otherwise.
            - export_status_data (dict or list): Export status record if successful, or an empty list on failure.
    """
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        module_name = data.get("module_name")
        tenant_name = data.get("tenant_name")

        #find the billing platform flag
        if tenant_name == "Altaworx Test":
            tenant_name = 'Altaworx'
        tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id","billing_platform_flag"])
        billing_platform_flag = tenant_data["billing_platform_flag"].to_list()[0]
        if module_name in ("Active Customer Rate Plan","Customer Rate Plan") and billing_platform_flag:
            module_name = module_name + " Billing Platform"
            
        export_status_query = (
            f"select * from export_status where module_name='{module_name}'"
        )
        export_status_data = common_utils_database.execute_query(
            export_status_query, True
        ).to_dict(orient="records")
        try:
            audit_data_user_actions = {
                "service_name": "get_export_status",
                "created_by": data.get("username", ""),
                "status": "True",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": f"get export status of report - {module_name}",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        return {"flag": True, "export_status_data": export_status_data[0]}
    except Exception as e:
        logging.exception(f"### Exception occurred while getting the  export status of report : {e}")
        message = 'failed to get the export status of report'
        common_utils_database.log_error_to_db(
            {
                "service_name": "Module Management",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "export",
                "request_received_at": data.get("request_received_at", ""),
            },
            "error_log_table",
        )
        return {"flag": False, "export_status_data": []}


def reports_dropdown_data_export(data):
    """
    Prepares dropdown data for report export modules based on tenant and module context.

    Args:
        data (dict): Input dictionary containing:
            - username (str): Name of the user performing the request.
            - module (str): Name of the report module.
            - db_name (str): Target tenant database name.
            - tenant_name (str): Name of the tenant.
            - is_size_exceeded (bool): If True, upload output to S3 instead of returning inline.
            - Partner (str): Partner name for audit logging.

    Returns:
        dict: A response dictionary containing:
            - flag (bool): True if data fetched or uploaded successfully.
            - unique_service_providers (list): List of unique service providers or customer names.
            - billing_period_dates (dict): Mapping of provider/customer to list of billing end dates.
            - cross_provider (bool): True if cross-provider optimization is enabled.

            # Optional keys if is_size_exceeded is True:
            - s3_path (str): URL to download the exported dropdown data from S3.
    """
    # request_received_at = data.get("request_received_at", "")
    # session_id = data.get("session_id", "")
    # username = data.get("username", "")
    module_name = data.get("module", "")
    tenant_database = data.get("db_name", "")
    tenant_name = data.get("tenant_name", "")
    # call_flag=False
    # database Connection
    try : 
        database = DB(database=tenant_database, **db_config)
        dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        is_size_exceeded = data.get("is_size_exceeded",False)

        if tenant_name == "Altaworx Test":
            tenant_name='Altaworx'

        tenant_details = dbs.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id","parent_tenant_id"]
        )
        tenant_id = tenant_details["id"].to_list()[0]
        parent_tenant_id = tenant_details["parent_tenant_id"].to_list()[0]
        if tenant_id:
            tenant_id=int(tenant_id)
        try:
            if parent_tenant_id:
                query = f"SELECT optino_cross_providercustomer_optimization FROM optimization_setting_tenant_override WHERE tenant_id = {tenant_id}"
                cross_carrier_optimization = database.execute_query(query, True)
                if not cross_carrier_optimization.empty:
                    p = cross_carrier_optimization["optino_cross_providercustomer_optimization"].to_list()[0]
                else:
                    p = False
            else:
            # Attempt to retrieve the value from the 'tenant' table
                p = database.get_data(
                    "optimization_setting",
                    {"tenant_id": tenant_id},
                    ["optino_cross_providercustomer_optimization"],
                )["optino_cross_providercustomer_optimization"].to_list()[0]
        except Exception as e:
            logging.exception(f"### Failed to get the cross_carrier_optimization : {e}")
            p = False

        # p = database.get_data("optimization_setting",{"tenant_id":tenant_id},["optino_cross_providercustomer_optimization"],).iloc[0, 0]
        dbs.update_dict(
            "export_status",
            {"status_flag": "Waiting", "url": ""},
            {"module_name": module_name},
        )
        if module_name == 'Usage By Line Report':

            if not p:

                billing_period_query = """
                            SELECT service_provider, billing_cycle_end_date
                            FROM billing_period
                            WHERE is_active = 'true'
                            ORDER BY
                                CASE
                                    WHEN CURRENT_DATE BETWEEN billing_cycle_start_date
                                    AND billing_cycle_end_date THEN 0
                                    ELSE 1
                                END,
                                billing_cycle_end_date DESC
                        """
                billing_period_dates = database.execute_query(billing_period_query, True)
                billing_period_dates["billing_cycle_end_date"] = pd.to_datetime(
                billing_period_dates["billing_cycle_end_date"], errors="coerce"
                    )

                # Remove NaT (null) values before processing
                billing_period_dates = billing_period_dates.dropna(subset=["billing_cycle_end_date"])

                # Format valid dates
                billing_period_dates["billing_cycle_end_date"] = billing_period_dates["billing_cycle_end_date"].dt.strftime("%m-%d-%Y %H:%M:%S")
                billing_period_dates = billing_period_dates.to_dict(orient="records")
                # Extract only the service_provider values
                service_providers = [row["service_provider"] for row in billing_period_dates]

                # Create a dictionary where the key is service_provider and
                # the value is a list of billing_cycle_end_dates
                service_provider_dict = {}

                for row in billing_period_dates:
                    if row["service_provider"] in service_provider_dict:
                        service_provider_dict[row["service_provider"]].append(
                            row["billing_cycle_end_date"]
                        )
                    else:
                        service_provider_dict[row["service_provider"]] = [
                            row["billing_cycle_end_date"]
                        ]

                # Optionally, remove duplicates
                unique_service_providers = sorted(list(set(service_providers)))

                # Add "All" to the list of unique service providers
                unique_service_providers.insert(0, "All service providers")
            else:
                view_query = f"""
                    SELECT customer_id, customer_name, billing_period_ids, billing_cycle_end_date
                    FROM vw_cross_provider_usage_by_line_report_for_customer where tenant_id = {tenant_id}
                    AND is_active = true AND is_deleted = false
                """
                billing_data = database.execute_query(view_query, True)

                # Convert to your dictionary structure
                service_provider_dict = {}
                unique_service_providers = []

                for _, row in billing_data.iterrows():
                    customer_id = str(row['customer_id'])
                    customer_name = row['customer_name']
                    customer_key = f"{customer_name}-{customer_id}"

                    # Get the sets from the row
                    billing_period_ids = row['billing_period_ids']  # This is a set
                    billing_dates = row['billing_cycle_end_date']   # This is a set

                    # Create a dictionary to store the date-to-period mapping
                    date_period_map = {}

                    # Convert billing_dates to list of (date_obj, date_str) tuples for sorting
                    date_objects = []
                    for date_str in billing_dates:
                        try:
                            date_obj = datetime.datetime.strptime(date_str, "%m-%d-%Y %H:%M:%S")
                            date_objects.append((date_obj, date_str))
                        except (ValueError, TypeError):
                            # Skip invalid dates
                            continue

                    # Sort dates in descending order
                    date_objects.sort(reverse=True)
                    sorted_dates = [date_str for _, date_str in date_objects]

                    # Sort period IDs in ascending order (assuming newer dates get larger IDs)
                    sorted_period_ids = sorted(billing_period_ids)

                    # Match sorted dates with period IDs
                    # Using the business rule you mentioned (04-01-2025 → 80)
                    # I'm assuming the most recent date gets the highest period ID
                    if sorted_dates and sorted_period_ids and len(sorted_dates) == len(sorted_period_ids):
                        for i in range(len(sorted_dates)):
                            date_period_map[sorted_dates[i]] = sorted_period_ids[len(sorted_period_ids) - i - 1]

                    # Store the mapping in the service_provider_dict
                    service_provider_dict[customer_key] = date_period_map

                    # Add to unique customers list
                    unique_service_providers.append(customer_key)

                # Sort unique customer names
                unique_service_providers.sort()

                # Add "All Customers" at the beginning
                unique_service_providers.insert(0, "All Customers")

        else:
            billing_period_query = """
                            SELECT service_provider, billing_cycle_end_date
                            FROM billing_period
                            WHERE is_active = 'true'
                            ORDER BY
                                CASE
                                    WHEN CURRENT_DATE BETWEEN billing_cycle_start_date
                                    AND billing_cycle_end_date THEN 0
                                    ELSE 1
                                END,
                                billing_cycle_end_date DESC
                        """
            billing_period_dates = database.execute_query(billing_period_query, True)
            billing_period_dates["billing_cycle_end_date"] = pd.to_datetime(
            billing_period_dates["billing_cycle_end_date"], errors="coerce"
                )

            # Remove NaT (null) values before processing
            billing_period_dates = billing_period_dates.dropna(subset=["billing_cycle_end_date"])

            # Format valid dates
            billing_period_dates["billing_cycle_end_date"] = billing_period_dates["billing_cycle_end_date"].dt.strftime("%m-%d-%Y %H:%M:%S")
            billing_period_dates = billing_period_dates.to_dict(orient="records")
            # Extract only the service_provider values
            service_providers = [row["service_provider"] for row in billing_period_dates]

            # Create a dictionary where the key is service_provider and
            # the value is a list of billing_cycle_end_dates
            service_provider_dict = {}

            for row in billing_period_dates:
                if row["service_provider"] in service_provider_dict:
                    service_provider_dict[row["service_provider"]].append(
                        row["billing_cycle_end_date"]
                    )
                else:
                    service_provider_dict[row["service_provider"]] = [
                        row["billing_cycle_end_date"]
                    ]

            # Optionally, remove duplicates
            unique_service_providers = sorted(list(set(service_providers)))

            if module_name != "Status History Report":

                # Add "All" to the list of unique service providers
                unique_service_providers.insert(0, "All service providers")
        try:
            audit_data_user_actions = {
                "service_name": "reports_dropdown_data_export",
                "created_by": data.get("username", ""),
                "status": 'True',
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": f"dropdown data exported of report - {module_name}",
                "request_received_at": data.get("request_received_at", ""),
            }
            dbs.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")

        response =  {
            "flag": True,
            "unique_service_providers": unique_service_providers,
            "billing_period_dates": service_provider_dict,
            "cross_provider": p
        }
        
        if is_size_exceeded:
            payload = {
                "unique_service_providers": unique_service_providers,
                "billing_period_dates": service_provider_dict,
                "cross_provider": p
            }
            S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME", " ")
            file_name = f"report_dropdown_data_export/{module_name}.json"
            download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"
            try:
                s3_client.put_object(
                    Bucket=S3_BUCKET_NAME,
                    Key=file_name,
                    Body=json.dumps(payload),
                    ContentType='application/json'
                )
                logging.info(
                    f"### File successfully uploaded to {S3_BUCKET_NAME}/{file_name}"
                )
                response =  {
                    "flag": True,
                    "s3_path":download_url,
                    "cross_provider": p,
                }
                dbs.update_dict(
                    "export_status",
                    {"status_flag": "Success", "url": download_url},
                    {"module_name": module_name},
                )
            except Exception as e:
                logging.exception(f"### Failed to upload file : {e}")

        return response
    

    except Exception as e:
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error in reports dropdown data export : {e}")
        message = "Something went wrong while fetching reports dropdown data export"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "reports_dropdown_data_export",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            dbs.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            
        response = {
            "flag": False,
            "unique_service_providers": [],
            "billing_period_dates": {},
            "cross_provider": False,
            "message": "Something went wrong while fetching reports dropdown data export",
            "error": str(e)  # Optional: include only in non-production
        }
        return response      


def reports_data_with_date_filter(data):
    """
    Retrieves filtered report data based on module name, tenant, and date range.

    Args:
        data (dict): Input dictionary containing:
            - module_name (str): The name of the report module.
            - username (str): Username of the requester.
            - Partner (str): Tenant's partner name (used in audit logging).
            - tenant_name (str): Tenant name.
            - db_name (str): Database name for the tenant.
            - mod_pages (dict): Pagination settings, typically {"start": int}.
            - role_name (str): User role (used in column filtering).
            - col_sort (dict): Optional sorting key-value pair, e.g., {"column_name": "asc"}.

    Returns:
        dict: A response object with the following structure:
            - flag (bool): True if the report was generated successfully.
            - message (str): Status or error message.
            - headers_map (dict): Mapped headers based on module and user role.
            - data (list): A list of dictionaries representing the report records.

        If an error occurs:
            - flag (bool): False
            - message (str): Error message
    """
    # Start time  and date calculation
    start_time = time.time()
    module_name = data.get("module_name", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", None)
    Partner = data.get("Partner", "")
    tenant_name = data.get("tenant_name", "")
    mod_pages = data.get("mod_pages", {})
    logging.info(f"### mod_pages : {mod_pages}")
    limit = 100
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    offset = mod_pages.get("start", 0)
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    role_name = data.get("role_name", "")
    col_sort = data.get("col_sort", "")
    ##Database connection
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]
    return_json_data = {}
    logging.info(
        f"### Report request for module: {module_name}, Username: {username}, Partner: {Partner}"
    )
    try:
        # Fetch the query from the database based on the module name
        module_query_df = common_utils_database.get_data(
            "export_queries", {"module_name": module_name}
        )
        ### checking the dataframe is empty or not
        if module_query_df.empty:
            return {
                "flag": False,
                "message": f"No query found for module name: {module_name}",
            }
        # Extract the query string from the DataFrame
        query = module_query_df.iloc[0]["module_query"]
        if not query:
            logging.warning(f"### No query defined for module name: {module_name}")
            return {"flag": False, "message": f"Unknown  module name: {module_name}"}
        start_date = start_date + " 00:00:00"
        end_date = end_date + " 23:59:59"
        params = [tenant_id, start_date, end_date, limit, offset]
        if module_name == "Daily usage report":
            # fetch all billing cycle end dates between start_date and end_date
            billing_cycle_query = """
                    SELECT DISTINCT billing_cycle_end_date
                    from vw_daily_usage_report WHERE billing_cycle_end_date is not null AND tenant_id = %s
                """
            billing_cycle_dates = database.execute_query(billing_cycle_query, params=[tenant_id])
            if not billing_cycle_dates.empty:
                billing_cycle_dates = billing_cycle_dates['billing_cycle_end_date'].tolist()
                # remove null values
                billing_cycle_dates = [date for date in billing_cycle_dates if date is not None]
                logging.info(f"### billing_cycle_dates - {billing_cycle_dates}")
                billing_periods = []
                for date in billing_cycle_dates:
                    cycle_start = date - pd.DateOffset(months=1) + datetime.timedelta(days=1)
                    cycle_end = date
                    billing_periods.append((cycle_start, cycle_end))
                logging.info(f"### billing_periods - {billing_periods}")

                start_date = pd.to_datetime(start_date)
                end_date = pd.to_datetime(end_date)


                # Check overlap with billing periods
                matching_ends = []
                for cycle_start, cycle_end in billing_periods:
                    # Check overlap
                    if cycle_end >= start_date and cycle_start <= end_date:
                        matching_ends.append(cycle_end)

                if matching_ends:
                    placeholders = ', '.join(['%s'] * len(matching_ends))
                    query = re.split(r"WHERE", query,flags=re.IGNORECASE)[0].strip()
                    query += f""" where  billing_cycle_end_date IN ({placeholders}) """
                    # Combine all parameters: service_provider, billing_dates..., tenant_id
                    params = matching_ends
                    query = modify_query(query,tenant_id)
                    # set limit and offset to query
                    query += " LIMIT %s OFFSET %s"
                    params.extend([limit, offset])
        ##executing the query

        if col_sort:
            # Remove existing ORDER BY clause
            order_by_pattern = r"\sORDER\s+BY\s+[^)]+(?=\s*LIMIT)"
            query = re.sub(order_by_pattern, "", query, flags=re.IGNORECASE)

            # Extract the single key-value pair
            key, value = list(col_sort.items())[0]

            # Ensure ORDER BY comes before LIMIT and OFFSET
            limit_offset_match = re.search(
                r"(LIMIT\s+%s\s+OFFSET\s+%s)", query, re.IGNORECASE
            )

            if limit_offset_match:
                # Replace LIMIT and OFFSET with ORDER BY correctly placed
                limit_offset_clause = limit_offset_match.group(1)
                query = query.replace(
                    limit_offset_clause,
                    f"ORDER BY {key} {value.upper()} {limit_offset_clause}",
                )
            else:
                # Append ORDER BY at the end if no LIMIT and OFFSET found
                query += f" ORDER BY {key} {value.upper()}"

        df = database.execute_query(query, params=params)
        # Convert dataframe to dictionary
        df_dict = df.to_dict(orient="records")
        for record in df_dict:
            for key, value in record.items():
                if isinstance(value, pd.Timestamp):
                    record[key] = value.strftime("%m-%d-%Y %H:%M:%S")
        headers_map = get_headers_mapping(
            tenant_database,
            [module_name],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )
        logging.info("### Report written Successfully")
        return_json_data.update(
            {
                "message": "Successfully generated the report",
                "flag": True,
                "headers_map": headers_map,
                "data": df_dict,
            }
        )
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "reports_data_with_date_filter",
                "created_by": username,
                "status": str(return_json_data["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f"Reports data with date filter - {module_name}",
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
            logging.info("### Audit log recorded successfully")
        except Exception as e:
            logging.exception(f"### exception is : {e}")
        return return_json_data
    except Exception as e:
        logging.exception(f"### An error occurred: {e}")
        message = "### Unable to fetch the reports data"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "reports_data_with_date_filter",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
            logging.info("### Error details logged successfully")
        except Exception as e:
            logging.exception(f"### exception is : {e}")
        return response



def get_optimization_setting_details(data):
    """
    Retrieves optimization setting details for a given tenant.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): Tenant-specific database name.
            - username (str): User making the request.
            - module_name (str): The module name (not directly used here).
            - Partner (str): Partner name (used in auditing).
            - tenant_name (str): Tenant display name, e.g., 'Altaworx Test'.

    Returns:
        dict: A response dictionary containing:
            - flag (bool): True if retrieval succeeded.
            - optimization_setting_data (list): List of dictionaries with optimization setting values.

        In case of exceptions, logs errors but still attempts to return a valid response.
    """
    logging.info(f"### get_optimization_setting_details Request Recieved : {data}")
    # Record the start time for performance measurement
    start_time = time.time()
    session_id = data.get("session_id")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    module_name = data.get("module_name", "")
    partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    try:
        # database Connection
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error(f"### Failed to connect to the database: {str(db_exception)}")

    try :     
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
        tenant_details = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id","parent_tenant_id"]
        )
        tenant_id = tenant_details["id"].to_list()[0]
        parent_tenant_id = tenant_details["parent_tenant_id"].to_list()[0]
        logging.info(f"### parent_tenant_id_sub : {parent_tenant_id}")
        if parent_tenant_id:
            try:
                query = f"SELECT tenant_id FROM optimization_setting_tenant_override WHERE tenant_id = {tenant_id}"
                optimization_setting_dataframe = database.execute_query(query, True)
                logging.info(f"### optimization_setting_dataframe_sub : {optimization_setting_dataframe}")
                # insert record optimization_setting_tenant_override if empty
                if optimization_setting_dataframe.empty:
                    insert_new_record = {
                        "tenant_id": tenant_id,
                        "optino_cross_providercustomer_optimization": False,
                        "setting_value": 0,
                        "created_by": username,
                    }
                    database.insert_dict(
                        insert_new_record, "optimization_setting_tenant_override"
                    )
                query = f"SELECT optino_cross_providercustomer_optimization FROM optimization_setting_tenant_override WHERE tenant_id = {tenant_id}"
                optimization_setting_dataframe = database.execute_query(query, True)
                logging.info(f"### optimization_setting_dataframe_sub : {optimization_setting_dataframe}")
            except Exception as e:
                logging.info(f"### optimization_setting_tenant_override Exception is {e}")
        else:
            optimization_setting_dataframe = database.get_data(
                "optimization_setting", {"tenant_id": tenant_id}
            )
            logging.info(f"### optimization_setting_dataframe_main columns : {optimization_setting_dataframe.columns}")

        optimization_setting_dataframe = optimization_setting_dataframe.astype("str")
        optimization_setting_data = optimization_setting_dataframe.to_dict(orient="records")
        response = {"flag": True, "optimization_setting_data": optimization_setting_data}
        try:
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "get_optimization_setting_details",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": partner,
                "module_name": "Module_management",
                "comments": f"successfully fetched optimization setting details of given {partner} module {module_name}",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
        return response
    
    except Exception as e:
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error in getting optimization setting details data : {e}")
        message = "Something went wrong while getting optimization setting details data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_optimization_setting_details",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 

        response = {"flag": False, "optimization_setting_data": []}

        return response


def update_optimization_setting_details(data):
    """
    Updates optimization settings for a tenant or parent tenant.

    This function handles updating the `optimization_setting` or
    `optimization_setting_tenant_override` table based on the presence
    of a parent tenant. It updates the relevant fields such as
    `optino_cross_providercustomer_optimization` and audit logs.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): Target tenant database name.
            - tenant_name (str): Name of the tenant.
            - changed_data (dict): Dictionary containing the changed fields and values.
            - username (str): Name of the user performing the update.
            - Partner (str, optional): Partner name (used in logging and auditing).

    Returns:
        dict: A dictionary with:
            - flag (bool): True if the update was successful, False otherwise.
            - message (str, optional): Success or failure message.
            - optimization_setting_data (dict, optional): Returned only if parent_tenant_id exists and update is successful.
    """
    logging.info(f"### update_optimization_setting_details Request Recieved : {data}")
    # Database connection
    # Extract database name and validate
    tenant_database = data.get("db_name", "")
    tenant_name = data.get("tenant_name", "")
    if not tenant_database:
        logging.warning("### update_optimization_setting_details Database name is missing in the request data")
    try:
        # Establishing the database connection
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        logging.info("### update_optimization_setting_details Connected to the database")
    except Exception as db_exception:
        logging.error(f"### update_optimization_setting_details Failed to connect to the database : {db_exception}")
        return {"flag": False, "message": "Database connection failed."}
    changed_data = data.get("changed_data", "")
    tenant_details = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id","parent_tenant_id"]
    )
    tenant_id = tenant_details["id"].to_list()[0]
    parent_tenant_id = tenant_details["parent_tenant_id"].to_list()[0]
    logging.info(f"### update_optimization_setting_details parent_tenant_id_sub : {parent_tenant_id}")

    if parent_tenant_id:
        optino_cross_providercustomer_optimization = changed_data.get("optino_cross_providercustomer_optimization", None)
        logging.info(f"### update_optimization_setting_details optino_cross_providercustomer_optimization : {optino_cross_providercustomer_optimization}")
        if optino_cross_providercustomer_optimization.lower() == "true":
            optino_cross_providercustomer_optimization = True
        else :
            optino_cross_providercustomer_optimization = False
        logging.info(f"### update_optimization_setting_details optino_cross_providercustomer_optimization_sub : {optino_cross_providercustomer_optimization} - type : {type(optino_cross_providercustomer_optimization)}")
        try:
            update_changed_data = {
                "optino_cross_providercustomer_optimization": optino_cross_providercustomer_optimization,
                "modified_by": data.get("username", ""),
                "modified_date": data.get("request_received_at", ""),

            }
            database.update_dict(
                "optimization_setting_tenant_override",
                update_changed_data,
                {"tenant_id": tenant_id}
            )
            optimization_setting_data = {"optino_cross_providercustomer_optimization": optino_cross_providercustomer_optimization}
            response = {"flag": True, "optimization_setting_data": optimization_setting_data}
            return response
        except Exception as e:
            logging.info(f"### update_optimization_setting_details optimization_setting_tenant_override Exception is {e}")
            return {"flag": False, "message": f"Failed to Update!!! - {str(e)}"}
    else:
        list_view_id = changed_data.get("id")
        logging.info(f"###update_optimization_setting_details  List view Id is :{list_view_id}")
        try:
            # Ensure 'id' is removed, but the rest of the data remains as a dictionary
            if "id" in changed_data:
                changed_data.pop("id")
            changed_data.pop("id_10")
            database.update_dict("optimization_setting", changed_data, {"id": list_view_id})
            try:
                audit_data_user_actions = {
                    "service_name": "update_optimization_setting_details",
                    "created_by": data.get("username", ""),
                    "status": "True",
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": data.get("Partner", ""),
                    "module_name": "Module Management",
                    "comments": json.dumps(update_changed_data),
                    "request_received_at": data.get("request_received_at", ""),
                }
                common_utils_database.update_audit(
                    audit_data_user_actions, "audit_user_actions"
                )
            except Exception as e:
                logging.warning(f"### update_optimization_setting_details Exception is : {e}")
            return {"flag": True, "message": "Updated Successfully"}
        except Exception as e:
            logging.exception(f"### update_optimization_setting_details Exception occurred while updating the optimization setting details:  {e}")
            message = "failed while updating the optimization setting details "
            common_utils_database.log_error_to_db(
                {
                    "service_name": "update_optimization_setting_details",
                    "error_message": str(e),
                    "error_type": type(e).__name__,
                    "users": data.get("username", ""),
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": data.get("Partner", ""),
                    "comments": message ,
                    "module_name": "Module Management",
                    "request_received_at": data.get("request_received_at", ""),
                },
                "error_log_table",
            )
            return {"flag": False, "message": "Failed to Update!!!"}


def get_integration_data(data):
    """
    Fetch integration connection and authentication status details for a tenant.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): Name of the tenant database.
            - tenant_name (str): Name of the tenant.
            - username (str, optional): Name of the user (for audit logs).
            - Partner (str, optional): Partner name (for audit logs).

    Returns:
        dict: A dictionary with:
            - connections (list): List of dictionaries each containing:
                - label (str): Integration or service provider name.
                - authenticated (bool): True if valid authentication exists, False otherwise.
                - integration_id (int): ID of the integration.
                - authentication_type (str): Type of authentication required.
            - intergation_details (list): List of integration authentication configurations with settings.
        If an exception occurs, returns a dict with:
            - flag (bool): True (but indicates failure).
            - message (str): Error message.
    """
    tenant_database = data.get("db_name", "altaworx_central")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    database = DB(tenant_database, **db_config)
    tenant_name = data.get("tenant_name", "")
    result_dict = {}

    try:

        if tenant_name == "Altaworx Test":
            tenant_id = [1]  # Include the hardcoded ID
            # Fetch the ID from the database as well
            db_tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()
            tenant_id.extend(db_tenant_id)  # Combine both IDs
        else:
            # Default case: fetch only from the database
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()
        tenant_id = list(tenant_id)

        # Get integration and integration_connection data from common database
        integration_query = """
            SELECT
                IC.id AS ic_id,
                IC.integration_id,
                I.id AS i_id,
                I.name AS i_name,
                I.authentication_type,
                I.has_service_provider
            FROM integration_connection IC
            LEFT JOIN integration I on I.id = IC.integration_id
            WHERE IC.is_deleted = false
        """

        # Get service provider data from altaworx database
        service_provider_query = f"""
            SELECT
                id AS s_id,
                tenant_id AS s_tenant_id,
                integration_id AS s_integration_id,
                service_provider_name AS s_name
            FROM serviceprovider
            WHERE is_deleted = false
            and tenant_id in ({','.join(map(str, tenant_id))})
        """

        # Get data from common database
        integration_data = database.execute_query(
            integration_query, True
        ).to_dict(orient="records")

        # Get service provider data from altaworx database
        service_providers = database.execute_query(
            service_provider_query, True
        ).to_dict(orient="records")

        # Create a dictionary of service providers keyed by integration_id
        sp_by_integration = {}
        for sp in service_providers:
            if sp["s_integration_id"] not in sp_by_integration:
                sp_by_integration[sp["s_integration_id"]] = []
            sp_by_integration[sp["s_integration_id"]].append(sp)

        # Combine the data
        all_records = []

        for record in integration_data:
            # Check for service providers related to this integration
            sps = sp_by_integration.get(record["integration_id"], [])

            if sps:
                # If there are service providers, add a record for each one
                for sp in sps:
                    combined_record = {**record}
                    combined_record.update(sp)
                    all_records.append(combined_record)
            else:
                # If no service providers, add the record with has_service_provider = False
                if not record["has_service_provider"]:
                    combined_record = {**record}
                    combined_record.update(
                        {
                            "s_id": None,
                            "s_tenant_id": None,
                            "s_integration_id": None,
                            "s_name": None,
                        }
                    )
                    all_records.append(combined_record)


        result = []
        LABELS_TO_EXCLUDE = {
                "Qualification",
                "NetSapiens",
                "Intrado E911",
                "CyberReef",
                "CereTax"
            }

        for record in all_records:
            authentication_type = record.get("authentication_type")
            if record.get("s_id") and record["s_tenant_id"]:
                query_integration_authentication = f"""
                    SELECT * FROM integration_authentication
                    WHERE integration_id = {record['i_id']}
                    AND tenant_id in ({','.join(map(str, tenant_id))})
                    AND is_active = TRUE
                    AND service_provider_id = {record['s_id']}
                """
            else:
                query_integration_authentication = f"""
                    SELECT * FROM integration_authentication
                    WHERE integration_id = {record['i_id']}
                    AND is_active = TRUE and is_deleted = false
                """

            auth_results = database.execute_query(
                query_integration_authentication, True
            )

            if not auth_results.empty:
                auth_results = auth_results.to_dict(orient="records")
                authenticated = bool(auth_results and len(auth_results) > 0)
            else:
                authenticated = False

            label = record["s_name"] if record.get("s_name") else record["i_name"]

            if tenant_name == "Altaworx - Go Tech" and label in LABELS_TO_EXCLUDE:
                continue  # Skip this record

            result.append(
                {
                    "label": label,
                    "authenticated": authenticated,  # True if authentication results exist, otherwise False
                    "integration_id": record["integration_id"],
                    "authentication_type": authentication_type,
                }
            )

        intergation_details = """SELECT DISTINCT ON (ia.integration_id, ia.authentication_type)
            ia.integration_id,
            ia.authentication_type,
            ia.*,
            json_agg(
                json_build_object(
                    'setting_key', sps.setting_key,
                    'setting_value', sps.setting_value
                )
            ) AS settings
        FROM
            public.integration_authentication ia
        LEFT JOIN
            public.service_provider_setting sps
        ON
            ia.service_provider_id = sps.service_provider_id
        WHERE
            ia.is_active = TRUE
            AND (ia.service_provider_id IS NOT NULL OR ia.integration_id IS NOT NULL)
        GROUP BY
            ia.integration_id, ia.authentication_type, ia.id
        ORDER BY
            ia.integration_id, ia.authentication_type, ia.id;"""
        intergation_details = database.execute_query(intergation_details, True).to_dict(
            orient="records"
        )

        result_dict["intergation_details"] = intergation_details

        result = sorted(result, key=lambda x: x["label"])

        result_dict["connections"] = result

        try:
            audit_data_user_actions = {
                "service_name": "get_integration_data",
                "created_by": data.get("username", ""),
                "status": "True",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": "fetched integration data successfully",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception is : {e}")

        return serialize_data(result_dict)
    except Exception as e:
        logging.exception(f"### An error occurred while fetching integration data: {str(e)}")
        message = "failed while fetching integration data"
        common_utils_database.log_error_to_db(
            {
                "service_name": "get_integration_data" , 
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message,
                "module_name": "Module Management",
                "request_received_at": data.get("request_received_at", ""),
            },
            "error_log_table",
        )
        return {"flag": True, "message": message}





def save_integration_details(data):
    """
    Saves integration authentication details for various service providers and integration types.

    Args:
        data (dict): A dictionary containing:
            - tenant_name (str): Name of the tenant
            - db_name (str): Target database name
            - changed_data (dict): Integration configuration details including:
                - service_provider_id (int): ID of the service provider
                - integration_id (int): ID of the integration type
                - authentication_type (int): Authentication method ID
                - id (int): Record ID (for updates)
                - Various auth fields (username, password, tokens, etc.)
            - username (str): User performing the operation
            - sessionID (str): Session identifier
            - request_received_at (str): Timestamp of the request

    Returns:
        dict: A dictionary with:
            - flag (bool): True if operation succeeded, False otherwise
            - message (str): Status message
            - error (str, optional): Error details if operation failed

    Note:
        Handles special cases for providers like Telegence, Bandwidth, Kore, Verizon ThingSpace, etc.
        Performs live API validation for many integration types before saving to database.
    """

    tenant_name = data.get("tenant_name", "")
    """
    Save integration data filtered by service_provider_id, integration_id, and authentication_type.
    """
    tenant_database = data.get("db_name", "altaworx_test")
    try:

        # Validate input data
        if not isinstance(data, dict):
            return {
                "flag": False,
                "message": "Invalid data format. Expected a dictionary.",
            }
        changed_data = data.get("changed_data", {})
        if not isinstance(changed_data, dict):
            return {
                "flag": False,
                "message": "Invalid or missing 'changed_data'. Expected a dictionary.",
            }
        service_provider_id = changed_data.get("service_provider_id")
        integration_id = changed_data.get("integration_id")
        authentication_type = changed_data.get("authentication_type")
        record_id = changed_data.get(
            "id"
        )  # Use 'id' if service_provider_id is not provided

        if not (
            service_provider_id or (integration_id and authentication_type) or record_id
        ):
            return {
                "flag": False,
                "message": "Missing required fields: service_provider_id, integration_id, authentication_type, or id.",
            }

        # Define base where condition
        where_dict = {}
        if service_provider_id is not None:
            where_dict["service_provider_id"] = service_provider_id
        elif (
            record_id is not None
        ):  # Use 'id' for filtering if service_provider_id is not present
            where_dict["id"] = record_id
        else:
            where_dict.update(
                {
                    "integration_id": integration_id,
                    "authentication_type": authentication_type,
                }
            )

        # Prepare data for insertion based on conditions
        insert_data = {}
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'

        json_data = load_json()
        telegence_ids = get_provider_ids(json_data, tenant_name, ["Telegence"])
        bandwidthids = get_provider_ids(json_data, tenant_name, ["Bandwidth"])
        koreids = get_provider_ids(json_data, tenant_name, ["Koremain"])
        pond_iot_ids = get_provider_ids(json_data, tenant_name, ["POND IoT"])
        webbing_ids = get_provider_ids(json_data, tenant_name, ["Webbing"])
        verizon_thingspaceiot_ids = get_provider_ids(json_data, tenant_name, ["Verizon - ThingSpace IoT"])
        ciscojasper_ids = get_provider_ids(json_data, tenant_name, ["Cisco Jasper"])
        condition_ids = get_provider_ids(json_data, tenant_name, ["Teal","POND IoT"])
        condition2_ids = get_provider_ids(json_data, tenant_name, ["T-Mobile - Advantage","AT&T - POD19","T-Mobile","Rogers"])
        # Convert the comma-separated string into a list
        if service_provider_id in telegence_ids:
            insert_data = {
                "oauth2_client_id": changed_data.get("oauth2_client_id"),
                "oauth2_client_secret": changed_data.get("oauth2_client_secret"),
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
                "is_active":True,
            }
        elif service_provider_id in bandwidthids:
            insert_data = {
                "oauth2_custom1": changed_data.get("oauth2_custom1"),
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif service_provider_id in koreids:
            insert_data = {
                "oauth2_client_id": changed_data.get("oauth2_client_id"),
                "oauth2_client_secret": changed_data.get("oauth2_client_secret"),
                "token_value": changed_data.get("token_value"),
                "token_variable_name": changed_data.get("token_variable_name"),
            }
        elif service_provider_id in pond_iot_ids:
            insert_data = {
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
                "oauth2_custom1": changed_data.get("oauth2_custom1"),
                "oauth2_custom2": changed_data.get("oauth2_custom2"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif service_provider_id in verizon_thingspaceiot_ids:
            insert_data = {
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif authentication_type == 15 and integration_id == 14:
            insert_data = {"oauth2_custom1": changed_data.get("oauth2_custom1")}
        elif authentication_type in {13, 1} and integration_id == 3:
            insert_data = {
                "username": changed_data.get("username"),
                "rev_bill_profile": changed_data.get("rev_bill_profile"),
                "password": changed_data.get("password"),
                "token_value": changed_data.get("token_value"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
                "is_active": True,
                "is_deleted":False
            }

        elif service_provider_id in bandwidthids:
            insert_data = {
                "oauth2_client_id": changed_data.get("oauth2_client_id"),
                "oauth2_client_secret": changed_data.get("oauth2_client_secret"),
                "token_value": changed_data.get("token_value"),
                "token_variable_name": changed_data.get("token_variable_name"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif authentication_type == 16 and integration_id == 16:
            insert_data = {
                "realm_id": changed_data.get("realm_id"),
                "password": changed_data.get("password"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif authentication_type == 3 and integration_id == 17:
            insert_data = {
                "oauth2_custom1": changed_data.get("oauth2_custom1"),
                "oauth2_client_secret": changed_data.get("oauth2_client_secret"),
                "oauth2_client_id": changed_data.get("oauth2_client_id"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif authentication_type == 4 and integration_id == 5:
            insert_data = {
                "oauth2_custom2": changed_data.get("oauth2_custom2"),
                "oauth2_client_id": changed_data.get("oauth2_client_id"),
                "oauth2_client_secret": changed_data.get("oauth2_client_secret"),
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif service_provider_id in condition_ids:
            insert_data = {
                # "oauth2_client_id": changed_data.get("oauth2_client_id"),
                # "oauth2_client_secret": changed_data.get("oauth2_client_secret"),
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
                "is_active": True
            }
        elif service_provider_id in webbing_ids:
            insert_data = {
                "username": changed_data.get("oauth2_client_id"),
                "password": changed_data.get("oauth2_client_secret"),
                "token_value": changed_data.get("token_value"),
                "oauth2_custom1": changed_data.get("oauth2_custom1"),
                "oauth2_custom2": changed_data.get("oauth2_custom2"),
                "oauth2_custom3": changed_data.get("oauth2_custom3"),
                "oauth2_custom4": changed_data.get("oauth2_custom4")
            }
        elif service_provider_id in ciscojasper_ids:
            settings = changed_data.get("settings", [])
            if not isinstance(settings, list):
                return {"flag": False, "message": "Settings must be a list."}
            for idx, setting in enumerate(settings):
                setting_key = setting.get("setting_key")
                setting_value = setting.get("setting_value")
                if not setting_key or setting_value is None:
                    continue
                response = update_settings(
                    setting_key, setting_value, service_provider_id,tenant_database
                )
            return {
                "flag": True,
                "message": "Updated successfully for service_provider.",
            }

        elif service_provider_id in condition2_ids:
            settings = changed_data.get("settings", [])
            if not isinstance(settings, list):
                return {"flag": False, "message": "Settings must be a list."}
            for idx, setting in enumerate(settings):
                setting_key = setting.get("setting_key")
                setting_value = setting.get("setting_value")
                if not setting_key or setting_value is None:
                    continue
                response = update_settings(
                    setting_key, setting_value, service_provider_id,tenant_database
                )
            insert_data = {
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
            }

        # If no valid insert data, skip update
        if not insert_data:
            return {"flag": False, "message": "No valid data found to update."}
        # telegence_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "Telegence")
        # kore_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "Koremain")
        # testv2_ids = get_integration_id_by_unique_name(json_data, tenant_name, "testv2")
        # verizon_thingspaceiot_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "Verizon - ThingSpace IoT")
        # bandwidth_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "Bandwidth")
        # qatest_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "QA test")
        # teal_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "Teal")
        # pond_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "POND")
        telegence_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "Telegence")]
        kore_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "Koremain")]
        testv2_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "testv2")]
        verizon_thingspaceiot_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "Verizon - ThingSpace IoT")]
        bandwidth_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "Bandwidth")]
        # qatest_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "QA test")]
        teal_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "Teal")]
        pond_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "POND")]
        webbing_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "Webbing")]
        pond_19_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "AT&T - POD19")]

        if integration_id  in telegence_integration_ids:
            integration_id = integration_id
            # Dynamically construct the URL and headers
            api_url_base = changed_data.get(
                "oauth2_custom2"
            )  # base URL ( https://apsapi.att.com:8082)

            try:
                dbs = DB(data.get("db_name"), **db_config)
                api_endpoint_url = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["auth_test_url"],
                )["auth_test_url"].to_list()[0]

            except Exception as e:
                logging.exception(f"### Error updating api_endpoint_url: {e}", "save_integration_details")

            url = api_url_base + api_endpoint_url  # Construct the full URL


            # Extract headers from the changed data
            app_id = changed_data.get("oauth2_client_id")
            app_secret = changed_data.get("oauth2_client_secret")

            # Validate that necessary values are present
            if not app_id or not app_secret:
                return {
                    "flag": False,
                    "message": "Missing app_id or app_secret in changed_data.",
                }

            headers = {"app-id": app_id, "app-secret": app_secret}


            api_response = requests.get(url, headers=headers)
            logging.info(f"### api response {api_response}","save_integration_details")

        elif integration_id in kore_integration_ids:
            client_id = changed_data.get("oauth2_client_id")
            client_secret = changed_data.get("oauth2_client_secret")
            api_key = changed_data.get("token_value")
            email = changed_data.get("token_variable_name")
            integration_id = integration_id

            try:
                dbs = DB(data.get("db_name"), **db_config)
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["production_url"],
                )["production_url"].to_list()[0]

            except Exception as e:
                logging.exception(f"### Error updating api_endpoint_url: {e}","save_integration_details")

            production_url = endpoint_data
            api_endpoint_url = f"{production_url}/v1/accounts?email={email}"
            access_token = get_access_token(client_id, client_secret)

            url = api_endpoint_url

            headers = {
                "Accept": "application/json",
                "Authorization": f"Bearer {access_token}",
            }
            if api_key:
                api_key = api_key[0] if isinstance(api_key, tuple) else api_key
                headers["x-api-key"] = api_key

            api_response = requests.get(url, headers=headers)

        elif integration_id in webbing_integration_ids:
            username = changed_data.get("username")
            password = changed_data.get("password")
            token_value = changed_data.get("token_value")
            integration_id = integration_id

            try:
                dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["production_url"],
                )["production_url"].to_list()[0]

            except Exception as e:
                logging.exception(f"### Error updating api_endpoint_url: {e}","save_integration_details")

            production_url = endpoint_data
            api_endpoint_url = production_url
            soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Header>
                    <Credentials xmlns="http://wws.iamwebbing.com/">
                        <Username>{username}</Username>
                        <Password>{password}</Password>
                        <WSKey>{token_value}</WSKey>
                    </Credentials>
                </soap:Header>
                <soap:Body>
                    <GetAccount xmlns="http://wws.iamwebbing.com/">
                    <GetAccountRequest>
                        <AccountID>{int(1)}</AccountID>
                    </GetAccountRequest>
                    </GetAccount>
                </soap:Body>
                </soap:Envelope>"""

            url = "https://wws.iamwebbing.com/accounts/Accounts.asmx"

            headers = {
                "Content-Type": "text/xml; charset=utf-8",
                "SOAPAction": "http://wws.iamwebbing.com/GetAccount"
            }




            logging.info(f'### soap_body {soap_body}')
            logging.info(f'### headers {headers}')
            api_response = requests.post(url, data=soap_body, headers=headers)


        elif integration_id in testv2_ids:
            x_api_key = changed_data.get("oauth2_custom1")
            integration_id = integration_id

            try:
                dbs = DB(data.get("db_name"), **db_config)
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["sandbox_url", "auth_test_url"],
                )["sandbox_url", "auth_test_url"].to_list()[0]
            except Exception as e:
                logging.exception(f"### Error updating api_endpoint_url: {e}")

            sandbox_url_template = endpoint_data["sandbox_url"].to_list()[0]
            auth_test_url = endpoint_data["auth_test_url"].to_list()[0]
            sandbox_url = sandbox_url_template.format("calc")
            api_endpoint_url = f"{sandbox_url}{auth_test_url}"

            url = api_endpoint_url

            # Validate that necessary values are present
            if not x_api_key:
                return {
                    "flag": False,
                    "message": "Missing app_id or app_secret in changed_data.",
                }

            headers = {"Accept": "application/json", "x-api-key": x_api_key}

            api_response = requests.get(url, headers=headers)
        elif integration_id in verizon_thingspaceiot_integration_ids:
            integration_id = integration_id
            try:
                # Initialize the database connection
                dbs = DB(data.get("db_name"), **db_config)

                # Fetch production_url from the database
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["production_url"],
                )
            except Exception as e:
                logging.exception(f"### Error updating api_endpoint_url: {e}")
                endpoint_data = None
            # Endpoint and credentials for token
            # url = 'https://thingspace.verizon.com/api/ts/v1/oauth2/token?grant_type=client_credentials'
            baseurl = endpoint_data["production_url"].to_list()[0]

            # Define the additional path and query parameters
            auth_test_url = changed_data.get("oauth2_token_url")
            query_params = "?grant_type=client_credentials"

            # Combine base URL, auth URL, and query parameters
            url = f"{baseurl}{auth_test_url}{query_params}"
            clientid = changed_data.get("oauth2_client_id")
            # clientid = "RvxMbfpulNVNBU2FpSnBZ2QSai8a"
            clientsecret = changed_data.get("oauth2_client_secret")
            # clientsecret = "5Con_pshpyYfjZ1PMCuBePGS7fQa"

            username = changed_data.get("username")
            password = changed_data.get("password")

            # Combine client ID and secret
            credentials = f"{clientid}:{clientsecret}"

            # Encode credentials as base64
            encoded_credentials = base64.b64encode(credentials.encode()).decode()

            # Set headers for token request
            headers = {
                "Accept": "application/json",
                "Authorization": f"Basic {encoded_credentials}",
            }

            # Send POST request for token
            api_response_data = requests.post(url, headers=headers)

            logging.info(f"### Status Code: {api_response_data.status_code}")
            if api_response_data.status_code == 200:
                # Parse the JSON response
                response_data = api_response_data.json()
                baseurl = baseurl
                try:
                    # Initialize the database connection
                    dbs = DB(data.get("db_name"), **db_config)

                    # Fetch production_url from the database
                    endpoint_data = dbs.get_data(
                        "integration_connection",
                        {"integration_id": integration_id, "is_active": True},
                        ["production_url"],
                    )
                except Exception as e:
                    logging.exception(f"### Error updating api_endpoint_url: {e}")
                    endpoint_data = None

                auth_test_url = changed_data.get("oauth2_authorization_url")

                # Extract the access token
                access_token = response_data.get("access_token")

                if access_token:
                    url = f"{baseurl}{auth_test_url}"
                    # Use access token for login request
                    # url = "https://thingspace.verizon.com/api/m2m/v1/session/login"

                    # Set the Authorization header using Bearer token
                    headers = {
                        "Accept": "application/json",
                        "Authorization": f"Bearer {access_token}",  # Corrected authorization scheme
                    }

                    # Login body with username and password
                    body = {"username": username, "password": password}

                    body["password"] = base64.b64decode(body["password"]).decode()

                    # Send POST request to login
                    api_response = requests.post(url, headers=headers, json=body)

                    logging.info(f"### Login Status Code: {api_response.status_code}")
                else:
                    logging.info("### Access token not found.")
            else:
                logging.info(f"### Error: {api_response.status_code}")

        elif integration_id in bandwidth_integration_ids:
            integration_id = integration_id
            account = changed_data.get("oauth2_custom1")

            try:
                # Initialize the database connection
                dbs = DB(data.get("db_name"), **db_config)

                # Fetch production_url from the database
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["production_url", "auth_test_url"],
                )
            except Exception as e:
                logging.exception(f"### Error updating api_endpoint_url: {e}")
                endpoint_data = None

            production_url = endpoint_data["production_url"].to_list()[0]
            auth_url = endpoint_data["auth_test_url"].to_list()[0]

            url = f"{production_url}{auth_url}{account}"

            # url = 'https://dashboard.bandwidth.com/api/accounts/5001532'

            username = changed_data.get("username")
            password = changed_data.get("password")
            # username= "fderr"
            # password = "QldAUGkhMjM0"

            password_1 = base64.b64decode(password).decode()
            credentials = f"{username}:{password_1}"

            encoded = base64.b64encode(credentials.encode()).decode()


            # encoded = 'ZmRlcnI6QldAUGkhMjM0'

            headers = {"Authorization": f"Basic {encoded}"}

            api_response = requests.get(url, headers=headers)
        elif integration_id in [3]:
            integration_id = integration_id
            try:
                # Initialize the database connection
                dbs = DB(data.get("db_name"), **db_config)

                # Fetch production_url from the database
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["auth_test_url"],
                )
            except Exception as e:
                logging.exception(f"### Error updating api_endpoint_url: {e}")
                endpoint_data = None

            url = endpoint_data["auth_test_url"].to_list()[0]

            # url = 'https://api.revioapi.com/v1/Customers'

            username = changed_data.get("username")
            password = changed_data.get("password")
            token_value = changed_data.get("token_value")

            # username = "AMOPToRevio@altaworx_sandbox"
            # password = "R2VvbG9neTdAU2hvd2luZ0BTdGFuaw=="

            # Combine client ID and secret
            credentials = f"{username}:{password}"

            # Encode credentials as base64
            encoded_credentials = base64.b64encode(credentials.encode()).decode()
            headers = {
                "Accept": "application/json",
                "Ocp-Apim-Subscription-Key": token_value,
                "Authorization": f"Basic {encoded_credentials}",
            }
            logging.info(f"### url {url} , headers {headers}")
            api_response = requests.get(url, headers=headers)
        elif integration_id == 17:
            integration_id = integration_id
            client_id = changed_data.get("oauth2_client_id")
            client_secret = changed_data.get("oauth2_custom2")

            try:
                # Initialize the database connection
                dbs = DB(data.get("db_name"), **db_config)

                # Fetch production_url from the database
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["sandbox_url", "auth_test_url"],
                )
            except Exception as e:
                logging.exception(f"### Error updating api_endpoint_url: {e}")
                endpoint_data = None

            sandbox_test_url = endpoint_data["sandbox_url"].to_list()[0]
            auth_test1_url = endpoint_data["auth_test_url"].to_list()[0]

            url = f"{sandbox_test_url}{auth_test1_url}"

            # url = 'https://lgw.att.com/aps/service/v3/oauth2/token'
            body = {
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
            }
            api_response = requests.post(url, json=body)
        elif integration_id == 5:
            url = changed_data.get("oauth2_custom2")
            client_id = changed_data.get("oauth2_client_id")
            client_secret = changed_data.get("oauth2_custom2")
            username = changed_data.get("username")
            password = changed_data.get("password")

            decoded_password = base64.b64decode(password).decode("utf-8")

            # url = "https://api.netsapiens.com/ns-api/apidoc/"
            # url = "https://api.netsapiens.com/ns-api/apidoc/#api-Reseller-Read"
            params = {
                "grant_type": "password",
                "client_id": client_id,
                "client_secret": client_secret,
                "username": username,
                "password": decoded_password,
            }

            # Headers
            headers = {
                "Accept": "application/json",
            }

            # Make the request
            api_response = requests.get(url, headers=headers, params=params)
        elif integration_id in teal_integration_ids:
            username = changed_data.get("username")
            password = changed_data.get("password")
            decoded_password = base64.b64decode(password).decode("utf-8")

            integration_id = integration_id
            try:
                # Initialize the database connection
                dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

                # Fetch production_url from the database
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["sandbox_url", "auth_test_url"],
                )
            except Exception as e:
                logging.exception(f"### Error updating api_endpoint_url: {e}")
                endpoint_data = None

            sandbox_test_url = endpoint_data["sandbox_url"].to_list()[0]
            auth_test1_url = endpoint_data["auth_test_url"].to_list()[0]

            base_url = f"{sandbox_test_url}{auth_test1_url}"

            # base_url = "https://integrationapi.teal.global/api/v1/esims"

            # Generate the current datetime in the required format
            current_datetime = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            request_id = f"GetDevice_{current_datetime}"

            # Construct the full URL with the updated datetime
            url = f"{base_url}?requestId={request_id}"

            # Headers
            headers = {
                "ApiKey": username,
                "ApiSecret": decoded_password,
                "Accept": "application/json",
            }

            # Make the GET request
            api_response = requests.get(url, headers=headers)
        elif integration_id in pond_integration_ids:
            DistributorId = changed_data.get("oauth2_custom2")
            username = changed_data.get("username")
            password = changed_data.get("password")
            oauth2_custom1 = changed_data.get("oauth2_custom1")

            try:
                # Initialize the database connection
                dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

                if tenant_name=='Altaworx Test':
                    # Fetch production_url from the database
                    endpoint_data = dbs.get_data(
                        "integration_connection",
                        {"integration_id": integration_id, "is_active": True},
                        ["sandbox_url", "auth_test_url"],
                    )
                else:
                    # Fetch production_url from the database
                    endpoint_data = dbs.get_data(
                        "integration_connection",
                        {"integration_id": integration_id, "is_active": True},
                        ["production_url", "auth_test_url"],
                    )
            except Exception as e:
                logging.exception(f"### Error updating api_endpoint_url: {e}")
                endpoint_data = None

            if tenant_name =='Altaworx Test':
                sandbox_url_t = endpoint_data["sandbox_url"].to_list()[0]
            else:
                sandbox_url_t = endpoint_data["production_url"].to_list()[0]
            auth_test_url_ = endpoint_data["auth_test_url"].to_list()[0]
            # Construct the URL dynamically

            # base_url = "https://www.mydashboard.pondmobile.com/ds/u/distributorPPUService/v1"
            url = f"{sandbox_url_t}/{DistributorId}{auth_test_url_}"


            # username = "person@altaworx.com"
            # password = "M2YxMjUzNzYtNzljZi00N2VlLTk4NTEtNjQyY2MyZWVjNmU4"

            # Combine username and password with a colon

            # Encode the string in Base64
            decoded_password = base64.b64decode(password).decode("utf-8")

            auth_string = f"{username}:{decoded_password}"

            encoded_auth_string = base64.b64encode(auth_string.encode()).decode("utf-8")
            # Create the Basic Auth header
            basic_auth_header = f"Basic {encoded_auth_string}"

            # Headers
            headers = {
                "ApiKey": oauth2_custom1,
                "Authorization": basic_auth_header,
                "Accept": "application/json",
            }

            # Make the GET request
            api_response = requests.get(url, headers=headers)

        elif integration_id in pond_19_integration_ids:
            # pond 19
            integration_id = integration_id
            try:
                # Initialize the database connection
                dbs = DB(data.get("db_name"), **db_config)

                # Fetch production_url from the database
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["production_url", "auth_test_url"],
                )
            except Exception as e:
                logging.exception(f"### Error updating api_endpoint_url: {e}")
                endpoint_data = None
            baseurl = endpoint_data["production_url"].to_list()[0]

            # Define the additional path and query parameters
            auth_test_url = endpoint_data["auth_test_url"].to_list()[0]


            # Combine base URL, auth URL, and query parameters
            url = f"{baseurl}{auth_test_url}"

            username = changed_data.get("username")
            password = changed_data.get("password")

            decoded_password = base64.b64decode(password).decode("utf-8")

            # Combine client ID and secret
            credentials = f"{username}:{decoded_password}"

            # Encode credentials as base64
            encoded_credentials = base64.b64encode(credentials.encode("utf-8")).decode("utf-8")

            # Set headers for token request
            headers = {
                "Accept": "application/json",
                "Authorization": f"Basic {encoded_credentials}",
            }

            # Send POST request for token
            api_response_data = requests.get(url, headers=headers)

            # Access the nested data structure
            settings = data["changed_data"]["settings"]

            # Find the setting with key "JasperUiAddress"
            jasper_ui_address = next(
                (item["setting_value"] for item in settings if item["setting_key"] == "JasperUiAddress"),
                None  # Default if not found
            )

            jasper_ui_username = next(
                (item["setting_value"] for item in settings if item["setting_key"] == "JasperUiUsername"),
                None  # Default if not found
            )

            jasper_ui_password = next(
                (item["setting_value"] for item in settings if item["setting_key"] == "JasperUiPassword"),
                None  # Default if not found
            )


              # Output: "https://iotcontrolcenter.att.com/"

            logging.info(f"### Status Code: :  {api_response_data.status_code}")
            if api_response_data.status_code == 200:
                url2 = f"{jasper_ui_address}provision/jsp/login.jsp"
                response2 = requests.get(url2)

                if response2.status_code == 200:
                    url3 = f"{jasper_ui_address}provision/j_acegi_security_check"

                    decoded_jasper_ui_password = base64.b64decode(jasper_ui_password).decode("utf-8")


                    # Login credentials
                    login_form_fields = {
                        "j_username": jasper_ui_username,  # Replace with actual username
                        "j_password": decoded_jasper_ui_password,   # Replace with actual password
                    }

                    # Make the POST request to submit login form
                    api_response = requests.post(url3, data=login_form_fields)
        else:
            pass

        if integration_id in [20]:
            if api_response.status_code == 200:
                # Parse XML response
                root = ET.fromstring(api_response.text)
                ns = {"ns0": "http://wws.iamwebbing.com/"}

                # Extract response values
                success = root.find(".//ns0:Success", ns)
                response_code = root.find(".//ns0:ResponseCode", ns)
                response_description = root.find(".//ns0:ResponseDescription", ns)

                result = {
                    "success": success.text.strip().lower() == "true" if success is not None else False,
                    "response_code": response_code.text if response_code is not None else "N/A",
                    "response_description": response_description.text if response_description is not None else "No description"
                }

                return result

            else:
                return {"success": False, "error": f"HTTP Error {api_response.status_code}: {api_response.text}"}


        # If status code is 200, proceed with the database update
        if api_response.status_code == 200:
            try:
                db = DB(tenant_database, **db_config)
                dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
                update_result = db.update_dict(
                    "integration_authentication", insert_data, where_dict
                )
                if update_result:
                    # return {
                    #     "flag": True,
                    #     "message": "Integration details updated successfully.",
                    # }
                    response = {
                        "flag": True,
                        "message": "Integration details updated successfully.",
                    } 
                    try:
                        audit_data_user_actions = {
                            "service_name": "save_integration_details",
                            "created_by": data.get("username", ""),
                            "status": str(response['flag']) ,
                            "session_id": data.get("sessionID", ""),
                            "tenant_name": data.get("Partner", ""),
                            "module_name": "Module Management",
                            "comments": "Integration details updated successfully",
                            "request_received_at": data.get("request_received_at", ""),
                        }
                        dbs.update_audit(
                            audit_data_user_actions, "audit_user_actions"
                        )
                    except Exception as e:
                        logging.warning(f"### Audit logging exception: {e}")

                    return response
                
                else:
                    return {
                        "flag": False,
                        "message": "Failed to update integration details.",
                    }
            except Exception as db_error:
                return {
                    "flag": False,
                    "message": f"Database error occurred: {db_error}",
                }
        elif authentication_type == 16 and integration_id == 16:
            try:
                db = DB(tenant_database, **db_config)
                update_result = db.update_dict(
                    "integration_authentication", insert_data, where_dict
                )
                if update_result:
                    return {
                        "flag": True,
                        "message": "Integration details updated successfully.",
                    }
                else:
                    return {
                        "flag": False,
                        "message": "Failed to update integration details.",
                    }
            except Exception as db_error:
                return {
                    "flag": False,
                    "message": f"Database error occurred: {db_error}",
                }
        else:
            return {
                "flag": False,
                "message": f"API call failed with status code {api_response.status_code} and {api_response.text}",
            }

    except Exception as e:
        db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        logging.exception(f"exception occurred while saving integration details : {e}")
        message = "something went wrong while saving integration details" 
        db.log_error_to_db(
            {
                "service_name": "save_integration_details",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"An error occurred while saving the integration details : {str(e)}"}





def update_settings(setting_key, setting_value, service_provider_id,tenant_database):
    """
    Update a specific setting for a given service provider in the database.

    This helper function updates the `setting_value` of a specific `setting_key`
    for the given `service_provider_id` in the `service_provider_setting` table.

    Args:
        setting_key (str): The key of the setting to update.
        setting_value (str | int | bool): The new value to be set for the setting.
        service_provider_id (int): The ID of the service provider whose setting is being updated.
        tenant_database (str): The name of the tenant-specific database.

    Returns:
        None
    """
    try:
        db = DB(tenant_database, **db_config)
        insert_data = {"setting_value": setting_value}
        where_dict = {
            "setting_key": setting_key,
            "service_provider_id": service_provider_id,
        }
        db.update_dict("service_provider_setting", insert_data, where_dict)
        logging.info(f"### Successfully updated setting: {setting_key}","update_settings")

    except Exception as e:
        logging.exception(f"### Error updating setting {setting_key}: {e}","update_settings")


def get_cross_provider_optimization_status(data):
    """
    Retrieves cross-provider optimization and billing platform status for a given tenant.

    Args:
        data (dict): A dictionary containing:
            - 'db_name': Tenant database name.
            - 'tenant_name': Name of the tenant (e.g., 'Altaworx Test').

    Returns:
        dict: {
            "flag": bool (always True),
            "cross_carrier_optimization": bool (True/False),
            "billing_platform_flag": bool (True/False)
        }

    """
    tenant_database=data.get('db_name')
    try : 
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        tenant_name = data.get("tenant_name", "")
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        tenant_details = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id","parent_tenant_id","billing_platform_flag"]
        )
        tenant_id = tenant_details["id"].to_list()[0]
        parent_tenant_id = tenant_details["parent_tenant_id"].to_list()[0]
        billing_platform_flag = tenant_details["billing_platform_flag"].to_list()[0] # To fetch the details of billing platform enablement
        if tenant_id:
            tenant_id=int(tenant_id)
        try:
            if parent_tenant_id:
                query = f"SELECT optino_cross_providercustomer_optimization FROM optimization_setting_tenant_override WHERE tenant_id = {tenant_id}"
                cross_carrier_optimization = database.execute_query(query, True)
                if not cross_carrier_optimization.empty:
                    cross_carrier_optimization = cross_carrier_optimization["optino_cross_providercustomer_optimization"].to_list()[0]
                else:
                    cross_carrier_optimization = False
            else:
            # Attempt to retrieve the value from the 'tenant' table
                cross_carrier_optimization = database.get_data(
                    "optimization_setting",
                    {"tenant_id": tenant_id},
                    ["optino_cross_providercustomer_optimization"],
                )["optino_cross_providercustomer_optimization"].to_list()[0]

        except Exception as e:
            logging.exception(f"### Failed to get the cross_carrier_optimization{e}","cross_provider_optimization")
            cross_carrier_optimization = False
            billing_platform_flag = False
        response={"flag":True,"cross_carrier_optimization":cross_carrier_optimization,"billing_platform_flag":billing_platform_flag}
        try:
            audit_data_user_actions = {
                "service_name": "get_cross_provider_optimization_status",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module_management",
                "comments": "successfully fetched the cross provider optimization status",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
        return response
 

    except Exception as e:
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error occurred while getting cross provider optimization status : {e}")
        message = "Something went wrong while getting cross provider optimization status"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_cross_provider_optimization_status",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 

        response = {
            "flag": False,
            "cross_carrier_optimization": None,
            "billing_platform_flag": None
        }

        return response      




def get_service_provider_config(data):
    """
    Fetches configuration data related to service providers for a given tenant.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): The name of the tenant-specific database.
            - tenant_name (str): Name of the tenant (e.g., "Altaworx").
            - username (str): The user requesting the data.
            - request_received_at (str): Timestamp when the request was received.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if the operation was successful.
            - rev_products (list): List of dictionaries with product descriptions and IDs.
            - rev_product_types (list): List of dictionaries with product type descriptions and IDs.
            - service_providers (list): List of service provider records including mapped integration names.
            - service_provider_tenant_configuration (list): Configuration details linked to each service provider.
    """
    tenant_database = data.get("db_name", "")
    db = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")

    try:

        if tenant_name == "Altaworx Test":
            tenant_id = 1  # Include the hardcoded ID
            # Fetch the ID from the database as well
        else:
            # Default case: fetch only from the database
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
        result = {}

        result["flag"]=  True


        integration_authentication_json_data = load_integration_authentication_json()
        integration_auth_id = get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)
        if not integration_auth_id:
            query=f'''select parent_tenant_id from tenant where tenant_name='{tenant_name}'
            '''
            parent_tenant_id=common_utils_database.execute_query(query,True)['parent_tenant_id'].to_list()[0]
            if parent_tenant_id:
                parent_tenant_id=int(parent_tenant_id)
            parent_tenant_query=f'''select tenant_name from tenant where id={parent_tenant_id}
            '''
            parent_tenant_name=common_utils_database.execute_query(parent_tenant_query,True)['tenant_name'].to_list()[0]
            integration_auth_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, parent_tenant_name)

        # If no valid integration_auth_id is found, return empty result
        logging.info(f"### Integration Authentication ID: {integration_auth_id}","get_service_provider_config")
        if integration_auth_id is None:
            return []

        # Get products and product types
        result["rev_products"] = [
            {"description": row["description"], "product_id": row["product_id"],"billing_flag": False}
            for _, row in db.get_data("rev_product",
                                    {"is_active": True, "is_deleted": False, "integration_authentication_id": integration_auth_id},
                                    ["description", "product_id"]).iterrows()
        ]

        #check billing_platform enablment flag
        billing_flag = common_utils_database.get_data(
            "tenant", {"id": tenant_id}, ["billing_platform_flag"]
        )["billing_platform_flag"].to_list()[0]
        logging.info(f'billing_flag------------{billing_flag}')
        
        if billing_flag:
            killbill_products = [
                {"description": row["description"], "product_id": row["id"], "billing_flag": True}
                for _, row in killbill_database.get_data(
                    "products",
                    {"is_active": True, "tenant_id": tenant_id},
                    ["id", "description"]
                ).iterrows()
            ]

            result["rev_products"].extend(killbill_products)


        result["rev_product_types"] = [
            {"description": row["description"], "product_type_id": row["product_type_id"]}
            for _, row in db.get_data("rev_product_type",
                                    {"is_active": True, "is_deleted": False, "integration_authentication_id": integration_auth_id},
                                    ["description", "product_type_id"]).iterrows()
        ]


        integration_query = """
        SELECT id, name FROM integration
        WHERE is_active='true'
        """
        integrations = common_utils_database.execute_query(integration_query, True)
        integration_map = dict(zip(integrations["id"], integrations["name"]))

        # Fetch service providers
        sp_query = """
        SELECT SP.id, SP.service_provider_name, SP.integration_id FROM serviceprovider SP
        WHERE SP.is_active = 'true' OR SP.is_deleted = 'false'
        ORDER BY SP.service_provider_name ASC
        """

        service_providers = db.execute_query(sp_query, True)

        service_providers["integration_name"] = service_providers["integration_id"].map(integration_map)


        result["service_providers"] = service_providers.to_dict(orient="records")
        parent_query=f'''select parent_tenant_id from tenant where tenant_name='{tenant_name}'
        '''
        parent_tenant_id=common_utils_database.execute_query(parent_query,True)['parent_tenant_id'].to_list()[0]
        if parent_tenant_id:
            parent_tenant_id=int(parent_tenant_id)
            tenant_id=parent_tenant_id
        sptc_query = f"""
        SELECT spc.*
            FROM public.service_provider_tenant_configuration spc
            JOIN public.serviceprovider sp
            ON spc.service_provider_id = sp.id
            WHERE spc.is_active = true and sp.is_active = true and sp.is_deleted = false

			and spc.tenant_id = {tenant_id}
            ORDER BY spc.service_provider_id ASC

        """

        service_provider_tenant_configuration = db.execute_query(sptc_query, True).to_dict(orient="records")



        tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
        service_provider_tenant_configuration = convert_timestamp_data(
            service_provider_tenant_configuration, tenant_time_zone
        )
        result["service_provider_tenant_configuration"] = service_provider_tenant_configuration

        try:
            audit_data_user_actions = {
                "service_name": "get_service_provider_config",
                "created_by": username,
                "status": str(result["flag"]),
                "tenant_name": tenant_name,
                "comments": "fetches service provider config",
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception is : {e}")
        logging.info(f"### Successfully fetched data get_service_provider_config => {result}","get_service_provider_config")
        return result


    except Exception as e:
        # Handle exceptions and provide feedback
        logging.exception(f"### Exception occurred while getting service provider config data : {e}")
        message = "Something went wrong while getting service provider config data"
        # Error Management
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "get_service_provider_config",
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Module Management",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        result = {"flag": False, "error": str(e)}
    return result




def save_service_provider_config(data):
    """
    Saves updates to the service provider configuration for a tenant.

    This function processes a list of changed configuration entries and updates
    the `service_provider_tenant_configuration` table in the tenant-specific database.
    It also logs user actions into the audit table and captures errors into an error log table.

    Args:
        data (dict): A dictionary containing:
            - changed_data (list): List of dictionaries, each containing updated field values and the 'id' to update.
            - db_name (str): The name of the tenant-specific database.
            - request_received_at (str): Timestamp when the request was received.
            - username (str): Username of the person making the request.
            - tenant_name (str): Name of the tenant (e.g., "Altaworx").

    Returns:
        dict: A response dictionary with:
            - flag (bool): True if the update was successful, False otherwise.
            - message (str): A success or failure message.
    """

    changed_data_list = data.get("changed_data", [])
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    table_name = "service_provider_tenant_configuration"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)


    try:
        # Process each item in the changed_data list
        for changed_data in changed_data_list:
            unique_id = changed_data.get("id", "")

            # Filter out None values
            # changed_data = {
            #     k: v for k, v in changed_data.items() if v not in [None, "None"]
            # }

            # Remove id from update data
            update_data = {
                key: value for key, value in changed_data.items() if key != "id"
            }

            logging.info(f"### Updating record with ID {unique_id}. Update data: {update_data}","get_service_provider_config")

            if update_data and unique_id:
                database.update_dict(table_name, update_data, {"id": unique_id})
            else:
                logging.info(f"### Skipping update for ID {unique_id}: No valid update data or missing ID","get_service_provider_config")

        response_data = {"flag": True, "message": "Successfully Updated"}

        try:
            # Log the user action in the audit table
            audit_data_user_actions = {
                "service_name": "save_service_provider_config",
                "created_by": username,
                "status": str(response_data["flag"]),
                "session_id": "session_id",
                "tenant_name": tenant_name,
                "comments": f"saving service provider config {json.dumps(changed_data_list)}",
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
            logging.info("### Audit log recorded successfully")
        except Exception as e:
            logging.warning(f"### Exception during audit log: {e}")

        return response_data

    except Exception as e:
        logging.info(f"### An error occurred: {e}")
        message = "Unable to save the data"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)

        try:
            # Log error to database
            error_data = {
                "service_name": "save_service_provider_config",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": "session_id",
                "tenant_name": tenant_name,
                "comments": message ,
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
            logging.info("### Error details logged successfully")
        except Exception as e:
            logging.warning(f"### Exception during error log: {e}")

        return response





def get_cross_carrier_optimization(data):
    """
    Retrieves cross-carrier optimization settings for a tenant.

    This function checks whether cross-carrier optimization is enabled for a tenant.
    It first checks for any tenant-specific overrides and then falls back to default optimization settings
    if no override exists. It also logs user actions and errors.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): The name of the tenant-specific database.
            - tenant_name (str): The name of the tenant (e.g., "Altaworx Test").
            - username (str): The name of the user requesting the data.
            - request_received_at (str): Timestamp when the request was received.

    Returns:
        dict: A dictionary with:
            - flag (bool): True if the operation was successful, False otherwise.
            - cross_carrier_optimization (bool, optional): Indicates whether cross-carrier optimization is enabled.
            - error (str, optional): Error message if an exception occurs.
    """
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB('common_utils', **db_config)
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    tenant_details = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id","parent_tenant_id"]
    )
    tenant_id = tenant_details["id"].to_list()[0]
    parent_tenant_id = tenant_details["parent_tenant_id"].to_list()[0]
    if tenant_id:
        tenant_id=int(tenant_id)
    try:
        if parent_tenant_id:
            query = f"SELECT optino_cross_providercustomer_optimization FROM optimization_setting_tenant_override WHERE tenant_id = {tenant_id}"
            cross_carrier_optimization = database.execute_query(query, True)
            if not cross_carrier_optimization.empty:
                cross_carrier_optimization = cross_carrier_optimization["optino_cross_providercustomer_optimization"].to_list()[0]
            else:
                cross_carrier_optimization = False
            return {"flag": True, "cross_carrier_optimization": cross_carrier_optimization}
        else:
            p = database.get_data(
                    "optimization_setting",
                    {"tenant_id":tenant_id},
                    ["optino_cross_providercustomer_optimization"],
                ).iloc[0, 0]
        result={"flag": True, "cross_carrier_optimization": False if int(p) == 0 else True}

        try:
            audit_data_user_actions = {
                "service_name": "get_cross_carrier_optimization",
                "created_by": username,
                "status": str(result["flag"]),
                "tenant_name": tenant_name,
                "comments": f"fetched cross carrier optimization - {tenant_name}",
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception is : {e}")


        return result

    except Exception as e:
        # Handle exceptions and provide feedback
        logging.exception(f"### Exception occurred while fetching cross carrier optimization data : {e}")
        message = "Something went wrong while fetching cross carrier optimization data "
        # Error Management
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "get_cross_carrier_optimization",
            "error_message": str(e),
            "error_type": error_type ,
            "users": username,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Module Management",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        result = {"flag": False, "error": str(e)}
        return result


def convert_and_filter(data):
    """
    Converts date and timestamp values to ISO format and filters out None values from a list of dictionaries.

    This function processes each dictionary in the input list:
    - Converts all `date` or `Timestamp` values to ISO 8601 string format.
    - Removes key-value pairs where the value is `None`.

    Args:
        data (list of dict): A list of dictionaries, where each dictionary may contain
                             date, Timestamp, or None values.

    Returns:
        list of dict: A new list of dictionaries with:
            - Dates and Timestamps converted to ISO strings.
            - All keys with `None` values removed.
    """
    converted_list = []

    for entry in data:
        converted_entry = {
            k: (v.isoformat() if isinstance(v, (date, Timestamp)) else v)
            for k, v in entry.items() if v is not None  # Remove None values
        }
        converted_list.append(converted_entry)

    return converted_list


def get_customer_user_by_line_report_view_data(data):
    """
    Retrieves customer usage by line report data for a given tenant and user context.

    Args:
        data (dict): A dictionary containing:
            - tenant_name (str): The name of the tenant.
            - db_name (str): The database name of the tenant.
            - username (str): Name of the user requesting the data.
            - module_name (str): The name of the module for export.
            - role_name (str): The role of the user (for header mapping).
            - service_provider (int, optional): ID of the service provider.
            - billing_cycle_period (int, optional): ID of the billing cycle period.
            - mod_pages (dict, optional): Dictionary with 'start' and 'end' for pagination.

    Returns:
        dict: A dictionary with:
            - flag (bool): True if data is successfully retrieved, False otherwise.
            - data (list of dict): The report data (if successful).
            - headers_map (dict): Header mappings for front-end rendering.
            - pages (dict): Pagination details if provided.
            - error (str, optional): Error message if operation fails.
    """
    logging.info(f"### Request Data Received : {data}")
    Partner = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", " ")
    module_name = data.get("module_name", "")
    col_sort = data.get("col_sort", "")

    # Initialize the database connection
    tenant_database = data.get("db_name", "")
    try:
        try:
            del db_config['customers']
            del db_config['service_providers']
            del db_config['billing_account_number']
            del db_config['feature_codes']
        except Exception as e:
                logging.exception(f"### get_customer_user_line_report_view del db_config exption : {e}")

        try:
            # database Connection
            database = DB(tenant_database, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        except Exception as db_error:
            logging.error(f"### Database connection error: {db_error}")
            return {"flag": False, "error": f"Failed to connect to database: {str(db_error)}"}

        tenant_database = data.get("db_name", "altaworx_test")
        customer_id = data.get("service_provider", "")
        billing_id = data.get("billing_cycle_period", "")

        export_base_path = os.getenv("EXPORT_BASE_PATH")
        module_name_snake_case = "_".join(module_name.strip().lower().split())
        file_name = f"{export_base_path}/{module_name_snake_case}/{module_name}.json"
        download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

        # Update export status to 'Waiting'
        try:
            common_utils_database.update_dict(
                "export_status",
                {"status_flag": "Waiting", "url": ""},
                {"module_name": "Usage By Line Report View"},
            )
        except Exception as status_error:
            logging.warning(f"### Failed to update export status to 'Waiting': {status_error}")
            # Continue execution despite this error

        # Handle pagination
        pages = {}
        if "mod_pages" in data:
            start = data["mod_pages"].get("start") or 0  # Default to 0 if no value
            end = data["mod_pages"].get("end") or 100  # Default to 100 if no value
            logging.info(f"### Starting page is {start} and ending page is {end}")

        # Get service providers for the user
        try:
            query = f"select service_provider from users where username ='{username}'"
            filters = common_utils_database.execute_query(query, True)
            service_providers = None
            if not filters.empty:
                service_providers = filters["service_provider"].to_list()[0]

            if isinstance(service_providers, str):
                # If it's a string, convert it to a list by evaluating it
                import ast
                try:
                    service_providers = ast.literal_eval(service_providers)
                except Exception as e:
                    logging.error(f"### Failed to determine service_providers: {e}")
                    service_providers = [service_providers]
        except Exception as sp_error:
            logging.warning(f"### Error retrieving service providers: {sp_error}")
            service_providers = None

        # Build conditions with parameterized query
        conditions = ""
        if service_providers:
            # Dynamically generate conditions for service providers
            conditions = f"""WHERE service_provider_display_name IN ({','.join(f"'{service_provider}'" for service_provider in service_providers)}) """

        # Construct ORDER BY clause
        if col_sort:
            # Extract the single key-value pair
            key, value = list(col_sort.items())[0]  # Get the first and only pair
            order_condition = f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start}"
        else:
            order_condition = f"LIMIT 100 OFFSET {start}"

        # Get tenant ID
        try:
            tenant_name = data.get("tenant_name", "Altaworx Test")
            tenant_names_str = os.getenv("TENANT_NAMES", "")
            # Convert the comma-separated string into a list
            tenant_names_str = re.sub(r"[^a-zA-Z0-9]", " ", tenant_names_str)
            tenant_names = tenant_names_str.split(",")

            if tenant_name in tenant_names:
                tenant_id = 1
            else:
                tenant_query_result = common_utils_database.get_data(
                    "tenant", {"tenant_name": tenant_name}, ["id"]
                )
                if tenant_query_result.empty:
                    return {"flag": False, "error": f"Tenant not found: {tenant_name}"}
                tenant_id = tenant_query_result["id"].to_list()[0]
        except Exception as tenant_error:
            logging.error(f"### Error retrieving tenant ID: {tenant_error}")
            return {"flag": False, "error": f"Failed to retrieve tenant ID: {str(tenant_error)}"}

        # Main query with parameterization
        try:
            if int(billing_id) == 0:
                customer_user_by_line_query = f"""
                    select
                            service_provider_display_name,
                            billing_cycle_end_date,
                            customer_cycle_end_date,
                            iccid,msisdn,
                            foundation_account_number,
                            billing_account_number,
                            customer_rate_pool_name,
                            customer_name,
                            customer_id,
                            username,
                            carrier_rate_plan,
                            rate_plan_name,
                            integration_id,
                            data_usage_mb,
                            status_display_name,
                            date_activated,
                            tenant_id
                            from usp_report_customer_usage_by_line
                            WHERE tenant_id = {tenant_id} and is_active=True
                            {f' AND customer_id = {customer_id}' if customer_id else ''}
                    {conditions}
                    {order_condition}"""
            else:
                customer_user_by_line_query = f"""
                    select
                        service_provider_display_name,
                        customer_cycle_end_date,
                        billing_cycle_end_date,
                        iccid,
                        msisdn,
                        foundation_account_number,
                        billing_account_number,
                        customer_rate_pool_name,
                        customer_name,username,
                        carrier_rate_plan,
                        rate_plan_name,
                        integration_id,
                        data_usage_mb,
                        status_display_name,
                        date_activated,
                        tenant_id
                    from usp_report_customer_historyusagebyline_rmf({int(customer_id)},{int(tenant_id)},{int(billing_id)})
                    {conditions}
                    {order_condition}
                """

            # Execute the query with parameters
            query_result = database.execute_query(customer_user_by_line_query, True)
            if query_result is None or query_result.empty:
                customer_user_by_line_report = []
            else:
                customer_user_by_line_report = query_result.to_dict(orient="records")

                customer_user_by_line_report = convert_and_filter(customer_user_by_line_report)
        except Exception as query_error:
            logging.error(f"### Query execution error: {query_error}")
            return {"flag": False, "error": f"Query execution failed: {str(query_error)}"}

        # Apply timezone conversion if needed
        try:
            tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
            customer_user_by_line_report = convert_timestamp_data(
                customer_user_by_line_report, tenant_time_zone
            )
            # customer_user_by_line_report = serialize_data(customer_user_by_line_report)
        except Exception as timezone_error:
            logging.warning(f"### Error converting timestamps: {timezone_error}")
            # Continue execution despite this error

        # Generate the headers mapping
        try:
            headers_map = get_headers_mapping(
                tenant_database,
                ["Usage By Line Report"],
                role_name,
                "",
                "",
                "",
                "",
                data,
                common_utils_database,
            )
        except Exception as headers_error:
            logging.warning(f"### Error generating headers mapping: {headers_error}")
            headers_map = {}  # Use empty dict if headers mapping fails

        # Serialize data for S3 upload
        try:
            import json
            serialized_data = json.dumps(customer_user_by_line_report)

            # Upload JSON to S3
            try:
                import boto3
                s3_client = boto3.client('s3')
                s3_client.put_object(
                    Bucket=S3_BUCKET_NAME,
                    Key=file_name,
                    Body=serialized_data,
                    ContentType="application/json",
                )

                # Update export status to 'Success'
                common_utils_database.update_dict(
                    "export_status",
                    {"status_flag": "Success", "url": download_url},
                    {"module_name": "Usage By Line Report View"},
                )
            except Exception as s3_error:
                logging.error(f"### S3 upload error: {s3_error}")
                # Continue execution even if S3 upload fails
        except Exception as serialize_error:
            logging.error(f"### Data serialization error: {serialize_error}")
            # Continue execution even if serialization fails



        # Prepare the response
        response = {
            "flag": True,
            "data": serialize_data(customer_user_by_line_report),
            "headers_map": headers_map,
            "pages": pages,
        }

        # Log audit
        try:
            audit_data_user_actions = {
                "service_name": "get_customer_user_by_line_report_view_data",
                "created_by": username,
                "status": str(response["flag"]),
                "tenant_name": Partner,
                "comments": f"fetches customer user by line report data - {customer_id}",
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as audit_error:
            logging.warning(f"### Audit logging exception: {audit_error}")
            # Continue execution despite audit logging error

        return response

    except Exception as e:
        # Handle general exceptions and provide feedback
        logging.exception(f"### Exception occurred in retrieving Usage By Line Report data: {e}")
        message = "Something went wrong while retrieving Usage By Line Report data"
        error_type = str(type(e).__name__)
        try:
            # Error Management
            error_data = {
                "service_name": "get_customer_user_by_line_report_view_data",
                "error_message": str(e),
                "error_type": error_type ,
                "users": username,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as error_log_error:
            logging.error(f"### Failed to log error to database: {error_log_error}")

        response = {"flag": False, "error": str(e)}
        return response



def customer_info_details(data):
    """
    Fetches customer-related dropdown information for a given partner.

    This function connects to the common_utils database to fetch the database
    name of a tenant based on the provided `partner_name`. If found, it connects
    to the partner's tenant database and retrieves:
    - Active customers
    - Active service providers
    - Active customer groups

    Args:
        data (dict): Dictionary containing:
            - partner_name (str): The name of the partner whose tenant data should be fetched.

    Returns:
        dict: A dictionary with:
            - flag (bool): Indicates whether data was successfully fetched.
            - message (str): Success or failure message.
            - data (dict): Empty dict (reserved for future use).
            - pages (dict): Empty dict (reserved for future use).
            - features (dict): Empty dict (reserved for future use).
            - dropdown (dict): Dictionary with dropdown lists:
                - customers (list of str): List of unique active customer names.
                - serviceprovider (list of str): List of unique active service provider names.
                - customergroups (list of str): List of unique active customer group names.
    """
    try : 
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        partner_name=data.get("partner_name",'')

        # get the db_name
        if partner_name:
            try:
                db_name=common_utils_database.get_data("tenant",{"tenant_name":partner_name},["db_name"])["db_name"].to_list()[0]
            except Exception as e:
                db_name=''
                logging.info(f"### Error:{e}")
        else:
            db_name=''


        if db_name:
            partner_db=DB(db_name, **db_config)

            # get customer from users table
            try:
                customers=partner_db.get_data("customers",{"is_active":True},["customer_name"],{"customer_name":"asc"})["customer_name"].to_list()
                customers=sorted(set(customers))
            except Exception as e:
                customers=[]
                logging.info(f"### Error:{e}")

            # get customer from users table
            try:
                serviceprovider=partner_db.get_data("serviceprovider",{"is_active":True},["service_provider_name"],{"service_provider_name":"asc"})["service_provider_name"].to_list()
                serviceprovider=sorted(set(serviceprovider))
            except Exception as e:
                serviceprovider=[]
                logging.info(f"### Error:{e}")

            # get customer from users table
            try:
                customergroups=partner_db.get_data("customergroups",{"is_active":True},["name"],{"name":"asc","is_active":True})["name"].to_list()
                customergroups=sorted(set(customergroups))
            except Exception as e:
                customergroups=[]
                logging.info(f"### Error:{e}")

            dropdown={
                "customers":customers,
                "serviceprovider":serviceprovider,
                "customergroups":customergroups
            }


            response = {
                "flag": True,
                "message":"Data Fetched Succesfully",
                "data": {},
                "pages": {},
                "features": {},
                "dropdown": dropdown
            }

            try:
                audit_data_user_actions = {
                    "service_name": "customer_info_details",
                    "created_by": data.get("username", ""),
                    "status": str(response['flag']),
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": data.get("Partner", ""),
                    "module_name": "Module Management",
                    "comments": "customer info details fetched successfully",
                    "request_received_at": data.get("request_received_at", ""),
                }
                common_utils_database.update_audit(
                    audit_data_user_actions, "audit_user_actions"
                )
            except Exception as e:
                logging.warning(f"### Audit logging exception: {e}")

            return response
 

            # return response
        else:
            response = {
                "flag": False,
                "message":"Not db found"
            }
            return response

         
    except Exception as e : 
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error in getting customer info details : {e}")
        message = "Something went wrong while getting customer info details"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "customer_info_details",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 

        response = {
                "flag": False,
                "message": "Something went wrong while getting Customer Groups Dropdown Data",
                "data": {},
                "pages": {},
                "features": {},
                "dropdown": {
                    "customers": [],
                    "serviceprovider": [],
                    "customergroups": []
                }
            }

        return response 


def get_submit_customer_group_dropdown_details(data):
    """
    Retrieves dropdown details related to customer groups, including tenant hierarchy.

    Args:
        data (dict): Input dictionary containing:
            - db_name (str): Name of the tenant database to connect to.
            - username (str): Username of the requester (optional).
            - module_name (str): Name of the module requesting data (optional).
            - tenant_name (str): Tenant's name to retrieve dropdown data for.
            - role_name (str): Role of the user (e.g., "Super Admin"), defaults to "Super Admin".
            - sub_tenant_name (str): Sub-tenant to use instead of the main tenant (optional).

    Returns:
        dict: A dictionary (`response_data`) with:
            - tenant_details (dict):
                - parent_tenant (list): List containing the parent tenant name (if found).
                - sub_tenants (list): Sorted list of active sub-tenant names.
    """
    # Record the start time for performance measurement
    start_time = time.time()
    session_id = data.get("session_id")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    module_name = data.get("module_name", "")
    partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    role_name= data.get("role_name", "Super Admin")
    sub_tenant_name = data.get("sub_tenant_name", "")
    try : 
        # database Connection
        if role_name=='Super Admin':
            database = DB(tenant_database, **db_config_withoutfilter)
        else:
            database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)

        response_data = {}
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        parent_tenant_id=None
        # tenant and sub tenants
        try:
            parent_tenant_id=common_utils_database.get_data("tenant",{"tenant_name":tenant_name,"is_active":True},["id"])["id"].to_list()[0]
            if parent_tenant_id:
                sub_tenants=common_utils_database.get_data("tenant",{"parent_tenant_id":parent_tenant_id,"is_active":True},["tenant_name"])["tenant_name"].to_list()
                parent_tenant=[tenant_name]
            else:
                sub_tenants=[tenant_name]
                parent_tenant=[]
        except Exception as e:
            logging.exception(f"### get_submit_customer_group_dropdown_details tenant_id exception : {e}")
            parent_tenant=[]
            sub_tenants=[]

        tenant_details={
            "parent_tenant":parent_tenant,
            "sub_tenants":sorted(sub_tenants)
        }
        response_data["tenant_details"] = tenant_details

        if sub_tenant_name:
            tenant_name = sub_tenant_name
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        tenant_row = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id", "billing_platform_flag"]
        )

        tenant_id = tenant_row["id"].to_list()[0]
        billing_platform_flag = bool(tenant_row["billing_platform_flag"].to_list()[0])



        soc_codes_pop_up_query = """SELECT distinct(soc_code) FROM public.mobility_feature
        where soc_code is not null
        """
        soc_codes_pop_up_values = database.execute_query(
            soc_codes_pop_up_query, True
        )["soc_code"].to_list()
        # Add SOC codes to the module_data
        if soc_codes_pop_up_values:

            response_data["feature_codes"] = soc_codes_pop_up_values
        else:
            response_data["feature_codes"] = []
        # Fetch role module data with efficient query
        role_module_data = common_utils_database.get_data(
            "role_module",
            {"role": role_name},
            ["sub_module"],
        )

        # Initialize default status
        module_status = False

        if not role_module_data.empty:
            try:
                # Parse JSON safely with fallback
                sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                # Strict nested check
                if "People" in sub_modules:
                    people_modules = sub_modules["People"]
                    if isinstance(people_modules, list):  # Ensure it's a list
                        module_status = "Billing Platform Customers" in people_modules

            except json.JSONDecodeError:
                logging.error(f"### Invalid JSON in sub_module for role: {role_name}")
            except KeyError:
                pass  # People section not present
            except Exception as e:
                logging.error(f"### Unexpected error processing modules: {str(e)}")
        if billing_platform_flag:
            if module_status and tenant_name!='WingTel':
                # response_data["feature_codes"] = soc_codes_pop_up_values
                if parent_tenant_id and role_name != "Super Admin":
                    customers_data_query = f"""SELECT distinct customer_name FROM public.revcustomer where is_active=True and tenant_id={tenant_id}   order by customer_name asc
                    """
                    bp_customers_data_query = f"""SELECT distinct customer_name FROM public.customers where is_active=True and billing_platform_flag=True and tenant_id={tenant_id}   order by customer_name asc
                    """

                else:
                    customers_data_query = """SELECT distinct customer_name FROM public.revcustomer where is_active=True  order by customer_name asc
                    """
                    bp_customers_data_query = """SELECT distinct customer_name FROM public.customers where is_active=True and billing_platform_flag=True order by customer_name asc
                    """
            else:
                if parent_tenant_id and role_name != "Super Admin":
                    customers_data_query = f"""SELECT distinct customer_name FROM public.customers where is_active=True and tenant_id={tenant_id}  order by customer_name asc
                    """
                    bp_customers_data_query = f"""SELECT distinct customer_name FROM public.customers where is_active=True  and billing_platform_flag=True and tenant_id={tenant_id}  order by customer_name asc
                    """
                else:
                    customers_data_query = """SELECT distinct customer_name FROM public.customers where is_active=True  order by customer_name asc
                    """
                    bp_customers_data_query = """SELECT distinct customer_name FROM public.customers where is_active=True and billing_platform_flag=True order by customer_name asc
                    """

            customer_names = database.execute_query(
                customers_data_query, True
            )["customer_name"].to_list()
            if bp_customers_data_query:
                bp_customers = database.execute_query(bp_customers_data_query, True)["customer_name"].to_list()
                customer_names=bp_customers+customer_names


            if customer_names:
                response_data["customer_names"] = customer_names
            else:
                response_data["customer_names"] = []
        else:
            if module_status and tenant_name!='WingTel':
                # response_data["feature_codes"] = soc_codes_pop_up_values
                if parent_tenant_id and role_name != "Super Admin":
                    customers_data_query = f"""SELECT distinct customer_name FROM public.revcustomer where is_active=True and tenant_id={tenant_id}   order by customer_name asc
                    """
                else:
                    customers_data_query = """SELECT distinct customer_name FROM public.revcustomer where is_active=True  order by customer_name asc
                    """
            else:
                if parent_tenant_id and role_name != "Super Admin":
                    customers_data_query = f"""SELECT distinct customer_name FROM public.customers where is_active=True and tenant_id={tenant_id}  order by customer_name asc
                    """
                else:
                    customers_data_query = """SELECT distinct customer_name FROM public.customers where is_active=True  order by customer_name asc
                    """

            customer_names = database.execute_query(
                customers_data_query, True
            )["customer_name"].to_list()

            if customer_names:
                response_data["customer_names"] = customer_names
            else:
                response_data["customer_names"] = []

        billing_account_number = []
        if parent_tenant_id and role_name != "Super Admin":
            # 1. Get customer group from user table
            user_data = common_utils_database.get_data(
                "users", 
                {"username": username}, 
                ["customer_group"]
            )
            
            if not user_data.empty:
                customer_group = user_data['customer_group'].iloc[0]
                
                if customer_group:
                    if parent_tenant_id:
                        tenant_id = parent_tenant_id
                    # 2. Get billing account numbers from customergroups table
                    group_data = database.get_data(
                        "customergroups",
                        {"name": customer_group,"tenant_id": tenant_id},
                        ["billing_account_number"]
                    )
                    
                    if not group_data.empty:
                        # Get the billing account numbers string
                        billing_account_str = group_data['billing_account_number'].iloc[0]
                        
                        # Directly use the string as is
                        billing_account_number = [billing_account_str] if billing_account_str else []
                    else:
                        billing_account_number = []
        else:
            billing_data_query = """SELECT distinct billing_account_number FROM public.sim_management_inventory where is_active=True and ban_status in ('Active','active') and billing_account_number is not null order by billing_account_number asc
            """
            billing_account_number = database.execute_query(
                billing_data_query, True
            )["billing_account_number"].to_list()

        if billing_account_number:

            response_data["billing_account_number"] = billing_account_number
        else:
            response_data["billing_account_number"] = []
        
        # if parent_tenant_id and role_name != "Super Admin":
        #    # 1. Get customer group from user table
        #     user_data = common_utils_database.get_data(
        #         "users", 
        #         {"username": username}, 
        #         ["customer_group"]
        #     )
            
        #     if not user_data.empty:
        #         customer_group = user_data['customer_group'].iloc[0]
                
        #         if customer_group:
        #             if parent_tenant_id:
        #                 tenant_id = parent_tenant_id
        #             # 2. Get billing account numbers from customergroups table
        #             group_data = database.get_data(
        #                 "customergroups",
        #                 {"name": customer_group,"tenant_id": tenant_id},
        #                 ["billing_account_number"]
        #             )
                    
        #             if not group_data.empty:
        #                 # Get the billing account numbers string
        #                 billing_account_str = group_data['billing_account_number'].iloc[0]
                        
        #                 # Directly use the string as is
        #                 response_data["billing_account_number"] = [billing_account_str] if billing_account_str else []
        #             else:
        #                 response_data["billing_account_number"] = []
        #         else:
        #             response_data["billing_account_number"] = []
        #     else:
        #         response_data["billing_account_number"] = []

        if parent_tenant_id and role_name != "Super Admin":
            customer_rate_plan_query = f"""SELECT distinct rate_plan_name FROM public.customerrateplan where is_active=True and tenant_id={tenant_id} order by rate_plan_name asc
            """
        else:
            customer_rate_plan_query = f"""SELECT distinct rate_plan_name FROM public.customerrateplan where is_active=True and tenant_id={tenant_id} order by rate_plan_name asc
            """
        customer_rate_plan = database.execute_query(
            customer_rate_plan_query, True
        )["rate_plan_name"].to_list()

        if customer_rate_plan:
            response_data["rate_plan_name"] = customer_rate_plan
        else:
            response_data["rate_plan_name"] = []


        notifications_data_query = """SELECT distinct name FROM public.rule_rule_definition where is_active=True order by name asc
        """
        notification_rules = database.execute_query(
            notifications_data_query, True
        )["name"].to_list()

        if notification_rules:
            response_data["notification_rules"] = notification_rules
        else:
            response_data["notification_rules"] = []

        response_data = serialize_data(response_data)

        response = {"flag": True, "message": "Data fetched successfully", "data": response_data, "tenant_details":tenant_details}

        try:
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "get_submit_customer_group_dropdown_details",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": partner,
                "module_name": "Module Management",
                "comments": f"Customer Groups Dropdown Data fetched successfully for module : {module_name}",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception is {e}")
            
        return response
    
    except Exception as e:
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error in getting Customer Groups Dropdown Data  : {e}")
        message = "Something went wrong while getting Customer Groups Dropdown Data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_submit_customer_group_dropdown_details",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 

        response = {
                "flag": False,
                "message": "Something went wrong while getting Customer Groups Dropdown Data",
                "data": {},
                "tenant_details": {}
            }

        return response


# def get_submit_customer_group_dropdown_details(data):
#     """
#     Retrieves dropdown details related to customer groups, including tenant hierarchy.

#     Args:
#         data (dict): Input dictionary containing:
#             - db_name (str): Name of the tenant database to connect to.
#             - username (str): Username of the requester (optional).
#             - module_name (str): Name of the module requesting data (optional).
#             - tenant_name (str): Tenant's name to retrieve dropdown data for.
#             - role_name (str): Role of the user (e.g., "Super Admin"), defaults to "Super Admin".
#             - sub_tenant_name (str): Sub-tenant to use instead of the main tenant (optional).

#     Returns:
#         dict: A dictionary (`response_data`) with:
#             - tenant_details (dict):
#                 - parent_tenant (list): List containing the parent tenant name (if found).
#                 - sub_tenants (list): Sorted list of active sub-tenant names.
#     """
#     # Record the start time for performance measurement
#     start_time = time.time()
#     session_id = data.get("session_id")
#     tenant_database = data.get("db_name", "")
#     username = data.get("username", "")
#     module_name = data.get("module_name", "")
#     partner = data.get("Partner", "")
#     request_received_at = data.get("request_received_at", "")
#     tenant_name = data.get("tenant_name", "")
#     role_name= data.get("role_name", "Super Admin")
#     sub_tenant_name = data.get("sub_tenant_name", "")
#     try : 
#         # database Connection
#         if role_name=='Super Admin':
#             database = DB(tenant_database, **db_config_withoutfilter)
#         else:
#             database = DB(tenant_database, **db_config)
#         common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)

#         response_data = {}
#         if tenant_name=='Altaworx Test':
#             tenant_name='Altaworx'
#         parent_tenant_id=None
#         # tenant and sub tenants
#         try:
#             parent_tenant_id=common_utils_database.get_data("tenant",{"tenant_name":tenant_name,"is_active":True},["id"])["id"].to_list()[0]
#             if parent_tenant_id:
#                 sub_tenants=common_utils_database.get_data("tenant",{"parent_tenant_id":parent_tenant_id,"is_active":True},["tenant_name"])["tenant_name"].to_list()
#                 parent_tenant=[tenant_name]
#             else:
#                 sub_tenants=[tenant_name]
#                 parent_tenant=[]
#         except Exception as e:
#             logging.exception(f"### get_submit_customer_group_dropdown_details tenant_id exception : {e}")
#             parent_tenant=[]
#             sub_tenants=[]

#         tenant_details={
#             "parent_tenant":parent_tenant,
#             "sub_tenants":sorted(sub_tenants)
#         }
#         response_data["tenant_details"] = tenant_details

#         if sub_tenant_name:
#             tenant_name = sub_tenant_name
#         if tenant_name=='Altaworx Test':
#             tenant_name='Altaworx'
#         tenant_id = common_utils_database.get_data(
#             "tenant", {"tenant_name": tenant_name}, ["id"]
#         )["id"].to_list()[0]



#         soc_codes_pop_up_query = """SELECT distinct(soc_code) FROM public.mobility_feature
#         where soc_code is not null
#         """
#         soc_codes_pop_up_values = database.execute_query(
#             soc_codes_pop_up_query, True
#         )["soc_code"].to_list()
#         # Add SOC codes to the module_data
#         if soc_codes_pop_up_values:

#             response_data["feature_codes"] = soc_codes_pop_up_values
#         else:
#             response_data["feature_codes"] = []
#         # Fetch role module data with efficient query
#         role_module_data = common_utils_database.get_data(
#             "role_module",
#             {"role": role_name},
#             ["sub_module"],
#         )

#         # Initialize default status
#         module_status = False

#         if not role_module_data.empty:
#             try:
#                 # Parse JSON safely with fallback
#                 sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

#                 # Strict nested check
#                 if "People" in sub_modules:
#                     people_modules = sub_modules["People"]
#                     if isinstance(people_modules, list):  # Ensure it's a list
#                         module_status = "Billing Platform Customers" in people_modules

#             except json.JSONDecodeError:
#                 logging.error(f"### Invalid JSON in sub_module for role: {role_name}")
#             except KeyError:
#                 pass  # People section not present
#             except Exception as e:
#                 logging.error(f"### Unexpected error processing modules: {str(e)}")
#         if module_status and tenant_name!='WingTel':
#             # response_data["feature_codes"] = soc_codes_pop_up_values
#             if parent_tenant_id and role_name != "Super Admin":
#                 customers_data_query = f"""SELECT distinct customer_name FROM public.revcustomer where is_active=True and tenant_id={tenant_id}   order by customer_name asc
#                 """
#             else:
#                 customers_data_query = """SELECT distinct customer_name FROM public.revcustomer where is_active=True  order by customer_name asc
#                 """
#         else:
#             if parent_tenant_id and role_name != "Super Admin":
#                 customers_data_query = f"""SELECT distinct customer_name FROM public.customers where is_active=True and tenant_id={tenant_id}  order by customer_name asc
#                 """
#             else:
#                 customers_data_query = """SELECT distinct customer_name FROM public.customers where is_active=True  order by customer_name asc
#                 """

#         customer_names = database.execute_query(
#             customers_data_query, True
#         )["customer_name"].to_list()

#         if customer_names:
#             response_data["customer_names"] = customer_names
#         else:
#             response_data["customer_names"] = []

#         billing_account_number = []
#         if parent_tenant_id and role_name != "Super Admin":
#             # 1. Get customer group from user table
#             user_data = common_utils_database.get_data(
#                 "users", 
#                 {"username": username}, 
#                 ["customer_group"]
#             )
            
#             if not user_data.empty:
#                 customer_group = user_data['customer_group'].iloc[0]
                
#                 if customer_group:
#                     if parent_tenant_id:
#                         tenant_id = parent_tenant_id
#                     # 2. Get billing account numbers from customergroups table
#                     group_data = database.get_data(
#                         "customergroups",
#                         {"name": customer_group,"tenant_id": tenant_id},
#                         ["billing_account_number"]
#                     )
                    
#                     if not group_data.empty:
#                         # Get the billing account numbers string
#                         billing_account_str = group_data['billing_account_number'].iloc[0]
                        
#                         # Directly use the string as is
#                         billing_account_number = [billing_account_str] if billing_account_str else []
#                     else:
#                         billing_account_number = []
#         else:
#             billing_data_query = """SELECT distinct billing_account_number FROM public.sim_management_inventory where is_active=True and ban_status in ('Active','active') and billing_account_number is not null order by billing_account_number asc
#             """
#             billing_account_number = database.execute_query(
#                 billing_data_query, True
#             )["billing_account_number"].to_list()

#         if billing_account_number:

#             response_data["billing_account_number"] = billing_account_number
#         else:
#             response_data["billing_account_number"] = []
        
#         # if parent_tenant_id and role_name != "Super Admin":
#         #    # 1. Get customer group from user table
#         #     user_data = common_utils_database.get_data(
#         #         "users", 
#         #         {"username": username}, 
#         #         ["customer_group"]
#         #     )
            
#         #     if not user_data.empty:
#         #         customer_group = user_data['customer_group'].iloc[0]
                
#         #         if customer_group:
#         #             if parent_tenant_id:
#         #                 tenant_id = parent_tenant_id
#         #             # 2. Get billing account numbers from customergroups table
#         #             group_data = database.get_data(
#         #                 "customergroups",
#         #                 {"name": customer_group,"tenant_id": tenant_id},
#         #                 ["billing_account_number"]
#         #             )
                    
#         #             if not group_data.empty:
#         #                 # Get the billing account numbers string
#         #                 billing_account_str = group_data['billing_account_number'].iloc[0]
                        
#         #                 # Directly use the string as is
#         #                 response_data["billing_account_number"] = [billing_account_str] if billing_account_str else []
#         #             else:
#         #                 response_data["billing_account_number"] = []
#         #         else:
#         #             response_data["billing_account_number"] = []
#         #     else:
#         #         response_data["billing_account_number"] = []

#         if parent_tenant_id and role_name != "Super Admin":
#             customer_rate_plan_query = f"""SELECT distinct rate_plan_name FROM public.customerrateplan where is_active=True and tenant_id={tenant_id} order by rate_plan_name asc
#             """
#         else:
#             customer_rate_plan_query = f"""SELECT distinct rate_plan_name FROM public.customerrateplan where is_active=True and tenant_id={tenant_id} order by rate_plan_name asc
#             """
#         customer_rate_plan = database.execute_query(
#             customer_rate_plan_query, True
#         )["rate_plan_name"].to_list()

#         if customer_rate_plan:
#             response_data["rate_plan_name"] = customer_rate_plan
#         else:
#             response_data["rate_plan_name"] = []


#         notifications_data_query = """SELECT distinct name FROM public.rule_rule_definition where is_active=True order by name asc
#         """
#         notification_rules = database.execute_query(
#             notifications_data_query, True
#         )["name"].to_list()

#         if notification_rules:
#             response_data["notification_rules"] = notification_rules
#         else:
#             response_data["notification_rules"] = []

#         response_data = serialize_data(response_data)

#         response = {"flag": True, "message": "Data fetched successfully", "data": response_data, "tenant_details":tenant_details}

#         try:
#             end_time = time.time()
#             time_consumed = f"{end_time - start_time:.4f}"
#             time_consumed = int(float(time_consumed))
#             audit_data_user_actions = {
#                 "service_name": "get_submit_customer_group_dropdown_details",
#                 "created_by": data.get("username", ""),
#                 "status": str(response['flag']),
#                 "time_consumed_secs": time_consumed,
#                 "session_id": session_id,
#                 "tenant_name": partner,
#                 "module_name": "Module Management",
#                 "comments": f"Customer Groups Dropdown Data fetched successfully for module : {module_name}",
#                 "request_received_at": request_received_at,
#             }
#             common_utils_database.update_audit(
#                 audit_data_user_actions, "audit_user_actions"
#             )
#         except Exception as e:
#             logging.warning(f"### Exception is {e}")
            
#         return response
    
#     except Exception as e:
#         # Handle any exceptions that occur during data retrieval
#         logging.exception(f"### error in getting Customer Groups Dropdown Data  : {e}")
#         message = "Something went wrong while getting Customer Groups Dropdown Data"
#         error_type = str(type(e).__name__)
#         try:
#             # Log error to database
#             error_data = {
#                 "service_name": "get_submit_customer_group_dropdown_details",
#                 "error_message":str(e),
#                 "error_type": error_type,
#                 "users": data.get("username", ""),
#                 "session_id": data.get("sessionID", ""),
#                 "tenant_name": data.get("Partner", ""),
#                 "comments": message ,
#                 "module_name": "Module management",
#                 "request_received_at": data.get("request_received_at", ""),
#             }
#             common_utils_database.log_error_to_db(error_data, "error_log_table")
#         except Exception as e:
#             logging.error(f"### Exception while updating audit and exception is:  {e}") 

#         response = {
#                 "flag": False,
#                 "message": "Something went wrong while getting Customer Groups Dropdown Data",
#                 "data": {},
#                 "tenant_details": {}
#             }

#         return response


def get_user_info_details(data):
    """
    Retrieves user-specific dropdown details such as customer group, service provider, and customer list
    based on the partner name and username.

    Args:
        data (dict): Input dictionary containing:
            - partner_name (str): The partner/tenant name.
            - username (str): The username to fetch details for.

    Returns:
        dict: Response dictionary with the following structure:
            - flag (bool): Indicates success or failure.
            - message (str): Status message.
            - data (dict): Reserved for future use (currently empty).
            - pages (dict): Reserved for future use (currently empty).
            - features (dict): Reserved for future use (currently empty).
            - dropdown (dict): Contains:
                - customer_group (str)
                - service_provider (list)
                - customers (list)
    """
    common_utils_database = DB('common_utils', **db_config_withoutfilter)
    partner_name=data.get("partner_name",'')
    username = data.get("username", "")

    try :
        # get the db_name
        if partner_name:
            try:
                tenant_id=common_utils_database.get_data("tenant", {"tenant_name": partner_name}, ["id"])[
                "id"
            ].to_list()[0]
            except Exception as e:
                tenant_id=''
                logging.info(f"### Error:{e}")
        else:
            tenant_id=''
        logging.info(f'### tenant_id - {tenant_id}')
        if tenant_id:
            # get customer_group, service_provider and customers from user_module_tenant_mapping
            try:
                data = common_utils_database.get_data(
                    "user_module_tenant_mapping",
                    {"tenant_id": tenant_id,"user_name": username},
                    ["customer_group","service_provider", "customers"],
                )
                if not data.empty:
                    customer_group = data["customer_group"].iloc[0]
                    service_provider = data["service_provider"].iloc[0]
                    customers = data["customers"].iloc[0]
                else:
                    customer_group = ""
                    service_provider = []
                    customers = []
            except Exception as e:
                customer_group = ""
                service_provider = []
                customers = []
                logging.info(f"### Error:{e}")

            dropdown = {
                "customer_group": customer_group,
                "service_provider": service_provider,
                "customers": customers,
            }
            response = {
                "flag": True,
                "message":"Data Fetched Succesfully",
                "data": {},
                "pages": {},
                "features": {},
                "dropdown": dropdown
            }
            # return response
        else:
            response = {
                "flag": False,
                "message":"Not db found"
            }
            # return response

        try:
            audit_data_user_actions = {
                "service_name": "get_user_info_details",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": "user info details Data fetched successfully",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
 
        return response

    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error occurred in getting user info details Data  : {e}")
        message = "Something went wrong while getting user info details Data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_user_info_details",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            

        response = {
                "flag": True,
                "message": "Something went wrong while getting Customer Groups Dropdown Data",
                "data": {},
                "pages": {},
                "features": {},
                "dropdown": {
                    "customer_group": "",
                    "service_provider": None,
                    "customers": None
                }
            }

        return response


def update_customer_info_tenant_based(data):
    """
    Updates customer information in the `user_module_tenant_mapping` table for a given tenant.

    This function:
    - Retrieves the tenant ID using the provided `partner_name`.
    - Extracts the `customer_info` dictionary from the input, converting any list values to JSON strings.
    - Removes the `username` key from the `customer_info` dict and uses it to locate the user record.
    - Performs an update operation in the `user_module_tenant_mapping` table.

    Args:
        data (dict): Input dictionary with the following keys:
            - partner_name (str): Name of the partner/tenant.
            - changed_data (dict): Dictionary containing:
                - customer_info (dict): Fields to update along with a mandatory "username" key.

    Returns:
        dict: A dictionary with:
            - flag (bool): Indicates success or failure.
            - message (str): Success or error message.
    """
    try:
        # Initialize DB connection
        common_utils_database = DB('common_utils', **db_config)

        # Extract tenant ID
        partner_name = data.get("partner_name", "")
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": partner_name}, ["id"]
        )["id"].to_list()[0]

        # Extract changed data and username
        customer_info = data.get("changed_data", {}).get("customer_info", {})
        # Convert all list-type fields in customer_info to JSON strings
        for key, value in customer_info.items():
            if isinstance(value, list):
                customer_info[key] = json.dumps(value)
        user_name = customer_info.pop("username", "")  # Remove username from update dict

        # Update DB
        common_utils_database.update_dict(
            "user_module_tenant_mapping",
            customer_info,
            {"tenant_id": tenant_id, "user_name": user_name}
        )

        message = f'User {user_name} updated successfully in user_module_tenant_mapping table for tenant_id {tenant_id}'
        response = {"flag": True, "message": message} 
        try:
            audit_data_user_actions = {
                "service_name": "update_customer_info_tenant_based",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": f"Updating customer info for tenant '{data.get('Partner', '')}' and user '{data.get('username', '')}'",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")

        return response

    # except Exception as e:
    #     logging.exception("### Error updating user info")
    #     return {
    #         "flag": False,
    #         "message": "Unable to save the data into user_module_tenant_mapping table"
    #     } 

    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### Error occurred while updating customer info for tenant '{data.get('Partner', '')}' and user '{data.get('username', '')}': {e}")
        message = f"Something went wrong while updating customer info for tenant '{data.get('Partner', '')}'"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "update_customer_info_tenant_based",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            

        response = {
            "flag": False,
            "message": "Unable to save the data into user_module_tenant_mapping table",
            "data": {},
            "dropdown": {}
        }

        return response 

def customer_info_dropdown(data):
    """
    Retrieves a dropdown list of customers based on the user's role, partner, and module access.

    Args:
        data (dict): A dictionary containing:
            - partner_name (str): The name of the partner or tenant.
            - role_name (str): The role of the user (used to determine module access).
            - tenant_name (str): The name of the tenant (not directly used for DB switch).

    Returns:
        dict: A dictionary with:
            - flag (bool): True if customer list is fetched successfully, False otherwise.
            - message (str): Status message of the operation.
            - data (dict): Empty (reserved for future use).
            - pages (dict): Empty (reserved for future use).
            - features (dict): Empty (reserved for future use).
            - dropdown (dict): Contains:
                - customers (list): List of unique, sorted active customer names.
    """
    try:
        del db_config['service_providers']
        del db_config['tenant_ids']
        del db_config['customer_rate_plan_name']
    except Exception as e:
        logging.exception(f"### Failed to delete the db_config : {e}")
    common_utils_database = DB('common_utils', **db_config_withoutfilter)
    try :     
        partner_name=data.get("partner_name",'')
        role_name=data.get('role_name','')
        # tenant_name=data.get('tenant_name','')
        role_module_data = common_utils_database.get_data(
            "role_module",
            {"role": role_name},
            ["sub_module"],
        )

        # Initialize default status
        module_status = False

        if not role_module_data.empty:
            try:
                # Parse JSON safely with fallback
                sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                # Strict nested check
                if "People" in sub_modules:
                    people_modules = sub_modules["People"]
                    if isinstance(people_modules, list):  # Ensure it's a list
                        module_status = "Billing Platform Customers" in people_modules

            except json.JSONDecodeError:
                logging.error(f"### Invalid JSON in sub_module for role: {role_name}")
            except KeyError:
                pass  # People section not present
            except Exception as e:
                logging.error(f"### Unexpected error processing modules: {str(e)}")
        # get the db_name
        if partner_name:
            try:
                db_name_data=common_utils_database.get_data("tenant",{"tenant_name":partner_name},["db_name", "id"])
                db_name = db_name_data["db_name"].to_list()[0]
                tenant_id = db_name_data["id"].to_list()[0]
            except Exception as e:
                db_name=''
                logging.info(f"### Error:{e}")
        else:
            db_name=''


        if db_name:
            partner_db=DB(db_name, **db_config)
            if module_status and partner_name!='WingTel':
                # get customer from users table
                try:
                    customers=partner_db.get_data("revcustomer",{"is_active":True, "tenant_id":tenant_id},["customer_name"],{"customer_name":"asc"})["customer_name"].to_list()
                    customers = sorted(set(filter(None, customers)))
                except Exception as e:
                    customers=[]
                    logging.info(f"### Error:{e}")
            else:
                # get customer from users table
                try:
                    customers=partner_db.get_data("customers",{"is_active":True, "tenant_id":tenant_id},["customer_name"],{"customer_name":"asc"})["customer_name"].to_list()
                    customers = sorted(set(filter(None, customers)))
                except Exception as e:
                    customers=[]
                    logging.info(f"### Error:{e}")

            dropdown={
                "customers":customers
            }


            response = {
                "flag": True,
                "message":"Data Fetched Successfully",
                "data": {},
                "pages": {},
                "features": {},
                "dropdown": dropdown
            }
            # return response
        else:
            response = {
                "flag": False,
                "message":"Not db found"
            }
            # return response  
        try:
            audit_data_user_actions = {
                "service_name": "customer_info_dropdown",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": "customer info dropdown Data fetched successfully",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
 
        return response     

    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error in getting customer info dropdown Data  : {e}")
        message = "Something went wrong while getting customer info dropdown Data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "customer_info_dropdown",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            

        response = {
            "flag": True,
            "message": "Something went wrong while getting customer info dropdown Data",
            "data": {},
            "pages": {},
            "features": {},
            "dropdown": {
                "customers": []
            }
        }
        return response  

def serviceprovider_info_dropdown(data):
    """
    Fetches a dropdown list of active service providers for the given partner.

    This function performs the following operations:
    - Extracts the partner's database name from the common_utils tenant table.
    - Connects to the partner-specific database.
    - Retrieves a list of active service providers sorted alphabetically.

    Args:
        data (dict): A dictionary containing:
            - partner_name (str): Name of the partner for which service provider data is required.

    Returns:
        dict: A dictionary with:
            - flag (bool): True if data is fetched successfully, False otherwise.
            - message (str): Status message of the operation.
            - dropdown (dict, optional): Contains a list of service providers under the key 'serviceprovider'.
    """
    try:
        del db_config['customers']
        del db_config['tenant_ids']
        del db_config['customer_rate_plan_name']
    except Exception as e:
        logging.exception(f"### Failed to delete the db_config : {e}")
    common_utils_database = DB('common_utils', **db_config)
    partner_name=data.get("partner_name",'')
    try : 
    # get the db_name
        if partner_name:
            try:
                db_name=common_utils_database.get_data("tenant",{"tenant_name":partner_name},["db_name"])["db_name"].to_list()[0]
            except Exception as e:
                db_name=''
                logging.info(f"### Error:{e}")
        else:
            db_name=''


        if db_name:
            partner_db=DB(db_name, **db_config)


            # get customer from users table
            try:
                serviceprovider=partner_db.get_data("serviceprovider",{"is_active":True},["service_provider_name"],order={"service_provider_name":"asc"})["service_provider_name"].to_list()
                serviceprovider = sorted(set(filter(None, serviceprovider)))
            except Exception as e:
                serviceprovider=[]
                logging.info(f"### Error:{e}")


            dropdown={
                "serviceprovider":serviceprovider,
            }


            response = {
                "flag": True,
                "message":"Data Fetched Succesfully",
                "data": {},
                "pages": {},
                "features": {},
                "dropdown": dropdown
            }
            # return response
        else:
            response = {
                "flag": False,
                "message":"Not db found"
            }
            # return response

        try:
            audit_data_user_actions = {
                "service_name": "serviceprovider_info_dropdown",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": "service provider info dropdown Data fetched successfully",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
 
        return response    

    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error in getting service provider info dropdown Data  : {e}")
        message = "Something went wrong while getting service provider info dropdown Data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "serviceprovider_info_dropdown",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            

        response = {
                "flag": True,
                "message": "Something went wrong while getting Service Provider Dropdown Data",
                "data": {},
                "pages": {},
                "features": {},
                "dropdown": []
            }
        return response

def customer_group_info_dropdown(data):
    """
    Retrieves a dropdown list of active customer groups based on the user's role and mapping.

    This function performs the following operations:
    - Extracts the partner's database name and tenant ID from the common_utils.tenant table.
    - Checks the user-to-tenant mapping to determine assigned customer groups.
    - Connects to the partner-specific database.
    - Fetches a list of active customer groups based on the user's role and permissions.

    Args:
        data (dict): A dictionary containing:
            - partner_name (str): Name of the partner.
            - username (str): Username of the logged-in user.
            - role_name (str): Role assigned to the user (e.g., Super Admin, Partner Admin).

    Returns:
        dict: A response dictionary containing:
            - flag (bool): Indicates success (True) or failure (False).
            - message (str): Message describing the outcome.
            - dropdown (dict, optional): Contains a list of customer groups under the key 'customergroups' if successful.
    """
    role_name=data.get('role_name','')
    common_utils_database = DB('common_utils', **db_config_withoutfilter)
    partner_name=data.get("partner_name",'')
    username=data.get('username','')

    try :
        # get the db_name
        if partner_name:
            try:
                tenant_data=common_utils_database.get_data("tenant",{"tenant_name":partner_name},["db_name","id"])
                db_name=tenant_data["db_name"].to_list()[0]
                tenant_id=tenant_data["id"].to_list()[0]

            except Exception as e:
                db_name=''
                tenant_id=None
                logging.info(f"### Error:{e}")
            try:
                query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{username}' and tenant_id={tenant_id}"
                filters = common_utils_database.execute_query(query, True)
                try:
                    customer_group = filters["customer_group"].to_list()[0]
                except Exception as e:
                    logging.error(f"### Failed to determine customer_group: {e}")
                    customer_group = None
            except Exception as e:
                logging.exception(f"### Exception while fetching the customer_Group : {e}")
                customer_group = None

        else:
            db_name=''


        if db_name:
            partner_db=DB(db_name, **db_config_withoutfilter)
            if role_name=='Super Admin' and not customer_group:
                # get customer from users table
                try:
                    customergroups=partner_db.get_data("customergroups",{"is_active":True},["name"],{"name":"asc"})["name"].to_list()
                    customergroups = sorted(set(filter(None, customergroups)))
                except Exception as e:
                    customergroups=[]
                    logging.info(f"### Error:{e}")
            else:
                try:
                    customergroups=partner_db.get_data("customergroups",{"is_active":True},["name"],{"name":"asc"})["name"].to_list()
                    customergroups = sorted(set(filter(None, customergroups)))
                except Exception as e:
                    customergroups=[]
                    logging.info(f"### Error:{e}")


            dropdown={
                "customergroups":customergroups
            }


            response = {
                "flag": True,
                "message":"Data Fetched Successfully",
                "data": {},
                "pages": {},
                "features": {},
                "dropdown": dropdown
            }
            # return response
        else:
            response = {
                "flag": False,
                "message":"Not db found"
            }
            # return response

        try:
            audit_data_user_actions = {
                "service_name": "customer_group_info_dropdown",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": "customer group info dropdown Data fetched successfully",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
 
        return response


    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error in getting customer group info dropdown Data  : {e}")
        message = "Something went wrong while getting customer group info dropdown Data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "customer_group_info_dropdown",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            
        response = {
                "flag": True,
                "message": "Something went wrong while getting Customer Groups Dropdown Data",
                "data": {},
                "dropdown": []
            }
        return response 

def update_tenant_based_partner_admin_filters(data):
    """
    Updates or creates tenant-based partner admin filters and associated data.

    This function handles:
    - Creating/updating partner admin filters in the database
    - Syncing customer rate plans from main tenant to sub-tenant
    - Syncing SIM inventory data from main tenant to sub-tenant
    - Creating default 'Unassigned' customer records
    - Triggering API calls for data synchronization

    Args:
        data (dict): A dictionary containing:
            - tenant_name (str): Name of the sub-tenant
            - main_tenant_name (str): Name of the main tenant (default 'Altaworx')
            - username (str): Username performing the operation
            - action (str): 'create' or 'update' action
            - customers_data (dict): Filter configuration data including:
                - customers (list): List of customer names
                - service_provider (list): List of service providers
                - customer_group (str): Customer group name
                - Other filter fields (rate_plan_name, feature_codes, etc.)

    Returns:
        dict: A dictionary with:
            - flag (bool): True if operation succeeded, False otherwise
            - message (str): Status message
    """
    common_utils_database = DB('common_utils', **db_config_withoutfilter)
    try:
        tenant_name=data.get('tenant_name','')
        main_tenant_name=data.get('main_tenant_name','Altaworx')
        if main_tenant_name=='Altaworx Test':
            main_tenant_name='Altaworx'
        main_tenant_id=common_utils_database.get_data("tenant",{"tenant_name":main_tenant_name},["id"])["id"].to_list()[0]
        username=data.get('username')
        action=data.get('action','')
        # get the db_name
        customers_data=data.get('customers_data','')
        customers=customers_data.get('customers',[])
        service_provider=customers_data.get('service_provider',[])
        tenant_data = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name},
        ["id", "db_name"]
        )
        api_url = os.getenv("OPTIMIZATIONSYNCURL", " ")
        api_payload = {
            "data":{'path': '/lambda_sync_jobs_', 'key_name': 'tenant_insert', 'tenant_name':tenant_name }
        }
        customers_api_payload = {
            "data":{'path': '/lambda_sync_jobs_', 'key_name': 'customers_sub_tenant_insert', 'tenant_name':tenant_name }
        }
        customer_rate_plan_api_payload = {
            "data":{'path': '/lambda_sync_jobs_', 'key_name': 'customer_rate_plan_sync', 'tenant_name':tenant_name }
        }
        customer_id=None
        tenant_id = tenant_data["id"].to_list()[0]
        db_name = tenant_data["db_name"].to_list()[0]
        database = DB(db_name, **db_config_withoutfilter)
        tenant_id=int(tenant_id)
        # Keys to treat as JSON lists
        json_keys = ['customer_names', 'rate_plan_name', 'feature_codes', 'notification_rules','service_provider','customers']

        # Get customer group data
        customer_group = customers_data.get('customer_group', '')
        customer_groups_data_query = f'''
            SELECT customer_names, rate_plan_name, feature_codes, billing_account_number, notification_rules
            FROM customergroups
            WHERE name = '{customer_group}'
        '''
        customer_groups_data_df = database.execute_query(customer_groups_data_query, True)

        if not customer_groups_data_df.empty:
            customer_group_data = customer_groups_data_df.iloc[0].to_dict()

            # Convert JSON strings to Python lists
            for key in json_keys:
                if customer_group_data.get(key):
                    customer_group_data[key] = json.loads(customer_group_data[key])

            customers_data.update(customer_group_data)

            additional_fields = {
                "username": username,
                "tenant_id": tenant_id,
                "role_name": "Partner Admin","tenant_name":tenant_name
            }
            customers_data.update(additional_fields)

            # Convert all list-type fields to JSON strings for DB storage
            for key, value in customers_data.items():
                if isinstance(value, list):
                    customers_data[key] = json.dumps(value)

            if action == 'create':
                common_utils_database.insert_data(
                    customers_data, 'tenant_based_partner_admin_filters'
                )
                customer_rate_plan= customers_data.get('rate_plan_name', [])
                if customer_rate_plan:
                    if isinstance(customer_rate_plan, str):
                        try:
                            customer_rate_plan = json.loads(customer_rate_plan)
                        except Exception as e:
                            logging.exception(f"### update_tenant_based_partner_admin_filters customer_rate_plan json exception {e}")
                            customer_rate_plan = [customer_rate_plan]
                    # Ensure lists
                    if not isinstance(customer_rate_plan, list):
                        customer_rate_plan = [customer_rate_plan] if customer_rate_plan else []
                    quoted_customer_rate_plans = ', '.join([f"'{c}'" for c in customer_rate_plan])
                    existed_customer_rate_plans_query = f'''select distinct rate_plan_name
                                     from customerrateplan
                                    WHERE rate_plan_name IN ({quoted_customer_rate_plans})
                                    AND is_active = TRUE
                                    AND tenant_id = {tenant_id}
                                    ;
                                '''
                    existed_rate_plans=database.execute_query(existed_customer_rate_plans_query,True)['rate_plan_name'].to_list()
                    logging.info(f"### existed_rate_plans: {existed_rate_plans}")
                    remaining_rate_plans = [c for c in customer_rate_plan if c not in existed_rate_plans]
                    logging.info(f"### remaining_rate_plans : {remaining_rate_plans}")

                    if remaining_rate_plans:
                        remaining_rate_plans = ', '.join([f"'{c}'" for c in remaining_rate_plans])
                        rate_plan_data_query = f'''select *
                                        from customerrateplan
                                        WHERE rate_plan_name IN ({remaining_rate_plans})
                                        AND is_active = TRUE
                                        AND tenant_id = {main_tenant_id}
                                        ;
                                    '''
                        rate_plan_data=database.execute_query(rate_plan_data_query,True)
                        rate_plan_data = handle_date_and_nat_columns(rate_plan_data)
                        rate_plan_data['tenant_id'] = tenant_id
                        rate_plan_data['created_by'] = username
                        rate_plan_data.drop(['id', 'id_10','created_date','modified_date'], axis=1, inplace=True)
                        rate_plan_data = format_data_for_dict(rate_plan_data.to_dict(orient="records"))
                        rate_plan_data = format_data_for_dict(rate_plan_data)
                        #database.insert_data(rate_plan_data, 'customerrateplan')
                        try:
                            response = requests.post(api_url, json=customer_rate_plan_api_payload)
                            if response.status_code == 200:
                                # Get the current timestamp
                                #current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                                # Log the message with the timestamp

                                logging.info("### Customers API call successful.Data synn call is succssefully done ")
                            else:
                                logging.error(
                                    f"### API call failed with statudafdfadsfs code: {response.status_code}"
                                )
                        except Exception as e:
                            logging.error(f"### Error making API call: {e}")
                customers = customers_data.get('customers', [])
                customers_names= customers_data.get('customer_names', [])
                # Convert stringified lists to actual lists
                if isinstance(customers_names, str):
                    try:
                        customers_names = json.loads(customers_names)
                    except Exception as e:
                        logging.exception(f"### update_tenant_based_partner_admin_filters customers_names json exception {e}")
                        customers_names = [customers_names]

                if isinstance(customers, str):
                    try:
                        customers = json.loads(customers)
                    except Exception as e:
                        logging.exception(f"### update_tenant_based_partner_admin_filters customers json exception {e}")
                        customers = [customers]

                # Ensure lists
                if not isinstance(customers_names, list):
                    customers_names = [customers_names] if customers_names else []

                if not isinstance(customers, list):
                    customers = [customers] if customers else []

                # Combine and quote
                user_customers = customers_names + customers
                quoted_customers = ', '.join([f"'{c}'" for c in user_customers])
                logging.info(f'### customers_names : {customers_names}  customers  : {customers}')
                service_provider_condition = ''
                if service_provider:
                    quoted_service_provider = ', '.join([f"'{c}'" for c in service_provider])
                    service_provider_condition = f"AND service_provider_display_name IN ({quoted_service_provider})"
                # Combine both safely
                # user_customers = customers_names + customers
                # quoted_customers = ', '.join([f"'{c}'" for c in user_customers])
                logging.info('### quoted_customers : {quoted_customers}')
                existed_customers_query = f'''select distinct iccid
                                     from sim_management_inventory
                                    where is_active = TRUE
                                    AND tenant_id = {tenant_id}
                                    ;
                                '''
                existed_iccids=database.execute_query(existed_customers_query,True)['iccid'].to_list()
                logging.info(f"### existed_iccids : {existed_iccids}")
                new_iccids_customers_query = f'''select  iccid
                                     from sim_management_inventory
                                    WHERE customer_name IN ({quoted_customers})
                    AND is_active = TRUE
                    AND tenant_id = {main_tenant_id} {service_provider_condition}

                                '''
                new_iccids=database.execute_query(new_iccids_customers_query,True)['iccid'].to_list()
                logging.info(f"### new_iccids : {new_iccids}")
                remaining_iccids = [c for c in new_iccids if c not in existed_iccids]
                logging.info(f"### remaining_iccids : {remaining_iccids}")
                remaining_iccids = ', '.join([f"'{c}'" for c in remaining_iccids])
                inventory_data = f'''select device_id,
                    mobility_device_id,tenant_id,rev_service_id,customer_rate_plan_id,customer_data_allocation_mb,customer_rate_pool_id,
                    account_number,customer_id,account_number_integration_authentication_id,created_by,created_date,
                    modified_by,modified_date,deleted_by,deleted_date,is_active,is_deleted,customer_rate_pool_name,customer_rate_plan_name,customer_name,service_provider_display_name from sim_management_inventory
                    WHERE iccid IN ({remaining_iccids})
                    AND is_active = TRUE
                    AND tenant_id = {main_tenant_id} and customer_name IN ({quoted_customers}) {service_provider_condition}
                    ;
                '''
                inventory_data=database.execute_query(inventory_data,True)
                inventory_data['tenant_id'] = tenant_id

                existinct_customer=f'{tenant_name} - Unassigned'
                exist_customer_query=f'''select id from customers where customer_name='{existinct_customer}'
                '''
                exist_customer=database.execute_query(exist_customer_query,True)
                if not exist_customer.empty:
                    customer_id=exist_customer['id'].to_list()[0]
                else:
                    customers_data={"customer_name":existinct_customer,"tenant_id":tenant_id,"created_by":username,"tenant_name":tenant_name,"is_active":True,"is_deleted":False}
                    customer_id=database.insert_data(customers_data, 'customers')
                    logging.info("### customer_id : {customer_id}")
                    try:
                        response = requests.post(api_url, json=customers_api_payload)
                        if response.status_code == 200:
                            # Get the current timestamp
                            #current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                            # Log the message with the timestamp

                            logging.info("### Customers API call successful.Data synn call is succssefully done ")
                        else:
                            logging.error(
                                f"### API call failed with statudafdfadsfs code: {response.status_code}"
                            )
                    except Exception as e:
                        logging.error(f"### Error making API call: {e}")
                inventory_data['customer_name'] = existinct_customer
                logging.info(f'### coming customer_id is : {customer_id}')
                inventory_data['customer_id'] = customer_id
                inventory_data['created_by'] = username

                try:
                    inventory_data = handle_date_and_nat_columns(inventory_data)
                except Exception as e:
                    logging.error(f"### Error handling date and nat columns: {e}")
                if not inventory_data.empty:
                    # List of service provider names for Telegence-related records
                    telegence_providers = ['AT&T - Telegence', 'AT&T - Telegence - UAT ONLY','AT&T - eBonding']

                    # Filter for Telegence-related records
                    telegence_df = inventory_data[inventory_data['service_provider_display_name'].isin(telegence_providers)].copy()

                    # Everything else goes to device_df
                    device_df = inventory_data[~inventory_data['service_provider_display_name'].isin(telegence_providers)].copy()

                    # Process Telegence data
                    if not telegence_df.empty:
                        telegence_df.drop(['service_provider_display_name', 'device_id','created_date','modified_date'], axis=1, inplace=True)
                        formatted_telegence = format_data_for_dict(telegence_df.to_dict(orient="records"))
                        formatted_telegence = format_data_for_dict(formatted_telegence)
                        database.insert_data(formatted_telegence, 'mobility_device_tenant')

                    # Process other providers
                    if not device_df.empty:
                        device_df.drop(['service_provider_display_name', 'mobility_device_id','created_date','modified_date'], axis=1, inplace=True)
                        formatted_others = format_data_for_dict(device_df.to_dict(orient="records"))
                        formatted_device = format_data_for_dict(formatted_others)
                        database.insert_data(formatted_device, 'device_tenant')
                try:
                    response = requests.post(api_url, json=api_payload)
                    if response.status_code == 200:
                        # Get the current timestamp
                        #current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                        # Log the message with the timestamp

                        logging.info("### API call successful.Data synn call is succssefully done ")
                    else:
                        logging.error(
                            f"### API call failed with statudafdfadsfs code: {response.status_code}"
                        )
                except Exception as e:
                    logging.error(f"### Error making API call: {e}")
                response = {"flag": True, "message": "tenant based partner admin filters created successfully"}
                # return response
            else:
                try:
                    common_utils_database.update_dict(
                        'tenant_based_partner_admin_filters',
                        customers_data,
                        {"username": username, "tenant_id": tenant_id}
                    )
                except Exception as e:
                    logging.error(f"### Error updating tenant_based_partner_admin_filters: {e}")
                customers = customers_data.get('customers', [])
                customers_names= customers_data.get('customer_names', [])
                customer_rate_plan= customers_data.get('rate_plan_name', [])
                if customer_rate_plan:
                    if isinstance(customer_rate_plan, str):
                        try:
                            customer_rate_plan = json.loads(customer_rate_plan)
                        except Exception as e:
                            logging.exception(f"### update_tenant_based_partner_admin_filters customer_rate_plan json exception {e}")
                            customer_rate_plan = [customer_rate_plan]
                    # Ensure lists
                    if not isinstance(customer_rate_plan, list):
                        customer_rate_plan = [customer_rate_plan] if customer_rate_plan else []
                    quoted_customer_rate_plans = ', '.join([f"'{c}'" for c in customer_rate_plan])
                    existed_customer_rate_plans_query = f'''select distinct rate_plan_name
                                     from customerrateplan
                                    WHERE rate_plan_name IN ({quoted_customer_rate_plans})
                                    AND is_active = TRUE
                                    AND tenant_id = {tenant_id}
                                    ;
                                '''
                    existed_rate_plans=database.execute_query(existed_customer_rate_plans_query,True)['rate_plan_name'].to_list()
                    logging.info(f"### existed_rate_plans : {existed_rate_plans}")
                    remaining_rate_plans = [c for c in customer_rate_plan if c not in existed_rate_plans]
                    logging.info(f"### remaining_rate_plans : {remaining_rate_plans}")

                    if remaining_rate_plans:
                        remaining_rate_plans = ', '.join([f"'{c}'" for c in remaining_rate_plans])
                        rate_plan_data_query = f'''select *
                                        from customerrateplan
                                        WHERE rate_plan_name IN ({remaining_rate_plans})
                                        AND is_active = TRUE
                                        AND tenant_id = {main_tenant_id}
                                        ;
                                    '''
                        rate_plan_data=database.execute_query(rate_plan_data_query,True)
                        rate_plan_data = handle_date_and_nat_columns(rate_plan_data)
                        rate_plan_data['tenant_id'] = tenant_id
                        rate_plan_data['created_by'] = username
                        rate_plan_data.drop(['id', 'id_10','created_date','modified_date'], axis=1, inplace=True)
                        rate_plan_data = format_data_for_dict(rate_plan_data.to_dict(orient="records"))
                        rate_plan_data = format_data_for_dict(rate_plan_data)
                        #database.insert_data(rate_plan_data, 'customerrateplan')
                        try:
                            response = requests.post(api_url, json=customer_rate_plan_api_payload)
                            if response.status_code == 200:
                                # Get the current timestamp
                                #current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                                # Log the message with the timestamp

                                logging.info("### Customers API call successful.Data synn call is succssefully done ")
                            else:
                                logging.error(
                                    f"### API call failed with statudafdfadsfs code: {response.status_code}"
                                )
                        except Exception as e:
                            logging.error(f"### Error making API call: {e}")
                # Convert stringified lists to actual lists
                if isinstance(customers_names, str):
                    try:
                        customers_names = json.loads(customers_names)
                    except Exception as e:
                        logging.exception(f"### update_tenant_based_partner_admin_filters customers_names json exception {e}")
                        customers_names = [customers_names]

                if isinstance(customers, str):
                    try:
                        customers = json.loads(customers)
                    except Exception as e:
                        logging.exception(f"### update_tenant_based_partner_admin_filters customers json exception {e}")
                        customers = [customers]

                # Ensure lists
                if not isinstance(customers_names, list):
                    customers_names = [customers_names] if customers_names else []

                if not isinstance(customers, list):
                    customers = [customers] if customers else []

                # Combine and quote
                user_customers = customers_names + customers
                quoted_customers = ', '.join([f"'{c}'" for c in user_customers])
                logging.info('### customers_names',customers_names,'customers',customers)
                service_provider_condition = ''
                if service_provider:
                    quoted_service_provider = ', '.join([f"'{c}'" for c in service_provider])
                    service_provider_condition = f"AND service_provider_display_name IN ({quoted_service_provider})"
                # Combine both safely
                #user_customers = customers_names + customers
                #quoted_customers = ', '.join([f"'{c}'" for c in user_customers])
                logging.info('quoted_customers',quoted_customers)
                existed_customers_query = f'''select distinct iccid
                                     from sim_management_inventory
                                    where is_active = TRUE
                                    AND tenant_id = {tenant_id}
                                    ;
                                '''
                existed_iccids=database.execute_query(existed_customers_query,True)['iccid'].to_list()
                logging.info("### existed_iccids : {existed_iccids}")
                new_iccids_customers_query = f'''select distinct iccid
                                     from sim_management_inventory
                                    WHERE customer_name IN ({quoted_customers})
                    AND is_active = TRUE
                    AND tenant_id = {main_tenant_id} {service_provider_condition}

                                '''
                new_iccids=database.execute_query(new_iccids_customers_query,True)['iccid'].to_list()
                logging.info(f"###  new_iccids : {new_iccids}")
                remaining_iccids = [c for c in new_iccids if c not in existed_iccids]
                logging.info(f"### remaining_iccids : {remaining_iccids}")
                remaining_iccids = ', '.join([f"'{c}'" for c in remaining_iccids])
                inventory_data = f'''select device_id,
                    mobility_device_id,tenant_id,rev_service_id,customer_rate_plan_id,customer_data_allocation_mb,customer_rate_pool_id,
                    account_number,customer_id,account_number_integration_authentication_id,created_by,created_date,
                    modified_by,modified_date,deleted_by,deleted_date,is_active,is_deleted,customer_rate_pool_name,customer_rate_plan_name,customer_name,service_provider_display_name from sim_management_inventory
                    WHERE iccid IN ({remaining_iccids})
                    AND is_active = TRUE
                    AND tenant_id = {main_tenant_id} and customer_name IN ({quoted_customers}) {service_provider_condition}
                    ;
                '''
                inventory_data=database.execute_query(inventory_data,True)
                inventory_data['tenant_id'] = tenant_id
                existinct_customer=f'{tenant_name} - Unassigned'
                exist_customer_query=f'''select id from customers where customer_name='{existinct_customer}'
                '''
                exist_customer=database.execute_query(exist_customer_query,True)
                if not exist_customer.empty:
                    customer_id=exist_customer['id'].to_list()[0]
                else:
                    customers_data={"customer_name":existinct_customer,"tenant_id":tenant_id,"created_by":username,"tenant_name":tenant_name,"is_active":True,"is_deleted":False}
                    customer_id=database.insert_data(customers_data, 'customers')
                    try:
                        response = requests.post(api_url, json=customers_api_payload)
                        if response.status_code == 200:
                            # Get the current timestamp
                            #current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                            # Log the message with the timestamp

                            logging.info("### Customers API call successful.Data synn call is succssefully done ")
                        else:
                            logging.error(
                                f"### API call failed with statudafdfadsfs code: {response.status_code}"
                            )
                    except Exception as e:
                        logging.error(f"### Error making API call: {e}")
                inventory_data['customer_name'] = existinct_customer
                inventory_data['customer_id'] = customer_id
                inventory_data['created_by'] = username
                inventory_data = handle_date_and_nat_columns(inventory_data)
                if not inventory_data.empty:
                    # List of service provider names for Telegence-related records
                    telegence_providers = ['AT&T - Telegence', 'AT&T - Telegence - UAT ONLY','AT&T - eBonding']

                    # Filter for Telegence-related records
                    telegence_df = inventory_data[inventory_data['service_provider_display_name'].isin(telegence_providers)].copy()

                    # Everything else goes to device_df
                    device_df = inventory_data[~inventory_data['service_provider_display_name'].isin(telegence_providers)].copy()

                    # Process Telegence data
                    if not telegence_df.empty:
                        telegence_df.drop(['service_provider_display_name', 'device_id','created_date','modified_date'], axis=1, inplace=True)
                        formatted_telegence = format_data_for_dict(telegence_df.to_dict(orient="records"))
                        formatted_telegence = format_data_for_dict(formatted_telegence)
                        database.insert_data(formatted_telegence, 'mobility_device_tenant')

                    # Process other providers
                    if not device_df.empty:
                        device_df.drop(['service_provider_display_name', 'mobility_device_id','created_date','modified_date'], axis=1, inplace=True)
                        formatted_others = format_data_for_dict(device_df.to_dict(orient="records"))
                        formatted_device = format_data_for_dict(formatted_others)
                        database.insert_data(formatted_device, 'device_tenant')
                try:
                    response = requests.post(api_url, json=api_payload)
                    if response.status_code == 200:
                        # Get the current timestamp

                        # Log the message with the timestamp

                        logging.info("### API call successful.Data synn call is succssefully done ")
                    else:
                        logging.error(
                            f"### API call failed with statudafdfadsfs code: {response.status_code}"
                        )
                except Exception as e:
                    logging.error(f"### Error making API call: {e}")
                response={"flag":True,"message":"tenant based partner admin filters updated successfully"}
                # return response
        else:
            # Convert all list-type fields to JSON strings for DB storage
            for key, value in customers_data.items():
                if isinstance(value, list):
                    customers_data[key] = json.dumps(value)
            if action == 'create':
                additional_fields = {
                    "username": username,
                    "tenant_id": tenant_id,
                    "role_name": "Partner Admin",
                    "tenant_name": tenant_name
                }
                logging.info(f'### customers_data BEFORE update: {customers_data}')
                customers_data.update(additional_fields)  
                logging.info(f'### customers_data AFTER update: {customers_data}')

                common_utils_database.insert_data(
                    customers_data, 'tenant_based_partner_admin_filters'
                )
                logging.info(f'### user_customers :  {customers}')
                service_provider_condition = ''
                if service_provider:
                    quoted_service_provider = ', '.join([f"'{c}'" for c in service_provider])
                    service_provider_condition = f"AND service_provider_display_name IN ({quoted_service_provider})"
                quoted_customers = ', '.join([f"'{c}'" for c in customers])
                existed_iccids_query = f'''select distinct iccid
                                     from sim_management_inventory
                                    where is_active = TRUE
                                    AND tenant_id = {tenant_id}
                                    ;
                                '''
                existed_iccids=database.execute_query(existed_iccids_query,True)['iccid'].to_list()
                logging.info(existed_iccids,'existed_iccidsexisted_iccids')
                new_iccids_customers_query = f'''select distinct iccid
                                     from sim_management_inventory
                                    WHERE customer_name IN ({quoted_customers})
                    AND is_active = TRUE
                    AND tenant_id = {main_tenant_id} {service_provider_condition}

                                '''
                new_iccids=database.execute_query(new_iccids_customers_query,True)['iccid'].to_list()
                logging.info(f"### new_iccids : {new_iccids}")
                remaining_iccids = [c for c in new_iccids if c not in existed_iccids]
                logging.info(f"### remaining_iccids : {remaining_iccids}")
                remaining_iccids = ', '.join([f"'{c}'" for c in remaining_iccids])
                inventory_data = f'''select device_id,
                    mobility_device_id,tenant_id,rev_service_id,customer_rate_plan_id,customer_data_allocation_mb,customer_rate_pool_id,
                    account_number,customer_id,account_number_integration_authentication_id,created_by,created_date,
                    modified_by,modified_date,deleted_by,deleted_date,is_active,is_deleted,customer_rate_pool_name,customer_rate_plan_name,customer_name,service_provider_display_name from sim_management_inventory
                    WHERE iccid IN ({remaining_iccids})
                    AND is_active = TRUE
                    AND tenant_id = {main_tenant_id} and customer_name IN ({quoted_customers})  {service_provider_condition}
                    ;
                '''
                inventory_data=database.execute_query(inventory_data,True)
                inventory_data['tenant_id'] = tenant_id
                existinct_customer=f'{tenant_name} - Unassigned'
                exist_customer_query=f'''select id from customers where customer_name='{existinct_customer}'
                '''
                exist_customer=database.execute_query(exist_customer_query,True)
                if not exist_customer.empty:
                    customer_id=exist_customer['id'].to_list()[0]
                else:
                    customers_data={"customer_name":existinct_customer,"tenant_id":tenant_id,"created_by":username,"tenant_name":tenant_name,"is_active":True,"is_deleted":False}
                    customer_id=database.insert_data(customers_data, 'customers')
                    try:
                        response = requests.post(api_url, json=customers_api_payload)
                        if response.status_code == 200:
                            # Get the current timestamp
                            #current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                            # Log the message with the timestamp

                            logging.info("### Customers API call successful.Data synn call is succssefully done ")
                        else:
                            logging.error(
                                f"### API call failed with statudafdfadsfs code: {response.status_code}"
                            )
                    except Exception as e:
                        logging.error(f"### Error making API call: {e}")
                inventory_data['customer_name'] = existinct_customer
                inventory_data['customer_id'] = customer_id
                inventory_data = handle_date_and_nat_columns(inventory_data)
                if not inventory_data.empty:
                    # List of service provider names for Telegence-related records
                    telegence_providers = ['AT&T - Telegence', 'AT&T - Telegence - UAT ONLY','AT&T - eBonding']

                    # Filter for Telegence-related records
                    telegence_df = inventory_data[inventory_data['service_provider_display_name'].isin(telegence_providers)].copy()

                    # Everything else goes to device_df
                    device_df = inventory_data[~inventory_data['service_provider_display_name'].isin(telegence_providers)].copy()

                    # Process Telegence data
                    if not telegence_df.empty:
                        telegence_df.drop(['service_provider_display_name', 'device_id'], axis=1, inplace=True)
                        formatted_telegence = format_data_for_dict(telegence_df.to_dict(orient="records"))
                        formatted_telegence = format_data_for_dict(formatted_telegence)
                        database.insert_data(formatted_telegence, 'mobility_device_tenant')

                    # Process other providers
                    if not device_df.empty:
                        device_df.drop(['service_provider_display_name', 'mobility_device_id'], axis=1, inplace=True)
                        formatted_others = format_data_for_dict(device_df.to_dict(orient="records"))
                        formatted_device = format_data_for_dict(formatted_others)
                        database.insert_data(formatted_device, 'device_tenant')
                try:
                    response = requests.post(api_url, json=api_payload)
                    if response.status_code == 200:
                        # Get the current timestamp


                        # Log the message with the timestamp

                        logging.info("### API call successful.Data synn call is succssefully done ")
                    else:
                        logging.error(
                            f"### API call failed with statudafdfadsfs code: {response.status_code}"
                        )
                except Exception as e:
                    logging.error(f"### Error making API call: {e}")
                response = {"flag": True, "message": "tenant based partner admin filters created successfully"}
                # return response
            else:
                default_empty_fields = {
                    "customer_names": "",
                    "rate_plan_name": "",
                    "feature_codes": "",
                    "billing_account_number": "",
                    "notification_rules": ""
                }
                customers_data.update(default_empty_fields)
                try:
                    common_utils_database.update_dict(
                        'tenant_based_partner_admin_filters',
                        customers_data,
                        {"username": username, "tenant_id": tenant_id}
                    )
                except Exception as e:
                    logging.error(f"### Error updating tenant_based_partner_admin_filters: {e}")
                logging.info(f'### user_customers : {user_customers}')
                service_provider_condition = ''
                if service_provider:
                    quoted_service_provider = ', '.join([f"'{c}'" for c in service_provider])
                    service_provider_condition = f"AND service_provider_display_name IN ({quoted_service_provider})"
                quoted_customers = ', '.join([f"'{c}'" for c in customers])
                existed_iccids_query = f'''select distinct iccid
                                     from sim_management_inventory
                                    where is_active = TRUE
                                    AND tenant_id = {tenant_id}
                                    ;
                                '''
                existed_iccids=database.execute_query(existed_iccids_query,True)['iccid'].to_list()
                logging.info(f"### existed_iccids : {existed_iccids}")
                new_iccids_customers_query = f'''select distinct iccid
                                     from sim_management_inventory
                                    WHERE customer_name IN ({quoted_customers})
                    AND is_active = TRUE
                    AND tenant_id = {main_tenant_id} {service_provider_condition}

                                '''
                new_iccids=database.execute_query(new_iccids_customers_query,True)['iccid'].to_list()
                logging.info(f"new_iccids : {new_iccids}")
                remaining_iccids = [c for c in new_iccids if c not in existed_iccids]
                logging.info(f"remaining_iccids : {remaining_iccids}")
                remaining_iccids = ', '.join([f"'{c}'" for c in remaining_iccids])
                inventory_data = f'''select device_id,
                    mobility_device_id,tenant_id,rev_service_id,customer_rate_plan_id,customer_data_allocation_mb,customer_rate_pool_id,
                    account_number,customer_id,account_number_integration_authentication_id,created_by,created_date,
                    modified_by,modified_date,deleted_by,deleted_date,is_active,is_deleted,customer_rate_pool_name,customer_rate_plan_name,customer_name,service_provider_display_name from sim_management_inventory
                    WHERE iccid IN ({remaining_iccids})
                    AND is_active = TRUE
                    AND tenant_id = {main_tenant_id} and customer_name IN ({quoted_customers})  {service_provider_condition}
                    ;
                '''
                inventory_data=database.execute_query(inventory_data,True)
                inventory_data['tenant_id'] = tenant_id
                existinct_customer=f'{tenant_name} - Unassigned'
                exist_customer_query=f'''select id from customers where customer_name='{existinct_customer}'
                '''
                exist_customer=database.execute_query(exist_customer_query,True)
                if not exist_customer.empty:
                    customer_id=exist_customer['id'].to_list()[0]
                else:
                    customers_data={"customer_name":existinct_customer,"tenant_id":tenant_id,"created_by":username,"tenant_name":tenant_name,"is_active":True,"is_deleted":False}
                    customer_id=database.insert_data(customers_data, 'customers')
                    try:
                        response = requests.post(api_url, json=customers_api_payload)
                        if response.status_code == 200:
                            # Get the current timestamp
                            #current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                            # Log the message with the timestamp

                            logging.info("### Customers API call successful.Data synn call is succssefully done ")
                        else:
                            logging.error(
                                f"### API call failed with statudafdfadsfs code: {response.status_code}"
                            )
                    except Exception as e:
                        logging.error(f"### Error making API call: {e}")
                inventory_data['customer_name'] = existinct_customer
                inventory_data['customer_id'] = customer_id
                inventory_data['created_by'] = username
                inventory_data = handle_date_and_nat_columns(inventory_data)
                if not inventory_data.empty:
                    # List of service provider names for Telegence-related records
                    telegence_providers = ['AT&T - Telegence', 'AT&T - Telegence - UAT ONLY','AT&T - eBonding']

                    # Filter for Telegence-related records
                    telegence_df = inventory_data[inventory_data['service_provider_display_name'].isin(telegence_providers)].copy()

                    # Everything else goes to device_df
                    device_df = inventory_data[~inventory_data['service_provider_display_name'].isin(telegence_providers)].copy()

                    # Process Telegence data
                    if not telegence_df.empty:
                        telegence_df.drop(['service_provider_display_name', 'device_id','created_date','modified_date'], axis=1, inplace=True)
                        formatted_telegence = format_data_for_dict(telegence_df.to_dict(orient="records"))
                        formatted_telegence = format_data_for_dict(formatted_telegence)
                        database.insert_data(formatted_telegence, 'mobility_device_tenant')

                    # Process other providers
                    if not device_df.empty:
                        device_df.drop(['service_provider_display_name', 'mobility_device_id','created_date','modified_date'], axis=1, inplace=True)
                        formatted_others = format_data_for_dict(device_df.to_dict(orient="records"))
                        formatted_device = format_data_for_dict(formatted_others)
                        database.insert_data(formatted_device, 'device_tenant')
                # Prepare the data to send in the API request

                # Send the POST request
                try:
                    response = requests.post(api_url, json=api_payload)
                    if response.status_code == 200:
                        # Get the current timestamp


                        # Log the message with the timestamp
                        logging.info("### API call successful.Data synn call is succssefully done ")
                    else:
                        logging.error(
                            f"### API call failed with statudafdfadsfs code: {response.status_code}"
                        )
                except Exception as e:
                    logging.error(f"### Error making API call: {e}")
                # Prepare the response
                response={"flag":True,"message":"tenant based partner admin filters updated successfully"}
                # return response 

        try:
            audit_data_user_actions = {
                "service_name": "update_tenant_based_partner_admin_filters",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": "tenant based partner admin filters updated successfully",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")


        return response


    except Exception as e:
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### Error occurred while editing the tenant based partner admin filters : {e}")
        message = "Unable to edit the tenant based partner admin filters"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "update_tenant_based_partner_admin_filters",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 

        response={"flag":False,"message":"Unable to edit the tenant based partner admin filters"}
        return response

# Function to handle NaT values and date columns
def handle_date_and_nat_columns(df):
    """
    Cleans and standardizes datetime and null values in a pandas DataFrame.

    Args:
        df (pandas.DataFrame): The DataFrame to clean.

    Returns:
        pandas.DataFrame: The cleaned DataFrame with standardized datetime and null values.
    """
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            # If the column is a datetime type, we fill NaT with pd.NaT (or other fallback date)
            df[col] = pd.to_datetime(df[col], errors='coerce')  # Coerce invalid dates to NaT
            df[col] = df[col].fillna(pd.NaT)  # Optional: Replace NaT with a default (you can use None or a specific date)
        elif df[col].isnull().any():
            # Replace None or NaN in non-datetime fields with a custom fallback or None
            df[col] = df[col].replace({None: np.nan, np.nan: None}).infer_objects(copy=False)

    return df

def format_data_for_dict(data):
    """
    Formats a list of dictionaries by converting timestamps and handling null values.

    This function iterates through a list of dictionary records, typically from a DataFrame `to_dict('records')` call,
    and formats each record as follows:
    - `pandas.Timestamp` values are converted to string in '%Y-%m-%d %H:%M:%S' format.
    - Invalid timestamps (NaT) and null values (None/NaN) are replaced with `None`.
    - All other values are kept unchanged.

    Args:
        data (list of dict): List of dictionaries representing row-wise data.

    Returns:
        list of dict: The formatted list with cleaned datetime and null representations.
    """
    formatted_data = []
    for record in data:
        formatted_record = {}
        for key, value in record.items():
            if isinstance(value, pd.Timestamp):
                # Handle Timestamps: Convert valid Timestamps to string, invalid to None
                if pd.isna(value):
                    formatted_record[key] = None  # Coerce NaT or invalid date to None
                else:
                    formatted_record[key] = value.strftime('%Y-%m-%d %H:%M:%S')  # Format as string (or use other format)
            elif pd.isnull(value):
                formatted_record[key] = None  # For None/NaT/NaN, replace with None
            else:
                formatted_record[key] = value  # Keep other values unchanged
        formatted_data.append(formatted_record)
    return formatted_data


def reports_readme(data,module_name = ""):
    """
    Fetches paginated report data for a given module, with access control and dynamic query construction.

    Args:
        data (dict): A dictionary containing request and user metadata:
            - z_access_token (str): Authorization token for access validation.
            - client_id (str): Service client ID used to determine role and tenant.
            - page (int, optional): Page number for paginated data (default is 1).

        module_name (str, optional): Name of the report module used to fetch the base SQL query.

    Returns:
        dict: A dictionary with the following structure:
            - flag (bool): True if the operation was successful, False otherwise.
            - message (str): Description or error message.
            - readme (bool): Always True when the function executes, used for UI identification.
            - current_page (int): Current page number in the pagination.
            - total_pages (int): Total number of pages based on record count.
            - total_records (int): Total number of matching records.
            - data (list, optional): List of dictionaries representing the report data. Empty list if no records.
    """
    logging.info(f"### module_name : {module_name} data: {data}")
    try:
        del db_config['customer_rate_plan_name']
    except Exception as e:
        logging.exception(f"### Exception is {e}")
    z_access_token = data.get("z_access_token")
    if not z_access_token:
        return {"flag": False, "message": "Access token is required"}

    try:
        client_id = data.get("client_id", "")
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        service_data = common_utils_database.get_data("service_accounts", {"client_id": client_id})
        role = service_data["role"].to_list()[0]
        if role == "Agent" and module_name == "Customer Rate Pool Usage Report":
            return {"flag":True,"message":"You do not have permission to perform this action.","readme": True}
        elif role == "User" and module_name == "Pool Group Summary Report":
            return {"flag":True,"message":"You do not have permission to perform this action.","readme": True}
        tenant = service_data["tenant"].to_list()[0]
        if tenant == "Altaworx Test":
            tenant = "Altaworx"
        tenant_details = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant}, ["id","db_name"]
        )
        tenant_id = tenant_details["id"].to_list()[0]
        db_name = tenant_details["db_name"].to_list()[0]

        database = DB(db_name, **db_config)

        module_query_df = common_utils_database.get_data(
            "export_queries", {"module_name": module_name}
        )
        if module_query_df.empty:
            raise ValueError(f"### No query found for module name: {module_name}")

        base_query = module_query_df.iloc[0]["module_query"]
        base_query = base_query.split('LIMIT')[0].strip()
        base_query = re.split(r'\bwhere\b', base_query, flags=re.IGNORECASE)[0].strip()

        # Filter last 30 days
        if module_name != "Customer Rate Pool Usage Report":
            thirty_days_ago = (datetime.datetime.now() - datetime.timedelta(days=30)).strftime('%Y-%m-%d')
            if 'WHERE' not in base_query.upper():
                base_query = f"{base_query} WHERE modified_date >= '{thirty_days_ago}'"
            else:
                base_query = f"{base_query} AND modified_date >= '{thirty_days_ago}'"

        # Pagination
        if "WHERE" in base_query.upper():
            base_query = f"{base_query} AND is_active = TRUE AND tenant_id = {tenant_id}"
        else:
            base_query = f"{base_query} WHERE is_active = TRUE AND tenant_id = {tenant_id}"
        page_number = int(data.get("page", 1))
        page_size = 100
        offset = (page_number - 1) * page_size
        match = re.search(r'FROM\s+([a-zA-Z0-9_]+)', base_query, re.IGNORECASE)
        table_name = match.group(1) if match else None
        if db_config and "customers" in db_config and table_name:
            customers = db_config["customers"]
            customer_filter = f"AND customer_name IN {customers}" if customers else ""
            count_query = f"SELECT COUNT(*) AS total FROM {table_name} WHERE modified_date >= '2025-04-06' AND is_active = TRUE AND tenant_id = 1 {customer_filter}"
            logging.info(f"### module_name : {module_name} Count Query: {count_query}")
            count_result = database.execute_query(count_query, True)
        else:
            # Count query for total records
            count_query = f"SELECT COUNT(*) AS total FROM ({base_query}) AS subquery"
            logging.info(f"### module_name : {module_name} Count Query: {count_query}")
            count_result = database.execute_query(count_query, True)
        logging.info(f"### readme Count Result: {count_result}")
        try:
            logging.info(f"### readme Count Result 2: {count_result}")

            total_count = int(count_result.iloc[0]["total"]) if not count_result.empty else 0
            total_pages = (total_count + page_size - 1) // page_size
        except Exception as e:
            logging.exception(f"### Error in reports_readme: {e}")
            return {
                "flag": True,
                "data": [],
                "message": "No records found.",
                "current_page": page_number,
                "total_pages": 0,
                "total_records": 0,
                "readme": True
            }

        # Handle page_number greater than total_pages
        if page_number > total_pages and total_pages > 0:
            return {
                "flag": True,
                "data": [],
                "message": f"No records found. Page {page_number} exceeds total pages ({total_pages}).",
                "current_page": page_number,
                "total_pages": total_pages,
                "total_records": total_count,
                "readme": True
            }

        # Paginated query
        final_query = f"{base_query} LIMIT {page_size} OFFSET {offset}"
        logging.info(f"### module_name : {module_name} Final Query: {final_query}")

        query_data = database.execute_query(final_query, True)

        if not query_data.empty:
            query_data = query_data.to_dict(orient='records')

            def convert_timestamps(obj):
                if isinstance(obj, (datetime.datetime, pd.Timestamp)):
                    return obj.isoformat()
                if isinstance(obj, list):
                    return [convert_timestamps(item) for item in obj]
                if isinstance(obj, dict):
                    return {key: convert_timestamps(value) for key, value in obj.items()}
                return obj

            query_data = convert_timestamps(query_data)
        else:
            query_data = []
            total_pages = 0
            total_count = 0

        response =  {
            "flag": True,
            "current_page": page_number,
            "total_pages": total_pages,
            "total_records": total_count,
            "readme": True,
            "data": query_data
        }

        try:
            audit_data_user_actions = {
                "service_name": "reports_readme",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": "Report data fetched successfully",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
 
        return response 
    
    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### Error occurred in fetching report data : {e}")
        message = "Something went wrong while getting report data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "reports_readme",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 

        return {"flag": False, "message": message}

def sim_management_inventory_export(data):
    """
    Exports SIM management inventory data to an S3 bucket based on the tenant and client context.

    Args:
        data (dict): Dictionary containing:
            - z_access_token (str): Required for access validation.
            - client_id (str): Service account client ID used to resolve tenant and database.
            - Any additional parameters required by `export_to_s3_bucket()`.

    Returns:
        dict: Response from the export process. Structure:
            - flag (bool): Indicates success (usually True even on exception for UI handling).
            - message (str): Success or error message.
            - readme (bool): True if export executed, helps UI identify this as a ReadMe response.
            - Any additional keys returned by `export_to_s3_bucket()`.
    """
    z_access_token = data.get("z_access_token", "")
    try:
        if z_access_token:
            client_id = data.get("client_id", "")
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
            service_data = common_utils_database.get_data(
                    "service_accounts", {"client_id": client_id}
                )
            tenant = service_data["tenant"].to_list()[
                    0
                ]
            data['tenant_name']=tenant #tenant
            db_name = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant}, ["db_name"]

            )["db_name"].to_list()[0]
            data["db_name"] = db_name  # tenant database name
            response = export_to_s3_bucket(data)
            response["readme"] = True
            # body = response["body"]
            logging.info(f"### sim_management_inventory_export response: {type(response)} --- {response}")
            # body["readme"] = True
            try:
                audit_data_user_actions = {
                    "service_name": "sim_management_inventory_export",
                    "created_by": data.get("username", ""),
                    "status": str(response.get("flag", "")),
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": data.get("Partner", ""),
                    "module_name": "Module Management",
                    "comments": "SIM management inventory export executed successfully",
                    "request_received_at": data.get("request_received_at", ""),
                }
                common_utils_database.update_audit(
                    audit_data_user_actions, "audit_user_actions"
                )
            except Exception as e:
                logging.warning(f"### Audit logging exception: {e}")
    
            return response


    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### Error occurred during SIM management inventory export: {e}")
        message = "Something went wrong during SIM management inventory export"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "sim_management_inventory_export",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            
        # return {"flag": True, "message": f"sim_management_inventory - {str(e)}"}
        response = {"flag": False, "message": f"sim_management_inventory - {str(e)}"}
        return response 
    
    return {"flag": True, "message": "sim_management_inventory_export success"}

def daily_usage_report(data):
    """
    Handles export of daily usage report to an S3 bucket or fetches the export status.

    Args:
        data (dict): Dictionary containing:
            - z_access_token (str): Required for access authentication.
            - client_id (str): Used to identify the tenant from `service_accounts`.
            - readme_path (str, optional): Determines whether to fetch status or perform export.
            - Additional keys required by `get_export_status` or `export_to_s3_bucket`.

    Returns:
        dict: Response dictionary with:
            - flag (bool): Always True (even on error, for UI compatibility).
            - message (str): Success or error message.
            - Additional keys as returned by `get_export_status` or `export_to_s3_bucket`.
    """
    z_access_token = data.get("z_access_token", "")
    try:
        if z_access_token:
            client_id = data.get("client_id", "")
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
            service_data = common_utils_database.get_data(
                    "service_accounts", {"client_id": client_id}
                )
            tenant = service_data["tenant"].to_list()[
                    0
                ]
            if tenant == "Altaworx Test":
                tenant = "Altaworx"
            data['tenant_name']=tenant #tenant
            db_name = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant}, ["db_name"]

            )["db_name"].to_list()[0]
            data["db_name"] = db_name  # tenant database name
            logging.info(f"### Daily usage report Export data: {data}")
            readme_path = data.get("readme_path", "")
            if readme_path == "/get_export_status":
                response = get_export_status(data)
            else:
                response = export_to_s3_bucket(data)
            # body = response["body"]
            logging.info(f"### Daily usage report Export response: {type(response)} --- {response}")
            # body["readme"] = True

            try:
                audit_data_user_actions = {
                    "service_name": "daily_usage_report",
                    "created_by": data.get("username", ""),
                    "status": str(response.get("flag", "")),
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": data.get("Partner", ""),
                    "module_name": "Module Management",
                    "comments": "Daily usage report Exported successfully",
                    "request_received_at": data.get("request_received_at", ""),
                }
                common_utils_database.update_audit(
                    audit_data_user_actions, "audit_user_actions"
                )
            except Exception as e:
                logging.warning(f"### Audit logging exception: {e}")
    
            return response

    # except Exception as e:
    #     logging.exception(f"### Unexpected error in Daily usage report Export : {e}")
    #     return {"flag": True, "message": f"sim_management_inventory - {str(e)}"}
    
    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### Unexpected error in Daily usage report Export : {e}")
        message = "Something went wrong in Daily usage report Export"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "daily_usage_report",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            
        # return {"flag": True, "message": f"sim_management_inventory - {str(e)}"}
        response = {"flag": True, "message": f"daily_usage_report - {str(e)}"}
        return response 
    

    return {"flag": True, "message": "Daily usage report Export success"}

def status_history_report(data):
    """
    Handles the export or status check of the status history report to an S3 bucket.

    Args:
        data (dict): Dictionary containing:
            - z_access_token (str): Access token for verification.
            - client_id (str): Identifies the tenant in the system.
            - readme_path (str, optional): Path to determine export vs. status check.
            - Any additional keys required by `get_export_status` or `export_to_s3_bucket`.

    Returns:
        dict: Response with:
            - flag (bool): True, indicating completion (even on failure).
            - message (str): Message describing the result or error.
            - Additional response data depending on export or status check.
    """

    z_access_token = data.get("z_access_token", "")
    try:
        if z_access_token:
            client_id = data.get("client_id", "")
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
            service_data = common_utils_database.get_data(
                    "service_accounts", {"client_id": client_id}
                )
            tenant = service_data["tenant"].to_list()[0]
            if tenant == "Altaworx Test":
                tenant = "Altaworx"
            data['tenant_name']=tenant #tenant
            db_name = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant}, ["db_name"]

            )["db_name"].to_list()[0]
            data["db_name"] = db_name  # tenant database name
            logging.info(f"### status_history_report data: {data}")
            readme_path = data.get("readme_path", "")
            if readme_path == "/get_export_status":
                response = get_export_status(data)
            else:
                response = export_to_s3_bucket(data)
            # body = response["body"]
            logging.info(f"### status_history_report response: {type(response)} --- {response}")
            # body["readme"] = True
            try:
                audit_data_user_actions = {
                    "service_name": "status_history_report",
                    "created_by": data.get("username", ""),
                    "status": str(response.get("flag", "")),
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": data.get("Partner", ""),
                    "module_name": "Module Management",
                    "comments": "status history report Exported successfully",
                    "request_received_at": data.get("request_received_at", ""),
                }
                common_utils_database.update_audit(
                    audit_data_user_actions, "audit_user_actions"
                )
            except Exception as e:
                logging.warning(f"### Audit logging exception: {e}")
    
            return response
        
    # except Exception as e:
    #     logging.exception(f"### Unexpected error in status_history_report  Export : {e}")
    #     return {"flag": True, "message": f"status_history_report - {str(e)}"}

    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### Unexpected error in status history report  Export : {e}")
        message = "Something went wrong in status history report Export"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "status_history_report",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            
        # return {"flag": True, "message": f"sim_management_inventory - {str(e)}"}
        response = {"flag": True, "message": f"status_history_report - {str(e)}"}
        return response 
    

    return {"flag": True, "message": "status_history_report Export success"}

def usage_by_line_report(data):
    """
    Generates or checks the status of the 'Usage by Line' report export for a given customer or service provider.

    Args:
        data (dict): A dictionary containing:
            - z_access_token (str): Token to validate request.
            - client_id (str): Client ID used to fetch tenant details.
            - customer_name (str): Name of the customer or service provider.
            - billing_cycle_period (str): Selected billing cycle end date (in 'YYYY-MM-DD' or 'MM-DD-YY' format).
            - readme_path (str, optional): Endpoint path to check export status.

    Returns:
        dict: A response object containing:
            - flag (bool): Indicates success or failure.
            - message (str): Informative message regarding the outcome.
            - readme (bool): Always True for readme-style responses.
            - Additional keys depending on export status or S3 export result.
    """
    logging.info(f"### usage_by_line_report_data: {data}")
    z_access_token = data.get("z_access_token", "")
    customer_name = data.get("customer_name", "")
    customer_name = customer_name.strip() if customer_name else ""
    billing_cycle_period = data.get("billing_cycle_period", "")
    try:
        if z_access_token:
            client_id = data.get("client_id", "")
            common_utils_database = DB('common_utils', **db_config)
            service_data = common_utils_database.get_data(
                    "service_accounts", {"client_id": client_id}
                )
            tenant = service_data["tenant"].to_list()[0]
            if tenant == "Altaworx Test":
                tenant = "Altaworx"
            data['tenant_name']=tenant #tenant
            db_details = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant}, ["id","db_name"]

            )
            tenant_id = db_details["id"].to_list()[0]
            db_name = db_details["db_name"].to_list()[0]
            data["db_name"] = db_name  # tenant database name
            logging.info(f"### usage_by_line_report data: {data}")
            readme_path = data.get("readme_path", "")
            if readme_path == "/get_export_status":
                response = get_export_status(data)
            else:
                if not customer_name or not billing_cycle_period:
                    return {"flag": True, "message": "customer_name and billing_cycle_period is required.", "readme": True}
                database = DB(db_name, **db_config)
                optimization_status = get_cross_provider_optimization_status(data)
                logging.info(f"### optimization_status: {optimization_status.get('cross_carrier_optimization')}")
                if optimization_status.get("cross_carrier_optimization"):
                    select_customer_query = f"SELECT id FROM customers WHERE TRIM(customer_name) = '{customer_name}' AND tenant_id = {tenant_id}  AND is_active=true"
                    customer_id = database.execute_query(select_customer_query, True)
                    logging.info(f"### customer_id: {customer_id}")
                    if customer_id.empty:
                        return {"flag": True, "message": f"Customer {customer_name} not found.", "readme": True}
                    customer_id = customer_id["id"].to_list()[0]
                    billing_details = database.get_data(
                        "vw_cross_provider_usage_by_line_report_for_customer",
                        {"customer_id":customer_id},
                        ["billing_period_ids","billing_cycle_end_date"]
                    )
                    if billing_details.empty:
                        return {"flag": True, "message": f"Customer {customer_name} billing details not found.", "readme": True}
                    billing_cycle_end_date = billing_details["billing_cycle_end_date"].to_list()[0]
                    billing_period_ids = billing_details["billing_period_ids"].to_list()[0]

                    # Ensure elements in billing_cycle_end_date are stripped of quotes and whitespace if needed
                    billing_cycle_end_date_cleaned = [
                        x.strip().strip('"').split(" ")[0] for x in billing_cycle_end_date if x
                    ]

                    billing_period_ids = [int(x) for x in billing_period_ids if x]

                    # Check if the billing_cycle_period is present
                    if billing_cycle_period not in billing_cycle_end_date_cleaned:
                        return {
                            "flag": True,
                            "message": f"{billing_cycle_period} not found in billing cycle end dates.",
                            "readme": True
                        }
                    logging.info(f'### billing_cycle_end_date_cleaned : {billing_cycle_end_date_cleaned}, billing_cycle_period : {billing_cycle_period}')
                    index = billing_cycle_end_date_cleaned.index(billing_cycle_period)
                    logging.info(f"###  : {index}")
                    # Guard against index mismatch
                    if index >= len(billing_period_ids):
                        return {"flag": False, "message": " in billing_period_ids not found", "readme": True}

                    selected_billing_period_id = billing_period_ids[index]
                    logging.info(f"### Selected Billing Period ID: {selected_billing_period_id}")
                    data["billing_cycle_period"] = selected_billing_period_id
                    data["service_provider"] = customer_id
                    logging.info(f'### customer_id : {customer_id}')
                else:
                    service_provider_df = database.get_data(
                            "serviceprovider",
                            {"tenant_id": tenant_id,"service_provider_name":customer_name},
                            ["id"]
                        )
                    if service_provider_df.empty:
                        message = "Please provide a valid service provider."
                        return {"flag": True, "message": message, "readme": True}
                    billing_period_df = database.get_data(
                        "billing_period",
                        {"service_provider":customer_name,"is_active":True},
                        ["billing_cycle_end_date"]
                    )
                    if billing_period_df.empty:
                        message = f"Billing cycle period not found for service provider : {customer_name}."
                        return {"flag": True, "message": message, "readme": True}
                    billing_cycle_end_date = billing_period_df["billing_cycle_end_date"].to_list()
                    # fetch billing_periods without time
                    billing_cycle_dates = [
                        x.strftime("%m-%d-%y") if isinstance(x, pd.Timestamp) else str(x).split(" ")[0]
                        for x in billing_cycle_end_date if x
                    ]
                    logging.info(f"### billing_cycle_dates: {billing_cycle_dates}")
                    if billing_cycle_period not in billing_cycle_dates:
                        message = f''' Billing cycle period {billing_cycle_period} not found for service provider'''
                        return {"flag": True, "message": message, "readme": True}
                    index = billing_cycle_dates.index(billing_cycle_period)
                    logging.info(f"### billing_cycle_end_date[index] - {billing_cycle_end_date[index]} - {[billing_cycle_end_date[index]]}")
                    data["billing_cycle_period"] = [billing_cycle_end_date[index]]
                    data["service_provider"] = customer_name
                response = export_to_s3_bucket(data)
            # body = response["body"]
            logging.info(f"### usage_by_line_report_data : {data}")
            logging.info(f"### usage_by_line_report response: {type(response)} --- {response}")
            # body["readme"] = True

            try:
                audit_data_user_actions = {
                    "service_name": "usage_by_line_report",
                    "created_by": data.get("username", ""),
                    "status":  str(response.get("flag", "")),
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": data.get("Partner", ""),
                    "module_name": "Module Management",
                    "comments": "usage by line report exported successfully",
                    "request_received_at": data.get("request_received_at", ""),
                }
                common_utils_database.update_audit(
                    audit_data_user_actions, "audit_user_actions"
                )
            except Exception as e:
                logging.warning(f"### Audit logging exception: {e}")
    
            return response

    # except Exception as e:
    #     logging.exception(f"### Unexpected error in usage_by_line_report  Export : {e}")
    #     return {"flag": True, "message": "unable to fetch usage by line report"}
    

    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### Unexpected error in usage_by_line_report  Export : {e}")
        message = "Something went wrong while exporting usage by line report"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "usage_by_line_report",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
        # return {"flag": True, "message": f"sim_management_inventory - {str(e)}"}
        response = {"flag": False, "message": f"usage_by_line_report - {str(e)}"}
        return response 


def update_service_account_info_tenant_based(data):
    """
    Updates service account information for a specific tenant in the `user_module_tenant_mapping` table.

    Args:
        data (dict): Input data containing:
            - partner_name (str): Name of the tenant partner used to identify the tenant.
            - changed_data (dict): Dictionary with:
                - service_account_info (dict): Updated fields for the user, including:
                    - username (str): Username to match for the update.
                    - Other optional fields to be updated in the table.

    Returns:
        dict: Response indicating the result of the update operation:
            - flag (bool): True if update was successful, False otherwise.
            - message (str): Descriptive success or error message.
    """
    try:
        # Initialize DB connection
        common_utils_database = DB('common_utils', **db_config)

        # Extract tenant ID
        partner_name = data.get("partner_name", "")
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": partner_name}, ["id"]
        )["id"].to_list()[0]

        # Extract changed data and username
        service_account_info = data.get("changed_data", {}).get("service_account_info", {})
        # Convert all list-type fields in customer_info to JSON strings
        for key, value in service_account_info.items():
            if isinstance(value, list):
                service_account_info[key] = json.dumps(value)
        user_name = service_account_info.pop("username", "")  # Remove username from update dict

        # Update DB
        common_utils_database.update_dict(
            "user_module_tenant_mapping",
            service_account_info,
            {"tenant_id": tenant_id, "user_name": user_name}
        )

        message = f'Service Account Details for  {user_name} updated successfully in user_module_tenant_mapping table for tenant_id {tenant_id}'
        response = {"flag": True, "message": message}

        try:
            audit_data_user_actions = {
                "service_name": "update_service_account_info_tenant_based",
                "created_by": data.get("username", ""),
                "status": str(response["flag"]),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": "Service account info for '{data.get('username', "")}'updated successfully",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")
    
        return response

    # except Exception as e:
    #     logging.exception("### Error updating user info")
    #     return {
    #         "flag": False,
    #         "message": "Unable to save the data into user_module_tenant_mapping table"
    #     }
    
    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### Error occurred while updating service account info : {e}")
        message = "Something went wrong while updating service account info"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "update_service_account_info_tenant_based",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            
        # return {"flag": True, "message": f"sim_management_inventory - {str(e)}"}
        response = {
            "flag": False,
            "message": "Unable to save the data into user_module_tenant_mapping table"
        }
        return response 
    
def get_service_account_info_details(data):
    """
    Fetches service account credentials and related configuration for a user
    associated with a tenant based on the partner name and username.

    Args:
        data (dict): Dictionary containing:
            - partner_name (str): Name of the tenant partner.
            - username (str): Username for which service account info is requested.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True indicating the operation was performed (successfully or not).
            - message (str): Informational message.
            - data (dict): Retrieved service account information (may be empty).
            - tax_profiles (list): Currently an empty list (placeholder for future use).
    """
    common_utils_database = DB('common_utils', **db_config_withoutfilter)
    partner_name=data.get("partner_name",'')
    username = data.get("username", "")
    service_account_data = {}
   
    try : 
        # get the db_name
        if partner_name:
            try:
                tenant_id=common_utils_database.get_data("tenant", {"tenant_name": partner_name}, ["id"])[
                "id"
            ].to_list()[0]
            except Exception as e:
                tenant_id=''
                logging.info(f"### Error:{e}")
        else:
            tenant_id=''
        logging.info(f"### tenant_id : {tenant_id}")
        if tenant_id:
            # get customer_group, service_provider and customers from user_module_tenant_mapping
            try:
                data = common_utils_database.get_data(
                    "user_module_tenant_mapping",
                    {"tenant_id": tenant_id,"user_name": username},
                    ["client_id","client_secret", "tax_profile"],
                )
                if not data.empty:
                    service_account_data=data.to_dict(orient="records")[0]
                else:
                    service_account_data={}
            except Exception as e:
                service_account_data={}
                logging.info(f"### Error:{e}")
            tax_profiles = []
            response = {
                "flag": True,
                "message":"Data Fetched Succesfully",
                "data": service_account_data,"tax_profiles":tax_profiles

            }
            # return response
        else:
            tax_profiles = []
            response = {
                "flag": True,
                "message":"Data Fetched Succesfully",
                "data": service_account_data,"tax_profiles":tax_profiles
            }
            # return response
        try:
            audit_data_user_actions = {
                "service_name": "get_service_account_info_details",
                "created_by": data.get("username", ""),
                "status": str(response.get("flag", "")),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": "service account info details data fetched successfully",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")

        return response
 
    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### Error occurred in getting service account info details data: {e}")
        message = "Something went wrong in getting service account info details data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_service_account_info_details",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            
        # return {"flag": True, "message": f"sim_management_inventory - {str(e)}"}
        response = {
                "flag": False,
                "message": message,
                "data": {},
                "tax_profiles": []
            }
        return response

def sort_data(data_list, sort_dict):
    """
    Sorts a list of dictionaries based on one or more keys with specified sort directions.

    Args:
        data_list (list): List of dictionaries to be sorted.
        sort_dict (dict): Dictionary where:
            - keys are the dictionary fields to sort by.
            - values are either "ASC" or "DESC" (case-insensitive) indicating sort direction.

    Returns:
        list: A new list of dictionaries sorted according to the specified keys and directions.

    """
    for key, direction in sort_dict.items():
        reverse = direction.upper() == "DESC"
        data_list = sorted(
            data_list,
            key=lambda x: (x.get(key) is None, x.get(key)),  # Sort None last
            reverse=reverse
        )
    return data_list

def bp_settings_list_view(data):
    """
    Retrieves and structures billing platform settings data including:
    - Partner/sub-partner hierarchy
    - Service provider suspension statuses
    - Carrier status mappings
    - Service line descriptions

    This function handles two operational modes:
    1. Without parameters: Returns just the partner/sub-partner hierarchy
    2. With parameters: Returns detailed billing platform settings for specified tenant(s)

    Args:
        data (dict): A dictionary containing:
            - role_name (str): User's role for permission filtering
            - tenant_name (str): Tenant name filter
            - flag (str): Operation mode ('withoutparameters' or 'withparameters')
            - Selected_Partner (str): Selected partner name (for withparameters mode)
            - sub_partner (str): Selected sub-partner name (for withparameters mode)
            - module_name (str): Module name for logging
            - username (str): User performing the operation

    Returns:
        dict: A structured response containing:
            - flag (bool): Operation success status
            - data (dict): Serialized billing platform settings data
            - partners_and_sub_partners (dict): Partner hierarchy mapping
            - headers_map (dict): Column headers for UI display
            - pages_data_suspend (dict): Pagination info for suspension data
            - pages_data_status (dict): Pagination info for status data
            - billing_platfrom_enable_flag (bool): Billing platform activation status
    """

    try:
        # Initialize DB connections using environment variables and shared configuration
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

        # Extract input filters from request payload with default fallbacks
        role_name = data.get('role_name', '')
        tenant_name = data.get('tenant_name', '')
        flag = data.get('status', '')
        # db_name = data.get('db_name', '')
        username = data.get("username", None)
        flag = data.get('flag', '')
        data_dict_all = {}
        start = data.get('mod_pages', {}).get('start', 0)
        end = data.get('mod_pages', {}).get('end',10)
        col_sort = data.get("col_sort", "")
        # module_name = data.get("module_name", "")


        # Step 1: Fetch all top-level (parent) tenants that are active
        parent_tenant_df = common_utils_database.get_data(
            "tenant",
            {"parent_tenant_id": "Null", "is_active": True},
            ["id", "tenant_name"],
        )

        # Step 2: Fetch all active tenants (both parent and child)
        all_tenants_df = common_utils_database.get_data(
            "tenant", {"is_active": True}, ["tenant_name", "parent_tenant_id"]
        )

        tenant_dict = {}

        # Step 3: For each parent tenant, collect and sort its active sub-tenants
        for _, parent_row in parent_tenant_df.iterrows():
            parent_tenant_name = parent_row["tenant_name"]
            parent_tenant_id = parent_row["id"]

            # Filter sub-tenants whose parent ID matches current parent
            child_tenants = sorted(
                all_tenants_df[
                    all_tenants_df["parent_tenant_id"] == parent_tenant_id
                ]["tenant_name"].tolist(),
                key=lambda name: (
                    not name[0].isdigit(),  # Prioritize numeric-starting names
                    name                    # Then sort alphabetically
                ),
            )

            # Add to the dictionary
            tenant_dict[parent_tenant_name] = child_tenants

        # Step 4: Sort tenant_dict keys for consistent display order
        tenant_dict = dict(
            sorted(
                tenant_dict.items(),
                key=lambda item: (
                    not item[0][0].isdigit(),  # Prioritize numeric-starting parent names
                    item[0]
                )
            )
        )
        pages_data_suspend = {}
        pages_data_status = {}
        tenant_module_status = False
        if flag.lower() == 'withoutparameters':
            # Final structured response
            data_dict_all = {"partners_and_sub_partners": tenant_dict}
        
        elif flag.lower() == 'withparameters':
            partner = data.get("Selected_Partner", "")
            sub_partner = data.get('sub_partner') or partner

            # tenant_names = [name for name in [sub_partner, partner] if name]
            if sub_partner != partner:
                tenant_names = [name for name in [sub_partner, partner] if name]
            else:
                tenant_names = sub_partner  
            
            tenants_df = common_utils_database.get_data(
                "tenant",
                {"tenant_name": tenant_names, "is_active": True},  # Assumes backend supports IN query for list
                ["id", "tenant_name", "db_name"]
            )

            # Step 2: Convert result to a dictionary for quick lookup
            #tenant_id_map = dict(zip(tenants_df["tenant_name"], tenants_df["id"]))
            tenant_info_map = {
                    row["tenant_name"]: {"id": row["id"], "db_name": row["db_name"]}
                    for _, row in tenants_df.iterrows()
                }
            

            # if len(tenant_id_map) == 1:
            #     # Only one match found → assign it to sub_tenant_id
            #     sub_partner_tenant_id = list(tenant_id_map.values())[0]
            #     partner_tenant_id = sub_partner_tenant_id  # Optional: keep both aligned
            # else:
            #     # Match using names if multiple tenants are returned
            #     sub_partner_tenant_id = tenant_id_map.get(sub_partner)
            #     partner_tenant_id = tenant_id_map.get(partner)
            if len(tenant_info_map) == 1:
            # Only one match — use it for both
                only_record = list(tenant_info_map.values())[0]
                sub_partner_tenant_id = only_record["id"]
                # partner_tenant_id = only_record["id"]
                resolved_db_name = only_record["db_name"]
            else:
                sub_partner_tenant_id = tenant_info_map.get(sub_partner, {}).get("id")
                # partner_tenant_id = tenant_info_map.get(partner, {}).get("id")
                
                resolved_db_name = (
                    tenant_info_map.get(sub_partner, {}).get("db_name") or
                    tenant_info_map.get(partner, {}).get("db_name")
                    )

            #connect to db_name database, and get data from service_provider_tenant_configuration
            if resolved_db_name:
                logging.info(f'### resolved_db_name : {resolved_db_name}')
                #database = DB(db_name, **db_config)
                database = DB(resolved_db_name, **db_config)
                service_provider_query = database.get_data(
                    "serviceprovider",
                    {"is_active": True},
                    ["service_provider_name", "id", "integration_id"]
                )
                service_provider_names = service_provider_query['service_provider_name'].tolist()
                service_provider_ids = service_provider_query['id'].tolist()
                integration_ids = service_provider_query['integration_id'].dropna().tolist()
                raw_integration_ids = service_provider_query['integration_id'].tolist()  # May contain None

                # Step 2: Get existing suspension status from carrier_suspension_settings
                suspension_data_query = killbill_database.get_data(
                    "carrier_suspension_settings",
                    {
                        "sub_tenant_id": sub_partner_tenant_id,
                        "service_provider_id": service_provider_ids
                    },
                    ["service_provider_id", "suspension_status"]
                ).to_dict(orient="records")
                logging.info(f'### suspension_data_query : {suspension_data_query}')

                # Step 3: Convert to dict for quick lookup
                suspension_status_map = {
                    item["service_provider_id"]: item["suspension_status"]
                    for item in suspension_data_query
                }
                logging.info(f'### suspension_status_map : {suspension_status_map}')
                # Step 4: Build the final status list with fallback to False
                service_provider_status_list = []
                for _, row in service_provider_query.iterrows():
                    sp_id = row["id"]
                    sp_name = row["service_provider_name"]
                    suspend = suspension_status_map.get(sp_id, False)
                    service_provider_status_list.append({
                        "service_provider_name": sp_name,
                        "suspension_status": suspend
                    })
                
                # Step 3: Fetch device status data
                device_status_query = database.get_data(
                    "device_status",
                    {"integration_id": integration_ids},  # Assumes get_data supports list-based IN filtering
                    ["integration_id", "display_name"]
                )

                device_status_map = defaultdict(list)
                for _, row in device_status_query.iterrows():
                    device_status_map[row['integration_id']].append(row['display_name'])

                sim_status_query = killbill_database.get_data(
                    "sim_status_mapping",
                    {},  # no filters — load full mapping
                    ["service_provider", "amop_status", "billing_platform_status"]
                )

                # Step 5: Build mapping for quick lookup: (provider, sp_status) → bp_status
                sim_status_map = {
                    (row['service_provider'], row['amop_status']): row['billing_platform_status']
                    for _, row in sim_status_query.iterrows()
                }

                # # Step 6: Build final list with sp_status and bp_status
                # service_provider_status_entries = []

                # for name, integration_id in zip(service_provider_names, raw_integration_ids):
                #     statuses = device_status_map.get(integration_id, [None])  # Default to [None] if no status
                #     for status in statuses:
                #         bp_status = sim_status_map.get((name, status))  # Lookup by tuple
                #         service_provider_status_entries.append({
                #             "service_provider_name": name,
                #             "service_provider_status": status,
                #             "billing_platform_status": bp_status
                #         })
                service_provider_id_map = {
                                    row['service_provider_name']: row['id']
                                    for _, row in service_provider_query.iterrows()
                                }
                                # Step 4: Query carrier_status_settings for relevant rows
                carrier_settings_query = killbill_database.get_data(
                    "carrier_status_settings",
                    {
                        "sub_tenant_id": sub_partner_tenant_id,
                        "service_provider_id": list(service_provider_id_map.values())
                    },
                    ["service_provider_id", "service_provider_status", "billing_platform_status"]
                ).to_dict(orient="records")
                
                carrier_settings_map = {
                    (row["service_provider_id"], row["service_provider_status"]): row["billing_platform_status"]
                    for row in carrier_settings_query
                }

                # Step 6: Final loop to construct enriched result
                service_provider_status_entries = []

                for name, integration_id in zip(service_provider_names, raw_integration_ids):
                    sp_id = service_provider_id_map.get(name)
                    statuses = device_status_map.get(integration_id, [None])
                    
                    for status in statuses:
                        db_bp_status = carrier_settings_map.get((sp_id, status))
                        
                        fallback_bp_status = sim_status_map.get((name, status))
                        
                        service_provider_status_entries.append({
                            "service_provider_name": name,
                            "service_provider_status": status,
                            "billing_platform_status": db_bp_status if db_bp_status is not None else fallback_bp_status
                        })

            # Sort the full lists
            service_provider_status_list = sort_data(service_provider_status_list, col_sort)
            service_provider_status_entries = sort_data(service_provider_status_entries, col_sort)
            
            paged_service_provider_status_list = service_provider_status_list[start:end]
            #paged_service_provider_status_entries = service_provider_status_entries[start:end]
            # Step: Fetch service_line_description for sub_tenant
            try:
                logging.info(f'### sub_partner_tenant_id : {sub_partner_tenant_id}')
                service_line_description_df = killbill_database.get_data(
                    "service_line_description",
                    {"sub_tanant_id": sub_partner_tenant_id},
                    ["service_line_description"]
                )
                if not service_line_description_df.empty:
                    logging.info(f'### service_line_description_df : {service_line_description_df}')
                    service_line_description_value = service_line_description_df["service_line_description"].iloc[0]
                else:
                    logging.warning("### bp_settings_list_view No service_line_description found for the sub_tenant.")
                    service_line_description_value = ""
            except Exception as e:
                logging.warning(f"### Failed to fetch service_line_description: {e}")
                service_line_description_value = ""


            #data_dict_all = {"billing_platform_suspend": service_provider_status_list, "billing_platform_status": service_provider_status_entries}
            data_dict_all = {
                "billing_platform_suspend": paged_service_provider_status_list,
                "billing_platform_status": service_provider_status_entries
            }
            # Add to response data
            data_dict_all["service_line_description"] = service_line_description_value
            pages_data_suspend = {
                "start": start,
                "end": end,
                "total": len(service_provider_status_list),
            }
            pages_data_status = {
                "start": start,
                "end": end,
                "total": len(service_provider_status_entries),
            }

            #get status of billing_platform sub_partner
            tenant_module_query = common_utils_database.get_data(
                "tenant_module",
                {"tenant_id": sub_partner_tenant_id, "module_name": "Billing Platform"},
                ["is_active"]
            )
            tenant_module_status = tenant_module_query['is_active'].to_list()[0]


        headers_map = get_headers_mapping(
                    common_utils_database,
                    ["Suspension Settings Data", "Carrier Mapping Data"],
                    role_name,
                    username,
                    "",
                    "",
                    "parent_module",
                    data,
                    common_utils_database,
                )        
        response = {
            "flag": True,
            "data": serialize_data(data_dict_all),
            "partners_and_sub_partners": tenant_dict,
            "headers_map": headers_map,
            "pages_data_suspend": pages_data_suspend,
            "pages_data_status": pages_data_status,
            "billing_platfrom_enable_flag" : tenant_module_status
        }

        try:
            audit_data_user_actions = {
                "service_name": "bp_settings_list_view",
                "created_by": username,
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "module_name": "Module Management",
                "comments": "Succesfully Fetched BP Settings Data",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception is : {e}")
        return response

    except Exception as e:
        # Log or handle the error accordingly
        logging.info(f"### Error in bp_settings_suspended_list_view: {str(e)}")
        # message = "Something went wrong while fetching bp_settings__list_view data {e}"
        # response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "bp_settings_list_view",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "comments": "Error in fetching BP Settings Data",
                "module_name": "Module Management",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Exception is : {e}")
        return {
            "flag": True,
            "message": "Unable to fetch Billing Platfrom Data"
        }

def update_carrier_suspend_status(data):
    """
    Updates carrier suspension status and mapping data in the billing platform database.

    This function handles two types of updates:
    1. Suspension Settings Data: Updates service provider suspension statuses
    2. Carrier Mapping Data: Updates service provider status mappings

    Args:
        data (dict): A dictionary containing:
            - db_name (str): Target database name
            - role_name (str): User's role for permission checking
            - tenant_name (str): Tenant name
            - username (str): User performing the operation
            - changed_data (list): List of dictionaries containing update data
            - tenant_id (int): Tenant ID
            - Selected_Partner (str): Partner name
            - sub_partner (str): Sub-partner name
            - table_name (str): Target table name ('carrier_suspension_settings')
            - module_name (str): Module name ('Suspension Settings Data' or 'Carrier Mapping Data')

    Returns:
        dict: A response dictionary containing:
            - flag (bool): True if operation succeeded, False otherwise
            - message (str): Status message
    """
    # Initialize DB connections using environment variables and shared configuration
    # database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

    tenant_db_name = data.get('db_name', '')
    tenant_database = DB(tenant_db_name, **db_config)

    # Extract input filters from request payload with default fallbacks
    # role_name = data.get('role_name', '')
    # tenant_name = data.get('tenant_name', '')
    # db_name = data.get('db_name', '')
    username = data.get("username", None)
    changed_data = data.get('changed_data', {})
    # tenant_id = data.get('tenant_id', 0)
    partner_name = data.get('Selected_Partner', 0)
    sub_tenant_name = data.get('sub_partner') or partner_name
    table_name = data.get('table_name', 'carrier_suspension_settings')
    module_name = data.get('module_name', '')

    try:
        if sub_tenant_name != partner_name:
            tenant_names = [name for name in [sub_tenant_name, partner_name] if name]
        else:
            tenant_names = sub_tenant_name

        # Step 3: Fetch matching tenants in a single query
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_names},  # Assuming your get_data handles `IN` condition for lists
            ["id", "tenant_name"]
        )

        # Step 4: Map tenant_name to id
        tenant_map = dict(zip(tenant_df["tenant_name"], tenant_df["id"]))
        logging.info(f"### tenant_map: {tenant_map}")

        if len(tenant_map) == 1:
            # Only one match found → assign it to sub_tenant_id
            sub_tenant_id = list(tenant_map.values())[0]
            partner_id = sub_tenant_id  # Optional: keep both aligned
        else:
            # Match using names if multiple tenants are returned
            sub_tenant_id = tenant_map.get(sub_tenant_name)
            partner_id = tenant_map.get(partner_name)
        logging.info(f"### sub_tenant_id: {sub_tenant_id}, partner_id: {partner_id}")
        #get service_providers_ from chnages data and make as alist 
        service_providers = [item['service_provider_name'] for item in changed_data if 'service_provider_name' in item]
        #get ids from serviceprovider table
        service_provider_id_query = tenant_database.get_data(
            "serviceprovider",
            {"is_active": True, "service_provider_name": service_providers},
            ["id", "service_provider_name"]
        ).to_dict(orient='records')
        logging.info(f"### service_provider_id_query: {service_provider_id_query}")
        service_provider_list = {item['service_provider_name']: item['id'] for item in service_provider_id_query}
        logging.info(f"### service_provider_list: {service_provider_list}")
        try:
            for item in changed_data:
                item['tenant_id'] = partner_id
                item['tenant_name'] = partner_name
                item['service_provider_id'] = service_provider_list.get(item['service_provider_name'], None)
                item['sub_tenant_id'] = sub_tenant_id
                item['created_by'] = username
                item['modified_by'] = username
                item['is_active'] = True
                item['is_deleted'] = False
        except Exception as e:
            logging.info(f"### Exception occurred while processing changed_data: {e}")
        #insert the changed data into table_name 
        logging.info(f"### changed_data: {changed_data}")
        update_data = []
        insert_data = []
        if module_name == 'Suspension Settings Data':
            existing_rows = killbill_database.get_data(
            table_name,
            {
                "sub_tenant_id": sub_tenant_id,
                "service_provider_id": [item["service_provider_id"] for item in changed_data]
                },
            []
            ).to_dict(orient='records')
            existing_sp_ids = {row["service_provider_id"] for row in existing_rows}
            for item in changed_data:
                if item["service_provider_id"] in existing_sp_ids:
                    update_data.append(item)
                else:
                    insert_data.append(item)

        
        elif module_name == 'Carrier Mapping Data':
            existing_rows = killbill_database.get_data(
            table_name,
            {
                "sub_tenant_id": sub_tenant_id,
                "service_provider_id": [item["service_provider_id"] for item in changed_data],
                "service_provider_status":[item["service_provider_status"] for item in changed_data]
                },
            []
            ).to_dict(orient='records')
            existing_keys = {
                (row["service_provider_id"], row["service_provider_status"]) for row in existing_rows
            }

            for item in changed_data:
                key = (item["service_provider_id"], item["service_provider_status"])
                if key in existing_keys:
                    update_data.append(item)
                else:
                    insert_data.append(item)

        # Perform update
        for update_item in update_data:
            logging.info(f"### Updating :  {update_item}")
            if module_name == 'Suspension Settings Data':
                where_clause = {
                    "sub_tenant_id": sub_tenant_id,
                    "service_provider_id": update_item["service_provider_id"]
                }
            elif module_name == 'Carrier Mapping Data':
                where_clause = {
                    "sub_tenant_id": sub_tenant_id,
                    "service_provider_id": update_item["service_provider_id"],
                    "service_provider_status": update_item["service_provider_status"]
                }
            try:
                killbill_database.update_dict(
                    table_name,
                    update_item,
                    where_clause
                )
            except Exception as e:
                logging.info(f"### Exception occurred while updating {update_item}: {e}")
                response = {
                    "flag": False,
                    "message": f"Error updating {update_item['service_provider_name']} in {table_name}",
                    "data": {}
                }

        if insert_data:
            try:
                killbill_database.insert_data(insert_data, table_name)
            except Exception as e:
                logging.info(f"### Exception occurred while inserting data: {e}")
                response = {
                    "flag": False,
                    "message": "Error inserting data into carrier_suspension_settings"
                    }
        
        response = {
            "flag": True,
            "message": "Data inserted successfully into carrier_suspension_settings"
            }
        

        try:
            audit_data_user_actions = {
                "service_name": "update_carrier_suspend_status",
                "created_by": data.get("username", ""),
                "status": str(response['flag']) or "",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": "Carrier suspend status update executed successfully",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")

        return response
    
    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception("### Error occurred during carrier suspend status update : {e}")
        message= "Error while updating carrier suspend status in user_module_tenant_mapping table"

        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "update_carrier_suspend_status",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            
        # return {"flag": True, "message": f"sim_management_inventory - {str(e)}"}
        response = {
            "flag": False,
            "message": "Error processing changed data"
        }
        return response


def enabling_billing_platform(data):
    """
    Enables or disables the billing platform module for a tenant.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): Target database name
            - role_name (str): User's role for permission checking
            - status (str): Status flag
            - username (str): User performing the operation
            - changed_data (dict): Contains 'is_active' status to set
            - tenant_id (int): Tenant ID
            - Selected_Partner (str): Partner name
            - sub_partner (str): Sub-partner name
            - module_name (str): Module name (default 'Billing Platform')

    Returns:
        dict: A response dictionary containing:
            - flag (bool): True if operation succeeded, False otherwise
            - message (str): Status message
            - get_module_check (bool): Indicates if sub_tenant matches tenant_name
    """
    # Initialize DB connections using environment variables and shared configuration
    # database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    # killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

    # tenant_db_name = data.get('db_name', '')
    # tenant_database = DB(tenant_db_name, **db_config)
    # Extract input filters from request payload with default fallbacks
    tenant_name = data.get('tenant_name', '')
    changed_data = data.get('changed_data', {})
    # tenant_id = data.get('tenant_id', 0)
    partner_name = data.get('Selected_Partner', 0)
    sub_tenant_name = data.get('sub_partner') or partner_name
    # module_name = data.get('module_name', 'Billing Platform')
    changed_data = data.get('changed_data', {})
    is_active = changed_data.get('is_active', False)
    if sub_tenant_name.lower() == tenant_name.lower():
        get_module_check = True
    else:
        get_module_check = False

    #we need to update the is_active status of tenant_module
    sub_tenant_id = common_utils_database.get_data(
            "tenant",
            {"tenant_name": sub_tenant_name},
            ["id"] 
        )
    #get the id from sub_tenant_id dataframe
    sub_tenant_id = sub_tenant_id['id'].to_list()[0] if not sub_tenant_id.empty else None
    mode=os.getenv('ENV','UAT')
    #updated_data = {"is_active": False, "is_deleted": True}
    try:
        common_utils_database.update_dict(
            "tenant_module",
            changed_data,
            {
                "tenant_id": sub_tenant_id,
                "module_name": "Billing Platform"
            }
        )
        if mode=='UAT':
            if sub_tenant_name == 'Altaworx Test':
                sub_tenant_id = 1
        common_utils_database.update_dict(
            "tenant",
            {"billing_platform_flag":is_active},
            {"id":sub_tenant_id}
        )
        response =  {
            "flag": True,
            "message": "Tenant module updated successfully",
            "get_module_check": get_module_check,
        }


        try:
            audit_data_user_actions = {
                "service_name": "enabling_billing_platform",
                "created_by": data.get("username", ""),
                "status": str(response['flag']),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": "Billing platform module status updated successfully",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")

        return response 
    
    # except Exception as e:
    #     logging.exception(f"### enabling_billing_platform Exception occurred while updating tenant_module: {e}")
    #     response =  {
    #         "flag": False,
    #         "message": "Error updating tenant module",
    #         "get_module_check": get_module_check,
    #     }
    #     return response 

    except Exception as e :
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### enabling_billing_platform Exception occurred while updating tenant_module: {e}")
        message = "Error while updating billing platform module for tenant"

        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "enabling_billing_platform",
                "error_message":str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message ,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}") 
            
        # return {"flag": True, "message": f"sim_management_inventory - {str(e)}"}
        response =  {
            "flag": False,
            "message": "Error updating tenant module",
            "get_module_check": get_module_check,
        }
        return response
    
def update_service_line_description_backup(data):
    logging.info(f"### update_service_line_description called with data: {data}")

    try:
        from datetime import datetime
        current_time = datetime.now()

        partner_name = data.get('Selected_Partner', "")
        sub_tenant_name = data.get('sub_partner') or partner_name

        # Determine the list of tenant names
        if sub_tenant_name != partner_name:
            tenant_names = [name for name in [sub_tenant_name, partner_name] if name]
        else:
            tenant_names = [sub_tenant_name]

        # Fetch tenant IDs
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        billing_platform_db = DB(os.environ["BILLING_PLATFORM"], **db_config)
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_names},
            ["id", "tenant_name"]
        )
        tenant_map = dict(zip(tenant_df["tenant_name"], tenant_df["id"]))

        if len(tenant_map) == 1:
            sub_tenant_id = list(tenant_map.values())[0]
            partner_id = sub_tenant_id
        else:
            sub_tenant_id = tenant_map.get(sub_tenant_name)
            partner_id = tenant_map.get(partner_name)

        # Form new_data for insert/update
        new_data = {
            "tenant_id": partner_id,
            "sub_tanant_id": sub_tenant_id,
            "tenant_name": partner_name,
            "sub_tanant_name": sub_tenant_name,
            "service_line_description": data["changed_data"]["service_line_description"],
            "modified_by": data.get("firstLastName", "System"),
            "modified_date": current_time,
            "created_by": data.get("firstLastName", "System"),
            "created_date": current_time
        }

        # Connect to tenant database
        # tenant_database = data.get("db_name", "")
        # database = DB(tenant_database, **db_config)

        # Check if record already exists
        check_df = billing_platform_db.get_data(
            "service_line_description", {"sub_tanant_id": sub_tenant_id}, ["id"]
        )

        if not check_df.empty:
            # Update existing record
            update_dict = {
                "service_line_description": new_data["service_line_description"],
                "modified_by": new_data["modified_by"],
                "modified_date": new_data["modified_date"]
            }
            billing_platform_db.update_dict(
                "service_line_description", update_dict, {"sub_tanant_id": sub_tenant_id}
            )
            message = "Service line description updated successfully."
        else:
            # Insert new record
            billing_platform_db.insert_data(new_data,"service_line_description")
            message = "Service line description created successfully."

        return {"flag": True, "message": message}

    except Exception as e:
        logging.exception(f"update_service_line_description encountered an error: {e}")
        return {"flag": False, "message": "Failed to update/create service line description."}



def update_service_line_description(data):
    """
    Inserts or updates the service line description for a given sub-tenant under a partner.

    This function:
    1. Extracts partner and sub-partner names from the input data.
    2. Resolves the tenant IDs for both partner and sub-partner using the common_utils tenant table.
    3. Checks if an entry for the sub-tenant already exists in the `service_line_description` table.
       - If it exists, it updates the `service_line_description` and modified metadata.
       - If not, it creates a new record with both creation and modification metadata.
    
    Parameters:
        data (dict): Dictionary containing tenant info, user info, and the changed service line description.

    Returns:
        dict: A dictionary indicating success (`flag`) and a descriptive `message`.
    """
    logging.info(f"### update_service_line_description called with data: {data}")

    try:
        from datetime import datetime
        current_time = datetime.now()

        # Extract partner and sub-partner from the request
        partner_name = data.get('Selected_Partner', "")
        sub_tenant_name = data.get('sub_partner') or partner_name

        # Build list of tenant names to look up
        if sub_tenant_name != partner_name:
            tenant_names = [name for name in [sub_tenant_name, partner_name] if name]
        else:
            tenant_names = [sub_tenant_name]

        # Connect to required databases
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        billing_platform_db = DB(os.environ["BILLING_PLATFORM"], **db_config)

        # Get tenant information from the common_utils database
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_names},
            ["id", "tenant_name"]
        )
        tenant_map = dict(zip(tenant_df["tenant_name"], tenant_df["id"]))

        # Resolve tenant IDs
        if len(tenant_map) == 1:
            sub_tenant_id = list(tenant_map.values())[0]
            partner_id = sub_tenant_id
        else:
            sub_tenant_id = tenant_map.get(sub_tenant_name)
            partner_id = tenant_map.get(partner_name)

        # Form data dictionary to be inserted or updated
        new_data = {
            "tenant_id": partner_id,
            "sub_tanant_id": sub_tenant_id,
            "tenant_name": partner_name,
            "sub_tanant_name": sub_tenant_name,
            "service_line_description": data["changed_data"]["service_line_description"],
            "modified_by": data.get("firstLastName", "System"),
            "modified_date": current_time,
            "created_by": data.get("firstLastName", "System"),
            "created_date": current_time
        }

        # Also connect to tenant-specific database (if needed later)
        # tenant_database = data.get("db_name", "")
        # database = DB(tenant_database, **db_config)

        # Check if a record for this sub-tenant already exists
        check_df = billing_platform_db.get_data(
            "service_line_description", {"sub_tanant_id": sub_tenant_id}, ["id"]
        )

        if not check_df.empty:
            # If record exists, update it
            update_dict = {
                "service_line_description": new_data["service_line_description"],
                "modified_by": new_data["modified_by"],
                "modified_date": new_data["modified_date"]
            }
            billing_platform_db.update_dict(
                "service_line_description", update_dict, {"sub_tanant_id": sub_tenant_id}
            )
            message = "Service line description updated successfully."
        else:
            # Else insert new record
            billing_platform_db.insert_data(new_data,"service_line_description")
            message = "Service line description created successfully."

        return {"flag": True, "message": message}

    except Exception as e:
        logging.exception(f"update_service_line_description encountered an error: {e}")
        return {"flag": False, "message": "Failed to update/create service line description."}


def get_update_service_type_mapping(data):
    """
    Get or update service type mappings for providers (m2m, mobility).
    
    Args:
        data (dict): Request data containing action, db_name, tenant_name, changed_data
        
    Returns:
        dict: Result with flag, selected_data, service_type_mapping, and message
    """
    logging.info(f"### get_update_service_type_mapping request data : {data}")
    start_time = time.time()

    db_name = data.get("db_name", "")
    tenant_name = "Altaworx" if data.get("tenant_name") == "Altaworx Test" else data.get("tenant_name", "")
    action = data.get("action","get")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    session_id = data.get("session_id")
    tenant_database = DB(db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    changed_data = data.get("changed_data",{})
    result = {}
    try:
        integration_authentication_json_data = load_integration_authentication_json()
        integration_auth_id = get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)
        if not integration_auth_id:
            query=f'''select parent_tenant_id from tenant where tenant_name='{tenant_name}'
            '''
            parent_tenant_id=common_utils_database.execute_query(query,True)['parent_tenant_id'].to_list()[0]
            if parent_tenant_id:
                parent_tenant_id=int(parent_tenant_id)
            parent_tenant_query=f'''select tenant_name from tenant where id={parent_tenant_id}
            '''
            parent_tenant_name=common_utils_database.execute_query(parent_tenant_query,True)['tenant_name'].to_list()[0]
            integration_auth_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, parent_tenant_name)
        if action == "update":
            for provider_type, records in changed_data.items():
                if len(records) < 1:
                    continue # Skip if no records for this provider type
                service_type_ids = [rec.get("service_type_id") for rec in records]
                service_type_descptions = [rec.get("description") for rec in records]
                
                # Check for mismatch between IDs and descriptions
                if len(service_type_descptions) != len(service_type_ids):
                    logging.info(f"### get_update_service_type_mapping len mismatch service_type_descptions({len(service_type_descptions)}) and service_type_ids({len(service_type_ids)})")
                    return {"flag":False, "message":"service type id or description missing"}
                # fetch rev_service_type_ids of service_type_ids from rev_service_type table
                query = f"""
                    SELECT id
                    FROM rev_service_type
                    WHERE service_type_id IN ({','.join(map(str, service_type_ids))})
                    AND integration_authentication_id = {integration_auth_id}
                    AND is_active = TRUE
                    AND is_deleted = FALSE;
                """
                rev_service_type_ids = tenant_database.execute_query(query,True)["id"].to_list()
                logging.info(f"rev_service_type_ids -- {rev_service_type_ids}")
                # Prepare data for update
                data_to_update = {
                    "service_type_id":json.dumps(service_type_ids),
                    "service_type_description":json.dumps(service_type_descptions),
                    "is_active":True,
                    "is_deleted":False,
                    "modified_date":datetime.datetime.now(),
                    "modified_by":username,
                    "rev_service_type_ids":", ".join(map(str, rev_service_type_ids))
                }
                # Try to update existing mapping
                is_updated = tenant_database.update_dict(
                    "service_type_mapping",
                    data_to_update,
                    {"service_provider_type":provider_type})
                # If update fails, insert a new mapping record
                if not is_updated:
                    data_to_update.update(
                        {"created_date":datetime.datetime.now(),"created_by":username,"service_provider_type":provider_type}
                         )
                    is_inserted = tenant_database.insert_data(
                        data_to_update,"service_type_mapping"
                    )
                    logging.info(f"### get_update_service_type_mapping inserted -- {is_inserted}")

        mapped_service_types_df = tenant_database.get_data(
            "service_type_mapping",
            {"is_active":True,"is_deleted":False},
            ["service_provider_type","service_type_description","service_type_id"]
        )
        if mapped_service_types_df.empty:
            selected_data = {
                "m2m":[],
                "mobility":[]
            }
        else:
            selected_data = {"m2m": [], "mobility": []}
            for _, row in mapped_service_types_df.iterrows():
                provider_type = row.get("service_provider_type")

                # Skip rows with missing or empty provider_type
                if not provider_type or str(provider_type).strip() == "":
                    logging.warning("### get_update_service_type_mapping Skipping row with empty service_provider_type")
                    continue
                try:
                    type_ids = json.loads(row["service_type_id"])
                    descriptions = json.loads(row["service_type_description"])
                except Exception as e:
                    logging.warning(f"### get_update_service_type_mapping JSON decode failed for row: {row}, error: {e}")
                    continue

                if len(type_ids) != len(descriptions):
                    logging.warning(f"### get_update_service_type_mapping ID/description mismatch for provider_type: {provider_type}")
                    continue
                
                # Only update known types (m2m, mobility) — ignore anything else
                if provider_type in selected_data:
                    selected_data[provider_type] = [
                        {"service_type_id": sid, "description": desc}
                        for sid, desc in zip(type_ids, descriptions)
                    ]
                else:
                    logging.warning(f"### get_update_service_type_mapping Unknown provider_type found in DB: {provider_type}")

            
        result["selected_data"] = selected_data
        # Get active, non-deleted service type mappings
        service_type_mapping_df = tenant_database.get_data(
            "rev_service_type",
            {"integration_authentication_id":integration_auth_id,"is_active": True, "is_deleted": False},
            ["service_type_id", "description"]
        )
        result["service_type_mapping"] = service_type_mapping_df.to_dict(orient="records")
        result["flag"] = True
        comments = json.dumps(changed_data) if action == "update" else "Service Type Mapping fetched"
        try:
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "get_update_service_type_mapping",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(result["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": comments,
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### get_update_service_type_mapping audit_user_actions Exception is {e}")
        return result
    except Exception as e:
        logging.exception(f"### get_update_service_type_mapping exception : {e}")
        try:
            comments = json.dumps(changed_data) if action == "update" else "Fetching Service Type Mapping failed"
            # Log error to database
            error_data = {
                "service_name": "get_update_service_type_mapping",
                "created_date": request_received_at,
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": comments,
                "module_name": "Module Managament",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### get_update_service_type_mapping error_log_table Exception is {e}")
        return {"flag": False, "message": "Service Type Mapping Failed"}


def glcode_list_view(data):
    """
    Fetches and processes GL code data based on the provided filters.

    Args:
        data (dict): Request data containing filters like tenant_name, sub_partner, module_name, etc.

    Returns:
        dict: Processed GL code data with pagination and other metadata.
    """
    logging.info(f"### glcode_list_view request data : {data}")
    killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    role_name = data.get('role_name', '')
    tenant_name = data.get('tenant_name', '')
    tenant_id = data.get('tenant_id', None)
    username = data.get('username', '')
    session_id = data.get('session_id', '')
    module_name = data.get('module_name', '')
    request_received_at = data.get('request_received_at', '')
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end',10)
    col_sort = data.get("col_sort", "")
    partner_name = data.get('Selected_Partner', 0)
    sub_tenant_name = data.get('sub_partner') or partner_name

    try:
        if sub_tenant_name != partner_name:
            tenant_names = [name for name in [sub_tenant_name, partner_name] if name]
        else:
            tenant_names = sub_tenant_name

        # Step 3: Fetch matching tenants in a single query
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_names},  # Assuming your get_data handles `IN` condition for lists
            ["id", "tenant_name"]
        )

        # Step 4: Map tenant_name to id
        tenant_map = dict(zip(tenant_df["tenant_name"], tenant_df["id"]))
        logging.info(f"### tenant_map: {tenant_map}")

        if len(tenant_map) == 1:
            # Only one match found → assign it to sub_tenant_id
            sub_tenant_id = list(tenant_map.values())[0]
            partner_id = sub_tenant_id  # Optional: keep both aligned
        else:
            # Match using names if multiple tenants are returned
            sub_tenant_id = tenant_map.get(sub_tenant_name)
            partner_id = tenant_map.get(partner_name)
        
        # fetch count
        total_count_result = killbill_database.get_data(
                "gl_code", {"sub_tenant_id":sub_tenant_id},["id"]
            )["id"].to_list()
        total_count=len(total_count_result)

        
        pages_data = {
        "start": start,
        "end": end,
        "total": total_count
        }
        # sorting
        if col_sort:
            order =  {k: v.lower() for k, v in col_sort.items()}
        else:
            order={"gl_codes":"asc"}

        # Fetch GL codes
        gl_codes = killbill_database.get_data(
            table_name='gl_code',
            # {'tenant_id': tenant_id},
            condition={"sub_tenant_id":sub_tenant_id},
            columns=['gl_codes', 'gl_code_name', 'gl_code_description','is_active','modified_by','modified_date',"id"],
            order=order,
            mod_pages={"start": start, "end": end}
        )
        # if gl_codes.empty:
        #     logging.info("###glcode_list_view: No GL codes found.")
        #     return {"flag": True, "message": "No GL codes found."}
        gl_codes_dict= gl_codes.to_dict(orient='records')

        gl_codes_dict=serialize_data(gl_codes_dict)
        data_dict_all={"billing_gl_code":gl_codes_dict}
        print(f"data_dict_all---{data_dict_all}")


        headers_map = get_headers_mapping(
                    common_utils_database,
                    ["Billing GL Code"],
                    role_name,
                    username,
                    "",
                    "",
                    "parent_module",
                    data,
                    common_utils_database,
                )
       
        print(f"headers_map---{headers_map}")
        response = {
            "flag": True,
            "data": data_dict_all,
            "headers_map": headers_map,
            "pages": pages_data,
        }  
        return response
    except Exception as e:
        logging.info(f"###glcode_list_view:Function Exception in List View {e}")
        response = {"flag": False, "message": "An error occurred."}
        database.log_error_to_db({
            "service_name": "glcode_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": "Failed to fetch GL codes",
            "module_name": module_name,
            "request_received_at": request_received_at
        }, "error_log_table")   
        return response



def add_glcode(data):
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    common_utils_database= DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    # tenant_name = data.get('tenant_name', '')
    username = data.get('username','')
    session_id = data.get('session_id','')
    module_name = data.get('module_name','')
    request_received_at = data.get('request_received_at','')
    partner_name = data.get('Selected_Partner', 0)
    sub_tenant_name = data.get('sub_partner') or partner_name

    try:
        if sub_tenant_name != partner_name:
            tenant_names = [name for name in [sub_tenant_name, partner_name] if name]
        else:
            tenant_names = sub_tenant_name

        # Step 3: Fetch matching tenants in a single query
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_names},  # Assuming your get_data handles `IN` condition for lists
            ["id", "tenant_name"]
        )

        # Step 4: Map tenant_name to id
        tenant_map = dict(zip(tenant_df["tenant_name"], tenant_df["id"]))
        logging.info(f"### tenant_map: {tenant_map}")

        if len(tenant_map) == 1:
            # Only one match found → assign it to sub_tenant_id
            sub_tenant_id = list(tenant_map.values())[0]
            partner_id = sub_tenant_id  # Optional: keep both aligned
        else:
            # Match using names if multiple tenants are returned
            sub_tenant_id = tenant_map.get(sub_tenant_name)
            partner_id = tenant_map.get(partner_name)

        # Add GL code
        changed_data=data.get('changed_data',None)
        gl_codes = changed_data.get('gl_codes')
        gl_code_name = changed_data.get('gl_code_name')
        gl_code_description = changed_data.get('gl_code_description','')

        gl_code_data = killbill_database.get_data(
            'gl_code',
            {'sub_tenant_id': sub_tenant_id, 'gl_codes': gl_codes},
            ['id']
        )
        print(f"gl_code_data---{gl_code_data}")
        if not gl_code_data.empty:
            return {"flag": False, "message": "GL Code already exists."}
        insertion_data = {
            "tenant_id": partner_id,
            "sub_tenant_id": sub_tenant_id,
            "tenant_name": partner_name,
            "gl_codes": gl_codes,
            "gl_code_name": gl_code_name,
            "gl_code_description": gl_code_description,
            "created_by":username,
            "modified_by":username
            }
        inserted_id = killbill_database.insert_data(insertion_data, 'gl_code')
        if not inserted_id:
            error_message = "Failed to insert GL code into database."
            database.log_error_to_db({
                "service_name": "add_glcode",
                "username": username,
                "session_id": session_id,
                "module_name": module_name,
                "request_received_at": request_received_at,
                "error_message": error_message
                },"log_error_to_db")
            return {"flag": False, "message": "Failed to add GL code."}
        # Log audit
        database.update_audit({
            "service_name": "add_glcode",
            "module_name": module_name,
            "username": username,
            "session_id": session_id,
            "request_received_at": request_received_at,
            "data": data
            },"audit_user_actions")
        return {"flag": True, "message": "GL Code added successfully."}
    except Exception as e:
        error_message = "Failed to add GL code"
        database.log_error_to_db({
            "service_name": "add_glcode",
            "module_name": module_name,
            "username": username,
            "session_id": session_id,
            "request_received_at": request_received_at,
            "error_message": str(e)
            },"error_log_table")
        return {"flag": False, "message": f"Failed to add GL code :{e} "}

def update_glcode(data):
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    common_utils_database= DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    # tenant_name = data.get('tenant_name', '')
    username = data.get('username','')
    session_id = data.get('session_id','')
    module_name = data.get('module_name','')
    request_received_at = data.get('request_received_at','')
    partner_name = data.get('Selected_Partner', 0)
    sub_tenant_name = data.get('sub_partner') or partner_name

    try:
        if sub_tenant_name != partner_name:
            tenant_names = [name for name in [sub_tenant_name, partner_name] if name]
        else:
            tenant_names = sub_tenant_name

        # Step 3: Fetch matching tenants in a single query
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_names},  # Assuming your get_data handles `IN` condition for lists
            ["id", "tenant_name"]
        )

        # Step 4: Map tenant_name to id
        tenant_map = dict(zip(tenant_df["tenant_name"], tenant_df["id"]))
        logging.info(f"### tenant_map: {tenant_map}")

        if len(tenant_map) == 1:
            # Only one match found → assign it to sub_tenant_id
            sub_tenant_id = list(tenant_map.values())[0]
            partner_id = sub_tenant_id  # Optional: keep both aligned
        else:
            # Match using names if multiple tenants are returned
            sub_tenant_id = tenant_map.get(sub_tenant_name)
            partner_id = tenant_map.get(partner_name)

        # Add GL code
        changed_data=data.get('changed_data',None)
        gl_codes = changed_data.get('gl_codes')
        gl_code_name = changed_data.get('gl_code_name')
        gl_code_description = changed_data.get('gl_code_description','')
        gl_code_id=changed_data.get("id",None)

        # gl_code_data = killbill_database.get_data(
        #     'gl_code',
        #     {'sub_tenant_id': sub_tenant_id, 'gl_codes': gl_codes},
        #     ['id']
        # )

        # query to get whether gl_code already present or not
        query="select id from gl_code where sub_tenant_id=%s and gl_codes=%s and id !=%s "
        gl_code_data=killbill_database.execute_query(query, params=[sub_tenant_id,gl_codes,gl_code_id])
        print(f"gl_code_data---{gl_code_data}")
        if not gl_code_data.empty:
            return {"flag": False, "message": "GL Code already exists."}
        update_data = {
            "gl_codes": gl_codes,
            "gl_code_name": gl_code_name,
            "gl_code_description": gl_code_description,
            "modified_by":username
            }
        updated_dict = killbill_database.update_dict('gl_code',update_data,{"id":gl_code_id})
        if not updated_dict:
            error_message = "Failed to Update GL code into database."
            database.log_error_to_db({
                "service_name": "update_glcode",
                "username": username,
                "session_id": session_id,
                "module_name": module_name,
                "request_received_at": request_received_at,
                "error_message": error_message
                },"log_error_to_db")
            return {"flag": False, "message": "Failed to Update GL code."}
        # Log audit
        database.update_audit({
            "service_name": "update_glcode",
            "module_name": module_name,
            "username": username,
            "session_id": session_id,
            "request_received_at": request_received_at,
            "data": data
            },"audit_user_actions")
        return {"flag": True, "message": "GL Code Updated successfully."}
    except Exception as e:
        error_message = "Failed to Update GL code"
        database.log_error_to_db({
            "service_name": "add_glcode",
            "module_name": module_name,
            "username": username,
            "session_id": session_id,
            "request_received_at": request_received_at,
            "error_message": str(e)
            },"error_log_table")
        return {"flag": False, "message": f"Failed to Update GL code :{e}"}

def deactivate_glcode(data):
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    # tenant_name = data.get('tenant_name', '')
    username = data.get('username','')
    session_id = data.get('session_id','')
    module_name = data.get('module_name','')
    request_received_at = data.get('request_received_at','')
    changed_data=data.get('changed_data', None)
    is_active = changed_data.get('is_active', None)
    if is_active:
        status="Activate"
    else:
        status="Deactivate"

    try:
        # Deactivate GL code
        gl_code_id=changed_data.get("id",None)
        update_data = {
            "is_active":is_active,
            "modified_by":username
            }
        updated_dict = killbill_database.update_dict('gl_code',update_data,{"id":gl_code_id})
        if not updated_dict:
            error_message = f"Failed to {status} GL code into database."
            database.log_error_to_db({
                "service_name": "deactivate_glcode",
                "username": username,
                "session_id": session_id,
                "module_name": module_name,
                "request_received_at": request_received_at,
                "error_message": error_message
                },"log_error_to_db")
            return {"flag": False, "message": f"Failed to {status} GL code."}
        # Log audit
        database.update_audit({
            "service_name": "deactivate_glcode",
            "module_name": module_name,
            "username": username,
            "session_id": session_id,
            "request_received_at": request_received_at,
            "data": data
            },"audit_user_actions")
        return {"flag": True, "message": f"GL Code {status}d"}
    except Exception as e:
        error_message = "Failed to Deactivate GL code"
        database.log_error_to_db({
            "service_name": "deactivate_glcode",
            "module_name": module_name,
            "username": username,
            "session_id": session_id,
            "request_received_at": request_received_at,
            "error_message": str(e)
            },"error_log_table")
        return {"flag": False, "message": f"Failed to {status} GL code :{e}"}





def get_status_active_lines_list(data):
    """
    Handles export of status active lines report to an S3 bucket.

    Args:
        data (dict): Dictionary containing:
            - z_access_token (str): Required for access authentication.
            - client_id (str): Used to identify the tenant from `service_accounts`.
            - username (str): For audit logging.
            - sessionID (str): For session tracking and logging.
            - Partner (str): Tenant name for audit/error logging.
            - request_received_at (str): Timestamp of request.
            - page (int): Page number (1 = first 30,000 records, 2 = next 30,000, etc.)

    Returns:
        dict: Response with:
            - flag (bool): Always True (even on error, for UI compatibility).
            - message (str): Success or error message.
            - active_lines_report_url (str): Download URL (on success).
            - total_pages (int): Total number of available pages.
            - current_page (int): Current page number returned.
    """
    logging.info(f"received data for active lines list {data}")
    try:
        # 1. Extract required inputs from request data
        z_access_token = data.get("z_access_token", "")
        service_provider_name = data.get("service_provider", "")
        client_id = data.get("client_id", "")

        # 2. Set page number (defaults to 1 if not provided or invalid)
        page_number = int(data.get("page", 1))
        if page_number < 1:
            page_number = 1

        # 3. Set fixed page size
        page_size = 30000  # Number of records per page

        # 4. Calculate offset based on page number
        offset = (page_number - 1) * page_size

        # 5. Setup S3 path and URL
        export_base_path = os.getenv("EXPORT_BASE_PATH")
        S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME")
        file_name = f"{export_base_path}/ActiveLinesReport/Active Lines Report.xlsx"
        download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

        # 6. Initialize common DB
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        # 7. Get tenant name from service_accounts
        service_data = common_utils_database.get_data("service_accounts", {"client_id": client_id})
        if service_data.empty or "tenant" not in service_data.columns:
            logging.error("### No tenant info found for the provided client_id.")
            return {"flag": True, "message": "Tenant not found for the given client_id."}
        tenant = service_data["tenant"].to_list()[0]

        # 8. Normalize test tenants
        if tenant == "Altaworx Test":
            tenant = "Altaworx"
        data["tenant_name"] = tenant

        # 9. Get tenant DB and ID
        result = common_utils_database.get_data("tenant", {"tenant_name": tenant}, ["db_name", "id"])
        if result.empty or "db_name" not in result.columns or "id" not in result.columns:
            logging.error("### Tenant database info not found.")
            return {"flag": True, "message": "Database info not found for tenant."}
        db_name = result["db_name"].to_list()[0]
        tenant_id = result["id"].to_list()[0]

        # 10. Clean up unused DB config keys if any
        db_config.pop("customer_rate_plan_name", None)
        db_config.pop("feature_codes", None)

        # 11. Connect to tenant DB
        try:
            database = DB(db_name, **db_config)
        except Exception as e:
            logging.exception(f"### Exception while connecting to tenant DB: {e}")
            return {"flag": True, "message": "Failed to connect to tenant DB."}

        # 12. Log input data
        logging.info(f"### get_status_active_lines_list export data: {data}")

        # 13. Get total records count for pagination
        count_query = """
            SELECT COUNT(*) FROM sim_management_inventory
            WHERE LOWER(TRIM(sim_status)) IN ('activated', 'active', 'a')
              AND is_active = TRUE
              AND tenant_id = %s
              AND service_provider_display_name = %s
        """
        count_result = database.execute_query(count_query, params=[tenant_id, service_provider_name])
        total_records = int(count_result.iloc[0, 0]) if not count_result.empty else 0
        total_pages = math.ceil(total_records / page_size) if total_records > 0 else 1

        # 14. Fetch paginated records
        active_lines_query = '''
            SELECT
                iccid,
                msisdn,
                customer_rate_plan_name,
                customer_cycle_usage_mb,
                sms_count,
                date_activated,
                service_provider_display_name,
                sim_status
            FROM sim_management_inventory
            WHERE LOWER(TRIM(sim_status)) IN ('activated', 'active', 'a')
              AND is_active = TRUE
              AND tenant_id = %s
              AND service_provider_display_name = %s
            ORDER BY id DESC
            LIMIT %s OFFSET %s
        '''
        params = [tenant_id, service_provider_name, page_size, offset]
        active_lines_df = database.execute_query(active_lines_query, params=params)

        # 15. Handle no results case
        if active_lines_df.empty:
            logging.info("### No active lines found for export.")
            return {
                "flag": True,
                "message": "No active lines found for export.",
                "current_page": page_number,
                "total_pages": total_pages
            }

        # 16. Rename columns and format
        column_mapping = {
            "iccid": "ICCID",
            "msisdn": "MSISDN",
            "service_provider_display_name": "Service Provider Name",
            "customer_rate_plan_name": "Customer Rate Plan Name",
            "customer_cycle_usage_mb": "Customer Cycle Usage MB",
            "sms_count": "SMS Count",
            "date_activated": "Date Activated",
            "sim_status": "Sim Status"
        }
        active_lines_df.rename(columns=column_mapping, inplace=True)
        desired_column_order = list(column_mapping.values())
        active_lines_df = active_lines_df[desired_column_order]

        # 17. Convert DataFrame to Excel in memory
        excel_buffer = BytesIO()
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            active_lines_df.to_excel(writer, index=False, sheet_name="Sheet1")
            sheet = writer.book["Sheet1"]

            # Apply header formatting
            header_font = Font(bold=True)
            center_alignment = Alignment(horizontal="center", vertical="center")
            header_fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
            for col_idx, header_title in enumerate(desired_column_order, 1):
                cell = sheet.cell(row=1, column=col_idx)
                cell.value = header_title
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = center_alignment

            # Center-align all data cells
            for row in sheet.iter_rows(min_row=2, max_row=sheet.max_row, min_col=1, max_col=sheet.max_column):
                for cell in row:
                    cell.alignment = center_alignment

            # Auto-fit column widths
            for col_idx, column_cells in enumerate(sheet.columns, 1):
                max_length = max((len(str(cell.value)) for cell in column_cells if cell.value), default=0)
                sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        excel_buffer.seek(0)

        # 18. Upload to S3
        s3_client = boto3.client("s3")
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=excel_buffer.getvalue(),
            ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

        # 19. Prepare final response (convert numpy/int64 to int)
        response = {
            "flag": True,
            "active_lines_report_url": download_url,
            "total_pages": int(total_pages),
            "current_page": int(page_number)
        }

        # 20. Audit logging
        try:
            audit_data_user_actions = {
                "service_name": "get_status_active_lines_list",
                "created_by": data.get("username", ""),
                "status": str(response.get("flag", "")),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module Management",
                "comments": "Active lines report exported successfully",
                "request_received_at": data.get("request_received_at", "")
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")

        return response

    except Exception as e:
        # Catch unexpected error
        logging.exception(f"### Unexpected get_status_active_lines_list export: {e}")
        message = "Something went wrong in get_status_active_lines_list export"
        error_type = str(type(e).__name__)

        # Attempt error logging
        try:
            error_data = {
                "service_name": "get_status_active_lines_list",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message,
                "module_name": "Module management",
                "request_received_at": data.get("request_received_at", "")
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating error log: {e}")

        return {"flag": True, "message": f"get_status_active_lines_list - {str(e)}"}

def update_device_history_tables(data):
    """
    Updates device history tables with SIM inventory data.

    Args:
        data (dict): Contains db_name, tenant_name, iccids/msisdns, username, and service_provider

    Returns:
        dict: Response with flag indicating success/failure and a message
    """
    logging.info(f"### update_device_history_tables request data {data}")
    start_time = time.time()

    db_name = data.get("db_name", "")
    tenant_name = data.get("tenant_name")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    iccids = data.get("iccids", [])
    msisdns = data.get("msisdns", [])
    effective_date = data.get("effective_date",datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    username = data.get("username")
    service_provider = data.get("service_provider", "") or ""
    request_received_at = data.get("request_received_at", "")

    tenant_database = DB(db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        # ---------- Tenant ----------
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]

        # ---------- Inventory fetch condition ----------
        if iccids:
            condition = {"iccid": iccids, "tenant_id": tenant_id, "is_active": True,"service_provider_display_name":service_provider}
        elif msisdns:
            condition = {"msisdn": msisdns, "tenant_id": tenant_id, "is_active": True,"service_provider_display_name":service_provider}
        else:
            return {"flag": False, "message": "No iccids or msisdns provided."}

        # ---------- Cross-Provider flag ----------
        response = get_cross_provider_optimization_status(data)
        is_cross_provider = response.get("cross_carrier_optimization", False)

        # ---------- Inventory rows ----------
        sim_details_df = tenant_database.get_data("sim_management_inventory", condition)
        if sim_details_df.empty:
            return {"flag": False, "message": "No records found in inventory"}
        sim_rows = sim_details_df.to_dict(orient="records")

        # ---------- service_provider_id ----------
        sp_df = tenant_database.get_data(
            "serviceprovider",
            {"service_provider_name": service_provider, "is_active": True},
            ["id"]
        )
        service_provider_id = sp_df["id"].to_list()[0] if not sp_df.empty else None

        # ---------- Helpers ----------
        def parse_effective_date(dt):
            if not isinstance(dt, str):
                return dt
            for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ",
                        "%Y-%m-%dT%H:%M:%SZ",
                        "%Y-%m-%dT%H:%M:%S",
                        "%Y-%m-%d %H:%M:%S",
                        "%Y-%m-%d"):
                try:
                    return datetime.datetime.strptime(dt, fmt)
                except ValueError:
                    continue
            raise ValueError(f"Unrecognized effective_date format: {dt}")

        def build_base_record(row):
            return {
                "m2m_device_id": row.get("device_id"),
                "mobility_device_id": row.get("mobility_device_id"),
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "msisdn": row.get("msisdn"),
                "imsi": row.get("imsi"),
                "imei": row.get("imei"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "created_by": row.get("created_by"),
                "created_date": row.get("created_date"),
                "modified_by": row.get("modified_by"),
                "modified_date": row.get("modified_date"),
                "account_number": row.get("account_number"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "tenant_id": tenant_id,
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "username": row.get("username"),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "rate_plan": row.get("carrier_rate_plan_name"),
                "last_usage_date": row.get("last_usage_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "last_activated_date": row.get("last_activated_date"),
                "billing_period_id": row.get("billing_period_id"),
                "package": row.get("package"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "cost_center": row.get("cost_center"),
                "communication_plan": row.get("communication_plan"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "is_active":True,
                "is_deleted":False
            }

        def record_for_table(row, table_name):
            base = build_base_record(row)
            if table_name == "cross_provider_device_history":
                return base
            rec = dict(base)
            rec.pop("m2m_device_id", None)
            rec.pop("mobility_device_id", None)
            if table_name == "mobility_device_history":
                rec["id"] = row.get("mobility_device_id")
                rec.pop("cost_center", None)
                rec.pop("communication_plan", None)
                rec.pop("package", None)
                rec.pop("billing_cycle_end_date", None)
                return rec
            if table_name == "device_history":
                rec["id"] = row.get("device_id")
                rec.pop("billing_account_number", None)
                rec.pop("foundation_account_number", None)
                return rec
            return base

        def try_update_then_insert(table_name, record, and_conditions, in_conditions):
            logging.info(f"### trying update_then_insert {table_name} record {record}, and_conditions={and_conditions}, in_conditions={in_conditions}")

            # Remove keys from record that are part of match conditions
            safe_record = {k: v for k, v in record.items() if k not in and_conditions and (not in_conditions or k not in in_conditions)}

            if in_conditions and "customer_billing_period_id" in in_conditions:
                for cbp_id in in_conditions["customer_billing_period_id"]:
                    conds = dict(and_conditions)
                    conds["customer_billing_period_id"] = cbp_id
                    try:
                        updated_id = tenant_database.update_dict(table_name, safe_record, and_conditions=conds)
                        if not updated_id:
                            # update safe_record with conds and insert if update fails
                            logging.info(f"### update_device_history update no existing row found to update in {table_name} with {conds}")
                            safe_record.update(conds)
                            inserted_id = tenant_database.insert_data(safe_record, table_name)
                            logging.info(f"### update_device_history insert {table_name} inserted_id {inserted_id}")
                    except Exception as e:
                        logging.exception(f"### update_device_history update or insert failed for {table_name} with {conds} - {e}")
            else:
                try:
                    for bp in in_conditions.get("billing_period_id", []):
                        conds = dict(and_conditions)
                        conds["billing_period_id"] = bp
                        updated_id = tenant_database.update_dict(table_name, safe_record, and_conditions=conds)
                        if not updated_id:
                            logging.info(f"### update_device_history no existing row found to update in {table_name} with {conds}")
                            safe_record.update(conds)
                            inserted_id = tenant_database.insert_data([safe_record], table_name)
                            logging.info(f"### update_device_history insert {table_name} inserted_id {inserted_id}")
                except Exception as e:
                    logging.exception(f"### update_device_history update failed for {table_name} - {e}")
                    return False


        def target_tables_for(service_provider_name, cross_provider):
            if cross_provider:
                if "Telegence" in service_provider_name:
                    return ["cross_provider_device_history","mobility_device_history"]
                return ["cross_provider_device_history", "device_history"]
            if "Telegence" in service_provider_name:
                return ["mobility_device_history"]
            return ["device_history"]

        # ---------- Allowed billing periods ----------
        eff_dt = parse_effective_date(effective_date)
        if is_cross_provider:
            customer_ids = sim_details_df["customer_id"].dropna().unique().tolist()

            if not customer_ids:
                logging.error("### update_device_history_tables No customer IDs found in inventory records.")
                return {"flag": False, "message": "No customer IDs found in inventory records."}
            
            cust_df = tenant_database.get_data(
                "customers",
                {"id": customer_ids},
                ["id", "customer_bill_period_end_date"]
            )
            # Map customer_id to their billing period end date
            cust_bp_end_date_map = {row["id"]: row["customer_bill_period_end_date"] for _, row in cust_df.iterrows()}
            # Update sim_rows with customer billing period end date
            for row in sim_rows:
                row["customer_bill_period_end_date"] = cust_bp_end_date_map.get(row["customer_id"])

            cbp_q = """SELECT id, bill_year, bill_month FROM customer_billing_period WHERE bill_year > %s
                        OR (bill_year = %s AND bill_month >= %s) AND is_active = True AND is_deleted = False"""
            allowed_cbp_ids = tenant_database.execute_query(
                cbp_q, params=[eff_dt.year, eff_dt.year, eff_dt.month]
            ).to_dict(orient="records")
            
            eff_year, eff_month = eff_dt.year, eff_dt.month
            for row in sim_rows:
                cust_end_date = row.get("customer_bill_period_end_date")
                if isinstance(cust_end_date, str):  # e.g., '28.0'
                    try:
                        cust_end_date = datetime.date.fromisoformat(cust_end_date)
                    except Exception:
                        # fallback if stored as day only, construct with eff_dt's year+month
                        cust_end_date = datetime.date(eff_year, eff_month, int(float(cust_end_date)))
                
                    if eff_dt.date() < cust_end_date:
                        row["allowed_cbp_ids"] = [cbp["id"] for cbp in allowed_cbp_ids]
                    else:
                        row["allowed_cbp_ids"] = [
                            cbp["id"] for cbp in allowed_cbp_ids
                            if not (cbp["bill_year"] == eff_year and cbp["bill_month"] == eff_month)
                        ]
                else:
                    row["allowed_cbp_ids"] = [cbp["id"] for cbp in allowed_cbp_ids]


        bp_q = """SELECT id FROM billing_period WHERE service_provider_id = %s
                    AND billing_cycle_end_date >= %s
                    AND is_active = True AND is_deleted = False"""
        allowed_bp_ids = tenant_database.execute_query(bp_q, params=[service_provider_id, eff_dt])
        allowed_bp_ids = [] if allowed_bp_ids is None or allowed_bp_ids is True else allowed_bp_ids["id"].to_list()

        # ---------- Upsert loop ----------
        for row in sim_rows:
            targets = target_tables_for(service_provider, is_cross_provider)
            for table_name in targets:
                record = record_for_table(row, table_name)
                logging.info(f"### update_device_history_tables prepared record for {table_name}: {record}")
                if table_name == "cross_provider_device_history":
                    allowed_cbp_ids = row.get("allowed_cbp_ids", [])
                    if not allowed_cbp_ids:
                        logging.info(f"### update_device_history_tables skipping cross_provider_device_history for ICCID {row.get('iccid')} as no allowed_cbp_ids")
                        continue
                    and_conds = {"tenant_id": tenant_id}
                    if "Telegence" in service_provider:
                        and_conds["mobility_device_id"] = row.get("mobility_device_id")
                    else:
                        and_conds["m2m_device_id"] = row.get("device_id")
                    in_conds = {"customer_billing_period_id": row.get("allowed_cbp_ids",[])}
                elif table_name == "mobility_device_history":
                    and_conds = {"id": row.get("mobility_device_id"), "tenant_id": tenant_id}
                    in_conds = {"billing_period_id": allowed_bp_ids}

                else:
                    and_conds = {"id": row.get("device_id"), "tenant_id": tenant_id}
                    in_conds = {"billing_period_id": allowed_bp_ids}
                logging.info(f"### update_device_history_tables upserting {table_name} for ICCID {row.get('iccid')} and_conds: {and_conds} in_conds: {in_conds}")
                try_update_then_insert(table_name, record, and_conds, in_conds)

        # ---------- Audit ----------
        try:
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "update_device_history_tables",
                "created_by": username,
                "status": "True",
                "time_consumed_secs": time_consumed,
                "session_id": data.get("session_id"),
                "tenant_name": tenant_name,
                "comments": "update_device_history_tables successfull",
                "module_name": "Module Management",
                "request_received_at": request_received_at or datetime.datetime.now().isoformat(),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### update_device_history_tables audit_user_actions Exception is {e}")
        return {"flag": True, "message": "Device History Tables updated"}

    except Exception as e:
        logging.exception(f"update_device_history_tables exception {e}")
        try:
            comments = json.dumps(iccids) if iccids else json.dumps(msisdns)
            # Log error to database
            error_data = {
                "service_name": "update_device_history_tables",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "session_id": data.get("session_id"),
                "tenant_name": tenant_name,
                "comments": comments,
                "module_name": "Module Managament",
                "request_received_at": request_received_at or datetime.datetime.now().isoformat(),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### update_device_history_tables error_log_table Exception is {e}")
        return {"flag": False, "message": "Device History Tables update Failed"}


def bp_service_providers_list_view(data):
    """
    Fetches service provider records and header mapping for the billing platform.

    Args:
        data (dict): Request parameters for header mapping retrieval.

    Returns:
        dict: Contains success flag, message, serialized service provider data,
              and header mapping.
    """
    start_time = time.time()
    logging.info(f"Initiating bp_service_providers_list_view function.{data}")
    
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    
    partner_name = data.get('Selected_Partner', 0)
    sub_tenant_name = data.get('sub_partner') or partner_name
    role_name = data.get('role_name', 0)
    
    try:
        if sub_tenant_name != partner_name:
            tenant_names = [name for name in [sub_tenant_name, partner_name] if name]
        else:
            tenant_names = sub_tenant_name

        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_names},  # Assuming your get_data handles `IN` condition for lists
            ["id", "tenant_name"]
        )
        
        tenant_map = dict(zip(tenant_df["tenant_name"], tenant_df["id"]))
        logging.info(f"### tenant_map: {tenant_map}")

        if len(tenant_map) == 1:
            # Only one match found → assign it to sub_tenant_id
            sub_tenant_id = list(tenant_map.values())[0]
            partner_id = sub_tenant_id  # Optional: keep both aligned
        else:
            # Match using names if multiple tenants are returned
            sub_tenant_id = tenant_map.get(sub_tenant_name)
            partner_id = tenant_map.get(partner_name)

        service_providers = killbill_database.get_data(
        "serviceprovider",
        {"tenant_id": sub_tenant_id},
        None,
        {"display_name":"asc"}
        ).to_dict(orient='records')

        if not service_providers:
            service_providers = {}

        header_map = get_headers_mapping(common_utils_database,["Service Provider BP"],role_name, '', '', '', '',data, common_utils_database)
        data_dict_all = {"billing_service_providers": serialize_data(service_providers)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map
        }
        return response
    
    except Exception as e:
        logging.exception(f"bp_service_providers_list_view exception {e}")
        return {"flag": False, "message": "bp_service_providers_list_view Failed"}


def add_bp_service_provider(data):
    start_time = time.time()
    logging.info(f"Initiating add_bp_service_provider function.{data}")

    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    
    partner_name = data.get('Selected_Partner', 0)
    sub_tenant_name = data.get('sub_partner') or partner_name
    user_name = data.get('username', '')
    changed_data = data.get('changed_data', {})
    if not changed_data:
        return {"flag": False, "message": "No data provided"}
    try:
        if sub_tenant_name != partner_name:
            tenant_names = [name for name in [sub_tenant_name, partner_name] if name]
        else:
            tenant_names = sub_tenant_name

        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_names},  # Assuming your get_data handles `IN` condition for lists
            ["id", "tenant_name", "db_name"]
        )
        
        tenant_map = dict(zip(tenant_df["tenant_name"], tenant_df["id"]))
        db_map = dict(zip(tenant_df["tenant_name"], tenant_df["db_name"]))
        logging.info(f"### tenant_map: {tenant_map}")

        if len(tenant_map) == 1:
            # Only one match found → assign it to sub_tenant_id
            sub_tenant_id = list(tenant_map.values())[0]
            partner_id = sub_tenant_id  # Optional: keep both aligned
            partner_db_name = list(db_map.values())[0]  # db_name for the selected partner
        else:
            # Match using names if multiple tenants are returned
            sub_tenant_id = tenant_map.get(sub_tenant_name)
            partner_id = tenant_map.get(partner_name)
            partner_db_name = db_map.get(partner_name)

        partner_db = DB(partner_db_name, **db_config)

        duplicate_check = partner_db.get_data("serviceprovider", {"display_name": changed_data.get('display_name', '')}, None)
        logging.info(f"### duplicate_check: {duplicate_check}")

        if not duplicate_check.empty:
            return {"flag": False, "message": "Service Provider already exists"}  

        #duplicate check in billing platform
        duplicate_check = killbill_database.get_data(
            "serviceprovider",
            {"display_name": changed_data.get('display_name', ''), "tenant_id": sub_tenant_id},
            None
            )
        logging.info(f"### duplicate_check: {duplicate_check}")
        if not duplicate_check.empty:
            return {"flag": False, "message": "Service Provider already exists"}

        changed_data['service_provider_name'] = changed_data.get('display_name', '')
        changed_data['created_by'] = user_name
        changed_data['modified_by'] = user_name
        changed_data['is_active'] = True
        changed_data['is_deleted'] = False
        changed_data['tenant_id'] = sub_tenant_id
        changed_data['tenant_name'] = sub_tenant_name

        status = killbill_database.insert_data(changed_data, "serviceprovider")
        if status:
            return {"flag": True, "message": "Service Provider added successfully"}
    
    except Exception as e:
        logging.info(f"add_bp_service_provider exception {e}")
        return {"flag": False, "message": "add_bp_service_provider Failed"}

def update_bp_service_provider(data):
    start_time = time.time()
    logging.info(f"Initiating update_service_provider function.{data}")

    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

    changed_data = data.get('changed_data', {})
    row_id = changed_data.get('id', '')
    if not changed_data:
        return {"flag": False, "message": "No data provided"}
    try:
        killbill_database.update_dict(
            "serviceprovider",
            changed_data,
            {"id": row_id}
        )
        return {"flag": True, "message": "Service Provider updated successfully"}
    
    except Exception as e:
        logging.info(f"update_service_provider exception {e}")
        error_type = str(type(e).__name__)
        # Log error to database
        error_data = {
            "service_name": "update_service_provider",
            "error_message": str(e),
            "error_type": error_type,
            "session_id": data.get("sessionID", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": json.dumps({
                "changed_data": changed_data
            }, default=str),
            "module_name": "Module Management",
            "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "update_service_provider Failed"}

def deactivate_bp_service_provider(data):
    start_time = time.time()
    logging.info(f"Initiating deactivate_service_provider function.{data}")

    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)

    changed_data = data.get('changed_data', {})
    row_id = changed_data.get('id', '')
    if not changed_data:
        return {"flag": False, "message": "No data provided"}
    try:
        killbill_database.update_dict(
            "serviceprovider",
            changed_data,
            {"id": row_id}
        )
        response = {"flag": True, "message": "Service Provider deactivated successfully"}
        audit_data_user_actions = {
            "service_name": "deactivate_service_provider",
            "created_by": data.get("username", ""),
            "status": str(response['flag']) or "",
            "session_id": data.get("sessionID", ""),
            "tenant_name": data.get("Partner", ""),
            "module_name": "Module Management",
            "comments":json.dumps({
                "changed_data": changed_data
            }, default=str),
            "request_received_at": data.get("request_received_at", ""),
        }
        common_utils_database.update_audit(
            audit_data_user_actions, "audit_user_actions"
        )
        return response

    except Exception as e:
        logging.info(f"deactivate_service_provider exception {e}")
        error_type = str(type(e).__name__)
        # Log error to database
        error_data = {
            "service_name": "deactivate_service_provider",
            "error_message": str(e),
            "error_type": error_type,
            "session_id": data.get("sessionID", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": json.dumps({
                "changed_data": changed_data
            }, default=str),
            "module_name": "Module Management",
            "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "deactivate_service_provider Failed"}

def update_version_flag(data):
    '''
    Update the version flag for a user in the common utils database.
    Args:
        data (dict): A dictionary containing 'username' and 'version_flag' keys.

    Returns:
        {flag: True}
    '''
    logging.info(f"### update_version_flag function request data is {data}.")
    start_time = time.time()
    request_received_at=data.get("request_received_at", "")
    tenant_name=data.get("tenant_name", "")
    username=data.get('username')
    version_flag=data.get('version_flag',[])
    # Database Connection
    try:
        ## Common Utils Database Connection
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.exception(f"### update_version_flag Exception while connecting to common utils database: {e}")
    try:
        
        update_data = {"switch_user_20_modules_json": json.dumps(version_flag)}
        common_utils_database.update_dict("users", update_data,{"username":username})
        response={"flag": True,"message": "Version flag updated successfully"}
        logging.info("### update_version_flag Returning data response")
        ##Audit log for user actions
        try:
            audit_data_user_actions = {
                "service_name": "update_version_flag",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "tenant_name": tenant_name,
                "module_name": "Module Management",
                "comments": f"Version flag updated successfully and data is: {json.dumps(update_data)}",
                "request_received_at": request_received_at,
            }

            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### update_version_flag Exception while updating audit {e}")
        return response
    except Exception as e:
        logging.exception(f"### update_version_flag An error occurred in deployment alert data retrieval: {e}")
        message = f"Unable Update the version data for user {username} and data is {json.dumps(version_flag)}"
        # Error Management
        error_data = {
            "service_name": "update_version_flag",
            "error_messag": str(e),
            "error_type": type(e).__name__,
            "user": username,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Module Management",
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        response={
                "flag": True,
                "data": [],
                "message": "update failed!",
                    }
        return response


    
    
    