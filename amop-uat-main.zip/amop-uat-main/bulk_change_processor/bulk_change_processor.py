"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24
"""
# Importing the necessary Libraries
import json
import logging
import os
import ast
import boto3
import requests
import os
import pandas as pd
from common_utils.db_utils import DB
import psycopg2
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import *
from pandas import Timestamp
from datetime import datetime
from dotenv import load_dotenv
from dateutil.relativedelta import relativedelta
import time
from io import BytesIO
from sqlalchemy import create_engine, text
import base64
import re
import pytds
import uuid
import threading
from pytz import timezone
import numpy as np
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import uuid
import time, random

logging = Logging(name="bulk_change_processor")
# Database configuration
db_config = {
     "host": os.environ["HOST"],
     "port": os.environ["PORT"],
     "user": os.environ["USER"],
     "password": os.environ["PASSWORD"],

 }


function_registry= {
  "AT&T - Telegence - UAT ONLY": {
    "actions": [
      {
        "change_type": "Activate New Service",
        "function_name": "telegence_bc_activate_new_service"
      },
      {
        "change_type": "Archive",
        "function_name": "telegence_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "telegence_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "telegence_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "telegence_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "telegence_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "telegence_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "telegence_bc_update_device_status"
      },
      {
        "change_type": "Change Phone Number",
        "function_name": "telegence_bc_change_phone_number"
      },
      {
        "change_type": "Update PPU address",
        "function_name": "telegence_bc_update_ppu_address"
      },
      {
        "change_type": "Update Features",
        "function_name": "telegence_bc_update_feature"
      },
      {
        "change_type": "Create Rev Service",
        "function_name": "telegence_bc_create_rev_service"
      },
      {
        "change_type": "Refresh A Line",
        "function_name": "telegence_refresh_a_line"
      },
    ]
  },
  "AT&T - Telegence": {
    "actions": [
      {
        "change_type": "Activate New Service",
        "function_name": "telegence_bc_activate_new_service"
      },
      {
        "change_type": "Archive",
        "function_name": "telegence_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "telegence_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "telegence_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "telegence_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "telegence_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "telegence_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "telegence_bc_update_device_status"
      },
      {
        "change_type": "Change Phone Number",
        "function_name": "telegence_bc_change_phone_number"
      },
      {
        "change_type": "Update PPU address",
        "function_name": "telegence_bc_update_ppu_address"
      },
      {
        "change_type": "Update Features",
        "function_name": "telegence_bc_update_feature"
      },
      {
        "change_type": "Create Rev Service",
        "function_name": "telegence_bc_create_rev_service"
      },
      {
        "change_type": "Refresh A Line",
        "function_name": "telegence_refresh_a_line"
      },
    ]
  },
  "Verizon - ThingSpace PN": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username /Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
    ]
  },
  "Verizon - ThingSpace IoT": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username /Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
    ]
  },
  "VZN 5G/FWA 4740948": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username /Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
    ]
  },
  "VZN 5G/FWA 4740948": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "webbing_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "webbing_bc_assign_customer"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "webbing_bc_change_customer_rate_plan"
      }
    ]
  },
  "Webbing": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "webbing_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "webbing_bc_assign_customer"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "webbing_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "webbing_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "webbing_bc_update_device_status"
      }

    ]
  },
  "AT&T - POD19": {
  "actions": [
    {
      "change_type": "Archive",
      "function_name": "pod19_bc_archive_devices"
    },
    {
      "change_type": "Assign Customer",
      "function_name": "pod19_bc_assign_customer"
    },
    {
      "change_type": "Change Carrier Rate Plan",
      "function_name": "pod19_bc_change_carrier_rate_plan"
    },
    {
      "change_type": "Change Customer Rate Plan",
      "function_name": "pod19_bc_change_customer_rate_plan"
    },
    {
      "change_type": "Edit Username/Cost Center",
      "function_name": "pod19_bc_edit_username_cost_center"
    },
    {
      "change_type": "Update Device Status",
      "function_name": "pod19_bc_update_device_status"
    }
  ]
},
"POND IoT": {
  "actions": [
    {
      "change_type": "Archive",
      "function_name": "pondiot_bc_archive_devices"
    },
    {
      "change_type": "Assign Customer",
      "function_name": "pondiot_bc_assign_customer"
    },
    {
      "change_type": "Change Carrier Rate Plan",
      "function_name": "pondiot_bc_change_carrier_rate_plan"
    },
    {
      "change_type": "Change Customer Rate Plan",
      "function_name": "pondiot_bc_change_customer_rate_plan"
    },
    {
      "change_type": "Edit Username/Cost Center",
      "function_name": "pondiot_bc_edit_username_cost_center"
    },
    {
      "change_type": "Update Device Status",
      "function_name": "pondiot_bc_update_device_status"
    }
  ]
},
"AT&T - Cisco Jasper": {
  "actions": [
    {
      "change_type": "Archive",
      "function_name": "ciscojasper_bc_archive_devices"
    },
    {
      "change_type": "Assign Customer",
      "function_name": "ciscojasper_bc_assign_customer"
    },
    {
      "change_type": "Change Carrier Rate Plan",
      "function_name": "ciscojasper_bc_change_carrier_rate_plan"
    },
    {
      "change_type": "Change Customer Rate Plan",
      "function_name": "ciscojasper_bc_change_customer_rate_plan"
    },
    {
      "change_type": "Edit Username/Cost Center",
      "function_name": "ciscojasper_bc_edit_username_cost_center"
    },
    {
      "change_type": "Update Device Status",
      "function_name": "ciscojasper_bc_update_device_status"
    }
  ]
  },
  "Teal": {
  "actions": [
    
    {
      "change_type": "Assign Customer",
      "function_name": "Teal_bc_assign_customer"
    },
    {
      "change_type": "Change Carrier Rate Plan",
      "function_name": "Teal_bc_change_carrier_rate_plan"
    },
    {
      "change_type": "Change Customer Rate Plan",
      "function_name": "Teal_bc_change_customer_rate_plan"
    },
    {
      "change_type": "Update Device Status",
      "function_name": "Teal_bc_update_device_status"
    }
  ]
},
"Kore": {
  "actions": [
    {
      "change_type": "Archive",
      "function_name": "kore_bc_archive_devices"
    },
    {
      "change_type": "Assign Customer",
      "function_name": "kore_bc_assign_customer"
    },
    {
      "change_type": "Change Customer Rate Plan",
      "function_name": "kore_bc_change_customer_rate_plan"
    },
    {
      "change_type": "Edit Username/Cost Center",
      "function_name": "kore_bc_edit_username_cost_center"
    },
    {
      "change_type": "Update Device Status",
      "function_name": "kore_bc_update_device_status"
    }
  ]
  },
"T-Mobile Jasper": {
  "actions": [
    {
      "change_type": "Archive",
      "function_name": "tmobilejasper_bc_archive_devices"
    },
    {
      "change_type": "Assign Customer",
      "function_name": "tmobilejasper_bc_assign_customer"
    },
    {
      "change_type": "Change Carrier Rate Plan",
      "function_name": "tmobilejasper_bc_change_carrier_rate_plan"
    },
    {
      "change_type": "Change Customer Rate Plan",
      "function_name": "tmobilejasper_bc_change_customer_rate_plan"
    },
    {
      "change_type": "Edit Username/Cost Center",
      "function_name": "tmobilejasper_bc_edit_username_cost_center"
    },
    {
      "change_type": "Update Device Status",
      "function_name": "tmobilejasper_bc_update_device_status"
    }
  ]
  }
}
container_mapping = {
    "AT&T - Telegence - UAT ONLY": "Telegence",
    "AT&T - Telegence": "Telegence",
    "Verizon - ThingSpace IoT":"Verizon",
    "Verizon - ThingSpace PN":"Verizon",
    "VZN 5G/FWA 4740948":"Verizon",
    "Webbing":"Webbing",
    "AT&T - POD19":"POD19",
    "POND IoT":"PondIOT",
    "AT&T - Cisco Jasper":"CiscoJasper",
    "Teal":"Teal",
    "Kore":"Kore",
    "T-Mobile Jasper":"TMobileJasper"

}

port_mapping = {
    "AT&T - Telegence - UAT ONLY": 5000,
    "AT&T - Telegence": 5000,
    "Verizon - ThingSpace IoT":5002,
    "Verizon - ThingSpace PN":5002,
    "VZN 5G/FWA 4740948":5002,
    "Webbing":5003,
    "AT&T - POD19":5004,
    "POND IoT":5005,
    "AT&T - Cisco Jasper":5006,
    "Teal":5007,
    "Kore":5008,
    "T-Mobile Jasper":5009
}

def funtion_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler
    if path == "/bulk_change_processor":
        result = bulk_change_processor(data)
    elif path == "/get_bulk_change_audit_trial_logs":
        result = get_bulk_change_audit_trial_logs(data)
    elif path == "/get_standard_iccid_msisdn_data":
        result = get_standard_iccid_msisdn_data(data)
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result


# Initialize SQS client once
sqs = boto3.client('sqs')

def get_sqs_url(service_provider,change_type,common_utils_database):
    '''
    Function to get the SQS URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The SQS URL if found, otherwise None.'''
    sqs_url=None
    sqs_details= common_utils_database.get_data(
    "bulk_change_provider_sqs", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["sqs_url"]
    )
    if not sqs_details.empty:
        sqs_url=sqs_details.iloc[0]['sqs_url']
        return sqs_url
    else:
        return sqs_url

def get_carrier_api_details(service_provider,change_type,common_utils_database):
    '''
    Function to get the Carrier API URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The Carreir API URL,app_id,app_secret if found, otherwise None.'''
    # Initialize variables
    carrier_api_url=None
    app_id=None
    app_secret=None
    carrier_limit=None

    carrier_details= common_utils_database.get_data(
    "bulk_change_carrier_limits", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["carrier_api_url","app_id","app_secret","carrier_limit"]
    )
    logging.info('carrier_details',carrier_details)
    if not carrier_details.empty:
        carrier_api_url=carrier_details.iloc[0]['carrier_api_url']
        app_id=carrier_details.iloc[0]['app_id']
        app_secret=carrier_details.iloc[0]['app_secret']
        carrier_limit=carrier_details.iloc[0]['carrier_limit']
        return carrier_api_url,carrier_limit,app_id,app_secret
    else:
        return carrier_api_url,carrier_limit,app_id,app_secret

    
def bulk_change_processor(data):
    '''
    Function to prioritize bulk change requests based on the number of IDs provided.
    It sends the request to an SQS queue with a priority attribute based on the number of IDs.
    Args:
        data (dict): Request data containing user/tenant information and IDs.
    Returns:
    '''
    logging.info(f"Received data for priority processor: %s", data)
    start_time = time.time()
    ## Validate required fields
    change_type= data.get("change_type", "")
    service_provider = data.get("service_provider", "")
    bulk_change_id = data.get("bulk_change_id", "")
    username = data.get("username", "")
    created_by = data.get("created_by")

    # Check if required fields are present
    if not change_type or not service_provider:
        logging.error("Missing required fields: change_type or service_provider")
        return {"flag":False,"message": "change_type and service_provider are required fields"}
    # DB connections
    try:
        database = DB(data.get("db_name", ""), **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {"flag":False,"message": "DB connection failed", "details": str(e)}
    bulk_change_audit_action(
            data, common_utils_database,
            action=f"Bulk Change Request Initiated"
        )
    ## Validate tenant name and get tenant ID
    tenant_name = data.get("tenant_name", "")
    if not tenant_name:
        logging.error("Tenant name is required in the request data.")
        return {"flag":False,"message": "Tenant name is required."}
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    tenant_details = common_utils_database.get_data(
      "tenant", {"tenant_name": tenant_name}, ["id"]
    )
    #"change_phone_number_frequency_setting"

    if not isinstance(tenant_details, pd.DataFrame) or tenant_details.empty:
        logging.error("Tenant ID not found or invalid response for tenant name: %s. Response: %s", tenant_name, tenant_details)
        return {"flag": False, "message": "Tenant ID not found."}

    tenant_id = int(tenant_details.iloc[0]['id'])
    #frequency_setting=tenant_details.iloc[0]['change_phone_number_frequency_setting']
    data["tenant_id"] = tenant_id
    #data["frequency_setting"]=frequency_setting
    service_provider_data=database.get_data(
        "serviceprovider", {"service_provider_name": service_provider}, ["id","integration_id","write_is_enabled"])
    if not service_provider_data.empty:
        service_provider_id = int(service_provider_data.iloc[0]['id'])
        integration_id = int(service_provider_data.iloc[0]['integration_id'])
        carrier_enabled=service_provider_data.iloc[0]["write_is_enabled"]

        data["service_provider_id"] = service_provider_id
        data["integration_id"] = integration_id
    else:
        logging.error("Service provider ID not found for service provider: %s", service_provider)
        return {"flag":False,"message": "Service provider ID not found."}
    # IDs from input
    ids = data.get('iccids') or data.get('msisdns') or []
    ##updating the bulk change request with uploaded count
    database.update_dict(
            'sim_management_bulk_change',
            {
                "uploaded": len(ids),
                "processed_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            {'id': bulk_change_id}
        )
    # Validate IDs
    if not isinstance(ids, list):
        return {"error": "iccids/msisdns must be a list"}
    ##updating the status of the bulk change request to PROCESSING
    if bulk_change_id:
        logging.info("Updating status of bulk change request with ID: %s", bulk_change_id)
        # Update the status to PROCESSING
        database.update_dict(
                "sim_management_bulk_change",
                { "status": "PROCESSING"},
                {"id": bulk_change_id},
                
            )
    bulk_change_audit_action(
            data, common_utils_database,
            action=f"Request Validated"
        )
    bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number"]
        ).rename(columns={"subscriber_number": "msisdn"})
    msisdn_to_request_id = {}
    data_log=[]
    if not bulk_requests_df.empty:
      msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))

    if not carrier_enabled and change_type not in ["Archive","Change Customer Rate Plan","Edit Username/Cost Center","Assign Customer"]:
        logging.info(f"### Carrier Writes are disabled for this service provider {service_provider} ")
        database.update_dict(
                "sim_management_bulk_change",
                { "status": "ERROR"},
                {"id": bulk_change_id},
                
            )
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,"status_details":"Writes are disabled for this service provider",
                    "processed_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
            and_conditions={"bulk_change_id": bulk_change_id}
          )
        for msisdn in bulk_requests_df["msisdn"].tolist():
          data_log.append({
              "bulk_change_id": bulk_change_id,
              "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
              "log_entry_description": "Update AMOP",
              "request_text": "Bulk Change Processer",
              "has_errors": True,
              "response_status": "ERROR",
              "response_text": "Writes are disabled for this service provider",
              "error_text": "Carrier writes are Disabled",
              "processed_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
              "processed_by": created_by,
              "created_by": created_by,
              "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
              "is_deleted": False,
              "is_active": True,
            })
        database.insert_data(data_log, "sim_management_bulk_change_log")
        return {"flag":False,"message": f"Carrier Writes are disabled for this service provider {service_provider}"}

    #validating the sims
    if change_type not in ('Activate New Service'):
        data=validating_sims(data,database,common_utils_database)
    logging.info(f"Request after validation{data}")
    # Find the function name from registry
    actions = function_registry.get(service_provider, {}).get("actions", [])
    matching_action = next(
        filter(lambda a: a["change_type"] == change_type, actions),
        None
    )
    function_name = matching_action["function_name"] if matching_action else None
    if not function_name:
        return {"flag":False,"message": f"No function found for service provider '{service_provider}' and change event type '{change_type}'."}
    logging.info("Function to call: %s", function_name)
    bulk_change_audit_action(
            data, common_utils_database,
            action=f"In Bulk Change Processor"
        )
    # get the container name based on service provider
    container_name = container_mapping.get(service_provider, None)
    if not container_name:
        logging.error(f"Container name not found for service provider: {service_provider}")
        return {"flag":False,"message": f"Container name not found for service provider: {service_provider}"}
    port = port_mapping.get(service_provider, None)
    if not port:
        logging.error(f"port  not found for service provider: {service_provider}")
        return {"flag":False,"message": f"port not found for service provider: {service_provider}"}
    ## Prepare the data to be sent to the container , update path with the function name
    data["path"] = f"/{function_name}"
    logging.info("Data to be sent to the container: %s", data)

    ##URL needs to be changed 
    url = f"http://{os.environ['EC2_HOST']}:{port}/{container_name}_BulkChange_Handler"
    # bulk_change_audit_action(
    #         data, common_utils_database,
    #         action=f"Request Forwarded to EC2 Container"
    #     )
    logging.info(f"Forwarding request to EC2 endpoint: {url}")
    ##call the container
    try:
        try:
            ##call the container with retries
            logging.info(f"Calling container with data: {data}")
            result=post_with_retries(url, data, retries=1)
            response={"flag": True, "message": "Request forwarded to EC2 successfully"}
            try:
                # End time calculation
                end_time = time.time()
                time_consumed = f"{end_time - start_time:.4f}"
                time_consumed = int(float(time_consumed))
                audit_data_user_actions = {
                    "service_name": "bulk_change_processor",
                    "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "created_by": username,
                    "time_consumed_secs": time_consumed,
                    "status": "Success - Request forwarded to EC2 route",
                    "tenant_name": tenant_name,
                    "module_name": "Bulk Change",
                    "comments": f'''Bulk Change request forwarded to EC2 route for service provider: {service_provider} 
                              and change type: {change_type} and bulk_change_id: {bulk_change_id}''',
                    "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### Audit logging failed: {e}")
            return response
        except Exception as e:
            logging.exception(f"HTTP forward failed{e}")
            response = {"flag": False, "error": "Forward to EC2 route failed", "details": str(e)}
            error_message = f"Error during bulk change processing: {str(e)}"
            error_type = str(type(e).__name__)
            try:
                # Log failure to error log table
                error_data = {
                    "service_name": "bulk_change_processor",
                    "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "error_message": error_message,
                    "error_type": error_type,
                    "users": username,
                    "tenant_name": tenant_name,
                    "comments": f"Error during bulk change processing for service provider: {service_provider} and change type: {change_type} and bulk_change_id: {bulk_change_id}",
                    "module_name": "Bulk Change",
                    "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
            except Exception as e:
                logging.exception(f"### Logging error to DB failed: {e}")
            return response
    except requests.RequestException as e:
        logging.exception("HTTP forward failed")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response={"flag": False, "error": "Forward to EC2 route failed", "details": str(e)}
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "bulk_change_processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change processing for service provider: {service_provider} and change type: {change_type} and bulk_change_id: {bulk_change_id}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
        return response
    


def post_with_retries(url, json, retries=1):
    '''
    main container caller function
    Args:
        url (str): The URL to send the POST request to.
        json (dict): The JSON data to include in the POST request.
        retries (int): Number of retry attempts in case of failure.
    '''
    delay = 1
    for attempt in range(1, retries + 1):
        try:
            resp = requests.post(url, json=json, timeout=60)
            if resp.status_code < 400:
                return resp.json()
        except requests.RequestException:
            pass  # ignore and retry

        logging.warning("Attempt %d failed; retrying in %ds", attempt, delay)
        time.sleep(delay + random.uniform(0, 0.5))
        delay *= 2
    logging.error("All %d attempts failed", retries)
    return None  # After all retries fail

def validating_sims(data,database,common_utils_database):
    """
    Validates SIMs (ICCID or MSISDN) based on availability and active status.

    Args:
        data (dict): Request data containing 'iccids' or 'msisdns'.

    Returns:
        dict: Updated data with only validated SIMs.
    """
    logging.info(f"Received data for validating sims: %s", data)
    # Validate required fields
    iccids = data.get("iccids", [])
    msisdns = data.get("msisdns", [])
    tenant_id = data.get("tenant_id", None)
    bulk_change_id = data.get("bulk_change_id", None)
    try:
        # Determine which key to use for validation
        filter_key = "iccid" if iccids else "msisdn"
        values = iccids if iccids else msisdns

        if not values:
            return {"error": "No ICCIDs or MSISDNs provided for validation."}

        # Query only active SIMs matching the ICCIDs or MSISDNs
        filter_conditions = {"is_active": True, filter_key: values,"tenant_id":tenant_id}
        df = database.get_data("sim_management_inventory", filter_conditions,['iccid','msisdn'])

        # Extract validated values
        validated = df[filter_key].tolist() if not df.empty else []
        invalid = list(set(values) - set(validated))
        #Keeping it disabled to avoid incorrect INVALID status and error counts 
        # if invalid:
        #      # Use update_dict with in_conditions to match multiple entries
        #     database.update_dict(
        #         "sim_management_bulk_change_request",
        #         {"status": "INVALID"},
        #         and_conditions={"bulk_change_id": bulk_change_id},  # optional pre-filter
        #         in_conditions={filter_key: invalid}
        #     )
        # ##updating the counts
        # database.update_dict(
        #         'sim_management_bulk_change',
        #         {
        #             "errors": len(invalid),
        #             "processed_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        #         },
        #         {'id': bulk_change_id}
        #     )
        # Replace original list in data
        data[filter_key + "s"] = validated
        if iccids:
            data["invalid_iccids"] = invalid
        else:
            data["invalid_msisdns"] = invalid
            invalid_ids_query = """
                SELECT id 
                FROM sim_management_bulk_change_request  
                WHERE bulk_change_id = %s 
                AND (subscriber_number IS NULL OR TRIM(subscriber_number) = '')
            """
            params = [bulk_change_id]

            # Execute the query
            invalid_ids_df = database.execute_query(invalid_ids_query, params=params)

            # Add to data if any invalid records are found
            if not invalid_ids_df.empty:
                data["invalid_ids"] = invalid_ids_df["id"].to_list()
        return data
    except Exception as e:
        logging.error("Error during SIM validation: %s", str(e))
        return data


    
def bulk_change_audit_action(data, common_utils_database,action):
    """
    Audits user actions by logging them into the bulk change auditing table.
 
    Args:
        data (dict): Data containing user action details.
        common_utils_database (DB): Database connection object.
 
    Returns:
        None
    """
    service_provider = data.get("service_provider", "")
    change_event_type = data.get("change_type", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at", "")
    bulk_change_id = data.get("bulk_change_id", "")
    try:
        audit_data_user_actions = {
                "tenant_name": tenant_name,
                "bulk_change_id":bulk_change_id,
                "serviceprovider": service_provider,
                "change_event_type": change_event_type,
                "action": action,
                "created_date": request_received_at,
                "created_by": username,
               
        }
        common_utils_database.update_audit(audit_data_user_actions, "bulk_change_auditing")
           
    except Exception as e:
            logging.exception(f"### Error logging user actions: {e}")
            logging.info("User action audited successfully.")
    except Exception as e:
        logging.error(f"Error auditing user action: {e}")



def get_bulk_change_audit_trial_logs(data):
    """
    Retrieve audit-trial logs for a bulk change operation.

    If no audit records are found, returns a default entry
    indicating that the operation was processed in version 1.0.

    Parameters:
        data (dict): Dictionary with keys:
            db_name (str): Tenant's database name.
            tenant_name (str): Name of the tenant.
            z_access_token (str): Authentication token.
            client_id (str): Client identifier.
            Partner (str): Partner information.
            session_id (str, optional): Session ID (default: "client_call").
            bulk_change_id (int): ID of the bulk change.
            offset (int, optional): Pagination offset (default: 0).
            module_name (str, optional): Name of the module.
            username (str, optional): User requesting the operation.
            request_received_at (str, optional): Timestamp of request.

    Returns:
        dict: Response containing:
            flag (bool): Indicates operation success.
            message (str): Info about the fetch result.
            bulk_change_audit_data (list of dict):
                - Each dict has 'id' (int) and 'action' (str or None).
                - If empty, contains single record {'id': 1, 'action': 'Bulk Change Request was initiated in 1.0'}.
            recall_flag (bool): Reserved field for future use.
    """
    ## Fetching the required params
    logging.info(f"Request recieved for get_bulk_change_audit_trial_logs is :{data}")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    try:
        ##Common Utils Database Connection
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.exception(f"Exception while connecting to common utils database: {e}")
    complete_audit_data_dict=[{"id":1,"action":"Bulk Change Request Initiated"},{"id":2,"action":"Request Validated"},{"id":3,"action":"In Bulk Change Processor"},{"id":4,"action":"Bulk Change Process Initiated"},{"id":5,"action":"Processing With Carrier APIs"},{"id":6,"action":"Sync To 1.0 Tables"},{"id":7,"action":"Sync Finished"},{"id":8,"action":"Auditing"},{"id":9,"action":"Bulk Change Process Completed"}]
    bulk_change_id = data.get('list_view_data_id')
    if not bulk_change_id:
        response = {"flag": False, "message": "Bulk Change ID is missing"}
        return response
    try:
        bulk_change_audit_data=common_utils_database.get_data('bulk_change_auditing',{'bulk_change_id':str(bulk_change_id)},['action'],order={"id": "asc"})
        if not bulk_change_audit_data.empty:
            db_actions = {rec['action'] for rec in bulk_change_audit_data.to_dict(orient="records")}
            bulk_change_audit_data = [
                entry for entry in complete_audit_data_dict
                if entry['action'] in db_actions
            ]
        else:
            bulk_change_audit_data=[{'id': 1, 'action': 'Bulk Change Request Was Initiated in 1.0'}]
        response={"flag":True,"message":"Bulk Change Audit Trial fecthed successfully","bulk_change_audit_data":bulk_change_audit_data,"recall_flag":False,"complete_audit_data_dict":complete_audit_data_dict}
        try:
            audit_data_user_actions = {
                "module_name": "Bulk Change Processor",
                "created_by": username,
                "status": "True",
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "comments": f"bulk_change_audit logs proesseced for the bulk_change_id {bulk_change_id}",
                "service_name": "get_bulk_change_audit_trial_logs",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return response

    except Exception as e:
        logging.exception(f"Exception while fetching bulk change audit trial  data: {e}")
        # response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_bulk_change_audit_trial_logs",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message":str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": "",
                "module_name": "Bulk Change Processor",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        return {
            "flag": True,
            "message": "Unable to fetch bulk change audit trial data",
            "complete_audit_data_dict":complete_audit_data_dict,
            "bulk_change_audit_data":{},
            "recall_flag":False
        }

def get_standard_iccid_msisdn_data(data):
    '''
    Function to get standard ICCID and MSISDN data based on provided ICCIDs or MSISDNs.
    Args:
        data (dict): Request data containing 'iccids', 'msisdns', 'tenant
            _id', 'service_provider_name', and optional 'db_name'.
    Returns:
        dict: Response containing either 'msisdns' or 'iccids' based on input.
        If neither 'iccids' nor 'msisdns' are provided, returns an error
        message.
    '''
    logging.info(f"Received data for standardization: %s", data)
    ## Validate required fields
    iccids = data.get('iccids',None)
    msisdns = data.get('msisdns',None)
    iccids_imei_map = data.get('iccids_imei_map',None)
    msisdns_imei_map = data.get('msisdns_imei_map',None)
    tenant_name = data.get('tenant_name')
    service_provider_name = data.get('service_provider',None)
    ##Database connection
    try:
        database = DB(data.get("db_name", ""), **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {"flag": False, "message": "DB connection failed", "details": str(e)}
    ##Function will start here
    try:
        ##initialize the sim_identifier_map
        sim_identifier_map = []
        if tenant_name=='Altaworx Test':
           tenant_name='Altaworx'
        tenant_details= common_utils_database.get_data(
               "tenant", {"tenant_name": tenant_name}, ["id"]
              )
        if tenant_details.empty:
          logging.error("Tenant ID not found for tenant name: %s", tenant_name)
          return {"flag":False,"message": "Tenant ID not found."}
        tenant_id = int(tenant_details.iloc[0]['id'])
        # If iccids provided, get associated msisdns
        if iccids:
            logging.info(f"Fetching msisdns for iccids")
            sim_identifier_msisdn = database.get_data(
                "sim_management_inventory",
                {
                    "is_active": True,
                    "tenant_id": tenant_id,
                    "service_provider_display_name": service_provider_name,
                    "iccid": iccids
                },
                ['iccid', 'msisdn']
            ).to_dict(orient="records")
            # Extend the sim_identifier_map with the fetched data
            sim_identifier_map.extend(sim_identifier_msisdn)
            # Create a set of found iccids for quick lookup
            found_iccids = {row['iccid'] for row in sim_identifier_msisdn}
            ## For each iccid, check if it exists in the found list
            for iccid in iccids:
                if iccid not in found_iccids:
                    sim_identifier_map.append({"iccid": iccid, "msisdn": iccid})

            # Return only msisdns (since iccids were passed)
            msisdn_list = [row['msisdn'] for row in sim_identifier_map]
            response={"flag": True, "msisdns": msisdn_list,"message":"Successfully fetched msisdns for the provided iccids."}
            return response

        # If msisdns provided, reverse logic: get associated iccids
        if msisdns:
            logging.info(f"Fetching iccids for msisdns")
            ## Query the database for active SIMs with the provided msisdns
            sim_identifier_iccid = database.get_data(
                "sim_management_inventory",
                {
                    "is_active": True,
                    "tenant_id": tenant_id,
                    "service_provider_display_name": service_provider_name,
                    "msisdn": msisdns
                },
                ['msisdn', 'iccid']
            ).to_dict(orient="records")

            sim_identifier_map.extend(sim_identifier_iccid)
            # Create a set of found msisdns for quick lookup
            found_msisdns = {row['msisdn'] for row in sim_identifier_iccid}
            # For each msisdn, check if it exists in the found list
            for msisdn in msisdns:
                if msisdn not in found_msisdns:
                    sim_identifier_map.append({"msisdn": msisdn, "iccid": msisdn})
            ## If msisdns were provided, we need to return the associated iccids
            # Return only iccids (since msisdns were passed)
            iccid_list = [row['iccid'] for row in sim_identifier_map]
            response={"flag": True, "iccids": iccid_list,"message":"Successfully fetched iccids for the provided msisdns."}
            return response
        # Block 3: Handle ICCIDs to IMEI map → return MSISDNs to IMEI map
        if iccids_imei_map:
            iccid_keys = list(iccids_imei_map.keys())
            sim_identifier_msisdn = database.get_data(
                "sim_management_inventory",
                {
                    "is_active": True,
                    "tenant_id": tenant_id,
                    "service_provider_display_name": service_provider_name,
                    "iccid": iccid_keys
                },
                ['iccid', 'msisdn']
            ).to_dict(orient="records")

            iccid_to_msisdn = {row['iccid']: row['msisdn'] for row in sim_identifier_msisdn}

            final_map = {}
            for iccid, imei in iccids_imei_map.items():
                msisdn = iccid_to_msisdn.get(iccid, iccid)  # fallback to iccid if not found
                final_map[msisdn] = imei

            response={"flag": True, "msisdns_imei_map": final_map}
            return response

        # Block 4: Handle MSISDNs to IMEI map → return ICCIDs to IMEI map
        if msisdns_imei_map:
            msisdn_keys = list(msisdns_imei_map.keys())
            sim_identifier_iccid = database.get_data(
                "sim_management_inventory",
                {
                    "is_active": True,
                    "tenant_id": tenant_id,
                    "service_provider_display_name": service_provider_name,
                    "msisdn": msisdn_keys
                },
                ['msisdn', 'iccid']
            ).to_dict(orient="records")

            msisdn_to_iccid = {row['msisdn']: row['iccid'] for row in sim_identifier_iccid}

            final_map = {}
            for msisdn, imei in msisdns_imei_map.items():
                iccid = msisdn_to_iccid.get(msisdn, msisdn)  # fallback to msisdn if not found
                final_map[iccid] = imei

            response={"flag": True, "iccids_imei_map": final_map}
            return response
    except Exception as e:
        logging.error("Error while fetching the standard msisdn and iccid: %s", e)
        response={"flag": False, "message": "Fetching Failed", "details": str(e)}
        return response

