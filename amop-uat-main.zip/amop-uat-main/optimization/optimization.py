"""
@Author : Phaneendra. Y
Created Date: 21-06-24
"""

# Standard Library Imports
import base64
import concurrent.futures
import io
import json
import os
import re
import time
import zipfile
from datetime import datetime
from io import BytesIO
import threading
import ast
# Third-Party Imports
import boto3
import pandas as pd
import pytds
import requests
from pytz import timezone
import re
import pandas as pd
from pytz import timezone
import numpy as np
from uuid import UUID  # Add this import
from datetime import datetime, timedelta
import calendar
import psycopg2
# Local Application/Custom Imports
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import *
import pytds
import logging
import time

##for single customers
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta  # Import the relativedelta
import openpyxl
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
from openpyxl import load_workbook
from openpyxl import Workbook
from openpyxl.styles.numbers import BUILTIN_FORMATS

# AWS S3 client
s3_client = boto3.client("s3")
# Retrieve the S3 bucket name from an environment variable
S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME")

logging = Logging(name="optimization")

db_config_withoutfilter = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

##helper function to convert the data to json to make db_config
def clean_tuple(tpl):
    """
    Formats a tuple for SQL query usage, handling edge cases like None values and single-item tuples.
    
    Args:
        tpl (tuple): The tuple to format
        
    Returns:
        str or tuple: A properly formatted string representation of the tuple for SQL queries,
                     or an empty tuple if the input is None or not a tuple
    """
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        logging.info(f"### clean_tuple Exception while converting : {e}")
        return ()

##helper function to convert the data to json to make db_config
def db_config_maker(user, db_config_making,tenant_database,tenant_name,role_name,readme_flag=False):
    """
    Creates a database configuration dictionary with user-specific filters based on tenant and role.
    
    Args:
        user (str): Username to look up permissions for
        db_config_making (dict): Base database configuration to extend
        tenant_database (str): Name of the tenant database
        tenant_name (str): Name of the tenant
        role_name (str): User's role (e.g., 'Super Admin')
        readme_flag (bool): Flag to determine query format (client_id vs user_name)
        
    Returns:
        dict: Modified database configuration with user-specific filters
    """
    # Bypass filtering for Super Admin users
    if role_name in ('Super Admin'):
        return db_config_making
    # Connect to common_utils database to get tenant info
    common_utils_database = DB('common_utils',**db_config_making)
    # Get tenant ID and parent tenant ID
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )

    tenant_id = tenant_data["id"].to_list()[0]
    # parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    if tenant_id:
        tenant_id=int(tenant_id)
    #Get user permissions from mapping table
    if readme_flag:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where client_id ='{user}' and tenant_id={tenant_id}"
        filters = common_utils_database.execute_query(query, True)
        if filters.empty:
            query = f"""
                SELECT customers, service_provider, customer_group 
                FROM user_module_tenant_mapping 
                WHERE user_name = '{user}' AND tenant_id = {tenant_id}
            """
            filters = common_utils_database.execute_query(query, True)
    else:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"

        filters = common_utils_database.execute_query(query, True)
    # Connect to tenant database
    database = DB(tenant_database, **db_config)
    # Extract customer group if exists
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except Exception as e:
        logging.exception(f"### db_config_maker Error extracting customer_group: {e}")
        customer_group = None

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    # If user has a customer group, get additional filters from it
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            # Extract rate plan names
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
            # Extract customer names
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
                customer_names=None
            # Extract billing account number
            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None


            except Exception as e:
                logging.exception("Error extracting billing_account_number:", e)
                billing_account_number=None
            # Extract feature codes
            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception("Error extracting feature_codes:", e)
    # Set customer filter - use customer group names if available, otherwise use direct mapping
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except Exception as e:
            logging.exception(f"### db_config_maker Error extracting customers: {e}")
            customer = None
    else:
        customer=customer_names
    #customer=clean_tuple(customer)
    # Get service provider info and convert names to IDs
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            formatted_values = "', '".join(service_provider)
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except Exception as e:
        logging.exception(f"### db_config_maker Error extracting serviceprovider: {e}")
        service_provider = None
        service_provider_id = None
    # Get additional customers created by this user
    logging.info('customers after changes',customer)
    try:
        customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customers_df=database.execute_query(customers_query,True)
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                fixed_customer_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer, str):
                    customer = [customer]
                elif isinstance(customer_rate_plan_name, tuple):
                    customer = list(customer)
                else:
                    customer = customer  # Already a list

                fixed_customer_list = customer.copy() 
                # Clean and fix the list by splitting the elements and ensuring they are correctly quoted
                logging.info(f"### db_config_maker before extending customers : {fixed_customer_list}")
                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info(f"### db_config_maker customer after extend : {fixed_customer_list}")

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info(f"### db_config_maker final customer tuple : {customer}")
                customer=clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(f"Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")

    # Get additional rate plans created by this user
    try:
        customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                fixed_customer_rate_plan_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_list = [customer_rate_plan_name]
                elif isinstance(customer_rate_plan_name, tuple):
                    customer_rate_plan_list = list(customer_rate_plan_name)
                else:
                    customer_rate_plan_list = customer_rate_plan_name  # Already a list

                fixed_customer_rate_plan_list = customer_rate_plan_list.copy() # Remove extra quotes and commas
                logging.info(f"### db_config_maker customer rate plan list before extend : {fixed_customer_rate_plan_list}")

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info(f"### db_config_maker customer rate plan list after extend : {fixed_customer_rate_plan_list}")

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info(f"### db_config_maker final customer rate plan tuple : {customer_rate_plan_name}")

    except Exception as e:
        logging.exception(f"Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    # Update configuration with all filters
    logging.info(f"### db_config_maker customer at the end : {customer}")
    db_config_making["customers"] = customer
    db_config_making["service_providers"] = service_provider
    db_config_making["service_provider_id"] = service_provider_id
    db_config_making["customer_rate_plan_name"] = customer_rate_plan_name
    return db_config_making



####Main function to call the respective function based on the path
def funtion_caller(data, path):
    """
    Main function that routes API requests to the appropriate handler function based on the path.
    
    Args:
        data (dict): The request data containing user information and parameters
        path (str): The API endpoint path to route the request to
        
    Returns:
        dict: The response from the handler function or an error message if the path is invalid
    """
    if "data" in data:
        data = data.get("data")
    global db_config

    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

    user = data.get("username")
    if not user:
        user = data.get("user_name")
    tenant_database = data.get("db_name",'')
    if path == "/get_optimization_progress_bar_data" or path == "/get_optimization_error_details_data":
        pass
    else:
        role_name = data.get("role_name", "") or data.get('role', "") or data.get('role',"") or 'Super Admin'
        tenant_name = data.get("tenant_name", "") or data.get('tenant', "") or data.get('Partner',"") or 'Altaworx'
        db_config_making = db_config_maker(user, db_config,tenant_database,tenant_name,role_name)
        db_config = db_config_making

    ROUTES = {
        "/optimization_dropdown_data": optimization_dropdown_data,
        "/get_optimization_data": get_optimization_data,
        "/export_optimization_data_zip": export_optimization_data_zip,
        "/start_optimization": start_optimization,
        "/get_optimization_pop_up_data": get_optimization_pop_up_data,
        "/push_charges_submit": push_charges_submit,
        "/get_optimization_row_details": get_optimization_row_details,
        "/get_optimization_details_reports_data": get_optimization_details_reports_data,
        "/get_optimization_push_charges_data": get_optimization_push_charges_data,
        "/get_assign_rate_plan_optimization_dropdown_data": get_assign_rate_plan_optimization_dropdown_data,
        "/update_optimization_actions_data": update_optimization_actions_data,
        "/update_push_charges_data_optimization": update_push_charges_data_optimization,
        "/get_export_status": get_export_status,
        "/get_optimization_progress_bar_data": get_optimization_progress_bar_data,
        "/get_optimization_error_details_data": get_optimization_error_details_data,
        "/optimize_button_status": optimize_button_status,
        "/get_push_charges_status": get_push_charges_status,
        "/get_push_charges_count": get_push_charges_count,
        "/rate_plan_progress": rate_plan_progress,
        "/get_rate_plan_upload_pop_up_values": get_rate_plan_upload_pop_up_values,
        "/rate_plan_upload": rate_plan_upload,
        "/get_optimization_pop_up_values": get_optimization_pop_up_values,
        "/get_cross_provider_optimization_dropdown_data": get_cross_provider_optimization_dropdown_data,
        "/get_billing_periods_for_customer_and_site": get_billing_periods_for_customer_and_site,
        "/get_rate_plans_count_cross_optimization": get_rate_plans_count_cross_optimization,
        "/get_cross_provider_optimization_pop_up_data": get_cross_provider_optimization_pop_up_data,
        "/start_cross_provider_optimization": start_cross_provider_optimization,
        "/get_customer_optimization_customers_data": get_customer_optimization_customers_data,
        "/get_cross_provider_customer_offsets": get_cross_provider_customer_offsets,
    }

    handler = ROUTES.get(path)
    if handler:
        return handler(data)
    logging.warning(f"### function_caller Invalid path or method requested: {path}")
    return {"error": "Invalid path or method"}

##to fetch the service providers ids for each tenants separately used to get the serviceprovider ids in generic way
def load_json():
    """
    Loads a JSON file containing tenant-based service provider information.
    
    Args:
        None: Uses a predefined file path "tenant_based_serviceproviders.json"
        
    Returns:
        dict: Parsed JSON data as a dictionary, or an empty dictionary if an error occurs
    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_serviceproviders.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs


def get_db_credentials(tenant_name):
    """
    Retrieves database credentials for a specific tenant from a JSON configuration file.
    If the tenant is not found directly, attempts to find its parent tenant and use those credentials.
    
    Args:
        tenant_name (str): The name of the tenant to get credentials for
        
    Returns:
        dict: A dictionary containing database connection parameters (server, database_name, username, password, port)
              or an empty dictionary if credentials cannot be found
    """
    try:
        data = load_json()
        tenant_db_info = data.get("TenanatDatabaseDetails", {}).get(tenant_name)
        if tenant_db_info:
            return {
                "server": tenant_db_info["ONEPOINTOSERVER"],
                "database_name": tenant_db_info["ONEPOINTODATABASE"],
                "username": tenant_db_info["ONEPOINTOUSERNAME"],
                "password": tenant_db_info["ONEPOINTOPASSWORD"],
                "port": tenant_db_info.get("ONEPOINTOPORT", "1433")
            }
        else:
            db = DB('common_utils', **db_config)
            query=f'''select parent_tenant_id from tenant where tenant_name='{tenant_name}'
            '''
            parent_tenant_id=db.execute_query(query,True)['parent_tenant_id'].to_list()[0]
            if parent_tenant_id:
                parent_tenant_id=int(parent_tenant_id)
            parent_tenant_query=f'''select tenant_name from tenant where id={parent_tenant_id}
            '''
            parent_tenant_name=db.execute_query(parent_tenant_query,True)['tenant_name'].to_list()[0]
            tenant_db_info = data.get("TenanatDatabaseDetails", {}).get(parent_tenant_name)
            return {
                "server": tenant_db_info["ONEPOINTOSERVER"],
                "database_name": tenant_db_info["ONEPOINTODATABASE"],
                "username": tenant_db_info["ONEPOINTOUSERNAME"],
                "password": tenant_db_info["ONEPOINTOPASSWORD"],
                "port": tenant_db_info.get("ONEPOINTOPORT", "1433")
            }
    except Exception as e:
        logging.exception(f"Error retrieving database credentials: {e}")
        return {}

##Function to get the optimization data
def get_optimization_data(data):
    """
    Retrieves optimization data by executing a query based on the provided parameters.
    
    Args:
        data (dict): Dictionary containing request parameters including optimization_type,
                    tenant_name, session_id, username, and pagination information
                    
    Returns:
        dict: A dictionary containing:
            - flag (bool): Success status of the operation
            - message (str): Status message
            - headers_map (dict): Column mapping information
            - data (list): List of optimization records
            - service_providers (list): List of available service providers
            - billing_period_dates (dict): Billing period information by service provider
            - cross_carrier_optimization (bool): Whether cross-carrier optimization is enabled
    """
    logging.info(f"### get_optimization_data Request Received : {data}")
    # Record the start time for performance measurement
    start_time = time.time()
    # module_name = data.get("module_name", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", None)
    Partner = data.get("Partner", "")
    mod_pages = data.get("mod_pages", {})
    role_name = data.get("role_name", "")
    col_sort = data.get("col_sort", "")
    # Set the limit for the number of records to retrieve per request
    limit = 100
    offset = mod_pages.get("start", 0)
    end = mod_pages.get("end", 0)
    # table = data.get("table_name", "")
    tenant_name = data.get("tenant_name", "")
    optimization_type = data.get("optimization_type", "")
    logging.info(f"### get_optimization_data Optimization Type is : {optimization_type}")
    # Check if optimization_type is empty or None and return a response
    if not optimization_type:
        logging.warning("Optimization type is missing from the data.")
        return {
            "flag": False,
            "message": "Optimization type is required but not provided.",
        }
    # Database connection
    tenant_database = data.get("db_name", "")
    try:
        database = DB(tenant_database, **db_config_withoutfilter)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    tenant_details = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id","parent_tenant_id"]
    )
    tenant_id = tenant_details["id"].to_list()[0]
    parent_tenant_id = tenant_details["parent_tenant_id"].to_list()[0]
    logging.info(f"parent_tenant_id=> {parent_tenant_id}")
    return_json_data = {}
    # Initialize pagination dictionary
    pages = {"start": offset, "end": end}

    # tenant_timezone = None
    try:
        # count_params = [table]
        # if optimization_type == "Customer":
        #     count_query = "SELECT COUNT(*) FROM vw_customer_optimization"
        # else:
        #     count_query = "SELECT COUNT(*) FROM vw_carrier_optimization"
        # count_start_time = time.time()
        #count_result = database.execute_query(count_query, count_params).iloc[0, 0]
        count_result=0
        # Set total pages count
        pages["total"] = int(count_result)
        # Retrieve the module query from the 'module_view_queries' table
        module_query_df = common_utils_database.get_data(
            "module_view_queries", {"module_name": optimization_type}
        )
        if module_query_df.empty:
            raise ValueError(f"No query found for module name: {optimization_type}")
        query = module_query_df.iloc[0]["module_query"]
        if not query:
            raise ValueError(f"Unknown module name: {optimization_type}")
        params = [tenant_id,offset, limit]

        if col_sort:
            # Extract the single key-value pair for sorting
            key, value = list(col_sort.items())[0]
            if key == "run_start_time":
                key = "optimization_run_start_date"

            # Handle special sorting for 'billing_period_duration'
            if key == "billing_period_duration":
                # Determine the sorting direction (ASC/DESC)
                sort_direction = value.upper()

                # Define the complex ORDER BY clause for billing_period_duration
                custom_order_by = (
                    f"GREATEST(billing_period_start_date, billing_period_end_date) {sort_direction} NULLS LAST, "
                    f"LEAST(billing_period_start_date, billing_period_end_date) {sort_direction} NULLS LAST, "
                    f"id ASC"
                )
            if key in ("total_charges" "total_charge_amount"):
                custom_order_by = f"{key}::NUMERIC {value.upper()}"
            else:
                # Default single-column ORDER BY clause
                custom_order_by = f"{key} {value.upper()}"

            # Remove any existing ORDER BY clause
            order_by_pattern = (
                r"\sORDER\s+BY\s+[^\s]+(\sASC|\sDESC)?(?=\s+(OFFSET|LIMIT))"
            )
            query = re.sub(order_by_pattern, "", query, flags=re.IGNORECASE)

            # Insert the new ORDER BY clause before OFFSET and LIMIT
            limit_offset_pattern = (
                r"(OFFSET\s+%s\s+LIMIT\s+%s;)"  # Captures OFFSET and LIMIT
            )
            query = re.sub(
                limit_offset_pattern,
                f"ORDER BY {custom_order_by} \\1",
                query,
                flags=re.IGNORECASE,
            )

        # Query Execution
        optimization_dataframe = database.execute_query(query, params=params)
        optimization_dict = optimization_dataframe.to_dict(orient="records")
        if optimization_dict:
            tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
            optimization_dict = convert_timestamp_data(
                optimization_dict, tenant_time_zone
            )
        logging.info("### get_optimization_data Optimization data converted successfully")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database,
            [optimization_type],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )
        # Query for billing period information
        billing_period_query = """
                SELECT service_provider,
                (TO_CHAR(billing_cycle_start_date, 'MM/DD/YYYY') || ' - ' || TO_CHAR(billing_cycle_end_date, 'MM/DD/YYYY')) AS billing_cycle_start_date
                    FROM billing_period
                    WHERE is_active = 'true'
                    ORDER BY
                        CASE
                            WHEN CURRENT_DATE BETWEEN billing_cycle_start_date
                            AND billing_cycle_end_date THEN 0
                            ELSE 1
                        END,
                        billing_cycle_end_date DESC
            """
        billing_period_dates = database.execute_query(
            billing_period_query, True
        ).to_dict(orient="records")
        # Extract only the service_provider values
        service_providers = [row["service_provider"] for row in billing_period_dates]

        # Create a dictionary where the key is service_provider and
        # the value is a list of billing_cycle_end_dates
        service_provider_dict = {}

        for row in billing_period_dates:
            if row["service_provider"] in service_provider_dict:
                service_provider_dict[row["service_provider"]].append(
                    row["billing_cycle_start_date"]
                )
            else:
                service_provider_dict[row["service_provider"]] = [
                    row["billing_cycle_start_date"]
                ]

        # Optionally, remove duplicates
        unique_service_providers = sorted(list(set(service_providers)))
        # Add "All" to the list of unique service providers
        unique_service_providers.insert(0, "All service providers")
        try:
            if parent_tenant_id:
                query = f"SELECT optino_cross_providercustomer_optimization FROM optimization_setting_tenant_override WHERE tenant_id = {tenant_id}"
                cross_carrier_optimization = database.execute_query(query, True)
                logging.info(f"cross_carrier_optimization=> {cross_carrier_optimization}")
                if not cross_carrier_optimization.empty:
                    cross_carrier_optimization = cross_carrier_optimization["optino_cross_providercustomer_optimization"].to_list()[0]
            else:
                cross_carrier_optimization = database.get_data(
                    "optimization_setting",
                    {"tenant_id":tenant_id},
                    ["optino_cross_providercustomer_optimization"],
                )["optino_cross_providercustomer_optimization"].to_list()[0]
        except Exception as e:
            logging.exception(f"Failed to get the cross_carrier_optimization{e}")
            cross_carrier_optimization = False
        # Preparing the response data
        return_json_data.update(
            {
                "message": "Successfully Fetched the optimization data",
                "flag": True,
                "service_providers": unique_service_providers,
                "billing_period_dates": serialize_data(service_provider_dict),
                "headers_map": headers_map,
                "data": optimization_dict,

                "cross_carrier_optimization": cross_carrier_optimization,
            }
        )
        # End time and audit logging
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "get_optimization_data",
            "created_date": request_received_at,
            "created_by": username,
            "status": str(return_json_data["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": f"successfully fetched the optimization list view data : {optimization_type}",
            "module_name": "Optimization",
            "request_received_at": request_received_at,
        }
        common_utils_database.update_audit(
            audit_data_user_actions, "audit_user_actions"
        )
        return return_json_data
    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database,
            [optimization_type],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )
        message = f"Unable to fetch the Optimization list view data{e}"
        return_json_data = {
            "flag": True,
            "message": message,
            "headers_map": headers_map,
            "data": [],
            "cross_carrier_optimization": False,
        }
        error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "get_optimization_data",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": message,
            "module_name": "Optimization",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")

        return return_json_data

##helper function to get the header mapping
def get_headers_mapping(
    tenant_database,
    module_list,
    role,
    user,
    tenant_id,
    sub_parent_module,
    parent_module,
    data,
    common_utils_database,
):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.
    
    Args:
        tenant_database (str): Name of the tenant database
        module_list (list): List of module names to get mappings for
        role (str): User role name
        user (str): Username
        tenant_id (int): Tenant ID
        sub_parent_module (str): Sub-parent module name
        parent_module (str): Parent module name
        data (dict): Request data containing additional parameters
        common_utils_database (DB): Database connection object for common_utils database
        
    Returns:
        dict: A dictionary containing field mappings, headers, and features for each module
    """
    ##Database connection
    try:
        del db_config['customers']
        del db_config['service_providers']
    except Exception as e:
        logging.exception(f"### get_headers_mapping Failed to delete the db_config : {e}")
    ret_out = {}
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    try:
        logging.info(f"### get_headers_mapping Module name is : {module_list} and role is {role}")
        # common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        feature_module_name = data.get("feature_module_name", "")
        user_name = data.get("username") or data.get("user_name") or data.get("user")
        tenant_name = data.get("tenant_name") or data.get("tenant")
        parent_module_name = data.get("parent_module_name") or data.get("parent_module")
        if parent_module_name == "Sim Management":
            parent_module_name = "Sim Management"
        try:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            logging.info(f"### get_headers_mapping tenant_id is : {tenant_id}")
        except Exception as e:
            logging.exception(f"Getting exception at fetching tenant id {e}")
        # Iterate over each module name in the provided module list
        for module_name in module_list:
            out = common_utils_database.get_data(
                "field_column_mapping", {"module_name": module_name}
            ).to_dict(orient="records")
            pop_up = []
            general_fields = []
            table_fileds = {}
            # Categorize the fetched data based on field types
            for data in out:
                if data["pop_col"]:
                    pop_up.append(data)
                elif data["table_col"]:
                    table_fileds.update(
                        {
                            data["db_column_name"]: [
                                data["display_name"],
                                data["table_header_order"],
                            ]
                        }
                    )
                else:
                    general_fields.append(data)
            # Create a dictionary to store categorized fields
            headers = {}
            headers["general_fields"] = general_fields
            headers["pop_up"] = pop_up
            headers["header_map"] = table_fileds
            try:
                final_features = []

                # Fetch all features for the 'super admin' role
                if role.lower() == "super admin":
                    all_features = common_utils_database.get_data(
                        "module_features",
                        {
                            "module": feature_module_name,
                            "parent_module_name": parent_module_name,
                        },
                        ["features"],
                    )["features"].to_list()
                    if all_features:
                        final_features = json.loads(all_features[0])
                else:
                    final_features = get_features_by_feature_name(
                        user_name,
                        tenant_id,
                        feature_module_name,
                        common_utils_database,
                        role,
                        parent_module_name,
                    )

            except Exception as e:
                logging.warning(f"there is some error {e}")
                pass
            # Add the final features to the headers dictionary
            headers["module_features"] = final_features
            ret_out[module_name] = headers
    except Exception as e:
        logging.warning("there is some error %s", e)

    return ret_out


##helper function to get the features by feature name
def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, role, parent_module
):
    """
    Description:
        This function retrieves a list of features associated with a specific
        feature name for a user within a tenant.
        It fetches user-module-tenant mapping data, processes the features,
        and extracts relevant features
        linked to the specified feature name.

    Parameters:
    ----------
    user_name : str
        The name or identifier of the user for whom the features are being fetched.
    tenant_id : str
        The tenant ID associated with the user.
    feature_name : str
        The specific feature name for which features need to be extracted.
    common_utils_database : object
        Utility database object to query data from the required tables.

    Returns:
    -------
    list
        A list of features associated with the specified feature name for the user.
    """
    try:
        del db_config['customers']
        del db_config['service_providers']
        del db_config['tenant_ids']
    except Exception as e:
        logging.exception(f"### get_features_by_feature_name Failed to delete the db_config : {e}")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    # Fetch user features from the database based on user name and tenant ID
    user_features_raw = common_utils_database.get_data(
        "user_module_tenant_mapping",
        {"user_name": user_name, "tenant_id": tenant_id},
        ["module_features"],
    )["module_features"].to_list()
    logging.info(f"### get_features_by_feature_name Raw user features fetched : {user_features_raw}")
    if not user_features_raw or user_features_raw[0] is None:
        query=f'''select module_features from role_module where role='{role}'
        '''
        user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
    # Parse the JSON string to a dictionary
    try:
        features = json.loads(
            user_features_raw[0]
        )  # Assuming it's a list with one JSON string
    except Exception as e:
        logging.exception(f"### get_features_by_feature_name Error parsing user features JSON: {e}")
        features = {}

    if not features:
        features = common_utils_database.get_data(
            "role_module",
            {"role": role},
            ["module_features"],
        )["module_features"].to_list()
        features = json.loads(features[0])

    # Initialize a list to hold features for the specified feature name
    features_list = []

    # Loop through all modules to find the specified feature name and collect its features
    for par_module, modules in features.items():
        if parent_module == par_module:
            for module, features_l in modules.items():
                if module == feature_name:
                    features_list = features_l

    # Log the retrieved features for debugging purposes
    logging.info(f"### get_features_by_feature_name Retrieved features : {features_list}")

    # Return the list of features associated with the specified feature name
    return features_list


##helper function to format the columns names
def format_column_names(columns):
    """
    Formats column names by removing underscores and capitalizing each word.
    
    Args:
        columns (list): List of column names to format
        
    Returns:
        list: List of formatted column names (e.g., 'session_id' becomes 'Session ID')
    """
    formatted_columns = []
    for col in columns:
        formatted_col = col.replace(
            "_", " "
        ).title()  # Replaces underscores and capitalizes each word
        formatted_columns.append(formatted_col)
    return formatted_columns


##Export optimization data to zip in list view
def export_optimization_data_zip(data):
    """
    Generates a ZIP file containing Excel files grouped by session IDs based on optimization data.
    
    Args:
        data (dict): Dictionary containing request parameters including optimization_type,
                    service_provider, billing_period_start_date, billing_period_end_date,
                    username, tenant_name, and database connection info
                    
    Returns:
        dict: A dictionary containing:
            - flag (bool): Success status of the operation
            - message (str): Status message
            - download_url (str): S3 URL to download the generated ZIP file
            - error (str, optional): Error message if operation fails
    """
    logging.info(f"### export_optimization_data_zip Request Data Received : {data}")
    ##start time for performance measurement
    start_time = time.time()
    request_received_at = data.get("request_received_at", "")
    # module_name = data.get("module_name", "Optimization")
    optimization_type = data.get("optimization_type", "")
    if optimization_type == "Carrier":
        module_name = "Carrier Optimization"
    else:
        module_name = "Customer Optimization"

    service_provider = data.get("service_provider", "")
    billing_period_start_date = data.get("billing_period_start_date", "")
    billing_period_end_date = data.get("billing_period_end_date", "")
    Partner = data.get("Partner", "")
    username = data.get("username", "")
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    common_utils_database.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": "Export Optimization"},
    )
    zip_filename = "Optimization_session.zip"
    s3_key = f"exports/optimization/{zip_filename}"
    S3_BUCKET_NAME = os.environ[
            "S3_BUCKET_NAME"
        ]
    # Generate download URL
    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{s3_key}"

    try:
        # Convert input dates to match database format
        if billing_period_start_date:
            billing_period_start_date = datetime.strptime(
                billing_period_start_date, "%m/%d/%Y"
            ).strftime("%m-%d-%Y %H:%M:%S")
        if billing_period_end_date:
            billing_period_end_date = datetime.strptime(
                billing_period_end_date, "%m/%d/%Y"
            ).strftime("%m-%d-%Y 23:59:59")
        logging.info("### export_optimization_data_zip Fetching the query from the database")
        # Fetch the query from the database based on the module name
        module_query_df = common_utils_database.get_data(
            "export_queries", {"module_name": module_name}
        )
        query = module_query_df.iloc[0]["module_query"]
        # Prepare the WHERE clause with necessary filters
        base_query = query.split("where")[0].strip()
        where_clause = ""
        params = []

        if service_provider:
            where_clause += " WHERE serviceprovider = %s AND billing_period_start_date >= %s AND billing_period_end_date <= %s"
            # params.append(service_provider)
            params = [
                service_provider,
                billing_period_start_date,
                billing_period_end_date,
            ]

        final_query = f"{base_query} {where_clause}"

        # Executing the query and fetching data
        data_frame = database.execute_query(final_query, params=params)
        # Create a new ZIP file buffer
        zip_buffer = io.BytesIO()        

        # If the data frame is empty, create an empty DataFrame with headers only
        if data_frame.empty:
            logging.info("### export_optimization_data_zip No data found, creating an empty Excel file")
            empty_df = pd.DataFrame(columns=["S.NO", "Session ID", "Other Columns"])
            with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zipf:
                excel_buffer = io.BytesIO()
                with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                    empty_df.to_excel(writer, index=False)
                    # Access the workbook and sheet after writing to Excel
                    workbook = writer.book
                    sheet = workbook.active

                    # Apply styles to the header row
                    for cell in sheet[1]:
                        # Center align the header cells
                        cell.alignment = Alignment(
                            horizontal="center", vertical="center"
                        )
                        # Set grey background for header cells
                        cell.fill = PatternFill(
                            start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                        )

                    # Adjust column widths based on content
                    for col_idx, col_cells in enumerate(sheet.columns, 1):
                        max_length = max(
                            len(str(cell.value or "")) for cell in col_cells
                        )
                        sheet.column_dimensions[get_column_letter(col_idx)].width = (
                            max_length + 2
                        )

                excel_buffer.seek(0)
                zipf.writestr("Empty_Optimization_Data.xlsx", excel_buffer.read())
        else:
            with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zipf:
                grouped = data_frame.groupby("session_id")
                for session_id, group in grouped:
                    folder_name = f"{session_id}/"
                    zipf.writestr(folder_name, "")

                    excel_buffer = io.BytesIO()
                    group.columns = format_column_names(group.columns)
                    with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                        group.to_excel(writer, index=False)
                        # Access the workbook and sheet after writing to Excel
                        workbook = writer.book
                        sheet = workbook.active

                        # Apply styles to the header row
                        for cell in sheet[1]:
                            # Center align the header cells
                            cell.alignment = Alignment(
                                horizontal="center", vertical="center"
                            )
                            # Set grey background for header cells
                            cell.fill = PatternFill(
                                start_color="D3D3D3",
                                end_color="D3D3D3",
                                fill_type="solid",
                            )

                        # Adjust column widths based on content
                        for col_idx, col_cells in enumerate(sheet.columns, 1):
                            max_length = max(
                                len(str(cell.value or "")) for cell in col_cells
                            )
                            sheet.column_dimensions[
                                get_column_letter(col_idx)
                            ].width = (max_length + 2)

                    excel_buffer.seek(0)
                    zipf.writestr(
                        f"{folder_name}{session_id}.xlsx", excel_buffer.read()
                    )

        # Upload the ZIP file to S3
        zip_buffer.seek(0)
        s3_client = boto3.client("s3")

        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=s3_key,
            Body=zip_buffer.getvalue(),
            ContentType="application/zip",
        )

        
        logging.info("### export_optimization_data_zip File uploaded to S3 successfully")

        # Log success and return response
        response = {
            "flag": True,
            "message": "Export successful",
            "download_url": download_url,
        }
        common_utils_database.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": "Export Optimization"},
        )
        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "export_optimization_data_zip",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f"successfully export the optimization zip file : {optimization_type} download url : {download_url}",
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"Failed to log the audit data: {e}")
        return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        message = "Something went wrong in export optimization data zip"
        error_data = {
            "service_name": "export_optimization_data_zip",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "tenant_name": Partner,
            "comments": f"export optimization zip file failed : {optimization_type} download url : {download_url}",
            "module_name": "Optimization",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        common_utils_database.update_dict(
            "export_status",
            {"status_flag": "Failure", "url": ""},
            {"module_name": "Export Optimization"},
        )

        return {"flag": False, "error": message}


##helper function to convert the timestamp data
def format_timestamp(ts):
    """
    Formats a timestamp into a human-readable string format.
    
    Args:
        ts (datetime or pandas.Timestamp): The timestamp to format
        
    Returns:
        str: Formatted timestamp string (e.g., "Jan 01, 2023, 12:00 PM") or "N/A" if timestamp is None or NaN
    """
    # Check if the timestamp is not None
    if ts is not None and pd.notna(ts):
        # Convert a Timestamp or datetime object to the desired string format
        return ts.strftime("%b %d, %Y, %I:%M %p")
    else:
        # Return a placeholder or empty string if the timestamp is None
        return "N/A"


##optimization dropdown data function
def optimization_dropdown_data(data):
    """
    Fetches dropdown data for service providers, customers, and billing periods.
    
    Args:
        data (dict): Dictionary containing request parameters including tenant_database,
                    tenant_name, username, and session_id
                    
    Returns:
        dict: A dictionary containing:
            - flag (bool): Success status of the operation
            - service_provider_customers (dict): Mapping of service providers to their customers
            - service_provider_dict (dict): Mapping of service provider names to their IDs
            - service_provider_billing_periods (dict): Mapping of service providers to their billing periods
            - cross_carrier_optimization (bool): Whether cross-carrier optimization is enabled
            - message (str, optional): Error message if operation fails
    """
    logging.info(f"### optimization_dropdown_data Request Data Received : {data}")
    ##start time for performance measurement
    start_time = time.time()
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    tenant_database = data.get("db_name", "")
    tenant_name = data.get("tenant_name", "")
    session_id = data.get("session_id", "")
    try:
        # Database connection
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    try:
        # List of service provider names with their IDs
        serviceproviders = database.get_data(
            "serviceprovider",
            {"is_active": True, "service_provider_name": "not Null"},
            ["id", "service_provider_name"],
        )
        service_provider_list = serviceproviders.to_dict(
            orient="records"
        )  # List of dicts containing both id and service_provider_name
        service_provider_list = sorted(
            service_provider_list, key=lambda x: x["service_provider_name"]
        )
        logging.info(f"Successfully fetched the service providers")

        # Initialize dictionaries to store separate data
        service_provider_customers = {}
        service_provider_billing_periods = {}

        # Iterate over each service provider
        for service_provider in service_provider_list:
            service_provider_id = service_provider["id"]
            service_provider_name = service_provider["service_provider_name"]

            # Get customer data (including possible duplicates)
            query_customers = f"""SELECT DISTINCT customer_name, customer_id
              FROM optimization_customer_processing where service_provider='{service_provider_name}' order by customer_name asc
              """
            customers = database.execute_query(query_customers, True)

            # Create a set to filter unique customer names
            unique_customers = set()
            customer_list = []

            # Loop through each customer and add unique ones to the list
            for row in customers.to_dict(orient="records"):
                customer_name = row["customer_name"]
                if (
                    customer_name not in unique_customers
                ):  # Check if the customer is already added
                    unique_customers.add(customer_name)
                    customer_list.append(
                        {
                            "customer_id": row["customer_id"],
                            "customer_name": customer_name,
                        }
                    )

            # Get billing period data including start date, end date, and ID
            billing_periods_query = f"""
            SELECT DISTINCT ON (billing_cycle_end_date)
                id,
                service_provider,
                billing_cycle_start_date,
                billing_cycle_end_date
            FROM public.billing_period where service_provider='{service_provider_name}' and is_active=True
            ORDER BY billing_cycle_end_date DESC;
            """
            billing_periods = database.execute_query(billing_periods_query, True)

            # Check and handle missing or invalid values in the billing_cycle_end_date column
            billing_periods["billing_cycle_end_date"] = pd.to_datetime(
                billing_periods["billing_cycle_end_date"], errors="coerce"
            )
            billing_periods["billing_cycle_end_date"] = billing_periods[
                "billing_cycle_end_date"
            ].apply(
                lambda date: (
                    (date - pd.Timedelta(days=1)).replace(hour=23, minute=59, second=59)
                    if pd.notna(date) and date.time() == pd.Timestamp("00:00:00").time()
                    else date
                )
            )

            # Filter out rows with NaT in billing_cycle_end_date
            billing_periods = billing_periods.dropna(subset=["billing_cycle_end_date"])

            # Initialize a list to hold the formatted billing periods
            formatted_billing_periods = []
            for period in billing_periods.to_dict(orient="records"):
                formatted_period = {
                    "id": period["id"],
                    "billing_period_start_date": format_timestamp(
                        period["billing_cycle_start_date"]
                    ),
                    "billing_period_end_date": format_timestamp(
                        period["billing_cycle_end_date"]
                    ),
                }
                formatted_billing_periods.append(formatted_period)

            # Add the service provider's ID, customer list, and formatted
            # billing periods to the dictionary
            service_provider_customers[service_provider_name] = {
                "id": service_provider_id,
                "customers": customer_list,
            }
            service_provider_billing_periods[service_provider_name] = (
                formatted_billing_periods
            )

        service_provider_id_map = database.get_data(
            "serviceprovider", {"is_active": True}, ["id", "service_provider_name"]
        ).to_dict(orient="records")
        service_provider_dict = {
            item["service_provider_name"]: item["id"]
            for item in service_provider_id_map
        }
        # Prepare the response
        response = {
            "flag": True,
            "service_provider_customers": service_provider_customers,
            "service_provider_dict": service_provider_dict,
            "service_provider_billing_periods": service_provider_billing_periods,
            "cross_carrier_optimization": False,
        }
        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "optimization_dropdown_data",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": "successfully fetched optimization_dropdown_data",
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"### optimization_dropdown_data Failed to log the audit data: {e}")
        return response

    except Exception as e:
        logging.exception(f"### optimization_dropdown_data Exception occurred while fetching the data: {e}")
        message = f"Exception: {e}"
        # Prepare the response in case of an exception
        response = {
            "flag": False,
            "service_provider_customers": {},
            "service_provider_billing_periods": {},
            "message": message,
        }
        message = "Failed to fetch the optimization dropdown data"
        error_data = {
            "service_name": "optimization_dropdown_data",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Optimization",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return response

##Helper function to get the rate plans by customer count
def rate_plans_by_customer_count(data, mobility_service_provider_ids):
    """
    Retrieves and processes rate plan information based on the number of customers for a specified service provider.
    
    Args:
        data (dict): Dictionary containing request parameters including ServiceProviderId, BillingPeriodId, 
                    tenant_name, and customer_name
        mobility_service_provider_ids (list): List of service provider IDs that are mobility providers
        
    Returns:
        list or int: For portal_id=0, returns a list of tuples with rate plan data; 
                    for portal_id=2, returns an integer count of rate plans
    """
    logging.info(f"### rate_plans_by_customer_count data : {data}")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_database = data.get("db_name", "")
    # database Connection
    database = DB(tenant_database, **db_config)
    ServiceProviderId = data.get("ServiceProviderId", "")
    BillingPeriodId = data.get("BillingPeriodId", "")
    tenant_name = data.get("tenant_name", "")
    role_name=data.get('role_name','')
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    TenantId = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id"]
    )["id"].to_list()[0]
    customer_name = data.get("customer_name", "")
    # Fetch integration_id and portal_id using database queries
    integration_id = database.get_data(
        "serviceprovider", {"id": ServiceProviderId}, ["integration_id"]
    )["integration_id"].to_list()[0]
    portal_id = database.get_data(
        "integration", {"id": integration_id}, ["portal_type_id"]
    )["portal_type_id"].to_list()[0]
    logging.info(f"portal id is {portal_id}")
    rev_status=True
    try:
        role_module_data = common_utils_database.get_data(
                                    "role_module",
                                    {"role": role_name},
                                    ["sub_module"],
                                )

             # Initialize default status
        rev_status = False

        if not role_module_data.empty:
            try:
                # Parse JSON safely with fallback
                sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                # Strict nested check
                if "People" in sub_modules:
                    people_modules = sub_modules["People"]
                    if isinstance(people_modules, list):  # Ensure it's a list
                        rev_status = "Billing Platform Customers" in people_modules

            except json.JSONDecodeError:
                logging.error(f"Invalid JSON in sub_module for role: {role_name}")
            except KeyError:
                pass  # People section not present
            except Exception as e:
                logging.error(f"Unexpected error processing modules: {str(e)}")  
        if rev_status == True:
            SiteType = 1
        else:
            SiteType = 0
    except Exception as e:
        logging.error(f"Exception while fetching the sitetype")
        SiteType = 1
    # If portal_id is 0, proceed with M2M connection and stored procedure execution
    if portal_id == 0:
        logging.info(f"portal id is {portal_id}")
        # Define database connection parameters
        creds = get_db_credentials(tenant_name)
        if creds:
            server = creds["server"]
            database_name = creds["database_name"]
            username = creds["username"]
            password = creds["password"]
            port = creds["port"]
        else:
            # Define database connection parameters
            server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
            database_name = os.environ["ONEPOINTODATABASE"]
            username = os.environ["ONEPOINTOUSERNAME"]
            password = os.environ["ONEPOINTOPASSWORD"]
        if customer_name == "All Customers":
            AMOPCustomerIds = None
            RevCustomerIds = None
            # SiteType = 1
        else:
            rev_customer_data = database.get_data(
                "customers", {"customer_name": customer_name}, ["rev_customer_id"]
            )["rev_customer_id"].to_list()
            # Check if rev_customer_id data is available
            if rev_customer_data and rev_status:
                RevCustomerIds = ",".join([str(id) for id in rev_customer_data])
                AMOPCustomerIds = ""
                # SiteType = 1
            else:
                # If rev_customer_id is None or empty, get customer_id data
                AMOPCustomerIds = ",".join(
                    [
                        str(id)
                        for id in database.get_data(
                            "customers",
                            {"customer_name": customer_name},
                            ["id"],
                        )["id"].to_list()
                    ]
                )
                RevCustomerIds = ""
                # SiteType = 0
        # Try connecting to the database and executing the stored procedure
        try:
            with pytds.connect(
                server=server, database=database_name, user=username, password=password
            ) as conn:
                with conn.cursor() as cursor:
                    # Define the stored procedure name
                    stored_procedure_name = (
                        f"{database_name}.dbo.usp_OptimizationRatePlansByCustomerCount"
                    )

                    # Execute the stored procedure
                    cursor.callproc(
                        stored_procedure_name,
                        (
                            RevCustomerIds,
                            ServiceProviderId,
                            TenantId,
                            SiteType,
                            AMOPCustomerIds,
                            BillingPeriodId,
                        ),
                    )
                    logging.info("### rate_plans_by_customer_count successfully hit happened")
                    # Fetch and return the results
                    results = cursor.fetchall()
                    return results

        except Exception as e:
            logging.exception(f"### rate_plans_by_customer_count Error in connection or execution: {e}")
            return None
    elif portal_id == 2:
        # Define database connection parameters
        creds = get_db_credentials(tenant_name)
        if creds:
            server = creds["server"]
            database_name = creds["database_name"]
            username = creds["username"]
            password = creds["password"]
            port = creds["port"]
        else:
            # Define database connection parameters
            server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
            database_name = os.environ["ONEPOINTODATABASE"]
            username = os.environ["ONEPOINTOUSERNAME"]
            password = os.environ["ONEPOINTOPASSWORD"]
        if customer_name != "All Customers":
            rev_customer_data = database.get_data(
                "customers", {"customer_name": customer_name}, ["rev_customer_id"]
            )["rev_customer_id"].to_list()
        # working for mobility rate plan count
        # Define your connection parameters
        with pytds.connect(
            server=server, database=database_name, user=username, password=password
        ) as conn:
            with conn.cursor() as cursor:
                stored_procedure_name = (
                    "dbo.usp_OptimizationMobilityRatePlansByCustomerCount"
                )
                if customer_name == "All Customers":
                    AMOPCustomerIds = ""
                    RevCustomerIds = ""
                    if rev_status==True:
                        SiteType = 1
                    else:
                        SiteType = 0

                else:
                    # Check if rev_customer_id data is available
                    if rev_customer_data and rev_status:
                        RevCustomerIds = ",".join([str(id) for id in rev_customer_data])
                        AMOPCustomerIds = ""
                        SiteType = 1
                    else:
                        # If rev_customer_id is None or empty, get customer_id data
                        AMOPCustomerIds = ",".join(
                            [
                                str(id)
                                for id in database.get_data(
                                    "customers",
                                    {"customer_name": customer_name},
                                    ["id"],
                                )["id"].to_list()
                            ]
                        )
                        RevCustomerIds = ""
                        SiteType = 0
                output_param = pytds.output(value=0, param_type=int)
                logging.info(
                    f"Calling rate plan stored procedure '{stored_procedure_name}' with params: "
                    f"ServiceProviderId={ServiceProviderId}, "
                    f"TenantId={TenantId}, "
                    f"SiteType={SiteType}, "
                    f"BillingPeriodId={BillingPeriodId}, "
                    f"AMOPCustomerIds={AMOPCustomerIds}, "
                    f"RevCustomerIds={RevCustomerIds}"
                )
                return_value = cursor.callproc(
                    stored_procedure_name,
                    (
                        RevCustomerIds,
                        ServiceProviderId,
                        TenantId,
                        SiteType,
                        AMOPCustomerIds,
                        BillingPeriodId,
                        output_param,
                    ),
                )  # Placeholder for output parameter
                return_values = int(output_param.value)
                output_value = return_value[-1]
                return output_value

##Helper function to get the sim cards to optimize count
def sim_cards_to_optimize_count(data, mobility_service_provider_ids):
    """
    Calculates the number of SIM cards eligible for optimization based on the provided filters.
    
    Args:
        data (dict): Dictionary containing request parameters including ServiceProviderId, BillingPeriodId,
                    tenant_name, customer_name, and optimization_type
        mobility_service_provider_ids (list): List of service provider IDs that are mobility providers
        
    Returns:
        int: The count of SIM cards eligible for optimization
    """
    logging.info(f"### sim_cards_to_optimize_count Request Data Recieved : {data}")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    ServiceProviderIds = data.get("ServiceProviderId", "")
    query = f"select id from serviceprovider where id={ServiceProviderIds}"
    ServiceProviderId = database.execute_query(query, True)["id"].to_list()[0]
    logging.info(f"ServiceProviderId is {ServiceProviderId}")
    BillingPeriodId = data.get("BillingPeriodId", "")
    customer_name = data.get("customer_name", "")
    tenant_name = data.get("tenant_name", "")
    role_name=data.get('role_name','')
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    TenantId = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id"]
    )["id"].to_list()[0]
    optimization_type = data.get("optimization_type", "")
    rev_status=True
    try:
        role_module_data = common_utils_database.get_data(
                                    "role_module",
                                    {"role": role_name},
                                    ["sub_module"],
                                )

             # Initialize default status
        rev_status = False
        if not role_module_data.empty:
            try:
                # Parse JSON safely with fallback
                sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                # Strict nested check
                if "People" in sub_modules:
                    people_modules = sub_modules["People"]
                    if isinstance(people_modules, list):  # Ensure it's a list
                        rev_status = "Billing Platform Customers" in people_modules

            except json.JSONDecodeError:
                logging.error(f"Invalid JSON in sub_module for role: {role_name}")
            except KeyError:
                pass  # People section not present
            except Exception as e:
                logging.error(f"Unexpected error processing modules: {str(e)}")  
        if rev_status == True:
            SiteType = 1
        else:
            SiteType = 0
    except Exception as e:
        logging.error(f"Exception while fetching the sitetype")
        SiteType = 1
    # Define your connection parameters
    creds = get_db_credentials(tenant_name)
    if creds:
        server = creds["server"]
        database = creds["database_name"]
        username = creds["username"]
        password = creds["password"]
        port = creds["port"]
    else:
        # Define database connection parameters
        server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
        database = os.environ["ONEPOINTODATABASE"]
        username = os.environ["ONEPOINTOUSERNAME"]
        password = os.environ["ONEPOINTOPASSWORD"]
    sim_cards_to_optimize = 0  # Ensure default initialization
    if optimization_type == "Customer" and customer_name == "All Customers":
        # customer_name='Easy Shop Supermarket (300007343)'
        # Create a connection to the database
        try:
            with pytds.connect(
                server=server, database=database, user=username, password=password
            ) as conn:
                with conn.cursor() as cursor:
                    # Define the stored procedure name
                    # rev_status=False
                    if rev_status == True:
                        if ServiceProviderId in mobility_service_provider_ids:
                            stored_procedure_name = f"{database}.dbo.[usp_Optimization_Mobility_CustomersGet]"
                        else:
                            stored_procedure_name = (
                                f"{database}.dbo.[usp_OptimizationCustomersGet]"
                            )

                    else:
                        if ServiceProviderId in mobility_service_provider_ids:
                            stored_procedure_name = f"{database}.dbo.[usp_Optimization_Mobility_AMOPCustomersGet]"

                        else:
                            stored_procedure_name = (
                                f"{database}.dbo.[usp_Optimization_AMOPCustomersGet]"
                            )

                    # Execute the stored procedure
                    cursor.callproc(
                        stored_procedure_name,
                        (TenantId, ServiceProviderId, BillingPeriodId),
                    )

                    # Fetch results if the stored procedure returns any
                    results = cursor.fetchall()
                    # If a specific customer_name is provided, count only that customer's records
                    if customer_name == "All Customers":
                        # If no customer_name is provided, sum all the records
                        for row in results:
                            sim_cards_to_optimize += row[-1]

                    else:
                        for row in results:
                            if row[1] == customer_name:
                                sim_cards_to_optimize = row[-1]
                                break

                    return sim_cards_to_optimize

        except Exception as e:
            logging.exception(f"### sim_cards_to_optimize_count Error in connection or execution : {e}")
    elif optimization_type == "Carrier":
        # Create a connection to the database for optimization type other than 'Customer'
        try:
            with pytds.connect(
                server=server, database=database, user=username, password=password
            ) as conn:
                with conn.cursor() as cursor:
                    # Define the stored procedure name
                    if ServiceProviderId in mobility_service_provider_ids:
                        stored_procedure_name = (
                            f"{database}.dbo.[usp_Optimization_Mobility_SimCardsCount]"
                        )
                        SiteType = 1
                        AMOPCustomerId = None
                        RevAccountNumber = None
                        isCarrierOptimization = True
                        IntegrationAuthenticationId=None
                        # Execute the stored procedure
                        cursor.callproc(
                            stored_procedure_name,
                            (
                                ServiceProviderId,
                                RevAccountNumber,
                                BillingPeriodId,
                                SiteType,
                                AMOPCustomerId,
                                isCarrierOptimization,
                                IntegrationAuthenticationId,
                                TenantId
                            ),
                        )
                        # Fetch results if the stored procedure returns any
                        results = cursor.fetchall()
                    else:
                        stored_procedure_name = (
                            f"{database}.dbo.[usp_OptimizationSimCardsCount]"
                        )
                        SiteType = 1
                        AMOPCustomerId = None
                        RevAccountNumber = None
                        IntegrationAuthenticationId=None
                        # Execute the stored procedure
                        cursor.callproc(
                            stored_procedure_name,
                            (
                                ServiceProviderId,
                                RevAccountNumber,
                                BillingPeriodId,
                                SiteType,
                                AMOPCustomerId,
                                IntegrationAuthenticationId,
                                TenantId
                            ),
                        )
                        # Fetch results if the stored procedure returns any
                        results = cursor.fetchall()

                    for row in results:
                        sim_cards_to_optimize += row[-1]

                    return sim_cards_to_optimize

        except Exception as e:
            logging.exception(f"### sim_cards_to_optimize_count Error in connection or execution: {e}")
    else:
        rev_customer_id = str(data.get("customer_id", ""))
        rev_customer_id = str(rev_customer_id)
        IntegrationAuthenticationId=os.environ["INTEGRATION_AUTHENTICATION_ID"]
        # Create a connection to the database for optimization type other than 'Customer'
        try:
            with pytds.connect(
                server=server, database=database, user=username, password=password
            ) as conn:
                with conn.cursor() as cursor:
                    # Define the stored procedure name
                    if ServiceProviderId in mobility_service_provider_ids:
                        stored_procedure_name = (
                            f"{database}.dbo.[usp_Optimization_Mobility_SimCardsCount]"
                        )
                    else:
                        stored_procedure_name = (
                            f"{database}.dbo.[usp_OptimizationSimCardsCount]"
                        )
                    if rev_status==True:
                        SiteType = 1
                    else:
                        SiteType = 0
                    if rev_status == True:
                        AMOPCustomerId = None
                        RevAccountNumber = rev_customer_id
                    else:
                        AMOPCustomerId = rev_customer_id
                        RevAccountNumber = None
                    isCarrierOptimization=False
                    # Execute the stored procedure
                    logging.info(TenantId,'Tenant Id recieved in sim_cards_to_optimize_count')
                    if ServiceProviderId in mobility_service_provider_ids:
                        logging.info(
                            f"Calling stored procedure '{stored_procedure_name}' with parameters: "
                            f"ServiceProviderId={ServiceProviderId}, "
                            f"RevAccountNumber='{RevAccountNumber}', "
                            f"BillingPeriodId={BillingPeriodId}, "
                            f"SiteType='{SiteType}', "
                            f"AMOPCustomerId={AMOPCustomerId}, "
                            f"isCarrierOptimization={isCarrierOptimization}, "
                            f"IntegrationAuthenticationId={IntegrationAuthenticationId}, "
                            f"TenantId={TenantId}"
                        )
                        cursor.callproc(
                            stored_procedure_name,
                            (
                                ServiceProviderId,
                                RevAccountNumber,
                                BillingPeriodId,
                                SiteType,
                                AMOPCustomerId,
                                isCarrierOptimization,
                                IntegrationAuthenticationId,
                                TenantId
                            ),
                        )
                    else:
                        cursor.callproc(
                            stored_procedure_name,
                            (
                                ServiceProviderId,
                                RevAccountNumber,
                                BillingPeriodId,
                                SiteType,
                                AMOPCustomerId,
                                IntegrationAuthenticationId,
                                TenantId
                            ),
                        )
                    # Fetch results if the stored procedure returns any
                    results = cursor.fetchall()
                    for row in results:
                        sim_cards_to_optimize += row[-1]

                    return sim_cards_to_optimize
        except Exception as e:
            logging.exception(f"### sim_cards_to_optimize_count Error in connection or execution: {e}")


def get_customer_total_sim_cards_count(
    rev_customer_id,
    database,
    ServiceProviderId,
    tenant_id,
    mobility_service_provider_ids,role_name
):
    """
    This function get_customer_total_sim_cards_count(rev_customer_id, database,
    ServiceProviderId) counts the total number of SIM cards for a given customer (identified by rev_customer_id)
    and service provider (ServiceProviderId).
    It executes different SQL queries based on whether the rev_customer_id is provided and whether it is valid
    """
    logging.info(f"### get_customer_total_sim_cards_count Request Data Received : {rev_customer_id}, {ServiceProviderId}")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    rev_status=True
    try:
        role_module_data = common_utils_database.get_data(
                                    "role_module",
                                    {"role": role_name},
                                    ["sub_module"],
                                )

             # Initialize default status
        rev_status = False

        if not role_module_data.empty:
            try:
                # Parse JSON safely with fallback
                sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                # Strict nested check
                if "People" in sub_modules:
                    people_modules = sub_modules["People"]
                    if isinstance(people_modules, list):  # Ensure it's a list
                        rev_status = "Billing Platform Customers" in people_modules
                logging.info(f"Rev Status in module is  {rev_status}")

            except json.JSONDecodeError:
                logging.error(f"Invalid JSON in sub_module for role: {role_name}")
            except KeyError:
                pass  # People section not present
            except Exception as e:
                logging.error(f"Unexpected error processing modules: {str(e)}")  
    except Exception as e:
        logging.error(f"Exception while fetching the sitetype")
        rev_status=True
    logging.info(f"Rev Status {rev_status}")
    try:
        # Ensure rev_customer_id is a string
        rev_customer_id = str(rev_customer_id)

        # Check if rev_customer_id is 0 or empty string and go to else block
        if rev_customer_id == "0" or not rev_customer_id:
            if ServiceProviderId in mobility_service_provider_ids:
                # If rev_customer_id is not provided or is '0', count SIM cards for all customers
                rev_customer_ids_query = f"""
                SELECT
                	COUNT(*) AS count
                	FROM
                		Mobility_Device_Tenant AS dt
                	INNER JOIN
                		Mobility_Device AS d ON dt.Mobility_Device_Id = d.id
                	LEFT OUTER JOIN
                		customers AS s ON dt.customer_id = s.id
                	INNER JOIN
                		ServiceProvider sp ON d.service_provider_id = sp.Id
                WHERE
                (sp.Tenant_Id = {tenant_id} OR dt.Tenant_Id = {tenant_id})
                AND dt.Is_Active = true
                AND dt.Is_Deleted = false AND d.Service_Provider_Id ={ServiceProviderId}
                """
            else:
                rev_customer_ids_query = f"""
                SELECT
                    count(*)
                    FROM
                        Device_Tenant AS dt
                    INNER JOIN
                        Device AS d ON dt.Device_id = d.id
                    LEFT OUTER JOIN
                        customers AS s ON dt.customer_Id = s.id
                    INNER JOIN
                        ServiceProvider sp ON d.Service_Provider_Id = sp.Id
                    WHERE
                        (sp.Tenant_Id = {tenant_id} OR dt.Tenant_Id = {tenant_id})
                        AND dt.Is_Active = true
                        AND dt.Is_Deleted = false AND d.Service_Provider_Id ={ServiceProviderId}
                        """
            rev_customer_ids = database.execute_query(rev_customer_ids_query, True)
            count_value = rev_customer_ids["count"][
                0
            ]  # Assuming the result is returned as a DataFrame
            return count_value
        else:
            logging.info(f"entered where single customer query is executed")
            integration_authentication_id = database.get_data(
                "integration_authentication",
                {"service_provider_id": ServiceProviderId, "is_active": True},
                ["id"],
            )["id"].to_list()[0]
            integration_authenticationid= os.environ["INTEGRATION_AUTHENTICATION_ID"]
            if rev_status == True:
                logging.info(f"Rev Status is True and {mobility_service_provider_ids}")
                site_id_query = f"""
                    SELECT c.id FROM public.revcustomer rc
                    JOIN customers c ON rc.id=c.rev_customer_id
                    WHERE rc.rev_customer_id='{rev_customer_id}'
                    AND rc.is_active=True AND rc.tenant_id={tenant_id}
                    AND rc.integration_authentication_id={integration_authenticationid}
                """
                siteId = database.execute_query(site_id_query, True)["id"].to_list()[0]
                if ServiceProviderId in mobility_service_provider_ids:
                    rev_customer_ids_query = f"""
                            SELECT
                            COUNT(*) AS count
                            FROM
                                Mobility_Device_Tenant AS dt
                            INNER JOIN
                                Mobility_Device AS d ON dt.Mobility_Device_Id = d.id
                            LEFT OUTER JOIN
                                customers AS s ON dt.customer_id = s.id
                            INNER JOIN
                                ServiceProvider sp ON d.service_provider_id = sp.Id
                            WHERE
                                dt.Tenant_Id = {tenant_id}
                                AND dt.Is_Active = TRUE
                                AND d.service_provider_id = {ServiceProviderId}
                                AND dt.Account_Number = '{rev_customer_id}'
                                AND dt.Account_Number_Integration_Authentication_Id = {integration_authenticationid}
                                AND (dt.customer_id = {siteId} OR s.parent_customer_id = {siteId});
                    """
                else:
                    logging.info(f"Rev Status is True and query will run for M2M Devices")
                    # If rev_customer_id is provided and valid, count SIM cards for this specific customer
                    rev_customer_ids_query = f"""
                        SELECT
                            count(*)
                            FROM
                                Device_Tenant AS dt
                            INNER JOIN
                            Device AS d ON dt.Device_Id = d.id
                            LEFT OUTER JOIN
                                customers AS s ON dt.customer_id = s.id
                            INNER JOIN
                                ServiceProvider sp ON d.Service_Provider_Id = sp.Id
                            WHERE
                                (sp.Tenant_Id = {tenant_id} OR dt.Tenant_Id = {tenant_id})
                                AND dt.Is_Active = true
                                and d.is_active =true
                                AND d.Service_Provider_Id = {ServiceProviderId}
                                and Account_Number = '{rev_customer_id}'
                                AND Account_Number_Integration_Authentication_Id ={integration_authenticationid} and s.Id={siteId}
                    """
                rev_customer_ids = database.execute_query(rev_customer_ids_query, True)
                count_value = rev_customer_ids["count"][
                    0
                ]  # Assuming the result is returned as a DataFrame

                return count_value
            else:
                logging.info(f"Rev Status is False and checking for single customer")
                integration_authentication_id = database.get_data(
                    "integration_authentication",
                    {"service_provider_id": ServiceProviderId, "is_active": True},
                    ["id"],
                )["id"].to_list()[0]
                # If rev_customer_id is provided and valid, count SIM cards for this specific customer
                if ServiceProviderId not in mobility_service_provider_ids:
                    rev_customer_ids_query = f"""
                        SELECT
                            count(*)
                            FROM
                                Device_Tenant AS dt
                            INNER JOIN
                            Device AS d ON dt.Device_Id = d.id
                            LEFT OUTER JOIN
                                customers AS s ON dt.customer_id = s.id
                            INNER JOIN
                                ServiceProvider sp ON d.Service_Provider_Id = sp.Id
                            WHERE
                                (sp.Tenant_Id = {tenant_id} OR dt.Tenant_Id = {tenant_id})
                                AND dt.Is_Active = true
                                and d.is_active =true
                                AND d.Service_Provider_Id = {ServiceProviderId}
                                and Account_Number = '{rev_customer_id}'
                                AND Account_Number_Integration_Authentication_Id ={integration_authentication_id}
                    """
                else:
                    rev_customer_ids_query = f"""
                    SELECT count(*) FROM Mobility_Device_Tenant AS dt 
                    INNER JOIN Mobility_Device AS d ON dt.Mobility_Device_Id = d.id
                    LEFT OUTER JOIN customers AS s ON dt.customer_id = s.id
                    INNER JOIN ServiceProvider sp ON d.service_provider_id = sp.Id 
                    WHERE (sp.Tenant_Id = {tenant_id} OR dt.Tenant_Id = {tenant_id}) 
                    AND dt.Is_Active = true and dt.is_deleted =false AND 
                    d.service_provider_id = 6 and dt.customer_id ='{rev_customer_id}'
                    """

                rev_customer_ids = database.execute_query(rev_customer_ids_query, True)
                count_value = rev_customer_ids["count"][
                    0
                ]  # Assuming the result is returned as a DataFrame

                return count_value

    except Exception as e:
        logging.exception(f"### get_customer_total_sim_cards_count Exception is {e}")
        count_value = 0
        return count_value



def get_optimization_pop_up_data(data):
    """
    Fetches rate plan count, SIM cards to optimize, and total SIM cards count for optimization pop-up.
    
    Args:
        data (dict): Dictionary containing request parameters including optimization_type,
                    ServiceProviderId, customer_id, tenant_name, and database connection info
                    
    Returns:
        dict: A dictionary containing:
            - flag (bool): Success status of the operation
            - rate_plan_count (int): Number of rate plans available
            - sim_cards_to_optimize (int): Number of SIM cards eligible for optimization
            - total_sim_cards_count (int): Total number of SIM cards
            - message (str, optional): Error message if operation fails
    """
    logging.info(f"Request Data in recieved in get_optimization_pop_up_data")
    try:
        del db_config['customers']
        del db_config['service_providers']
        del db_config['tenant_ids']
    except Exception as e:
        logging.exception(f"### get_optimization_pop_up_data Failed to delete the db_config {e}")
    # Record the start time for performance measurement
    start_time = time.time()
    ##database connection
    tenant_database = data.get("db_name", "")
    role_name=data.get("role_name","")
    request_received_at = data.get("request_received_at", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    tenant_id = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id"]
    )["id"].to_list()[0]
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    # database Connection
    database = DB(tenant_database, **db_config)
    mobility_service_providers = os.getenv("MOBILITY_SERVICE_PROVIDER_NAMES", "").split("/")
    try:
        # Construct the query dynamically based on the service provider names
        mobility_service_provider_ids_query = f"""
            SELECT id
            FROM serviceprovider
            WHERE service_provider_name IN ({', '.join(["'" + name.strip() + "'" for name in mobility_service_providers])})
        """
        mobility_service_provider_dataframe = database.execute_query(
            mobility_service_provider_ids_query, True
        )
        # Assuming the result is a Pandas DataFrame, we extract the 'id' column as a list
        if isinstance(mobility_service_provider_dataframe, pd.DataFrame):
            mobility_service_provider_ids = mobility_service_provider_dataframe[
                "id"
            ].tolist()
    except Exception as e:
        logging.warning(f"### get_optimization_pop_up_data Exception while fetching the service providers : {e}")
        mobility_service_provider_ids = [0]

    ServiceProviderId = data.get("ServiceProviderId", "")
    common_utils_database.update_dict(
        "optimization_pop_up_values",
        {
            "rate_plan_count": 0,
            "sim_cards_to_optimize": 0,
            "total_sim_cards_count": 0,
            "status": "Waiting",
        },
        {"id": 1},
    )
    try:
        optimization_type = data.get("optimization_type", "")

        if optimization_type == "Customer":
            """Rate Plan Count"""
            try:
                # Call function to get rate plans count by customer
                results = rate_plans_by_customer_count(
                    data, mobility_service_provider_ids
                )
                try:
                    rate_plan_count = int(
                        results[0][0]
                    )  # Ensure conversion to standard int
                except Exception as e:
                    logging.exception(f"### get_optimization_pop_up_data Exception while converting rate_plan_count to int: {e}")
                    rate_plan_count = results
            except Exception as e:
                logging.exception(f"### get_optimization_pop_up_data Failed to fetch the rate_plans : {e}")
                rate_plan_count = 0
            if rate_plan_count==None:
                rate_plan_count=0
            logging.info(f"### get_optimization_pop_up_data rate_plan_count is {rate_plan_count}")

            """Sim cards to Optimize"""
            try:
                # Call function to get SIM cards to optimize
                sim_cards_to_optimize = sim_cards_to_optimize_count(
                    data, mobility_service_provider_ids
                )
                if sim_cards_to_optimize is None:
                    sim_cards_to_optimize = 0
                sim_cards_to_optimize = int(
                    sim_cards_to_optimize
                )  # Ensure conversion to standard int
            except Exception as e:
                logging.warning(f"### get_optimization_pop_up_data sim_cards_to_optimize : {e}")
                sim_cards_to_optimize = 0

            """Total Sim cards"""
            rev_customer_id = str(data.get("customer_id", ""))
            total_sim_cards_count = int(
                get_customer_total_sim_cards_count(
                    rev_customer_id,
                    database,
                    ServiceProviderId,
                    tenant_id,
                    mobility_service_provider_ids,role_name
                )
            )  # Ensure conversion to standard int
            common_utils_database.update_dict(
                "optimization_pop_up_values",
                {
                    "rate_plan_count": rate_plan_count,
                    "sim_cards_to_optimize": sim_cards_to_optimize,
                    "total_sim_cards_count": total_sim_cards_count,
                    "status": "Success",
                },
                {"id": 1},
            )
            response = {
                "flag": True,
                "rate_plan_count": rate_plan_count,
                "sim_cards_to_optimize": sim_cards_to_optimize,
                "total_sim_cards_count": total_sim_cards_count,
            }
            return response

        else:
            """Rate Plan Count"""
            params = [ServiceProviderId]
            logging.info(ServiceProviderId, "ServiceProviderId")
            rate_plan_count_query = "SELECT count(*) FROM public.carrier_rate_plan where service_provider_id=%s and is_active=True"
            rate_plan_count = int(
                database.execute_query(rate_plan_count_query, params=params).iloc[0, 0]
            )  # Ensure conversion to standard int
            logging.info(rate_plan_count, "rate_plan_count")

            """Sim cards to Optimize"""
            try:
                sim_cards_to_optimize = sim_cards_to_optimize_count(
                    data, mobility_service_provider_ids
                )
                if sim_cards_to_optimize is None:
                    sim_cards_to_optimize = 0
                sim_cards_to_optimize = int(
                    sim_cards_to_optimize
                )  # Ensure conversion to standard int
            except Exception as e:
                logging.exception(f"### get_optimization_pop_up_data sim_cards_to_optimize : {e}")
                sim_cards_to_optimize = 0

            """Total Sim cards"""
            params = [ServiceProviderId]
            total_sim_cards_count_query = f"""
            SELECT
                count(*)
                FROM
                    Device_Tenant AS dt
                INNER JOIN
                    Device AS d ON dt.Device_id = d.id
                LEFT OUTER JOIN
                    customers AS s ON dt.customer_Id = s.id
                INNER JOIN
                    ServiceProvider sp ON d.Service_Provider_Id = sp.Id
                WHERE
                    (sp.Tenant_Id = {tenant_id} OR dt.Tenant_Id = {tenant_id})
                    AND dt.Is_Active = true
                    AND dt.Is_Deleted = false AND d.Service_Provider_Id =%s
            """
            # total_sim_cards_count_query = "SELECT count(*) FROM public.sim_management_inventory where service_provider_id=%s  and is_active=True"
            total_sim_cards_count = int(
                database.execute_query(total_sim_cards_count_query, params=params).iloc[
                    0, 0
                ]
            )  # Ensure conversion to standard int
            common_utils_database.update_dict(
                "optimization_pop_up_values",
                {
                    "rate_plan_count": rate_plan_count,
                    "sim_cards_to_optimize": sim_cards_to_optimize,
                    "total_sim_cards_count": total_sim_cards_count,
                    "status": "Success",
                },
                {"id": 1},
            )
            response = {
                "flag": True,
                "rate_plan_count": rate_plan_count,
                "sim_cards_to_optimize": sim_cards_to_optimize,
                "total_sim_cards_count": total_sim_cards_count,
            }
            try:
                # End time and audit logging
                end_time = time.time()
                time_consumed = f"{end_time - start_time:.4f}"
                time_consumed = int(float(time_consumed))
                audit_data_user_actions = {
                    "service_name": "get_optimization_pop_up_data",
                    "created_date": request_received_at,
                    "created_by": username,
                    "status": str(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "session_id": session_id,
                    "tenant_name": tenant_name,
                    "comments": "successfully fetched the optimization pop up  data",
                    "module_name": "Optimization",
                    "request_received_at": request_received_at,
                }
                common_utils_database.update_audit(
                    audit_data_user_actions, "audit_user_actions"
                )
            except Exception as e:
                logging.exception(f"### get_optimization_pop_up_data Failed to log the audit data: {e}")
            return response

    except Exception as e:
        logging.exception(f"### get_optimization_pop_up_data Error in connection or execution: {e}")
        error_type = str(type(e).__name__)
        message = f"Exception occurred while fetching the pop up data: {e}"
        # Error logging
        error_data = {
            "service_name": "get_optimization_pop_up_data",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": "Failed to get the  Optimization pop up data",
            "module_name": "Optimization",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "Failed to fetch the data"}


def start_optimization(data):
    """
    Initiates an optimization process by sending a POST request to the optimization API.
    
    Args:
        data (dict): Dictionary containing request parameters including body (optimization parameters),
                    template (email template), tenant_name, role_name, username, session_id,
                    and database connection info
                    
    Returns:
        dict: A dictionary containing:
            - flag (bool): Success status of the operation
            - status code (int): HTTP status code from the API response
            - message (dict): Response message from the optimization API
    """
    logging.info(f"### start_optimization Request Data Received : {data}")
    # Start time  and date calculation
    start_time = time.time()
    # Database connection
    tenant_database = data.get("db_name", "")
    try:
        database = DB(tenant_database, **db_config_withoutfilter)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {"error": "Database connection failed.", "details": str(db_exception)}
    template = data.get("template", "")
    request_received_at = data.get("request_received_at", "")
    role = data.get("role_name", "")
    body = data.get("body", {})
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    tenant_details = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id","parent_tenant_id"]
    )
    tenant_id = tenant_details["id"].to_list()[0]
    parent_tenant_id = tenant_details["parent_tenant_id"].to_list()[0]
    logging.info(f"parent_tenant_id=> {parent_tenant_id}")
    if parent_tenant_id and parent_tenant_id is not None:
        optimization_setting_table='optimization_setting_tenant_override'
    else:
        optimization_setting_table='optimization_setting'

    try:
        if body.get("optimizationType") == 1:
            optimization_mail = database.get_data(
                optimization_setting_table, {"tenant_id":tenant_id}, ["customer_optimization_to_email_address"]
            )["customer_optimization_to_email_address"].to_list()[0]
        else:
            optimization_mail = database.get_data(
                optimization_setting_table, {"tenant_id":tenant_id}, ["carrier_optimization_to_email_address"]
            )["carrier_optimization_to_email_address"].to_list()[0]
        common_utils_database.update_dict(
            "email_templates",
            {"body": template},
            {"template_name": "Start Optimization"},
        )
        try:
            common_utils_database.update_dict(
                "email_templates",
                {
                    "last_email_triggered_at": request_received_at,
                    "to_mail": optimization_mail,
                },
                {"template_name": "Start Optimization"},
            )
            # Call send_email and assign the result to 'result'
            result = send_email("Start Optimization", user_mail=optimization_mail)
            # Check the result and handle accordingly
            if isinstance(result, dict) and result.get("flag") is False:
                logging.info(f"### start_optimization : {result}")
            else:
                # Continue with other logic if needed
                (
                    to_emails,
                    cc_emails,
                    subject,
                    bodyy,
                    from_email,
                    partner_name,
                ) = result
                common_utils_database.update_dict(
                    "email_templates",
                    {"last_email_triggered_at": request_received_at},
                    {"template_name": "Start Optimization"},
                )
                query = """
                    SELECT parents_module_name, sub_module_name,
                        child_module_name, partner_name
                    FROM email_templates
                    WHERE template_name = %s
                """

                params = ["Start Optimization"]
                # Execute the query with template_name as the parameter
                email_template_data = common_utils_database.execute_query(
                    query, params=params
                )
                if not email_template_data.empty:
                    # Unpack the results
                    (
                        parents_module_name,
                        sub_module_name,
                        child_module_name,
                        partner_name,
                    ) = email_template_data.iloc[0]
                else:
                    # If no data is found, assign default values or log an error
                    parents_module_name = ""
                    sub_module_name = ""
                    child_module_name = ""
                    partner_name = ""

                try:
                    ##email audit
                    email_audit_data = {
                        "template_name": "Start Optimization",
                        "email_type": "Application",
                        "partner_name": partner_name,
                        "email_status": "success",
                        "from_email": from_email,
                        "to_email": to_emails,
                        "cc_email": cc_emails,
                        "comments": "update inventory data",
                        "subject": subject,
                        "body": bodyy,
                        "role": role,
                        "action": "Email triggered",
                        "parents_module_name": parents_module_name,
                        "sub_module_name": sub_module_name,
                        "child_module_name": child_module_name,
                    }
                    common_utils_database.update_audit(email_audit_data, "email_audit")
                except Exception as e:
                    logging.error(f"### start_optimization Failed to update the email audit table {e}")
        except Exception as e:
            logging.warning(f"### start_optimization Failed to send the email : {e}")
    except Exception as e:
        logging.warning(
            f"Failed to get the optimization data from settings and  failed to trigger the mail{e}"
        )
    try:
        body = data.get("body", {})
        logging.info(f"### start_optimization body of the start optimization is :{body}")
        # Check if optimizationType is 1, then replace the siteId as described
        if body.get("optimizationType") == 1 and body.get("siteId") != 0:
            site_id_from_params = body.get("siteId")
            # Database Connection to fetch rev_status
            # common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
            rev_status = True
            role_module_data = common_utils_database.get_data(
                                    "role_module",
                                    {"role": role},
                                    ["sub_module"],
                                )
            if not role_module_data.empty:
                try:
                    # Parse JSON safely with fallback
                    sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                    # Strict nested check
                    if "People" in sub_modules:
                        people_modules = sub_modules["People"]
                        if isinstance(people_modules, list):  # Ensure it's a list
                            rev_status = "Billing Platform Customers" in people_modules

                except json.JSONDecodeError:
                    logging.error(f"Invalid JSON in sub_module for role: {role}")
                except KeyError:
                    pass  # People section not present
                except Exception as e:
                    logging.error(f"Unexpected error processing modules: {str(e)}")  
            logging.info(f"rev_status is to check whether the rev is enabled or not{rev_status}")
            if rev_status:  # If Rev.IO module is active
                # Execute the queries to get the new siteId
                rev_io_query = """
                    SELECT id FROM public.integration
                    WHERE name='Rev.IO'
                """
                rev_io_id = database.execute_query(rev_io_query, True)["id"].to_list()[
                    0
                ]

                integration_authentication_id_query = f"""
                    SELECT id FROM public.integration_authentication
                    WHERE integration_id={rev_io_id} AND tenant_id={tenant_id} AND is_active=True
                """
                integration_authentication_id = database.execute_query(
                    integration_authentication_id_query, True
                )["id"].to_list()[0]

                site_id_query = f"""
                    SELECT c.id FROM public.revcustomer rc
                    JOIN customers c ON rc.id=c.rev_customer_id
                    WHERE rc.rev_customer_id='{site_id_from_params}'
                    AND rc.is_active=True AND rc.tenant_id={tenant_id}
                    AND rc.integration_authentication_id={integration_authentication_id}
                """
                siteId = database.execute_query(site_id_query, True)["id"].to_list()[0]

                # Replace the siteId in the body with the new value
                body["siteId"] = siteId
                logging.info(f"### start_optimization Updated siteId to {siteId}")

        # If siteId is 0, set it to 'null' as before
        if body["siteId"] == 0:
            body["siteId"] = None  # ✅ Already correct

        # Take the first item in the serviceProviderId list if it exists
        if (
            "serviceProviderId" in body
            and isinstance(body["serviceProviderId"], list)
            and body["serviceProviderId"]
        ):
            body["serviceProviderId"] = body["serviceProviderId"][0]

        ui_username = data.get("username", "") or data.get("user","")

        additional_data = {
            "BillingPeriodStartDate": data.get("billing_period_start_date", ""),
            "BillingPeriodEndDate": data.get("billing_period_end_date", ""),
            "DeviceCount": data.get("device_count", 0),
        }

        # Update the body with additional data
        body.update(additional_data)
        logging.info(f"### start_optimization body of the start optimization is :{body}")

        tenant_id = str(tenant_id)
        url = os.getenv("OPTIMIZATIONAPI", " ")
        username = os.getenv("ONEPOINTOOPTIMIZATIONUSERNAME", " ")
        password = os.getenv("ONEPOINTOOPTIMIZATIONPASSWORD", " ")
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode("utf-8")).decode(
            "utf-8"
        )
        authorization_header = f"Basic {encoded_credentials}"
        one_pointo_user = os.getenv("ONEPOINTOUSER", " ")
        # Define the headers
        headers = {
            "Authorization": authorization_header,
            "user-name": ui_username,
            "x-tenant-id": tenant_id,
            "Content-Type": "application/json",  # Specify content type for JSON
        }
        logging.info(f"### start_optimization headers of the start optimization is :{headers}")
        logging.info(f"### start_optimization body of the start optimization is :{body}")
        # Send the POST request
        response = requests.post(url, headers=headers, data=json.dumps(body))
        response_data = {
            "flag": True,
            "status code": response.status_code,
            "message": response.json(),
        }
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "start_optimization",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response_data["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": f"Optimization Run started for type {body.get('optimizationType')} with siteId {body.get('siteId')}",
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### start_optimization Exception is {e}")

        # Return the status code and response JSON
        return response_data

    except Exception as e:
        logging.exception(f"### start_optimization Error fetching data: {e}")
        message = f"exception is {e}"
        response_data = {"flag": False, "message": message}
        error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "start_optimization",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Failed to Start the Optimization data of type {body.get('optimizationType')} with siteId {body.get('siteId')}",
            "module_name": "Optimization",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        # Return the status code and response JSON
        return response_data


##second point
def get_optimization_row_details(data):
    """
    Retrieves and paginates optimization data for a given session, including high-usage customers and errors.
    
    Args:
        data (dict): Dictionary containing request parameters including session_id, optimization_type,
                    fetch_type (high_usage, error_details, or both), pagination parameters (start, end),
                    col_sort (sorting options), and database connection info
                    
    Returns:
        dict: A dictionary containing:
            - flag (bool): Success status of the operation
            - pages (dict): Pagination information including total counts
            - instance_ids (list): List of instance IDs
            - high_usage_customers_data (list, optional): List of high usage customer records
            - error_details (list, optional): List of error records
            - error_message (str, optional): Error message if operation fails
    """
    logging.info(f"### get_optimization_row_details Request Recieved : {data}")
    
    # Record the start time for performance measurement
    start_time = time.time()
    session_id = data.get("session_id")
    # Database connection
    tenant_database = data.get("db_name", "")
    col_sort = data.get("col_sort", "")
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    except Exception as db_exception:
        logging.error(F"### get_optimization_row_details Failed to connect to the database: {str(db_exception)}")
        return {"error": "Database connection failed.", "details": str(db_exception)}
    try:
        #del db_config['customers']
        del db_config['service_providers']
    except Exception as e:
        logging.exception(f"### get_optimization_row_details Failed to delete the db_config : {e}")
    #databasewithoutfilter = DB(tenant_database, **db_config_withoutfilter)
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    # Pagination parameters
    start = data.get("start", 0)
    end = data.get("end", 10)  # Default to 10 if no end parameter provided
    limit = 10
    params = [start, limit]
    errors_params=[limit,start]
    pages = {"start": start, "end": end}
    total_count = 0
    error_details_count = 0
    high_usage_customers_data = []
    error_details = []
    optimization_type = data.get("optimization_type", "")
    if optimization_type == "Customer":
        error_view = "vw_optimization_error_details_customer"
    else:
        error_view = "vw_optimization_error_details_carrier"

    try:
        count_params = [session_id]
        # Query to get instance IDs
        try:
            instance_ids_query = f"""
                SELECT instance_id
                FROM
                    public.vw_optimization_high_usage_customers
                WHERE
                    session_id = '{session_id}'
            """
            instance_ids = database.execute_query(instance_ids_query, True)[
                "instance_id"
            ].to_list()
        except Exception as e:
            instance_ids = (
                []
            )  # If the instance IDs query fails, we'll set it to an empty list
            logging.exception(f"### get_optimization_row_details Exception is: {e}")

        # Check if we're fetching high usage customers, error details, or both
        fetch_type = data.get("fetch_type", "both")  # Default to 'both'

        if fetch_type == "both" or fetch_type == "high_usage":
            # Count query to get total count of high usage customers
            count_query = f"""
                SELECT COUNT(customer_name)
                FROM public.vw_optimization_high_usage_customers
                WHERE  session_id = '{session_id}'
            """

            total_count = database.execute_query(count_query, count_params).iloc[0, 0]
            if col_sort:
                # Query for high usage customers
                query = f"""
                    SELECT instance_id,
                    customer_name,rev_customer_id,TO_CHAR(sms_charge_total, 'FM999,999,999,999.00') AS sms_charge_total,
                    device_count,
                    TO_CHAR(total_charges, 'FM$999,999,999,999.00') AS total_charges,
                    TO_CHAR(total_charge_amount, 'FM$999,999,999,999.00') AS total_charge_amount
                FROM
                    public.vw_optimization_high_usage_customers
                WHERE
                    session_id = '{session_id}'
                    OFFSET %s LIMIT %s;
                """
                # Extract the single key-value pair for sorting
                key, value = list(col_sort.items())[0]
                if key == "run_start_time":
                    key = "optimization_run_start_date"

                # Handle special sorting for 'billing_period_duration'
                if key == "billing_period_duration":
                    # Determine the sorting direction (ASC/DESC)
                    sort_direction = value.upper()

                    # Define the complex ORDER BY clause for billing_period_duration
                    custom_order_by = (
                        f"GREATEST(billing_period_start_date, billing_period_end_date) {sort_direction} NULLS LAST, "
                        f"LEAST(billing_period_start_date, billing_period_end_date) {sort_direction} NULLS LAST, "
                        f"id ASC"
                    )
                if key in ("total_charges", "total_charge_amount", "rev_customer_id"):
                    custom_order_by = f"{key}::NUMERIC {value.upper()}  NULLS LAST"
                    logging.info(f"### get_optimization_row_details custom_order_by : {custom_order_by}")
                else:
                    # Default single-column ORDER BY clause
                    custom_order_by = f"{key} {value.upper()}  NULLS LAST"

                # Remove any existing ORDER BY clause
                order_by_pattern = (
                    r"\sORDER\s+BY\s+[^\s]+(\sASC|\sDESC)?(?=\s+(OFFSET|LIMIT))"
                )
                query = re.sub(order_by_pattern, "", query, flags=re.IGNORECASE)

                # Insert the new ORDER BY clause before OFFSET and LIMIT
                limit_offset_pattern = (
                    r"(OFFSET\s+%s\s+LIMIT\s+%s;)"  # Captures OFFSET and LIMIT
                )
                query = re.sub(
                    limit_offset_pattern,
                    f"ORDER BY {custom_order_by} \\1",
                    query,
                    flags=re.IGNORECASE,
                )
            else:
                # Query for high usage customers
                query = f"""
                    SELECT instance_id,
                    customer_name,rev_customer_id,TO_CHAR(sms_charge_total, 'FM999,999,999,999.00') AS sms_charge_total,
                    device_count,
                    TO_CHAR(total_charges, 'FM$999,999,999,999.00') AS total_charges,
                    TO_CHAR(total_charge_amount, 'FM$999,999,999,999.00') AS total_charge_amount
                FROM
                    public.vw_optimization_high_usage_customers
                WHERE
                    session_id = '{session_id}'
                ORDER BY CAST(total_charge_amount AS NUMERIC) DESC NULLS LAST, instance_id DESC
                    OFFSET %s LIMIT %s;
                """

            high_usage_customers_data = database.execute_query(
                query, params=params
            ).to_dict(orient="records")

            # Add total count to the pages dictionary for pagination
            pages["high_usage_total"] = int(total_count)

        if fetch_type == "both" or fetch_type == "error_details":
            # Count query to get total count of error details
            error_details_count_query = f"""
                select count(*) from {error_view} where session_id='{session_id}' 

            """

            error_details_count = database.execute_query(
                error_details_count_query, True
            ).iloc[0, 0]
            if col_sort:
                # Query for high usage customers
                # Error details query
                error_details_query = f"""
                    select rev_customer_id,iccid,msisdn,customer_name,
                    error_message from {error_view} where session_id='{session_id}' 
                     limit %s offset %s
                """
                # Extract the single key-value pair for sorting
                key, value = list(col_sort.items())[0]
                if key == "run_start_time":
                    key = "optimization_run_start_date"

                # Handle special sorting for 'billing_period_duration'
                if key == "billing_period_duration":
                    # Determine the sorting direction (ASC/DESC)
                    sort_direction = value.upper()

                    # Define the complex ORDER BY clause for billing_period_duration
                    custom_order_by = (
                        f"GREATEST(billing_period_start_date, billing_period_end_date) {sort_direction} NULLS LAST, "
                        f"LEAST(billing_period_start_date, billing_period_end_date) {sort_direction} NULLS LAST, "
                        f"id ASC"
                    )
                if key in ("total_charges", "total_charge_amount", "rev_customer_id"):
                    custom_order_by = f"{key}::NUMERIC {value.upper()} NULLS LAST"
                else:
                    # Default single-column ORDER BY clause
                    custom_order_by = f"{key} {value.upper()} NULLS LAST"

                # Remove any existing ORDER BY clause
                order_by_pattern = (
                    r"\sORDER\s+BY\s+[^\s]+(\sASC|\sDESC)?(?=\s+(OFFSET|LIMIT))"
                )
                error_details_query = re.sub(
                    order_by_pattern, "", error_details_query, flags=re.IGNORECASE
                )

                # Insert the new ORDER BY clause before OFFSET and LIMIT
                limit_offset_pattern = (
                    r"(OFFSET\s+%s\s+LIMIT\s+%s;)"  # Captures OFFSET and LIMIT
                )
                error_details_query = re.sub(
                    limit_offset_pattern,
                    f"ORDER BY {custom_order_by} \\1",
                    error_details_query,
                    flags=re.IGNORECASE,
                )
            else:
                # Error details query
                error_details_query = f"""
                    select rev_customer_id,iccid,msisdn,customer_name,
                    error_message from {error_view} where session_id='{session_id}' 
                     limit %s offset %s
                """

            error_details = database.execute_query(
                error_details_query, params=errors_params
            ).to_dict(orient="records")

            # Add total count to the pages dictionary for pagination
            pages["error_details_total"] = int(error_details_count)

        # Build response
        response = {"flag": True, "pages": pages, "instance_ids": instance_ids}

        if fetch_type == "both" or fetch_type == "high_usage":
            response["high_usage_customers_data"] = high_usage_customers_data
        if fetch_type == "both" or fetch_type == "error_details":
            response["error_details"] = error_details

        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "get_optimization_row_details",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"successfully fetched the optimization details of type : {optimization_type}",
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"### get_optimization_row_details Exception while fechting the row details : {e}")
        return response

    except Exception as e:
        # Handle any exceptions and provide default empty data
        response = {
            "flag": False,
            "high_usage_customers_data": [],
            "error_details": [],
            "pages": pages,
            "instance_ids": [],
            "error_message": str(e),
        }
        error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "get_optimization_row_details",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": f"Failed to get the  Optimization list view data : {optimization_type}",
            "module_name": "Optimization",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return response

def generate_report_to_excel(
    report_name, query, database, optimization_type, session_id, tenant_name
):
    """
    Executes a database query and generates formatted Excel data for various report types.
    
    Args:
        report_name (str): The name of the report to generate
        query (str): SQL query to execute to get the report data
        database (DB): Database connection object
        optimization_type (str): Type of optimization ("Customer" or "Carrier")
        session_id (str): Session ID for the optimization run
        tenant_name (str): Name of the tenant
        
    Returns:
        bytes: Excel file content as bytes
    """
    logging.info("generate_report_to_excel")
    acronyms = {
        "SMS",
        "IMEI",
        "IP",
        "BAN",
        "URL",
        "UID",
        "MAC",
        "EID",
        "MSISDN",
        "MB",
        "CCID",
        "ICCID",
        "SIM",
    }
    special_replacements = {"Att": "AT&T", "And": "and", "mb": "MB"}
    # Execute the main query to fetch data
    df = database.execute_query(query, True)
    df.columns = [
        " ".join(
            part.upper() if part.upper() in acronyms else part.capitalize()
            for part in col.replace("_", " ").split(
                " "
            )  # Replace underscores and split
        )
        for col in df.columns
    ]

    # Apply any special replacements
    df.columns = [
        " ".join([special_replacements.get(word, word) for word in col.split(" ")])
        for col in df.columns
    ]

    # Handle NaN values, numeric types, and date formatting
    def format_value(val):
        if pd.isna(val):
            return ""  # Replace NaN with empty string
        if isinstance(val, (int, float)):
            return val  # Numeric values should remain as numeric types
        if isinstance(val, pd.Timestamp):
            return val.strftime(
                "%Y-%m-%d %H:%M:%S"
            )  # Format date columns as YYYY-MM-DD
        return str(val)  # For all other values, convert to string

    # Apply formatting to all values in the dataframe
    df = df.applymap(format_value)

    # Function to truncate to two decimals
    def truncate_to_two_decimals(value):
        try:
            # Remove commas, convert to float, truncate to 2 decimals
            value = float(str(value).replace(",", ""))
            return f"{int(value * 100) / 100:.2f}"
        except (ValueError, TypeError):
            return "0.00"  # Default for invalid entries

    # Check if the DataFrame is empty
    if df.empty:
        excel_buffer = io.BytesIO()
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            empty_df = pd.DataFrame(columns=df.columns)
            empty_df.to_excel(writer, index=False, sheet_name="Empty Report")
        return excel_buffer.getvalue()
    logging.info(f"### generate_report_to_excel Report Name: {report_name}")
    # Handle specific reports
    if (
        report_name == "Device Assignments By Customer Report"
        and optimization_type == "Customer"
    ):
        binary_query = """
            SELECT r.results_id, r.customer_name, r.rev_customer_id as customer_account_number, f.assignment_xlsx_bytes
            FROM public.vw_optimization_instance r
            JOIN optimization_instance_result_file f ON r.results_id = f.id
            WHERE r.session_id = %s
        """
        try:
            customers=db_config['customers']
           
            if customers:
                binary_query = f"""
                        SELECT r.results_id, r.customer_name, r.rev_customer_id as customer_account_number, f.assignment_xlsx_bytes
                        FROM public.vw_optimization_instance r
                        JOIN optimization_instance_result_file f ON r.results_id = f.id
                        WHERE r.session_id = %s and customer_name IN {customers}
                    """
        except Exception as e:
            logging.exception(f"### generate_report_to_excel Exception occurred while fetching the customer names: {e}")

        params = [session_id]
        customer_report_data = database.execute_query(binary_query, params=params)

        excel_buffer = io.BytesIO()

        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            sheet_created = False  # Track if at least one sheet is created

            # Iterate through customer report data
            for _, row in customer_report_data.iterrows():
                assignment_xlsx_binary = row["assignment_xlsx_bytes"]
                customer_name = row["customer_name"]
                customer_account_number = row["customer_account_number"]

                if assignment_xlsx_binary:
                    assignment_file = io.BytesIO(assignment_xlsx_binary)
                    assignment_df = pd.read_excel(assignment_file, dtype={'ICCID': str})
                    assignment_df = assignment_df.loc[
                        :, ~assignment_df.columns.str.contains("^Unnamed")
                    ]
                    assignment_df.columns = assignment_df.columns.str.replace(
                        r"\.\d+$", "", regex=True
                    )
                    # Clean up column names
                    assignment_df.columns = (
                        assignment_df.columns.str.strip()
                        .str.lower()
                        .str.replace(" ", "_")
                    )
                    df.columns = (
                        df.columns.str.strip().str.lower().str.replace(" ", "_")
                    )
                    try:
                        try:
                            assignment_df["iccid"] = assignment_df["iccid"].apply(lambda x: str(x) if pd.notna(x) else x)
                            df["iccid"] = df["iccid"].apply(lambda x: str(x) if pd.notna(x) else x)
                        except Exception as e:
                            logging.exception(f"### generate_report_to_excel occurd while conveting the iccids{e}")
                        # Define columns to merge
                        columns_to_merge = ["iccid", "usage_cost"]

                        # Merge assignment_df with df on 'iccid' and 'usage_cost'
                        assignment_df = assignment_df.merge(
                            df[columns_to_merge],
                            on="iccid",
                            how="left",
                            suffixes=(
                                "",
                                "_y",
                            ),  # Add suffix to avoid column name clashes
                        )

                        # Drop any duplicate columns that may have been created during the merge
                        assignment_df = assignment_df.loc[
                            :, ~assignment_df.columns.str.endswith("_y")
                        ]

                        # Check if 'usage_cost' exists and handle accordingly
                        if "usage_cost" in assignment_df.columns:
                            # Convert 'Usage Cost' to numeric and apply formatting
                            assignment_df["usage_cost"] = (
                                assignment_df["usage_cost"]
                                .replace(r"[$,]", "", regex=True)
                                .astype(float)
                            )
                        ##commentiing this for now
                        # assignment_df = assignment_df.drop_duplicates(
                        #     subset=["iccid"], keep="first"
                        # )
                        part1 = assignment_df.iloc[
                            :, :6
                        ]  # Columns before the 12th position
                        # part1 = part1.drop_duplicates(
                        #     subset=["iccid"], keep="first"
                        # )
                        part2 = assignment_df.iloc[
                            :, 6:
                        ]  # Columns after the 12th position
                        # Drop 'Usage Cost' column only if it exists
                        if "usage_cost" in part2.columns:
                            part2 = part2.drop(columns=["usage_cost"])

                        # Concatenate the parts together with 'Usage Cost' in the middle
                        assignment_df = pd.concat(
                            [part1, assignment_df[["usage_cost"]], part2], axis=1
                        )
                        # assignment_df["Usage Cost"] = assignment_df["usage_cost"].apply(lambda x: f"${x:.2f}" if not pd.isnull(x) else "$.00")
                        # Apply truncation and formatting to float columns (if any)
                    except Exception as e:
                        logging.exception(f"### generate_report_to_excel Error in merging dataframes: {e}")
                    columns_to_format = [
                        "usage_cost",
                        "cycle_data_usage(mb)",
                        "average_usage(mb)",
                        "average_cost",
                        "total_usage",
                        "total_cost",
                    ]
                    for col in columns_to_format:
                        if col in assignment_df.columns:
                            # Apply truncation only to rows with valid numeric values
                            assignment_df[col] = assignment_df[col].apply(
                                lambda x: (
                                    truncate_to_two_decimals(x)
                                    if isinstance(x, (int, float)) and not pd.isna(x)
                                    else x
                                )
                            )

                    # Apply formatting to all values in the dataframe
                    assignment_df = assignment_df.applymap(
                        lambda val: (
                            format_value(val)
                            if not isinstance(val, (int, float))
                            else val
                        )
                    )

                    # assignment_df = assignment_df.applymap(lambda val: format_value(val) if not isinstance(val, (int, float)) else val)
                    # Format column names
                    assignment_df.columns = [
                        " ".join(
                            (
                                part.upper()
                                if part.upper() in acronyms
                                else part.capitalize()
                            )
                            for part in col.replace("_", " ").split(
                                " "
                            )  # Replace underscores and split
                        )
                        for col in assignment_df.columns
                    ]

                    # Apply any special replacements
                    assignment_df.columns = [
                        " ".join(
                            [
                                special_replacements.get(word, word)
                                for word in col.split(" ")
                            ]
                        )
                        for col in assignment_df.columns
                    ]
                    # Replace NaN with empty strings immediately after reading
                    assignment_df = assignment_df.applymap(format_value)
                    # Specify the index of the column to format (5th column has index 4 in zero-based indexing)

                    # Add customer-specific columns
                    assignment_df.insert(0, "Customer Name", customer_name)
                    assignment_df.insert(
                        1, "Customer Account Number", customer_account_number
                    )

                    # Adjust the DataFrame to show 'Customer Name' and 'Customer Account Number' only once per group
                    assignment_df.loc[1:, "Customer Name"] = ""
                    assignment_df.loc[1:, "Customer Account Number"] = ""
                    try:
                        # Split the DataFrame into two parts: before and after the 12th column (index 11)
                        part1 = assignment_df.iloc[
                            :, :6
                        ]  # Columns before the 12th position
                        part2 = assignment_df.iloc[
                            :, 6:
                        ]  # Columns after the 12th position
                        # Drop 'Usage Cost' column only if it exists
                        if "Usage Cost" in part2.columns:
                            part2 = part2.drop(columns=["Usage Cost"])

                        # Concatenate the parts together with 'Usage Cost' in the middle
                        assignment_df = pd.concat(
                            [part1, assignment_df[["Usage Cost"]], part2], axis=1
                        )
                    except Exception as e:
                        logging.exception(f"### generate_report_to_excel Error in splitting DataFrame: {e}")

                    # if "Cycle Data Usage(mb)" in assignment_df.columns:
                    #     # Apply truncation only to rows with valid numeric values
                    #     assignment_df["Cycle Data Usage(mb)"] = (
                    #         assignment_df["Cycle Data Usage(mb)"]
                    #         .replace({",": ""}, regex=True)  # Remove commas if present
                    #         .replace(
                    #             {"": None}
                    #         )  # Replace empty strings with None (which will become NaN)
                    #         .astype(float)  # Convert to float
                    #         .apply(
                    #             lambda x: int(x * 100) / 100.0 if pd.notna(x) else x
                    #         )  # Truncate to 2 decimal places
                    #         .apply(
                    #             lambda x: f"{x:.2f}" if pd.notna(x) else x
                    #         )  # Format as string with 2 decimals (e.g., '0.00')
                    #     )
                    if "Usage Cost" in assignment_df.columns:
                        # Add $ symbol to numeric values
                        assignment_df["Usage Cost"] = assignment_df["Usage Cost"].apply(
                            lambda x: (
                                f"${x}" if str(x).replace(".", "", 1).isdigit() else x
                            )
                        )
                    # Use a sanitized sheet name
                    # sanitized_sheet_name = sanitize_sheet_name(
                    #     customer_name.replace("_", " ") if customer_name else ""
                    # )
                    trimmed_customer_name = (customer_name or 'Unknown')[:22].strip()
                    # Build the sheet name
                    sheet_name = f"{trimmed_customer_name}_{customer_account_number or ''}".strip()
                    sanitized_sheet_name = sanitize_sheet_name(sheet_name)

                    # Write to the Excel workbook
                    # Step 1: Drop duplicates
                    deduplicated_df = assignment_df.drop_duplicates()

                    # Step 2: Check if duplicates were removed
                    if len(deduplicated_df) < len(assignment_df):
                        # If duplicates were removed, drop the second row
                        deduplicated_df = deduplicated_df.drop(
                            index=deduplicated_df.index[1]
                        )

                    # Assign the result back to the original DataFrame or use it further
                    assignment_df = (
                        deduplicated_df
                        if len(deduplicated_df) < len(assignment_df)
                        else assignment_df
                    )
                    assignment_df['ICCID'] = assignment_df['ICCID'].astype(str)
                    assignment_df.to_excel(
                        writer, index=False, sheet_name=sanitized_sheet_name
                    )
                    sheet_created = True  # Mark that a sheet has been created

            if not sheet_created:
                # Ensure at least one sheet is visible
                empty_df = pd.DataFrame(columns=["No Data"])
                empty_df.to_excel(writer, index=False, sheet_name="Empty Report")

            # Apply formatting to all sheets
            workbook = writer.book
            for sheet_name in workbook.sheetnames:
                sheet = workbook[sheet_name]

                # Adjust column widths
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = (
                        max_length + 2
                    )

                # Ensure consistent number formatting
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    for cell in col_cells:
                        if isinstance(cell.value, (int, float)):
                            cell.number_format = (
                                "0"  # Format as an integer without decimal points
                            )
                        elif isinstance(cell.value, float):
                            cell.number_format = (
                                "0.00"  # Format as float with 2 decimal places
                            )

                # Format header row
                for cell in sheet[1]:
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(
                        start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                    )
                    cell.font = Font(bold=True)

            # Reorder sheets by name in ascending order
            workbook._sheets.sort(key=lambda ws: ws.title)

            # Reorder sheets by name in ascending order
            workbook._sheets.sort(key=lambda ws: ws.title)

        return excel_buffer.getvalue()
    
    elif report_name == "Device Assignments" and optimization_type == "Carrier":
        carrier_query = """
            SELECT r.results_id, r.customer_name, r.rev_customer_id as customer_account_number, f.assignment_xlsx_bytes
            FROM public.vw_optimization_instance r
            JOIN optimization_instance_result_file f ON r.results_id = f.id
            WHERE r.session_id = %s
        """
        params = [session_id]
        carrier_data = database.execute_query(carrier_query, params=params)

        # Create an Excel buffer
        excel_buffer = io.BytesIO()

        # Check if the query returned any data
        if carrier_data.empty:
            # If no data is available, add a "No Data Available" sheet
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                empty_df = pd.DataFrame(columns=["No Data Available"])
                empty_df.to_excel(writer, index=False, sheet_name="Carrier Report")
            return excel_buffer.getvalue()

        # Process the first row, assuming a single result
        row = carrier_data.iloc[0]
        assignment_xlsx_binary = row.get("assignment_xlsx_bytes")

        if pd.isna(assignment_xlsx_binary) or not assignment_xlsx_binary:
            # If no valid Excel data exists, add a "No Data Available" sheet
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                empty_df = pd.DataFrame(columns=["No Data Available"])
                empty_df.to_excel(writer, index=False, sheet_name="Carrier Report")
            return excel_buffer.getvalue()

        # Process the Excel binary data
        assignment_file = io.BytesIO(assignment_xlsx_binary)
        try:
            assignment_df = pd.read_excel(assignment_file, dtype={'ICCID': str})
            logging.info(f"Number of rows in carrier report are {len(assignment_df)} ")
        except Exception as e:
            logging.exception(f"### generate_report_to_excel Error reading Excel file: {e}")
            # Handle errors reading the Excel file
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                empty_df = pd.DataFrame(columns=["Error Reading Data"])
                empty_df.to_excel(writer, index=False, sheet_name="Carrier Report")
            return excel_buffer.getvalue()

        # Clean and format the DataFrame
        assignment_df = assignment_df.loc[
            :, ~assignment_df.columns.str.contains("^Unnamed")
        ]
        assignment_df.columns = assignment_df.columns.str.replace(
            r"\.\d+$", "", regex=True
        )
        assignment_df.columns = [
            " ".join(
                part.upper() if part.upper() in acronyms else part.capitalize()
                for part in col.replace("_", " ").split(
                    " "
                )  # Replace underscores and split
            )
            for col in assignment_df.columns
        ]

        # Apply any special replacements
        assignment_df.columns = [
            " ".join([special_replacements.get(word, word) for word in col.split(" ")])
            for col in assignment_df.columns
        ]
        assignment_df.columns = [
            col.replace(" mb", " (MB)").replace(" Mb", " (MB)")
            for col in assignment_df.columns
        ]
        assignment_df = assignment_df.map(format_value)  # Updated to use `map`
        columns_to_format = [
            "Cycle Data Usage(mb)",
            "Average Usage(mb)",
            "Total Usage",
            "Total Cost",
        ]
        # Apply truncation to specified columns
        for col in columns_to_format:
            assignment_df[col] = assignment_df[col].apply(truncate_to_two_decimals)
        # Split the DataFrame at the 13th column (index 12)
        df1 = assignment_df.iloc[:, :11]  # Columns from 0 to 12 (13th column)
        df2 = assignment_df.iloc[:, 11:]  # Columns from 13 to the end
        subtotal_index = df2[
            df2["Rate Plan"].str.contains("Sub-Total", case=False, na=False)
        ].index

        if not subtotal_index.empty:
            subtotal_index = subtotal_index[0]  # Get the first "Sub-Total" row index

            # Remove all rows after the "Sub-Total" row (including the "Sub-Total" row)
            df2 = df2.iloc[: subtotal_index + 1]

            # Replace the "Sub-Total" row with "Grand Total"
            df2.at[subtotal_index, "Rate Plan"] = "Total"
        assignment_df = pd.concat([df1, df2], axis=1)
        # Write the cleaned data to Excel
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            assignment_df.to_excel(writer, index=False, sheet_name="Carrier Report")

            # Format the workbook
            workbook = writer.book
            sheet = workbook.active

            # Format header row
            for cell in sheet[1]:
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.fill = PatternFill(
                    start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                )
                cell.font = Font(bold=True)
            # Ensure consistent number formatting (e.g., remove unnecessary decimal points for whole numbers)
            for col_idx, col_cells in enumerate(sheet.columns, 1):
                for cell in col_cells:
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = (
                            "0"  # Format as an integer without decimal points
                        )
                    elif isinstance(cell.value, float):
                        cell.number_format = (
                            "0.00"  # Format as float with 2 decimal places
                        )

            # Adjust column widths
            for col_idx, col_cells in enumerate(sheet.columns, 1):
                max_length = max(len(str(cell.value or "")) for cell in col_cells)
                sheet.column_dimensions[get_column_letter(col_idx)].width = (
                    max_length + 2
                )

        return excel_buffer.getvalue()
    else:
        # Handle general reports
        excel_buffer = io.BytesIO()
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            # Convert all values to string before writing, while handling NaN, numeric and date
            df = df.applymap(format_value)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
            if tenant_name=='Altaworx Test':
                tenant_name='Altaworx'
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            if tenant_id:
                tenant_id=int(tenant_id)
            cross_carrier_optimization = database.get_data(
                "optimization_setting",
                {"tenant_id":tenant_id},
                ["optino_cross_providercustomer_optimization"],
            )["optino_cross_providercustomer_optimization"].to_list()[0]
            if not cross_carrier_optimization:
                if "Customer Pool" in df.columns:
                    df = df.drop(columns=["Customer Pool"])
            if (
                report_name == "Session Device Assignments Report"
                and optimization_type == "Customer"
            ):
                df.to_excel(writer, index=False, sheet_name="Session Device Assignment")
            elif (
                report_name == "Customer Charge Breakdown Report"
                and optimization_type == "Customer"
            ):
                df.to_excel(writer, index=False, sheet_name="Customer Charge Breakdown")
            else:
                df.to_excel(writer, index=False, sheet_name=report_name)
            workbook = writer.book
            sheet = workbook.active

            for cell in sheet[1]:  # Format header row
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.fill = PatternFill(
                    start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                )
                cell.font = Font(bold=True)

            for col_idx, col_cells in enumerate(
                sheet.columns, 1
            ):  # Adjust column widths
                max_length = max(len(str(cell.value or "")) for cell in col_cells)
                sheet.column_dimensions[get_column_letter(col_idx)].width = (
                    max_length + 2
                )

            # Ensure consistent number formatting (e.g., remove unnecessary decimal points for whole numbers)
            for col_idx, col_cells in enumerate(sheet.columns, 1):
                for cell in col_cells:
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = (
                            "0"  # Format as an integer without decimal points
                        )
                    elif isinstance(cell.value, float):
                        cell.number_format = (
                            "0.00"  # Format as float with 2 decimal places
                        )

        return excel_buffer.getvalue()


##Helper function to sanitize the sheet
def sanitize_sheet_name(name):
    """
    Sanitize sheet name to remove invalid characters and enforce length limit.
    
    Args:
        name (str): The original sheet name to sanitize
        
    Returns:
        str: A sanitized sheet name that is valid for Excel (no invalid characters, max 31 chars)
    """
    if not name:  # Check for None or empty string
        return "Untitled_Sheet"  # Or any default value you'd prefer
    """Sanitize sheet name to remove invalid characters and enforce length limit."""
    invalid_chars = [
        "/",
        "\\",
        "?",
        "*",
        "[",
        "]",
        ":",
        "#",
    ]  # Adding '#' to invalid chars if needed
    # Replace invalid characters with underscore
    for char in invalid_chars:
        name = name.replace(char, "_")
    # Ensure sheet name doesn't exceed 31 characters
    name = name[:31]
    # Replace spaces with underscores for consistency
    name = name.replace(" ", "_")
    # Optionally remove any other unwanted characters
    name = "".join(e for e in name if e.isalnum() or e == "_")
    # If the name becomes empty after sanitizing, use a default name
    if not name:
        name = "Untitled_Sheet"
    return name


##get optimization details rpeorts data
def get_optimization_details_reports_data(data):
    """
    Generates various optimization-related reports and packages them into a downloadable ZIP file.
    
    Args:
        data (dict): Dictionary containing request parameters including report_type (specific report or "All Reports"),
                    session_id, optimization_type ("Customer" or "Carrier"), pushed_charges (bool),
                    errors (bool), tenant_name, username, and database connection info
                    
    Returns:
        dict: A dictionary containing:
            - flag (bool): Success status of the operation
            - file_url (str): S3 URL to download the generated ZIP file with reports
            - message (str, optional): Error message if operation fails
    """
    logging.info(f"### get_optimization_details_reports_data Request Data Received : {data}")
    ##start time for performance measurement
    start_time = time.time()
    report_type = data.get("report_type")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    session_id = data.get("session_id")
    optimization_type = data.get("optimization_type")
    tenant_database = data.get("db_name", "")
    # Normalize pushed_charges and errors to boolean values
    pushed_charges = (
        data.get("pushed_charges", "").lower() == "true"
        if isinstance(data.get("pushed_charges"), str)
        else bool(data.get("pushed_charges"))
    )
    errors = (
        data.get("errors", "").lower() == "true"
        if isinstance(data.get("errors"), str)
        else bool(data.get("errors"))
    )
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        # Remove unnecessary keys from db_config
        for key in [
            "customer_rate_plan_name",
        ]:
            if key in db_config:
                del db_config[key]

    except Exception as e:
        logging.exception(f"### get_optimization_details_reports_data Exception while removing variables of db config : {e}")

    # Database Connection
    database = DB(tenant_database, **db_config)
    db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": optimization_type},
    )
    # Queries for different report types
    if optimization_type == "Customer":
        logging.info(f"Customer flow")
        # Define the queries and their respective report types
        queries = {
            "optimization_summary_report": f"""
                SELECT session_id,
                       service_provider,
                       run_start_time,
                       run_end_time,
                       device_count,
                       TO_CHAR(ROUND(total_cost, 2), 'FM$999,999,999,999.00') AS total_charges,
                       TO_CHAR(ROUND(total_charge_amount, 2), 'FM$999,999,999,999.00') AS charges_pushing_from_amop,
                       rev_customer_id,
                       customer_name,
                       billing_period_start_date,
                       billing_period_end_date,
                       run_status
                FROM public.vw_optimization_instance_summary
                WHERE session_id = '{session_id}' AND run_status='Complete with Success'
                AND total_charge_amount is not null
            """,
            "device_assignments_by_customer_report": f"""
                SELECT customer_name,
                    iccid,service_provider,
                    customer_pool,
                    carrier_rate_plan,
                    cycle_data_usage_mb,
                    TO_CHAR(usage_cost, 'FM$999,999,999,999.00') AS usage_cost,
                    communication_plan,
                    msisdn,
                    uses_proration,
                    date_activated,
                    EXTRACT(DAY FROM (billing_period_end_date - billing_period_start_date))
                    AS billing_period_duration,
                    days_activated_in_billing_period,
                    EXTRACT(DAY FROM (days_in_billing_period)) AS days_in_billing_period,
                    device_count,
                    average_cost,
                    TO_CHAR(total_cost, 'FM$999,999,999,999.00') AS total_cost
                FROM public.vw_optimization_export_device_assignments
                WHERE session_id = '{session_id}'
            """,
            "session_device_assignments_report": f"""
                SELECT customer_name,rev_customer_id as customer_account_number,
                    iccid,service_provider,
                    customer_pool,
                    carrier_rate_plan,
                    TO_CHAR(TRUNC(cycle_data_usage_mb, 2), 'FM999,999,999,999.00') AS cycle_data_usage_mb,
                    TO_CHAR(ROUND(usage_cost, 2), 'FM$999,999,999,999.00') AS usage_cost,
                    communication_plan,
                    msisdn,
                    uses_proration,
                    date_activated,
                    EXTRACT(DAY FROM (billing_period_end_date - billing_period_start_date))
                    AS billing_period_duration,
                    days_activated_in_billing_period,
                    EXTRACT(DAY FROM (days_in_billing_period)) AS days_in_billing_period
                FROM public.vw_optimization_export_device_assignments
                WHERE session_id = '{session_id}'
            """,
            "customer_charge_breakdown_report": f"""
                SELECT
                    rev_account_number,
                    customer_name,
                    EXTRACT(DAY FROM (billing_period_end_date - billing_period_start_date))
                    AS billing_period_duration,
                    billing_period_end_date,
                    billing_period_start_date,
                    TO_CHAR(ROUND(usage_mb, 2), 'FM999,999,999,999.00') AS usage_mb,
                    TO_CHAR(ROUND(base_charge_amount, 2), 'FM$999,999,999,999.00') AS base_charge_amount,
                    TO_CHAR(ROUND(rate_charge_amt, 2), 'FM$999,999,999,999.00') AS rate_charge_amt,
                    TO_CHAR(ROUND(overage_charge_amount, 2), 'FM$999,999,999,999.00') AS overage_charge_amount,
                    TO_CHAR(ROUND(total_charges_pushed, 2), 'FM$999,999,999,999.00') AS total_charges_pushed,
                    TO_CHAR(ROUND(base_charge_amount + rate_charge_amt + overage_charge_amount, 2), 'FM$999,999,999,999.00') AS total_data_charge_amount,
                    is_processed,
                    error_message,
                    iccid,
                    msisdn,
                    TO_CHAR(ROUND(sms_usage, 2), 'FM999,999,999,999.00') AS sms_usage,

                    TO_CHAR(ROUND(sms_charge_amount, 2), 'FM$999,999,999,999.00') AS sms_charge_amount,
                    TO_CHAR(ROUND(total_charge_amount, 2), 'FM$999,999,999,999.00') AS total_charge_amount
                    FROM
                    public.vw_optimization_smi_result_customer_charge_queue
                WHERE session_id = '{session_id}'
            """,
            "error_breakdown_report": f"""
                select rev_customer_id as rev_account_number,iccid,msisdn,customer_name,
                error_message from vw_optimization_error_details_customer where session_id='{session_id}' and error_message is not null

            """,
        }
    else:
        logging.info(f"Carrier flow")
        # Define the queries and their respective report types
        queries = {
            "device_assignments": f"""
                SELECT
                    iccid,service_provider,
                    customer_pool,
                    carrier_rate_plan,
                    TO_CHAR(TRUNC(cycle_data_usage_mb, 2), 'FM$999,999,999,999.00') AS cycle_data_usage_mb,
                    communication_plan,
                    msisdn,
                    uses_proration,
                    date_activated,
                    EXTRACT(DAY FROM (billing_period_end_date - billing_period_start_date))
                    AS billing_period_duration,
                    days_activated_in_billing_period,
                    EXTRACT(DAY FROM (days_in_billing_period)) AS days_in_billing_period,
                    device_count as sim_count,
                    average_cost,
                    total_cost
                FROM public.vw_optimization_export_device_assignments
                WHERE session_id = '{session_id}'
            """,
            "error_breakdown_report": f"""
                select iccid,msisdn,
                error_message from vw_optimization_error_details_carrier where session_id='{session_id}' and error_message is not null

            """,
        }

    # Initialize a buffer for the zip file
    zip_buffer = io.BytesIO()

    try:
        # Process reports sequentially
        if report_type == "All Reports":
            if not pushed_charges:
                logging.info("Removing customer_charge_breakdown_report")
                queries.pop("customer_charge_breakdown_report", None)
            if not errors:
                logging.info("Removing error_breakdown_report")
                queries.pop("error_breakdown_report", None)
            logging.info(f"Queries: {queries}")
            for report_key, query in queries.items():
                # Ensure report_name is assigned here
                report_name = " ".join(
                    word.capitalize() for word in report_key.replace("_", " ").split()
                )
                logging.info(f"Generating {report_name} report data")
                excel_data = generate_report_to_excel(
                    report_name, query, database, optimization_type, session_id,tenant_name
                )
                if report_name == "Device Assignments By Customer Report":
                    try:
                        excel_datas, customers_with_second_sheet = (
                            generate_customer_pool_report(data)
                        )
                    except Exception as e:
                        logging.warning(f"### get_optimization_details_reports_data Error generating customer pool report: {e}")
                        customers_with_second_sheet = []
                # Write the Excel data to the zip file
                with zipfile.ZipFile(zip_buffer, "a", zipfile.ZIP_DEFLATED) as zip_file:
                    zip_file.writestr(f"{report_name} {session_id}.xlsx", excel_data)
                    if report_name == "Device Assignments By Customer Report":
                        try:
                            if excel_datas == "No customers found":
                                logging.info("### get_optimization_details_reports_data No Customers found")
                            else:
                                zip_file.writestr(
                                    f"Cross Customer Pools {session_id}.xlsx",
                                    excel_datas,
                                )
                        except Exception as e:
                            logging.exception(
                                f"### get_optimization_details_reports_data Exception occurred while writting it to report: {e}"
                            )

        elif report_type in queries:
            # Ensure report_name is assigned here
            report_name = " ".join(
                word.capitalize() for word in report_type.replace("_", " ").split()
            )
            excel_data = generate_report_to_excel(
                report_name,
                queries[report_type],
                database,
                optimization_type,
                session_id,tenant_name
            )
            logging.info(f"Generated {report_name} report data")
            if report_name == "Device Assignments By Customer Report":
                try:
                    excel_datas, customers_with_second_sheet = (
                        generate_customer_pool_report(data)
                    )
                except Exception as e:
                    logging.error(f"Error generating customer pool report: {e}")
                    customers_with_second_sheet = []
            # Write the Excel data to the zip file
            with zipfile.ZipFile(zip_buffer, "a", zipfile.ZIP_DEFLATED) as zip_file:
                zip_file.writestr(f"{report_name} {session_id}.xlsx", excel_data)
                try:
                    if excel_datas == "No customers found":
                        logging.info(f"No Customers found")
                    else:
                        zip_file.writestr(
                            f"Cross Customer Pools {session_id}.xlsx", excel_datas
                        )
                except Exception as e:
                    logging.exception(
                        f"Exceptdion occurred while writting it to report: {e}"
                    )

        # Now upload the zip buffer to S3
        file_name = f"optimization_module_uat/{optimization_type}/details/Optimization.zip"  # Adjust file path as necessary
        zip_buffer.seek(0)  # Reset the buffer to the beginning
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=zip_buffer.getvalue(),
            ContentType="application/zip",
        )

        # Generate the download URL
        download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

        # Assuming `db.update_dict` is updating the database with the download URL
        db.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": optimization_type},
        )

        # Return the download URL as the response
        response = {
            "flag": True,
            "file_url": download_url,
        }
        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "get_optimization_details_reports_data",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"fetched optimization details reports data : {optimization_type}",
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            db.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"Failed to log the audit data: {e}")
        logging.info(f"File successfully uploaded to S3. Download URL: {download_url}")
        return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        db.update_dict(
            "export_status",
            {"status_flag": "Failure", "url": ""},
            {"module_name": optimization_type},
        )
        message = "Something went wrong fetching optimization details data"
        response = {
            "flag": False,
            "file_url": "",  # Return empty URL in case of error,
            "message": message,
        }
        error_data = {
            "service_name": "get_optimization_details_reports_data",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Optimization",
            "request_received_at": request_received_at,
        }
        db.log_error_to_db(error_data, "error_log_table")
        return response


# Helper function to sanitize the cross pool report
def sanitize_sheet_name_cross_pool(name):
    """
    Sanitize sheet name for cross pool reports by removing invalid characters, 
    stripping specific prefixes/suffixes, and enforcing Excel's length limit.
    
    Args:
        name (str): The original sheet name to sanitize
        
    Returns:
        str: A sanitized sheet name that is valid for Excel, with spaces instead of underscores
             and specific prefixes/suffixes removed
    """
    invalid_chars = [
        "/",
        "\\",
        "?",
        "*",
        "[",
        "]",
        ":",
        "#",
    ]  # Invalid characters for Excel sheet names

    # Strip 'Customer_Pool____' prefix if it exists
    if name.startswith("Customer_Pool__"):
        name = name[len("Customer_Pool__") :]  # Strip the 'Customer_Pool____' prefix

    # Strip 'Customer_' suffix if it exists
    if name.endswith("Customer_"):
        name = name[: -len("Customer_")]  # Strip the 'Customer_' suffix

    # Remove unnecessary leading and trailing spaces
    name = name.strip()

    # Replace invalid characters with an underscore
    for char in invalid_chars:
        name = name.replace(char, "_")

    # Remove any underscores and replace them with spaces
    name = name.replace("_", " ")

    # Ensure sheet name doesn't exceed 31 characters (Excel's limit)
    name = name[:31]

    # Remove any unwanted characters (non-alphanumeric)
    name = "".join(e for e in name if e.isalnum() or e == " ")

    # If the name becomes empty after sanitizing, use a default name
    if not name:
        name = "Untitled_Sheet"

    return name


# def generate_customer_pool_report(data):
#     """
#     Generates the 'Customer Pool Report' with separate sheets for each customer pool.
#     Sheets will be named based on the 'Customer Pool' column from the second sheet of each customer's data,
#     and duplicates will be ignored.

#     Args:
#         data (list): Data used for reporting (not used directly here, but could be useful for other reports).
#         session_id (str): The current session ID for tracking purposes.
#         database (object): The database connection object.

#     Returns:
#         excel_data (bytes or str): Excel file data as bytes, or message if no data is found.
#         customers_with_second_sheet (list): List of customer names that have a second sheet.
#     """
#     tenant_database = data.get("db_name", "")
#     # database Connection
#     database = DB(tenant_database, **db_config)
#     session_id = data.get("session_id")
#     logging.info(f"Generating customer pool report for session ID: {session_id}")
#     # Direct SQL query to fetch customer report data
#     binary_query = """
#         SELECT r.results_id, r.customer_name, r.rev_customer_id as customer_account_number, f.assignment_xlsx_bytes
#         FROM public.vw_optimization_instance r
#         JOIN optimization_instance_result_file f ON r.results_id = f.id
#         WHERE r.session_id = %s
#     """
#     params = [session_id]
#     customer_report_data = database.execute_query(binary_query, params=params)

#     if customer_report_data.empty:
#         logging.warning(f"No data found for the customer pool report.")
#         return "No customers found", []

#     # Initialize the excel buffer to write to
#     excel_buffer = io.BytesIO()

#     # List to store customer names with a second sheet
#     customers_with_second_sheet = []

#     # Set to keep track of already used customer pool names as sheet names
#     used_sheet_names = set()

#     # Flag to track if at least one customer with data is added
#     customer_added = False
#     try:
#         with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
#             # Iterate through customer report data
#             for _, row in customer_report_data.iterrows():
#                 assignment_xlsx_binary = row["assignment_xlsx_bytes"]
#                 customer_name = row["customer_name"]
#                 customer_account_number = row["customer_account_number"]

#                 # Initialize a DataFrame to hold the data for this customer
#                 customer_df = pd.DataFrame()

#                 if assignment_xlsx_binary:
#                     # Read the binary content of the Excel file
#                     assignment_file = io.BytesIO(assignment_xlsx_binary)
#                     # Read all sheets in the Excel file
#                     try:
#                         # Read the CrossPoolingResult sheet
#                         cross_pooling_df = pd.read_excel(
#                             assignment_file, sheet_name="CrossPoolingResult"
#                         )

#                         # Apply column name capitalization and special replacements
#                         cross_pooling_df = capitalize_and_replace(cross_pooling_df)

#                         # Drop empty columns (where all values are NaN)
#                         cross_pooling_df = cross_pooling_df.dropna(axis=1, how="all")

#                         # Only add non-empty data to the customer DataFrame
#                         if not cross_pooling_df.empty:
#                             customer_df = cross_pooling_df  # Start with the CrossPoolingResult data

#                         # Now, check if there is a second sheet
#                         all_sheets = pd.read_excel(
#                             assignment_file, sheet_name=None
#                         )  # Read all sheets
#                         sheet_names = list(all_sheets.keys())

#                         # If there is a second sheet, process it
#                         if len(sheet_names) > 1:
#                             second_sheet_name = sheet_names[
#                                 1
#                             ]  # Get the second sheet's name
#                             second_sheet_df = all_sheets[second_sheet_name]

#                             # Optionally, process or clean the second sheet data here (if needed)
#                             second_sheet_df = second_sheet_df.dropna(
#                                 axis=1, how="all"
#                             )  # Drop empty columns if any

#                             # Apply column name capitalization and special replacements
#                             second_sheet_df = capitalize_and_replace(second_sheet_df)

#                             # Extract the 'Customer Pool' column value from the second sheet for sheet naming
#                             if "Customer Pool" in second_sheet_df.columns:
#                                 # Extract the first value from the 'Customer Pool' column
#                                 customer_pool_value = second_sheet_df[
#                                     "Customer Pool"
#                                 ].values[0][0]
#                                 logging.info(
#                                     f"Customer Pool value: {customer_pool_value}"
#                                 )
#                                 # Ensure the value is properly cleaned and sanitized
#                                 sanitized_name = sanitize_sheet_name_cross_pool(
#                                     str(customer_pool_value)
#                                 )  # Sanitize
#                                 # Make sure the name is not too long or incorrect after sanitization
#                                 sheet_name = sanitized_name[
#                                     :31
#                                 ]  # Ensure it fits Excel's 31 character limit
#                                 # Skip if this sheet name has already been used
#                                 if sheet_name in used_sheet_names:
#                                     continue
#                                 used_sheet_names.add(sheet_name)
#                             # Only append non-empty second sheet data to the customer DataFrame
#                             if not second_sheet_df.empty:
#                                 customer_df = pd.concat(
#                                     [customer_df, second_sheet_df], ignore_index=True
#                                 )

#                             # Add the customer name to the list of customers with a second sheet
#                             customers_with_second_sheet.append(customer_name)

#                         # Remove duplicates in the final customer DataFrame
#                         customer_df = customer_df.drop_duplicates(ignore_index=True)

#                     except ValueError:
#                         # If the sheet "CrossPoolingResult" doesn't exist, append an empty dataframe
#                         empty_df = pd.DataFrame(columns=["No Data"])
#                         customer_df = (
#                             empty_df  # Set to empty DataFrame if no data exists
#                         )

#                 # Only add the customer sheet if they have data
#                 if not customer_df.empty:
#                     first_df = customer_df.iloc[
#                             :, :5
#                         ]
#                     second_df=customer_df.iloc[
#                             :, 5:
#                         ]

#                     # Filter out 'No Pool' rows
#                     second_df = second_df[second_df["Customer Pool"] != "No Pool"]

#                     # Find the index of "Sub-Total" row
#                     sub_total_index = second_df[second_df["Rate Plan"] == "Sub-Total"].index

#                     if not sub_total_index.empty:
#                         sub_total_index = sub_total_index[0]  # Get first occurrence
#                         df_filtered = second_df.loc[:sub_total_index].copy()  # Keep rows up to Sub-Total
#                         print('entered here')
#                         numeric_cols = ["Total Usage", "Total Cost","Average Usage(mb)", "Average Cost"]  # Specify numeric columns explicitly

#                         for col in numeric_cols:
#                             df_filtered[col] = df_filtered[col].replace(',', '', regex=True).astype(float)  # Remove commas & convert to float
#                         df_filtered.loc[df_filtered["Rate Plan"] == "Sub-Total", "Rate Plan"] = "Grand Total"  # Rename Sub-Total to Grand Total

#                         # Identify numeric columns
#                         numeric_cols = df_filtered.select_dtypes(include=['number']).columns

#                         # Adjust "Grand Total" row for summation columns
#                         for col in df_filtered.select_dtypes(include=['number']).columns:
#                             if col not in ["Average Usage(mb)", "Average Cost"]:  # Exclude mean columns
#                                 df_filtered.loc[df_filtered["Rate Plan"] == "Grand Total", col] = (
#                                     df_filtered[col].sum() - df_filtered[df_filtered.index == sub_total_index][col].values[0]
#                                 )

#                         # Compute correct mean for "Average Usage (MB)" and "Average Cost"
#                         mean_cols = ["Average Usage(mb)", "Average Cost"]
#                         for col in mean_cols:
#                             df_filtered.loc[df_filtered["Rate Plan"] == "Grand Total", col] = (
#                                 df_filtered[df_filtered["Rate Plan"] != "Grand Total"][col].sum() / (len(df_filtered) - 1)  # Excluding Grand Total row
#                             )
#                     df_filtered = df_filtered.dropna(how='all')

#                     print(df_filtered,'second_dfsecond_dfsecond_dfsecond_df')
#                     iccid_list = first_df["ICCID"].dropna().unique().tolist()

#                     # Query to fetch customer_name for extracted ICCIDs
#                     iccid_query = (
#                         "SELECT iccid, customer_name "
#                         "FROM sim_management_inventory "
#                         "WHERE iccid IN (" + ",".join(f"'{iccid}'" for iccid in iccid_list) + ") "
#                         "AND tenant_id=1;"
#                     )
#                     iccid_df = database.execute_query(iccid_query,True)
#                     iccid_map = dict(zip(iccid_df['iccid'], iccid_df['customer_name']))

#                     first_df["Customer Name"] = first_df["ICCID"].map(iccid_map)
#                     first_df = first_df[['Customer Name'] + [col for col in first_df.columns if col != 'Customer Name']]
#                     if 'Customer Pool' in first_df.columns:
#                         # Filter out rows where 'Customer Pool' is NaN or empty
#                         first_df = first_df[first_df['Customer Pool'].notna() & (first_df['Customer Pool'] != '')]

#                     customer_df = pd.concat(
#                             [first_df,df_filtered], axis=1
#                         )
#                     # Format MSISDN and Sim Card Count columns to remove .00
#                     try:
#                         customer_df = format_columns(customer_df)
#                     except Exception as e:
#                         logging.info(f"Exception while formatting columns: {e}")
#                     customer_df.to_excel(writer, index=False, sheet_name=sheet_name)
#                     customer_added = True

#             # If no customers with data, create an empty sheet to avoid the "At least one sheet must be visible" error
#             if not customer_added:
#                 empty_df = pd.DataFrame(columns=["No Data"])
#                 empty_df.to_excel(writer, index=False, sheet_name="Empty Report")

#             # Apply formatting to all sheets after writing data
#             workbook = writer.book
#             for sheet_name in workbook.sheetnames:
#                 sheet = workbook[sheet_name]

#                 # Adjust column widths
#                 for col_idx, col_cells in enumerate(sheet.columns, 1):
#                     max_length = max(len(str(cell.value or "")) for cell in col_cells)
#                     sheet.column_dimensions[get_column_letter(col_idx)].width = (
#                         max_length + 2
#                     )

#                 # Apply number formatting
#                 for col_idx, col_cells in enumerate(sheet.columns, 1):
#                     for cell in col_cells:
#                         if isinstance(cell.value, (int, float)):
#                             if sheet.cell(row=1, column=col_idx).value in [
#                                 "Sim Card Count",
#                                 "MSISDN",
#                             ]:
#                                 cell.number_format = (
#                                     "0"  # Format as integer with no decimals
#                                 )
#                             else:
#                                 cell.number_format = (
#                                     "0.00"  # Format with two decimal places
#                                 )
#                 # Format header row
#                 for cell in sheet[1]:
#                     cell.alignment = Alignment(horizontal="center", vertical="center")
#                     cell.fill = PatternFill(
#                         start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
#                     )
#                     cell.font = Font(bold=True)

#             # Reorder sheets by name in ascending order
#             workbook._sheets.sort(key=lambda ws: ws.title)
#     except Exception as e:
#         logging.exception(f"Exception occurred at report data : {e}")

#     # If no customers with data, return a message
#     if not customer_added:
#         return "No customers found", []

#     # Return the Excel buffer as bytes and the list of customers with a second sheet
#     return excel_buffer.getvalue(), customers_with_second_sheet


def generate_customer_pool_report(data):
    """
    Generates the 'Customer Pool Report' with separate sheets for each customer pool.
    
    Args:
        data (dict): Dictionary containing request parameters including db_name, tenant_name, and session_id
        
    Returns:
        tuple: A tuple containing:
            - bytes or str: Excel file data as bytes, or "No customers found" message if no data is found
            - list: List of customer names that have a second sheet
    """
    tenant_database = data.get("db_name", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    tenant_id = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id"]
    )["id"].to_list()[0]
    # database Connection
    database = DB(tenant_database, **db_config)
    session_id = data.get("session_id")
    logging.info(f"### generate_customer_pool_report Generating customer pool report for session ID: {session_id}")
    # Direct SQL query to fetch customer report data
    binary_query = """
        SELECT r.results_id, r.customer_name, r.rev_customer_id as customer_account_number, f.assignment_xlsx_bytes
        FROM public.vw_optimization_instance r
        JOIN optimization_instance_result_file f ON r.results_id = f.id
        WHERE r.session_id = %s
    """
    params = [session_id]
    customer_report_data = database.execute_query(binary_query, params=params)

    if customer_report_data.empty:
        logging.warning("### generate_customer_pool_report No data found for the customer pool report.")
        return "No customers found", []

    # Initialize the excel buffer to write to
    excel_buffer = io.BytesIO()

    # List to store customer names with a second sheet
    customers_with_second_sheet = []

    # Set to keep track of already used customer pool names as sheet names
    used_sheet_names = set()

    # Flag to track if at least one customer with data is added
    customer_added = False
    try:
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            # Iterate through customer report data
            for _, row in customer_report_data.iterrows():
                assignment_xlsx_binary = row["assignment_xlsx_bytes"]
                customer_name = row["customer_name"]
                customer_account_number = row["customer_account_number"]

                # Initialize a DataFrame to hold the data for this customer
                customer_df = pd.DataFrame()

                if assignment_xlsx_binary:
                    # Read the binary content of the Excel file
                    assignment_file = io.BytesIO(assignment_xlsx_binary)
                    # Read all sheets in the Excel file
                    try:
                        # Read the CrossPoolingResult sheet
                        cross_pooling_df = pd.read_excel(
                            assignment_file, sheet_name="CrossPoolingResult"
                        )

                        # Apply column name capitalization and special replacements
                        cross_pooling_df = capitalize_and_replace(cross_pooling_df)

                        # Drop empty columns (where all values are NaN)
                        cross_pooling_df = cross_pooling_df.dropna(axis=1, how="all")

                        # Only add non-empty data to the customer DataFrame
                        if not cross_pooling_df.empty:
                            customer_df = cross_pooling_df  # Start with the CrossPoolingResult data

                        # Now, check if there is a second sheet
                        all_sheets = pd.read_excel(
                            assignment_file, sheet_name=None
                        )  # Read all sheets
                        sheet_names = list(all_sheets.keys())

                        # If there is a second sheet, process it
                        if len(sheet_names) > 1:
                            second_sheet_name = sheet_names[
                                1
                            ]  # Get the second sheet's name
                            second_sheet_df = all_sheets[second_sheet_name]

                            # Optionally, process or clean the second sheet data here (if needed)
                            second_sheet_df = second_sheet_df.dropna(
                                axis=1, how="all"
                            )  # Drop empty columns if any

                            # Apply column name capitalization and special replacements
                            second_sheet_df = capitalize_and_replace(second_sheet_df)

                            # Extract the 'Customer Pool' column value from the second sheet for sheet naming
                            if "Customer Pool" in second_sheet_df.columns:
                                # Extract the first value from the 'Customer Pool' column
                                customer_pool_value = second_sheet_df[
                                    "Customer Pool"
                                ].values[0][0]
                                logging.info(
                                    f"Customer Pool value: {customer_pool_value}"
                                )
                                # Ensure the value is properly cleaned and sanitized
                                sanitized_name = sanitize_sheet_name_cross_pool(
                                    str(customer_pool_value)
                                )  # Sanitize
                                # Make sure the name is not too long or incorrect after sanitization
                                sheet_name = sanitized_name[
                                    :31
                                ]  # Ensure it fits Excel's 31 character limit
                                # Skip if this sheet name has already been used
                                if sheet_name in used_sheet_names:
                                    continue
                                used_sheet_names.add(sheet_name)
                            # Only append non-empty second sheet data to the customer DataFrame
                            if not second_sheet_df.empty:
                                customer_df = pd.concat(
                                    [customer_df, second_sheet_df], ignore_index=True
                                )

                            # Add the customer name to the list of customers with a second sheet
                            customers_with_second_sheet.append(customer_name)

                        # Remove duplicates in the final customer DataFrame
                        customer_df = customer_df.drop_duplicates(ignore_index=True)

                    except ValueError:
                        # If the sheet "CrossPoolingResult" doesn't exist, append an empty dataframe
                        empty_df = pd.DataFrame(columns=["No Data"])
                        customer_df = (
                            empty_df  # Set to empty DataFrame if no data exists
                        )

                # Only add the customer sheet if they have data
                if not customer_df.empty:
                    first_df = customer_df.iloc[:, :5]
                    second_df = customer_df.iloc[:, 5:]

                    # # Filter out 'No Pool' rows
                    # second_df = second_df[second_df["Customer Pool"] != "No Pool"]

                    # # Find the index of "Sub-Total" row
                    # sub_total_index = second_df[second_df["Rate Plan"] == "Sub-Total"].index

                    # if not sub_total_index.empty:
                    #     sub_total_index = sub_total_index[0]  # Get first occurrence
                    #     df_filtered = second_df.loc[:sub_total_index].copy()  # Keep rows up to Sub-Total
                    #     print('entered here')
                    #     numeric_cols = ["Total Usage", "Total Cost","Average Usage(mb)", "Average Cost"]  # Specify numeric columns explicitly

                    #     for col in numeric_cols:
                    #         df_filtered[col] = df_filtered[col].replace(',', '', regex=True).astype(float)  # Remove commas & convert to float
                    #     df_filtered.loc[df_filtered["Rate Plan"] == "Sub-Total", "Rate Plan"] = "Grand Total"  # Rename Sub-Total to Grand Total

                    #     # Identify numeric columns
                    #     numeric_cols = df_filtered.select_dtypes(include=['number']).columns

                    #     # Adjust "Grand Total" row for summation columns
                    #     for col in df_filtered.select_dtypes(include=['number']).columns:
                    #         if col not in ["Average Usage(mb)", "Average Cost"]:  # Exclude mean columns
                    #             df_filtered.loc[df_filtered["Rate Plan"] == "Grand Total", col] = (
                    #                 df_filtered[col].sum() - df_filtered[df_filtered.index == sub_total_index][col].values[0]
                    #             )

                    #     # Compute correct mean for "Average Usage (MB)" and "Average Cost"
                    #     mean_cols = ["Average Usage(mb)", "Average Cost"]
                    #     for col in mean_cols:
                    #         df_filtered.loc[df_filtered["Rate Plan"] == "Grand Total", col] = (
                    #             df_filtered[df_filtered["Rate Plan"] != "Grand Total"][col].sum() / (len(df_filtered) - 1)  # Excluding Grand Total row
                    #         )
                    # df_filtered = df_filtered.dropna(how='all')

                    # print(df_filtered,'second_dfsecond_dfsecond_dfsecond_df')
                    iccid_list = first_df["ICCID"].dropna().unique().tolist()

                    # Query to fetch customer_name for extracted ICCIDs
                    iccid_query = (
                        "SELECT iccid, customer_name "
                        "FROM sim_management_inventory "
                        "WHERE iccid IN ("
                        + ",".join(f"'{iccid}'" for iccid in iccid_list)
                        + ") "
                        "AND tenant_id=%s;"
                    )
                    params = [tenant_id]
                    iccid_df = database.execute_query(iccid_query, params=params)
                    iccid_map = dict(zip(iccid_df["iccid"], iccid_df["customer_name"]))

                    first_df["Customer Name"] = first_df["ICCID"].map(iccid_map)
                    first_df = first_df[
                        ["Customer Name"]
                        + [col for col in first_df.columns if col != "Customer Name"]
                    ]
                    if "Customer Pool" in first_df.columns:
                        # Filter out rows where 'Customer Pool' is NaN or empty
                        first_df = first_df[
                            first_df["Customer Pool"].notna()
                            & (first_df["Customer Pool"] != "")
                        ]

                    customer_df = pd.concat([first_df, second_df], axis=1)
                    # Format MSISDN and Sim Card Count columns to remove .00
                    try:
                        customer_df = format_columns(customer_df)
                    except Exception as e:
                        logging.info(f"### generate_customer_pool_report Exception while formatting columns: {e}")
                    customer_df.to_excel(writer, index=False, sheet_name=sheet_name)
                    customer_added = True

            # If no customers with data, create an empty sheet to avoid the "At least one sheet must be visible" error
            if not customer_added:
                empty_df = pd.DataFrame(columns=["No Data"])
                empty_df.to_excel(writer, index=False, sheet_name="Empty Report")

            # Apply formatting to all sheets after writing data
            workbook = writer.book
            for sheet_name in workbook.sheetnames:
                sheet = workbook[sheet_name]

                # Adjust column widths
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = (
                        max_length + 2
                    )

                # Apply number formatting
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    for cell in col_cells:
                        if isinstance(cell.value, (int, float)):
                            if sheet.cell(row=1, column=col_idx).value in [
                                "Sim Card Count",
                                "MSISDN",
                            ]:
                                cell.number_format = (
                                    "0"  # Format as integer with no decimals
                                )
                            else:
                                cell.number_format = (
                                    "0.00"  # Format with two decimal places
                                )
                # Format header row
                for cell in sheet[1]:
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(
                        start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                    )
                    cell.font = Font(bold=True)

            # Reorder sheets by name in ascending order
            workbook._sheets.sort(key=lambda ws: ws.title)
    except Exception as e:
        logging.exception(f"### generate_customer_pool_report Exception occurred at report data : {e}")

    # If no customers with data, return a message
    if not customer_added:
        return "No customers found", []

    # Return the Excel buffer as bytes and the list of customers with a second sheet
    return excel_buffer.getvalue(), customers_with_second_sheet


##Helper function to capitalize and replcae the columns
def capitalize_and_replace(df):
    """
    Apply capitalization and special replacements to DataFrame column names.

    Args:
        df (pandas.DataFrame): The DataFrame whose column names will be modified.

    Returns:
        pandas.DataFrame: DataFrame with updated column names.
    """
    # Capitalize and replace underscores with spaces
    special_replacements = {
        "Iccid": "ICCID",
        "Msisdn": "MSISDN",
        "Sim_card_count": "Sim Card Count",
        "Communication_plan": "Communication Plan",
        "Customer_pool": "Customer Pool",
        "Rate_plan": "Rate Plan",
        # Add more replacements as needed
    }

    # Define a list of acronyms to keep in uppercase
    acronyms = {"ICCID", "MSISDN", "URL", "IP"}
    df.columns = [
        " ".join(
            part.upper() if part.upper() in acronyms else part.capitalize()
            for part in col.replace("_", " ").split(
                " "
            )  # Replace underscores and split
        )
        for col in df.columns
    ]

    # Apply any special replacements
    df.columns = [
        " ".join([special_replacements.get(word, word) for word in col.split(" ")])
        for col in df.columns
    ]

    # Remove ".1" suffix from column names
    df.columns = [col.replace(".1", "") for col in df.columns]

    return df


##Helper function to format the columnss
def format_columns(df):
    """
    Format MSISDN and Sim Card Count columns to remove '.00' for whole numbers.
    Handle NaN values correctly for Sim Card Count.
    
    Args:
        df (pandas.DataFrame): The DataFrame containing columns to format
        
    Returns:
        pandas.DataFrame: DataFrame with formatted columns
    """
    # Apply to Sim Card Count (remove .00 if it's a whole number)
    if "Sim Card Count" in df.columns:
        df["Sim Card Count"] = df["Sim Card Count"].apply(
            lambda x: (
                int(x)
                if pd.notnull(x)
                and isinstance(x, (float, int))
                and (isinstance(x, int) or (isinstance(x, float) and x.is_integer()))
                else x
            )
        )

    # Apply to MSISDN (remove .00 if it's a whole number)
    if "MSISDN" in df.columns:
        df["MSISDN"] = df["MSISDN"].apply(
            lambda x: (
                int(x)
                if pd.notnull(x)
                and isinstance(x, (float, int))
                and (isinstance(x, int) or (isinstance(x, float) and x.is_integer()))
                else x
            )
        )
    return df


##third point
def get_optimization_push_charges_data(data):
    """
    The get_optimization_push_charges_data function retrieves data for push charges
    based on the provided session ID and pagination parameters (start, end, limit).
    It first counts the total number of rows that match the session ID and then fetches
    the corresponding push charges data. If data exists, it returns the data in a
    paginated format; otherwise, it returns a message indicating no data was found.
    The function also handles errors gracefully by logging exceptions and returning an
    error response with a message.
    Args:
        data (dict): Dictionary containing request parameters including session_id, start, end, username,
        request_received_at, tenant_name, db_name
    Returns:
        dict: A dictionary containing the status of the operation, pagination information,
        push charges data, instance IDs, and ICCIDs. If an error occurs, it returns an error message.
    """
    logging.info(f"### get_optimization_push_charges_data Request Data Received : {data}")
    try:
        for key in ["customers", "service_providers", "tenant_ids"]:
            db_config.pop(key, None)  # removes if exists, ignores otherwise    
    except Exception as e:
        logging.exception(f"### get_optimization_push_charges_data Failed to delete the db_config : {e}" )
    ##start time for performance measurement
    start_time = time.time()
    session_id = data.get("session_id")
    username = data.get("username", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    tenant_database = data.get("db_name", "")
    # database Connection
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    start = data.get("start", 0)
    end = data.get("end", 10)  # Default to 10 if no 'end' parameter provided
    limit = 10
    params = [start, end]
    pages = {"start": start, "end": end}
    total_count = 0

    try:
        try:
            instance_ids_query = f"""
            SELECT DISTINCT ON (instance_id)
                        instance_id, iccid
            FROM public.vw_optimization_push_charges_error
            WHERE session_id ='{session_id}'
            """

            # Execute the query and get the result
            instance_ids_data = database.execute_query(instance_ids_query, True)

            # Extract instance_id and iccid into separate lists
            instance_ids = instance_ids_data["instance_id"].to_list()
            iccid_list = instance_ids_data["iccid"].to_list()
        except Exception as e:
            logging.exception(f"### get_optimization_push_charges_data Exception occurred while fetching instance_ids and iccids: {e}")
            instance_ids = []
            iccid_list = []
        # Query to get the total count of rows
        error_details_count_query = """
           SELECT COUNT(DISTINCT instance_id)
            FROM public.vw_optimization_push_charges_error
            WHERE session_id = %s;
        """
        total_count_result = database.execute_query(
            error_details_count_query, params=[session_id]
        ).iloc[0, 0]
        pages["total_count"] = int(total_count_result)

        # Query to get the data for push charges
        push_charges_dataquery = """
            SELECT DISTINCT ON (instance_id)
                instance_id, iccid, service_provider_id, service_provider,
                rev_customer_id, customer_name, msisdn, total_charge_amount, error_message
            FROM public.vw_optimization_push_charges_error
            WHERE session_id = %s
            OFFSET %s LIMIT %s;
        """

        push_charges_data = database.execute_query(
            push_charges_dataquery, params=[session_id, start, limit]
        )
        # push_charges_data = push_charges_data.astype(str)
        # Check if data is empty
        if push_charges_data.empty:
            # If no data, create an empty list with column names as keys
            columns = [
                "rev_customer_id",
                "customer_name",
                "iccid",
                "msisdn",
                "run_status",
                "instance_id",
                "error_message",
                "total_charge_amount",
            ]
            # Return an empty list of data with the column names in the response
            push_charges_data = []
            response = {
                "flag": True,
                "message": "No data found for the given parameters",
                "pages": pages,
                "push_charges_data": push_charges_data,
                "columns": columns,
                "instance_ids": instance_ids,
                "iccids": iccid_list,
            }
        else:
            # If data exists, convert to list of dictionaries
            push_charges_data = push_charges_data.to_dict(orient="records")

            response = {
                "flag": True,
                "pages": pages,
                "push_charges_data": push_charges_data,
                "instance_ids": instance_ids,
                "iccids": iccid_list,
            }
        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "get_optimization_push_charges_data",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": "get_optimization_push_charges_data function fetched successfully",
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"### get_optimization_push_charges_data Failed to log the audit data: {e}")
        # Ensure everything is JSON serializable
        return response

    except Exception as e:
        # Log the exception and return a failure response
        logging.exception(f" ### get_optimization_push_charges_dataException occurred: {e}")
        response = {
            "flag": False,
            "error": str(e),
            "message": "An error occurred while fetching the data",
        }
        message = "Failed to get the push charges data"
        error_data = {
            "service_name": "get_optimization_push_charges_data",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Optimization",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        # Ensure error response is also JSON serializable
        return response


##update button for rate plans and other updates
def update_optimization_actions_data(data):
    """
    The update_optimization_actions_data function updates the rate plans and
    other relevant data for a specific ICCID in the sim_management_inventory table.
    It takes the changed_data (the data to be updated) and the iccid
    (identifier for the SIM) from the request.
    The function attempts to update the record and returns a success message
    if the update is successful. If an exception occurs during the update process,
    it logs the exception and continues.
    Args:
        data (dict): Dictionary containing request parameters including db_name, changed_data, action, username
        session_id, tenant_name, request_received_at, iccid
    Returns:
        dict: A dictionary containing the status of the update operation and a message.
    """
    logging.info(f"Request Data Received for update_optimization_actions_data path : {data}")
    ##start time for performance measurement
    start_time = time.time()
    # Database connection
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    changed_data = data.get("changed_data", "")
    action = data.get("action", "push_charges_update")
    username = data.get("username", "")
    session_id = data.get("session_id")
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at", "")
    iccid = str(data.get("iccid"))
    # Check if iccid is provided and is not an empty string
    if not iccid or iccid == "0":
        return {"flag": False, "message": "ICCID is required and cannot be empty. "}
    ##updation in 2.0 for sim_management_inventory table
    try:
        database.update_dict("sim_management_inventory", changed_data, {"iccid": iccid})
    except Exception as e:
        logging.exception(f"### update_optimization_actions_data Exception is {e}")
        return {"flag": False, "message": "Failed to Update in 2.0!!!"}
    ##updation in 1.0 for Device and Mobility Device  tables
    try:
        onepointorelated_query = f"""SELECT distinct service_provider_id,device_id,mobility_device_id
        FROM sim_management_inventory WHERE iccid = '{iccid}'
        """
        onepointorelated_dataframe = database.execute_query(
            onepointorelated_query, True
        )
        row = onepointorelated_dataframe.iloc[0]  # Get the 0th row
        # Extract values
        service_provider_id = row["service_provider_id"]
        device_id = row["device_id"]
        mobility_device_id = row["mobility_device_id"]
        customer_rate_plan_name = changed_data.get("customer_rate_plan_name", "")
        customer_rate_pool_name = changed_data.get("customer_rate_pool_name", "")
        if customer_rate_plan_name:
            customer_rate_plan_id = database.get_data(
                "customerrateplan",
                {"service_provider_id": str(service_provider_id)},
                ["id"],
            )["id"].to_list()[0]
        else:
            customer_rate_plan_id = None

        if customer_rate_pool_name:
            customer_rate_pool_id = database.get_data(
                "customer_rate_pool",
                {"service_provider_id": str(service_provider_id)},
                ["id"],
            )["id"].to_list()[0]
        else:
            customer_rate_pool_id = None
        optimizations_actions_update_in_10(
            service_provider_id,
            customer_rate_pool_id,
            customer_rate_plan_id,
            device_id,
            mobility_device_id,
            iccid,
            action,
            tenant_name
        )
        response = {"flag": True, "message": "Updated Successfully"}
        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "update_optimization_actions_data",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(changed_data),
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"### update_optimization_actions_data Failed to log the audit data: {e}")
        return response
    except Exception as e:
        logging.exception(f"### update_optimization_actions_data Exception is {e}")
        response = {"flag": False, "message": "Failed to Update in 1.0!!!"}
        error_data = {
            "service_name": "update_optimization_actions_data",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "tenant_name": tenant_name,
            "comments": json.dumps(changed_data),
            "module_name": "Optimization",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return response


def optimizations_actions_update_in_10(
    service_provider_id,
    customer_rate_pool_id,
    customer_rate_plan_id,
    device_id,
    mobility_device_id,
    iccid,
    action,tenant_name
):
    """ The optimizations_actions_update_in_10 function updates the
    customer rate plan and customer rate pool for a device or mobility device
    in the database based on the provided parameters.
    Args:
        service_provider_id (int): The ID of the service provider.
        customer_rate_pool_id (int): The ID of the customer rate pool.
        customer_rate_plan_id (int): The ID of the customer rate plan.
        device_id (int): The ID of the device.
        mobility_device_id (int): The ID of the mobility device.
        iccid (str): The ICCID of the SIM card.
        action (str): The action to be performed, either "Assign Rate Plan" or "Assign Rate Pool".
    """
    logging.info("### optimizations_actions_update_in_10 Function Has Started optimization_actions_update_in_10")
    creds = get_db_credentials(tenant_name)
    if creds:
        server = creds["server"]
        database = creds["database_name"]
        username = creds["username"]
        password = creds["password"]
        port = creds["port"]
    else:
        # Define database connection parameters
        server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
        database = os.environ["ONEPOINTODATABASE"]
        username = os.environ["ONEPOINTOUSERNAME"]
        password = os.environ["ONEPOINTOPASSWORD"]
    mobility_flag = False
    customer_rate_plan_id = (
        int(customer_rate_plan_id) if customer_rate_plan_id is not None else None
    )
    customer_rate_pool_id = (
        int(customer_rate_pool_id) if customer_rate_pool_id is not None else None
    )
    mobility_device_id = (
        int(mobility_device_id) if mobility_device_id is not None else None
    )
    device_id = int(device_id) if device_id is not None else None
    mobility_service_providers = os.getenv("MOBILITY_SERVICE_PROVIDER_NAMES", "").split("/")
    try:
        # Construct the query dynamically based on the service provider names
        mobility_service_provider_ids_query = f"""
            SELECT id
            FROM serviceprovider
            WHERE service_provider_name IN ({', '.join(["'" + name.strip() + "'" for name in mobility_service_providers])})
        """
        mobility_service_provider_dataframe = database.execute_query(
            mobility_service_provider_ids_query, True
        )
        # Assuming the result is a Pandas DataFrame, we extract the 'id' column as a list
        if isinstance(mobility_service_provider_dataframe, pd.DataFrame):
            mobility_service_provider_ids = mobility_service_provider_dataframe[
                "id"
            ].tolist()
    except Exception as e:
        logging.warning(f"### optimizations_actions_update_in_10 Exception while fetching the service providers : {e}")
        mobility_service_provider_ids = [0]
    if str(service_provider_id) in mobility_service_provider_ids:
        mobility_flag = True
        table_name = f"{database}.dbo.MobilityDevice_Tenant"
        where_col = "MobilityDeviceId"
        if mobility_device_id is not None:
            where_val = int(mobility_device_id)

    else:
        table_name = f"{database}.dbo.Device_Tenant"
        where_col = "DeviceId"
        if device_id is not None:
            device_id = int(device_id)
    if action == "Assign Rate Plan":
        # Construct query with parameterized values
        query = f"""
        UPDATE {table_name}
        SET CustomerRatePlanId = %s
        WHERE {where_col} = %s and TenantId=1
        """
        logging.info(f"Query: {query}")
        # Establishing connection and executing the query
        with pytds.connect(
            server=server, database=database, user=username, password=password
        ) as conn:
            cursor = conn.cursor()
            if mobility_flag:
                logging.info(
                    f"### optimizations_actions_update_in_10 mobility_device_id: {mobility_device_id}, customer_rate_plan_id: {customer_rate_plan_id}"
                )
                cursor.execute(query, (customer_rate_plan_id, mobility_device_id))
            else:
                logging.info(
                    f"### optimizations_actions_update_in_10 device_id: {device_id}, customer_rate_plan_id: {customer_rate_plan_id} , customer_rate_pool_id: {customer_rate_pool_id}"
                )
                cursor.execute(query, (customer_rate_plan_id, device_id))
            conn.commit()

    else:
        # Construct query with parameterized values
        query = f"""
        UPDATE {table_name}
        SET CustomerRatePlanId = %s, CustomerRatePoolId = %s
        WHERE {where_col} = %s and TenantId=1
        """
        logging.info(f"### optimizations_actions_update_in_10 Query: {query}")

        # Establishing connection and executing the query
        with pytds.connect(
            server=server, database=database, user=username, password=password
        ) as conn:
            cursor = conn.cursor()
            if mobility_flag:
                cursor.execute(
                    query,
                    (customer_rate_plan_id, customer_rate_pool_id, mobility_device_id),
                )
            else:
                logging.info(
                    f"### optimizations_actions_update_in_10 device_id: {device_id}, customer_rate_plan_id: {customer_rate_plan_id} , customer_rate_pool_id: {customer_rate_pool_id} , device_id: {device_id}"
                )
                cursor.execute(
                    query, (customer_rate_plan_id, customer_rate_pool_id, device_id)
                )

            conn.commit()


# Function to fetch both service providers and their rate plans
def get_assign_rate_plan_optimization_dropdown_data(data):
    """
    The get_assign_rate_plan_optimization_dropdown_data function fetches
    the rate plans for a specified service provider, based on the
    optimization type (either "Customer" or "Carrier)
    Args:
        data (dict): A dictionary containing the request data, including:
            - service_provider (str): The name of the service provider.
            - optimization_type (str): The type of optimization, default is "Customer".
            - username (str): The username of the requester.
            - request_received_at (str): The timestamp when the request was received.
            - session_id (str): The session ID for tracking the request.
            - tenant_name (str): The name of the tenant.
    Returns:
        dict: A dictionary containing the response with the following keys:
            - flag (bool): Indicates whether the operation was successful.
            - message (str): A message indicating the result of the operation.
            - rate_plan_list_data (list): A list of rate plans fetched based on the service provider and optimization type.
            - rate_plan_code (list, optional): A list of rate plan codes if the optimization type is "Carrier".
    """
    logging.info(f"### get_assign_rate_plan_optimization_dropdown_data Request Data : {data}")
    # Start time  and date calculation
    start_time = time.time()
    service_provider = data.get("service_provider")
    optimization_type = data.get("optimization_type", "Customer")
    username = data.get("username", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("SessionID", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    try:
        tenant_database = data.get("db_name", "")
        # database Connection
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error(f"### get_assign_rate_plan_optimization_dropdown_data Failed to connect to the database: {str(db_exception)}")
        return {"error": "Database connection failed.", "details": str(db_exception)}
    try:
        # based on the optimization type the rate plans will be fetched
        if optimization_type == "Customer":
            rate_plan_list_data = database.get_data(
                "customerrateplan",
                {"service_provider_name": service_provider, "is_active": True},
                ["rate_plan_name"],
                order={"rate_plan_name": "asc"},  # Rate plan column
            )["rate_plan_name"].to_list()

            response = {
                "flag": True,
                "message": "assign rate plan data fetched successfully",
                "rate_plan_list_data": rate_plan_list_data,
            }
        else:
            carrier_data_query = f'''
                    select carp.friendly_name,carp.rate_plan_code,crp.soc_code from carrier_rate_plan  carp
                    left join customer_rate_plan_jasper_carrier_rate_plan crpjcrp
                    ON carp.id = crpjcrp.jasper_carrier_rate_plan_id and crpjcrp.is_active=true
                    left join customerrateplan crp on crp.id=crpjcrp.customer_rate_plan_id
                    where carp.service_provider='{service_provider}' and carp.is_active=True
                    order by friendly_name asc
                '''
            carrier_data = database.execute_query(carrier_data_query, True)
            carrier_data['temp_name'] = carrier_data['friendly_name'].combine_first(carrier_data['rate_plan_code'])
            rate_plan_list_data = (carrier_data['temp_name'] + ' -- ' + carrier_data['soc_code'].fillna("")).to_list()
            carrier_rate_plan_code = carrier_data["rate_plan_code"].to_list()

            response = {
                "flag": True,
                "message": "assign rate plan data fetched successfully",
                "rate_plan_list_data": rate_plan_list_data,
                "rate_plan_code": carrier_rate_plan_code
            }
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "get_assign_rate_plan_optimization_dropdown_data",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"Get Rate plans by service provider : {service_provider} and optimization type : {optimization_type}",
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### get_assign_rate_plan_optimization_dropdown_data Exception is {e}")
        # Return the data as a JSON response,
        return response

    except Exception as e:
        message = f"Something went wrong while fetching the  rate plans by service provider : {service_provider} and optimization type : {optimization_type}"
        response = {
            "flag": True,
            "message": "unable to fetch the assign rate plan data",
            "rate_plan_list_data": [],
        }
        logging.exception(f"### get_assign_rate_plan_optimization_dropdown_data Something went wrong {e}")

        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_assign_rate_plan_optimization_dropdown_data",
                "created_date": request_received_at,
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### get_assign_rate_plan_optimization_dropdown_data Exception is {e}")
        return response


def charges_upload_status_mail(
    common_utils_database, username, template_name, database, session_id
):
    """
    The charges_upload_status_mail function is responsible for sending an email notification
    regarding the status of a charges upload process. It queries the database for charge
    details based on a specific session ID and attaches the results as an Excel file.
    Depending on the upload status, it sends either a success or failure email,
    while also updating the email audit with relevant details such as the email's subject,
    recipient, and status.
    Args:
        common_utils_database (DB): Database connection for common utilities.
        username (str): The username of the person sending the email.
        template_name (str): The name of the email template to be used.
        database (DB): Database connection for the specific tenant.
        session_id (str): The session ID associated with the charges upload.
    Returns:
        dict: A dictionary indicating the success or failure of the email sending operation.

    """
    if template_name == "Charges Upload Completed":
        query = f"""
            SELECT
                customer_name,session_id,
                msisdn,
                charge_id,
                charge_amount,
                sms_charge_amount,
                billing_period_end_date,
                billing_period_start_date, error_message
            FROM vw_optimization_smi_result_customer_charge_queue
            where session_id='{session_id}'
        """
        result_df = database.execute_query(query, True)
        # Generate an Excel file from the result DataFrame
        blob_data = dataframe_to_blob(result_df)
        # Prepare the email content
        subject = "Charges Uploaded Successfully"

        # Send the email with Excel file attached
        result = send_email(
            template_name=template_name,
            username=username,
            subject=subject,
            attachments=blob_data,  # Pass the blob_data as attachment
        )
    else:
        query = f"""
            SELECT
                customer_name,session_id,
                msisdn,
                charge_id,
                charge_amount,
                sms_charge_amount,
                billing_period_end_date,
                billing_period_start_date, error_message
            FROM vw_optimization_smi_result_customer_charge_queue
            where session_id='{session_id}'
        """
        result_df = database.execute_query(query, True)
        # Generate an Excel file from the result DataFrame
        blob_data = dataframe_to_blob(result_df)
        # Prepare the email content
        subject = "Charges Uploaded Failed!!"
        # Send the email with Excel file attached
        result = send_email(
            template_name=template_name,
            username=username,
            subject=subject,
            attachments=blob_data,  # Pass the blob_data as attachment
        )

        # Handle email sending result and update audit
        if isinstance(result, dict) and result.get("flag") is False:
            to_emails = result.get("to_emails")
            cc_emails = result.get("cc_emails")
            subject = result.get("subject")
            from_email = result.get("from_email")
            partner_name = result.get("partner_name")
            body = result.get("body")

            # Email failed - log failure in email audit
            email_audit_data = {
                "template_name": template_name,
                "email_type": "Application",
                "partner_name": partner_name,
                "email_status": "failure",
                "from_email": from_email,
                "to_email": to_emails,
                "cc_email": cc_emails,
                "action": "Email sending failed",
                "comments": "Email sending failed",
                "subject": subject,
                "body": body,
            }
            common_utils_database.update_audit(email_audit_data, "email_audit")
            logging.exception(f"### charges_upload_status_mail Failed to send email: {email_audit_data}")
        else:
            to_emails, cc_emails, subject, from_email, body, partner_name = result

            query = """
                        SELECT parents_module_name, sub_module_name, child_module_name,
                          partner_name
                        FROM email_templates
                        WHERE template_name = %s
                    """

            params = [template_name]
            # Execute the query with template_name as the parameter
            email_template_data = common_utils_database.execute_query(
                query, params=params
            )
            parents_module_name, sub_module_name, child_module_name, partner_name = (
                email_template_data[0]
            )

            # Email success - log success in email audit
            email_audit_data = {
                "template_name": template_name,
                "email_type": "Application",
                "partner_name": partner_name,
                "email_status": "success",
                "from_email": from_email,
                "to_email": to_emails,
                "cc_email": cc_emails,
                "comments": "Report Email sent successfully",
                "subject": subject,
                "body": body,
                "action": "Email triggered",
                "parents_module_name": parents_module_name,
                "sub_module_name": sub_module_name,
                "child_module_name": child_module_name,
            }
            common_utils_database.update_audit(email_audit_data, "email_audit")
            logging.info(f"### charges_upload_status_mail Email sent successfully: {email_audit_data}")
    return {"flag": True}


def push_charges_submit(data):
    """
    The push_charges_submit function handles the submission of customer charges
    for a specific session. It builds a POST request payload with session details
    (SessionId, selectedInstances, selectedUsageInstances, and pushType) and sends
    it to the configured API endpoint for processing. The function dynamically retrieves
    the tenant_id and uses it in the headers. It returns the API response,
    including status code and message, while logging errors in case of failure.
    Args:
        data (dict): A dictionary containing the session details, including:
            - username: The username of the user making the request
            - tenant_name: The name of the tenant
            - SessionId: The session ID for the charges submission
            - selectedInstances: A list of selected instance IDs
            - selectedUsageInstances: A list of selected usage instance IDs
            - pushType: The type of push operation (e.g., "push", "sync")
    Returns:
        dict: A dictionary containing the API response, including:
            - status_code: The HTTP status code of the response
            - message: A message indicating the success or failure of the operation
    """
    logging.info(f"### push_charges_submit Request data Recieved : {data}")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    session_id = data.get("SessionId", "")
    selected_instances = data.get(
        "selectedInstances", ""
    )  # Placeholder, needs to be discussed
    selected_usage_instances = data.get(
        "selectedUsageInstances", ""
    )  # Placeholder, needs to be discussed
    push_type = data.get("pushType", "")
    # Convert `selectedInstances` to a comma-separated string
    if isinstance(selected_instances, list):
        selected_instances = ",".join(map(str, selected_instances))
    # Convert `selectedUsageInstances` to an empty string if it is None
    if isinstance(selected_usage_instances, list):
        selected_usage_instances = ",".join(map(str, selected_usage_instances))
    elif selected_usage_instances is None:
        selected_usage_instances = ""  # If None, set to an empty string
    # Connect to the database to get tenant_id
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    optimization_list_view_id = data.get("optimization_list_view_id", "")
    try:
        instance_ids = data[
            "selectedInstances"
        ]  # Assuming data is the provided dictionary
        sync_instance_ids = tuple(data["selectedInstances"])
        instance_ids_str = ",".join(
            map(str, instance_ids)
        )  # Convert list to comma-separated string

        # Update the query to include the instance_ids
        number_of_charges_to_push_query = f"""
            SELECT
                SUM(device_count) AS total_device_count,
                SUM(total_charges) AS total_usage_charges,
                SUM(sms_charge_total) AS total_sms_charges
            FROM vw_optimization_high_usage_customers
            WHERE instance_id IN ({instance_ids_str})
        """

        # Execute the query
        result = database.execute_query(number_of_charges_to_push_query, True)

        # Extract the calculated sums
        device_count = int(result["total_device_count"].to_list()[0] or 0)
        total_usage_charges = float(result["total_usage_charges"].to_list()[0] or 0)
        total_sms_charges = float(result["total_sms_charges"].to_list()[0] or 0)
        # Update the `optimization_session` table with the calculated values
        database.update_dict(
            "optimization_session",
            {
                "optimization_status_syncs": device_count,
                "total_usage_charges_20": total_usage_charges,
                "total_sms_charges_20": total_sms_charges,
                "push_charge_page": True,
            },
            {"id": optimization_list_view_id},
        )
    except Exception as e:
        logging.warning(f"### push_charges_submit Exception is {e}")
    service_provider_id = data.get("service_provider_id", "")
    service_provider_ids = data.get("service_provider_ids", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        username = os.getenv("ONEPOINTOOPTIMIZATIONUSERNAME", "")
        password = os.getenv("ONEPOINTOOPTIMIZATIONPASSWORD", "")
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode("utf-8")).decode(
            "utf-8"
        )
        authorization_header = f"Basic {encoded_credentials}"

        # Retrieve tenant_id once
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]

        # Define the URL for customer charges upload
        url = os.getenv("OPTIMIZATIONAPI_CREATECOMFIRM_SESSION", "")
        one_pointo_user = os.getenv("ONEPOINTOUSER", "")
        headers = {
            "Authorization": authorization_header,
            "user-name": one_pointo_user,
            "x-tenant-id": str(tenant_id),
            "Content-Type": "application/json",
        }

        # Create the request body dynamically
        body = {
            "SessionId": session_id,
            "selectedInstances": selected_instances,
            "selectedUsageInstances": selected_usage_instances,
            "pushType": push_type,
        }
        logging.info("Sending POST request to %s", url)
        logging.info("Headers: %s", headers)
        logging.info("Body: %s", json.dumps(body, indent=2))
        # Send the POST request to the main API
        response = requests.post(
            url, headers=headers, data=json.dumps(body), timeout=60
        )
        logging.info(f"### push_charges_submit Push charges  API response: {response.json()}")
        # Async send sync API request in a separate thread
        # Send the POST request to the synchronization API
        sync_url = os.getenv("PUSHCHARGESSYNCURL", "")
        try:
            service_provider_id=int(service_provider_id)
        except Exception as e:
            logging.exception(f"### push_charges_submit Failed to convert service_provider_id to integer : {e}")
        sync_payload = {
            "data": {
                "path": "/push_charges_sync",
                "key_name": "optimization_sync_push_charges",
                "session_id": optimization_list_view_id,
                "service_provider_id": service_provider_id,
                "service_provider_ids":service_provider_ids,
                "instance_id": sync_instance_ids,
                "total": device_count,
                "sync_call_first": True,"tenant_name":tenant_name
            }
        }
        logging.info(f"### push_charges_submit sync_payload : {sync_payload}")
        try:
            sync_response = requests.post(sync_url, json=sync_payload)
            logging.info(f"### push_charges_submit Sync API response: {sync_response.json()}")
            if sync_response.status_code == 200:
                current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                logging.info(
                    f"### push_charges_submit API call successful. Data sync completed at {current_timestamp}"
                )
            else:
                logging.error(
                    f"### push_charges_submit API sync call failed with status code: {sync_response.status_code}"
                )
        except Exception as sync_exception:
            logging.error(
                f"### push_charges_submit Error occurred while calling the sync API: {sync_exception}"
            )

        # Prepare the response data
        response_data = {
            "flag": True,
            "status code": response.status_code,
            "message": response.json() if response.content else "No Content",
        }

        # Async email sending
        def send_mail():
            try:
                charges_upload_status_mail(
                    common_utils_database,
                    username,
                    "Charges Upload Completed",
                    database,
                    session_id,
                )
            except Exception as e:
                logging.exception(f"### push_charges_submit Failed to send the mail: {e}")

        threading.Thread(target=send_mail).start()

        return response_data

    except Exception as e:
        logging.exception(f"### push_charges_submit Error uploading customer charges data: {e}")

        # Async failure email
        def send_failure_mail():
            try:
                charges_upload_status_mail(
                    common_utils_database,
                    username,
                    "Charges Upload Failure",
                    database,
                    session_id,
                )
            except Exception as e:
                logging.exception(f"### push_charges_submit Failed to send the mail: {e}")

        threading.Thread(target=send_failure_mail).start()
        return {"flag": False, "error": str(e)}


def update_push_charges_data_optimization(data):
    """
    The function update_push_charges_data_optimization(data)
    updates "push charges data" into a database
    Args:
        data (dict): A dictionary containing the following keys:
            - tenant_name (str): The name of the tenant.
            - db_name (str): The name of the database.
            - changed_data (dict): The data to be updated in the database.
    Returns:
        dict: A dictionary containing the status of the update operation.
    """
    logging.info(f"#### update_push_charges_data_optimization request data : {data}")
    tenant_name = data.get("tenant_name", "")
    # Database connection
    tenant_database = data.get("db_name", "")
    start_time = time.time()
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("SessionID", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    logging.info(f"### update_push_charges_data_optimization Request data Recieved : {data}")
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error(f"### update_push_charges_data_optimization Failed to connect to the database: {str(db_exception)}")
        return {"error": "Database connection failed.", "details": str(db_exception)}
    try:
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]
        submit_data = data.get("changed_data", "")
        submit_data["tenant_id"] = tenant_id
        database.insert_data(submit_data, "sim_management_bulk_change")
        response = {"flag": True, "message": "Push charges data updated Successfully!!"}
        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "update_push_charges_data_optimization",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(changed_data),
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"### update_optimization_actions_data Failed to log the audit data: {e}")
        return response
    except Exception as e:
        logging.exception(f"### update_push_charges_data_optimization Exception is {e}")
        response = {"flag": False, "message": "Push charges data updation failed!!"}
        error_data = {
            "service_name": "update_push_charges_data_optimization",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "tenant_name": tenant_name,
            "comments": json.dumps(changed_data),
            "module_name": "Optimization",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return response


def dataframe_to_blob(data_frame):
    """
    Description:The Function is used to convert the dataframe to blob
    Args:
        data_frame (pd.DataFrame): The DataFrame to be converted to a blob.
    Returns:
        bytes: The blob data representing the DataFrame in Excel format.
    """
    # Create a BytesIO buffer
    bio = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        data_frame.to_excel(writer, index=False)

    # Get the value from the buffer
    bio.seek(0)
    blob_data = base64.b64encode(bio.read())
    return blob_data


def get_export_status(data):
    """
    Retrieves the export status for a given module from the export_status table.

    Args:
        data (dict): Dictionary containing at least the 'module_name' key.

    Returns:
        dict: A dictionary with:
            - 'flag' (bool): True if the query was successful, False otherwise.
            - 'export_status_data' (dict or list): The export status record for the module, or an empty list if not found or on error.
    """
    logging.info(f"### get_export_status request data : {data}")
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        module_name = data.get("module_name")
        export_status_query = (
            f"select * from export_status where module_name='{module_name}'"
        )
        export_status_data = common_utils_database.execute_query(
            export_status_query, True
        ).to_dict(orient="records")
        return {"flag": True, "export_status_data": export_status_data[0]}
    except Exception as e:
        logging.exception(f"### get_export_status Exception is {e}")
        return {"flag": False, "export_status_data": []}


def get_total_cost_for_session(session_id,tenant_name):
    """The get_total_cost_for_session function retrieves the total cost for a given optimization session
    by querying the database.
    Args:
        session_id (int): The ID of the optimization session for which to retrieve the total cost
        tenant_name (str): The name of the tenant to connect to the database
    Returns:
        float: The total cost for the session, rounded to two decimal places
    """
    creds = get_db_credentials(tenant_name)
    if creds:
        server = creds["server"]
        database = creds["database_name"]
        username = creds["username"]
        password = creds["password"]
        port = creds["port"]
    else:
        # Define database connection parameters
        server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
        database = os.environ["ONEPOINTODATABASE"]
        username = os.environ["ONEPOINTOUSERNAME"]
        password = os.environ["ONEPOINTOPASSWORD"]

    # Query to calculate SUM(TotalCost) for the given OptimizationSessionId
    query = f"""
        SELECT SUM(TotalCost) AS TotalCostSum
        FROM vwOptimizationInstance
        WHERE OptimizationSessionId = {session_id}
    """

    total_cost_sum = 0.00  # Default value if no results or invalid data

    with pytds.connect(
        server=server, database=database, user=username, password=password
    ) as conn:
        cursor = conn.cursor()
        cursor.execute(query)
        result = cursor.fetchone()

        if result and result[0] is not None:
            # Convert result[0] to float, regardless of type
            try:
                total_cost_sum = round(float(result[0]), 2)
            except (ValueError, TypeError):
                logging.warning(f"### get_total_cost_for_session Error converting total cost: {result[0]}")

    return total_cost_sum





def get_optimization_progress_bar_data(data):
    '''
    The get_optimization_progress_bar_data function processes optimization progress data,
    updates the optimization session details, and retrieves the total cost for a given session.
    It handles database connections, retrieves tenant information, and updates the optimization details
    based on the provided data. The function also manages cross-carrier optimization settings
    Args:
        data (dict): A dictionary containing optimization progress data, including job name,
        session ID, progress, device count, error message, customer ID, and additional JSON data.
    Returns:
        dict: A response dictionary indicating success or failure of the operation.
    '''
    start_time = time.time()
    logging.info(f"### get_optimization_progress_bar_data data : {data}")

    job_name = data.get("job_name", "")
    optimization_session_id = data.get("SessionId", "")
    progress = data.get("Progress", "")
    progressed_device_count = data.get("DeviceCount", "")
    error_message = data.get("ErrorMessage", "")
    customer_id = data.get("CustomerId", "")
    session_id = data.get("OptimizationSessionGuid")
    tenant_name=data.get('tenant_name','Altaworx')
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        additional_dataa = json.loads(data['AdditionalJson'])
        # Extract TenantId
        tenant_id = additional_dataa.get('data', {}).get('TenantId',None)
    except Exception as e:
        logging.exception(f"### get_optimization_progress_bar_data Exception while removing tenant_id{e}")
        tenant_id = data.get('TenantId', None)
    #tenant_id=data.get('TenantId',1)
    tenant_id=int(tenant_id)
    logging.info(f"Tenant ID is: {tenant_id}")
    tenant_details=common_utils_database.get_data(
        "tenant", {"id": tenant_id}, ["db_name","tenant_name","parent_tenant_id"])
    tenant_name_to_use= tenant_details["tenant_name"].to_list()[0]
    tenant_name=tenant_name_to_use
    db_name= tenant_details["db_name"].to_list()[0]
    parent_tenant_id = tenant_details["parent_tenant_id"].to_list()[0]
    logging.info('db_name',db_name,'tenant_name',tenant_name_to_use,'parent_tenant_id',parent_tenant_id)
    if parent_tenant_id and parent_tenant_id is not None:
        optimization_setting_table='optimization_setting_tenant_override'
    else:
        optimization_setting_table='optimization_setting'

    # Database Connection
    tenant_database = data.get("db_name", "")
    try:
        database = DB(db_name, **db_config)
    except:
        database = DB("altaworx_central", **db_config)
    updated_data = {
        "optimization_session_id": optimization_session_id,
        "progress": progress,
        "error_message": error_message,
        "customer_id": customer_id,
        "session_id": session_id,
    }
    try:
        # Attempt to retrieve the value from the 'tenant' tablee
        cross_carrier_optimization = database.get_data(
            optimization_setting_table,
            {"tenant_id":tenant_id},
            ["optino_cross_providercustomer_optimization"],
        )["optino_cross_providercustomer_optimization"].to_list()[0]
    except Exception as e:
        logging.exception(f"### get_optimization_progress_bar_data Failed to get the cross_carrier_optimization{e}")
        cross_carrier_optimization = False
    try:
        total_cost = get_total_cost_for_session(optimization_session_id,tenant_name_to_use)
        logging.info(f"### get_optimization_progress_bar_data Total cost for session {optimization_session_id}: {total_cost}")
    except Exception as e:
        logging.exception(f"### get_optimization_progress_bar_data Exception  while getting total charges exception is {e}")
        total_cost = 0
    try:
        if job_name == "ErrorMessage":
            insert_id = database.insert_data(updated_data, "optimization_details")
            response = {"flag": True, "message": "Call Successful"}
            return response
        else:

            # Check if details_id exists
            details_data = database.get_data(
                "optimization_session", {"id": optimization_session_id}, ["id"]
            )
            if progress != 50:
                if not details_data.empty:
                    details_id = details_data["id"].to_list()[0]
                    updated_data.pop("session_id")  # Remove the key before updating
                    database.update_dict(
                        "optimization_details",
                        updated_data,
                        {"optimization_session_id": str(details_id)},
                    )
                    optimization_session_update_data = {
                        "progress": progress,
                        "device_count_20": progressed_device_count,
                        "total_charges_20": total_cost,
                    }
                    database.update_dict(
                        "optimization_session",
                        optimization_session_update_data,
                        {"session_id": session_id},
                    )
                else:
                    details_id = None
                    # Check if 'AdditionalJson' exists and parse it safely
                    if "AdditionalJson" in data and data["AdditionalJson"] is not None:
                        try:
                            additional_json_data = json.loads(data["AdditionalJson"])
                            logging.info(additional_json_data, "additional_json_data")
                            if "data" in additional_json_data and isinstance(
                                additional_json_data["data"], dict
                            ):
                                optimization_type = additional_json_data["data"].get(
                                    "OptimizationType"
                                )
                                if (
                                        optimization_type == "Carrier"
                                        or optimization_type == 0
                                    ):
                                        optimization_type_id_check = 0
                                else:
                                    optimization_type_id_check = 1

                                if cross_carrier_optimization and optimization_type_id_check==1:
                                    service_provider_str = additional_json_data["data"].get("ServiceProviderIds", "")
                                    # Convert the string to an actual list
                                    if service_provider_str.startswith("[") and service_provider_str.endswith("]"):
                                        service_provider_list = ast.literal_eval(service_provider_str)
                                    else:
                                        service_provider_list = service_provider_str.split(",")

                                    # ✅ Trim spaces and convert to proper format
                                    service_provider_ids = ", ".join(map(str, map(int, service_provider_list)))
                                else:
                                    service_provider_id = additional_json_data["data"].get(
                                        "ServiceProviderId"
                                    )

                                billing_period_start_date = additional_json_data[
                                    "data"
                                ].get("BillingPeriodStartDate")
                                billing_period_end_date = additional_json_data[
                                    "data"
                                ].get("BillingPeriodEndDate")
                                device_count_20 = additional_json_data["data"].get(
                                    "DeviceCount"
                                )
                                if cross_carrier_optimization and optimization_type_id_check==1:
                                    if service_provider_ids is None :
                                        logging.warning(
                                            "### get_optimization_progress_bar_data ServiceProviderIds is missing in AdditionalJson"
                                        )

                                if (
                                     optimization_type is None
                                ):
                                    logging.warning(
                                        "### get_optimization_progress_bar_data OptimizationType is missing in AdditionalJson"
                                    )
                                else:
                                    if (
                                        optimization_type == "Carrier"
                                        or optimization_type == 0
                                    ):
                                        optimization_type_id = 0
                                    else:
                                        optimization_type_id = 1
                                    if cross_carrier_optimization and optimization_type_id==1:
                                    # Prepare data for optimization session
                                        optimization_session_data = {
                                            "session_id": session_id,
                                            "is_active": True,
                                            "optimization_type_id": optimization_type_id,
                                            "service_provider_ids": service_provider_ids,
                                            "is_deleted": False,
                                            "progress": progress,
                                            "optimization_run_start_date": datetime.now(),  # Current timestamp
                                            "billing_period_end_date": billing_period_end_date,
                                            "billing_period_start_date": billing_period_start_date,
                                            "device_count_20": device_count_20,
                                            "tenant_id":tenant_id,
                                            "flag_20":True
                                        }
                                    else:
                                        optimization_session_data = {
                                            "session_id": session_id,
                                            "is_active": True,
                                            "optimization_type_id": optimization_type_id,
                                            "service_provider_id": service_provider_id,
                                            "is_deleted": False,
                                            "progress": progress,
                                            "optimization_run_start_date": datetime.now(),  # Current timestamp
                                            "billing_period_end_date": billing_period_end_date,
                                            "billing_period_start_date": billing_period_start_date,
                                            "device_count_20": device_count_20,
                                            "tenant_id":tenant_id,
                                            "flag_20":True
                                        }

                                    # Add optimization_type_id to updated_data dictionary
                                    updated_data["optimization_type_id"] = (
                                        optimization_type_id
                                    )
                                    try:
                                        insert_id = database.insert_data(
                                            updated_data, "optimization_details"
                                        )
                                    except Exception as e:
                                        logging.exception(
                                            f"### get_optimization_progress_bar_data Exception is coming while updating optimization details : {e}"
                                        )
                                    optimization_id = database.insert_data(
                                        optimization_session_data,
                                        "optimization_session",
                                    )
                                    if cross_carrier_optimization  and optimization_type_id==1:
                                        optimization_instance_data = {
                                            "run_status_id": 6,
                                            "service_provider_ids": service_provider_ids,
                                            "optimization_session_id": optimization_id,
                                            "is_deleted": False,
                                        }
                                    else:
                                        optimization_instance_data = {
                                            "run_status_id": 6,
                                            "service_provider_id": service_provider_id,
                                            "optimization_session_id": optimization_id,
                                            "is_deleted": False,
                                        }

                                    optimization_instance_id = database.insert_data(
                                        optimization_instance_data,
                                        "optimization_instance",
                                    )
                                    ##Duplicate Lines Handling
                                    if progress==0:
                                        # Prepare the data to send in the API request
                                        api_url = os.getenv("OPTIMIZATIONSYNCURL", " ")
                                        api_payload = {
                                            "data": {
                                                "path": "/lambda_sync_jobs_",
                                                "key_name": "optimization_sync_session",
                                                "session_id": session_id,"tenant_name":tenant_name,"tenant_id":tenant_id
                                            }
                                        }
                                        # Send the POST request
                                        try:
                                            response = requests.post(api_url, json=api_payload)
                                            if response.status_code == 200:
                                                # Get the current timestamp
                                                current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                                                # Log the message with the timestamp
                                                logging.info(
                                                    f"### get_optimization_progress_bar_data API call successful for Duplicate Lines Handling. Data sync call is successfully done at {current_timestamp}"
                                                )
                                                # logging.info("API call successful.Data synn call is succssefully done ")
                                            else:
                                                logging.error(
                                                    f"### get_optimization_progress_bar_data API call failed with status code for Handling Duplicates: {response.status_code}"
                                                )
                                        except Exception as e:
                                            logging.error(f"### get_optimization_progress_bar_data Error occurred while calling the API for handling duplicate lines: {e}")

                            else:
                                logging.warning(
                                    "### get_optimization_progress_bar_data The 'data' subfield within 'AdditionalJson' is not found or is not a dictionary."
                                )
                        except (json.JSONDecodeError, TypeError) as e:
                            logging.warning(f"### get_optimization_progress_bar_data Failed to parse 'AdditionalJson': {e}")
                    else:
                        logging.warning(
                            "### get_optimization_progress_bar_data The 'AdditionalJson' field is not found or is None."
                        )
            # Check if progress is 100, if so, hit the API
            else:
                logging.info('Progress is 50, hitting the API')
                optimization_session_update_data = {"progress": progress}
                database.update_dict(
                    "optimization_session",
                    optimization_session_update_data,
                    {"session_id": session_id},
                )
                # Prepare the data to send in the API request
                api_url = os.getenv("OPTIMIZATIONSYNCURL", " ")
                api_payload = {
                    "data": {
                        "path": "/lambda_sync_jobs_",
                        "key_name": "optimization_sync",
                        "session_id": session_id,"tenant_name":tenant_name,"tenant_id":tenant_id
                    }
                }
                # Send the POST request
                try:
                    response = requests.post(api_url, json=api_payload)
                    if response.status_code == 200:
                        # Get the current timestamp
                        current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                        # Log the message with the timestamp
                        logging.info(
                            f"### get_optimization_progress_bar_data API call successful. Data sync call is successfully done at {current_timestamp}"
                        )
                        # logging.info("API call successful.Data synn call is succssefully done ")
                    else:
                        logging.error(
                            f"### get_optimization_progress_bar_data API call failed with statudafdfadsfs code: {response.status_code}"
                        )

                    ##if auto update rate plan is enabled then only call the api
                    try:
                        optimization_type_idd = database.get_data(
                            "optimization_session",
                            {"id": optimization_session_id},
                            ["optimization_type_id"],
                        )["optimization_type_id"].to_list()[0]
                        if optimization_type_idd == 0:
                            if optimization_setting_table=='optimization_setting_tenant_override':
                                rate_plan_button_status=True
                            else:
                                rate_plan_button_status = database.get_data(
                                    optimization_setting_table, {"tenant_id":tenant_id}, ["auto_update_rateplans"]
                                )["auto_update_rateplans"].to_list()[0]
                            if rate_plan_button_status:
                                # Prepare the data to send in the API request
                                auto_update_rate_plan_api_url = os.getenv(
                                    "OPTIMIZATIONSYNCURL", " "
                                )
                                auto_update_api_payload = {
                                    "data": {
                                        "path": "/lambda_sync_jobs_",
                                        "key_name": "optimization_rate_plan_sync",
                                        "tenant_name":tenant_name
                                    }
                                }
                                auto_update_response = requests.post(
                                    auto_update_rate_plan_api_url,
                                    json=auto_update_api_payload,
                                )
                                if auto_update_response.status_code == 200:
                                    # Get the current timestamp
                                    current_timestamp = datetime.now().strftime(
                                        "%Y-%m-%d %H:%M:%S"
                                    )

                                    # Log the message with the timestamp
                                    logging.info(
                                        f"### get_optimization_progress_bar_data API call successful.Auto Update data sync call is successfully done at {current_timestamp}"
                                    )
                                else:
                                    logging.error(
                                        f"### get_optimization_progress_bar_data API call failed with Status code: {auto_update_response.status_code}"
                                    )
                    except Exception as e:
                        logging.exception(f"### get_optimization_progress_bar_data Exception is {e}")
                except Exception as e:
                    logging.error(f"### get_optimization_progress_bar_data Error occurred while calling the API: {e}")
            response = {"flag": True, "message": "Call Successful"}
            try:# End time and audit logging
                end_time = time.time()
                time_consumed = f"{end_time - start_time:.4f}"
                time_consumed = int(float(time_consumed))
                audit_data_user_actions = {
                    "service_name": "get_optimization_progress_bar_data",
                    "created_by": "1.0 API HIT",
                    "status": str(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "session_id": session_id,
                    "tenant_name": tenant_name,
                    "comments": f"Optimization progress bar data fetched successfully for session {session_id} and progress {progress}",
                    "module_name": "Optimization",   
                }
                common_utils_database.update_audit(
                    audit_data_user_actions, "audit_user_actions"
                )
            except Exception as e:
                logging.exception(f"### get_optimization_progress_bar_data Exception while logging audit data: {e}")
            return response
    except Exception as e:
        logging.exception(f"### get_optimization_progress_bar_data Exception is {e}")
        response = {"flag": False, "message": f"Call Failed {e}"}
        message=f"Failed to get the Optimization progress bar data for session {session_id} and progress {progress}"
        try:
            error_type = str(type(e).__name__)
            # Error logging
            error_data = {
                "service_name": "get_optimization_progress_bar_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": "1.0 API HIT",
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Optimization",
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as error_logging_exception:
            logging.exception(f"### get_optimization_progress_bar_data Exception while preparing error data: {error_logging_exception}")
        return response





def get_optimization_error_details_data(data):
    """The get_optimization_error_details_data function retrieves optimization error details
    based on the provided session ID and updates the optimization details in the database.
    Args:
        data (dict): Contains information such as SessionId, ErrorMessage, CustomerId,
        AdditionalJson, and TenantId.
    Returns:
        dict: A dictionary containing the status of the operation and a message.
    """
    logging.info(f"### get_optimization_error_details_data function started : {data}")
    start_time = time.time()
    session_id = data.get("SessionID", "")
    username = data.get("username", "")

    # job_name = data.get("job_name", "")
    optimization_session_id = data.get("SessionId", "")
    error_message = data.get("ErrorMessage", "")
    customer_id = data.get("CustomerId", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    # Extract TenantId
    try:
        additional_dataa = json.loads(data['AdditionalJson'])
        tenant_id = additional_dataa.get('data', {}).get('TenantId',None)
    except Exception as e:
        logging.exception(f"### get_optimization_error_details_data Exception while parsing AdditionalJson: {e}")
        tenant_id = data.get('TenantId', None)
    tenant_id=int(tenant_id)
    logging.info(f"Tenant ID is: {tenant_id}")
    db_name = common_utils_database.get_data(
        "tenant", {"id": tenant_id}, ["db_name"]
    )["db_name"].to_list()[0]
    logging.info('db_name',db_name)
    # Database Connection
    tenant_database = data.get("db_name", "")
    try:
        database = DB(db_name, **db_config)
    except Exception as e:
        logging.exception(f"### get_optimization_error_details_data Exception while connecting to database: {e}")
        database = DB("altaworx_central", **db_config)
    optimization_type_id = database.get_data(
        "optimization_details",
        {"optimization_session_id": optimization_session_id},
        ["optimization_type_id"],
    )["optimization_type_id"].to_list()[0]
    updated_data = {
        "optimization_session_id": optimization_session_id,
        "error_message": error_message,
        "customer_id": customer_id,
        "optimization_type_id": optimization_type_id,
    }
    try:
        if not customer_id:
            updated_data.pop(
                "optimization_session_id"
            )  # Remove the key before updating
            updated_data.pop("customer_id")  # Remove the key before updating
            updated_data.pop("optimization_type_id")  # Remove the key before updating
            database.update_dict(
                "optimization_details",
                updated_data,
                {"optimization_session_id": optimization_session_id},
            )

        else:
            # Check if details_id exists
            details_data = database.get_data(
                "optimization_details",
                {"customer_id": customer_id,"optimization_session_id":optimization_session_id},
                ["customer_id", "session_id"],
            )
            if not details_data.empty:
                details_id = details_data["customer_id"].to_list()[0]
                updated_data.pop(
                    "optimization_session_id"
                )  # Remove the key before updating
                updated_data.pop("customer_id")  # Remove the key before updating
                updated_data.pop(
                    "optimization_type_id"
                )  # Remove the key before updating
                database.update_dict(
                    "optimization_details", updated_data, {"customer_id": customer_id}
                )
            else:
                insert_id = database.insert_data(updated_data, "optimization_details")

        response = {"flag": True, "message": "Call Successfull"}
        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "get_optimization_error_details_data",
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Optimization error details data fetched successfully for session {session_id} and error message {error_message}",
                "module_name": "Optimization",
                "request_received_at": data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"### update_optimization_actions_data Failed to log the audit data: {e}")
        return response
    except Exception as e:
        logging.exception(f"### get_optimization_error_details_data Exception is {e}")
        message = f"call failed{e}"
        response = {"flag": False, "message": message}
        error_data = {
            "service_name": "get_optimization_error_details_data",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"Optimization error details data failed for session {session_id} and error message {error_message}",
            "module_name": "Optimization",
            "request_received_at": data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return response


# Function to get optimization sessions by tenant ID
def get_optimization_sessions_by_tenant_id(tenant_id, optimization_type, filter_str,tenant_name):
    """The get_optimization_sessions_by_tenant_id function retrieves optimization sessions
    for a given tenant ID and optimization type, with optional filtering.
    Args:
        tenant_id (int): The ID of the tenant for which to retrieve optimization sessions.
        optimization_type (str): The type of optimization sessions to retrieve (e.g., "All", "Carrier", "Cross-Carrier").
        filter_str (str): An optional filter string to apply to the results.
        tenant_name (str): The name of the tenant for which to retrieve optimization sessions.
    Returns:
        list: A list of tuples containing optimization session details.
    """
    creds = get_db_credentials(tenant_name)
    if creds:
        server = creds["server"]
        database = creds["database_name"]
        username = creds["username"]
        password = creds["password"]
        port = creds["port"]
    else:
        # Define database connection parameters
        server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
        database = os.environ["ONEPOINTODATABASE"]
        username = os.environ["ONEPOINTOUSERNAME"]
        password = os.environ["ONEPOINTOPASSWORD"]
    query = ""
    if optimization_type == "All":
        query = f"""
            SELECT *
            FROM vwOptimizationSession
            WHERE TenantId = {tenant_id}
            AND IsActive = 1
            AND IsDeleted = 0
            ORDER BY CreatedDate DESC
        """
    else:
        query = f"""
            SELECT *
            FROM vwOptimizationSession
            WHERE TenantId = {tenant_id}
            AND OptimizationTypeId = {int(optimization_type)}
            AND IsActive = 1
            AND IsDeleted = 0
            ORDER BY CreatedDate DESC
        """

    # Connect to the database and execute the query
    with pytds.connect(
        server=server, database=database, user=username, password=password
    ) as conn:
        cursor = conn.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()

        # Apply filter if provided
        if filter_str:
            filter_str = filter_str.lower()
            rows = [
                row
                for row in rows
                if (row.service_provider and filter_str in row.service_provider.lower())
                or (
                    row.billing_period_end_date
                    and filter_str in str(row.billing_period_end_date)
                )
            ]

        return rows


# Function to get running optimization sessions
def get_optimization_running(tenant_name):
    """The get_optimization_running function retrieves the list of currently running
    optimization sessions for a given tenant.
    Args:
        tenant_name (str): The name of the tenant for which to retrieve running optimization sessions.
    Returns:
        list: A list of dictionaries containing details of running optimization sessions.
    """
    creds = get_db_credentials(tenant_name)
    if creds:
        server = creds["server"]
        database = creds["database_name"]
        username = creds["username"]
        password = creds["password"]
        port = creds["port"]
    else:
        # Define database connection parameters
        server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
        database = os.environ["ONEPOINTODATABASE"]
        username = os.environ["ONEPOINTOUSERNAME"]
        password = os.environ["ONEPOINTOPASSWORD"]
    query = """
        SELECT *
        FROM vwOptimizationSessionRunning
        ORDER BY OptimizationSessionId DESC
    """

    with pytds.connect(
        server=server, database=database, user=username, password=password
    ) as conn:
        cursor = conn.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        columns = [column[0] for column in cursor.description]
        return [dict(zip(columns, row)) for row in rows]


# Function to check if optimization is running
def check_optimization_is_running(tenant_id,tenant_name):
    """The check_optimization_is_running function checks if there are any running
    optimization sessions for a given tenant ID and returns a boolean indicating
    whether the optimization session is running without errors.
    Args:
        tenant_id (int): The ID of the tenant to check for running optimization sessions.
        tenant_name (str): The name of the tenant to check for running optimization sessions.
    Returns:
        bool: True if there are running optimization sessions without errors, False otherwise.
    """
    # Get the list of optimization sessions
    optimization_session_list = get_optimization_sessions_by_tenant_id(
        tenant_id, "All", "",tenant_name
    )
    if not optimization_session_list:
        return False

    # Get the list of running optimization sessions
    optimization_session_running_list = get_optimization_running(tenant_name)
    if not optimization_session_running_list:
        return False

    # Assuming the first column in the tuple from optimization_session_list is the 'id'
    optimization_session_id = optimization_session_list[0][
        0
    ]  # Access the 'id' (first element of the tuple)

    # Check if the session is running using dictionary keys for the optimization_session_running_list
    opt_running = [
        x
        for x in optimization_session_running_list
        if x["OptimizationSessionId"] == optimization_session_id
    ]

    if opt_running:
        # Assuming '1' is 'COMPLETE_WITH_ERROR' for OptimizationQueueStatusId and OptimizationInstanceStatusId
        return not any(
            x["OptimizationQueueStatusId"] == 7
            or x["OptimizationInstanceStatusId"] == 7
            for x in opt_running
        )

    return False


# Main function to check optimize button status
def optimize_button_status(data):
    """
    Checks the status of the optimization button for a given tenant.

    Args:
        data (dict): Dictionary containing at least the 'tenant_name' key.

    Returns:
        dict: A dictionary with:
            - 'flag' (bool): Always True.
            - 'optimize_button_status' (bool): True if optimization is running, False otherwise.
    """
    logging.info(f"### optimize_button_status request data : {data}")
    # Database connection parameters
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    tenant_id = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id"]
    )["id"].to_list()[0]

    # Get the status of the optimization button
    optimize_button = check_optimization_is_running(tenant_id,tenant_name)
    return {"flag": True, "optimize_button_status": optimize_button}


def get_push_charges_status(data):
    """The get_push_charges_status function checks the status of the push charges
    for a specific optimization session and returns whether the push charges button
    should be enabled or disabled.
    Args:
        data (dict): Contains information such as session_id and db_name.
    Returns:
        dict: A dictionary containing the status of the push charges button.
    """
    logging.info(f"### get_push_charges_status request data : {data}")
    start_time = time.time()
    session_id = data.get("session_id", "")
    tenant_database = data.get("db_name", "")
    # database Connection
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    database = DB(tenant_database, **db_config)
    # Define the query to check push charges status
    push_charges_status_query = f"""
    SELECT run_status
    FROM vw_optimization_push_charges_data
    WHERE session_id='{session_id}'
    AND run_status IN ('Pending', 'Not Started')
    """

    try:
        # Execute the query to check for any results
        push_charges_status = database.execute_query(push_charges_status_query, True)

        # If the query returns any data, set push_charges_button_status to False
        if push_charges_status.empty:  # Check if any rows are returned
            push_charges_button_status = True
        else:
            push_charges_button_status = False

        # Prepare the response with the button status
        response = {
            "flag": True,
            "push_charges_button_status": push_charges_button_status,
        }
        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "get_push_charges_status",
                "created_by": data.get("username", ""),
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Push charges status fetched successfully for session {session_id} with button status {push_charges_button_status}",
                "module_name": "Optimization",
                "request_received_at": data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"### get_push_charges_status Failed to log the audit data: {e}")
        return response

    except Exception as e:
        logging.exception(f"Error occurred: {e}")
        response = {
            "flag": True,
            "push_charges_button_status": False,
        }  # Default to True on error
        error_data = {
            "service_name": "get_push_charges_status",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"Failed to fetch push charges status for session {session_id}",
            "module_name": "Optimization",
            "request_received_at": data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return response


def get_push_charges_count(data):
    """The get_push_charges_count function retrieves the count of charges to be pushed
    for a specific optimization session, including the total usage and SMS charges.
    Args:
        data (dict): Contains information such as optimization_session_id and db_name.
    Returns:
        dict: A dictionary containing the count of charges to push, remaining charges,
        total usage charges, total SMS charges, and a success message.
    """
    logging.info(f"### get_push_charges_count Function started : {data}")
    start_time = time.time()
    optimization_session_id = data.get("optimization_session_id", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        # Extract optimization session ID from input data
        optimization_session_id = data.get("optimization_session_id", "")
        if not optimization_session_id:
            return {
                "flag": False,
                "error": "Missing Parameters (optimization_session_id)",
            }

        # Extract tenant database name
        tenant_database = data.get("db_name", "")
        if not tenant_database:
            return {"flag": False, "error": "Missing Parameters (db_name)"}

        # Establish database connection
        try:
            database = DB(tenant_database, **db_config)
        except Exception as db_exception:
            logging.error(f"### get_push_charges_count Failed to connect to the database: {str(db_exception)}")
            return {
                "flag": False,
                "error": "Database connection failed.",
                "details": str(db_exception),
            }
        try:
            query = f"""SELECT optimization_status_syncs, push_charges_not_processed_count,total_usage_charges_20,total_sms_charges_20
                        FROM optimization_session WHERE id='{optimization_session_id}' """
            session_result = database.execute_query(query, True)
        except Exception as query_exception:
            logging.error(f"### get_push_charges_count Failed to fetch session data: {str(query_exception)}")
            return {
                "flag": False,
                "error": "Failed to fetch session data.",
                "details": str(query_exception),
            }

        # Check if session_result is valid
        if not isinstance(session_result, pd.DataFrame):
            logging.error(
                f"### get_push_charges_count Expected a DataFrame but got : {type(session_result).__name__}"
            )
            return {
                "flag": False,
                "error": "Invalid data returned from database query.",
            }

        if session_result.empty:
            return {"flag": False, "error": "Optimization session not found."}

        # Extract values from the DataFrame
        try:
            no_of_charges_to_push = int(
                session_result.iloc[0]["optimization_status_syncs"] or 0
            )
            push_charges_processed_count = session_result.iloc[0][
                "push_charges_not_processed_count"
            ]
            logging.info(push_charges_processed_count, "push_charges_processed_count")
            charges_remaining_to_push = no_of_charges_to_push - int(
                push_charges_processed_count or 0
            )
            # Truncate and format total_usage_charges_20 and total_sms_charges_20 with a dollar sign
            total_usage_charges_20 = (
                session_result.iloc[0]["total_usage_charges_20"] or 0
            )
            total_usage_charges_20 = f"${int(total_usage_charges_20 * 100) / 100:,.2f}"

            total_sms_charges = session_result.iloc[0]["total_sms_charges_20"] or 0
            total_sms_charges = f"{int(total_sms_charges * 100) / 100:,.2f}"
        except KeyError as key_error:
            logging.error(
                f"### get_push_charges_count Missing expected columns in session result: {str(key_error)}"
            )
            return {
                "flag": False,
                "error": "Invalid data structure in session result.",
                "details": str(key_error),
            }
        except ValueError as value_error:
            logging.error(f"### get_push_charges_count Invalid data type in session result: {str(value_error)}")
            return {
                "flag": False,
                "error": "Invalid data values in session result.",
                "details": str(value_error),
            }

        # Prepare the success message
        message = "Successfully fetched the count."
        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "get_push_charges_count",
                "created_by": data.get("username", ""),
                "status": True,
                "time_consumed_secs": time_consumed,
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Push charge count fetched successfully for session {optimization_session_id}",
                "module_name": "Optimization",
                "request_received_at": data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"### get_push_charges_count Failed to log the audit data: {e}")
        return {
            "flag": True,
            "no_of_charges_to_push": no_of_charges_to_push,
            "remaining_push_charges_count": charges_remaining_to_push,
            "total_usage_charges_20": total_usage_charges_20,
            "total_sms_charges": total_sms_charges,
            "message": message,
        }

    except Exception as e:
        logging.exception(f"### get_push_charges_count Exception occurred {e}")
        message = "Failed to get the count"
        error_data = {
            "service_name": "get_push_charges_count",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"Failed to fetch push charges count for session {optimization_session_id}",
            "module_name": "Optimization",
            "request_received_at": data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {
            "flag": True,
            "no_of_charges_to_push": 0,
            "remaining_push_charges_count": 0,
            "message": message,
        }


# def get_push_charges_count(data):
#     logging.info("get_push_charges_count Function started")
#     try:
#         # Extract optimization session ID from input data
#         optimization_session_id = data.get("optimization_session_id", "")
#         if not optimization_session_id:
#             return {
#                 "flag": False,
#                 "error": "Missing Parameters (optimization_session_id)",
#             }

#         # Extract tenant database name
#         tenant_database = data.get("db_name", "")
#         if not tenant_database:
#             return {"flag": False, "error": "Missing Parameters (db_name)"}

#         # Establish database connection
#         try:
#             database = DB(tenant_database, **db_config)
#         except Exception as db_exception:
#             logging.error("Failed to connect to the database: %s", str(db_exception))
#             return {
#                 "flag": False,
#                 "error": "Database connection failed.",
#                 "details": str(db_exception),
#             }
#         try:
#             query = f"""SELECT optimization_status_syncs, push_charges_not_processed_count,total_usage_charges_20,total_sms_charges_20
#                         FROM optimization_session WHERE id='{optimization_session_id}' """
#             session_result = database.execute_query(query, True)
#         except Exception as query_exception:
#             logging.error("Failed to fetch session data: %s", str(query_exception))
#             return {
#                 "flag": False,
#                 "error": "Failed to fetch session data.",
#                 "details": str(query_exception),
#             }

#         # Check if session_result is valid
#         if not isinstance(session_result, pd.DataFrame):
#             logging.error(
#                 "Expected a DataFrame but got %s", type(session_result).__name__
#             )
#             return {
#                 "flag": False,
#                 "error": "Invalid data returned from database query.",
#             }

#         if session_result.empty:
#             return {"flag": False, "error": "Optimization session not found."}

#         # Extract values from the DataFrame
#         try:
#             no_of_charges_to_push = int(
#                 session_result.iloc[0]["optimization_status_syncs"] or 0
#             )
#             charges_remaining_to_push = int(
#                 session_result.iloc[0]["push_charges_not_processed_count"] or 0
#             )
#             # Truncate and format total_usage_charges_20 and total_sms_charges_20 with a dollar sign
#             total_usage_charges_20 = (
#                 session_result.iloc[0]["total_usage_charges_20"] or 0
#             )
#             total_usage_charges_20 = f"${int(total_usage_charges_20 * 100) / 100:,.2f}"

#             total_sms_charges = session_result.iloc[0]["total_sms_charges_20"] or 0
#             total_sms_charges = f"{int(total_sms_charges * 100) / 100:,.2f}"
#         except KeyError as key_error:
#             logging.error(
#                 "Missing expected columns in session result: %s", str(key_error)
#             )
#             return {
#                 "flag": False,
#                 "error": "Invalid data structure in session result.",
#                 "details": str(key_error),
#             }
#         except ValueError as value_error:
#             logging.error("Invalid data type in session result: %s", str(value_error))
#             return {
#                 "flag": False,
#                 "error": "Invalid data values in session result.",
#                 "details": str(value_error),
#             }

#         # Prepare the success message
#         message = "Successfully fetched the count."
#         return {
#             "flag": True,
#             "no_of_charges_to_push": no_of_charges_to_push,
#             "remaining_push_charges_count": charges_remaining_to_push,
#             "total_usage_charges_20": total_usage_charges_20,
#             "total_sms_charges": total_sms_charges,
#             "message": message,
#         }

#     except Exception as e:
#         logging.exception("Exception occurred in get_push_charges_count: %s", str(e))
#         message = "Failed to get the count"
#         return {
#             "flag": True,
#             "no_of_charges_to_push": 0,
#             "remaining_push_charges_count": 0,
#             "message": message,
#         }


def rate_plan_progress(data):
    """
    Fetch rate plan progress for a given service provider and instance ID.

    Parameters:
    - data (dict): A dictionary containing 'service_provider_id' and 'instance_id'.

    Returns:
    - tuple: (assignments_queued, assignments_pushed_to_carrier)
    """
    logging.info(f"### rate_plan_progress request data : {data}")
    # Connection details for the OnePointO database
    tenant_name=data.get('tenant_name','')
    start_time = time.time()
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error(f"### get_push_charges_count Failed to connect to the database: {str(db_exception)}")
        return {"error": "Database connection failed.", "details": str(db_exception)}
    tenant_details = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id","parent_tenant_id"]
    )
    tenant_id = tenant_details["id"].to_list()[0]
    parent_tenant_id = tenant_details["parent_tenant_id"].to_list()[0]
    if parent_tenant_id and parent_tenant_id is not None: 
        optimization_setting_table='optimization_setting_tenant_override'
    else:
        optimization_setting_table='optimization_setting'
    creds = get_db_credentials(tenant_name)
    if creds:
        server = creds["server"]
        database_name = creds["database_name"]
        username = creds["username"]
        password = creds["password"]
        port = creds["port"]
    else:
        # Define database connection parameters
        server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
        database_name = os.environ["ONEPOINTODATABASE"]
        username = os.environ["ONEPOINTOUSERNAME"]
        password = os.environ["ONEPOINTOPASSWORD"]

    # Extract parameters from the data dictionary
    service_provider_id = data.get("service_provider_id", 0)
    instance_id = data.get("instance_id", 0)
    optimization_list_view_id = data.get("optimization_list_view_id", 0)
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    # Default values for output
    assignments_queued = 0
    assignments_pushed_to_carrier = 0
    if optimization_setting_table=='optimization_setting_tenant_override':
        rate_plan_status=True
    else:
        rate_plan_status = database.get_data(
            optimization_setting_table, {"tenant_id":tenant_id}, ["auto_update_rateplans"]
        )["auto_update_rateplans"].to_list()[0]
    mobility_service_providers = os.getenv("MOBILITY_SERVICE_PROVIDER_NAMES", "").split("/")
    logging.info(f"Rate Plan Status is {rate_plan_status}")
    try:
        # Construct the query dynamically based on the service provider names
        mobility_service_provider_ids_query = f"""
            SELECT id
            FROM serviceprovider
            WHERE service_provider_name IN ({', '.join(["'" + name.strip() + "'" for name in mobility_service_providers])})
        """
        mobility_service_provider_dataframe = database.execute_query(
            mobility_service_provider_ids_query, True
        )
        # Assuming the result is a Pandas DataFrame, we extract the 'id' column as a list
        if isinstance(mobility_service_provider_dataframe, pd.DataFrame):
            mobility_service_provider_ids = mobility_service_provider_dataframe[
                "id"
            ].tolist()
    except Exception as e:
        logging.warning(f"### rate_plan_progress Exception while fetching the service providers : {e}")
        mobility_service_provider_ids = [0]
    if rate_plan_status:
        try:
            with pytds.connect(
                server=server, database=database_name, user=username, password=password
            ) as conn:
                with conn.cursor() as cursor:

                    stored_procedure_name = (
                        "dbo.usp_Optimization_RatePlanChangeProgressCompleted"
                    )
                    # Execute the stored procedure
                    cursor.callproc(
                        stored_procedure_name, (instance_id, service_provider_id)
                    )
                    logging.info("Successfully called the stored procedure.")

                    # Fetch and assign results
                    results = cursor.fetchall()
                    logging.info(f"Results: {results}")
                    if results:
                        assignments_queued, assignments_pushed_to_carrier = results[0]
                    try:
                        if optimization_setting_table=='optimization_setting_tenant_override':
                            rate_plan_button_status=True
                        else:
                            rate_plan_button_status = database.get_data(
                                optimization_setting_table, {"tenant_id":tenant_id}, ["auto_update_rateplans"]
                            )["auto_update_rateplans"].to_list()[0]
                        if rate_plan_button_status:
                            button_message = "Auto Rate Plan Upload is Enabled"
                        else:
                            button_message = "Auto Rate Plan Upload is Disabled"
                    except Exception as e:
                        logging.exception(f"### rate_plan_progress Exception while fetching the rate plan button status: {e}")
                        rate_plan_button_status = False
                        button_message = "Auto Rate Plan Upload is Disabled"
                    message = "Rate Plan Progress data fetched successfully"
                    response = {
                        "flag": "True",
                        "assignments_queued": assignments_queued,
                        "assignments_pushed_to_carrier": assignments_pushed_to_carrier,
                        "message": message,
                        "button_message": button_message,
                        "rate_plan_button_status": rate_plan_button_status,
                    }
                    return response

        except Exception as e:
            logging.exception(f"### rate_plan_progress An error occurred: {e}")
            message = "Failed to get the Rate Plan Progress data"
            response = {
                "flag": "True",
                "assignments_queued": 0,
                "assignments_pushed_to_carrier": 0,
                "message": message,
            }
            return response
    else:

        try:
            with pytds.connect(
                server=server, database=database_name, user=username, password=password
            ) as conn:
                with conn.cursor() as cursor:
                    # Determine the stored procedure based on service_provider_id
                    if (
                        service_provider_id in mobility_service_provider_ids
                    ):  # Corrected to a tuple
                        stored_procedure_name = (
                            "dbo.usp_Optimization_Mobility_RatePlanChangeProgress"
                        )
                    else:
                        stored_procedure_name = (
                            "dbo.usp_Optimization_RatePlanChangeProgress"
                        )

                    # Execute the stored procedure
                    cursor.callproc(stored_procedure_name, (instance_id,))
                    logging.info("### rate_plan_progress Successfully called the stored procedure.")

                    # Fetch and assign results
                    results = cursor.fetchall()
                    if results:
                        assignments_queued, assignments_pushed_to_carrier = results[0]
                    carrier_assignments_queued = database.get_data(
                        "optimization_session",
                        {"id": optimization_list_view_id},
                        ["carrier_assignments_queued"],
                    )

                    # Check if the DataFrame is empty or the column has no values
                    if (
                        carrier_assignments_queued.empty
                        or carrier_assignments_queued["carrier_assignments_queued"]
                        .isna()
                        .all()
                    ):
                        carrier_assignments_queued_value = 0
                    else:
                        carrier_assignments_queued_value = carrier_assignments_queued[
                            "carrier_assignments_queued"
                        ].iloc[0]
                    # Determine the value of assignments_queued for the response
                    if (
                        assignments_pushed_to_carrier
                        and assignments_pushed_to_carrier > 0
                    ):
                        final_assignments_queued = assignments_queued
                    elif (
                        assignments_pushed_to_carrier is None
                        or assignments_pushed_to_carrier == 0
                    ):
                        final_assignments_queued = carrier_assignments_queued_value
                    else:
                        final_assignments_queued = 0
                    try:
                        if optimization_setting_table=='optimization_setting_tenant_override':
                            rate_plan_button_status=True
                        else:
                            rate_plan_button_status = database.get_data(
                                optimization_setting_table, {"tenant_id":tenant_id}, ["auto_update_rateplans"]
                            )["auto_update_rateplans"].to_list()[0]
                        if rate_plan_button_status:
                            button_message = "Auto Rate Plan Upload is Enabled"
                        else:
                            button_message = "Auto Rate Plan Upload is Disabled"
                    except Exception as e:
                        logging.exception(f"### rate_plan_progress Exception while fetching the rate plan button status: {e}")
                        rate_plan_button_status = False
                        button_message = "Auto Rate Plan Upload is Disabled"
                    message = "Rate Plan Progress data fetched successfully"
                    try:
                        # End time and audit logging
                        end_time = time.time()
                        time_consumed = f"{end_time - start_time:.4f}"
                        time_consumed = int(float(time_consumed))
                        audit_data_user_actions = {
                            "service_name": "rate_plan_progress",
                            "created_by": data.get("username", ""),
                            "status": str(response["flag"]),
                            "time_consumed_secs": time_consumed,
                            "session_id": data.get("session_id", ""),
                            "tenant_name": data.get("tenant_name", ""),
                            "comments": f"Rate Plan Progress data fetched successfully with assignments queued {final_assignments_queued} and assignments pushed to carrier {assignments_pushed_to_carrier}",
                            "module_name": "Optimization",
                            "request_received_at": data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                        }
                        common_utils_database.update_audit(
                            audit_data_user_actions, "audit_user_actions"
                        )
                    except Exception as e:
                        logging.exception(f"### rate_plan_progress Failed to log the audit data: {e}")
                    response = {
                        "flag": "True",
                        "assignments_queued": final_assignments_queued,
                        "assignments_pushed_to_carrier": assignments_pushed_to_carrier,
                        "message": message,
                        "button_message": button_message,
                        "rate_plan_button_status": rate_plan_button_status,
                    }
                    return response

        except Exception as e:
            logging.exception(f"### rate_plan_progress An error occurred: {e}")
            message = "Failed to get the Rate Plan Progress data"
            response = {
                "flag": "True",
                "assignments_queued": 0,
                "assignments_pushed_to_carrier": 0,
                "message": message,
            }
            error_data = {
                "service_name": "rate_plan_progress",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Failed to fetch rate plan progress for instance {instance_id} and service provider {service_provider_id}",
                "module_name": "Optimization",
                "request_received_at": data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
            return response


##get rate plan pop up values
def get_rate_plan_upload_pop_up_values(data):
    """The get_rate_plan_upload_pop_up_values function retrieves the rate plan upload
    pop-up values for a specific instance and service provider.
    Args:
        data (dict): Contains information such as instance_id, service_provider_id,
        db_name, and tenant_name.
    Returns:
        dict: A dictionary containing the instance_id_out, total_sim_cards_to_optimize,
        sim_cards_to_change, and a message indicating success or failure.
    """
    logging.info(f"### get_rate_plan_upload_pop_up_values request data : {data}")
    instance_id = data.get("instance_id", "")
    service_provider_id = data.get("service_provider_id", "")
    tenant_database = data.get("db_name", "")
    tenant_name=data.get('tenant_name','')
    database = DB(tenant_database, **db_config)
    mobility_service_providers = os.getenv("MOBILITY_SERVICE_PROVIDER_NAMES", "").split("/")
    try:
        # Construct the query dynamically based on the service provider names
        mobility_service_provider_ids_query = f"""
            SELECT id
            FROM serviceprovider
            WHERE service_provider_name IN ({', '.join(["'" + name.strip() + "'" for name in mobility_service_providers])})
        """
        mobility_service_provider_dataframe = database.execute_query(
            mobility_service_provider_ids_query, True
        )
        # Assuming the result is a Pandas DataFrame, we extract the 'id' column as a list
        if isinstance(mobility_service_provider_dataframe, pd.DataFrame):
            mobility_service_provider_ids = mobility_service_provider_dataframe[
                "id"
            ].tolist()
    except Exception as e:
        logging.warning(f"### get_rate_plan_upload_pop_up_values Exception while fetching the service providers : {e}")
        mobility_service_provider_ids = [0]
    try:
        # service_provider_id = 36
        # Connection details for the OnePointO database
        creds = get_db_credentials(tenant_name)
        if creds:
            server = creds["server"]
            database_name = creds["database_name"]
            username = creds["username"]
            password = creds["password"]
            port = creds["port"]
        else:
            # Define database connection parameters
            server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
            database_name = os.environ["ONEPOINTODATABASE"]
            username = os.environ["ONEPOINTOUSERNAME"]
            password = os.environ["ONEPOINTOPASSWORD"]

        # Parameters for the stored procedure
        # instance_id = 29510  # Replace this with your desired instance ID

        # Default values for variables
        instance_id_out = 0
        total_sim_cards_to_optimize = 0
        sim_cards_to_change = 0

        with pytds.connect(
            server=server, database=database_name, user=username, password=password
        ) as conn:
            with conn.cursor() as cursor:
                if (
                    service_provider_id in mobility_service_provider_ids
                ):  # Corrected to a tuple
                    # Define the stored procedure name
                    stored_procedure_name = (
                        "dbo.usp_Optimization_Mobility_RatePlanChangeCount"
                    )
                else:
                    # Define the stored procedure name
                    stored_procedure_name = "dbo.usp_Optimization_RatePlanChangeCount"

                # Execute the stored procedure with the instance ID
                cursor.callproc(stored_procedure_name, (instance_id,))
                logging.info("### get_rate_plan_upload_pop_up_values Successfully called the stored procedure.")

                # Fetch and assign results to variables
                results = cursor.fetchall()
                if results:
                    (
                        instance_id_out,
                        total_sim_cards_to_optimize,
                        sim_cards_to_change,
                    ) = results[0]
                message = "Rate Plan pop up data fetched successfully"
                response = {
                    "flag": "True",
                    "instance_id_out": instance_id_out,
                    "total_sim_cards_to_optimize": total_sim_cards_to_optimize,
                    "sim_cards_to_change": sim_cards_to_change,
                    "message": message,
                }
                return response

    except Exception as e:
        logging.exception(f"### get_rate_plan_upload_pop_up_values An error occurred: {e}")
        # Assign default values in case of an error
        instance_id_out = 0
        total_sim_cards_to_optimize = 0
        sim_cards_to_change = 0
        message = "Failed to get the response"
        response = {
            "flag": "True",
            "instance_id_out": instance_id_out,
            "total_sim_cards_to_optimize": total_sim_cards_to_optimize,
            "sim_cards_to_change": sim_cards_to_change,
            "message": message,
        }
        return response


##Carrier rate Plan upload
def rate_plan_upload(data):
    """
    The rate_plan_upload function handles the submission of customer charges
    for a specific session. It builds a POST request payload with session details
    (SessionId, selectedInstances, selectedUsageInstances, and pushType) and sends
    it to the configured API endpoint for processing. The function dynamically retrieves
    the tenant_id and uses it in the headers. It returns the API response,
    including status code and message, while logging errors in case of failure.
    Args:
        data (dict): Contains information such as username, tenant_name, instance_id,
        service_provider_id, carrier_assignments_queued, db_name, and optimization_list_view_id.
    Returns:
        dict: A dictionary containing the API response status and message.

    """
    logging.info(f"### rate_plan_upload Request data Recieved : {data}")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    ids = data.get("instance_id", [])
    service_provider_id = data.get("service_provider_id", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    carrier_assignments_queued = data.get("carrier_assignments_queued", "")
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    try:
        try:
            database.update_dict(
                "optimization_session",
                {"carrier_assignments_queued": carrier_assignments_queued},
                {"id": data.get("optimization_list_view_id", "")},
            )
        except Exception as e:
            logging.error(f"### rate_plan_upload Failed to update carrier_assignments_queued: {e}")
        # Define the API credentials
        username = os.getenv("ONEPOINTOOPTIMIZATIONUSERNAME", " ")
        password = os.getenv("ONEPOINTOOPTIMIZATIONPASSWORD", " ")
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode("utf-8")).decode(
            "utf-8"
        )
        authorization_header = f"Basic {encoded_credentials}"

        # Retrieve tenant_id once
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]

        # Define the URL for customer charges upload
        url = os.getenv("ONEPOINTORATEPLANUPLOADURL", " ")
        one_point_user = os.getenv("ONEPOINTOUSER", " ")
        headers = {
            "Authorization": authorization_header,
            "user-name": one_point_user,
            "x-tenant-id": str(tenant_id),
            "Content-Type": "application/json",
        }

        # Create the request body dynamically
        body = {"ids": ids}
        logging.info("body", body, "headers", headers)
        # Send the POST request to the main API
        response = requests.post(
            url, headers=headers, data=json.dumps(body), timeout=60
        )
        ##API CALL to sync the data
        # Prepare the data to send in the API request
        api_url = os.getenv("OPTIMIZATIONSYNCURL", " ")
        api_payload = {
            "data": {
                "path": "/lambda_sync_jobs_",
                "key_name": "optimization_rate_plans_sync",
                "tenant_name":tenant_name
            }
        }
        # Send the POST request
        try:
            responses = requests.post(api_url, json=api_payload)

            if responses.status_code == 200:
                # Get the current timestamp
                current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                # Log the message with the timestamp
                logging.info(
                    f"### rate_plan_upload API call successful. Data sync call is successfully done at {current_timestamp}"
                )
                # logging.info("API call successful.Data synn call is succssefully done ")
            else:
                logging.error(
                    f"### rate_plan_upload API call failed with statudafdfadsfs code: {response.status_code}"
                )
        except Exception as e:
            logging.error(f"### rate_plan_upload Error occurred while calling the API: {e}")
        # Prepare the response data
        response_data = {
            "flag": True,
            "status code": response.status_code,
            "message": response.json() if response.content else "No Content",
        }
        return response_data

    except Exception as e:
        logging.exception(f"### rate_plan_upload Error uploading rate plan  data: {e}")
        return {"flag": False, "error": str(e)}


def get_optimization_pop_up_values(data):
    """This function retrieves optimization pop-up values from the database.
    Args:
        data (dict): Contains information such as db_name.
    Returns:
        dict: A dictionary containing optimization pop-up values.
    """
    logging.info(f"### get_optimization_pop_up_values Function started : {data}")
    start_time = time.time()
    session_id = data.get("session_id", "")

    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
        return {
            "flag": True,
            "rate_plan_count": 0,
            "sim_cards_to_optimize": 0,
            "total_sim_cards_count": 0,
            "error": "Database connection failed.",
            "status": "Success",
        }

    try:
        # Fetch data from the database
        pop_up_values_dataframe = common_utils_database.get_data(
            "optimization_pop_up_values",
            {"id": 1},
            [
                "rate_plan_count",
                "sim_cards_to_optimize",
                "total_sim_cards_count",
                "status",
            ],
        )

        # Ensure the DataFrame has at least one row
        if pop_up_values_dataframe.empty:
            logging.warning("No data found for the provided criteria.")
            return {
                "flag": True,
                "rate_plan_count": 0,
                "sim_cards_to_optimize": 0,
                "total_sim_cards_count": 0,
                "status": "Success",
            }

        # Extract values from the DataFrame and convert to native Python types
        first_row = pop_up_values_dataframe.iloc[0]

        rate_plan_count = int(first_row["rate_plan_count"])
        sim_cards_to_optimize = int(first_row["sim_cards_to_optimize"])
        total_sim_cards_count = int(first_row["total_sim_cards_count"])
        status = str(first_row["status"])

        response = {
            "flag": True,
            "rate_plan_count": rate_plan_count,
            "sim_cards_to_optimize": sim_cards_to_optimize,
            "total_sim_cards_count": total_sim_cards_count,
            "status": status,
        }
        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "get_optimization_pop_up_values",
                "created_by": data.get("username", ""),
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"get_optimization_pop_up_values fetched successfully with rate_plan_count {rate_plan_count}, sim_cards_to_optimize {sim_cards_to_optimize}, and total_sim_cards_count {total_sim_cards_count}",
                "module_name": "Optimization",
                "request_received_at": data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"### get_optimization_pop_up_values Failed to log the audit data: {e}")
        return response

    except Exception as data_exception:
        logging.error(
            f"### get_optimization_pop_up_values Failed to fetch optimization pop-up values: {str(data_exception)}"
        )
        error_data = {
            "service_name": "get_push_charges_status",
            "error_message": str(data_exception),
            "error_type": type(data_exception).__name__,
            "users": data.get("username", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": "get_optimization_pop_up_values failed to fetch values",
            "module_name": "Optimization",
            "request_received_at": data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {
            "flag": False,
            "rate_plan_count": 0,
            "sim_cards_to_optimize": 0,
            "total_sim_cards_count": 0,
            "error": "Failed to fetch optimization pop-up values.",
            "status": "Failure",
        }


# def get_cross_provider_optimization_dropdown_data(data):
#     '''
#     This function is used to get the cross provider optimization dropdown data
#     :param data:
#     :return: cross_provider_optimization_dropdown_data
#     '''
#     logging.info(f"get_cross_provider_optimization_dropdown_data Function started Request Data:{data}")
#     tenant_database = data.get("db_name", "")
#     database = DB(tenant_database, **db_config)
#     common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
#     try:
#         customers=db_config['customers']
#     except Exception as e:
#         customers=None
#     try:
#         serviceproviders = database.get_data(
#             "serviceprovider",
#             {"is_active": True, "service_provider_name": "not Null"},
#             ["id", "service_provider_name"],
#             order={"service_provider_name": "asc"},
#         )
#         tenant_name=data.get('tenant_name','')
#         if tenant_name == "Altaworx Test":
#             tenant_name = "Altaworx"
#         tenant_id = common_utils_database.get_data(
#             "tenant", {"tenant_name": tenant_name}, ["id"]
#         )["id"].to_list()[0]
#         if tenant_id:
#             tenant_id=int(tenant_id)

#         service_provider_list = serviceproviders.to_dict(orient="records")
#         if customers:
#             # customer_names = ", ".join(f"'{c}'" for c in customers)
#             # customer_names = ", ".join(f"'{c}'" for c in customers)
#             # for pop up
#             customers_query = f"""
#             SELECT c.id, c.customer_name, rc.id as rev_customer_id
#             FROM customers c
#             JOIN revcustomer rc
#             ON rc.id = c.rev_customer_id
#             WHERE rc.id IS NOT NULL
#             AND c.tenant_id = {tenant_id}
#             AND c.is_Active = TRUE
#             AND rc.is_active = TRUE and c.customer_name IN {customers}
#             ORDER BY c.customer_name ASC
#             """
#         else:
#             # for pop up
#             customers_query = f"""
#             SELECT c.id, c.customer_name, rc.id as rev_customer_id
#             FROM customers c
#             JOIN revcustomer rc
#             ON rc.id = c.rev_customer_id
#             WHERE rc.id IS NOT NULL
#             AND c.tenant_id = {tenant_id}
#             AND c.is_Active = TRUE
#             AND rc.is_active = TRUE
#             ORDER BY c.customer_name ASC
#             """

#         customers_data = database.execute_query(customers_query, True)

#         # Convert customers_data DataFrame to dictionary format and ensure UUIDs are converted to strings
#         customers_data = customers_data.to_dict(orient="records")

#         for customer in customers_data:
#             # Convert UUID to string if it exists in the record
#             if isinstance(customer.get("rev_customer_id"), UUID):
#                 customer["rev_customer_id"] = str(customer["rev_customer_id"])

#         # Query to get the most recent active billing periods
#         query = """
#         SELECT id, bill_year, bill_month
#         FROM customer_billing_period
#         WHERE is_active = TRUE
#         ORDER BY bill_year DESC, bill_month DESC ;
#         """

#         # Simulate fetching the data from the database
#         # Replace this with actual database call
#         customer_billing_period = database.execute_query(query, True).to_dict(
#             orient="records"
#         )

#         # Assuming billingEndDayList is a string of days, e.g., '1,2,3,4,...'
#         billingEndDayList = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29"

#         # Deserialize billingEndDayList to a list of integers
#         endDayList = list(map(int, billingEndDayList.split(",")))

#         # Dictionary to store the results
#         all_customer_billing_period_key = {}

#         # Loop through each customer billing period
#         for customerBillPeriod in customer_billing_period:
#             bill_year = customerBillPeriod["bill_year"]
#             bill_month = customerBillPeriod["bill_month"]
#             billing_period_id = customerBillPeriod[
#                 "id"
#             ]  # Capture the billing period ID

#             # Get the number of days in the given month
#             _, num_days_in_month = calendar.monthrange(bill_year, bill_month)

#             # Filter out invalid days
#             valid_end_days = [x for x in endDayList if x <= num_days_in_month]

#             # Generate the end date list from the billing year and month for valid days
#             endDateList = [datetime(bill_year, bill_month, x) for x in valid_end_days]
#             endDateList.sort()  # Sort the dates

#             # The BillingPeriodEnd is the last date in the sorted endDateList
#             BillingPeriodEnd = endDateList[-1]

#             # The BillingPeriodStart is the start of the previous month
#             BillingPeriodStart = BillingPeriodEnd.replace(day=1) - timedelta(days=1)
#             BillingPeriodStart = BillingPeriodStart.replace(day=1)

#             # Convert the endDateList to strings in "dd/MM/yyyy HH:MM:SS" format
#             BillingEndDateList = [x.strftime("%d/%m/%Y %H:%M:%S") for x in endDateList]

#             # Store the results in the dictionary using the billing period ID as the key
#             all_customer_billing_period_key[
#                 f"BillingPeriod_{customerBillPeriod['id']}"
#             ] = {
#                 "billing_period_id": billing_period_id,
#                 "BillingPeriodStartDateTime": BillingPeriodStart.strftime(
#                     "%d/%m/%Y %H:%M:%S"
#                 ),
#                 "BillingPeriodEndDateTime": BillingPeriodEnd.strftime(
#                     "%d/%m/%Y %H:%M:%S"
#                 ),
#                 "BillingEndDateTimeList": BillingEndDateList,
#             }

#         response = {
#             "flag": True,
#             "service_provider_list": service_provider_list,
#             "customers_data": customers_data,
#             "customer_billing_period": all_customer_billing_period_key,
#         }
#         return response
#     except Exception as e:
#         logging.exception(f"Error occurred: {e}")
#         response = {"flag": False, "error": str(e)}
#         return response


def get_billing_periods_for_customer_and_site(data):
    """This function retrieves billing periods for a specific customer and site.
    Args:
        data (dict): Contains information such as customer_id and db_name.
    Returns:
        dict: A dictionary containing the billing periods for the customer.
        """
    logging.info(f"### get_billing_periods_for_customer_and_site request data : {data}")
    customer_id = data.get("customer_id", "")
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config_withoutfilter)
    try:
        # Query to get active billing periods
        customer_billing_period_query = """
        SELECT id, bill_year, bill_month
        FROM customer_billing_period
        WHERE is_active = TRUE
        ORDER BY bill_year DESC, bill_month DESC;
        """

        # Execute the query and fetch billing period data
        billing_periods_data = database.execute_query(
            customer_billing_period_query, True
        )

        # Convert the billing period data into a list of dictionaries if it's not already in that format
        billing_periods = billing_periods_data.to_dict(
            orient="records"
        )  # Assuming it's a DataFrame or similar structure

        # Query to get customer information (equivalent to site) based on customer_id
        customer_query = f"""
        SELECT id, customer_bill_period_end_day, customer_bill_period_end_hour
        FROM customers
        WHERE id = {customer_id} AND is_active = TRUE AND is_deleted = FALSE;
        """

        # Execute the query to get customer data
        customer_data = database.execute_query(customer_query, True)

        # If no customer data is found for the given customer_id, return an empty list
        if customer_data.empty:  # Use .empty to check if the DataFrame is empty
            return []

        # Get the first customer record (there should only be one)
        customer = customer_data.iloc[0]

        # Initialize the list to hold the billing periods to return
        select_billing_period_list = []

        # Ensure the customer has valid customer_bill_period_end_day and customer_bill_period_end_hour
        if (
            customer["customer_bill_period_end_day"] is not None
            and customer["customer_bill_period_end_hour"] is not None
        ):
            # Process the billing periods
            for billing_period in billing_periods:
                # Ensure the billing period has valid year and month
                if billing_period["bill_year"] > 0 and billing_period["bill_month"] > 0:
                    # Construct the billing cycle end date
                    billing_cycle_end_date = datetime(
                        billing_period["bill_year"],
                        billing_period["bill_month"],
                        customer["customer_bill_period_end_day"],
                        customer["customer_bill_period_end_hour"],
                        0,
                        0,
                    )

                    # Subtract one month to get the billing cycle start date
                    billing_cycle_start_date = billing_cycle_end_date - relativedelta(
                        months=1
                    )

                    # Check if the billing cycle end date is at least one month before the current date
                    if billing_cycle_end_date - relativedelta(months=1) <= datetime.now():
                    #if billing_cycle_end_date <= datetime.now() - timedelta(days=30):
                        # Add this billing period to the result list
                        select_billing_period_list.append(
                            {
                                "value": str(billing_period["id"]),
                                "billing_cycle_end_date": billing_cycle_end_date.strftime(
                                    "%b %d, %Y, %I:%M %p"
                                ),
                                "billing_cycle_start_date": billing_cycle_start_date.strftime(
                                    "%b %d, %Y, %I:%M %p"
                                ),  # Add start date
                            }
                        )

        response = {
            "flag": True,
            "customer_billing_period_list": select_billing_period_list,
        }
        return response
    except Exception as e:
        logging.exception(f"### get_billing_periods_for_customer_and_site Exception {e}")
        response = {"flag": True, "customer_billing_period_list": []}
        return response


def get_cross_provider_optimization_pop_up_data(data):
    """This function retrieves data for the cross-provider optimization pop-up.

    Args:
        data (dict): Contains information such as tenant_name, instance_id, and other parameters.
        
    Returns:
        dict: A dictionary containing the rate plan count, sim cards to optimize, total sim cards count, and status.

    """
    logging.info(f"### get_cross_provider_optimization_pop_up_data Request Data in received : {data}")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    # Update status in the common_utils_database
    common_utils_database.update_dict(
        "optimization_pop_up_values",
        {
            "rate_plan_count": 0,
            "sim_cards_to_optimize": 0,
            "total_sim_cards_count": 0,
            "status": "Waiting",
        },
        {"id": 1},
    )
    tenant_name=data.get('tenant_name','')
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    tenant_id = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id"]
    )["id"].to_list()[0]
    try:
        # Get Rate Plan Count
        try:
            # Fetch rate_plan_count from the get_rate_plans_count_cross_optimization function
            rate_plan_response = get_rate_plans_count_cross_optimization(data,tenant_id,tenant_name)
            rate_plan_count = rate_plan_response.get(
                "rate_plan_count", 0
            )  # Default to 0 if not found

            logging.info(f"### get_cross_provider_optimization_pop_up_data rate_plan_count is {rate_plan_count}")
            if rate_plan_count is None:
                rate_plan_count=0
        except Exception as e:
            logging.exception(f"### get_cross_provider_optimization_pop_up_data Failed to fetch the rate_plans : {e}" )
            rate_plan_count = 0

        # Get Sim Cards to Optimize
        try:
            sim_cards_reponse = get_sim_cards_to_optimize_from_data(data,tenant_id)
            sim_cards_to_optimize = int(
                sim_cards_reponse.get("sim_cards_to_optimize", 0)
            )
        except Exception as e:
            logging.warning(f"### get_cross_provider_optimization_pop_up_data Failed to fetch sim_cards_to_optimize : {e}")
            sim_cards_to_optimize = 0
        try:
            # Get Total Sim Cards Count
            total_sim_cards_count = int(get_total_sim_cards_count_cross_provider(data,tenant_id))
        except Exception as e:
            logging.warning(f"### get_cross_provider_optimization_pop_up_data Failed to fetch total_sim_cards_count : {e}")
            total_sim_cards_count = 0
        # Update common_utils_database with the final values
        common_utils_database.update_dict(
            "optimization_pop_up_values",
            {
                "rate_plan_count": rate_plan_count,
                "sim_cards_to_optimize": sim_cards_to_optimize,
                "total_sim_cards_count": total_sim_cards_count,
                "status": "Success",
            },
            {"id": 1},
        )

        # Build the response
        response = {
            "flag": True,
            "rate_plan_count": rate_plan_count,
            "sim_cards_to_optimize": sim_cards_to_optimize,
            "total_sim_cards_count": total_sim_cards_count,
        }

        return response

    except Exception as e:
        logging.exception(f"### get_cross_provider_optimization_pop_up_data Error in connection or execution: {e}")
        return {"flag": False, "message": "Failed to fetch the data"}


def get_rate_plans_count_cross_optimization(data,tenant_id,tenant_name):
    """This function retrieves the count of rate plans for cross-provider optimization.

    Args:
        data (dict): A dictionary containing the following
            keys:
            - "rev_customer_ids": A list of customer IDs for which to retrieve rate plans.
            - "service_provider_ids": A comma-separated string of service provider IDs (default is "20,1").
            - "amop_customer_ids": A list of AMOP customer IDs (optional).
            - "billing_period_id": The ID of the billing period (default is 77).
            - "site_ids": A list of site IDs (optional).

        tenant_id (int): The ID of the tenant for which to retrieve rate plans.
        tenant_name (str): The name of the tenant for which to retrieve rate plans.

    Returns:
        dict: A dictionary containing the rate plan count and an error message if applicable.
    """
    logging.info(f"### get_rate_plans_count_cross_optimization request data : {data}")
    # Set default values for parameters, with optional parameters from the data dict
    rev_customer_ids = data.get("rev_customer_ids", None)
    service_provider_ids = data.get("service_provider_ids", "20,1")  # Default to "20,1"
    #tenant_id = 1  # Set TenantId as 1 (replace as necessary)
    site_type = 1  # Default value for site_type
    amop_customer_ids = data.get("amop_customer_ids", None)
    billing_period_id = data.get("billing_period_id", 77)  # Default value
    site_ids = None  # Set to None if it's optional

    # Variables to store results and error message
    rate_plan_count = None
    error_message = None

    # Database connection details for the OnePointO database
    creds = get_db_credentials(tenant_name)
    if creds:
        server = creds["server"]
        database = creds["database_name"]
        username = creds["username"]
        password = creds["password"]
        port = creds["port"]
    else:
        # Define database connection parameters
        server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
        database = os.environ["ONEPOINTODATABASE"]
        username = os.environ["ONEPOINTOUSERNAME"]
        password = os.environ["ONEPOINTOPASSWORD"]

    try:
        # Establish the connection to the database
        with pytds.connect(
            server=server, database=database, user=username, password=password
        ) as conn:
            with conn.cursor() as cursor:
                # Define the stored procedure name
                stored_procedure_name = (
                    "dbo.usp_CrossProviderOptimizationRatePlansByCustomerCount"
                )

                # Execute the stored procedure with parameters
                cursor.callproc(
                    stored_procedure_name,
                    (
                        rev_customer_ids,
                        service_provider_ids,
                        tenant_id,
                        site_type,
                        amop_customer_ids,
                        billing_period_id,
                        site_ids,
                    ),
                )
                logging.info("Successfully called the stored procedure.")

                # Fetch the results
                results = cursor.fetchall()
                logging.info("Results:", results)

                # Extract the count from the first tuple in results
                if results and isinstance(results[0], tuple):
                    rate_plan_count = results[0][
                        0
                    ]  # The first element of the first tuple
                    logging.info("Rate Plan Count:", rate_plan_count)
                if rate_plan_count is not None:
                    return {"flag": "True", "rate_plan_count": rate_plan_count}

    except Exception as e:
        # Log the error and set the error message
        logging.exception(f"### get_rate_plans_count_cross_optimization An error occurred: {e}")
        error_message = "Failed to get the Rate Plan Progress data"
        return {"flag": "True", "error_message": error_message, "rate_plan_count": 0}


def get_total_sim_cards_count_cross_provider(data,tenant_id):
    """
    This function retrieves the total count of SIM cards for a given tenant and service providers.
    It constructs a SQL query based on the provided data, including optional filters for customer_id and
    service_provider_ids. The function returns the total count of SIM cards across both Device_Tenant and Mobility_Device_Tenant tables.
    If customer_id is not provided or is 0, it counts for all customers; otherwise
    it filters by the specified customer_id.
    Args:
        data (dict): A dictionary containing the following keys:
            - "db_name": The name of the tenant database.
            - "service_provider_ids": A comma-separated string of service provider IDs (default is "20,1").
            - "customer_id": An optional customer ID to filter the count (default is an empty string).
        tenant_id (int): The ID of the tenant for which to retrieve the SIM card count.
    Returns:
        int: The total count of SIM cards across both Device_Tenant and Mobility_Device_Tenant
        tables for the specified tenant and service providers.

    """
    # Database connection
    tenant_database = data.get("db_name", "")
    logging.info('tenant_database',tenant_database)
    if 'database' in db_config:
        db_config.pop('database')  # Remove 'database' key if present
    database = DB(tenant_database, **db_config)
    # Retrieve service_provider_ids and customer_id from the data
    service_provider_ids = data.get(
        "service_provider_ids", "20,1"
    )  # Default to "20,1" if not provided
    customer_id = data.get("customer_id", "")

    # Convert service_provider_ids into a list of integers
    service_provider_ids = [int(x.strip()) for x in service_provider_ids.split(",")]

    # Convert the customer_id to an integer (could be 0 or empty)
    customer_id = int(customer_id) if customer_id else None

    # If customer_id is None or 0, treat it as no specific customer filter, else apply filter based on customer_id
    if customer_id is None or customer_id == 0:
        # Query for no specific customer (count for all customers)
        total_sim_cards_count_query = f"""
        SELECT (
            SELECT COUNT(*)
            FROM Device_Tenant dt
            JOIN Device d ON dt.device_id = d.id
            JOIN customers s ON dt.customer_id = s.id
            WHERE dt.Tenant_Id = {tenant_id}
            AND dt.Is_Active = True
            AND dt.Is_Deleted = False
            AND (dt.customer_id IS NULL OR s.parent_customer_id IS NULL)
            AND d.Service_Provider_Id IN ({','.join(map(str, service_provider_ids))})
        ) + (
            SELECT COUNT(*)
            FROM Mobility_Device_Tenant mdt
            JOIN Mobility_Device md ON mdt.Mobility_Device_Id = md.id
            JOIN customers s ON mdt.customer_id = s.id
            WHERE mdt.Tenant_Id = {tenant_id}
            AND mdt.Is_Active = True
            AND mdt.Is_Deleted = False
            AND (mdt.customer_id IS NULL OR s.parent_customer_id IS NULL)
            AND md.Service_Provider_Id IN ({','.join(map(str, service_provider_ids))})
        ) AS total_device_count;
        """
    else:
        # Query for a specific customer (filter by customer_id)
        total_sim_cards_count_query = f"""
        SELECT (
            SELECT COUNT(*)
            FROM Device_Tenant dt
            JOIN Device d ON dt.device_id = d.id
            JOIN customers s ON dt.customer_id = s.id
            WHERE dt.Tenant_Id = {tenant_id}
            AND dt.Is_Active = True
            AND dt.Is_Deleted = False
            AND (dt.customer_id = {customer_id} OR s.parent_customer_id = {customer_id})
            AND d.Service_Provider_Id IN ({','.join(map(str, service_provider_ids))})
        ) + (
            SELECT COUNT(*)
            FROM Mobility_Device_Tenant mdt
            JOIN Mobility_Device md ON mdt.Mobility_Device_Id = md.id
            JOIN customers s ON mdt.customer_id = s.id
            WHERE mdt.Tenant_Id = {tenant_id}
            AND mdt.Is_Active = True
            AND mdt.Is_Deleted = False
            AND (mdt.customer_id = {customer_id} OR s.parent_customer_id = {customer_id})
            AND md.Service_Provider_Id IN ({','.join(map(str, service_provider_ids))})
        ) AS total_device_count;
        """

    # Execute the query
    result = database.execute_query(total_sim_cards_count_query, True)

    # Check if the result is not empty and contains the expected column
    if not result.empty and "total_device_count" in result.columns:
        total_sim_cards_count = result["total_device_count"].iloc[0]
    else:
        total_sim_cards_count = 0  # Handle the case where no count is returned

    return total_sim_cards_count


# Function to convert the date string to desired format
def convert_datetime_format(date_string, target_format="%Y-%m-%d"):
    # Parse the string into a datetime object
    date_obj = datetime.strptime(
        date_string, "%Y-%m-%d %H:%M:%S"
    )  # Parse to datetime object
    # Format the datetime object to the desired format
    return date_obj.strftime(target_format)  # Return the formatted string


# def get_sim_cards_to_optimize_from_data(data):
#     # Your connection details
#     server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
#     database_name = os.environ["ONEPOINTODATABASE"]
#     username = os.environ["ONEPOINTOUSERNAME"]
#     password = os.environ["ONEPOINTOPASSWORD"]

#     try:
#         # Extract parameters from the `data` dictionary
#         service_provider_ids = data.get(
#             "service_provider_ids", "20,1"
#         )  # Defaulting to "20,1" if not provided
#         site_id = data.get("site_id", None)  # Can be None if not provided
#         site_ids = data.get("site_ids", None)  # Can be None if not provided
#         customer_billing_period_id = data.get(
#             "billing_period_id", 77
#         )  # Default to 77 if not provided

#         # Get and format the start and end date from data (assuming they are strings)
#         billing_period_start_date = data.get(
#             "billing_period_start_date", "2024-11-10 12:00:00"
#         )
#         billing_period_end_date = data.get(
#             "billing_period_end_date", "2024-12-10 12:00:00"
#         )

#         # Convert to the desired date format (YYYY-MM-DD)
#         billing_period_start_date = convert_datetime_format(
#             billing_period_start_date, "%Y-%m-%d "
#         )
#         billing_period_end_date = convert_datetime_format(
#             billing_period_end_date, "%Y-%m-%d"
#         )

#         # Establish the connection to the database with a timeout of 30 seconds
#         start_time = time.time()  # Start timer for performance measurement
#         with pytds.connect(
#             server=server,
#             database=database_name,
#             user=username,
#             password=password,
#             timeout=300,  # Connection timeout set to 30 seconds
#         ) as conn:
#             with conn.cursor() as cursor:
#                 # Start a timer to track query execution time
#                 query_start_time = time.time()

#                 # Define the stored procedure name
#                 stored_procedure_name = "dbo.usp_CrossProviderOptimizationSimCardsCount"
#                 logging.info(
#                     f"Calling stored procedure with params: {service_provider_ids}, {site_id}, {site_ids}, {customer_billing_period_id}, {billing_period_start_date}, {billing_period_end_date}"
#                 )

#                 # Execute the stored procedure with parameters extracted from `data`
#                 cursor.callproc(
#                     stored_procedure_name,
#                     (
#                         service_provider_ids,  # This is now a string
#                         site_id,  # This is an INT, set to None for NULL
#                         site_ids,  # Comma-separated string or None for NULL
#                         customer_billing_period_id,  # This should be an integer
#                         billing_period_start_date,  # DATETIME (formatted as a string)
#                         billing_period_end_date,  # DATETIME (formatted as a string)
#                     ),
#                 )

#                 # Fetch and assign results
#                 results = cursor.fetchall()

#                 # Measure query execution time
#                 query_execution_time = time.time() - query_start_time
#                 logging.info(f"Query executed in: {query_execution_time:.2f} seconds")

#                 if results:
#                     # Extract the sim_cards_to_optimize value from results
#                     sim_cards_to_optimize = results[0][
#                         0
#                     ]  # Assuming the value is in the first column
#                 else:
#                     sim_cards_to_optimize = 0  # If no results, default to 0

#                 # Measure total execution time
#                 total_execution_time = time.time() - start_time
#                 logging.info(
#                     f"Total execution time: {total_execution_time:.2f} seconds"
#                 )

#                 # If the query takes too long, log and handle the error
#                 if total_execution_time > 30:
#                     raise TimeoutError(
#                         "Query execution exceeded the 30-second timeout limit."
#                     )

#                 # Return response as required
#                 response = {
#                     "flag": True,
#                     "sim_cards_to_optimize": sim_cards_to_optimize,
#                 }
#                 return response

#     except TimeoutError as e:
#         logging.exception("Timeout error:", e)
#         message = f"Failed to get the Sim Card Count data: {e}"
#         response = {"flag": False, "sim_cards_to_optimize": 0, "message": message}

#     except Exception as e:
#         logging.exception("An unexpected error occurred:", e)
#         message = f"Failed to get the Sim Card Count data: {e}"
#         response = {"flag": False, "sim_cards_to_optimize": 0, "message": message}

#     return response

def get_sim_cards_to_optimize_from_data(data,tenant_id):
    """This function retrieves the count of SIM cards to optimize by calling a stored procedure in the PostgreSQL database.
    Args:
        data (dict): A dictionary containing the request data, including service provider IDs, customer ID, site IDs,
            billing period ID, and billing period start and end dates.
        Returns:
            dict: A dictionary containing the result of the operation, including a flag indicating success or failure,
            and the count of SIM cards to optimize."""
    # Database connection details
    logging.info(f"### get_sim_cards_to_optimize_from_data request data : {data}")
    try:
        # Extract parameters from the `data` dictionary
        service_provider_ids = data.get("service_provider_ids", "")
        site_id = data.get("customer_id", None)
        site_ids = data.get("site_ids", None)
        customer_billing_period_id = data.get("billing_period_id", 77)
        billing_period_start_date = data.get("billing_period_start_date", "2024-12-01 00:00:00")
        billing_period_end_date = data.get("billing_period_end_date", "2025-01-29 00:00:00")
        tenant_database=data.get('db_name','')
        db_config["database"] = tenant_database
        bill_period_days = data.get("bill_period_days", None)
        logging.info(f"### get_sim_cards_to_optimize_from_data  bill_period_days are {bill_period_days}")
        if bill_period_days:
            database_com = DB(tenant_database, **db_config_withoutfilter)
            customer_bill_period_ids = database_com.get_data(
                'customers',
                {"is_active": True,"is_deleted":False, "tenant_id": tenant_id,"customer_bill_period_end_day":bill_period_days},
                ['id']
            )['id'].to_list()
            logging.info(f"###get_sim_cards_to_optimize from data customer period id count {len(customer_bill_period_ids)}")
            # Convert to comma-separated string if not empty, else None
            if customer_bill_period_ids:
                site_ids = ",".join(map(str, customer_bill_period_ids))
            else:
                site_ids = None
        # Establish the connection to PostgreSQL
        start_time = time.time()
        with psycopg2.connect(**db_config) as conn:
            with conn.cursor() as cursor:
                query_start_time = time.time()
                if site_id==0:
                    site_id=None
                # Call the stored function
                
                query = """
                    SELECT usp_cross_provider_optimization_sim_cards_count(
                        %s::text,  -- service provider IDs
                        %s::int,   -- customer ID (NULL allowed)
                        %s::text,  -- customer IDs (NULL allowed)
                        %s::int,   -- customer billing period ID
                        %s::timestamp,  -- billing period start date
                        %s::timestamp   -- billing period end date
                    );
                """
                # Log the query and its parameters
                logging.info(
                    "Executing query with parameters: service_provider_ids=%s, site_id=%s "
                    "customer_billing_period_id=%s, billing_period_start_date=%s, billing_period_end_date=%s",
                    service_provider_ids,
                    site_id,
                    customer_billing_period_id,
                    billing_period_start_date,
                    billing_period_end_date
                )
                cursor.execute(query, (
                    service_provider_ids,  # String with comma-separated IDs
                    site_id,  # Can be None
                    site_ids,  # Can be None
                    customer_billing_period_id,  # Integer
                    billing_period_start_date,  # Timestamp
                    billing_period_end_date,  # Timestamp
                ))


                # Fetch results
                results = cursor.fetchone()

                query_execution_time = time.time() - query_start_time
                logging.info(f"### get_sim_cards_to_optimize_from_data Query executed in: {query_execution_time:.2f} seconds")

                # Extract the value from the result
                sim_cards_to_optimize = results[0] if results else 0

                total_execution_time = time.time() - start_time
                logging.info(f"### get_sim_cards_to_optimize_from_data Total execution time: {total_execution_time:.2f} seconds")
                return {"flag": True, "sim_cards_to_optimize": sim_cards_to_optimize}

    except TimeoutError as e:
        logging.exception("### get_sim_cards_to_optimize_from_data Timeout error:", exc_info=True)
        return {"flag": False, "sim_cards_to_optimize": 0, "message": f"Failed to get data: {e}"}

    except Exception as e:
        logging.exception("### get_sim_cards_to_optimize_from_data An unexpected error occurred:", exc_info=True)
        return {"flag": False, "sim_cards_to_optimize": 0, "message": f"Failed to get data: {e}"}


def start_cross_provider_optimization(data):
    """
    The start_optimization function initiates an optimization process
    by sending a POST request with tenant and user-specific details to
    1.0 Controller. It retrieves the tenant ID from the database, sets
    necessary headers, and sends the request body as JSON, returning the
    API's response or error details in case of failure.
    Args:
        data (dict): A dictionary containing the request data, including
            tenant database name, template, request received time, role name,
            body, session ID, and tenant name.
    Returns:
        dict: A dictionary containing the response from the API or error details.

    """
    logging.info(f"### start_cross_provider_optimization Request Data Received : {data}")
    # Start time  and date calculation
    start_time = time.time()
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config_withoutfilter)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    template = data.get("template", "")
    request_received_at = data.get("request_received_at", "")
    role = data.get("role_name", "")
    body = data.get("body", {})
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    tenant_details = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id","parent_tenant_id"]
    )
    tenant_id = tenant_details["id"].to_list()[0]
    parent_tenant_id = tenant_details["parent_tenant_id"].to_list()[0]
    logging.info(f"parent_tenant_id=> {parent_tenant_id}")
    if parent_tenant_id and parent_tenant_id is not None:
        optimization_setting_table='optimization_setting_tenant_override'
    else:
        optimization_setting_table='optimization_setting'
    try:
        if body.get("optimizationType") == 1:
            optimization_mail = database.get_data(
                optimization_setting_table, {"tenant_id":tenant_id}, ["customer_optimization_to_email_address"]
            )["customer_optimization_to_email_address"].to_list()[0]
        else:
            optimization_mail = database.get_data(
                optimization_setting_table, {"tenant_id":tenant_id}, ["carrier_optimization_to_email_address"]
            )["carrier_optimization_to_email_address"].to_list()[0]
        common_utils_database.update_dict(
            "email_templates",
            {"body": template},
            {"template_name": "Start Optimization"},
        )
        try:
            common_utils_database.update_dict(
                "email_templates",
                {
                    "last_email_triggered_at": request_received_at,
                    "to_mail": optimization_mail,
                },
                {"template_name": "Start Optimization"},
            )
            # Call send_email and assign the result to 'result'
            result = send_email("Start Optimization", user_mail=optimization_mail)
            # Check the result and handle accordingly
            if isinstance(result, dict) and result.get("flag") is False:
                logging.info(f"### start_cross_provider_optimization : {result}")
            else:
                # Continue with other logic if needed
                (
                    to_emails,
                    cc_emails,
                    subject,
                    bodyy,
                    from_email,
                    partner_name,
                ) = result
                common_utils_database.update_dict(
                    "email_templates",
                    {"last_email_triggered_at": request_received_at},
                    {"template_name": "Start Optimization"},
                )
                query = """
                    SELECT parents_module_name, sub_module_name,
                        child_module_name, partner_name
                    FROM email_templates
                    WHERE template_name = %s
                """

                params = ["Start Optimization"]
                # Execute the query with template_name as the parameter
                email_template_data = common_utils_database.execute_query(
                    query, params=params
                )
                if not email_template_data.empty:
                    # Unpack the results
                    (
                        parents_module_name,
                        sub_module_name,
                        child_module_name,
                        partner_name,
                    ) = email_template_data.iloc[0]
                else:
                    # If no data is found, assign default values or log an error
                    parents_module_name = ""
                    sub_module_name = ""
                    child_module_name = ""
                    partner_name = ""

                try:
                    ##email audit
                    email_audit_data = {
                        "template_name": "Start Optimization",
                        "email_type": "Application",
                        "partner_name": partner_name,
                        "email_status": "success",
                        "from_email": from_email,
                        "to_email": to_emails,
                        "cc_email": cc_emails,
                        "comments": "update inventory data",
                        "subject": subject,
                        "body": bodyy,
                        "role": role,
                        "action": "Email triggered",
                        "parents_module_name": parents_module_name,
                        "sub_module_name": sub_module_name,
                        "child_module_name": child_module_name,
                    }
                    common_utils_database.update_audit(email_audit_data, "email_audit")
                except Exception as e:
                    logging.error(f"### start_cross_provider_optimization Failed to update the email audit table : {e}")
        except Exception as e:
            logging.warning(f"### start_cross_provider_optimization Failed to send the email : {e}")
    except Exception as e:
        logging.warning(
            f"### start_cross_provider_optimization Failed to get the optimization data from settings and  failed to trigger the mail{e}"
        )
    try:
        body = data.get("body", {})
        logging.info(f"### start_cross_provider_optimization Request body: {body}")
        # If siteId is 0, set it to 'null' as before
        if body["siteId"] == 0:
            body["siteId"] = "null"

        # Take the first item in the serviceProviderId list if it exists
        if (
            "serviceProviderId" in body
            and isinstance(body["serviceProviderId"], list)
            and body["serviceProviderId"]
        ):
            body["serviceProviderId"] = body["serviceProviderId"][0]

        ui_username = data.get("username", "")
        tenant_name = data.get("tenant_name", "")
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
        additional_data = {
            "BillingPeriodStartDate": data.get("billing_period_start_date", ""),
            "BillingPeriodEndDate": data.get("billing_period_end_date", ""),
            "DeviceCount": data.get("device_count", 0),
        }

        # Update the body with additional data
        body.update(additional_data)
        logging.info(f"### start_cross_provider_optimization body of the start optimization is :{body}")
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]
        tenant_id = str(tenant_id)
        url = os.getenv("OPTIMIZATIONAPI", " ")
        username = os.getenv("ONEPOINTOOPTIMIZATIONUSERNAME", " ")
        password = os.getenv("ONEPOINTOOPTIMIZATIONPASSWORD", " ")
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode("utf-8")).decode(
            "utf-8"
        )
        authorization_header = f"Basic {encoded_credentials}"
        one_pointo_user = os.getenv("ONEPOINTOUSER", " ")
        # Define the headers
        headers = {
            "Authorization": authorization_header,
            "user-name": ui_username,
            "x-tenant-id": tenant_id,
            "Content-Type": "application/json",  # Specify content type for JSON
        }
        logging.info(f"### start_cross_provider_optimization headers of the start optimization is :{headers}")
        if body['serviceProviderIds']:
            body['serviceProviderIds'] = str([int(x) for x in body['serviceProviderIds'].split(',')])
        logging.info(f"### start_cross_provider_optimization Request body: {body}")
        # Send the POST request
        response = requests.post(url, headers=headers, data=json.dumps(body))
        response_data = {
            "flag": True,
            "status code": response.status_code,
            "message": response.json(),
        }
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "start_cross_provider_optimization",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response_data["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": "Initiates an optimization process by sending a POST request with tenant and user-specific details to 1.0 Controller",
                "module_name": "Optimization",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### start_cross_provider_optimization Exception is {e}")

        # Return the status code and response JSON
        return response_data

    except Exception as e:
        logging.exception(f"### start_cross_provider_optimization Error fetching data: {e}")
        message = f"exception is {e}"
        response_data = {"flag": False, "message": message}
        error_data = {
            "service_name": "start_cross_provider_optimization",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": "1.0 API HIT",
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Optimization",
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        # Return the status code and response JSON
        return response_data


def get_customer_optimization_customers_data(data):
    '''
    get_customer_optimization_customers_data(data) retrieves customer names and IDs 
    for optimization based on a user's role, tenant context, and billing period. 
    It checks permissions to select the correct stored procedure, executes it 
    against the tenant database, extracts or parses customer IDs, sorts the results 
    alphabetically, and returns them in a standardized response format.
    Args:
        data (dict): Input data containing tenant name, role name, service provider ID,
        billing period ID, and mobility flag.
    Returns:
        dict: A dictionary containing a flag indicating success or failure,
        and a list of customers with their names and IDs, or an error message.
    '''
    logging.info(f"### get_customer_optimization_customers_data request data : {data}")
    # Direct database credentials
    role_name=data.get('role_name','')
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    # Extract values from input data
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    creds = get_db_credentials(tenant_name)
    if creds:
        server = creds["server"]
        database = creds["database_name"]
        username = creds["username"]
        password = creds["password"]
        port = creds["port"]
    else:
        # Define database connection parameters
        server = os.environ["ONEPOINTOSERVER"]  # Will raise a KeyError if not found
        database = os.environ["ONEPOINTODATABASE"]
        username = os.environ["ONEPOINTOUSERNAME"]
        password = os.environ["ONEPOINTOPASSWORD"]
    tenant_id = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id"]
    )["id"].to_list()[0]
    logging.info(tenant_id, "tenant_id is")

    service_provider_id = data.get(
        "service_provider_id", 1
    )  # Default to 1 if not provided
    billing_period_id = data.get(
        "billing_period_id", 486
    )  # Default to 486 if not provided
    mobility_flag = data.get("mobility_flag", False)

    # Initialize the response list
    response = []
    role_module_data = common_utils_database.get_data(
                                    "role_module",
                                    {"role": role_name},
                                    ["sub_module"],
                                )

             # Initialize default status
    rev_status = False

    if not role_module_data.empty:
        try:
            # Parse JSON safely with fallback
            sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

            # Strict nested check
            if "People" in sub_modules:
                people_modules = sub_modules["People"]
                if isinstance(people_modules, list):  # Ensure it's a list
                    rev_status = "Billing Platform Customers" in people_modules

        except json.JSONDecodeError:
            logging.error(f"Invalid JSON in sub_module for role: {role_name}")
        except KeyError:
            pass  # People section not present
        except Exception as e:
            logging.error(f"Unexpected error processing modules: {str(e)}")  
    try:
        with pytds.connect(
            server=server, database=database, user=username, password=password
        ) as conn:
            with conn.cursor() as cursor:
                if rev_status == True:
                    # Define the stored procedure name based on mobility_flag
                    if mobility_flag == True:
                        stored_procedure_name = (
                            f"{database}.dbo.[usp_Optimization_Mobility_CustomersGet]"
                        )
                    else:
                        stored_procedure_name = (
                            f"{database}.dbo.[usp_OptimizationCustomersGet]"
                        )
                    # Execute the stored procedure with the parameters
                    cursor.callproc(
                        stored_procedure_name,
                        (tenant_id, service_provider_id, billing_period_id),
                    )

                    # Fetch all results
                    result = cursor.fetchall()

                    if result:
                        # If data is found, collect all customer_name and customer_id pairs
                        for row in result:
                            response.append(
                                {
                                    "customer_name": row[
                                        1
                                    ],  # Customer name from the result
                                    "customer_id": row[
                                        3
                                    ],  # Customer ID from the result
                                }
                            )

                        ## Clean and sort the response list by customer_name (alphabetically)
                        response = sorted(
                            response, key=lambda x: x["customer_name"].strip().lower()
                        )  # Clean and sort by lowercase

                    else:
                        # If no data is found, return an empty list
                        response = []

                else:
                    logging.info("entered else condition in get_customer_optimization_customers_data")
                    if mobility_flag == True:
                        stored_procedure_name = f"{database}.dbo.[usp_Optimization_Mobility_AMOPCustomersGet]"
                    else:
                        stored_procedure_name = (
                            f"{database}.dbo.[usp_Optimization_AMOPCustomersGet]"
                        )
                    logging.info(f"tenant_id is {tenant_id},service_provider_id  is {service_provider_id} and billing_period_id is {billing_period_id}")
                    # Execute the stored procedure with the parameters
                    cursor.callproc(
                        stored_procedure_name,
                        (tenant_id, service_provider_id, billing_period_id),
                    )

                    # Fetch all results
                    result = cursor.fetchall()
                    logging.info("result is", result)
                    if result:
                        for row in result:
                            customer_id = row[0]  # Take the first element as customer_id
                            response.append({
                                "customer_name": row[1],
                                "customer_id": customer_id,
                            })

                        response = sorted(response, key=lambda x: x["customer_name"].strip().lower())

                    else:
                        # If no data is found, return an empty list
                        response = []

        # Returning response with flag and sorted customer data
        response = {"flag": True, "customers": response}
        return response
    except Exception as e:
        # Handle any errors
        response = {"error": f"Error occurred: {e}"}
        return response



def get_billing_end_days(bill_year, bill_month):
    _, num_days_in_month = calendar.monthrange(bill_year, bill_month)
    return list(range(1, num_days_in_month + 1))


def get_cross_provider_optimization_dropdown_data(data):
    """
    get_cross_provider_optimization_dropdown_data(data) retrieves dropdown data for cross-provider optimization.
    Args:
        data (dict): Input data containing tenant database name, offset, and tenant name.
    Returns:
        dict: A dictionary containing service providers, customers, and billing periods.
    """
    logging.info(f"#### get_cross_provider_optimization_dropdown_data request data : {data}")
    tenant_database = data.get("db_name", "")
    offset=data.get('offset', 0)
    page_size = 10000
    
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    try:
        customers=db_config['customers']
    except Exception as e:
        logging.exception(f"### get_cross_provider_optimization_dropdown_data Failed to get the customers from db_config : {e}")
        customers=None
    try:
        serviceproviders = database.get_data(
            "serviceprovider",
            {"is_active": True, "service_provider_name": "not Null"},
            ["id", "service_provider_name"],
            order={"service_provider_name": "asc"},
        )
        tenant_name=data.get('tenant_name','')
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]
        if tenant_id:
            tenant_id=int(tenant_id)

        service_provider_list = serviceproviders.to_dict(orient="records")
        if customers:
            # customer_names = ", ".join(f"'{c}'" for c in customers)
            # customer_names = ", ".join(f"'{c}'" for c in customers)
            # for pop up
            customers_query = f"""
            SELECT c.id, c.customer_name, rc.id as rev_customer_id,rc.rev_customer_id as account_number
            FROM customers c
            JOIN revcustomer rc
            ON rc.id = c.rev_customer_id
            WHERE rc.id IS NOT NULL
            AND c.tenant_id = {tenant_id}
            AND c.is_Active = TRUE
            AND rc.is_active = TRUE and c.customer_name IN {customers}
            ORDER BY c.customer_name ASC offset {offset * page_size} limit 10000
            """
        else:
            # for pop up
            customers_query = f"""
            SELECT c.id, c.customer_name, rc.id as rev_customer_id,rc.rev_customer_id as account_number
            FROM customers c
            JOIN revcustomer rc
            ON rc.id = c.rev_customer_id
            WHERE rc.id IS NOT NULL
            AND c.tenant_id = {tenant_id}
            AND c.is_Active = TRUE
            AND rc.is_active = TRUE
            AND rc.customer_name IS NOT NULL
            AND rc.customer_name <> ''
            ORDER BY c.customer_name ASC,c.id ASC   offset {offset * page_size} limit 10000
            """

        customers_data = database.execute_query(customers_query, True)

        # Convert customers_data DataFrame to dictionary format and ensure UUIDs are converted to strings
        customers_data = customers_data.to_dict(orient="records")

        for customer in customers_data:
            # Convert UUID to string if it exists in the record
            if isinstance(customer.get("rev_customer_id"), UUID):
                customer["rev_customer_id"] = str(customer["rev_customer_id"])

        # ================== Step 1: Fetch billing periods ==================
        query = """
        SELECT id, bill_year, bill_month
        FROM customer_billing_period
        WHERE is_active = TRUE
        ORDER BY bill_year DESC, bill_month DESC ;
        """
        customer_billing_period = database.execute_query(query, True).to_dict(orient="records")


        # ================== Step 2: Fetch end day list from customers ==================
        billingEndDayListQuery = """
        SELECT DISTINCT customer_bill_period_end_day
        FROM customers
        WHERE customer_bill_period_end_day IS NOT NULL
        """
        billingEndDayList_data = database.execute_query(billingEndDayListQuery, True)

        if not billingEndDayList_data.empty:
            endDayList = (
                billingEndDayList_data["customer_bill_period_end_day"]
                .dropna()
                .astype(int)    # convert to int
                .sort_values()
                .tolist()
            )
        else:
            endDayList = []

        logging.info(f"Configured End Day List from DB:", endDayList)
        # ================== Step 3: Build Billing Periods ==================
        all_customer_billing_period_key = {}

        for customerBillPeriod in customer_billing_period:
            bill_year = customerBillPeriod["bill_year"]
            bill_month = customerBillPeriod["bill_month"]
            billing_period_id = customerBillPeriod["id"]

            # All valid days in month
            all_days_in_month = get_billing_end_days(bill_year, bill_month)

            # Filter only DB days that exist in this month
            filtered_days = sorted([d for d in endDayList if d in all_days_in_month])

            if not filtered_days:
                continue  # skip if no valid days for this month

            # Build date list for filtered days
            endDateList = [datetime(bill_year, bill_month, d) for d in filtered_days]

            # End date = last available filtered day
            BillingPeriodEnd = endDateList[-1]

            # Start date = first day of previous month
            BillingPeriodStart = BillingPeriodEnd.replace(day=1) - relativedelta(months=1)

            # Format dates
            BillingEndDateList = [d.strftime("%d/%m/%Y %H:%M:%S") for d in endDateList]

            all_customer_billing_period_key[f"BillingPeriod_{billing_period_id}"] = {
                "billing_period_id": billing_period_id,
                "BillingPeriodStartDateTime": BillingPeriodStart.strftime("%d/%m/%Y %H:%M:%S"),
                "BillingPeriodEndDateTime": BillingPeriodEnd.strftime("%d/%m/%Y %H:%M:%S"),
                "BillingEndDateTimeList": BillingEndDateList,
            }

        response = {
            "flag": True,
            "service_provider_list": service_provider_list,
            "customers_data": customers_data,
            "customer_billing_period": all_customer_billing_period_key,
        }
        return response
    except Exception as e:
        logging.exception(f"### get_cross_provider_optimization_dropdown_data Error occurred: {e}")
        response = {"flag": False, "error": str(e)}
        return response


def get_cross_provider_customer_offsets(data):
    """
    Returns the number of offsets (pages) based on total records and a given page size.
    
    Parameters:
    - data (dict): Should contain:
        - 'db_name': tenant DB name
        - 'tenant_name': tenant name
        - 'customers' (optional): list of specific customer names
        - 'limit' (optional): number of records per chunk (default 10000)
    
    Returns:
    - dict: {
        'flag': True/False,
        'offsets': int (if successful),
        'total_count': int,
        'limit': int,
        'error': str (if failed)
    }
    """
    logging.info(f"### get_cross_provider_customer_offsets request data : {data}")
    start_time = time.time()
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    limit = int(data.get("limit", 10000))  # default to 10,000 rows per chunk
    tenant_name = data.get('tenant_name', '')
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    try:
        customers = db_config.get('customers', None)
        

        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"

        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]

        tenant_id = int(tenant_id)
        if customers:
            # Build base count query
            count_query = f"""
            SELECT COUNT(*) FROM customers c
            JOIN revcustomer rc ON rc.id = c.rev_customer_id
            WHERE rc.id IS NOT NULL
            AND c.tenant_id = {tenant_id}
            AND c.is_Active = TRUE and c.customer_name IN {customers}
            AND rc.is_active = TRUE
            """
        else:
            count_query = f"""
            SELECT COUNT(*) FROM customers c
            JOIN revcustomer rc ON rc.id = c.rev_customer_id
            WHERE rc.id IS NOT NULL
            AND c.tenant_id = {tenant_id}
            AND c.is_Active = TRUE 
            AND rc.is_active = TRUE
            AND rc.customer_name IS NOT NULL
            AND rc.customer_name <> ''
            """
        total_count = database.execute_query(count_query, True).iloc[0, 0]
        offsets = (total_count + limit - 1) // limit  # ceiling division
        if offsets==0:
            offsets=1
        try:
            # End time and audit logging
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "get_cross_provider_customer_offsets",
                "created_by": data.get("username", ""),
                "status": True,
                "time_consumed_secs": time_consumed,
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"fetched get cross provider customer for customers {customers}",
                "module_name": "Optimization",
                "request_received_at": data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"### get_cross_provider_customer_offsets Failed to log the audit data: {e}")
        return {
            "flag": True,
            "offsets": int(offsets),
            "total_count": int(total_count),
            "limit": int(limit)
        }

    except Exception as e:
        logging.exception(f"### get_cross_provider_customer_offsets Error in offset calculation: {e}")
        error_data = {
            "service_name": "get_cross_provider_customer_offsets",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"Error in offset calculation for customers {customers}",
            "module_name": "Optimization",
            "request_received_at": data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {
            "flag": True,
            "offsets": 1,
            "total_count":0,
            "limit": limit,
        }
