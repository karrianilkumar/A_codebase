"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 :
Created Date: 05-09-2025
"""

# Importing the necessary Libraries
import os
from datetime import datetime
import json, time
import pandas as pd
import requests
import re
import threading
import boto3

from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from concurrent.futures import ThreadPoolExecutor, as_completed

from carrier_apis import (
    send_carrier_rate_plan_update_request,
    fetch_individual_line_sync_request,
    get_carrier_api_details,
    send_device_update_status
)

logging = Logging(name="inventory")
# Database configuration
db_config_withoutfilter = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema": False,
}


def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes requests.

    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler

    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts

    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler

    path_function_map = {
        "/service_provider_change_types": service_provider_change_types,
        "/update_carrier_rate_plan": update_carrier_rate_plan,
        "/update_customer_rate_plan": update_customer_rate_plan,
        "/edit_cost_center": update_edit_cost_center,
        "/update_status": update_status,
        "/update_features": update_features,
        "/update_line_sync":update_line_sync,
    }
    # Use the map to call the corresponding function
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.info(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result

#sub functions
def service_provider_change_types(data):
    """
    Retrieves allowed change types for a specific service provider.

    Args:
        data (dict): Contains service_provider_id, db_name

    Returns:
        dict: Response with flag and list of allowed change_types
    """
    service_provider_id = data.get("service_provider_id", "")
    db_name = data.get("db_name", "")
    try:
        tenant_database = DB(db_name, **db_config_withoutfilter)
        change_type_ids = tenant_database.get_data(
            "smi_change_type_mapping",
            {"serviceprovider_id": int(service_provider_id), "is_allowed": True},
            ["change_type_id"],
        )["change_type_id"].to_list()

        change_types_df = tenant_database.get_data(
            "inventory_change_type",
            {"status": "active"},
            ["id", "change_type_name"],
        )
        # Get names for the change_type_ids
        change_types_names = change_types_df[
            change_types_df["id"].isin(change_type_ids)
        ]["change_type_name"].to_list()
        return {"flag": True, "change_types": change_types_names}

    except Exception as exception:
        logging.error(f"### Error in service_provider_change_types: {exception}")
        return {"flag": True, "change_types": []}

#data validatuon
def validate_inventory_data(data):
    """
    Validates inventory data and database connections for device operations.
    
    Args:
        data (dict): Contains changed_data, service_provider_display_name, tenant_name, and db_name
    
    Returns:
        dict: Response with flag, validated data objects, and error messages if validation fails
    """
    logging.info(f"### validate_inventory_data Request Data: {data}")
    changed_data = data.get("changed_data", [])
    row_ids = [record.get("id") for record in changed_data if "id" in record]

    # Extract and validate required input parameters
    service_provider = data.get("service_provider_display_name", "")

    # Validate tenant name is provided
    tenant_name = data.get("tenant_name")
    if not tenant_name:
        return {"flag": False, "message": "No tenant name provided."}

    # Handle special case for Altaworx Test tenant
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    # Get database name for tenant-specific operations
    db_name = data.get("db_name", "")

    try:
        # Initialize database connections
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter
        )

        # Validate tenant exists in the system
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name,"is_active":True},
        )
        if tenant_data.empty:
            return {"flag": False, "message": "Tenant not found."}

        # Connect to tenant-specific database
        tenant_database = DB(db_name, **db_config_withoutfilter)

        # Retrieve inventory details for the specified device
        inventory_data = tenant_database.get_data(
            "sim_management_inventory",
            {"id": row_ids},
          
            ["id", "iccid","subscription_id","msisdn", "service_provider_display_name", "carrier_rate_plan_name", "eid","account_number","customer_name","mobility_device_id","device_id","customer_rate_plan_name","sim_status","cost_center","telegence_features"],
        )
        if inventory_data.empty:
            return {"flag": False, "message": "Inventory details not found."}

        # Validate service provider exists in tenant database
        service_provider_data = tenant_database.get_data(
            "serviceprovider",
            {"service_provider_name": service_provider},
            ["id", "integration_id"],
        )
        if service_provider_data.empty:
            return {"flag": False, "message": "Service provider not found."}
        return {
            "flag": True,
            "inventory_data": inventory_data,
            "tenant_data": tenant_data,
            "service_provider_data": service_provider_data,
            "tenant_database": tenant_database,
            "common_utils_database": common_utils_database,
        }
    except Exception as exception:
        logging.exception(f"### validate_inventory_data Exception : {exception}")
        return {"flag": False, "message": "Error validating inventory data."}

def _update_inventory_records(carrier_response, updated_changed_data, 
                              inventory_data, tenant_database):
    """
    Updates inventory records for successfully processed devices.
    
    Args:
        carrier_response (dict): Response from carrier API
        changed_data (list): Original change data
        inventory_data (DataFrame): Inventory data
        tenant_database (DB): Database connection
        carrier_rate_plan_id (int): Rate plan ID
    """
    try:
        logging.info(f"### _update_inventory_records Request Data : {carrier_response}")
        failed_count = carrier_response.get("failed_count", 0)
        
        
        if failed_count == 0:
            # All devices successful - update all records
            updated_count = tenant_database.bulk_update_data(
                "sim_management_inventory", updated_changed_data, search_column="id"
            )
            if updated_count:
                logging.info(f"### _update_inventory_records Updated {len(updated_changed_data)} inventory records")
            else:
                logging.warning("### _update_inventory_records No inventory records updated")
        else:
            # Partial success - update only successful devices
            successful_devices = carrier_response.get("successful_devices", [])
            device_type = carrier_response.get("device_type", "iccid")
            
            # Filter inventory data for successful devices
            successful_inventory = inventory_data[
                inventory_data[device_type].isin(successful_devices)
            ]
            successful_ids = successful_inventory["id"].tolist()
            
            # Filter changed_data for successful devices only
            successful_changes = [
                record for record in updated_changed_data 
                if record["id"] in successful_ids
            ]
            
            if successful_changes:
                updated_count = tenant_database.bulk_update_data(
                    "sim_management_inventory", successful_changes, search_column="id"
                )
                if updated_count:
                    logging.info(f"### _update_inventory_records Updated {len(successful_changes)} inventory records")
                else:
                    logging.warning("### _update_inventory_records No inventory records updated")
            
            # Log failed devices
            failed_ids = set(record["id"] for record in updated_changed_data) - set(successful_ids)
            if failed_ids:
                logging.warning(f"### _update_inventory_records Failed to update inventory for device IDs: {failed_ids}")
                
    except Exception as exception:
        logging.exception(f"### _update_inventory_records Error updating inventory records: {exception}")

def fetch_previous_current_value(data,inventory_data):
    """Fetch previous and current values based on change event type"""
    # result = validate_inventory_data(data)
    # if not result["flag"]:
    #     return None, None
        
    change_event_type = data.get("change_event_type", "")
    changed_data = data.get("changed_data", [{}])
    first_record = changed_data[0] if changed_data else {}
    
    if change_event_type == 'Update feature':
        previous_value = inventory_data["telegence_features"].iloc[0]
        current_value = first_record.get("telegence_features", "")
    elif change_event_type == 'Update Customer Rate Plan':
        previous_value = inventory_data["customer_rate_plan_name"].iloc[0]
        current_value = first_record.get("customer_rate_plan_name", "")
    elif change_event_type == 'Update Carrier Rate Plan':
        previous_value = inventory_data["carrier_rate_plan_name"].iloc[0]
        current_value = first_record.get("carrier_rate_plan_name", "")
    elif change_event_type == 'Update Status':
        previous_value = inventory_data["sim_status"].iloc[0]
        current_value = first_record.get("sim_status", "")
    elif change_event_type == "Line Sync":
        key = list(first_record.keys())[1] if len(first_record.keys()) > 1 else None
        previous_value = inventory_data[key].iloc[0] if key in inventory_data.columns else ""
        current_value = first_record.get(key, "")
    else:
        previous_value = inventory_data["cost_center"].iloc[0]
        current_value = first_record.get("cost_center", "")
    
    return previous_value, current_value

def update_data_direct_db(tenant_database, changed_data):
    """
    Updates inventory records directly in database without API calls.
    
    Args:
        tenant_database (DB): Database connection object
        changed_data (list): List of records to update
    
    Returns:
        dict: Success response with flag and message
    """
    logging.info(f"### update_data_direct_db Updating {len(changed_data)} inventory records")
    updated_count = tenant_database.bulk_update_data(
        "sim_management_inventory", changed_data, search_column="id"
    )
    return {"flag": True, "message": "Customer rate plan records updated successfully"}

def _prepare_cost_center_data(changed_data, inventory_data, tenant_database):
    """
    Prepare cost center data by merging with inventory and rev_service data.
    
    Args:
        changed_data (list): Original change data
        inventory_data (DataFrame): Inventory data
        tenant_database (DB): Database connection
    
    Returns:
        list: Merged data with rev_service_id included
    """
    
    
    # Get unique MSISDNs
    msisdns = inventory_data["msisdn"].unique().tolist()
    
    # Fetch rev_service_id from rev_service table
    rev_data_df = tenant_database.get_data(
        "rev_service",
        {"number": msisdns, "is_active": True},
        ["number", "rev_service_id"]
    )
    
    if rev_data_df.empty:
        logging.warning("No rev_service data found for MSISDNs")
        return changed_data
    
    # Remove duplicates and prepare for merge
    rev_data_df = rev_data_df.drop_duplicates(subset=["number"], keep="last")
    
    # Convert to DataFrames and merge
    changed_data_df = pd.DataFrame(changed_data)
    inventory_subset = inventory_data[["iccid", "msisdn"]].drop_duplicates("iccid", keep="last")
    
    # Merge operations
    merged_df = changed_data_df.merge(inventory_subset, on="iccid", how="left")
    final_df = merged_df.merge(
        rev_data_df.rename(columns={"number": "msisdn"}),
        on="msisdn",
        how="left"
    )
    
    final_df["rev_service_id"] = final_df["rev_service_id"].astype("Int64")
    return final_df.to_dict(orient="records")

def _process_cost_center_with_api(updated_changed_data, service_provider, change_event_type,
                                 common_utils_database, tenant_database, cost_center):
    """
    Process cost center updates with carrier API calls.
    
    Args:
        updated_changed_data (list): Prepared data with rev_service_id
        service_provider (str): Service provider name
        change_event_type (str): Type of change event
        common_utils_database (DB): Common database connection
        tenant_database (DB): Tenant database connection
        cost_center (str): Cost center value to update
    
    Returns:
        dict: Response with success/failure status
    """
    # Get carrier API configuration
    carrier_api_url, carrier_limits, app_id, app_secret, _ = get_carrier_api_details(
        service_provider, change_event_type, common_utils_database
    )
    
    if not carrier_api_url:
        return {"flag": False, "message": "Carrier API configuration not found"}
    
    if isinstance(carrier_limits, str):
        carrier_limits = json.loads(carrier_limits)
    
    parallel_requests = min(carrier_limits.get("parallel_requests", 5), len(updated_changed_data), 10)
    
    def process_record(record):
        """Process single record with API call."""
        try:
            rev_service_id = record.get("rev_service_id")
            if not rev_service_id:
                logging.info(f"No rev_service_id for record {record.get('id')}, skipping API")
                return _clean_record_for_db(record)
            
            # Make API call
            api_success = _update_cost_center_via_api(
                carrier_api_url, app_id, app_secret, rev_service_id, cost_center
            )
            
            if api_success:
                return _clean_record_for_db(record)
            else:
                logging.error(f"API call failed for record {record.get('id')}")
                return None
                
        except Exception as exception:
            logging.exception(f"Error processing record {record.get('id')}: {exception}")
            return None
    
    # Process records in parallel
    with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
        futures = [executor.submit(process_record, record) for record in updated_changed_data]
        successful_records = [result for result in (f.result() for f in as_completed(futures)) if result]
    
    # Update database
    if successful_records:
        updated_count = tenant_database.bulk_update_data(
            "sim_management_inventory", successful_records, "id"
        )
        logging.info(f"Updated {updated_count} records in database")
        return {"flag": True, "message": f"Successfully updated {len(successful_records)} records"}
    else:
        return {"flag": False, "message": "No records were successfully processed"}

def _process_cost_center_without_api(changed_data, tenant_database):
    """Process cost center updates without carrier API calls."""
    updated_count = tenant_database.bulk_update_data(
        "sim_management_inventory", changed_data, "id"
    )
    logging.info(f"Updated {updated_count} records without API calls")
    return {"flag": True, "message": f"Successfully updated {updated_count} records"}

def _update_cost_center_via_api(carrier_api_url, app_id, app_secret, rev_service_id, cost_center):
    """Update cost center via carrier API."""
    headers = {
        "Authorization": app_id,
        "Ocp-Apim-Subscription-Key": app_secret,
        "Content-Type": "application/json-patch+json"
    }
    url = f"{carrier_api_url}/{rev_service_id}"
    
    try:
        # GET service details
        resp_get = requests.get(url, headers=headers, timeout=60)
        if resp_get.status_code != 200:
            logging.error(f"GET API failed for {rev_service_id}: {resp_get.status_code}")
            return False
        
        response_data = resp_get.json()
        fields = response_data.get("fields", [])
        
        # Find CostCenter field index
        costcenter_index = None
        for i, field in enumerate(fields):
            if field.get("label", "").startswith("CostCenter"):
                costcenter_index = i
                break
        
        if costcenter_index is None:
            logging.info(f"CostCenter field not found for {rev_service_id}")
            return True  # No field to update, consider success
        
        # PATCH cost center value
        payload = [{
            "op": "replace",
            "path": f"/fields/{costcenter_index}/value",
            "value": cost_center
        }]
        
        resp_patch = requests.patch(url, json=payload, headers=headers, timeout=60)
        success = 200 <= resp_patch.status_code < 300
        
        if not success:
            logging.error(f"PATCH API failed for {rev_service_id}: {resp_patch.status_code}")
        
        return success
        
    except Exception as exception:
        logging.exception(f"API call error for {rev_service_id}: {exception}")
        return False

def _clean_record_for_db(record):
    """Remove unnecessary fields from record before database update."""
    cleaned = record.copy()
    cleaned.pop("iccid", None)
    cleaned.pop("msisdn", None)
    cleaned.pop("rev_service_id", None)
    return cleaned

def build_to_update_dict(api_data, inventory_row, keys_to_check):
    """
    Compare API data with inventory row and return only changed fields.
    Normalizes values (strip + string conversion).
    Skips keys where API gives None.
    """

    def normalize(val):
        return str(val).strip() if val is not None else None

    to_update = {}
    for key in keys_to_check:
        new_val = normalize(api_data.get(key))
        old_val = normalize(inventory_row.get(key))
        if new_val is not None and new_val != old_val:
            to_update[key] = new_val

    return to_update
 
 
def update_telegence_features(database, msisdn, offering_code, operation):
    """
    Update a single offering code in the telegence_features field.
    If no record exists for the msisdn, insert a new one.
    
    :param database: DB helper with get_data, update_dict, insert_dict
    :param msisdn: phone number identifier (string)
    :param offering_code: code to add or remove (string)
    :param operation: either 'add' or 'remove'
    """
    try:
        logging.info(f"##telegence_bc_update_feature processing msisdn={msisdn}, operation={operation}, code={offering_code}")

        # Fetch the current DB value
        row = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "msisdn": msisdn},
            ["telegence_features"]
        )

        if row is None or row.empty:
            # No record exists
            if operation == "add":
                updated_features = offering_code
                database.insert_dict(
                    "sim_management_inventory",
                    {
                        "msisdn": msisdn,
                        "is_active": True,
                        "telegence_features": updated_features
                    }
                )
                logging.info(f"Inserted new record for msisdn={msisdn} with features={updated_features}")
                return updated_features
            else:
                logging.warning(f"No record found for msisdn={msisdn} and operation={operation}. Nothing to remove.")
                return []

        # Existing record
        features_str = row["telegence_features"].iloc[0] if "telegence_features" in row else None
        existing = [x.strip() for x in features_str.split(",")] if features_str else []

        # Modify list
        if operation == "add":
            if offering_code not in existing:
                existing.append(offering_code)
        elif operation == "remove":
            if offering_code in existing:
                existing.remove(offering_code)
        else:
            logging.warning(f"Unknown operation={operation} for msisdn={msisdn}")

        updated_features = ",".join(existing)

        # Update DB
        database.update_dict(
            "sim_management_inventory",
            {"telegence_features": updated_features},
            and_conditions={"is_active": True, "msisdn": msisdn}
        )
        logging.info(f"Updated msisdn={msisdn} with features={updated_features}")
        return updated_features

    except Exception as exception:
        logging.exception(f"Failed to update telegence_features for msisdn={msisdn}")
        return None

#sim management inventory action history updating
def inventory_action_history_update(data,result):
    """Update inventory action history for all changed records"""

    inventory_data = result["inventory_data"]
    

    
    # Get common data
    service_provider_id = result["service_provider_data"]["id"].iloc[0]
    tenant_id = result["tenant_data"]["id"].iloc[0]
    tenant_database = result["tenant_database"]
    
    # Process each record in changed_data
    changed_data = data.get("changed_data", [])
    insert_into_history = []
    for record in changed_data:
        row_id = record.get("id")
        if not row_id:
            continue
        single_record = inventory_data[inventory_data["id"] == row_id]
        if single_record.empty:
            continue
        # Extract data from the single record
        msisdn = single_record["msisdn"].iloc[0]
        account_number = single_record["account_number"].iloc[0]
        customer_name = single_record["customer_name"].iloc[0]
        mobility_device_id = single_record["mobility_device_id"].iloc[0]
        device_id = single_record["device_id"].iloc[0]
        iccid = single_record["iccid"].iloc[0]
       
        # Get previous and current values
        previous_value, current_value = fetch_previous_current_value({
            **data,
            "changed_data": [record]  # Pass only this record
        },inventory_data)
        
        # Create history record
        sim_management_inventory_action_history = {
            "iccid": str(iccid),
            "sim_management_inventory_id": row_id,
            "msisdn": str(msisdn),
            "username": str(data.get("username", "")),
            "change_event_type": str(data.get("change_event_type", "")),
            "date_of_change": datetime.utcnow(),
            "changed_by": str(data.get("username", "")),
            "is_deleted": False,
            "is_active": True,
            "service_provider_id": int(service_provider_id),
            "customer_account_number": str(account_number),
            "tenant_id": int(tenant_id),
            "service_provider": str(data.get("service_provider_display_name", "")),
            "bulk_change_id": int(data.get("bulk_change_id", 0)) if data.get("bulk_change_id") else None,
            "uploaded_file_id": int(data.get("uploaded_file_id", 0)) if data.get("uploaded_file_id") else None,
            "previous_value": str(previous_value) if previous_value else None,
            "current_value": str(current_value) if current_value else None,
            "changed_field": str(data.get("change_event_type", "")),
            "customer_account_name": str(customer_name),
            "m2m_device_id": int(device_id) if device_id else None,
            "mobility_device_id": int(mobility_device_id) if mobility_device_id else None,
        }
        insert_into_history.append(sim_management_inventory_action_history)
    # Insert history record
    if insert_into_history:
        tenant_database.insert_data(insert_into_history, "sim_management_inventory_action_history")

#audit log updating
def insert_audit_logs(data):
    """
    Records audit information for inventory operations into the database.
    Based on the operation outcome (success or failure), this function logs 
    the details into either the `audit_user_actions` table (for successful 
    actions) or the `error_log_table` (for failed actions).

    Args:
        data (dict): Input request payload containing:
            - tenant_id (int, optional): ID of the tenant.
            - tenant_name (str, optional): Name of the tenant.
            - user_id (int, optional): ID of the user performing the action.
            - username (str, optional): Name of the user performing the action.
            - service_provider_display_name (str, optional): Name of the service being invoked.
            - session_id (str, optional): Unique session identifier.

    Returns:
        None: The function does not return a value but writes logs to the 
        appropriate audit/error tables.        

    """
    logging.info(f"### insert_audit_logs Request Data: {data}")


    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at",datetime.now().timestamp())
    message = data.get("message", "")
    change_type = data.get("change_type", "")
    start_time = request_received_at
    service_provider = data.get("service_provider_display_name", "")
    session_id = data.get("session_id", "")
    error_type = data.get('error_type',"")
    comments = data.get('comments', "")
    
    # Initialize database connection
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter ) 
    
    if data.get("flag") == True : 
        try:
            end_time = time.time()
            start_time = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S.%f').timestamp()
            time_consumed = end_time - start_time  
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name":data.get('service_name'),
                "created_by": username,
                "status": True,
                "session_id":session_id,
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Inventory",
                "comments": message,
                "request_received_at": request_received_at
            }
        
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as exception:
            logging.warning(f"### Audit logging failed for tenant : {tenant_name} and service_provider : {service_provider} and change_type : {change_type}  and error :  {exception}")
    else :
        try:
            end_time = time.time()
            start_time = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S.%f').timestamp()
            time_consumed = end_time - start_time  
            time_consumed = int(round(time_consumed))
            error_data = {
                "service_name": data.get('service_name'),
                "created_by": username,
                "status": False,
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Inventory",
                "comments": comments,
                "session_id":session_id,
                "error_type":error_type,
                "error_message": message,
                "request_received_at":request_received_at 
            }
        
            common_utils_database.update_audit(error_data, "error_log_table")
        except Exception as exception:
            logging.warning(f"### Error logging failed for tenant : {tenant_name} and service_provider : {service_provider} and change_type : {change_type}  and error :  {exception}")    

# device history updating
def insert_device_history_records(tenant_name, username, iccids, service_provider, db_name,msisdns,effective_date=None):
    """
    Invokes Lambda function to update device history tables.
    
    Args:
        tenant_name (str): Name of the tenant
        username (str): Username performing the operation
        iccids (list): List of ICCID values to update
        service_provider (str): Service provider name
        db_name (str): Database name
    
    Returns:
        dict: False response if Lambda invocation fails, True otherwise
    """
    try:
        logging.info(f"### Invoking insert_device_history_records Lambda iccids : {iccids} , msisdns : {msisdns}, effective_date : {effective_date}")
        env = os.environ.get("ENV", "UAT").upper()
        lambda_name = "module_management_uat" if env == "UAT" else "module_management"
        lambda_payload = {
            "data": {
                "data": {
                    "tenant_name": tenant_name,
                    "username": username,
                    "path": "/update_device_history_tables",
                    "iccids": iccids,
                    "service_provider":service_provider,
                    "db_name": db_name,
                    "msisdns":msisdns,
                    "effective_date":effective_date
                }
            }
        }
        lambda_client = boto3.client('lambda')
        invoke_response = lambda_client.invoke(
            FunctionName = lambda_name,
            InvocationType = 'Event',
            Payload = json.dumps(lambda_payload),
        )
        logging.info(f"### insert_device_history_records Lambda invoked :{invoke_response}")
        return True
    except Exception as exception:
        logging.exception(f"### Error during insert_device_history_records: {exception}")
        return False
  
    
#carrier rate plan change type
def update_carrier_rate_plan(data):
    """
    Updates carrier rate plan for multiple devices.
    
    Args:
        data (dict): Request data containing device and rate plan information
    
    Returns:
        dict: Response with success/failure status and device processing details
    """
    logging.info(f"### update_carrier_rate_plan Request Data: {data}")

    
    # Validate input data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response
    
    # Extract validated data
    tenant_database = validate_response["tenant_database"]
    common_utils_database = validate_response["common_utils_database"]
    inventory_data = validate_response["inventory_data"]
    
    
    # Extract request parameters
    service_provider = data.get("service_provider_display_name", "")
    tenant_name=data.get("tenant_name", "")
    username=data.get("username", "")
    db_name=data.get("db_name", "")
    
    access_token=data.get("access_token", "")
    change_event_type = "Change Carrier Rate Plan"
    changed_data = data.get("changed_data", [])
    data["service_name"] = "update_carrier_rate_plan"
    
    # Get carrier rate plan details
    carrier_rate_plan_name = next((record.get("carrier_rate_plan_name") for record in changed_data), None)
    if not carrier_rate_plan_name:
        return {"flag": False, "message": "No carrier rate plan name provided"}
    
    communication_plan = next((record.get("communication_plan") for record in changed_data),None)
    effective_date = next((record.get("effective_date") for record in changed_data), None)
    
    try:
        # Validate rate plan exists
        rate_plan_data = tenant_database.get_data(
            "carrier_rate_plan",
            {"rate_plan_code": carrier_rate_plan_name, "is_active": True},
            ["id", "jasper_rate_plan_id"]
        )
        if rate_plan_data.empty:
            return {"flag": False, "message": "Rate plan not found"}
        
        jasper_rate_plan_id = rate_plan_data["jasper_rate_plan_id"].iloc[0]
        carrier_rate_plan_id = rate_plan_data["id"].iloc[0]
        
        # Prepare device lists for carrier API
        iccids = inventory_data["iccid"].tolist()
        msisdns = inventory_data["msisdn"].tolist()

        carrier_api_status = data.get("carrier_api_status",False)
        
        # Call carrier API
        if not carrier_api_status:
            updated_changed_data = [
                {**record, "carrier_rate_plan_id": int(carrier_rate_plan_id)}
                for record in changed_data
            ]
            updated_count = tenant_database.bulk_update_data(
                "sim_management_inventory", updated_changed_data, search_column="id"
            )
            logging.info(f"### update_carrier_rate_plan Updated {updated_count} inventory records")
            # call insert_audit_logs to insert records into device_history tables
            audit_data = data.copy()
            audit_data["flag"] = True
            audit_data["message"] = json.dumps(changed_data)
            threading.Thread(target=insert_audit_logs, args=(audit_data,),daemon=True).start()
            return {"flag":True, "message": "Carrier rate plan updated successfull,y"}

        carrier_response = send_carrier_rate_plan_update_request(
            service_provider, change_event_type, common_utils_database, tenant_database,
            communication_plan, carrier_rate_plan_name, jasper_rate_plan_id, iccids, msisdns
        )
        
        # Update inventory for successful devices
        if carrier_response.get("flag"):
            # Add carrier_rate_plan_id to all records
            updated_changed_data = [
                {**record, "carrier_rate_plan_id": int(carrier_rate_plan_id)}
                for record in changed_data
            ]
            _update_inventory_records(carrier_response, updated_changed_data, 
                                    inventory_data, tenant_database)
            
            # call insert_audit_logs to insert records into device_history tables
            audit_data = data.copy()
            audit_data["flag"] = True
            audit_data["message"] = json.dumps(changed_data)
            threading.Thread(target=insert_audit_logs, args=(audit_data,),daemon=True).start()
            try:
                threading.Thread(target=inventory_action_history_update, args=(data,validate_response), daemon=True).start()
                insert_device_history_records(tenant_name, username, iccids, service_provider, db_name,msisdns,effective_date)
            except Exception as exception:
                logging.error(f"### Error in inventory_action_history_update: {exception}")
            return {
                "flag":True,
                "message": "Carrier rate plan update request sent successfully",
                "successful_count": carrier_response.get("success_count", 0),
                "failed_count": carrier_response.get("failed_count", 0)
            }
        else:
            audit_data = data.copy()
            audit_data["flag"] = False
            audit_data["message"] = carrier_response.get("message", "Failed to send carrier rate plan update request")
            audit_data["comments"] = json.dumps(changed_data)
            threading.Thread(target=insert_audit_logs, args=(audit_data,), daemon=True).start()
            return {
                "flag": False,
                "message": "Failed to send carrier rate plan update request",
                "error": carrier_response.get("message", "Unknown error")
            }
    except Exception as exception:
        logging.exception(f"### update_carrier_rate_plan Error: {exception}")
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(exception)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(exception).__name__,
        threading.Thread(target=insert_audit_logs, args=(error_data,), daemon=True).start()
        return {"flag": False, "message": "Error updating carrier rate plan"}

#customer rate plan chnage type
def update_customer_rate_plan(data):
    """
    Updates customer rate plan for multiple devices in inventory.
    
    This function validates the input data, checks if the specified customer rate plan
    and optional rate pool exist, then updates the inventory records with the new
    rate plan information.
    
    Args:
        data (dict): Request data containing:
            - changed_data (list): List of device records to update, each containing:
                - id (int): Device inventory ID
                - customer_rate_plan_name (str): New customer rate plan name
                - customer_rate_pool_name (str, optional): Customer rate pool name
            - service_provider_display_name (str): Service provider name
            - tenant_name (str): Tenant name
            - db_name (str): Database name
    
    Returns:
        dict: Response with keys:
            - flag (bool): Success/failure indicator
            - message (str): Status message
    """
    logging.info(f"### update_customer_rate_plan Request Data Received: {data}")
    tenant_name=data.get("tenant_name", "")
    username=data.get("username", "")
    service_provider=data.get("service_provider_display_name", "")
    access_token=data.get("access_token", "")
    changed_data = data.get("changed_data", [])
    db_name=data.get("db_name", "")
    effective_date = next((record.get("effective_date") for record in changed_data), None)
    

    # Validate input data
    validate_response = validate_inventory_data(data)
    inventory_data = validate_response["inventory_data"]
    iccids = inventory_data["iccid"].tolist()
    msisdns = inventory_data["msisdn"].tolist()
    if not validate_response["flag"]:
        return validate_response
    
    tenant_database = validate_response["tenant_database"]
    changed_data = data.get("changed_data", [])

    if not changed_data:
        return {"flag": False, "message": "No records provided for update"}

    # Get customer rate plan details
    customer_rate_plan_name = next((r.get("customer_rate_plan_name") for r in changed_data), None)
    if not customer_rate_plan_name:
        return {"flag": False, "message": "No customer rate plan name provided"}  

    try:
        # Validate rate plan exists
        rate_plan_data = tenant_database.get_data(
            "customerrateplan", {"rate_plan_name": customer_rate_plan_name, "is_active": True}, ["id"]
        )
        if rate_plan_data.empty:
            return {"flag": False, "message": "Customer rate plan not found"}
        customer_rate_plan_id = int(rate_plan_data["id"].iloc[0])

        # Validate rate pool (optional)
        customer_rate_pool_id = None
        customer_rate_pool_name = next((r.get("customer_rate_pool_name") for r in changed_data), None)
        if customer_rate_pool_name:
            rate_pool_data = tenant_database.get_data(
                "customer_rate_pool", {"name": customer_rate_pool_name, "is_active": True}, ["id"]
            )
            if rate_pool_data.empty:
                return {"flag": False, "message": "Customer rate pool not found"}
            customer_rate_pool_id = int(rate_pool_data["id"].iloc[0])
        
        # Enrich changed_data with rate plan IDs
        enriched_data = [
            {
                **rec,
                "customer_rate_plan_id": customer_rate_plan_id,
                **({"customer_rate_pool_id": customer_rate_pool_id} if customer_rate_pool_id else {})
            }
            for rec in changed_data
        ]
        
        # Bulk update DB
        result = update_data_direct_db(tenant_database, changed_data)
        if result.get("flag"):
            # Update inventory action history for all records
            audit_data = data.copy()
            audit_data["flag"] = True
            audit_data["message"] = json.dumps(changed_data)
            try:
                threading.Thread(target=inventory_action_history_update, args=(data,validate_response), daemon=True).start()
                insert_device_history_records(tenant_name, username, iccids, service_provider,db_name,msisdns,effective_date)
                
            except Exception as thread_error:
                logging.warning(f"### update_customer_rate_plan Background task failed: {thread_error}")

    except Exception as exception:
        logging.exception(f"### update_customer_rate_plan Error: {exception}")
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(exception)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(exception).__name__,
        thread = threading.Thread(target=insert_audit_logs, args=(error_data,),daemon=True)
        thread.start()
        return {"flag": False, "message": "Error updating customer rate plan"}

#edit cost center chnage type
def update_edit_cost_center(data):
    """
    Updates the cost center for multiple devices in inventory and syncs with carrier API.

    Args:
        data (dict): Request data containing device and cost center information

    Returns:
        dict: Response indicating success or failure of the operation
    """
    logging.info(f"### Edit Cost Center Request Data Received : {data}")

    # Extract and validate input
    tenant_name=data.get("tenant_name", "")
    username=data.get("username", "")
    service_provider=data.get("service_provider_display_name", "")
    access_token=data.get("access_token", "")
    carrier_api_status = data.get("carrier_api_status", True)
    change_event_type = data.get("change_event_type", "")
    changed_data = data.get("changed_data", [])
    data["service_name"] = "edit_cost_center"
    db_name=data.get("db_name", "")
    effective_date = next((record.get("effective_date") for record in changed_data), None)
    iccids = inventory_data["iccid"].tolist()
    if not changed_data:
        return {"flag": False, "message": "No data provided for update"}

    # Validate inventory data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response

    tenant_database = validate_response["tenant_database"]
    common_utils_database = validate_response["common_utils_database"]
    inventory_data = validate_response["inventory_data"]
    msisdns = inventory_data["msisdn"].tolist()
    # Get cost center from first record (assuming all records have same cost center)
    cost_center = changed_data[0].get("cost_center", "")
    if not cost_center:
        return {"flag": False, "message": "Cost center value is required"}
    
    # Prepare data for processing
    try:
        updated_changed_data = _prepare_cost_center_data(changed_data, inventory_data, tenant_database)
        logging.info(f"### Prepared {len(updated_changed_data)} records for processing")
    except Exception as exception:
        logging.exception(f"### Error preparing cost center data: {exception}")
        return {"flag": False, "message": "Failed to prepare data for processing"}
    try:
        if carrier_api_status:
            # Process with carrier API
            result = _process_cost_center_with_api(
                updated_changed_data, service_provider, change_event_type,
                common_utils_database, tenant_database, cost_center
            )
        else:
            # Process without carrier API
            result = _process_cost_center_without_api(changed_data, tenant_database)
        if result.get("flag"):
            try:
                threading.Thread(target=inventory_action_history_update, args=(data, validate_response), daemon=True).start()
                insert_device_history_records(tenant_name, username, iccids, service_provider,db_name,msisdns,effective_date)
            except Exception as thread_error:
                logging.exception(f"### update_cost_center inventory_action_history_update: {thread_error}")
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        threading.Thread(target=insert_audit_logs, args=(audit_data,),daemon=True).start()
        
        return result
        
    except Exception as exception:
        logging.exception(f"### Error in update_edit_cost_center: {exception}")
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(exception)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(exception).__name__,
        threading.Thread(target=insert_audit_logs, args=(error_data,),daemon=True).start()
        return {"flag": False, "message": "Cost center update failed"}

#update status change type
def update_status(data):
    """
    Updates device status for multiple devices in inventory and syncs with carrier API.
    
    Args:
        data (dict): Request data containing device and status information
    
    Returns:
        dict: Response with success/failure status and processing details
    """
    logging.info(f"### update_status Request Data Recieved : {data}")

    # Validate input data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response
    
    # Extract validated data
    tenant_database = validate_response["tenant_database"]
    common_utils_database = validate_response["common_utils_database"]
    inventory_data = validate_response["inventory_data"]
    service_provider_data = validate_response["service_provider_data"]
    integration_id = service_provider_data["integration_id"].to_list()[0]
    service_provider_id = service_provider_data["id"].to_list()[0]
    db_name=data.get("db_name", "")
    effective_date = next((record.get("effective_date") for record in changed_data), None)
    
    # Extract request parameters
    service_provider = data.get("service_provider_display_name", "")
    tenant_name=data.get("tenant_name", "")
    username=data.get("username", "")
    
    access_token=data.get("access_token", "")
    change_event_type = "Update Device Status"
    changed_data = data.get("changed_data", [])
    data["service_name"] = "update_status"

    if not changed_data:
        return {"flag": False, "message": "No records provided for update"}
    
    device_status = changed_data[0].get("sim_status", "")

    
    # Prepare device lists for carrier API
    iccids = inventory_data["iccid"].tolist()
    msisdns = inventory_data["msisdn"].tolist()
    carrier_api_status = data.get("carrier_api_status",False)

    try:
        if not carrier_api_status:
            required_fields = ["id", "sim_status", "device_status_id", "modified_by"]

            updated_changed_data = []
            for record in changed_data:
                new_record = {field: record.get(field) for field in required_fields}
                # Build user_address from telegence_additional_details
                details = record.get("telegence_additional_details", {})
                user_address = {
                    "City": details.get("City"),
                    "State": details.get("State"),
                    "Country": details.get("Country"),
                    "ZipCode": details.get("ZipCode"),
                    "LastName": details.get("LastName"),
                    "FirstName": details.get("FirstName"),
                    "AddressLine": details.get("StreetNo") or details.get("StreetName") or details.get("StreetDirection")
                }
                new_record["user_address"] = json.dumps(user_address)  # For jsonb field
                updated_changed_data.append(new_record)
                
            updated_count = tenant_database.bulk_update_data(
                "sim_management_inventory", updated_changed_data, search_column="id"
            )
            logging.info(f"### update_status Updated {updated_count} inventory records")
            return {"flag":True, "message": "Device updated successfully"}
        carrier_response = send_device_update_status(service_provider,service_provider_id,change_event_type,common_utils_database,changed_data,
                                                    tenant_database,device_status, integration_id, iccids, msisdns)
        
        # Update inventory for successful devices
        if carrier_response.get("flag"):
            # Add carrier_rate_plan_id to all records
            required_fields = ["id", "sim_status", "device_status_id", "modified_by"]

            updated_changed_data = []
            for record in changed_data:
                new_record = {field: record.get(field) for field in required_fields}
                # Build user_address from telegence_additional_details
                details = record.get("telegence_additional_details", {})
                user_address = {
                    "City": details.get("City"),
                    "State": details.get("State"),
                    "Country": details.get("Country"),
                    "ZipCode": details.get("ZipCode"),
                    "LastName": details.get("LastName"),
                    "FirstName": details.get("FirstName"),
                    "AddressLine": details.get("StreetNo") or details.get("StreetName") or details.get("StreetDirection")
                }
                new_record["user_address"] = json.dumps(user_address)  # For jsonb field
                updated_changed_data.append(new_record)
            
            _update_inventory_records(carrier_response, updated_changed_data, 
                                    inventory_data, tenant_database)
            try:
                threading.Thread(target=inventory_action_history_update, args=(data,validate_response), daemon=True).start()
                insert_device_history_records(tenant_name, username, iccids, service_provider, db_name,msisdns,effective_date)
            except Exception as exception:
                logging.error(f"### Error in inventory_action_history_update: {exception}")
            return {
                "flag":True,
                "message": "Device update request sent successfully",
                "successful_count": carrier_response.get("success_count", 0),
                "failed_count": carrier_response.get("failed_count", 0)
            }
        else:
            return {
                "flag": False,
                "message": "Failed to send Device update request",
                "error": carrier_response.get("message", "Unknown error")
            }
    except Exception as exception:
        logging.exception(f"### update_status exception : {exception}")
        data["flag"] = False
        data["message"] = str(exception)
        data["comments"] = json.dumps(changed_data)
        data["error_type"] = type(exception).__name__,
        thread = threading.Thread(target=insert_audit_logs, args=(data,))
        thread.start()
        return {
            "flag":False,
            "message":"Failed to send Device update request"
        }

#update feature change type
def update_features(data):
    """
    Updates mobility feature offering codes (add/remove) for multiple MSISDNs in 
    the inventory and synchronizes the changes with the carrier API.

    Args:
        data (dict): Request payload containing:
            - service_provider_display_name (str): Carrier/Service Provider name.
            - change_event_type (str): Type of change event (e.g., feature update).
            - changed_data (list[dict]): List of configuration change details,
              each containing `MobilityConfigurationIDsToAdd` and/or 
              `MobilityConfigurationIDsToRemove`.

    Returns:
        dict: Response with keys:
            - flag (bool): Indicates overall success or failure.
            - successful_ids (list[str]): List of MSISDNs successfully updated.
            - message (str, optional): Error message if operation failed.
    """
    
    logging.info(f"### update_features Request Data Received : {data}")

    # Input validation
    service_provider= data.get("service_provider_display_name", "")
    change_event_type = data.get("change_event_type", "")
    changed_data = data.get("changed_data", [])
    tenant_name=data.get("tenant_name", "")
    username=data.get("username", "")
    access_token=data.get("access_token", "")
    db_name=data.get("db_name", "")
    effective_date = next((record.get("effective_date") for record in changed_data), None)
    iccids = inventory_data["iccid"].tolist()
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response

    tenant_database = validate_response.get("tenant_database", {})
    common_utils_database = validate_response.get("common_utils_database", {})
    inventory_data = validate_response.get("inventory_data", {})
    
    msisdn_list = inventory_data["msisdn"].unique().tolist()
    msisdns = inventory_data["msisdn"].tolist()
    add_codes, remove_codes, successful_ids = [], [], []

    try:
       
        # Extract add/remove codes (changed_data is a list)
        for item in changed_data:
            config_details = item.get("configuration_change_details", {})
            if not config_details:
                continue
            add_codes.extend(config_details.get("MobilityConfigurationIDsToAdd", []))
            remove_codes.extend(config_details.get("MobilityConfigurationIDsToRemove", []))

        
        # Carrier API details
        carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
            service_provider, change_event_type, common_utils_database
        )
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)

        batch_size = carrier_limits.get("batch_size", 50)
        parallel_requests = min(carrier_limits.get("parallel_requests", 5), 10)
        interval = carrier_limits.get("interval_minutes", 1) * 60

        headers = {
            "app-id": app_id,
            "app-secret": app_secret,
            "page-size": "100",
            "current-page": "0",
            "Content-Type": "application/json"
        }

        logging.info(f"### update_features Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval}")

        MAX_RETRIES = 3
        RETRY_DELAY = 5
       
        def process_msisdn(msisdn):
            url = f"{carrier_api_url}/{msisdn}"
            overwrite_codes=[]
            success_flag=False
            get_response = requests.get(url, headers=headers, timeout=60)
            #success 
            if get_response.status_code == 200:
                    data = get_response.json()
                    svc_chars = data.get("serviceCharacteristic", [])
                    pattern = re.compile(r"^offeringCode\d+$")
                    for item in svc_chars:
                        if pattern.match(item.get("name", "")) and item.get("value"):
                            overwrite_codes.append(item.get("value"))
                    # --- Handle Remove ---
                    for offercode in overwrite_codes :
                        payload = {
                            "serviceCharacteristic": [
                                {"name": "removeOfferingCode", "value": offercode}
                            ]
                        }
                        success = False
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                resp = requests.patch(url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### Remove attempt {attempt} for {msisdn}, code {offercode}, status {resp.status_code},responseresult{resp.text}")
                                if 200 <= resp.status_code < 300:
                                    success = True
                                    break
                            except Exception as exception:
                                logging.warning(f"### Remove attempt {attempt} failed for {msisdn}: {exception}")
                                time.sleep(RETRY_DELAY)
                        if success:
                            update_telegence_features(tenant_database, msisdn, offercode, "remove")
                            logging.info(f"### Successfully removed code {offercode} for {msisdn}")
                            success_flag=True
                        else:
                            success_flag = False
            else:
                logging.warning(f"### GET failed for {msisdn}: {get_response.status_code}")
            
            # Handle ---Add 
            for offercode in add_codes:
                payload = {
                    "serviceCharacteristic": [
                        {"name": "addOfferingCode", "value": offercode}
                    ]
                }
                success = False
                for attempt in range(1, MAX_RETRIES + 1):
                    try:
                        resp = requests.patch(url, json=payload, headers=headers, timeout=60)
                        logging.info(f"### Add attempt {attempt} for {msisdn}, code {offercode}, status {resp.status_code}")
                        if 200 <= resp.status_code < 300:
                            success = True
                            break
                    except Exception as exception:
                        logging.warning(f"### Add attempt {attempt} failed for {msisdn}: {exception}")
                        time.sleep(RETRY_DELAY)
                if success:
                    update_telegence_features(tenant_database, msisdn, offercode, "add")
                    logging.info(f"### Successfully added code {offercode} for {msisdn}")
                    success_flag=True
                else:
                    success_flag = False
            # Handle Remove ---
            for offercode in remove_codes :
                payload = {
                    "serviceCharacteristic": [
                        {"name": "removeOfferingCode", "value": offercode}
                    ]
                }
                success = False
                for attempt in range(1, MAX_RETRIES + 1):
                    try:
                        resp = requests.patch(url, json=payload, headers=headers, timeout=60)
                        logging.info(f"### Remove attempt {attempt} for {msisdn}, code {offercode}, status {resp.status_code}")
                        if 200 <= resp.status_code < 300:
                            success = True
                            break
                    except Exception as exception:
                        logging.warning(f"### Remove attempt {attempt} failed for {msisdn}: {exception}")
                        time.sleep(RETRY_DELAY)
                if success:
                    update_telegence_features(tenant_database, msisdn, offercode, "remove")
                    logging.info(f"### Successfully removed code {offercode} for {msisdn}")
                    success_flag=True
                else:
                    success_flag = False

            if success_flag:
                successful_ids.append(msisdn)
                try:
                    threading.Thread(target=inventory_action_history_update, args=(data,validate_response), daemon=True).start()
                    insert_device_history_records(tenant_name, username, iccids, service_provider, db_name,msisdns,effective_date)
                except Exception as exception:
                    logging.error(f"### Error in inventory_action_history_update: {exception}")
            return success_flag

        # Process in batches with parallel threads
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(msisdn_list), batch_size):
                batch = msisdn_list[i:i + batch_size]
                futures = [executor.submit(process_msisdn, msisdn) for msisdn in batch]
                for f in as_completed(futures):
                    f.result()
                time.sleep(interval)

        return {"flag": True, "successful_ids": successful_ids}

    except Exception as exception:
        logging.exception(f"### Exception in update_features: {exception}")
        return {"flag": False, "message": "Error in update_features"}

#update line sync change type
def update_line_sync(data):
    """
    Perform an individual line synchronization between the local inventory and the carrier API.

    This function validates the incoming request payload, fetches the latest line details 
    (by ICCID or MSISDN) from the configured carrier API, and updates the local 
    `sim_management_inventory` table with the latest information if available.

    Args:
        data (dict): Input request containing:
            - service_provider_display_name (str): Name of the carrier/service provider.
            - other fields required by `validate_inventory_data`.

    Returns:
        dict: Response object with the following keys:
            - flag (bool): Indicates success (True) or failure (False).
            - message (str): Human-readable status message.
            - successful_count (int, optional): Number of devices successfully updated.
            - failed_count (int, optional): Number of devices that failed to update.
            - error (str, optional): Error details if the operation fails.

    """
    try:
        logging.info(f"### update_line_sync Request Data: {data}")
        service_provider = data.get("service_provider_display_name", "")
        change_event_type = "Line Sync"
        data['service_name'] = 'update_line_sync'
        tenant_name=data.get("tenant_name", "")
        username=data.get("username", "")
        access_token=data.get("access_token", "")
        changed_data = data.get("changed_data", [])
        db_name=data.get("db_name", "")
        effective_date = next((record.get("effective_date") for record in changed_data), None)


        # Validate input data
        try:
            validate_response = validate_inventory_data(data)
        except Exception as e:
            logging.exception("### update_line_sync Error during validate_inventory_data")
            return {"flag": False, "message": "Validation failed", "error": str(e)}

        if not validate_response["flag"]:
            return validate_response

        # Extract validated data
        tenant_data_base = validate_response["tenant_data_base"]
        common_utils_database = validate_response["common_utils_database"]
        inventory_data = validate_response["inventory_data"]

        # Prepare device lists for carrier API
        
        iccids = inventory_data["iccid"].dropna().unique().tolist()
        msisdns = inventory_data["msisdn"].dropna().unique().tolist()
        # Keep only unique ICCIDs, then build dict
        subscription_ids = (inventory_data.drop_duplicates(subset="iccid").set_index("iccid")["subscription_id"].dropna().to_dict())

        # Call carrier API to fetch details
        carrier_response = fetch_individual_line_sync_request(
            iccids, msisdns,subscription_ids, service_provider, change_event_type, common_utils_database
        )
        
        # Update inventory for successful devices
        if carrier_response.get("flag"):
            try:
                records_to_update = carrier_response.get("records_to_update", [])
                inventory_data["iccid"] = inventory_data["iccid"].astype(str).str.strip()
                inventory_data["msisdn"] = inventory_data["msisdn"].astype(str).str.strip()
                successful_devices = carrier_response.get("successful_devices", [])
                failed_devices = carrier_response.get("failed_devices", [])
                logging.info(f"successful_devices : {successful_devices}")

                # Build changed data records
                changed_data_records = []
                logging.info(f"inventory_data : {inventory_data}")
                logging.info(f"records_to_update : {records_to_update}")
                for record in records_to_update:
                    record_iccid = str(record.get("iccid") or "").strip()
                    record_msisdn = str(record.get("msisdn") or "").strip()
                    
                    # Find matching inventory record
                    matching_inventory = inventory_data[
                        (inventory_data["iccid"] == record_iccid) |
                        (inventory_data["msisdn"] == record_msisdn)
                    ]
                    
                    if not matching_inventory.empty:
                        inventory_row = matching_inventory.iloc[0]
                        # Use ALL keys from the API response (except 'id') for comparison
                        keys_to_check = [key for key in record.keys() if key != 'id']
                        
                        # Build to_update dict with only changed fields
                        to_update = build_to_update_dict(record, inventory_row, keys_to_check)
                        
                        if to_update:  # Only add if there are changes
                            to_update["id"] = int(inventory_row["id"])
                            changed_data_records.append(to_update)
                
                # Replace records_to_update with only changed data
                if not changed_data_records : 
                    logging.info(f"### update_line_sync Updated {len(records_to_update)} inventory records")
                    data['flag'] = True
                    data ['message'] = f"update_line_sync request sent successfully ,successful_devices : {successful_devices} and : failed_devices : {failed_devices}"
                    
                    # auditing logs 
                    insert_audit_logs(data)
                    
                    return {
                        "flag": True,
                        "message": "update_line_sync request sent successfully",
                        "successful_count": carrier_response.get("success_count", 0),
                        "successful_devices": successful_devices,
                        "failed_devices": failed_devices,
                        "failed_count": carrier_response.get("failed_count", 0)
                    }
                    
                else : 
                    records_to_update = changed_data_records
                    data['changed_data'] = records_to_update
                    try:
                        threading.Thread(target=inventory_action_history_update, args=(data,validate_response), daemon=True).start()
                        insert_device_history_records(tenant_name, username, iccids, service_provider, db_name,msisdns,effective_date)
                        
                    except Exception as thread_error:
                        logging.warning(f"### update_customer_rate_plan Background task failed: {thread_error}")
                    logging.info("### inventory_action_history_update executed.......")
                
            except Exception as e:
                logging.exception("### update_line_sync Error preparing records_to_update")
                return {"flag": False, "message": "Error preparing records for update", "error": str(e)}

            if records_to_update:

                logging.info(f"### update_line_sync Records to Update: {records_to_update}")

                update_flag = tenant_data_base.bulk_update_data(
                    "sim_management_inventory", records_to_update, search_column="id"
                )

                if update_flag:
                    logging.info(f"### update_line_sync Updated {len(records_to_update)} inventory records")
                    data['flag'] = True
                    data ['message'] = f"update_line_sync request sent successfully ,successful_devices : {successful_devices} and : failed_devices : {failed_devices}"
                    
                    # auditing logs
                    insert_audit_logs(data)
                    
                    return {
                        "flag": True,
                        "message": "update_line_sync request sent successfully",
                        "successful_count": carrier_response.get("success_count", 0),
                        "successful_devices": successful_devices,
                        "failed_devices": failed_devices,
                        "failed_count": carrier_response.get("failed_count", 0)
                    }
                else:
                    logging.warning("### update_line_sync No inventory records updated")
                    return {
                        "flag": False,
                        "message": "No inventory records were updated for update_line_sync request",
                        "successful_count": 0,
                        "failed_count": len(records_to_update),
                    }
            else:
                return {
                    "flag": True,
                    "message": "No records to update from carrier response",
                    "successful_count": 0,
                    "failed_count": 0
                }
        else:
            return {
                "flag": False,
                "message": "Failed to send update_line_sync",
                "error": carrier_response.get("message", "Unknown error")
            }

    except Exception as e:
        logging.exception(f"### update_line_sync Unexpected error : {e}")
        data['flag'] = False
        data ['message'] = f"update_line_sync Unexpected error : {e}"
        data['error_type'] = type(e).__name__   
        insert_audit_logs(data)
        return {"flag": False, "message": "Unexpected error in update_line_sync", "error": str(e)}
