"""
@Author1 : Ajay Reddi
@Author2 :
@Author3 :
Created Date: 05-09-2025
"""


"""
Carrier API integration functions for inventory management.
Contains SOAP and REST API calls to various carrier services.
"""

import requests
import json
import os
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from common_utils.logging_utils import Logging
from inventory_utils import get_verizon_token_details

logging = Logging(name="carrier_apis")



## Function to get Carrier API details
def get_carrier_api_details(service_provider,change_type,common_utils_database):
    '''
    Function to get the Carrier API URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The Carreir API URL,app_id,app_secret if found, otherwise None.'''
    # Initialize variables
    carrier_api_url=None
    app_id=None
    app_secret=None
    carrier_limit=None
    alternative_api_url=None
    ##carrier api query and their limits query
    carrier_details= common_utils_database.get_data(
    "bulk_change_carrier_limits", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["carrier_api_url","app_id","app_secret","carrier_limit","alternative_api_url"]
    )
    logging.info(f"carrier_details: {carrier_details}")
    if not carrier_details.empty:
        ##fetching the carrier API limits
        carrier_api_url=carrier_details.iloc[0]['carrier_api_url']
        app_id=carrier_details.iloc[0]['app_id']
        app_secret=carrier_details.iloc[0]['app_secret']
        carrier_limit=carrier_details.iloc[0]['carrier_limit']
        alternative_api_url=carrier_details.iloc[0].get('alternative_api_url', None)
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url
    else:
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url
    
PROVIDER_HEADERS = {
    "AT&T - Telegence - UAT ONLY": {"app-id": "{app_id}", "app-secret": "{app_secret}", "Content-Type": "application/json"},
    "AT&T - Telegence": {"app-id": "{app_id}", "app-secret": "{app_secret}", "Content-Type": "application/json"},
    "AT&T - Cisco Jasper": {"Authorization": "{app_id}", "Content-Type": "application/json"},
    "AT&T - POD19": {"Authorization": "{app_id}", "Content-Type": "application/json"},
    "T-Mobile Jasper": {"Authorization": "{app_id}", "Content-Type": "application/json"},
    "POND IoT": {"Authorization": "{app_id}", "ApiKey": "{app_secret}", "Accept": "application/json"},
    "Rogers": {"Authorization": "{app_id}", "Content-Type": "application/json"},
    "Teal": {"Authorization": "{app_id}", "Content-Type": "application/json"},
    "Verizon - ThingSpace PN": {"Authorization": "Bearer {access_token}", "VZ-M2M-Token": "{session_token}", "Content-Type": "application/json"},
    "Verizon - ThingSpace IoT": {"Authorization": "Bearer {access_token}", "VZ-M2M-Token": "{session_token}", "Content-Type": "application/json"},
    "Webbing": {"Content-Type": "text/xml; charset=utf-8"}
}

def _build_headers(service_provider, app_id, app_secret, **kwargs):
    """Build headers for service provider."""
    header_template = PROVIDER_HEADERS[service_provider]
    headers = {}
    
    for key, value in header_template.items():
        if "{app_id}" in value:
            headers[key] = value.replace("{app_id}", app_id)
        elif "{app_secret}" in value:
            headers[key] = value.replace("{app_secret}", app_secret)
        elif "{access_token}" in value:
            headers[key] = value.replace("{access_token}", kwargs.get("access_token", ""))
        elif "{session_token}" in value:
            headers[key] = value.replace("{session_token}", kwargs.get("session_token", ""))
        else:
            headers[key] = value
    
    return headers
 
    

def send_carrier_rate_plan_update_request(service_provider, change_type, common_utils_database, tenant_database, 
                                          communication_plan, carrier_rate_plan, jasper_rate_plan_id, iccid=[], msisdn=[]):
    """
    Sends carrier rate plan update request for multiple devices based on service provider.
    
    Args:
        service_provider (str): Service provider name
        change_type (str): Type of change event
        common_utils_database (DB): Database connection
        carrier_rate_plan (str): Rate plan name
        jasper_rate_plan_id (str): Jasper rate plan ID
        iccid (list): List of device ICCIDs
        msisdn (list): List of device MSISDNs
    
    Returns:
        dict: Response with flag, success_count, failed_count, and details
    """
    try:
        # Get carrier API configuration
        carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
            service_provider, change_type, common_utils_database
        )

        # Parse and validate carrier limits
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except (json.JSONDecodeError, TypeError):
                carrier_limits = {}
        elif not carrier_limits:
            carrier_limits = {}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Carrier API configuration not found"}
        
        if service_provider not in PROVIDER_HEADERS:
            return {"flag": False, "message": f"Unsupported service provider: {service_provider}"}
        
        # Define which providers use MSISDN vs ICCID
        msisdn_providers = ["AT&T - Telegence - UAT ONLY", "AT&T - Telegence"]
        iccid_providers = ["AT&T - Cisco Jasper", "AT&T - POD19", "T-Mobile Jasper", "POND IoT", "Rogers", "Teal", "Verizon - ThingSpace PN", "Verizon - ThingSpace IoT"]
        
        # Determine device list and type based on provider
        if service_provider in msisdn_providers:
            device_list = msisdn
            device_type = "msisdn"
        elif service_provider in iccid_providers:
            device_list = iccid
            device_type = "iccid"
        else:
            return {"flag": False, "message": f"Unsupported service provider: {service_provider}"}
        
        if not device_list:
            return {"flag": False, "message": f"No {device_type.upper()}s provided for {service_provider}"}
        
        # Pre-fetch tokens for Verizon providers to avoid redundant calls
        verizon_tokens = None
        if service_provider in ("Verizon - ThingSpace PN", "Verizon - ThingSpace IoT"):
            try:
                access_token, session_token = get_verizon_token_details(app_id, app_secret)
                verizon_tokens = {"access_token": access_token, "session_token": session_token}
            except Exception as e:
                logging.error(f"Failed to get Verizon tokens: {e}")
                return {"flag": False, "message": "Failed to authenticate with Verizon"}
        
        # Pre-fetch Webbing product_id to avoid redundant database calls
        webbing_product_id = None
        if service_provider == "Webbing":
            try:
                product_id_df = tenant_database.get_data(
                    "webbing_service_products_staging",
                    {"product_name": carrier_rate_plan},
                    ["product_id"]
                )
                if not product_id_df.empty:
                    webbing_product_id = product_id_df['product_id'].to_list()[0]
                else:
                    logging.info(f"No product found for Rate Plan: {carrier_rate_plan}, using null product_id")
            except Exception as e:
                logging.error(f"Failed to fetch Webbing product_id: {e}")
        
        # Use carrier limits for parallel processing (default to 5 if not set)
        parallel_requests = carrier_limits.get("parallel_requests", 5)
        max_workers = min(int(parallel_requests) if parallel_requests else 5, len(device_list))
        
        # Process devices in parallel using ThreadPoolExecutor
        success_count = 0
        failed_count = 0
        failed_devices = []
        successful_devices = []
        
        def process_single_device(device_id):
            try:
                # Route to appropriate provider handler
                if service_provider in ("AT&T - Telegence - UAT ONLY", "AT&T - Telegence"):
                    url = f"{carrier_api_url}/{device_id}"
                    payload = {
                        "serviceCharacteristic": [{
                            "name": "singleUserCode",
                            "value": carrier_rate_plan
                        }]
                    }
                    headers = _build_headers(service_provider, app_id, app_secret)
                    return _make_api_request(url, headers, payload, method="PATCH")
                
                elif service_provider in ("AT&T - Cisco Jasper", "T-Mobile Jasper", "Rogers"):
                    url = f"{carrier_api_url}/{device_id}"
                    payload = {"ratePlan": carrier_rate_plan}
                    headers = _build_headers(service_provider, app_id, app_secret)
                    return _make_api_request(url, headers, payload, method="PUT")
                
                elif service_provider == "AT&T - POD19":
                    url = f"{carrier_api_url}/{device_id}"
                    payload = {"ratePlan": carrier_rate_plan, "servicePlan": carrier_rate_plan}
                    headers = _build_headers(service_provider, app_id, app_secret)
                    return _make_api_request(url, headers, payload, method="PUT")
                
                elif service_provider == "POND IoT":
                    return _handle_pond_iot_carrier_rate_plan(carrier_api_url, app_id, app_secret, jasper_rate_plan_id, device_id)
                
                elif service_provider == "Teal":
                    url = f"{carrier_api_url}/{device_id}"
                    payload = {"ratePlan": carrier_rate_plan, "communicationPlan": communication_plan}
                    headers = _build_headers(service_provider, app_id, app_secret)
                    return _make_api_request(url, headers, payload, method="PUT")
                
                elif service_provider in ("Verizon - ThingSpace PN", "Verizon - ThingSpace IoT"):
                    if not verizon_tokens:
                        return {"flag": False, "message": "Verizon authentication failed"}
                    
                    headers = _build_headers(service_provider, app_id, app_secret, **verizon_tokens)
                    payload = {
                        "devices": [{
                            "deviceIds": [{"kind": "iccid", "id": device_id}]
                        }],
                        "servicePlan": carrier_rate_plan
                    }
                    return _make_api_request(carrier_api_url, headers, payload, method="PUT")
                
                elif service_provider == "Webbing":
                    return _handle_webbing_carrier_rate_plan(carrier_api_url, webbing_product_id, device_id)
                
                else:
                    return {"flag": False, "message": f"Unsupported service provider: {service_provider}"}
                    
            except Exception as e:
                logging.exception(f"Error processing {device_type} {device_id}: {e}")
                return {"flag": False, "message": f"Failed to update carrier rate plan: {str(e)}"}
        
        # Execute parallel processing
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            future_to_device = {executor.submit(process_single_device, device_id): device_id 
                              for device_id in device_list}
            
            # Collect results
            for future in as_completed(future_to_device):
                device_id = future_to_device[future]
                try:
                    result = future.result()
                    if result and result.get("flag"):
                        success_count += 1
                        successful_devices.append(device_id)
                    else:
                        error_msg = result.get("message", "Unknown error") if result else "No response"
                        logging.error(f"Failed to update {device_type} {device_id}: {error_msg}")
                        failed_count += 1
                        failed_devices.append({"device_id": device_id, "error": error_msg})
                except Exception as e:
                    failed_count += 1
                    failed_devices.append({"device_id": device_id, "error": str(e)})
                    logging.exception(f"Future exception for {device_type} {device_id}: {e}")
        
        # Return summary
        total_processed = success_count + failed_count
        overall_success = success_count > 0
        
        return {
            "flag": overall_success,
            "message": f"Processed {total_processed} devices. Success: {success_count}, Failed: {failed_count}",
            "success_count": success_count,
            "failed_count": failed_count,
            "successful_devices": successful_devices,
            "failed_devices": failed_devices,
            "device_type": device_type
        }
            
    except Exception as e:
        logging.exception(f"Error in send_carrier_rate_plan_update_request: {e}")
        return {"flag": False, "message": f"Failed to update carrier rate plan: {str(e)}"}
    
def send_device_update_status(service_provider, service_provider_id, change_type, common_utils_database, changed_data,
                              tenant_database, device_status, integration_id, iccid=[], msisdn=[]):
    """
    Sends device status update request for multiple devices based on service provider.
    
    Args:
        service_provider (str): Service provider name
        change_type (str): Type of change event
        common_utils_database (DB): Database connection
        tenant_database (DB): Tenant database connection
        device_status (str): New device status
        iccid (list): List of device ICCIDs
        msisdn (list): List of device MSISDNs
    
    Returns:
        dict: Response with flag, success_count, failed_count, and details
    """
    try:
        # Get carrier API configuration
        carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
            service_provider, change_type, common_utils_database
        )
        
        # Parse and validate carrier limits
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except (json.JSONDecodeError, TypeError):
                carrier_limits = {}
        elif not carrier_limits:
            carrier_limits = {}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Carrier API configuration not found"}
        
        if service_provider not in PROVIDER_HEADERS:
            return {"flag": False, "message": f"Unsupported service provider: {service_provider}"}
        
        # Define which providers use MSISDN vs ICCID
        msisdn_providers = ["AT&T - Telegence - UAT ONLY", "AT&T - Telegence"]
        iccid_providers = ["AT&T - Cisco Jasper", "AT&T - POD19", "T-Mobile Jasper", "POND IoT", "Rogers", "Teal", "Verizon - ThingSpace PN", "Verizon - ThingSpace IoT"]
        
        # Determine device list and type based on provider
        if service_provider in msisdn_providers:
            device_list = msisdn
            device_type = "msisdn"
        elif service_provider in iccid_providers:
            device_list = iccid
            device_type = "iccid"
        else:
            return {"flag": False, "message": f"Unsupported service provider: {service_provider}"}
        
        if not device_list:
            return {"flag": False, "message": f"No {device_type.upper()}s provided for {service_provider}"}
        
        # Pre-fetch tokens for Verizon providers to avoid redundant calls
        verizon_tokens = None
        if service_provider in ("Verizon - ThingSpace PN", "Verizon - ThingSpace IoT"):
            try:
                access_token, session_token = get_verizon_token_details(app_id, app_secret)
                verizon_tokens = {"access_token": access_token, "session_token": session_token}
            except Exception as e:
                logging.error(f"Failed to get Verizon tokens: {e}")
                return {"flag": False, "message": "Failed to authenticate with Verizon"}
            try:
                account_data= tenant_database.get_data(
                    "integration_authentication",
                    {"integration_id": integration_id, "service_provider_id": service_provider_id,},
                    ["oauth2_custom1"]
                )
                if not account_data.empty:
                    accountname = account_data.iloc[0]["oauth2_custom1"]
                else:
                    logging.error(f"### _handle_verizon_update_device_status Account name not found for integration ID: {integration_id}")
                    accountname = None
            except Exception as e:
                logging.error(f"### _handle_verizon_update_device_status Failed to fetch account name: {e}")
                accountname = None
            

        
        # Use carrier limits for parallel processing (default to 5 if not set)
        parallel_requests = carrier_limits.get("parallel_requests", 5)
        max_workers = min(int(parallel_requests) if parallel_requests else 5, len(device_list))
        
        # Process devices in parallel using ThreadPoolExecutor
        success_count = 0
        failed_count = 0
        failed_devices = []
        successful_devices = []

        def process_single_device(device_id):
            try:
                # Route to appropriate provider handler
                if service_provider in ("AT&T - Telegence - UAT ONLY", "AT&T - Telegence"):
                    # These providers don't support status updates via API
                    return {"flag": True, "message": "Status update not supported for this provider"}
                
                elif service_provider in ("AT&T - Cisco Jasper", "AT&T - POD19", "T-Mobile Jasper", "Rogers"):
                    url = f"{carrier_api_url}/{device_id}"
                    payload = {"status": device_status}
                    headers = _build_headers(service_provider, app_id, app_secret)
                    return _make_api_request(url, headers, payload, method="PUT")
                
                elif service_provider == "POND IoT":
                    headers = _build_headers(service_provider, app_id, app_secret)
                    return _handle_pond_iot_update_status(carrier_api_url, headers, device_status, device_id)
                
                elif service_provider == "Teal":
                    headers = _build_headers(service_provider, app_id, app_secret)
                    payload = {"entries": [device_id]}
                    
                    # Decide URL based on device status
                    if device_status.lower() in ["online", "waiting", "active"]:
                        url = f"{carrier_api_url}/enable"
                    elif device_status.lower() in ["stopped", "suspended", "disabled"]:
                        url = f"{carrier_api_url}/disable"
                    else:
                        return {
                            "flag": False,
                            "message": f"Unsupported device status '{device_status}' for Teal provider"
                        }
                    return _make_api_request(url, headers, payload, method="PUT")
                
                elif service_provider in ("Verizon - ThingSpace PN", "Verizon - ThingSpace IoT"):
                    if not verizon_tokens:
                        return {"flag": False, "message": "Verizon authentication failed"}
                    
                    headers = _build_headers(service_provider, app_id, app_secret, **verizon_tokens)
                    return _handle_verizon_update_device_status(carrier_api_url, headers, device_status, device_id, changed_data, accountname)
                
                elif service_provider == "Webbing":
                    return _handle_webbing_update_status(carrier_api_url, app_id, device_id, device_status, tenant_database)
                
                else:
                    return {"flag": False, "message": f"Unsupported service provider: {service_provider}"}
                    
            except Exception as e:
                logging.exception(f"Error processing {device_type} {device_id}: {e}")
                return {"flag": False, "message": f"Failed to update device status: {str(e)}"}
        
        # Execute parallel processing
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            future_to_device = {executor.submit(process_single_device, device_id): device_id 
                              for device_id in device_list}
            
            # Collect results
            for future in as_completed(future_to_device):
                device_id = future_to_device[future]
                try:
                    result = future.result()
                    if result and result.get("flag"):
                        success_count += 1
                        successful_devices.append(device_id)
                    else:
                        error_msg = result.get("message", "Unknown error") if result else "No response"
                        logging.error(f"Failed to update {device_type} {device_id}: {error_msg}")
                        failed_count += 1
                        failed_devices.append({"device_id": device_id, "error": error_msg})
                except Exception as e:
                    failed_count += 1
                    failed_devices.append({"device_id": device_id, "error": str(e)})
                    logging.exception(f"Future exception for {device_type} {device_id}: {e}")
        
        # Return summary
        total_processed = success_count + failed_count
        overall_success = success_count > 0
        
        return {
            "flag": overall_success,
            "message": f"Processed {total_processed} devices. Success: {success_count}, Failed: {failed_count}",
            "success_count": success_count,
            "failed_count": failed_count,
            "successful_devices": successful_devices,
            "failed_devices": failed_devices,
            "device_type": device_type
        }
            
    except Exception as e:
        logging.exception(f"Error in send_device_update_status: {e}")
        return {"flag": False, "message": f"Failed to update device status: {str(e)}"}

    


def _handle_pond_iot_carrier_rate_plan(carrier_api_url, app_id, app_secret, jasper_rate_plan_id, iccid):
    """Handle POND IoT rate plan update for single device with two-step process."""
    headers = {"Authorization": app_id, "ApiKey": app_secret, "Accept": "application/json"}
    
    # Step 1: Add package
    url = f"{carrier_api_url}/sim/{iccid}/addPackage"
    payload = {"packageTypeId": jasper_rate_plan_id}
    
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=60)
        if not (200 <= response.status_code < 300):
            return {"flag": False, "message": f"Failed to add package: {response.status_code}"}
        
        # Get package ID from response
        try:
            package_id = response.json().get("packageId")
        except ValueError:
            logging.warning(f"Response not JSON for ICCID={iccid}: {response.text}")
            return {"flag": False, "message": "Invalid response format"}
        
        if not package_id:
            return {"flag": False, "message": "Package ID not received"}
        
        # Step 2: Activate package
        activate_url = f"{carrier_api_url}/package/{package_id}/status"
        activate_payload = {"packageStatus": "ACTIVE"}
        
        activate_response = requests.post(activate_url, json=activate_payload, headers=headers, timeout=60)
        
        if 200 <= activate_response.status_code < 300:
            return {"flag": True}
        else:
            return {
                "flag": False,
                "message": f"Failed to activate package: {activate_response.status_code}"
            }
            
    except Exception as e:
        logging.exception(f"POND IoT API error: {e}")
        return {"flag": False, "message": "POND IoT API request failed"}
    
def _handle_pond_iot_update_status(carrier_api_url, headers, device_status, iccid):
    device_status_mapping = {
            "Active": "ENABLED",
            "Suspended": "DISABLED",
            "Terminated": "DISABLED"
        }

    # Get mapped value
    mapped_status = device_status_mapping.get(device_status)

    # Build payload with mapped value
    payload = {
        "simDataServiceStatus": mapped_status,
        "simVoiceServiceStatus": mapped_status,
        "simSmsServiceStatus": mapped_status
    }
    url = f"{carrier_api_url}/sim/{iccid}/status"
    return _make_api_request(url, headers, payload, method="POST")

def _handle_verizon_update_device_status(carrier_api_url, headers, update_status, iccid, changed_data, accountname):
    """Handle Verizon device status update for single device."""
    if update_status.lower()=="deactive":
            update_status="deactivate"
    update_status = update_status.strip().lower()
    if update_status in ("restore","suspend"):
        url = f"{carrier_api_url}/{update_status}"
        payload ={
            "devices": [
                {
                    "deviceIds": [
                        {"kind": "iccid", "id":iccid},
                    ]
                }
            ],
            "ReasonCode": update_status
        }
    elif update_status == "deactivate":
        url = f"{carrier_api_url}/{update_status}"
        reason_code = changed_data[0].get("reason_code", "FF")
        payload = {
            "devices": [
                {
                    "deviceIds": [
                        {
                            "kind": "iccid",
                            "id": iccid
                        }
                    ]
                }
            ],
            "accountName": accountname,
            "reasonCode": reason_code,
            "state": update_status
        }
    elif update_status == "active":
        update_status = "activate"
        url = f"{carrier_api_url}/{update_status}"
        imei = changed_data[0].get("imei")
        rateplancode = changed_data[0].get("rateplancode")
        telegence_additional_details = changed_data[0].get("telegence_additional_details",{})
        mdnzipcode = telegence_additional_details.get("ZipCode")
        first_name = telegence_additional_details.get("FirstName")
        last_name = telegence_additional_details.get("LastName")
        address_line = telegence_additional_details.get("StreetNo")
        city = telegence_additional_details.get("City")
        state = telegence_additional_details.get("State")
        zip_code = telegence_additional_details.get("ZipCode")
        country = telegence_additional_details.get("Country")
        payload={
            "devices": [
                    {
                    "deviceIds": [
                        {
                        "kind": "iccid",
                        "id": iccid
                        },
                        {
                        "kind": "imei",
                        "id": imei
                        }
                    ]
                    }
                ],
                "accountName": accountname,
                "servicePlan": rateplancode,
                "publicIpRestriction": "Restricted",
                "mdnZipCode": mdnzipcode,
                "primaryPlaceOfUse": {
                    "customerName": {
                    "firstName": first_name,
                    "lastName": last_name
                    },
                    "address": {
                    "addressLine1": address_line,
                    "city": city,
                    "state": state,
                    "zip": zip_code,
                    "country":country
                    }
                }
            }
    return _make_api_request(url, headers, payload, method="POST")


def _handle_webbing_carrier_rate_plan(carrier_api_url, product_id, iccid):
    """Handle webbing rate plan update for single device."""
    username=os.getenv("WEBBING_API_USERNAME","")
    password=os.getenv("WEBBING_API_PASSWORD","")
    wskey=os.getenv("WEBBING_WS_KEY","")
    headers = {"Content-Type": "text/xml; charset=utf-8"}
    payload = f"""<?xml version="1.0" encoding="utf-8"?>
                    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                        <soap:Header>
                            <Credentials xmlns="http://wws.iamwebbing.com/">
                                <Username>{username}</Username>
                                <Password>{password}</Password>
                                <WSKey>{wskey}</WSKey>
                            </Credentials>
                        </soap:Header>
                        <soap:Body>
                            <ChangeServiceDeviceProduct xmlns="http://wws.iamwebbing.com/">
                                <ChangeServiceDeviceProductRequest>
                                    <ServiceDeviceIdentifier>
                                        <ICCID>{iccid}</ICCID>
                                    </ServiceDeviceIdentifier>
                                    <ProductID>{product_id}</ProductID>
                                </ChangeServiceDeviceProductRequest>
                            </ChangeServiceDeviceProduct>
                        </soap:Body>
                    </soap:Envelope>"""  
    return _make_api_request(carrier_api_url, headers, payload, method="POST")

def _handle_webbing_update_status(carrier_api_url, app_id, iccid, device_status, tenant_database, ssid=None, eid=None):
    username=os.getenv("WEBBING_API_USERNAME","")
    password=os.getenv("WEBBING_API_PASSWORD","")
    wskey=os.getenv("WEBBING_WS_KEY","")
    if device_status == "Active":
        staging_df = tenant_database.get_data(
            "webbing_devices_staging",
            {"iccid":iccid},
            ["imei","service_device_id"]
        )
        if staging_df.empty:
            imei = None
            service_device_id = None
        else:
            imei = staging_df["imei"].to_list()[0]
            service_device_id = staging_df["service_device_id"].to_list()[0]
        logging.info(f"### Webbing details userame password wskey {username}, {password}, {wskey}")
        payload = f"""<?xml version="1.0" encoding="utf-8"?>
        <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                        xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                        xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
            <soap12:Header>
                <Credentials xmlns="http://wws.iamwebbing.com/">
                    <Username>{username}</Username>
                    <Password>{password}</Password>
                    <WSKey>{wskey}</WSKey>
                </Credentials>
            </soap12:Header>
            <soap12:Body>
                <ActivateServiceDevice xmlns="http://wws.iamwebbing.com/">
                    <ActivateServiceDeviceRequest>
                        <ServiceDeviceIdentifier>
                            {f"<ServiceDeviceID>{service_device_id}</ServiceDeviceID>" if service_device_id else ""}
                            {f"<IMEI>{imei}</IMEI>" if imei else ""}
                            {f"<SSID>{ssid}</SSID>" if ssid else ""}
                            <ICCID>{iccid}</ICCID>
                            {f"<EID>{eid}</EID>" if eid else ""}
                        </ServiceDeviceIdentifier>
                    </ActivateServiceDeviceRequest>
                </ActivateServiceDevice>
            </soap12:Body>
        </soap12:Envelope>"""
    else:
        payload = f"""<?xml version="1.0" encoding="utf-8"?>
        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
            <soap:Header>
                <Credentials xmlns="http://wws.iamwebbing.com/">
                    <Username>{username}</Username>
                    <Password>{password}</Password>
                    <WSKey>{wskey}</WSKey>
                </Credentials>
            </soap:Header>
            <soap:Body>
                <SuspendServiceDevice xmlns="http://wws.iamwebbing.com/">
                    <SuspendServiceDeviceRequest>
                        <ServiceDeviceIdentifier>
                            <ICCID>{iccid}</ICCID>
                        </ServiceDeviceIdentifier>
                    </SuspendServiceDeviceRequest>
                </SuspendServiceDevice>
            </soap:Body>
        </soap:Envelope>"""

    # Detect operation name
    if "<ActivateServiceDevice" in payload:
        operation = "ActivateServiceDevice"
    elif "<SuspendServiceDevice" in payload:
        operation = "SuspendServiceDevice"
    else:
        operation = None

    # SOAP 1.1 headers
    headers = {
        "Content-Type": "text/xml; charset=utf-8"
    }
    if operation:
        headers["SOAPAction"] = f"http://wws.iamwebbing.com/{operation}"

    try:
        resp = requests.post(carrier_api_url, data=payload.encode("utf-8"), headers=headers, timeout=60)
        resp.raise_for_status()

        root = ET.fromstring(resp.text)
        ns = {
            "soap": "http://schemas.xmlsoap.org/soap/envelope/",
            "ns": "http://wws.iamwebbing.com/"
        }
        success = root.find(".//ns:Success", ns)
        response_code = root.find(".//ns:ResponseCode", ns)
        response_description = root.find(".//ns:ResponseDescription", ns)

        flag = success is not None and success.text.strip().lower() == "true"
        return {
            "flag": flag,
            "operation": operation or "Unknown",
            "response_code": response_code.text if response_code is not None else None,
            "response_description": response_description.text if response_description is not None else None
        }

    except Exception as e:
        logging.exception(f"### Exception in post_webbing_api: {e}")
        return {"flag": False, "error": str(e)}
    





def _make_api_request(url, headers, payload, method="PUT"):
    """Make API request with proper error handling."""
    try:
        if method.upper() == "POST":
            response = requests.post(url, json=payload, headers=headers, timeout=60)
        elif method.upper() == "PATCH":
            response = requests.patch(url, json=payload, headers=headers, timeout=60)
        else:
            response = requests.put(url, json=payload, headers=headers, timeout=60)
        
        if 200 <= response.status_code < 300:
            return {"flag": True}
        else:
            return {
                "flag": False,
                "message": f"Failed with status code {response.status_code}: {response.text}"
            }
            
    except requests.exceptions.Timeout:
        return {"flag": False, "message": "Request timeout"}
    except requests.exceptions.RequestException as e:
        return {"flag": False, "message": f"Request failed: {str(e)}"}
    except Exception as e:
        logging.exception(f"API request error: {e}")
        return {"flag": False, "message": "API request failed"}
    

def get_access_token_(client_id, client_secret):
    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
    }
    token_url = "https://api.korewireless.com/Api/api/token"  #os.getenv("KORE_API")
    try:
        response = requests.post(token_url, data=payload)
        response.raise_for_status()
        token_data = response.json()
        access_token = token_data.get("access_token")
        if access_token:
            logging.info("Access Token Generated Successfully:")
            logging.info(f"Access Token: {access_token}")
            return access_token
        else:
            logging.info("Error: Access token not found in response.")
            logging.info(token_data)
            return None
    except requests.exceptions.RequestException as e:
        logging.info(f"Error fetching access token: {e}")
        return None

def fetch_individual_line_sync_request(iccids, msisdns, subscription_ids,service_provider, change_type, common_utils_database):
    """
    This function retrieves detailed information for individual lines (devices) from the carrier’s API.
    Depending on the carrier type, it decides whether to query using ICCID or MSISDN.
    It then sends requests to the appropriate carrier API and processes the responses in parallel 
    using a ThreadPoolExecutor, ensuring efficient execution

    Args:
        iccids (list): List of ICCIDs to fetch details for.
        msisdns (list): List of MSISDNs to fetch details for.

    Returns:
        dict: Summary response containing:
            - flag (bool): True if at least one device sync succeeded, False otherwise.
            - message (str): Human-readable status message.
            - success_count (int): Number of devices successfully processed.
            - failed_count (int): Number of devices that failed.
            - successful_devices (list[str]): List of successfully processed device IDs.
            - failed_devices (list[dict]): List of failed devices with `device_id` and `error`.
            - device_type (str): Identifier type used ("iccid" or "msisdn").
            - records_to_update (list[dict]): List of mapped records ready for DB update.
    """
    try:
        logging.info(f"### fetch_individual_line_sync_request called with ICCIDs: {iccids}, MSISDNs: {msisdns}, Service Provider: {service_provider}, Change Type: {change_type}")
        
        # Get carrier API configuration
        carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
            service_provider, change_type, common_utils_database
        )
        logging.info(f"### fetch_individual_line_sync_request carrier_api_url: {carrier_api_url}, app_id: {app_id}, app_secret: {app_secret}, carrier_limits: {carrier_limits}, alternative_api_url: {alternative_api_url}")

        # Parse carrier limits
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        
        if not carrier_api_url:
            return {"flag": False, "message": "Carrier API configuration not found"}
        
        # headers = _build_headers(service_provider, app_id, app_secret)
        
        # Define which providers use MSISDN vs ICCID
        msisdn_providers = ["AT&T - Telegence - UAT ONLY", "AT&T - Telegence"]
        iccid_providers = ["AT&T - Cisco Jasper", "AT&T - POD19", "T-Mobile Jasper", "POND IoT", "Rogers Sandbox", "Teal", "Verizon - ThingSpace PN", "Verizon - ThingSpace IoT","Webbing","Kore"]
        
        # Determine device list and type based on provider
        if service_provider in msisdn_providers:
            device_list = msisdns
            device_type = "msisdn"
        elif service_provider in iccid_providers:
            device_list = iccids
            device_type = "iccid"
        else:
            return {"flag": False, "message": f"Unsupported service provider: {service_provider}"}
        logging.info(f"### fetch_individual_line_sync_request device_type: {device_type}, device_list: {device_list}")
        
        if not device_list:
            return {"flag": False, "message": f"No {device_type.upper()}s provided for {service_provider}"}
        
        # Use carrier limits for parallel processing (default to 5 if not set)
        parallel_requests = carrier_limits.get("parallel_requests", 5)
        max_workers = min(int(parallel_requests) if parallel_requests else 5, len(device_list))
        
        # Process devices in parallel using ThreadPoolExecutor
        success_count = 0
        failed_count = 0
        failed_devices = []
        successful_devices = []
        records_to_update = []
        if service_provider in ("Verizon - ThingSpace PN","Verizon - ThingSpace IoT"):
            access_token,session_token=get_verizon_token_details(app_id,app_secret)
        if service_provider in ("Kore"):
            kore_access_token =get_access_token_(app_id,app_secret)    
        
        def process_single_device(device_id):
            try:
                # Route to appropriate provider handler
                if service_provider in ("AT&T - Telegence - UAT ONLY", "AT&T - Telegence"):
                    # in header include this "Content-Type": "application/json"
                    url = f"{carrier_api_url}/{device_id}" 
                    headers={
                                    "app-id": app_id,
                                    "app-secret": app_secret,
                                    "Content-Type": "application/json"
                                }
                    
                    resp = requests.get(url, 
                        headers=headers, timeout=60)
                    logging.info(f"### telegence_bc_line_sync and Response Code: {resp.status_code} for ICCID: {device_id}")
                    success = 200 <= resp.status_code < 300
                    result = resp.text

                    if success:
                        api_data = resp.json()

                        # Extract serviceCharacteristic into a dict {name: value}
                        characteristics = {
                            item.get("name"): item.get("value")
                            for item in api_data.get("serviceCharacteristic", [])
                        }
                        effective_date = characteristics.get("effectiveDate")
                        if not effective_date:  
                            effective_date = None

                        # Handle ICCID - if API returns null/empty, keep the original device_id (ICCID)
                        iccid_from_api = characteristics.get("sim")
                        if not iccid_from_api:  
                            iccid_from_api = device_id  # Use the original ICCID from the request    

                        # Map Telegence API → Inventory columns
                        to_update = {
                            "effective_date": effective_date,
                            "username": characteristics.get("contactName"),
                            "iccid": iccid_from_api,
                            "imei": characteristics.get("NWIMEI"),
                            "sim_status": api_data.get("status"),
                            "msisdn": api_data.get("subscriberNumber"),
                        }

                        if success :
                            return {"flag": True,"to_update": to_update}
                        else:
                            return {
                                "flag": False,
                                "message": f"Failed with status code {resp.status_code}: {resp.text}"
                            }
                elif service_provider in ("Kore"):
                    subscription_id = subscription_ids.get(f"{device_id}")
                    url = f"{carrier_api_url}/{subscription_id}"
                    bearer_token= kore_access_token
                    kore_api_key = "FwEO4B4Fqq28VPsaetYh59xZ75wsUpow98XCbUFC"  # os.getenv("KORE_X_API_KEY") 
                    headers = {
                        "Authorization": f"Bearer {bearer_token}",  
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "x-api-key":kore_api_key
                    }

                    resp = requests.get(url, headers=headers)
                    logging.info(f"### service_provider : {service_provider} and Response Code: {resp.status_code} for ICCID: {device_id}")
                    success = 200 <= resp.status_code < 300

                    if success:
                        api_data = resp.json()
                        # Ensure ICCID is always present
                        if not api_data.get("iccid"):
                            api_data["iccid"] = device_id
                        sim_status = api_data["states"][0].get("state")    

                        to_update = {
                            "subscription_id": api_data.get("subscription-id"),   
                            "iccid": api_data.get("iccid"),                   
                            "imei": api_data.get("imei", ""),          
                            "sim_status": sim_status,                      
                        }

                        # Only add msisdn if it exists and is not None/empty
                        msisdn = api_data.get("last-active-imsi-msisdn", [{}])[0].get("msisdn")
                        if msisdn:
                            to_update["msisdn"] = msisdn

                        return {"flag": True, "to_update": to_update}
                    else:
                        return {
                            "flag": False,
                            "message": f"Failed with status code {resp.status_code}: {resp.text}",
                        }            
                                
                elif service_provider in ("AT&T - Cisco Jasper" ,"AT&T - POD19" ,"Rogers Sandbox"):
                    url = f"{carrier_api_url}/{device_id}"
                    headers={
                                    "Authorization": app_id,
                                    "Content-Type": "application/json"
                                }
                    
                    resp = requests.get(url, 
                        headers=headers, timeout=60)
                    logging.info(f"### service_provider : {service_provider} and Response Code: {resp.status_code} for ICCID: {device_id}")
                    success = 200 <= resp.status_code < 300
                    result = resp.text
        
                    if success:
                        api_data = resp.json()
                        if not api_data.get("iccid") :
                            api_data["iccid"] = device_id

                        to_update = {
                            "iccid": api_data.get("iccid"),
                            "imsi": api_data.get("imsi"),
                            "msisdn": api_data.get("msisdn"),
                            "imei": api_data.get("imei", ""),   # resp has `imei`
                            "sim_status": api_data.get("status"),
                            "carrier_rate_plan_name": api_data.get("ratePlan"),
                            "communication_plan": api_data.get("communicationPlan"),
                            "customer_name": api_data.get("customer"),
                            "date_activated": api_data.get("dateActivated"),
                            "account_number": api_data.get("accountId"),
                        }
                        
                        if success :
                            return {"flag": True ,"to_update": to_update }
                        else:
                            return {
                                "flag": False,
                                "message": f"Failed with status code {resp.status_code}: {resp.text}"
                            }
                    
                
                elif service_provider == "Webbing":
                    username=os.getenv("WEBBING_API_USERNAME","")
                    password=os.getenv("WEBBING_API_PASSWORD","")
                    wskey=os.getenv("WEBBING_WS_KEY","")
                    url = f"{carrier_api_url}"    
                    headers= {
                        "Content-Type": "text/xml; charset=utf-8",
                        "SOAPAction": "http://wws.iamwebbing.com/GetServiceDevices"
                        }
                    payload = f"""<?xml version="1.0" encoding="utf-8"?>
                                            <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                                                        xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                                                        xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                                            <soap:Header>
                                                <Credentials xmlns="http://wws.iamwebbing.com/">
                                                <Username>{username}</Username>
                                                <Password>{password}</Password>
                                                <WSKey>{wskey}</WSKey>
                                                </Credentials>
                                            </soap:Header>
                                            <soap:Body>
                                                <GetServiceDevices xmlns="http://wws.iamwebbing.com/">
                                                <GetServiceDevicesRequest>
                                                    <DeviceIdentifier>
                                                    <ICCID>{device_id}</ICCID>
                                                    </DeviceIdentifier>
                                                    <OnlyActivePlansDevices>true</OnlyActivePlansDevices>
                                                    <PaginationRequest>
                                                    <PageSize>10</PageSize>
                                                    <PageNumber>1</PageNumber>
                                                    </PaginationRequest>
                                                </GetServiceDevicesRequest>
                                                </GetServiceDevices>
                                            </soap:Body>
                                            </soap:Envelope>""" 
                    resp = requests.post(url, headers=headers, data=payload,timeout=60)
                    logging.info(f"### webbing_bc_line_sync and Response Code: {resp.status_code} for ICCID: {device_id}")
                    success = 200 <= resp.status_code < 300
                    result = resp.text
                    # Update inventory if successful
                    if success:


                        try:
                            root = ET.fromstring(resp.text)
                            # Navigate to the XML path for the ServiceDeviceRecord
                            ns = {"soap": "http://schemas.xmlsoap.org/soap/envelope/",
                                "ns": "http://wws.iamwebbing.com/"}  # namespaces

                            record = root.find(".//ns:ServiceDeviceRecord", ns)

                            if record is not None:
                                api_data = {
                                    "ICCID": record.findtext("ns:ICCID", default="", namespaces=ns),
                                    "MSISDN": record.findtext("ns:MSISDN", default="", namespaces=ns),
                                    "StatusName": record.findtext("ns:StatusName", default="", namespaces=ns),
                                    "AccountID": record.findtext("ns:AccountID", default="", namespaces=ns),
                                }
                            else:
                                logging.warning(f"### No ServiceDeviceRecord found for ICCID: {device_id}")
                                api_data = {}
                        except Exception as e:
                            logging.error(f"### Failed to parse XML for ICCID {device_id}: {e}")
                            api_data = {}


                        to_update = {
                            "iccid": api_data.get("ICCID"),
                            "msisdn": api_data.get("MSISDN"),
                            "sim_status": api_data.get("StatusName"),
                        }
                           
                        if success :
                            return {"flag": True,"to_update": to_update }
                        else:
                            return {
                                "flag": False,
                                "message": f"Failed with status code {resp.status_code}: {resp.text}"
                            }
                elif service_provider in ("Verizon - ThingSpace PN","Verizon - ThingSpace IoT"):

                    url = f"{carrier_api_url}"      
                    headers = {
                    "Authorization": f"Bearer {access_token}",
                    "VZ-M2M-Token": session_token,
                    "Content-Type": "application/json",
                }
                    payload = {
                            "deviceId": {
                                "id": device_id,   # Example ICCID
                                "kind": "iccid"
                            }
                        }
                    resp = requests.post(url, json=payload,headers=headers, timeout=60)
                    logging.info(f"### verizon_bc_line_sync and  Response Code: {resp.status_code} for ICCID: {device_id}")
                    success = 200 <= resp.status_code < 300
                    result = resp.text

                    # Update inventory if successful
                    if success:
                        api_data = resp.json()
                        
                        # Extract required fields from API response
                        if api_data.get("devices") :
                            device = api_data.get("devices", [])[0]
                        else :
                            logging.info(f"### Verizon response has no devices for ICCID: {device_id} -> Already up to date, no DB update needed")
                            # Return success but no to_update
                            return {"flag": True, "to_update": {}}

                        billing_cycle_end_date = device.get("billingCycleEndDate")
                        sim_status = None
                        imei = None

                        # Extract sim_status from carrierInformations
                        carrier_info = device.get("carrierInformations", [])
                        if carrier_info:
                            sim_status = carrier_info[0].get("state")

                        # Extract imei & iccid from deviceIds
                        for dev_id in device.get("deviceIds", []):
                            if dev_id.get("kind") == "imei":
                                imei = dev_id.get("id")
                            elif dev_id.get("kind") == "iccId":
                                iccid_val = dev_id.get("id")

                        # Prepare update values
                        to_update = {
                            "billing_cycle_end_date": billing_cycle_end_date,
                            "sim_status": sim_status,
                            "imei": imei,
                            "iccid": iccid_val,
                        }
                        if success :
                            return {"flag": True ,"to_update": to_update }
                        else:
                            return {
                                "flag": False,
                                "message": f"Failed with status code {resp.status_code}: {resp.text}"
                            }  
                           
            except Exception as e:
                logging.exception(f"Error processing {device_type} {device_id}: {e}")
                return {"flag": False, "message": "Failed to update carrier rate plan"}
        
        # Execute parallel processing
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            future_to_device = {executor.submit(process_single_device, device_id): device_id 
                              for device_id in device_list}
            
            # Collect results
            for future in as_completed(future_to_device):
                device_id = future_to_device[future]
                try:
                    result = future.result()
                    if result["flag"]:
                        to_update = result.get("to_update", {})
                        success_count += 1   
                        successful_devices.append(device_id)
                        if to_update:
                            records_to_update.append(to_update)
                    else:
                        logging.error(f"### fetch_individual_line_sync_request Failed to update {device_type} {device_id}: {result}")
                        failed_count += 1
                        failed_devices.append({"device_id": device_id, "error": result.get("message", "Unknown error")})
                except Exception as e:
                    failed_count += 1
                    failed_devices.append({"device_id": device_id, "error": str(e)})
                    logging.exception(f"### fetch_individual_line_sync_request Future exception for {device_type} {device_id}: {e}")
        
        # Return summary
        total_processed = success_count + failed_count
        overall_success = success_count > 0
        logging.info(f"### fetch_individual_line_sync_request total_processed: {total_processed}, success_count: {success_count}, failed_count: {failed_count}, records_to_update: {records_to_update}")
        
        return {
            "flag": overall_success,
            "message": f"Processed {total_processed} devices. Success: {success_count}, Failed: {failed_count}",
            "success_count": success_count,
            "failed_count": failed_count,
            "successful_devices": successful_devices,
            "failed_devices": failed_devices,
            "device_type": device_type,
            "records_to_update": records_to_update
        }
            
    except Exception as e:
        logging.exception(f"Error in fetch_individual_line_sync_request: {e}")
        return {"flag": False, "message": "Failed to fecth individual line sync details"}    



    
