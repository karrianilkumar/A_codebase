"""
@Author1 : Ajay Reddi
@Author2 :
@Author3 :
Created Date: 05-09-2025
"""

"""
Common utility functions for inventory management.
Contains shared helper functions used across multiple modules.
"""

import os
import json
import base64
from datetime import datetime
from common_utils.logging_utils import Logging
from common_utils.db_utils import DB
import requests

db_config_withoutfilter = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema": False,
}

logging = Logging(name="inventory_utils")

def load_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_serviceproviders.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"### load_json Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### load_json Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### load_json Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs

def get_provider_ids(json_data, tenant_name, provider_names):
    """Fetches only the IDs of specified providers for a given tenant."""
    return [
        details["id"]
        for provider_name, details in json_data.get(tenant_name, {}).items()
        if provider_name in provider_names
    ]


def get_integration_id_by_unique_name(json_data, tenant_name, unique_name):
    """Fetches 'main_name' of a provider based on its unique name."""
    return json_data.get(tenant_name, {}).get(unique_name, {}).get("integration_id", None)

def base64_decode(base64_encoded_data):
    """
    Decodes a Base64-encoded string to plain text.

    Args:
        base64_encoded_data (str): The Base64 string to decode.

    Returns:
        str: Decoded plain text string.
    """
    # Decode the Base64 string to bytes
    base64_encoded_bytes = base64.b64decode(base64_encoded_data)
    # Convert the bytes back to a UTF-8 string
    decoded_string = base64_encoded_bytes.decode("utf-8")
    return decoded_string

def base64_encode(plain_text):
    """
    Encodes a plain text string into Base64.

    Args:
        plain_text (str): The string to encode.

    Returns:
        str: Base64-encoded string.
    """
    # Convert the plain text to bytes, then encode it in Base64
    plain_text_bytes = plain_text.encode("utf-8")
    base64_encoded = base64.b64encode(plain_text_bytes).decode("utf-8")
    return base64_encoded


def get_verizon_token_details(app_id,app_secret):
    """
    Obtain an OAuth access token and session token from Verizon  API.

    Args:
        app_id (str): The client ID (application ID) for Verizon API.
        app_secret (str): The client secret associated with the app_id.

    Returns:
        tuple[str, str]: A tuple containing the access token and the session token.

    Raises:
        requests.exceptions.HTTPError: If any of the HTTP requests fail.
        Exception: For unexpected decoding or response format issues.
    """
    main_url = "https://thingspace.verizon.com"
    client_id = app_id
    client_secret = app_secret
    username = "ldaniel80"
    password_encoded = "OG81a1dnOFhNMDh6SkN0biQq"

    # Decode password from base64
    password = base64.b64decode(password_encoded).decode('utf-8')

    token_url = f"{main_url}/api/ts/v1/oauth2/token"
    session_url = f"{main_url}/api/m2m/v1/session/login"

    # Prepare Basic Auth header
    auth_header = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()

    # Get OAuth access token
    token_response = requests.post(
        token_url,
        headers={
            "Authorization": f"Basic {auth_header}",
            "Accept": "application/json",
        },
        data={"grant_type": "client_credentials"},
    )
    token_response.raise_for_status()
    access_token_id = token_response.json().get("access_token")
    logging.info(f"### get_verizon_token_details Access token: {access_token_id}")

    # Get session token
    session_response = requests.post(
        session_url,
        headers={
            "Authorization": f"Bearer {access_token_id}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        },
        json={"username": username, "password": password},
    )
    session_response.raise_for_status()
    session_token = session_response.json().get("sessionToken")
    logging.info(f"## get_verizon_token_details Session token: {session_token}")
    return access_token_id,session_token