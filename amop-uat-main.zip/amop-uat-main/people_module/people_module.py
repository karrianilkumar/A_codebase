"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil .N
Created Date: 21-06-24
"""

# Importing the necessary Libraries
import requests
import os
import pandas as pd
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.permission_manager import PermissionManager
from common_utils.timezone_conversion import fetch_tenant_timezone , convert_timestamp_data , serialize_data
from datetime import datetime ,time
from io import BytesIO
import json
import base64


logging = Logging(name="module_api")

db_config_withoutfilter = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema":False
    }


def db_config_maker(user,db_config_making):
    """
    Creates and returns an updated database configuration by adding customer 
    and service provider details for the given user.

    This function:
    - Connects to the COMMON_UTILS_DATABASE
    - Fetches the customers and service providers assigned to the user
    - Updates the db_config_making dictionary with these details

    Args:
        user (str): The username for which to fetch customer and service provider data.
        db_config_making (dict): Basic DB connection config (host, port, user, password)

    Returns:
        dict: Updated db_config with 'customers' and 'service_providers' keys added.
    """

    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config_making)

    query=f"select customers,service_provider from users where username ='{user}'"
    filters=common_utils_database.execute_query(query,True)
    try:
        customer=tuple(json.loads(filters['customers'].to_list()[0]))

    except Exception as e:
      logging.error(f"Exception occurred while getting customer: {str(e)}")
      customer= None     

    try:
        service_provider=tuple(json.loads(filters['service_provider'].to_list()[0]))

    except Exception as e:
      logging.error(f"Exception occurred while getting service_provider: {str(e)}")
      service_provider=None   

    db_config_making["customers"]= customer
    db_config_making["service_providers"]=service_provider

    return db_config_making

def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes people module-related requests.

    This function:
    1. Initializes database configuration from environment variables
    2. Determines the user and tenant-specific configuration
    3. Routes the request to the appropriate people module handler function based on the path

    Args:
        data (dict): Request data containing user/tenant information (e.g., username, db_name)
        path (str): API endpoint path being invoked

    Returns:
        dict: Result of the invoked handler function or an error message for an invalid path
    """
    # Access global db_config variable
    global db_config

    # Initialize base database configuration from environment variables
    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

    # Extract username from data (fallback handling)
    user = data.get("username") or data.get("user_name")

    # Build tenant-specific DB config
    db_config = db_config_maker(user, db_config)
    logging.info(f"### db_config created is : {db_config}")

    # Map API paths to corresponding handler functions
    path_function_map = {
        "/export": export,
        "/people_revio_customers_list_view": people_revio_customers_list_view,
        "/download_people_bulk_upload_template": download_people_bulk_upload_template,
        "/add_people_revcustomer_dropdown_data": add_people_revcustomer_dropdown_data,
        "/people_bulk_import_data": people_bulk_import_data,
        "/submit_update_info_people_revcustomer": submit_update_info_people_revcustomer,
        "/people_list_view": people_list_view,
        "/update_people_data": update_people_data,
        "/get_customers_list_view_data": get_customers_list_view_data,
        "/create_customer": create_customer,
        "/create_billing_platform_customer": create_billing_platform_customer,
        "/get_billing_platform_customer_list_view_data": get_billing_platform_customer_list_view_data,
    }

    # Route to the correct function based on the path
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result


def get_headers_mapping(
    tenant_database,
    module_list,
    role,
    user,
    tenant_id,
    sub_parent_module,
    parent_module,
    data,
    common_utils_database,
):
    """
    Description:
        This function fetches and organizes the field mappings and features for a list of modules 
        based on user role, tenant, and other context data. It separates fields into general fields, 
        popup fields, and table headers, and includes feature permissions per module.

    Args:
        tenant_database (str): Name of the tenant-specific database.
        module_list (list): List of module names to fetch headers and features for.
        tenant_id (int): Tenant ID (may be overwritten by data fetched inside the function).
        sub_parent_module (str): Name of the sub-parent module (not used inside currently).
        data (dict): Request-related data containing keys like 'username', 'tenant_name', etc.
        common_utils_database (DB): DB connection object to the common_utils database.

    Returns:
        dict: A dictionary where each key is a module name, and the value is a dictionary containing:
            - general_fields: List of fields not categorized as pop-up or table fields
            - pop_up: List of fields marked as pop-up fields
            - header_map: Dictionary of table fields with display name and order
            - module_features: List of feature permissions for the module and user role
    """
    ##Database connection
    ret_out = {}
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
        logging.info(f"### Module name is :{module_list} and role is :{role}")
        # common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        feature_module_name = data.get("feature_module_name", "")
        user_name = data.get("username") or data.get("user_name") or data.get("user")
        tenant_name = data.get("tenant_name") or data.get("tenant")
        parent_module_name = data.get("parent_module_name") or data.get("parent_module")
        if parent_module_name == "Sim Management":
            parent_module_name = "Sim Management"
        try:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            logging.debug(f"### tenant_id  is :{tenant_id}")
        except Exception as e:
            logging.exception(f"### Getting exception at fetching tenant id : {e}")
        # Iterate over each module name in the provided module list
        for module_name in module_list:
            out = common_utils_database.get_data(
                "field_column_mapping", {"module_name": module_name}
            ).to_dict(orient="records")
            pop_up = []
            general_fields = []
            table_fileds = {}
            # Categorize the fetched data based on field types
            for data in out:
                if data["pop_col"]:
                    pop_up.append(data)
                elif data["table_col"]:
                    table_fileds.update(
                        {
                            data["db_column_name"]: [
                                data["display_name"],
                                data["table_header_order"],
                            ]
                        }
                    )
                else:
                    general_fields.append(data)
            # Create a dictionary to store categorized fields
            headers = {}
            headers["general_fields"] = general_fields
            headers["pop_up"] = pop_up
            headers["header_map"] = table_fileds
            logging.info("### Got the header map here")
            try:
                final_features = []

                # Fetch all features for the 'super admin' role
                if role.lower() == "super admin":
                    all_features = common_utils_database.get_data(
                        "module_features",
                        {
                            "module": feature_module_name,
                            "parent_module_name": parent_module_name,
                        },
                        ["features"],
                    )["features"].to_list()
                    if all_features:
                        final_features = json.loads(all_features[0])
                else:
                    final_features = get_features_by_feature_name(
                        user_name,
                        tenant_id,
                        feature_module_name,
                        common_utils_database,
                        role,
                        parent_module_name
                    )

            except Exception as e:
                logging.warning(f"### there is some error: {e}")
                pass
            # Add the final features to the headers dictionary
            headers["module_features"] = final_features
            ret_out[module_name] = headers
    except Exception as e:
        logging.warning(f"### there is some error : {e}")

    return ret_out




def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database,role,parent_module
):
    """
    Description:
        This function retrieves a list of features associated with a specific
        feature name for a user within a tenant.
        It fetches user-module-tenant mapping data, processes the features,
        and extracts relevant features
        linked to the specified feature name.

    Parameters:
    ----------
    user_name : str
        The name or identifier of the user for whom the features are being fetched.
    tenant_id : str
        The tenant ID associated with the user.
    feature_name : str
        The specific feature name for which features need to be extracted.
    common_utils_database : object
        Utility database object to query data from the required tables.

    Returns:
    -------
    list
        A list of features associated with the specified feature name for the user.
    """
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    # Fetch user features from the database based on user name and tenant ID
    user_features_raw = common_utils_database.get_data(
        "user_module_tenant_mapping",
        {"user_name": user_name, "tenant_id": tenant_id},
        ["module_features"],
    )["module_features"].to_list()
    logging.debug(f"### Raw user features fetched: {user_features_raw}")
    if not user_features_raw or user_features_raw[0] is None:
        query=f'''select module_features from role_module where role='{role}'
        '''
        user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
    # Parse the JSON string to a dictionary
    try:
        features = json.loads(
            user_features_raw[0]
        )  # Assuming it's a list with one JSON string

    except Exception as e:
      logging.error(f"Exception occurred while getting features: {str(e)}")
      features={}        


    if not features:
        features = common_utils_database.get_data(
            "role_module",
            {"role": role},
            ["module_features"],
        )["module_features"].to_list()
        features = json.loads(
            features[0]
        )


    # Initialize a list to hold features for the specified feature name
    features_list = []

    # Loop through all modules to find the specified feature name and collect its features
    for par_module, modules in features.items():
        if parent_module == par_module:
            for module,features_l in modules.items():
                if module == feature_name:
                    features_list = features_l

    # Log the retrieved features for debugging purposes
    logging.info(f"### Retrieved features: {features_list}")


    # Return the list of features associated with the specified feature name
    return features_list



def form_modules_dict(data, sub_modules, tenant_modules, role_name):
    """
    Constructs a dictionary that organizes modules and submodules based on user role and tenant permissions.

    Args:
        data (list): List of dictionaries containing module info. Each item should have keys:
                     'parent_module_name', 'module_name', and 'submodule_name'.
        sub_modules (list): List of submodules the user is allowed to access.
        tenant_modules (list): List of modules assigned to the tenant.
        role_name (str): Role of the user (e.g., 'super admin', 'user', etc.).

    Returns:
        dict: A nested dictionary of the form:
              {
                "ParentModule1": {
                    "SubModule1": ["ChildModule1", "ChildModule2"],
                    "SubModule2": ["ChildModule3"]
                },
                "ModuleWithoutParent": {}
              }
    """
    logging.info("### Starting to form modules dictionary.")
    # Initialize an empty dictionary to store the output
    out = {}
    # Iterate through the list of modules in the data
    for item in data:
        parent_module = item["parent_module_name"]
        logging.debug(f"### Processing parent module: {parent_module}")
        # Skip modules not assigned to the tenant unless the role is 'super admin'
        if (
            parent_module not in tenant_modules and parent_module
        ) and role_name.lower() != "super admin":
            continue
        # If there's no parent module, initialize an empty dictionary for the module
        if not parent_module:
            out[item["module_name"]] = {}
            continue
        else:
            out[item["parent_module_name"]] = {}
        # Iterate through the data again to find related modules and submodules
        for module in data:
            temp = {}
            # Skip modules not in the specified submodules unless the role is 'super admin'
            if (
                module["module_name"] not in sub_modules
                and module["submodule_name"] not in sub_modules
            ) and role_name.lower() != "super admin":
                logging.debug(f"### Skipping parent module: {parent_module} (not in tenant modules)")

                continue
            # Handle modules without submodules and create a list for them
            if (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and not module["submodule_name"]
            ):
                temp = {module["module_name"]: []}
            # Handle modules with submodules and map them accordingly
            elif (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and module["submodule_name"]
            ):
                temp = {module["submodule_name"]: [module["module_name"]]}
            # Update the output dictionary with the constructed module mapping
            if temp:
                for key, value in temp.items():
                    if key in out[item["parent_module_name"]]:
                        out[item["parent_module_name"]][key].append(value[0])
                    elif temp:
                        out[item["parent_module_name"]].update(temp)

    # Return the final dictionary containing the module mappings
    logging.info(f"### Finished forming modules dictionary: {out}")
    return out


def transform_structure(input_data):
    """
    Transforms a nested dictionary of modules into a structured list format with queue order.

    This function:
    - Iterates through parent modules, their child modules, and sub-children
    - Builds a list of dictionaries that preserve hierarchy and order
    - Adds a 'queue_order' key at each level to maintain display/order sequence

    Args:
        input_data (dict): A nested dictionary in the format:
            {
                "ParentModule1": {
                    "ChildModule1": ["SubChild1", "SubChild2"],
                    "ChildModule2": ["SubChild3"]
                },
                ...
            }

    Returns:
        list: A structured list of dictionaries with the following format:
            [
                {
                    "parent_module_name": str,
                    "queue_order": int,
                    "children": [
                        {
                            "child_module_name": str,
                            "queue_order": int,
                            "sub_children": [
                                {
                                    "sub_child_module_name": str,
                                    "queue_order": int,
                                    "sub_children": []
                                },
                                ...
                            ]
                        },
                        ...
                    ]
                },
                ...
            ]
    """
    logging.info("### Starting transformation of input data.")

    # Initialize an empty list to store the transformed data
    transformed_data = []
    # Initialize the queue order for parent modules
    queue_order = 1
    # Iterate over each parent module and its children in the input data
    for parent_module, children in input_data.items():
        transformed_children = []
        child_queue_order = 1
        # Iterate over each child module and its sub-children
        for child_module, sub_children in children.items():
            transformed_sub_children = []
            sub_child_queue_order = 1
            # Iterate over each sub-child module
            for sub_child in sub_children:
                transformed_sub_children.append(
                    {
                        "sub_child_module_name": sub_child,
                        "queue_order": sub_child_queue_order,
                        "sub_children": [],
                    }
                )
                sub_child_queue_order += 1
            # Append the transformed child module with its sub-children
            transformed_children.append(
                {
                    "child_module_name": child_module,
                    "queue_order": child_queue_order,
                    "sub_children": transformed_sub_children,
                }
            )
            child_queue_order += 1
        # Append the transformed parent module with its children
        transformed_data.append(
            {
                "parent_module_name": parent_module,
                "queue_order": queue_order,
                "children": transformed_children,
            }
        )
        queue_order += 1
    # Return the list of transformed data
    return transformed_data


def get_people_data(data_list, module_name, tenant_id, database):

    """
    Fetches and updates customer-related data based on the specified module name.

    This function supports different customer modules such as:
    - Bandwidth Customers
    - E911 Customers
    - NetSapiens Customers

    Based on the module:
    - It fetches related customer details from respective tables.
    - Merges the new data into the input `data_list`.
    - Returns updated data and the count of fetched records.

    Args:
        data_list (dict): A dictionary containing customer-related data.
        module_name (str): Name of the module to fetch data for 
                           (e.g., 'Bandwidth Customers', 'E911 Customers', 'NetSapiens Customers').
        tenant_id (int): Tenant ID used for filtering or reference.
        database (DB): Database connection object to execute queries.

    Returns:
        tuple: 
            - data_list (dict): Updated data dictionary with fetched customer info.
            - total (int): Total number of records fetched from the database.
    """
    # database = DB('altaworx_central', **db_config)
    logging.info(f"### Fetching data for module: {module_name}")

    if module_name == "Bandwidth Customers":
        band_id = []

        for data_item in data_list["customers"]:
            if data_item["bandwidth_customer_id"]:
                band_id.append(data_item["bandwidth_customer_id"])
        logging.info(f"### Bandwidth Customer IDs collected: {band_id}")


        if band_id:
            band_id_int = tuple(int(float(i)) for i in band_id)
            logging.info(f"### Executing query to fetch bandwidth customers with IDs: {band_id_int}")

            query = f"""
            SELECT bws.id AS bandwidth_unique_col,
                   bws.bandwidth_account_id,
                   bws.bandwidth_customer_name,
                   c.bandwidth_customer_id
            FROM customers AS c
            JOIN bandwidth_customers AS bws
              ON bws.id = CAST(CAST(c.bandwidth_customer_id AS FLOAT) AS INTEGER)
            WHERE bws.id IN {band_id_int}
            ORDER BY c.modified_date DESC;
            """
            df = database.execute_query(query, True)
            total = len(df)
            logging.info(f"### Number of bandwidth customers fetched : {total}")
            bandwidth_account_id = df["bandwidth_account_id"].to_list()[0]
            logging.info(f"### Fetched bandwidth account ID: {bandwidth_account_id}")
            data_out = df.to_dict(orient="records")

            global_account_number_df = database.get_data(
                "bandwidthaccount",
                {"id": bandwidth_account_id},
                ["id", "global_account_number"],
            )
            global_account_number = global_account_number_df[
                "global_account_number"
            ].to_list()[0]
            bandwidthaccount_unique_col = global_account_number_df["id"].to_list()[0]
            logging.info(f"### Global account number: {global_account_number}, Bandwidth account unique col: {bandwidthaccount_unique_col}")
            merged_list = []
            dict2 = {d["bandwidth_customer_id"]: d for d in data_list["customers"]}
            for dic_data_out in data_out:
                # Find the corresponding dictionary in dict2
                dic_data_list = dict2.get(dic_data_out["bandwidth_customer_id"], {})
                # Merge dictionaries
                merged_dict = {**dic_data_list, **dic_data_out}
                merged_dict.update({"global_account_number": global_account_number})
                merged_dict.update(
                    {"bandwidthaccount_unique_col": bandwidthaccount_unique_col}
                )
                merged_list.append(merged_dict)

            data_list["customers"] = merged_list
            logging.info("### Successfully merged bandwidth customer data.")

        return data_list, total
    elif module_name == "E911 Customers":
        e911_customer_ids = tuple(int(float(i)) for i in data_list["e911_customer_id"])
        # e911_customer_ids=tuple(data_list['e911_customer_id'])
        if e911_customer_ids:
            df = database.get_data(
                "e911customers",
                {"id": e911_customer_ids},
                order={"modified_date": "desc"},
            )
            total = len(df)
            data_list["e911_customers"] = df.to_dict(orient="records")
            data_list.pop("e911_customer_id")
        return data_list, total

    elif module_name == "NetSapiens Customers":
        reseller_ids = database.get_data(
            "customers", {"netsapiens_customer_id": "not Null"}, ["id"]
        )["id"].to_list()
        total = len(reseller_ids)
        for data_item in data_list["customers"]:
            if data_item["id"] in reseller_ids:
                data_item["netsapiens_type"] = "Reseller"
            else:
                data_item["netsapiens_type"] = "Domain"

        return data_list, total


def update_people_data(data):
    """
    Updates module data (create, update, delete) for a specified module based on user action.

    This function:
    - Validates user permission using `PermissionManager`
    - Fetches module metadata (table names, column mappings)
    - Prepares the data for update/create/delete actions
    - Performs database operations on tenant-specific tables
    - Handles custom logic for modules like "Bandwidth Customers" and "NetSapiens Customers"

    Args:
        data (dict): A dictionary containing all necessary request information, including:
            - "session_id" (str): Session identifier
            - "action" (str): One of "create", "update", or "delete"
            - "changed_data" (dict): Actual data fields to be updated
            - "module" (str): Module name to be modified
            - "db_name" (str): Database name of the tenant

    Returns:
        dict: A response dictionary with:
            - "flag" (bool): Status of the operation
            - "message" (str): Success or failure message
    """
    logging.info(f"### update_people_data function called with data: {data}")
    # Start time  and date calculation
    start_time = time.time()
    Partner = data.get("Partner", "")
    ##Restriction Check for the Amop API's
    try:
        # Create an instance of the PermissionManager class
        permission_manager_instance = PermissionManager(db_config)
        logging.info("### Checking user permissions.")

        # Call the permission_manager method with the data dictionary and validation=True
        result = permission_manager_instance.permission_manager(data, validation=True)

        # Check the result and handle accordingly
        if isinstance(result, dict) and result.get("flag") is False:
            logging.warning(f"### User does not have permission: {result}")
            return result
        else:
            # Continue with other logic if needed
            pass
    except Exception as e:
        logging.warning(f"### got exception in the restriction : {e}")

    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    user_name = data.get("user_name", "")
    action = data.get("action", "")
    ui_changed_data = data.get("changed_data", {})
    module_name = data.get("module", {})
    ##Database connection
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        logging.info(f"### Fetching column mappings for module:{module_name}")
        df = dbs.get_data(
            "module_column_mappings",
            {"module_name": module_name},
            ["main_update_table", "sub_table_mapping", "unique_columns"],
        )
        main_update_table = df["main_update_table"].to_list()[0]
        try:
            sun_table_map = json.loads(df["sub_table_mapping"].to_list()[0])

        except Exception as e:
            logging.error(f"Exception occurred while getting sun_table_map: {str(e)}")
            sun_table_map = {}
        try:
            unique_column = json.loads(df["unique_columns"].to_list()[0])

        except Exception as e:
            logging.error(f"Exception occurred while getting unique_column: {str(e)}")
            unique_column = df["unique_columns"].to_list()    

        changed_data = {}
        for key, value in ui_changed_data.items():
            if value and value is not None and value != "None":
                changed_data[key] = value
            else:
                changed_data[key] = None

        update_dics = {}
        for table, cols in sun_table_map.items():
            if table not in update_dics:
                update_dics[table] = {}
            for col in cols:
                if col in changed_data and changed_data[col]:
                    update_dics[table][col] = changed_data[col]
                if col in changed_data:
                    changed_data.pop(col)
        if action == "delete":
            filtered_changed_data = {
                key: value for key, value in changed_data.items() if value is not None
            }
            logging.debug(f"### Updating record in main table: {main_update_table}")
            unique_column_val = filtered_changed_data.pop(
                unique_column[main_update_table]
            )
            logging.debug(f"### Unique column value for update: {unique_column_val}")
            logging.debug(f"### Main update table being used: {main_update_table}")


            database.update_dict(
                main_update_table, filtered_changed_data, {"id": changed_data["id"]}
            )
            logging.debug(f"### Record updated successfully in table: {main_update_table}")
            # database.execute(delete_query_sub_table)
        elif action == "update":
            filtered_changed_data = {
                key: value for key, value in changed_data.items() if value is not None
            }
            logging.debug(f"### Updating record in main table: {main_update_table}")
            unique_column_val = filtered_changed_data.pop(
                unique_column[main_update_table]
            )
            logging.debug(f"### Unique column value for update: {unique_column_val}")

            database.update_dict(
                main_update_table, filtered_changed_data, {"id": changed_data["id"]}
            )
            logging.debug(f"### Record updated successfully in table: {main_update_table}")

        elif action == "create":
            logging.info(f"### Creating new record in main table: {main_update_table}")
            tenant_id = changed_data.get("tenant_id", None)
            created_date = changed_data.get("created_date", None)
            if not created_date:
                changed_data["created_date"] = request_received_at
            if not tenant_id:
                tenant_name = changed_data.get("tenant_name", "")
                tenant_details = dbs.get_data(
                    "tenant", {"tenant_name": tenant_name}, ["id"]
                )
                logging.info(f"### Fetching tenant details for tenant_name: {tenant_name} - {tenant_details}")
                if not tenant_details.empty:
                    tenant_id  = tenant_details["id"].iloc[0]
                    changed_data["tenant_id"] = int(tenant_id)

            # Check if module is "Bandwidth Customers" and fetch bandwidth_account_id
            if module_name == "Bandwidth Customers":
                # Fetch the id from bandwidth_customers where bandwidth_customer_name matches Partner
                result = database.get_data(
                    "bandwidth_customers", {"bandwidth_customer_name": changed_data["tenant_name"]}, ["id"]
                )
                logging.info(f"### Fetched result from bandwidth_customers : {result}")


                # If a matching record is found, use it as the bandwidth_account_id
                if not result.empty:
                    bandwidth_id = result["id"].iloc[0]
                    logging.info(f"### bandwidth_id: {bandwidth_id}")
                    changed_data["bandwidth_customer_id"] = int(bandwidth_id)
                    logging.debug(f"Assigned bandwidth_account_id: {bandwidth_id} for Partner: {Partner}")

            # Check if module is "NetSapiens Customers" and fetch netsapiens_customer_id
            elif module_name == "NetSapiens Customers":
                # Fetch the territory_id from netsapiens_reseller where partner matches description
                territory_value = changed_data.get("tenant_name", None)
                query_filter = (
                    {"territory": territory_value}
                    if territory_value
                    else {"description": data.get("description", "")}
                )

                # Fetch the territory_id based on the selected filter
                result = database.get_data(
                    "netsapiens_reseller", query_filter, ["territory_id"]
                )

                if result.empty:
                    logging.debug("### No matching record found for 'territory'. Attempting to query by 'description' instead." )
                    description_value = changed_data.get("tenant_name", "")
                    query_filter = {"description": description_value}

                    # Run the query again using description as the filter
                    result = database.get_data(
                        "netsapiens_reseller", query_filter, ["territory_id"]
                    )

                # If a matching record is found, use it as the netsapiens_customer_id
                if not result.empty:
                    territory_id = result["territory_id"].iloc[0]
                    changed_data["netsapiens_customer_id"] = int(territory_id)
                    logging.info(f"### Assigned netsapiens_customer_id: {territory_id} for description: {data.get('description', '')}" )

            # Clean up changed_data to ensure it only contains relevant fields for the insert
            if "id" in changed_data:
                changed_data.pop(
                    "id"
                )  # Remove 'id' if present, as it may be auto-generated
            if "created_by" not in changed_data:
                changed_data["created_by"] = (
                    user_name  # Ensure created_by is set to the current user
                )
            if "created_date" not in changed_data:
                changed_data["created_date"] = (
                    request_received_at  # Set created_date to the request time
                )

            if "is_deleted" not in changed_data or changed_data["is_deleted"] in (
                None,
                "None",
                "",
            ):
                changed_data["is_deleted"] = False

            logging.info(f"### Inserting data: {changed_data}")
            # Insert the new record into the main update table
            database.insert_data(changed_data, main_update_table)

            message = "Record created successfully"
            logging.debug("### Create action completed successfully.")
            response = {"flag": True, "message": message}

       
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "update_people_data",  
                "created_by": user_name,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments":f"updated people data with action: {action} and module: {module_name}",
                "module_name": "People module",   
                "request_received_at": request_received_at,
            }
            dbs.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is: {e}")

        return response
    except Exception as e:
        logging.error(f"### An error occurred: {e}")
        
        response = "unable to save data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "update_people_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f"Unable to save data with action: {action} and module: {module_name}",
                "module_name": "People module",
                "request_received_at": request_received_at,
            }
            dbs.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}")
        return response


# Function to convert Timestamps to strings
# def convert_timestamps(obj):
#     logging.info("Converting timestamps in the object: %s", obj)
#     if isinstance(obj, dict):
#         logging.info("Processing a dictionary.")
#         return {k: convert_timestamps(v) for k, v in obj.items()}
#     elif isinstance(obj, list):
#         logging.info("Processing a list with %d elements.", len(obj))
#         return [convert_timestamps(elem) for elem in obj]
#     elif isinstance(obj, pd.Timestamp):
#         logging.info("Converting pandas Timestamp: %s", obj)
#         return obj.strftime("%m-%d-%Y %H:%M:%S")
#     logging.info("No conversion applied for object: %s", obj)
#     return obj


def dataframe_to_blob(data_frame):
    """
    Converts a pandas DataFrame into a base64-encoded blob (Excel format).

    This function:
    - Writes the given DataFrame into an in-memory Excel file using openpyxl
    - Encodes the Excel file into base64 format (as a blob)
    - Returns the blob which can be stored, transmitted, or saved later

    Args:
        data_frame (pandas.DataFrame): The DataFrame to convert to blob format.

    Returns:
        bytes: A base64-encoded blob of the Excel file.
    """
    logging.info("### Converting DataFrame to blob.")
    # Create a BytesIO buffer
    bio = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        logging.info("### Writing DataFrame to Excel.")
        data_frame.to_excel(writer, index=False)
        logging.info("### DataFrame written to Excel successfully.")

    # Get the value from the buffer
    bio.seek(0)
    blob_data = base64.b64encode(bio.read())
    logging.info("### DataFrame converted to blob successfully.")

    return blob_data


def export(data, max_rows=500):
    """
    Exports data into an Excel file for the requested module.

    Args:
        data (dict): Request payload containing keys like:
            - "Partner" (str): Tenant/partner name
            - "module_name" (str): Name of the module to export
            - "db_name" (str): Tenant-specific database name
            - "ids" (list or str): Specific record IDs (for some modules)

        max_rows (int, optional): Maximum number of rows allowed for export. Defaults to 500.

    Returns:
        dict: A dictionary with either:
            - {"flag": True, "blob": "<base64_excel_blob>"} on success
            - {"flag": False, "message": "<error_reason>"} on failure
    """
    # logging.info the request data for debugging
    logging.info(f"### Request Data: {data}")
    ### Extract parameters from the Request Data
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    user_name = data.get("user_name", "")
    session_id = data.get("session_id", "")
    tenant_database = data.get("db_name", "")
    ids = data.get("ids", "")
    ##database connection for common utilss
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    logging.info(f"### Fetching export query for module: {module_name}")
    # Start time  and date calculation
    start_time = time.time()
    try:
        ##databse connenction
        database = DB(tenant_database, **db_config)
        # Fetch the query from the database based on the module name
        module_query_df = db.get_data("export_queries", {"module_name": module_name})
        # logging.info(module_query_df,'module_query_df')
        ##checking the dataframe is empty or not
        if module_query_df.empty:
            return {
                "flag": False,
                "message": f"No query found for module name: {module_name}",
            }
        # Extract the query string from the DataFrame
        query = module_query_df.iloc[0]["module_query"]
        if not query:
            logging.warning(f"### Unknown module name: {module_name}")
            return {"flag": False, "message": f"Unknown module name: {module_name}"}
        ##params for the specific module
        if module_name in ("inventory status history", "bulkchange status history"):
            params = [ids]
        else:
            params = [start_date, end_date]
        if module_name == "Users":
            data_frame = db.execute_query(query, params=params)
        else:
            data_frame = database.execute_query(query, params=params)
        # Check the number of rows in the DataFrame
        row_count = data_frame.shape[0]
        # logging.info(row_count,'row_count')
        ##checking the max_rows count
        if row_count > max_rows:
            return {
                "flag": False,
                "message": f"Cannot export more than {max_rows} rows.",
            }
        if module_name == "NetSapiens Customers":
            data_frame["NetSapiensType"] = "Reseller"
        # Capitalize each word and add spaces
        data_frame.columns = [
            col.replace("_", " ").capitalize() for col in data_frame.columns
        ]
        data_frame["S.No"] = range(1, len(data_frame) + 1)
        # Reorder columns dynamically to put S.NO at the first position
        columns = ["S.No"] + [col for col in data_frame.columns if col != "S.No"]

        # Format specific columns with dollar symbol for "Rate Plan Socs" module

        if module_name == "Rate Plan Socs":
            if "Overage dollar mb" in data_frame.columns:
                data_frame["Overage dollar mb"] = data_frame["Overage dollar mb"].apply(
                    lambda x: f"${x}"
                )
            if "Base rate" in data_frame.columns:
                data_frame["Base rate"] = data_frame["Base rate"].apply(
                    lambda x: f"${x}"
                )

        if module_name == "Customer Rate Plan":

            # Check if "Id" column exists in data_frame
            if "Id" in data_frame.columns:
                try:
                    # Convert all "Id" values into a list for a single query
                    ids_list = data_frame["Id"].tolist()

                    # Use a single SQL query to get the counts for each ID at once
                    count_query = """
                        SELECT customer_rate_plan_id, COUNT(*) AS count
                        FROM sim_management_inventory
                        WHERE customer_rate_plan_id IN %s
                        GROUP BY customer_rate_plan_id
                    """

                    # Execute the single query with the list of IDs
                    count_results = database.execute_query(
                        count_query, params=(tuple(ids_list),)
                    )

                    # Convert the count results to a dictionary for quick lookup
                    tn_counts_dict = {
                        int(row["customer_rate_plan_id"]): row["count"]
                        for _, row in count_results.iterrows()
                    }

                    # Map counts back to the DataFrame
                    data_frame["# of TNs"] = (
                        data_frame["Id"]
                        .map(tn_counts_dict)
                        .fillna(0)
                        .astype(int)
                        .astype(str)
                    )
                    columns.append("# of TNs")
                    columns.remove("Id")

                except Exception as e:
                    logging.exception(f"### Failed to retrieve count for Customer Rate Plan: {e}")
                    return {
                        "flag": False,
                        "message": f"An error occurred while fetching count for Customer Rate Plan: {e}",
                    }

        data_frame = data_frame[columns]
        # Proceed with the export if row count is within the allowed limit
        data_frame = data_frame.astype(str)
        data_frame.replace(to_replace="None", value="", inplace=True)
        logging.info("### Converting DataFrame to blob.")

        blob_data = dataframe_to_blob(data_frame)
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))

        # Return JSON response
        response = {"flag": True, "blob": blob_data.decode("utf-8")}
        audit_data_user_actions = {
            "service_name": "export",
            "created_by": user_name,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": f"Exported data into an Excel file for module: {module_name}",
            "module_name": "People module",
            "request_received_at": request_received_at,
        }
        db.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("### Auditing user actions.")
        return response
    except Exception as e:
        error_type = str(type(e).__name__)
        logging.exception(f"An error occurred: {e}")
        response="failed to export data"
        try:
            # Log error to database
            error_data = {
                "service_name": "export",
                "error_message": str(e),
                "error_type": error_type,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments":f"Failed to export data for module: {module_name}",
                "module_name": "People module",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Exception is : {e}")
        return response

# def people_revio_customers_list_view(data):

#     # Extract input parameters
#     logging.info(f"Request Data people_revio_customers_list_view: {data}")
#     request_received_at = data.get("request_received_at", "")
#     username = data.get("username", "")
#     ui_session_id = data.get("sessionID", "")
#     tenant_name = data.get("tenant_name", None)
#     role_name = data.get("role_name", None)
#     col_sort = data.get("col_sort", "")
#     tenant_database = data.get("db_name", "")

#     # Clean DB config and initialize DB connections
#     db_config.pop('customers', None)
#     db_config.pop('service_providers', None)
#     database = DB(tenant_database, **db_config)
#     common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

#     if tenant_name == "Altaworx Test":
#         tenant_name = "Altaworx"

#     # Fetch tenant metadata
#     #tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "billing_platform_flag"])
#     tenant_query = f"select id, billing_platform_flag from tenant where tenant_name = '{tenant_name}'"
#     tenant_data = common_utils_database.execute_query(tenant_query, True)
#     tenant_id = tenant_data["id"].to_list()[0]
#     billing_platform_flag = tenant_data["billing_platform_flag"].to_list()[0]

#     try:
#         return_json_data = {}
#         start_page = data.get("mod_pages", {}).get("start", 0)
#         end_page = data.get("mod_pages", {}).get("end", 100)
#         limit, offset = end_page - start_page, start_page

#         tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)

#         headers_map = get_headers_mapping(
#             tenant_database,
#             ["people_rev_io_customers"],
#             role_name,
#             "", "", "", "",
#             data,
#             common_utils_database
#         )

#         dropdown_options = [{"label": "All", "value": "all"}]
#         customers, service_providers, _, _, _ = get_user_acess_filters(username, database, tenant_name, role_name)
#         logging.info(f"Customers: {customers}, Service Providers: {service_providers}")

#         # Order clause
#         if col_sort:
#             key, value = next(iter(col_sort.items()))
#             order_condition = f"ORDER BY {key} {value.upper()} LIMIT {limit} OFFSET {offset}"
#         else:
#             order_condition = f"ORDER BY modified_date DESC LIMIT {limit} OFFSET {offset}"

#         filters = [f"customer_name = '{customers[0]}'" if len(customers) == 1 else f"customer_name IN {tuple(customers)}"] if customers else []

#         # User list query
#         users = []
#         user_query = f"SELECT CONCAT(first_name, ' ', last_name) AS full_name FROM users WHERE username = '{username}'"
#         user_result = common_utils_database.execute_query(user_query, True)
#         if not user_result.empty:
#             users = user_result["full_name"].tolist()

#         if customers:
#             users_condition = (
#                 f""" AND created_by IN ({','.join(f"'{user}'" for user in users)}) """
#                 f"""OR modified_by IN ({','.join(f"'{user}'" for user in users)})  """
#             )
#         else:
#             users_condition = ""

#         # Construct base query
#         if service_providers or customers:
#             base_query = ("SELECT COUNT(*) OVER() AS total_count, id, tenant_name AS partner, '' AS agent_name, customer_name AS name, billing_account_number AS account,"
#                           " customer_bill_period_end_day, customer_bill_period_end_hour, modified_date, tenant_id FROM customers"
#                           if billing_platform_flag else
#                           "SELECT COUNT(*) OVER() AS total_count, id, partner, agent_name, name, account,"
#                           " customer_bill_period_end_day, customer_bill_period_end_hour, customer_name, created_by, modified_by, cust_id, tenant_id"
#                           " FROM public.vw_people_revio_customers")

#             conditions = [f"tenant_id = {tenant_id}"] + filters
#             if billing_platform_flag and not filters:
#                 conditions.append("billing_platform_customer_id IS NOT NULL AND billing_platform_customer_id != ''")

#             query = base_query + " WHERE " + " AND ".join(conditions) + users_condition + f" {order_condition}"
#         else:
#             query = (f"SELECT COUNT(*) OVER() AS total_count, id, partner, agent_name, name, account,"
#                      f" customer_bill_period_end_day, customer_bill_period_end_hour, cust_id, tenant_id"
#                      f" FROM public.vw_people_revio_customers WHERE tenant_id = {tenant_id} {order_condition}"
#                      if not billing_platform_flag else
#                      f"SELECT COUNT(*) OVER() AS total_count, id, tenant_name AS partner, '' AS agent_name, customer_name AS name, '' AS account,"
#                      f" customer_bill_period_end_day, customer_bill_period_end_hour, modified_date, tenant_id"
#                      f" FROM customers WHERE tenant_id = {tenant_id} AND billing_platform_customer_id IS NOT NULL {order_condition}")

#         # Query execution
#         logging.info(f"Executing customer query: {query}")
#         #start_time = time.time()
#         result = database.execute_query(query, True)
#         logging.info(f"Query executed")

#         total_count = int(result.iloc[0]["total_count"]) if not result.empty else 0
#         pages = {"start": start_page, "end": end_page, "total": total_count}

#         df_dict = convert_timestamp_data(result.to_dict(orient="records"), tenant_time_zone)

#         return_json_data.update({
#             "flag": True,
#             "message": "Data fetched successfully" if not result.empty else "No data found",
#             "data": serialize_data(df_dict),
#             "headers_map": headers_map,
#             "dropdown_options": dropdown_options,
#             "pages": pages
#         })

#         try:
#             audit_data = {
#                 "service_name": "people_revio_customers_list_View",
#                 "created_by": username,
#                 "status": str(return_json_data["flag"]),
#                 "session_id": ui_session_id,
#                 "tenant_name": tenant_name,
#                 "module_name": "people Billing Platform Customers",
#                 "comments": "getting billing platform customers list view",
#                 "request_received_at": request_received_at,
#             }
#             common_utils_database.update_audit(audit_data, "audit_user_actions")
#         except Exception as audit_exc:
#             logging.warning(f"Audit logging failed: {audit_exc}")

#         return return_json_data

#     except Exception as main_exc:
#         error_msg = str(main_exc)
#         logging.error(f"An error occurred for people_revio_customers_list_view: {error_msg}")
#         error_data = {
#             "service_name": "people_revio_customers_list_View",
#             "error_message": f"An error occurred while fetching data: {error_msg}",
#             "error_type": type(main_exc).__name__,
#             "users": username,
#             "session_id": ui_session_id,
#             "tenant_name": tenant_name,
#             "comments": error_msg,
#             "module_name": "getting billing platform customers list view",
#             "request_received_at": request_received_at,
#         }
#         common_utils_database.log_error_to_db(error_data, "error_log_table")

#         return {
#             "flag": True,
#             "message": "Something went wrong while fetching the data",
#             "data": [],
#             "headers_map": headers_map,
#         }

def people_revio_customers_list_view(data):

    """
    Fetches a paginated list of Rev.io customer data for the People module based on 
    user access, filters, and sorting preferences.

    Args:
        data (dict): Input data containing keys like:
            - tenant_name (str): Tenant name for access scope.
            - role_name (str): Role of the user (e.g. "admin", "user").
            - db_name (str): Tenant-specific database name.
            - col_sort (dict): Optional sorting column and direction (e.g., {"name": "asc"}).
            - mod_pages (dict): Pagination info with 'start' and 'end' indexes.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Success status of the operation.
            - message (str): Success or error message.
            - data (list): Serialized customer records with timestamps converted to tenant timezone.
            - headers_map (dict): Mapping of column headers.
            - dropdown_options (list): Filter dropdown options.
            - pages (dict): Pagination metadata with total count.
    """
    logging.info(f"### Request Data for people_revio_customers_list_view: {data}")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    ui_session_id = data.get("sessionID", "")
    # logging.info(f"Request Data: {data}")

    tenant_name = data.get("tenant_name", None)
    role_name = data.get("role_name", None)
    username = data.get("username", "")
    # del db_config['customers']
    # del db_config['service_providers']
    col_sort= data.get("col_sort", "")
    tenant_database = data.get("db_name", "")
    # Database Connection
    del db_config['customers']
    del db_config['service_providers']
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    logging.info(f"### DB config: {db_config}")


    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]



    try:
        return_json_data = {}

        # Fetch tenant_id based on tenant_name
        # tenant_id = common_utils_database.get_data("tenant", {'tenant_name': tenant_name}, ['id'])['id'].to_list()[0]

        # Pagination logic
        start_page = data.get("mod_pages", {}).get("start", 0)
        end_page = data.get("mod_pages", {}).get("end", 100)

        limit = end_page - start_page
        offset = start_page

        # # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(common_utils_database,data)

        headers_map = get_headers_mapping(
            tenant_database,
            ["people_rev_io_customers"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            common_utils_database
        )

        # Prepare dropdown data
        dropdown_options = [{"label": "All", "value": "all"}]  # Add the "All" option

        customers = []
        service_providers = []
        customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name = get_user_acess_filters(username, database,tenant_name,role_name)
        logging.info(f"### Customers: {customers}, Service Providers: {service_providers}")

        if col_sort:
            # Extract the single key-value pair
            key, value = list(col_sort.items())[0]  # Get the first and only pair
            # Construct the ORDER BY clause
            order_condition = (
                f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
            )
        else:
            # If users is None or empty, we skip the WHERE clause entirely
            order_condition = (
                f" ORDER BY modified_date DESC LIMIT 100 OFFSET {start_page}"
            )

        filters = []
        if customers:
            if len(customers) == 1:
                filters.append(f" customer_name = '{customers[0]}'")  # Add single quotes
            else:
                filters.append(f"  customer_name IN {tuple(customers)}")  # Tuple already includes quotes

        user_query = f"""
            SELECT CONCAT(first_name, ' ', last_name) AS full_name
            FROM users
            WHERE username = '{username}'
        """



        # Execute query safely
        user_result = common_utils_database.execute_query(user_query, True)

        if user_result is not None and not user_result.empty:
            users = user_result["full_name"].tolist()


        # Construct the WHERE clause conditionally based on 'users'
        if customers:
            users_condition = (
                f""" AND created_by IN ({','.join(f"'{user}'" for user in users)}) """
                f"""OR modified_by IN ({','.join(f"'{user}'" for user in users)})  """
            )
        else:
            users_condition = ""


        if service_providers or customers:

            query = """
                            SELECT
                                COUNT(*) OVER() AS total_count,
                                id,
                                partner,
                                agent_name,
                                name,
                                billing_customer_id,
                                account,
                                customer_bill_period_end_day,
                                customer_bill_period_end_hour,
                                customer_name,
                                created_by,
                                modified_by,
                                cust_id,
                                tenant_id
                            FROM
                                public.vw_people_revio_customers
                            """



            # Append filters to the WHERE clause
            if filters:
                query += " WHERE " + f""" tenant_id =  {tenant_id} and """  + " AND ".join(filters)  # Properly join conditions with AND

            # Add the order condition
            query += f"{users_condition} {order_condition}"
        else:
            query = f"""
                        SELECT
                            COUNT(*) OVER() AS total_count,
                            id,
                            partner,
                            billing_customer_id,
                            agent_name,
                            name,
                            account,
                            customer_bill_period_end_day,
                            customer_bill_period_end_hour,
                            cust_id,
                            tenant_id
                        FROM
                            public.vw_people_revio_customers
                            where tenant_id = {tenant_id}
                        {order_condition}"""

        params = [limit, offset]
        logging.info(f"### Executing query to fetch all customers with params: {params}")

        # Execute the main query and get results
        start_time = time.time()
        result = database.execute_query(query,True)
        query_duration = time.time() - start_time
        logging.info(f"### Query executed in {query_duration:.2f} seconds")

        # Execute the count query
        logging.info("### Executing count query.")
        # count_result = database.execute_query(count_query, True)
        total_count = int(result.iloc[0]["total_count"]) if not result.empty else 0

        # Pagination pages info
        pages = {"start": start_page, "end": end_page, "total": total_count}

        logging.info("### Preparing the response data.")
        # Execute each query and store the result
        # result = database.execute_query(query, params=params)
        # df_dict = result.to_dict(orient='records')
        df_dict = convert_timestamp_data(
            result.to_dict(orient="records"), tenant_time_zone
        )

        # Set the response data
        if not result.empty:
            return_json_data["flag"] = True
            return_json_data["message"] = "Data fetched successfully"
            return_json_data["data"] = serialize_data(df_dict)
            return_json_data["headers_map"] = headers_map
            return_json_data["dropdown_options"] = dropdown_options
            return_json_data["pages"] = pages
            logging.info("### Data fetched successfully.")
        else:
            return_json_data["flag"] = True
            return_json_data["message"] = "No data found or an error occurred"
            return_json_data["data"] = []
            return_json_data["dropdown_options"] = dropdown_options
            return_json_data["headers_map"] = headers_map
            logging.warning("No data found.")

        try:
            audit_data_user_actions = {
                "service_name": "people_revio_customers_list_view",
                "created_by": username,
                "status": str(return_json_data["flag"]),
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "module_name": "People module",
                "comments": f"getting revio customers list view for tenant: {tenant_name}",
                "request_received_at": request_received_at,
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception while updating audit and exception is : {e}")

        return return_json_data

    except Exception as e:
        logging.error(f"### An error occurred: {str(e)}")
        # Error handling
        return_json_data["flag"] = True
        return_json_data["headers_map"] = headers_map
        return_json_data["message"] = f"Failed!! Error: {str(e)}"
        return_json_data["data"] = []
        response = "failed while fetching the data"
        error_type = error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "people_revio_customers_list_view",
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Failed to fetch revio customers list view for tenant: {tenant_name}",
            "module_name": "People module",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return return_json_data




# def add_people_revcustomer_dropdown_data(data):
#     """
#     Fetches dropdown data for adding a REV customer in the People module.

#     Args:
#         data (dict): A dictionary containing the following keys:
#             - tenant_name (str): Tenant name for context
#             - module_name (str): Name of the module calling this function
#             - db_name (str): Name of the database to connect to
#             - customer_name (str, optional): Specific customer name to use (not mandatory)

#     Returns:
#         dict: A response dictionary with the following structure:
#             - flag (bool): Indicates success or failure
#             - message (str): A message about the status
#             - response_data (dict): Contains:
#                 - rev_io_account (list): List of integration usernames
#                 - customer_names (list): Unique customer names
#                 - rev_bill_profile (list): Active REV bill profiles
#                 - customer_rate_plan (list): Customer names with their REV customer IDs
#     """
#     # checking the access token valididty
#     username = data.get("username", None)

#     tenant_name = data.get("tenant_name", None)
#     session_id = data.get("session_id", None)
#     module_name = data.get("module_name", None)
#     tenant_database = data.get("db_name", "")
#     # database Connection
#     database = DB(tenant_database, **db_config)

#     try:
#         response_data = {}
#         rev_customer_name = data.get("customer_name", None)
#         response_message = ""
#         # Query 1: Get customer ID
#         query1 = """select ia.username from integration_authentication ia where ia.integration_id =3 and ia.is_active =true;"""
#         logging.info("### Executing Query 1 to retrieve customer ID.")

#         rev_io_account_df = database.execute_query(query1, flag=True)
#         # Extract only the 'username' column values as a list
#         if isinstance(rev_io_account_df, pd.DataFrame) and not rev_io_account_df.empty:
#             rev_io_account = rev_io_account_df["username"].dropna().tolist()
#             # Remove duplicates by converting to a set and back to a list
#             rev_io_account = list(dict.fromkeys(rev_io_account))

#             response_data["rev_io_account"] = rev_io_account
#             logging.debug(f"### Retrieved rev_io_account: {rev_io_account}")
#         else:
#             logging.info("### No data found or query failed")
#         # Retrieve all customer_name values from the 'customers' table
#         customer_names_df = database.get_data("customers", {}, ["customer_name"])
#         if isinstance(customer_names_df, pd.DataFrame) and not customer_names_df.empty:
#             customer_names = customer_names_df["customer_name"].tolist()
#             customer_names = list(set(customer_names))
#             response_data["customer_names"] = customer_names
#             logging.debug(f"### Retrieved customer names: {customer_names}")
#         else:
#             logging.info("### No customer names found or query failed")
#             response_data["customer_names"] = []

#         # Query 2: Get Bill Profile
#         query2 = """SELECT  description FROM public.revbillprofile where integration_authentication_id = 1 and is_active = 'true' and is_deleted = 'false' order by description ASC"""

#         logging.info("### Executing Query 2 to retrieve bill profiles.")
#         rev_io_bill_profile_df = database.execute_query(query2, flag=True)
#         # Extract only the 'username' column values as a list
#         if (
#             isinstance(rev_io_bill_profile_df, pd.DataFrame)
#             and not rev_io_bill_profile_df.empty
#         ):
#             rev_bill_profile_list = (
#                 rev_io_bill_profile_df["description"].dropna().unique().tolist()
#             )
#             response_data["rev_bill_profile"] = rev_bill_profile_list
#             logging.debug(f"### Retrieved bill profiles: {rev_bill_profile_list}")
#         else:
#             logging.info("### No bill profiles found or query failed")
#             response_data["rev_bill_profile"] = []

#         # Query 3: Get Customer Rate Plan
#         query3 = """
#                 SELECT *
#                 FROM revcustomer
#                 WHERE is_active = 'true'
#                 AND is_deleted = 'false'
#                 AND rev_customer_id IS NOT NULL
#                 AND rev_customer_id <> ''
#                 AND integration_authentication_id = 1
#                 AND status IS NOT NULL
#                 AND status <> 'CLOSED'
#                 ORDER BY customer_name, rev_customer_id;
#             """
#         logging.info("### Executing Query 3 to retrieve customer rate plans.")
#         customer_rate_plan = database.execute_query(query3, flag=True)
#         # Extract only the 'username' column values as a list
#         if (
#             isinstance(customer_rate_plan, pd.DataFrame)
#             and not customer_rate_plan.empty
#         ):
#             # Construct the customer rate plan list
#             response_data["customer_rate_plan"] = [
#                 f"{row['customer_name']} - {row['rev_customer_id']}"  # Adjust column names as needed
#                 for index, row in customer_rate_plan.iterrows()
#             ]
#             logging.debug(f"### Retrieved customer rate plans: {response_data['customer_rate_plan']}" )
#         else:
#             logging.warning("### No customers found or query failed")
#             response_data["customer_rate_plan"] = []

#         message = " data sent sucessfully"
#         response = {"flag": True, "message": message, "response_data": response_data}
#         return response
#     except Exception as e:
#         logging.warning(f"### Something went wrong and error is {e}")
#         message = "Something went wrong while getting add service product"
#         # Error Management
#         error_type = str(type(e).__name__)
#         error_data = {
#             "service_name": "add_people_revcustomer_dropdown_data",
#             "error_message": str(e),
#             "error_type": error_type,
#             "users": username,
#             "session_id": session_id,
#             "tenant_name": tenant_name,
#             "comments": message,
#             "module_name": module_name,
#         }
#         database.log_error_to_db(error_data, "error_log_table")
#         return {"flag": False, "message": message}




def add_people_revcustomer_dropdown_data(data):
    """
    Fetches dropdown data for adding a REV customer in the People module.

    Args:
        data (dict): A dictionary containing the following keys:
            - tenant_name (str): Tenant name for context
            - module_name (str): Name of the module calling this function
            - db_name (str): Name of the database to connect to
            - customer_name (str, optional): Specific customer name to use (not mandatory)

    Returns:
        dict: A response dictionary with the following structure:
            - flag (bool): Indicates success or failure
            - message (str): A message about the status
            - response_data (dict): Contains:
                - rev_io_account (list): List of integration usernames
                - customer_names (list): Unique customer names
                - rev_bill_profile (list): Active REV bill profiles
                - customer_rate_plan (list): Customer names with their REV customer IDs
    """
    logging.info(f"### Request Data for add_people_revcustomer_dropdown_data: {data}")
    # checking the access token valididty
    username = data.get("username", None)
    request_received_at = data.get("request_received_at","")

    tenant_name = data.get("tenant_name", None)
    session_id = data.get("session_id", None)
    module_name = data.get("module_name", None)
    tenant_database = data.get("db_name", "")
    # database Connection
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        response_data = {}
        # rev_customer_name = data.get("customer_name", None)
        # response_message = ""
        # Query 1: Get customer ID
        query1 = """select ia.username from integration_authentication ia where ia.integration_id =3 and ia.is_active =true;"""
        logging.info("### Executing Query 1 to retrieve customer ID.")

        rev_io_account_df = database.execute_query(query1, flag=True)
        # Extract only the 'username' column values as a list
        if isinstance(rev_io_account_df, pd.DataFrame) and not rev_io_account_df.empty:
            rev_io_account = rev_io_account_df["username"].dropna().tolist()
            # Remove duplicates by converting to a set and back to a list
            rev_io_account = list(dict.fromkeys(rev_io_account))

            response_data["rev_io_account"] = rev_io_account
            logging.debug(f"### Retrieved rev_io_account: {rev_io_account}")
        else:
            logging.info("### No data found or query failed")
        # Retrieve all customer_name values from the 'customers' table
        customer_names_df = database.get_data("customers", {}, ["customer_name"])
        if isinstance(customer_names_df, pd.DataFrame) and not customer_names_df.empty:
            customer_names = customer_names_df["customer_name"].tolist()
            customer_names = list(set(customer_names))
            response_data["customer_names"] = customer_names
            logging.debug(f"### Retrieved customer names: {customer_names}")
        else:
            logging.info("### No customer names found or query failed")
            response_data["customer_names"] = []

        # Query 2: Get Bill Profile
        query2 = """SELECT  description FROM public.revbillprofile where integration_authentication_id = 1 and is_active = 'true' and is_deleted = 'false' order by description ASC"""

        logging.info("### Executing Query 2 to retrieve bill profiles.")
        rev_io_bill_profile_df = database.execute_query(query2, flag=True)
        # Extract only the 'username' column values as a list
        if (
            isinstance(rev_io_bill_profile_df, pd.DataFrame)
            and not rev_io_bill_profile_df.empty
        ):
            rev_bill_profile_list = (
                rev_io_bill_profile_df["description"].dropna().unique().tolist()
            )
            response_data["rev_bill_profile"] = rev_bill_profile_list
            logging.debug(f"### Retrieved bill profiles: {rev_bill_profile_list}")
        else:
            logging.info("### No bill profiles found or query failed")
            response_data["rev_bill_profile"] = []

        # Query 3: Get Customer Rate Plan
        query3 = """
                SELECT *
                FROM revcustomer
                WHERE is_active = 'true'
                AND is_deleted = 'false'
                AND rev_customer_id IS NOT NULL
                AND rev_customer_id <> ''
                AND integration_authentication_id = 1
                AND status IS NOT NULL
                AND status <> 'CLOSED'
                ORDER BY customer_name, rev_customer_id;
            """
        logging.info("### Executing Query 3 to retrieve customer rate plans.")
        customer_rate_plan = database.execute_query(query3, flag=True)
        # Extract only the 'username' column values as a list
        if (
            isinstance(customer_rate_plan, pd.DataFrame)
            and not customer_rate_plan.empty
        ):
            # Construct the customer rate plan list
            response_data["customer_rate_plan"] = [
                f"{row['customer_name']} - {row['rev_customer_id']}"  # Adjust column names as needed
                for index, row in customer_rate_plan.iterrows()
            ]
            logging.debug(f"### Retrieved customer rate plans: {response_data['customer_rate_plan']}" )
        else:
            logging.warning("### No customers found or query failed")
            response_data["customer_rate_plan"] = []
        message = "Data sent successfully"
        response = {"flag": True, "message": message, "response_data": response_data}
       
        return response
    
    except Exception as e:
        logging.warning(f"### Something went wrong and error is {e}")
        response = "Something went wrong while fetching Rev customer dropdown data"

        # Error Management
        try : 
            error_type = str(type(e).__name__)
            error_data = {
                "service_name": "add_people_revcustomer_dropdown_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"Failed to fetch Rev customer dropdown data for tenant: {tenant_name}",
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e  : 
             logging.warning(f"### Exception while updating audit and exception is {e}")

        return {"flag": False, "message": message}



def download_people_bulk_upload_template(data):
    """
    Generates and returns an Excel bulk upload template for the 'People' module.

    Args:
        data (dict): Dictionary containing required metadata:
            - tenant_name (str): Name of the tenant
            - db_name (str): Name of the tenant's database
    Returns:
        dict: 
            On success:
                {
                    "flag": True,
                    "blob": <base64-encoded empty Excel template>
                }
            On failure:
                {
                    "flag": False,
                    "message": "Unable to download people bulk upload template"
                }
    """
    logging.info(f"### Request Data for download_people_bulk_upload_template: {data}")
    username = data.get("username", "")
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    tenant_database = data.get("db_name", "")
    request_received_at = data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    common_utils_database = None  #  Safe initialization

    try: 
        # Construct the SQL query based on the provided logic
        query = """
            SELECT column_name
            FROM information_schema.columns
            WHERE
                (table_name = 'revagent' AND column_name = 'agent_name') OR
                (table_name = 'revcustomer' AND column_name IN ('customer_name', 'rev_customer_id')) OR
                (table_name = 'customers' AND column_name IN ('tenant_name','customer_bill_period_end_day', 'customer_bill_period_end_hour'));
        """
        # database Connection
        database = DB(tenant_database, **db_config)
        common_utils_database = DB('common_utils', **db_config)

        logging.info(f"### Executing query to fetch column names from the database: {query}")
        columns_df = database.execute_query(
            query, flag=True
        )  # Use flag=True since no parameters are required

        if isinstance(
            columns_df, bool
        ):  # Handle case if execution returns True (error scenario)

            logging.info("### Query execution returned a boolean value instead of a DataFrame.")
            return {"flag": False, "error": "Failed to retrieve columns from the database."}
        logging.debug(f"### Columns retrieved from the database: {columns_df['column_name'].tolist()}")
        # Remove the 'id' column if it exists
        columns_df = columns_df[columns_df["column_name"] != "id"]
        columns_df["column_name"] = (
            columns_df["column_name"].str.replace("_", " ").str.capitalize()
        )

        # Create an empty DataFrame with the column names as columns
        result_df = pd.DataFrame(columns=columns_df["column_name"].values)


        logging.debug(f"### Resulting DataFrame structure: {result_df.columns.tolist()}")
        # Convert the DataFrame to blob (binary data) and return it as part of the response
        blob_data = dataframe_to_blob(result_df)
        response = {"flag": True, "blob": blob_data.decode("utf-8")}
        logging.info("### Successfully generated the bulk upload template.")

        try:
            audit_data_user_actions = {
                    "service_name": "download_people_bulk_upload_template",
                    "created_by": username,
                    "status": str(response["flag"]),
                    "session_id": ui_session_id,
                    "tenant_name": tenant_name,
                    "module_name": "People module",
                    "comments": f"Downloading people bulk upload template for tenant: {tenant_name}",
                    "request_received_at": request_received_at,
                }
            
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
                logging.warning(f"### Exception while updating audit :{e}")
        return response
    
    except Exception as e:
        logging.exception("### An error occurred in download_people_bulk_upload_template : {e}")
        response = "Unable to download people bulk upload template"
        error_type = type(e).__name__
        # Error Management
        error_data = {
            "service_name": "download_people_bulk_upload_template",
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Failed to download people bulk upload template for tenant: {tenant_name}",
            "module_name": "People module",
        }
        if common_utils_database : # if connection is exist then auditing will work 
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        response = {"flag": False, "message": "Unable to download people bulk upload template"}
        return response


def convert_booleans(data):
    """
    Converts string boolean values ("true"/"false") in a dictionary to actual Python boolean values (True/False).

    Args:
        data (dict): The input dictionary containing key-value pairs with potential string booleans.

    Returns:
        dict: The same dictionary with all "true"/"false" string values converted to boolean True/False.
    """
    logging.debug(f"### Initial data for conversion: {data}")
    for key, value in data.items():
        if isinstance(value, str) and value.lower() == "true":
            data[key] = True
            logging.debug(f"### Converted '{key}' from string 'true' to boolean True")
        elif isinstance(value, str) and value.lower() == "false":
            data[key] = False
            logging.debug(f"### Converted '{key}' from string 'false' to boolean False")
        elif isinstance(value, dict):  # Recursively process nested dictionaries
            logging.debug(f"###Found nested dictionary at key '{key}', processing recursively.")
            convert_booleans(value)
    return data  # Return the modified dictionary


def submit_update_info_people_revcustomer(data):
    """
    Submits, updates, or retrieves Rev.io customer information based on the provided action.
    Depending on the 'action' in the input data ('create', 'update', or 'info')

    Parameters:
        data (dict): Input dictionary containing:
            - tenant_name (str): Name of the tenant requesting the action.
            - db_name (str): Name of the tenant-specific database.
            - changed_data (dict): Dictionary with updated field values.
            - new_data (dict): Dictionary with newly submitted field values.
            - new_payload (dict): Cleaned payload to insert into database.
            - action (str): One of ['create', 'update', 'info'].
            - api_payload (dict): Parameters to be sent to Rev.io API (for 'create').

    Returns:
        dict: A structured response dictionary containing:
            - flag (bool): Indicates success or failure of the operation.
            - message (str): Human-readable message describing the outcome.
            - api_response (dict): Rev.io API response (if applicable).
            - insert_response (dict): Database insert response (if applicable).
            - error_type (str): Optional, describes the type of error if failure occurred.

    """
    logging.info(f"### Received data for submit_update_info_people_revcustomer: {data}")
    data = convert_booleans(data)
    changed_data = data.get("changed_data", {})
    user_name = data.get("username", "")
    ui_session_id = data.get("sessionID")
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at", "")
    new_data = {k: v for k, v in data.get("new_data", {}).items() if v}
    new_payload = {k: v for k, v in data.get("new_payload", {}).items() if v}
    # unique_id = changed_data.get("id")
    action = data.get("action", "")
    api_payload = data.get("api_payload", "")

    # Database connection setup
    tenant_database = data.get("db_name", "")
    # database Connection
    dbs = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    tenant_id = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id"]
    )["id"].to_list()[0]

    try:
        if action == "create":
            new_payload["tenant_id"] = tenant_id
            new_payload["customer_name"] = new_payload["parent_customer"]
            new_payload["tenant_name"] = tenant_name
            new_data = {k: v for k, v in new_data.items() if v not in [None, "None"]}
            for k, v in new_data.items():
                if isinstance(v, list):
                    if all(isinstance(item, dict) for item in v):
                        new_data[k] = json.dumps(
                            v
                        )  # Convert list of dicts to JSON string
                    else:
                        new_data[k] = ", ".join(
                            str(item) for item in v if item is not None
                        )  # Convert other types to strings

            new_payload = {
                k: v for k, v in new_payload.items() if v not in [None, "None"]
            }
            for k, v in new_payload.items():
                if isinstance(v, list):
                    if all(isinstance(item, dict) for item in v):
                        new_payload[k] = json.dumps(
                            v
                        )  # Convert list of dicts to JSON string
                    else:
                        new_payload[k] = ", ".join(
                            str(item) for item in v if item is not None
                        )  # Convert other types to strings

            # url = 'https://api.revioapi.com/v1/Customers'
            url = os.getenv("PEOPLE_REVIO_CUSTOMER", " ")
            # headers = {
            #     "Ocp-Apim-Subscription-Key": "0fc3f44bc0814510ba38c7fa27a151a7",
            #     "Authorization": "Basic QU1PUFRvUmV2aW9AYWx0YXdvcnhfc2FuZGJveDpHZW9sb2d5N0BTaG93aW5nQFN0YW5r",
            # }

            # First check parent tenant if needed
            if tenant_name not in ("Altaworx Test", "Altaworx", "Altaworx - Go Tech"):
                parent_tenant_query = f'''
                    SELECT parent_tenant_id
                    FROM tenant
                    WHERE tenant_name = '{tenant_name}'
                '''
                parent_tenant_id_df = common_utils_database.execute_query(parent_tenant_query, True)

                if not parent_tenant_id_df.empty:
                    parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

                    if parent_tenant_id is not None:
                        parent_tenant_id = int(parent_tenant_id)
                        parent_tenant_name_query = f'''
                            SELECT tenant_name
                            FROM tenant
                            WHERE id = {parent_tenant_id}
                        '''
                        parent_tenant_name_df = common_utils_database.execute_query(parent_tenant_name_query, True)

                        if not parent_tenant_name_df.empty:
                            tenant_name = parent_tenant_name_df['tenant_name'].to_list()[0]

            # Now set headers based on tenant_name
            if tenant_name == "Altaworx Test" or tenant_name == "Altaworx":
                headers = {
                    "Ocp-Apim-Subscription-Key": os.getenv("REVIO_Subscription_Key_ALTAWOX", " "),
                    "Authorization": f"Basic {os.getenv('ALTAWOX_REVIO_acess_token', '')}",
                    "Accept": "application/json",
                }
            elif tenant_name == "Altaworx - Go Tech":
                headers = {
                    "Ocp-Apim-Subscription-Key": os.getenv("REVIO_Subscription_Key_Go_Tech", " "),
                    "Authorization": f"Basic {os.getenv('Go_Tech_REVIO_acess_token', '')}",
                    "Accept": "application/json",
                }
            else:
                headers = {
                "Ocp-Apim-Subscription-Key": "0fc3f44bc0814510ba38c7fa27a151a7",
                "Authorization": "Basic QU1PUFRvUmV2aW9AYWx0YXdvcnhfc2FuZGJveDpHZW9sb2d5N0BTaG93aW5nQFN0YW5r",
            }

            # Pass the new_data as params in the GET request
            params = api_payload
            logging.info(f"### api_payload : {api_payload}")
            logging.info(f"### url : {url} and headers : {headers}")

            # Call the API and check response
            api_response = requests.post(url, headers=headers, params=params)
            if api_response.status_code == 200:
                # Success, construct and return response with both API and database insert responses
                message = "Add Rev.io product data submitted successfully."

                # Call the insert_data function and capture its response
                insert_response = dbs.insert_data(new_payload, "customers")

                # Ensure insert_response is a dictionary for consistency
                if isinstance(
                    insert_response, int
                ):  # if it's an ID or similar, wrap in dict
                    insert_response = {"success": True, "inserted_id": insert_response}
                elif not isinstance(insert_response, dict):
                    insert_response = {
                        "success": False,
                        "message": "Unknown insert response format",
                    }

                # Create the response data including both the API response and insert response
                response_data = {
                    "flag": True,
                    "message": message,
                    "api_response": api_response.json(),
                    "insert_response": insert_response,
                }

                # return response_data
                
            
            else:
                # API call failed, return error message
                response_data = {
                "flag": False,
                "message": f"Failed to retrieve data from client API: {api_response.status_code} - {api_response.text}",
                "error_type": "ClientAPIRequestFailed"
                 }
                # return response_data


        elif action == "update":
            # Remove fields not in 'customers' table from 'changed_data'
            allowed_fields = [
                "id",
                "customer_bill_period_end_day",
                "customer_bill_period_end_hour",
                "modified_by",
                "modified_date",
            ]
            filtered_changed_data = {
                k: v
                for k, v in changed_data.items()
                if k in allowed_fields and v is not None
            }

            # Ensure 'id' is available for WHERE clause
            if "id" in filtered_changed_data:
                dbs.update_dict(
                    "customers",
                    filtered_changed_data,
                    {"id": filtered_changed_data["id"]},
                )
                message = "Update successful."
                response_data = {"flag": True, "message": message}
            else:
                message = "Update failed. Missing required ID for update."
                response_data = {
                    "flag": False,
                    "message": message,
                    "error_type": "MissingIDForUpdate"
                }

                # return response_data

        elif action == "info":
            line_item_count = 0  # Initialize with a default value

            query = """
                SELECT COUNT(dt.customer_id) AS TotalSimCardCount
                    FROM public.device jd
                    INNER JOIN public.device_tenant dt ON jd.id = dt.device_id
                    INNER JOIN public.customers s ON dt.customer_id = s.id
                    WHERE jd.is_active = 'true'
                        AND jd.is_deleted = 'false'
                        AND (dt.customer_id IS NOT NULL
                            AND s.id IS NOT NULL
                            AND s.id = %s)
                        AND dt.tenant_id = %s;
            """
            params = [data["info_data"]["id"], tenant_id]

            # Execute the query
            result = dbs.execute_query(query, params=params)

            if isinstance(result, list) and result:
                line_item_count = result[0].get("line_item_count", 0)
            elif isinstance(result, pd.DataFrame) and not result.empty:
                line_item_count = result.iloc[0].get("line_item_count", 0)

            response_data = {
                "flag": True,
                "message": f"{action} Successfully",
                "line_item_count": str(line_item_count),
            }
        try:
            if response_data.get("flag") is True:
                audit_data_user_actions = {
                    "service_name": "submit_update_info_people_revcustomer",
                    "created_by": user_name,
                    "status": str(response_data["flag"]),
                    "session_id": ui_session_id,
                    "tenant_name": tenant_name,
                    "module_name": "People module",
                    "comments": response_data.get("message", ""),
                    "request_received_at": request_received_at,
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            else:
                error_data = {
                    "service_name": "submit_update_info_people_revcustomer",
                    "error_message": response_data.get("message", ""),
                    "error_type": response_data.get("error_type","Unknown Error"),
                    "users": user_name,
                    "session_id": ui_session_id,
                    "tenant_name": tenant_name,
                    "comments": response_data.get("message", ""),
                    "module_name": "People module",
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")

        return response_data
       
    except Exception as e:
        logging.error(f"### An error occurred: {e}")
        response = "Unable to save the data"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "submit_update_info_people_revcustomer",
                "error_message": str(e),
                "error_type": error_type,
                "users": user_name,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": f"unable to save the data with action {action}",
                "module_name": "People module",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"Audit logging exception : {e}")
        response = {"flag": False, "message": message}
        return response


def people_bulk_import_data(data):
    """
    Handles the bulk import of 'people' data from a base64-encoded Excel file.

    This function:
    - Reads the provided Excel data (in base64) and loads it into a DataFrame
    - Performs an append operation if the `insert_flag` is set correctly

    Args:
        data (dict): A dictionary containing the following keys:
            - "tenant_name" (str): Name of the tenant performing the import
            - "db_name" (str): Target tenant database
            - "insert_flag" (str): Insertion mode; currently supports only "append"
            - "blob" (str): Base64-encoded Excel data

    Returns:
        dict: Result of the operation with keys:
            - "flag" (bool): True if successful, False otherwise
            - "message" (str): Description of the result
            - Optional debugging info like column mismatches if applicable
    """
    logging.info(f"### Starting people_bulk_import_data with data: {data}")
    username = data.get("username", "")
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    common_utils_database = None  # Safe initialization

    insert_flag = data.get("insert_flag", "append")
    tenant_database = data.get("db_name", "")

    try:
        # Initialize the database connections
        database = DB(tenant_database, **db_config)
        common_utils_database = DB('common_utils', **db_config)

        # Check for blob
        blob_data = data.get("blob")
        if not blob_data:
            message = "Blob data not provided"
            logging.warning(message)
            if common_utils_database:
                error_data = {
                    "service_name": "people_bulk_import_data",
                    "error_message": message,
                    "error_type": "Validation Error",
                    "users": username,
                    "session_id": ui_session_id,
                    "tenant_name": tenant_name,
                    "comments": message,
                    "module_name": "People module",
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": message}

        # Decode blob
        blob_data = blob_data.split(",", 1)[1]
        blob_data += "=" * (-len(blob_data) % 4)
        file_stream = BytesIO(base64.b64decode(blob_data))

        # Read Excel into DataFrame
        uploaded_dataframe = pd.read_excel(file_stream, engine="openpyxl")
        uploaded_dataframe.columns = uploaded_dataframe.columns.str.replace(" ", "_").str.lower()

        # Query for comparison
        query = """
            SELECT
                C.tenant_name AS tenant_name,
                RA.agent_name AS agent_name,
                RC.customer_name AS customer_name,
                RC.rev_customer_id AS rev_customer_id,
                C.customer_bill_period_end_day,
                C.customer_bill_period_end_hour
            FROM
                revcustomer RC
            LEFT JOIN
                revagent RA ON RA.rev_agent_id = RC.agent_id
            LEFT JOIN
                customers C ON C.rev_customer_id = RC.id
            LIMIT 100 OFFSET 0;
        """
        result_df = database.execute_query(query, True)
        uploaded_columns = [col.strip().lower() for col in uploaded_dataframe.columns]
        query_columns = [col.strip().lower() for col in result_df.columns]

        # Column comparison
        if sorted(uploaded_columns) != sorted(query_columns):
            message = "Columns didn't match"
            logging.warning(message)
            if common_utils_database:
                error_data = {
                    "service_name": "people_bulk_import_data",
                    "error_message": message,
                    "error_type": "ColumnMismatch Error",
                    "users": username,
                    "session_id": ui_session_id,
                    "tenant_name": tenant_name,
                    "comments": f"Uploaded: {uploaded_columns}, Expected: {query_columns}",
                    "module_name": "People module",
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
            return {
                "flag": False,
                "message": message,
                "uploaded_columns": list(set(uploaded_columns) - set(query_columns)),
                "query_columns": list(set(query_columns) - set(uploaded_columns)),
            }

        # Split uploaded dataframe into separate dataframes for each table
        revcustomer_data = uploaded_dataframe[
            ["customer_name", "rev_customer_id", "agent_name"]
        ]
        revagent_data = uploaded_dataframe[["agent_name"]].drop_duplicates()
        customers_data = uploaded_dataframe[
            [
                "tenant_name",
                "customer_name",
                "customer_bill_period_end_day",
                "customer_bill_period_end_hour",
            ]
        ]

        # Perform the insertion
        if insert_flag == "append":
            database.insert(revcustomer_data, "revcustomer", if_exists="append", method="multi")
            database.insert(revagent_data, "revagent", if_exists="append", method="multi")
            database.insert(customers_data, "customers", if_exists="append", method="multi")
            logging.info("### Append operation completed successfully")
            response = {"flag": True, "message": "Append operation is done"} 

            # Audit logging
            if common_utils_database:
                audit_data_user_actions = {
                    "service_name": "people_bulk_import_data",
                    "created_by": username,
                    "status":  str(response['flag']) ,
                    "session_id": ui_session_id,
                    "tenant_name": tenant_name,
                    "module_name": "People module",
                    "comments": f"Bulk import data appended successfully for tenant: {tenant_name}",
                    "request_received_at": request_received_at,
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")

            return response

        # Invalid flag
        message = "Invalid insert_flag value"
        logging.error(message)
        if common_utils_database:
            error_data = {
                "service_name": "people_bulk_import_data",
                "error_message": f"{message} - insert_flag: {insert_flag}",
                "error_type": "InvalidInsertFlag",
                "users": username,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments": f"insert_flag = {insert_flag}",
                "module_name": "People module",
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": message}

    except Exception as e:
        logging.exception("### An error occurred in people_bulk_import_data")
        response = "Unable to import people bulk data"
        error_type = type(e).__name__
        if common_utils_database:
            error_data = {
                "service_name": "people_bulk_import_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "comments":f"unable to import people bulk data with insert_flag {insert_flag}",
                "module_name": "People module",
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": message}


def convert_timestamp(data):
    """
    Recursively converts pandas Timestamp objects in the input data into
    string format "MM-DD-YYYY HH:MM:SS".

    Args:
        data (any): The data to convert. Can be a single value, list, or dictionary
                    containing pandas Timestamp objects.

    Returns:
        any: The same structure as the input, but all pd.Timestamp values are
             converted to strings in the format "MM-DD-YYYY HH:MM:SS".
    """
    logging.debug(f"### Converting data: {data}")
    if isinstance(data, pd.Timestamp):
        logging.debug(f"### Converting pd.Timestamp: {data}")
        return data.strftime("%m-%d-%Y %H:%M:%S")
    elif isinstance(data, dict):
        logging.debug("### Processing dictionary in convert_timestamp")
        return {k: convert_timestamp(v) for k, v in data.items()}
    elif isinstance(data, list):
        logging.debug("### Processing list in convert_timestamp")
        return [convert_timestamp(v) for v in data]
    else:
        logging.debug(f"### No conversion needed for type: {type(data)}")
        return data


def get_user_acess_filters(username, database,tenant_name,role_name):
    """
    Fetches user-specific access filters based on the user's role and tenant association.

    Args:
        database (DB): An instance of the DB connection (for tenant-specific database).
        tenant_name (str): The name of the tenant the user belongs to.
        role_name (str): The role of the user (e.g., Admin, Super Admin, etc.)

    Returns:
        tuple:
            - customers (tuple or None): List of allowed customer names.
            - service_providers (tuple or None): List of allowed service providers.
            - billing_account_number (tuple or None): Allowed billing account numbers.
            - feature_codes (tuple or None): List of allowed feature codes.
            - customer_rate_plan_name (tuple or None): List of allowed rate plan names.
    """
    if role_name in ('Super Admin'):
        return None, None, None, None, None
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
        ["id", "db_name","parent_tenant_id"]
    )

    tenant_id = tenant_data["id"].to_list()[0]
    db_name = tenant_data["db_name"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    if tenant_id:
        tenant_id=int(tenant_id)

    database = DB(db_name, **db_config_withoutfilter)
    if parent_tenant_id and role_name in ('Admin'):
        try:
            # Sample query execution
            query = f'''SELECT customers, service_provider, customer_names, rate_plan_name, feature_codes, billing_account_number FROM tenant_based_partner_admin_filters WHERE tenant_id={tenant_id}
            '''
            df = common_utils_database.execute_query(query, True)

            # Initialize sets to accumulate unique values
            merged_customers = set()
            merged_service_provider = set()
            merged_rate_plan_name = set()
            merged_feature_codes = set()
            merged_billing_account_number = set()

            # Iterate over each row and collect values
            for index, row in df.iterrows():
                # Merge customers and customer_names
                for col in ['customers', 'customer_names']:
                    try:
                        values = json.loads(row[col]) if row[col] else []
                        merged_customers.update(values)
                    except Exception as e:
                        logging.error(f"### Error parsing {col}: {e}")


                # Process other columns
                for col, target in [
                    ('service_provider', merged_service_provider),
                    ('rate_plan_name', merged_rate_plan_name),
                    ('feature_codes', merged_feature_codes)
                ]:
                    try:
                        values = json.loads(row[col]) if row[col] else []
                        target.update(values)
                    except Exception as e:
                        logging.error(f"### Error parsing {col}: {e}")

                # Handle billing_account_number separately (not a list)
                billing_value = row['billing_account_number']
                if pd.notna(billing_value):
                    merged_billing_account_number.add(str(billing_value))

            # Final variables
            customers = tuple(sorted(merged_customers)) if merged_customers else None
            service_providers = tuple(sorted(merged_service_provider)) if merged_service_provider else None
            customer_rate_plan_name = tuple(sorted(merged_rate_plan_name)) if merged_rate_plan_name else None
            feature_codes = tuple(sorted(merged_feature_codes)) if merged_feature_codes else None
            billing_account_number = tuple(sorted(merged_billing_account_number)) if merged_billing_account_number else None
            return customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name
        except Exception as e:
            logging.exception(f"### Error while fetching filters of Partner for the tenant: {e}")
            return None, None, None, None, None
    query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{username}' and tenant_id={tenant_id}"
    filters = common_utils_database.execute_query(query, True)

    try:
        customer_group = filters["customer_group"].to_list()[0]

    except Exception as e:
        logging.error(f"Exception occurred while getting customer_group: {str(e)}")
        customer_group = None    

    customer_group_data = None
    customer_rate_plan_name = None
    billing_account_number = None
    feature_codes = None
    customer_names=None

    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )
        logging.info(f'### customer_group_data:{customer_group_data}')

        if not customer_group_data.empty:
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception(f"### Error extracting rate_plan_name:{e}")
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))
            except Exception as e:
                logging.exception(f"### Error extracting rate_plan_name: {e}")
                customer_names=None

            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None

            except Exception as e:
                logging.exception(f"### Error extracting billing_account_number: {e}")
                billing_account_number=None

            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception(f"### Error extracting feature_codes : {e}")
    if customer_names is None:
        try:
            customers = tuple(json.loads(filters["customers"].to_list()[0]))
        except Exception as e:
            logging.error(f"Error while loading customers from filters: {e}")
            customers = None
    else:
        customers=customer_names

    try:
        service_providers = tuple(json.loads(filters["service_provider"].to_list()[0]))
    except Exception as e:
        logging.error(f"Error while loading service providers from filters: {e}")
        service_providers = None
    return customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name



def people_list_view(data):
    """
    Fetches and returns customer-related data for different modules like NetSapiens, Bandwidth, and E911.

    Args:
        data (dict): A dictionary containing the following keys:
            - role_name (str): The role of the user (e.g., admin, viewer).
            - tenant_name (str): Name of the tenant.
            - module_name (str): Module selected (e.g., "NetSapiens Customers").
            - db_name (str): Name of the tenant's database.
            - col_sort (dict): Dictionary with column and sort order for sorting.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Success flag.
            - message (str): Response message.
            - data (list): List of records fetched from the database.
            - tenant_name (list): List of tenants associated.
            - headers_map (dict): Mapped column headers for UI.
            - pages (dict): Pagination details.
            - total_resellers (int): Number of resellers (optional based on module).
    """
    logging.info(f"### Starting people_list_view function with data: {data}")
    # Database Connection
    del db_config['customers']
    del db_config['service_providers']
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    role_name = data.get("role_name", "")
    username = data.get("username", "")
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    module_name = data.get("module_name", "")
    tenant_database = data.get("db_name", "")
    request_received_at = data.get("request_received_at", "")
    col_sort = data.get("col_sort", "")
    # Initialize data_list to hold customer data
    total_resellers = 0
    return_json_data = {}
    try:
        dbs = DB(tenant_database, **db_config)
        start_page = data.get("mod_pages", {}).get("start", 0)
        end_page = data.get("mod_pages", {}).get("end", 100)
        # limit = 100  # Set the limit to 100

        logging.info("### Received request data")
        logging.info(f"### Module name: {module_name}, Role name: {role_name}, Start page: {start_page}")

        if tenant_name == "Altaworx Test":
            tenant_id = 1  # Include the hardcoded ID
            # Fetch the ID from the database as well
        else:
            # Default case: fetch only from the database
            tenant_id = database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]

        # Query to get the list of tenants
        tenant_list = database.get_data("tenant", {"is_active": True, "parent_tenant_id": tenant_id,}, ["tenant_name"]
            )["tenant_name"].to_list()

        # Remove duplicates by converting to a set and back to a list
        tenant_list.append(tenant_name)
        tenant_list = list(set(tenant_list))

        # Sort the list alphabetically
        tenant_list.sort()
        # tenant_query = "SELECT DISTINCT tenant_name FROM tenant WHERE is_active=True"
        # tenant_list = database.execute_query(tenant_query, True)[
        #     "tenant_name"
        # ].to_list()
        logging.info("### Fetched tenant list")

        # # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(database,data)


        tenant_condition = f""" where tenant_id = {tenant_id} """




        # Handle 'NetSapiens Customers'
        if module_name == "NetSapiens Customers":

            customers = []
            service_providers = []
            billing_account_number=[]
            feature_codes=[]
            customer_rate_plan_name=[]
            customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name = get_user_acess_filters(username, dbs,tenant_name,role_name)
            logging.info(f"### customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name: {customers}, {service_providers}, {billing_account_number}, {feature_codes}, {customer_rate_plan_name}")

            if col_sort:
                # Extract the single key-value pair
                key, value = list(col_sort.items())[0]  # Get the first and only pair
                # Construct the ORDER BY clause
                order_condition = f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
            else:
                # If users is None or empty, we skip the WHERE clause entirely
                order_condition = f"ORDER BY modified_date DESC, customer_name DESC LIMIT 100 OFFSET {start_page}"





            if customers or billing_account_number or feature_codes or customer_rate_plan_name:



                query = """
                    SELECT
                        *
                    FROM vw_people_netsapiens_customers_list_view
                """
                filters = []

                # Add filters dynamically
                if customers:
                    if len(customers) == 1:
                        filters.append(f"customer_name = '{customers[0]}'")  # Add single quotes
                    else:
                        filters.append(f"customer_name IN {tuple(customers)}")  # Tuple already includes quotes

                # if service_providers:
                #     if len(service_providers) == 1:
                #         filters.append(f"service_provider = '{service_providers[0]}'")  # Add single quotes
                #     else:
                #         filters.append(f"service_provider IN {tuple(service_providers)}")  # Tuple already includes quotes

                # Append filters to the WHERE clause
                if filters:
                    query += f"""{tenant_condition} """ + " AND ".join(filters)

                # Add the order condition
                query += f" {order_condition}"

                count_query = """
                    SELECT COUNT(*) AS total_count
                        FROM vw_people_netsapiens_customers_list_view

                """
                if filters:
                    count_query += " WHERE " + " AND ".join(filters)
            else:
                query = f"""
                    SELECT
                        *
                    FROM vw_people_netsapiens_customers_list_view
                    {tenant_condition}
                    {order_condition}
                """
                count_query = """
                    SELECT COUNT(*) AS total_count
                        FROM vw_people_netsapiens_customers_list_view

                """


            # Execute the query using the existing execute_query function
            result = dbs.execute_query(query, True)
            total_count_result = dbs.execute_query(count_query, True)
            total_count = (
                total_count_result["total_count"].iloc[0]
                if not total_count_result.empty
                else 0
            )
            pages = {"start": start_page, "end": end_page, "total": int(total_count)}
            logging.info("### Query executed for NetSapiens Customers")

            # Get headers mapping
            headers_map = get_headers_mapping(
                tenant_database,
                ["NetSapiens Customers"],
                role_name,
                "",
                "",
                "",
                "",
                data,
                database,
            )

            if not result.empty:
                if 'netsapiens_customer_id' in result.columns:
                    result['netsapiens_customer_id'] = result['netsapiens_customer_id'].astype('Int64')
                df_dict = result.to_dict(orient="records")
                df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
                df_dict = serialize_data(df_dict)

                logging.info("### Data fetched for NetSapiens Customers")

                # Prepare final response
                return_json_data.update(
                    {
                        "flag": True,
                        "message": "Data fetched successfully",
                        "data": df_dict,
                        "tenant_name": tenant_list,
                        "headers_map": headers_map,
                        "pages": pages,
                    }
                )
                return return_json_data
            else:
                return_json_data.update(
                    {"flag": True, "data": [], "message": "No data found!","tenant_name": tenant_list,
                        "headers_map": headers_map}
                )
                logging.warning("### No data found for NetSapiens Customers")
                return return_json_data

        # Handle 'Bandwidth customers'
        elif module_name == "Bandwidth Customers":


            customers = []
            service_providers = []
            billing_account_number=[]
            feature_codes=[]
            customer_rate_plan_name=[]
            customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name = get_user_acess_filters(username, dbs,tenant_name,role_name)

            if col_sort:
                # Extract the single key-value pair
                key, value = list(col_sort.items())[0]  # Get the first and only pair
                # Construct the ORDER BY clause
                order_condition = (
                    f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
                )
            else:
                # If users is None or empty, we skip the WHERE clause entirely
                order_condition = f"ORDER BY modified_date DESC, customer_name ASC LIMIT 100 OFFSET {start_page}"



            if customers or billing_account_number or feature_codes or customer_rate_plan_name:
                filters = []


                query = """
                    SELECT
                        *
                    FROM vw_people_bandwidth_customers
                """

                # Add filters dynamically
                if customers:
                    if len(customers) == 1:
                        filters.append(f"customer_name = '{customers[0]}'")  # Add single quotes
                    else:
                        filters.append(f"customer_name IN {tuple(customers)}")  # Tuple already includes quotes

                # if service_providers:
                #     if len(service_providers) == 1:
                #         filters.append(f"service_provider = '{service_providers[0]}'")  # Add single quotes
                #     else:
                #         filters.append(f"service_provider IN {tuple(service_providers)}")  # Tuple already includes quotes

                # Append filters to the WHERE clause
                if filters:
                    query += f"""{tenant_condition} """ + " AND ".join(filters)

                # Add the order condition
                query += f" {order_condition}"

                count_query = """
                    SELECT COUNT(*) AS total_count
                        FROM vw_people_bandwidth_customers

                """

                if filters:
                    count_query += " WHERE " + " AND ".join(filters)



            else:
                query = f"""
                    SELECT
                        *
                    FROM vw_people_bandwidth_customers
                    {tenant_condition}
                    {order_condition}
                    """

                count_query = """
                    SELECT COUNT(*) AS total_count
                        FROM vw_people_bandwidth_customers

                """

            # Execute the query using the existing execute_query function
            result = dbs.execute_query(query, True)

            total_count_result = dbs.execute_query(count_query, True)
            total_count = (
                total_count_result["total_count"].iloc[0]
                if not total_count_result.empty
                else 0
            )
            logging.info("### Query executed for Bandwidth Customers")
            headers_map = get_headers_mapping(
                tenant_database,
                ["Bandwidth Customers"],
                role_name,
                "",
                "",
                "",
                "",
                data,
                database,
            )

            # Check if result is empty
            if result.empty:
                return_json_data.update(
                    {
                        "flag": True,
                        "data": [],
                        "message": "No data found for Bandwidth customers!",
                        "tenant_name": tenant_list,
                        "headers_map": headers_map,
                        "total_resellers": total_resellers,
                    }
                )
                logging.warning("### No data found for Bandwidth customers")
                return return_json_data

            # Process and format the data
            df_dict = result.to_dict(orient="records")
            # total = len(df_dict)
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            df_dict = serialize_data(df_dict)
            pages = {"start": start_page, "end": end_page, "total": int(total_count)}

            logging.info("### Returning data response")
            return_json_data.update(
                {
                    "flag": True,
                    "message": "Data fetched successfully",
                    "data": df_dict,
                    "tenant_name": tenant_list,
                    "headers_map": headers_map,
                    "pages": pages,
                    "total_resellers": total_resellers,
                }
            )
            return return_json_data
        elif module_name == "E911 Customers":
            customers = []
            service_providers = []
            billing_account_number=[]
            feature_codes=[]
            customer_rate_plan_name=[]
            customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name = get_user_acess_filters(username, dbs,tenant_name,role_name)
            logging.info(f"### people list view user access filters: {customers}, {service_providers}, {billing_account_number}, {feature_codes}, {customer_rate_plan_name}")

            if col_sort:
                # Extract the single key-value pair
                key, value = list(col_sort.items())[0]  # Get the first and only pair
                # Construct the ORDER BY clause
                order_condition = (
                    f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
                )
            else:
                # If users is None or empty, we skip the WHERE clause entirely
                order_condition = (
                    f"ORDER BY modified_date DESC LIMIT 100 OFFSET {start_page}"
                )

            # filters_list = []
            # if customers:
            #     if len(customers) == 1:
            #         filters_list.append(f"customer_name = '{customers[0]}'")  # Add single quotes
            #     else:
            #         filters_list.append(f"customer_name IN {tuple(customers)}")  # Tuple already includes quotes

            user_query = f"""
                SELECT CONCAT(first_name, ' ', last_name) AS full_name
                FROM users
                WHERE username = '{username}'
            """



            # Execute query safely
            user_result = database.execute_query(user_query, True)

            if user_result is not None and not user_result.empty:
                users = user_result["full_name"].tolist()


            # Construct the WHERE clause conditionally based on 'users'
            if customers:
                users_condition = (
                    f"""AND created_by IN ({','.join(f"'{user}'" for user in users)}) """
                    f"""OR modified_by IN ({','.join(f"'{user}'" for user in users)}) """
                    f"""OR deleted_by IN ({','.join(f"'{user}'" for user in users)})"""
                )
            else:
                users_condition = ""


            if service_providers or customers or billing_account_number or feature_codes or customer_rate_plan_name:


                query = f"""
                    SELECT
                    id,
                    account_name,
                    account_id,
                    created_by,
                    created_date,
                    modified_by,
                    modified_date,
                    deleted_by,
                    deleted_date,
                    is_active,
                    is_deleted
                    FROM e911customers
                    WHERE is_active = 'true' AND is_deleted = 'false'
                    {users_condition}
                    {order_condition}
                """
                count_query = f"""
                    SELECT COUNT(*) AS total_count
                        FROM e911customers
                WHERE is_active = 'true' AND is_deleted = 'false'
                {users_condition}

                """
            else:
                query = f"""
                SELECT
                id,
                account_name,
                account_id,
                created_by,
                created_date,
                modified_by,
                modified_date,
                deleted_by,
                deleted_date,
                is_active,
                is_deleted
                FROM e911customers
                WHERE is_active = 'true' AND is_deleted = 'false'
                {order_condition}
                """
                count_query = """
                    SELECT COUNT(*) AS total_count
                        FROM e911customers
                WHERE is_active = 'true' AND is_deleted = 'false'

                """

            # Execute the query using the existing execute_query function
            result = dbs.execute_query(query, True)


            total_count_result = dbs.execute_query(count_query, True)
            total_count = (
                total_count_result["total_count"].iloc[0]
                if not total_count_result.empty
                else 0
            )
            logging.info("### Query executed for e911customers")
            headers_map = get_headers_mapping(
                tenant_database,
                ["E911 Customers"],
                role_name,
                "",
                "",
                "",
                "",
                data,
                database,
            )

            # Check if result is empty
            if result.empty:
                return_json_data.update(
                    {
                        "flag": True,
                        "data": [],
                        "message": "No data found for E911 Customers!",
                        "tenant_name": tenant_list,
                        "headers_map": headers_map,
                        "total_resellers": total_resellers,
                    }
                )
                logging.info("### No data found for E911 Customers")
                return return_json_data

            # Process and format the data
            df_dict = result.to_dict(orient="records")
            # total = len(df_dict)
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            df_dict = serialize_data(df_dict)
            pages = {"start": start_page, "end": end_page, "total": int(total_count)}

            logging.info("### Returning data response")
            return_json_data.update(
                {
                    "flag": True,
                    "message": "Data fetched successfully",
                    "data": df_dict,
                    "tenant_name": tenant_list,
                    "headers_map": headers_map,
                    "pages": pages,
                    "total_resellers": total_resellers,
                }
            )
            try:
                audit_data_user_actions = {
                    "service_name": "people_list_view",
                    "created_by": username,
                    "status": str(return_json_data["flag"]),
                    "session_id": ui_session_id,
                    "tenant_name": tenant_name,
                    "module_name": "People module",
                    "comments": f"Successfully fetched data for module: {module_name}",
                    "request_received_at": request_received_at,
                }

                database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### Exception is {e}")
            return return_json_data

    except Exception as e:
        logging.exception("### An error occurred in people_list_view")
        response = "Unable to save the data"
        

        error_type = str(type(e).__name__)
        # Error Management
        error_data = {
            "service_name": "people_list_view",
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Error while fetching data for module: {module_name}",
            "module_name": "People module",
        }
        database.log_error_to_db(error_data, "error_log_table")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database, [module_name], role_name, "", "", "", "", data, database
        )
        response={
                        "flag": True,
                        "data": [],
                        "message": "No data found for E911 Customers!",
                        "tenant_name": [],
                        "headers_map": headers_map,
                        "total_resellers": [],
                    }
        return response



# def convert_timestamp_data(df_dict, tenant_time_zone):
#     """Convert timestamp columns in the provided dictionary list to the tenant's timezone."""
#     # Create a timezone object
#     target_timezone = timezone(tenant_time_zone)

#     # List of timestamp columns to convert
#     timestamp_columns = [
#         "created_date",
#         "modified_date",
#         "deleted_date",
#     ]  # Adjust as needed based on your data

#     # Convert specified timestamp columns to the tenant's timezone
#     for record in df_dict:
#         for col in timestamp_columns:
#             if col in record and record[col] is not None:
#                 # Convert to datetime if it's not already
#                 timestamp = pd.to_datetime(record[col], errors="coerce")
#                 if timestamp.tz is None:
#                     # If the timestamp is naive, localize it to UTC first
#                     timestamp = timestamp.tz_localize("UTC")
#                 # Now convert to the target timezone
#                 record[col] = timestamp.tz_convert(target_timezone).strftime(
#                     "%m-%d-%Y %H:%M:%S"
#                 )  # Ensure it's a string
#     return df_dict


# def serialize_data(data):
#     """Recursively convert pandas objects in the data structure to serializable types."""
#     if isinstance(data, list):
#         return [serialize_data(item) for item in data]
#     elif isinstance(data, dict):
#         return {key: serialize_data(value) for key, value in data.items()}
#     elif isinstance(data, pd.Timestamp):
#         return data.strftime("%m-%d-%Y %H:%M:%S")  # Convert to string
#     else:
#         return data  # Return as is if not a pandas object

def get_customers_list_view_data(data):
    """
    Fetches a paginated list of active customers from the tenant database with applied user-level filters.

    Args:
        data (dict): Dictionary containing request data including:
            - role_name (str): The role of the user.
            - tenant_name (str): Name of the tenant.
            - module_name (str): Name of the requesting module.
            - db_name (str): Database name to query from.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Success status.
            - message (str): Response message.
            - data (list): List of customer records.
            - tenant_name (dict): Parent tenant info.
            - sub_tenant (dict): Subtenant details.
            - headers_map (dict): Header mapping for the frontend.
            - pages (dict): Pagination metadata with total count.
    """
    logging.info(f"### Starting get_customers_list_view_data function with data: {data}")
    # Database Connection
    try:
        if db_config and 'customers' in db_config:
            db_config.pop('customers')
        if db_config and 'service_providers' in db_config:
            db_config.pop('service_providers')
    except Exception as e:
        logging.exception(f"### Error while removing keys from db_config : {e}")
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    role_name = data.get("role_name", "")
    username = data.get("username", "")
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    module_name = data.get("module_name", "")
    tenant_database = data.get("db_name", "")
    request_received_at = data.get("request_received_at", "")
    col_sort = data.get("col_sort", "")
    # Initialize data_list to hold customer data
    # total_resellers = 0
    return_json_data = {}
    try:
        dbs = DB(tenant_database, **db_config_withoutfilter)
        start_page = data.get("mod_pages", {}).get("start", 0)
        end_page = data.get("mod_pages", {}).get("end", 100)
        # limit = 100  # Set the limit to 100
        customers=None

        logging.info("### Received request data")
        logging.info(f"Module name: {module_name}, Role name: {role_name}, Start page: {start_page}")

        if tenant_name == "Altaworx Test":
            tenant_name ="Altaworx"
            tenant_id = 1  # Include the hardcoded ID
            # Fetch the ID from the database as well
        else:
            # Default case: fetch only from the database
            tenant_id = database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
        # # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(database,data)
        customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name = get_user_acess_filters(username, dbs,tenant_name,role_name)
        logging.info(f"### customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name {customers} {service_providers} {billing_account_number} {feature_codes} {customer_rate_plan_name}")


        if col_sort:
            # Extract the single key-value pair
            key, value = list(col_sort.items())[0]  # Get the first and only pair
            # Construct the ORDER BY clause
            order_condition = f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
        else:
            # If users is None or empty, we skip the WHERE clause entirely
            order_condition = f"ORDER BY id DESC LIMIT 100 OFFSET {start_page}"
        if customers:
            query = f"""
                SELECT
                id,
                    customer_name,
                    netsapiens_type,
                    inactivity_start,
                    inactivity_end,
                    address1,
                    address2,
                    city,
                    postal_code,
                    county_parish_borough,
                    state,
                    country,
                    customer_bill_period_end_day,
                    customer_bill_period_end_hour,
                    apt_suite,
                    tenant_name
                    FROM public.customers
                    WHERE is_active = TRUE 
                    AND tenant_id = {tenant_id} 

            """
            filters = []

            # Add filters dynamically
            if customers:
                customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{username}'
                '''
                customers_df=dbs.execute_query(customers_query,True)
                if not customers_df.empty:
                    existing_customers=customers_df['customer_name'].to_list()
                    if existing_customers:
                        existing_customers_tuple = tuple(existing_customers)
                        # Concatenate the tuple customers with the new tuple (existing_customers_tuple)
                        customers = customers + existing_customers_tuple  # Concatenating two tuples
                if len(customers) == 1:
                    filters.append(f"customer_name = '{customers[0]}'")  # Add single quotes
                else:
                    filters.append(f"customer_name IN {tuple(customers)}")  # Tuple already includes quotes
            # Append filters to the WHERE clause
            if filters:
                query += " AND " + " AND ".join(filters)


            # Add the order condition
            query += f" {order_condition}"

            count_query = f"""
                SELECT COUNT(*)  as total_count
                FROM public.customers
                WHERE is_active = TRUE 
                and tenant_id = {tenant_id}
            """
            if filters:
                count_query += " AND " + " AND ".join(filters)
        else:
            query = f"""
                SELECT
                id,
                    customer_name,
                    netsapiens_type,
                    inactivity_start,
                    inactivity_end,
                    address1,
                    address2,
                    city,
                    postal_code,
                    county_parish_borough,
                    state,
                    country,
                    customer_bill_period_end_day,
                    customer_bill_period_end_hour,
                    apt_suite,
                    tenant_name
                    FROM public.customers
                    WHERE is_active = TRUE
                    and tenant_id = {tenant_id}
                    {order_condition}
            """
            count_query = f"""
                SELECT COUNT(*) as total_count
                FROM public.customers
                WHERE is_active = TRUE
                and tenant_id = {tenant_id}
            """


        # Execute the query using the existing execute_query function
        result = dbs.execute_query(query, True)
        total_count_result = dbs.execute_query(count_query, True)
        total_count = (
            total_count_result["total_count"].iloc[0]
            if not total_count_result.empty
            else 0
        )
        pages = {"start": start_page, "end": end_page, "total": int(total_count)}
        logging.info("### Query executed for  Customers")

        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database,
            ["Customers"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            database,
        )
        # First, get the tenant record by name
        tenant_row = database.get_data(
            "tenant", {"tenant_name": tenant_name, "is_active": True},
            ["id", "parent_tenant_id"]
        )

        tenant_id = tenant_row["id"].to_list()[0] if not tenant_row.empty else None
        parent_tenant_id = tenant_row["parent_tenant_id"].to_list()[0] if not tenant_row.empty else None

        if parent_tenant_id:  # It's a subtenant
            # Get parent tenant details
            parent_row = database.get_data("tenant", {"id": parent_tenant_id, "is_active": True}, ["id", "tenant_name"])
            parent_tenant = {parent_row["tenant_name"].to_list()[0]: parent_tenant_id}

            # Get sibling subtenants
            sub_tenants_data = database.get_data(
                "tenant", {"parent_tenant_id": parent_tenant_id, "is_active": True},
                ["id", "tenant_name"]
            )
            sub_tenant = {
                name: _id
                for name, _id in zip(sub_tenants_data["tenant_name"], sub_tenants_data["id"])
            }

        else:  # It's a parent tenant
            parent_tenant = {tenant_name: tenant_id}
            sub_tenants_data = database.get_data(
                "tenant", {"parent_tenant_id": tenant_id, "is_active": True},
                ["id", "tenant_name"]
            )
            sub_tenants = {
                name: _id
                for name, _id in zip(sub_tenants_data["tenant_name"], sub_tenants_data["id"])
            }
            sub_tenant=dict(sorted(sub_tenants.items()))
        # Final result
        if not result.empty:
            df_dict = result.to_dict(orient="records")
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            df_dict = serialize_data(df_dict)

            logging.info("### Data fetched for Customers")

            # Prepare final response
            return_json_data.update(
                {
                    "flag": True,
                    "message": "Data fetched successfully",
                    "data": df_dict,
                    "sub_tenant": sub_tenant,
                    "headers_map": headers_map,
                    "pages": pages,
                    "tenant_name":tenant_name
                }
            )
            #return return_json_data
        else:
            return_json_data.update(
                {"flag": True, "data": [], "message": "No data found!",
                    "headers_map": headers_map}
            )
            logging.warning("### No data found for  Customers")
            #return return_json_data
        logging.info("### Returning data response")
        return_json_data.update(
            {
                "flag": True,
                "message": "Data fetched successfully",
                "data": df_dict,
                "tenant_name":parent_tenant,
                    "sub_tenant": sub_tenant,
                "headers_map": headers_map,
                "pages": pages,
            }
        )
        try:
            audit_data_user_actions = {
                "service_name": "get_customers_list_view_data",
                "created_by": username,
                "status": str(return_json_data["flag"]),
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "module_name": "People module",
                "comments": f"Successfully retrieved customer list view for module: {module_name}",
                "request_received_at": request_received_at,
            }

            database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        return return_json_data

    except Exception as e:
        logging.exception("### An error occurred in people_list_view")
        message = f"Failed to fetch customer list data for module: {module_name}"
        error_type = str(type(e).__name__)
        # Error Management
        error_data = {
            "service_name": "get_customers_list_view_data",
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "People module",
        }
        database.log_error_to_db(error_data, "error_log_table")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database, ["Customers"], role_name, "", "", "", "", data, database
        )
        response={
                        "flag": True,
                        "data": [],
                        "message": "No data found for Customers!",
                        "tenant_name": [],
                        "headers_map": headers_map,
                    }
        return response


def create_customer(data):
    """
    Processes customer rate plan data by creating or updating rate plans in the database.
    Validates input, handles errors, and logs actions.

    Parameters:
        data (dict): A dictionary containing the rate plan data to process, including:
            - 'Partner' (str): The partner name.
            - 'session_id' (str): The session ID associated with the request.
            - 'username' (str): The username of the requester.
            - 'rate_plan_data' (dict): The rate plan data containing the fields to update.
            - 'action' (str): Action to perform, either 'create' or 'update'.
            - 'table_name' (str): The database table for storing rate plans.
            - 'db_name' (str): The tenant database name.

    Returns:
        dict: A response dictionary with:
            - 'flag' (bool): Indicates success (True) or failure (False).
            - 'message' (str): Describes the result of the operation.
    """
    logging.info(f"### starting create_customer function with data: {data}")
    try:
        logging.info("### Processing customer data")

        request_received_at = data.get("request_received_at", "")
        username = data.get("username", "")
        session_id= data.get("sessionID", "")
        Partner = data.get("Partner", "")

        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        new_data=data.get('new_data',{})
        tenant_name = new_data.get("tenant_name", "")
        action=data.get("action", "")


        if action=='edit':
            cleaned_data = {k: v for k, v in new_data.items() if v != ''}
            updated_id=cleaned_data.pop("id", None)
            if updated_id:
                database.update_dict('customers', cleaned_data, {'id': updated_id})
        else:
            tenant_id=common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id"]).iloc[0]["id"]
            if tenant_id:
                new_data["tenant_id"]=int(tenant_id)
            new_data["created_by"]=data.get("username", "")
            cleaned_data = {k: v for k, v in new_data.items() if v != ''}
            insert_id = database.insert_data(cleaned_data, "customers")
            logging.info(f"### Rate plan created successfully with ID: {insert_id}")
            response ={
            "flag": True,
            "message": "Customers created successfully",
            "status_code": 200,
        }
        try:
            audit_data_user_actions = {
                "service_name": "create_customer",
                "created_by": username,
                "status": str(response['flag']),
                "session_id": session_id,
                "tenant_name": Partner,
                "module_name": "People module",
                "comments": f"Successfully created customer for user: {username}",
                "request_received_at": request_received_at,
            }

            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        return {
            "flag": True,
            "message": "Customers created successfully",
            "status_code": 200,
        }

    except Exception as e:
        logging.error(f"### Exception in create_customer: {e}")
        response = "Failed to create or update customer in People module"

        common_utils_database.log_error_to_db(
            {
                "service_name": "create_customer",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f"Error processing customers for user {username}",
                "module_name": "People module",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {
            "flag": False,
            "message": f"Error processing customers : {e}",
            "status_code": 500,
        }


def create_billing_platform_customer(data):
    """
    Processes customer rate plan data by creating or updating rate plans in the database.
    Validates input, handles errors, and logs actions.

    Parameters:
        data (dict): A dictionary containing the rate plan data to process, including:
            - 'Partner' (str): The partner name.
            - 'session_id' (str): The session ID associated with the request.
            - 'username' (str): The username of the requester.
            - 'rate_plan_data' (dict): The rate plan data containing the fields to update.
            - 'action' (str): Action to perform, either 'create' or 'update'.
            - 'table_name' (str): The database table for storing rate plans.
            - 'db_name' (str): The tenant database name.

    Returns:
        dict: A response dictionary with:
            - 'flag' (bool): Indicates success (True) or failure (False).
            - 'message' (str): Describes the result of the operation.
    """
    logging.info(f"### Starting create_billing_platform_customer function with data: {data}")
    try:
        request_received_at = data.get("request_received_at", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        Partner = data.get("Partner", "")
        logging.info(f"### Processing customer data: {data}")

        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        # try:
        # # Initialize database connection
        #     killbill_database = DB("billing_platform", **db_config)
        # except Exception as e:
        #     logging.info(f"### Database connection failed: {e}")
        #     return {"flag": False, "message": "Database connection error"}

        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        new_data = data.get('new_data', {})
        tenant_name = new_data.get("tenant_name", "")
        action = data.get("action", "")

        if action == 'edit':
            cleaned_data = {k: v for k, v in new_data.items() if v != ''}
            updated_id = cleaned_data.pop("id", None)
            if updated_id:
                database.update_dict('customers', cleaned_data, {'id': updated_id})
        else:
            tenant_id=common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id"]).iloc[0]["id"]
            if tenant_id:
                new_data["tenant_id"] = int(tenant_id)
            new_data["created_by"] = data.get("username", "")
            cleaned_data = {k: v for k, v in new_data.items() if v != ''}
            
            # Insert customer data
            insert_id = database.insert_data(cleaned_data, "customers")
            logging.info(f"### Customer created successfully with ID: {insert_id}")
            
            """
            # Prepare and insert customer profile
            profile_data = {
                "customer_name": cleaned_data.get("customer_name", ""),
                "billing_platform_customer_id": insert_id,
                "created_by": data.get("username", ""),
                "is_active": True,
                "is_deleted": False
            }
            # Insert into customer_profiles
            p = killbill_database.insert_data(profile_data, "customer_profiles")
            
            logging.info(f"Customer profile created successfully with ID: {p}")
            logging.info(f"Customer profile created successfully for customer ID: {insert_id}")

            # Update the customers table with the billing_platform_customer_id
            database.update_dict('customers', {'billing_platform_customer_id': p}, {'id': insert_id})
            logging.info(f"Updated customers table with billing_platform_customer_id: {p} for customer ID: {insert_id}")
            """
        
        response = {
            "flag": True,
            "message": "Customer processed successfully",
            "status_code": 200,
        }

        # Audit logging
        try:
            audit_data_user_actions = {
                "service_name": "create_billing_platform_customer",
                "created_by": username ,
                "status": str(response['flag']),
                "session_id": sessionID ,
                "tenant_name": Partner ,
                "module_name": "People Module",
               "comments": f"Created new customer record with data: {json.dumps(serialize_data(cleaned_data))}",
                "request_received_at": request_received_at ,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")

        return response 
    except Exception as e:
        logging.exception("### Error processing customer:")
        message = f"Exception in create_billing_platform_customer for user {username}"
        common_utils_database.log_error_to_db(
            {
                "service_name": "create_billing_platform_customer",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username ,
                "session_id": sessionID ,
                "tenant_name": Partner ,
                "comments": message ,
                "module_name": "People Module",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {
            "flag": False,
            "message": f"Error processing customer: {e}",
            "status_code": 500,
        }


def get_billing_platform_customer_list_view_data(data):
    """
    Fetches and returns a list view of Billing Platform Customers along with pagination, 
    tenant details, dropdowns, and headers, based on user role and permissions.

    Args:
        data (dict): Input dictionary containing:
            - role_name (str): User role
            - tenant_name (str): Tenant name
            - module_name (str): Module being accessed
            - db_name (str): Target database name

    Returns:
        dict: A JSON-style dictionary with the following keys:
            - flag (bool): Success or failure flag
            - message (str): Response message
            - data (list): List of customer records
            - tenant_name (dict): Parent tenant info
            - sub_tenant (dict): Sub-tenant mapping
            - headers_map (dict): Column header mappings
            - pages (dict): Pagination details
            - account_type (list): Account type options
            - btn_provider (list): Dropdown of service providers
            - sales_person (list): Dropdown of sales users
            - parent_accounts (list): Parent account number + name options
            - state (list): List of states from service locations
    """
    logging.info(f"### Starting people_list_view function request data is {data}")
    # Database Connection
    try:
        if db_config and 'customers' in db_config:
            db_config.pop('customers')
        if db_config and 'service_providers' in db_config:
            db_config.pop('service_providers')
    except Exception as e:
        logging.exception(f"### Error while removing keys from db_config : {e}")
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config_withoutfilter)
    role_name = data.get("role_name", "")
    username = data.get("username", "")
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    module_name = data.get("module_name", "")
    tenant_database = data.get("db_name", "")
    request_received_at = data.get("request_received_at", "")
    col_sort = data.get("col_sort", "")
    # Initialize data_list to hold customer data
    # total_resellers = 0
    return_json_data = {}
    try:
        dbs = DB(tenant_database, **db_config_withoutfilter)
        start_page = data.get("mod_pages", {}).get("start", 0)
        end_page = data.get("mod_pages", {}).get("end", 100)
        # limit = 100  # Set the limit to 100
        customers=None

        logging.info("### Received request data")
        logging.info(f"### Module name: {module_name}, Role name: {role_name}, Start page: {start_page}")

        if tenant_name == "Altaworx Test":
            tenant_name ="Altaworx"
            tenant_id = 1  # Include the hardcoded ID
            # Fetch the ID from the database as well
        else:
            # Default case: fetch only from the database
            tenant_id = database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
        # # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(database,data)
        customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name = get_user_acess_filters(username, dbs,tenant_name,role_name)
        logging.info(f"### customers: {customers}, service_providers: {service_providers}, billing_account_number: {billing_account_number}, feature_codes: {feature_codes}, customer_rate_plan_name: {customer_rate_plan_name}")

        if col_sort:
            # Extract the single key-value pair
            key, value = list(col_sort.items())[0]  # Get the first and only pair
            # Construct the ORDER BY clause
            order_condition = f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
        else:
            # If users is None or empty, we skip the WHERE clause entirely
            order_condition = f"ORDER BY id DESC LIMIT 100 OFFSET {start_page}"
        if customers:
            query = f"""
                SELECT
                id,
                    customer_name,
                    netsapiens_type,
                    inactivity_start,
                    inactivity_end,
                    address1,
                    address2,
                    city,
                    postal_code,
                    county_parish_borough,
                    state,
                    country,
                    customer_bill_period_end_day,
                    customer_bill_period_end_hour,
                    apt_suite,
                    tenant_name,
                    user_type,
                    bp_account_number as account_number,
                    bp_account_type as account_type,
                    bp_billing_cycle_start_date
                    FROM public.customers
                    WHERE is_active = TRUE 
                    AND tenant_id = {tenant_id}

            """
            filters = []

            # Add filters dynamically
            if customers:
                customers_query=f'''select customer_name from billing_platform_customers where tenant_id={tenant_id} and is_active=True and created_by='{username}'
                '''
                customers_df=dbs.execute_query(customers_query,True)
                if not customers_df.empty:
                    existing_customers=customers_df['customer_name'].to_list()
                    if existing_customers:
                        existing_customers_tuple = tuple(existing_customers)
                        # Concatenate the tuple customers with the new tuple (existing_customers_tuple)
                        customers = customers + existing_customers_tuple  # Concatenating two tuples
                if len(customers) == 1:
                    filters.append(f"customer_name = '{customers[0]}'")  # Add single quotes
                else:
                    filters.append(f"customer_name IN {tuple(customers)}")  # Tuple already includes quotes
            # Append filters to the WHERE clause
            if filters:
                query += " AND " + " AND ".join(filters)


            # Add the order condition
            query += f" {order_condition}"

            count_query = f"""
                SELECT COUNT(*)  as total_count
                FROM public.customers
                WHERE is_active = TRUE 
                and tenant_id = {tenant_id}
            """
            if filters:
                count_query += " AND " + " AND ".join(filters)
        else:
            query = f"""
                SELECT
                id,
                    customer_name,
                    netsapiens_type,
                    inactivity_start,
                    inactivity_end,
                    address1,
                    address2,
                    city,
                    postal_code,
                    county_parish_borough,
                    state,
                    country,
                    customer_bill_period_end_day,
                    customer_bill_period_end_hour,
                    apt_suite,
                    tenant_name, 
                    user_type,
                    bp_account_number as account_number,
                    bp_account_type as account_type,
                    bp_billing_cycle_start_date
                    FROM public.customers
                    WHERE is_active = TRUE 
                    and tenant_id = {tenant_id}
                    {order_condition}
            """
            count_query = f"""
                SELECT COUNT(*) as total_count
                FROM public.customers
                WHERE is_active = TRUE  
                and tenant_id = {tenant_id}
            """


        # Execute the query using the existing execute_query function
        result = dbs.execute_query(query, True)
        total_count_result = dbs.execute_query(count_query, True)
        total_count = (
            total_count_result["total_count"].iloc[0]
            if not total_count_result.empty
            else 0
        )
        pages = {"start": start_page, "end": end_page, "total": int(total_count)}
        logging.info("### Query executed for  Billing Platform Customers")

        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database,
            ["Billing Platform Customers"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            database,
        )
        # First, get the tenant record by name
        tenant_row = database.get_data(
            "tenant", {"tenant_name": tenant_name, "is_active": True},
            ["id", "parent_tenant_id"]
        )

        tenant_id = tenant_row["id"].to_list()[0] if not tenant_row.empty else None
        parent_tenant_id = tenant_row["parent_tenant_id"].to_list()[0] if not tenant_row.empty else None

        if parent_tenant_id:  # It's a subtenant
            # Get parent tenant details
            parent_row = database.get_data("tenant", {"id": parent_tenant_id, "is_active": True}, ["id", "tenant_name"])
            parent_tenant = {parent_row["tenant_name"].to_list()[0]: parent_tenant_id}

            # Get sibling subtenants
            sub_tenants_data = database.get_data(
                "tenant", {"parent_tenant_id": parent_tenant_id, "is_active": True},
                ["id", "tenant_name"]
            )
            sub_tenant = {
                name: _id
                for name, _id in zip(sub_tenants_data["tenant_name"], sub_tenants_data["id"])
            }

        else:  # It's a parent tenant
            parent_tenant = {tenant_name: tenant_id}
            sub_tenants_data = database.get_data(
                "tenant", {"parent_tenant_id": tenant_id, "is_active": True},
                ["id", "tenant_name"]
            )
            sub_tenants = {
                name: _id
                for name, _id in zip(sub_tenants_data["tenant_name"], sub_tenants_data["id"])
            }
            sub_tenant=dict(sorted(sub_tenants.items()))
        
        # Final result
        if not result.empty:
            df_dict = result.to_dict(orient="records")
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            df_dict = serialize_data(df_dict)
            # Dropdown: predefined account types
            account_type=['Standard','Parent','Child']

            # Dropdown: fetch active service providers linked with billing periods
            query = """
                SELECT DISTINCT sp.id as id, sp.display_name as display_name
                FROM public.serviceprovider sp
                ORDER BY sp.id DESC
            """
            service_provider_query = dbs.execute_query(query, flag=True)
            provider_list = sorted(set(
                name for name in service_provider_query['display_name'] if name is not None
            ))

            # Dropdown: list of user full names
            users_query=database.get_data(table_name="users",columns=["first_name","last_name"])
            users_list = sorted(set(
                users_query.apply(lambda row: f"{row['first_name']} {row['last_name']}", axis=1).tolist()
            ))
            
            # Dropdown: parent account numbers
            account_numbers=killbill_database.get_data('customer_profiles',{"account_type":'Parent'},["account_number", "customer_name"])
            #account_numbers_list = sorted(account_numbers["account_number"].to_list())
            formatted_list = sorted([
            f"{row['account_number']} - {row['customer_name']}"
            for _, row in account_numbers.iterrows()
        ])


            # Dropdown: service location states
            service_location_list= killbill_database.get_data(table_name="service_locations",condition=None,columns=["states"])["states"].to_list()
            service_locations=sorted(list(set(service_location_list)))

            logging.info("### Data fetched for Billing Platform Customers")

            # Prepare final response
            return_json_data.update(
                {
                    "flag": True,
                    "message": "Data fetched successfully",
                    "data": df_dict,
                    "sub_tenant": sub_tenant,
                    "headers_map": headers_map,
                    "pages": pages,"tenant_name":tenant_name,'account_type':account_type,
                'btn_provider':provider_list,
                'sales_person': users_list,
                'parent_accounts': formatted_list,
                'state': service_locations,
                }
            )
            #return return_json_data
        else:
            return_json_data.update(
                {"flag": True, "data": [], "message": "No data found!",
                    "headers_map": headers_map}
            )
            logging.warning("### No data found for  Customers")
            #return return_json_data
        logging.info("### Returning data response")
        return_json_data.update(
            {
                "flag": True,
                "message": "Data fetched successfully",
                "data": df_dict,
                "tenant_name":parent_tenant,
                    "sub_tenant": sub_tenant,
                "headers_map": headers_map,
                "pages": pages,
            }
        )
        try:
            audit_data_user_actions = {
                "service_name": "get_billing_platform_customer_list_view_data",
                "created_by": username,
                "status": str(return_json_data["flag"]),
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "module_name": "People module",
                "comments": f"Fetched Billing Platform Customers list view data for module: {module_name}",
                "request_received_at": request_received_at,
            }

            database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception while updating audit and exception is {e}")
        return return_json_data

    except Exception as e:
        logging.exception("### An error occurred in people_list_view")
        response = "Unable Fetch the Billing Platform Customers data"
        # Error Management
        error_data = {
            "service_name": "get_billing_platform_customers_list_view_data",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Failed to fetch Billing Platform Customers list view data for module: {module_name}",
            "module_name": "People module",
        }
        database.log_error_to_db(error_data, "error_log_table")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database, ["Billing Platform Customers"], role_name, "", "", "", "", data, database
        )
        response={
                        "flag": True,
                        "data": [],
                        "message": "No data found for Billing Platform Customers!",
                        "tenant_name": [],
                        "headers_map": headers_map,
                    }
        return response

