"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 :
Created Date: 05-09-2025
"""

# Importing the necessary Libraries
import os
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import fetch_tenant_timezone , convert_timestamp_data , serialize_data
from datetime import datetime ,time
import json

logging = Logging(name="Partnerbecoming")
# Database configuration
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema": False,
}


def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes requests.

    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler

    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts

    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler
    if path == "/get_partner_to_provider_data":
        result = get_partner_to_provider_data(data)
    elif path == "/partner_to_provider_actions" :
        result = partner_to_provider_actions(data)
    else:
        result = {"flag": False, "error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result


def get_partner_to_provider_list_view_data(data):
    """
    Fetches a paginated list of active customers from the tenant database with applied user-level filters.

    Args:
        data (dict): Dictionary containing request data including:
            - role_name (str): The role of the user.
            - tenant_name (str): Name of the tenant.
            - module_name (str): Name of the requesting module.
            - db_name (str): Database name to query from.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Success status.
            - message (str): Response message.
            - data (list): List of customer records.
            - tenant_name (dict): Parent tenant info.
            - sub_tenant (dict): Subtenant details.
            - headers_map (dict): Header mapping for the frontend.
            - pages (dict): Pagination metadata with total count.
    """
    logging.info(f"### Starting get_partner_to_provider_list_view_data function with data: {data}")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    module_name = data.get("module_name", "")
    request_received_at = data.get("request_received_at", "")
    col_sort = data.get("col_sort", "")
    # Database Connection
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        database = DB(tenant_database, **db_config)
    except Exception as e:
        logging.exception("### Failed to connect to common utils database")
        return {
            "flag": False,
            "message": "Database connection error",
            "data": [],
            "tenant_name": [],
            "headers_map": {},
            "pages": {},
        }
    role_name = data.get("role_name", "")
    # Initialize data_list to hold customer data
    # total_resellers = 0
    return_json_data = {}
    try:
        start_page = data.get("mod_pages", {}).get("start", 0)
        end_page = data.get("mod_pages", {}).get("end", 100)
        # limit = 100  # Set the limit to 100
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        # Fetch tenant ID
        tenant_id=common_utils_database.get_data('tenant',{'tenant_name':tenant_name},['id'])['id'].to_list()[0]
        logging.info(f"### Tenant ID fetched: {tenant_id}")

        logging.info("### Received request data")
        # # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(common_utils_database,data)
        if col_sort:
            # Extract the single key-value pair
            key, value = list(col_sort.items())[0]  # Get the first and only pair
            # Construct the ORDER BY clause
            order_condition = f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
        else:
            # If users is None or empty, we skip the WHERE clause entirely
            order_condition = f"ORDER BY id DESC LIMIT 100 OFFSET {start_page}"
        query = f"""
            SELECT * FROM public.partner_to_provider
                {order_condition}
        """
        count_query = f"""
            SELECT COUNT(*) as total_count
            FROM public.partner_to_provider
        """
        # Execute the query using the existing execute_query function
        result = common_utils_database.execute_query(query, True)
        total_count_result = common_utils_database.execute_query(count_query, True)
        total_count = (
            total_count_result["total_count"].iloc[0]
            if not total_count_result.empty
            else 0
        )
        pages = {"start": start_page, "end": end_page, "total": int(total_count)}
        ##tenant details
        tenant_details = common_utils_database.get_data(
            "tenant", {"is_active": True}, ["id", "tenant_name"])
        if not tenant_details.empty:
            tenant_details = tenant_details.to_dict(orient="records")
        else:
            tenant_details = []
        ##service_provider details
        service_provider_details = database.get_data('serviceprovider', {'is_active': True}, ['id', 'service_provider_name'])
        if not service_provider_details.empty:
            service_provider_details = service_provider_details.to_dict(orient="records")
        else:  
            service_provider_details = []
        customer_groups=database.get_data('customer_groups', {'is_active': True,"tenant_name":tenant_name}, ['name'])
        if not customer_groups:
            customer_groups = []
        else:
            customer_groups=customer_groups['name'].to_list()
        logging.info("### Fetched customer groups")
        fan_ban_data=database.get_data('sim_management_inventory', {'is_active': True,"tenant_id":tenant_id}, ['foundation_account_number','billing_account_number'])
        if not fan_ban_data.empty:
            foundation_account_numbers=fan_ban_data['foundation_account_number'].dropna().unique().tolist()
            billing_account_numbers=fan_ban_data['billing_account_number'].dropna().unique().tolist()
        else:
            foundation_account_numbers=[]
            billing_account_numbers=[]

        # Get headers mapping
        headers_map = get_headers_mapping(
            database,
            ["Partners Becoming Provider"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            common_utils_database,
        )
        # Final result
        if not result.empty:
            df_dict = result.to_dict(orient="records")
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            df_dict = serialize_data(df_dict)

            logging.info("### Data fetched for Customers")

            # Prepare final response
            return_json_data.update(
                {
                    "flag": True,
                    "message": "Data fetched successfully",
                    "data": df_dict,
                    "tenant_details":tenant_details,
                    "service_provider_details":service_provider_details,
                    "foundation_account_numbers":foundation_account_numbers,
                    "billing_account_numbers":billing_account_numbers,
                    "headers_map": headers_map,
                    "pages": pages
                }
            )
            #return return_json_data
        else:
            return_json_data.update(
                {"flag": True, "data": [], "message": "No data found!",
                    "headers_map": headers_map}
            )
            logging.warning("### No data found for  Customers")
            #return return_json_data
        logging.info("### Returning data response")
        return_json_data.update(
            {
                "flag": True,
                "message": "Data fetched successfully",
                "data": df_dict,
                "tenant_details":tenant_details,
                "service_provider_details":service_provider_details,
                "foundation_account_numbers":foundation_account_numbers,
                "billing_account_numbers":billing_account_numbers,
                "headers_map": headers_map,
                "pages": pages,
            }
        )
        try:
            audit_data_user_actions = {
                "service_name": "get_partner_to_provider_list_view_data",
                "created_by": username,
                "status": str(return_json_data["flag"]),
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "module_name": "Partner Becoming Provider",
                "comments": f"Successfully retrieved Partner to Provider list view data",
                "request_received_at": request_received_at,
            }

            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        return return_json_data

    except Exception as e:
        logging.exception("### An error occurred in get_partner_to_provider_list_view_data")
        message = f"Failed to fetch Partner becoming provider for module: {module_name}"
        error_type = str(type(e).__name__)
        # Error Management
        error_data = {
            "service_name": "get_partner_to_provider_list_view_data",
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Partner Becoming Provider",
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database, ["Partner "], role_name, "", "", "", "", data, database
        )
        response={
                        "flag": True,
                        "data": [],
                        "message": "No data found for Partner to Provider Data!",
                        "tenant_name": [],
                        "headers_map": headers_map,
                    }
        return response

    
def partner_to_provider_actions(data):
    """
    Processes customer rate plan data by creating or updating rate plans in the database.
    Validates input, handles errors, and logs actions.

    Parameters:
        data (dict): A dictionary containing the rate plan data to process, including:
            - 'Partner' (str): The partner name.
            - 'session_id' (str): The session ID associated with the request.
            - 'username' (str): The username of the requester.
            - 'rate_plan_data' (dict): The rate plan data containing the fields to update.
            - 'action' (str): Action to perform, either 'create' or 'update'.
            - 'table_name' (str): The database table for storing rate plans.
            - 'db_name' (str): The tenant database name.

    Returns:
        dict: A response dictionary with:
            - 'flag' (bool): Indicates success (True) or failure (False).
            - 'message' (str): Describes the result of the operation.
    """
    logging.info(f"### starting partner_to_provider_actions function with data: {data}")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    session_id= data.get("sessionID", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_database = data.get("db_name", "")
    partner_to_provider_data=data.get('partner_to_provider_data',{})
    tenant_name = data.get("tenant_name", "")
    action=data.get("action", "")
    try:
        logging.info("### Processing partner_to_provider_actions")
        if action=='edit':
            cleaned_data = {k: v for k, v in partner_to_provider_data.items() if v != ''}
            updated_id=cleaned_data.pop("id", None)
            if updated_id:
                common_utils_database.update_dict('partner_to_provider', cleaned_data, {'id': updated_id})
                logging.info(f"### Partner to Provider data updated successfully with ID: {updated_id}")
        else:
            cleaned_data = {k: v for k, v in partner_to_provider_data.items() if v != ''}
            insert_id = common_utils_database.insert_data(cleaned_data, "partner_to_provider")
            logging.info(f"### Partner to Provider data created successfully with ID: {insert_id}")
            response ={
            "flag": True,
            "message": "Partner to Provider created successfully",
            "status_code": 200,
        }
        try:
            audit_data_user_actions = {
                "service_name": "partner_to_provider_actions",
                "created_by": username,
                "status": str(response['flag']),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "module_name": "Partner Becoming Provider",
                "comments": f"Successfully processed partner to provider action: {action} and create data is {json.dumps(partner_to_provider_data)} ", 
                "request_received_at": request_received_at,
            }

            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        response={
            "flag": True,
            "message": f"Partner to Provider {action} successfully",
            "status_code": 200,
        }
        return response

    except Exception as e:
        logging.error(f"### Exception in partner_to_provider_actions: {e}")
        message = "Failed to create or update customer in People module"

        common_utils_database.log_error_to_db(
            {
                "service_name": "partner_to_provider_actions",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"{message} for module: {action} and data is {json.dumps(partner_to_provider_data)}",
                "module_name": "Partner Becoming Provider",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        response= {
            "flag": False,
            "message": f"Error processing customers : {e}",
            "status_code": 500,
        }
        return response



def get_headers_mapping(
    tenant_database,
    module_list,
    role,
    user,
    tenant_id,
    sub_parent_module,
    parent_module,
    data,
    common_utils_database,
):
    """
    Description:
        This function fetches and organizes the field mappings and features for a list of modules 
        based on user role, tenant, and other context data. It separates fields into general fields, 
        popup fields, and table headers, and includes feature permissions per module.

    Args:
        tenant_database (str): Name of the tenant-specific database.
        module_list (list): List of module names to fetch headers and features for.
        tenant_id (int): Tenant ID (may be overwritten by data fetched inside the function).
        sub_parent_module (str): Name of the sub-parent module (not used inside currently).
        data (dict): Request-related data containing keys like 'username', 'tenant_name', etc.
        common_utils_database (DB): DB connection object to the common_utils database.

    Returns:
        dict: A dictionary where each key is a module name, and the value is a dictionary containing:
            - general_fields: List of fields not categorized as pop-up or table fields
            - pop_up: List of fields marked as pop-up fields
            - header_map: Dictionary of table fields with display name and order
            - module_features: List of feature permissions for the module and user role
    """
    ##Database connection
    ret_out = {}
    try:
        logging.info(f"### Module name is :{module_list} and role is :{role}")
        # common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        feature_module_name = data.get("feature_module_name", "")
        user_name = data.get("username") or data.get("user_name") or data.get("user")
        tenant_name = data.get("tenant_name") or data.get("tenant")
        parent_module_name = data.get("parent_module_name") or data.get("parent_module")
        if parent_module_name == "Sim Management":
            parent_module_name = "Sim Management"
        try:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            logging.debug(f"### tenant_id  is :{tenant_id}")
        except Exception as e:
            logging.exception(f"### Getting exception at fetching tenant id : {e}")
        # Iterate over each module name in the provided module list
        for module_name in module_list:
            out = common_utils_database.get_data(
                "field_column_mapping", {"module_name": module_name}
            ).to_dict(orient="records")
            pop_up = []
            general_fields = []
            table_fileds = {}
            # Categorize the fetched data based on field types
            for data in out:
                if data["pop_col"]:
                    pop_up.append(data)
                elif data["table_col"]:
                    table_fileds.update(
                        {
                            data["db_column_name"]: [
                                data["display_name"],
                                data["table_header_order"],
                            ]
                        }
                    )
                else:
                    general_fields.append(data)
            # Create a dictionary to store categorized fields
            headers = {}
            headers["general_fields"] = general_fields
            headers["pop_up"] = pop_up
            headers["header_map"] = table_fileds
            logging.info("### Got the header map here")
            try:
                final_features = []

                # Fetch all features for the 'super admin' role
                if role.lower() == "super admin":
                    all_features = common_utils_database.get_data(
                        "module_features",
                        {
                            "module": feature_module_name,
                            "parent_module_name": parent_module_name,
                        },
                        ["features"],
                    )["features"].to_list()
                    if all_features:
                        final_features = json.loads(all_features[0])
                else:
                    final_features = get_features_by_feature_name(
                        user_name,
                        tenant_id,
                        feature_module_name,
                        common_utils_database,
                        role,
                        parent_module_name
                    )

            except Exception as e:
                logging.warning(f"### there is some error: {e}")
                pass
            # Add the final features to the headers dictionary
            headers["module_features"] = final_features
            ret_out[module_name] = headers
    except Exception as e:
        logging.warning(f"### there is some error : {e}")

    return ret_out




def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database,role,parent_module
):
    """
    Description:
        This function retrieves a list of features associated with a specific
        feature name for a user within a tenant.
        It fetches user-module-tenant mapping data, processes the features,
        and extracts relevant features
        linked to the specified feature name.

    Parameters:
    ----------
    user_name : str
        The name or identifier of the user for whom the features are being fetched.
    tenant_id : str
        The tenant ID associated with the user.
    feature_name : str
        The specific feature name for which features need to be extracted.
    common_utils_database : object
        Utility database object to query data from the required tables.

    Returns:
    -------
    list
        A list of features associated with the specified feature name for the user.
    """
    # Fetch user features from the database based on user name and tenant ID
    user_features_raw = common_utils_database.get_data(
        "user_module_tenant_mapping",
        {"user_name": user_name, "tenant_id": tenant_id},
        ["module_features"],
    )["module_features"].to_list()
    logging.debug(f"### Raw user features fetched: {user_features_raw}")
    if not user_features_raw or user_features_raw[0] is None:
        query=f'''select module_features from role_module where role='{role}'
        '''
        user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
    # Parse the JSON string to a dictionary
    try:
        features = json.loads(
            user_features_raw[0]
        )  # Assuming it's a list with one JSON string

    except Exception as e:
      logging.error(f"Exception occurred while getting features: {str(e)}")
      features={}        


    if not features:
        features = common_utils_database.get_data(
            "role_module",
            {"role": role},
            ["module_features"],
        )["module_features"].to_list()
        features = json.loads(
            features[0]
        )


    # Initialize a list to hold features for the specified feature name
    features_list = []

    # Loop through all modules to find the specified feature name and collect its features
    for par_module, modules in features.items():
        if parent_module == par_module:
            for module,features_l in modules.items():
                if module == feature_name:
                    features_list = features_l

    # Log the retrieved features for debugging purposes
    logging.info(f"### Retrieved features: {features_list}")


    # Return the list of features associated with the specified feature name
    return features_list
