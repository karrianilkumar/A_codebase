"""
@Author1: Ajay Kumar
@Author2: Gopi Teja B
"""

import json
import os
from datetime import datetime, timedelta
import concurrent.futures

from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import fetch_tenant_timezone, convert_timestamp_data, serialize_data

logging = Logging(name="centralized_view")
# Database configuration
db_config = {
            "host": os.environ["HOST"],
            "port": os.environ["PORT"],
            "user": os.environ["USER"],
            "password": os.environ["PASSWORD"],
            "multi_schema": False,
            }


##################  Generic Functions  ##################
def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name, role
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Parameters:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        logging.info(f"### Raw user features fetched:{user_features_raw}")
        if not user_features_raw or user_features_raw[0] is None:
            # query = f"""select module_features from role_module where role='{role}'
            # """
            # user_features_raw = common_utils_database.execute_query(query, True)[
            #     "module_features"
            # ].to_list()  # Convert the result to a list
            query = "SELECT module_features FROM role_module WHERE role = %s"
            user_features_raw = common_utils_database.execute_query(query, params=[role])["module_features"].to_list()


        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  # Assuming the result is a list with one JSON string

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  # Add features if found under parent module

        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        logging.info(f"### Retrieved features:{features_list}")  # Log the retrieved features

    except Exception as e:
        # Catch any exceptions and log a warning
        logging.warning(f"### There was an error while fetching features: {e}")

    return features_list  # Return the list of retrieved features


def get_headers_mappings(
    tenant_database,
    module_list,
    role,
    user,
    tenant_id,
    sub_parent_module,
    parent_module,
    data,
    common_utils_database,
):
    """
    Retrieves and organizes header field mappings and module features for the given modules.

    Parameters:
        tenant_database (str): Name of the tenant-specific database.
        module_list (list): List of module names to fetch header mappings for.
        tenant_id (int): Unique ID of the tenant.
        sub_parent_module (str): (Currently unused) Sub-parent module name if available.
        parent_module (str): Parent module name to help determine scope of features.
        data (dict): Input dictionary containing extra request info like:
                     - feature_module_name , username, tenant_name, parent_module_name
        common_utils_database (DB): DB connection object for the common_utils database.

    Returns:
        dict: A dictionary where each key is a module name and each value is another
              dictionary containing:
              - general_fields: Non-table, non-popup fields
              - pop_up: Pop-up specific fields
              - header_map: Table header display names and order
              - module_features: Features enabled for this module
    """
    ##Database connection
    ret_out = {}
    
    logging.info(f"### db_config_withoutfilter is : {db_config}")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        logging.info(f"### Module name is :{module_list} and role is: {role}")
        # common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        feature_module_name = data.get("feature_module_name", "")
        user_name = data.get("username") or data.get("user_name") or data.get("user")
        tenant_name = data.get("tenant_name") or data.get("tenant")
        parent_module_name = data.get("parent_module_name") or data.get("parent_module")
        if parent_module_name == "Sim Management":
            parent_module_name = "Sim Management"
        try:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            logging.info(f"### tenant_id  is :{tenant_id}")
        except Exception as e:
            logging.exception(f"### Getting exception at fetching tenant id : {e}")
        # Iterate over each module name in the provided module list
        for module_name in module_list:
            out = common_utils_database.get_data(
                "field_column_mapping", {"module_name": module_name}
            ).to_dict(orient="records")
            pop_up = []
            general_fields = []
            table_fileds = {}
            # Categorize the fetched data based on field types
            for data in out:
                if data["pop_col"]:
                    pop_up.append(data)
                elif data["table_col"]:
                    table_fileds.update(
                        {
                            data["db_column_name"]: [
                                data["display_name"],
                                data["table_header_order"],
                            ]
                        }
                    )
                else:
                    general_fields.append(data)
            # Create a dictionary to store categorized fields
            headers = {}
            headers["general_fields"] = general_fields
            headers["pop_up"] = pop_up
            headers["header_map"] = table_fileds
            logging.info("### Got the header map here")
            try:
                final_features = []

                # Fetch all features for the 'super admin' role
                if role.lower() == "super admin":
                    all_features = common_utils_database.get_data(
                        "module_features",
                        {
                            "module": feature_module_name,
                            "parent_module_name": parent_module_name,
                        },
                        ["features"],
                    )["features"].to_list()
                    if all_features:
                        final_features = json.loads(all_features[0])
                else:
                    final_features = get_features_by_feature_name(
                        user_name,
                        tenant_id,
                        feature_module_name,
                        common_utils_database,
                        parent_module_name,
                        role,
                    )

            except Exception as e:
                logging.warning(f"### there is some error : {e}")
                pass
            # Add the final features to the headers dictionary
            headers["module_features"] = final_features
            ret_out[module_name] = headers
    except Exception as e:
        logging.warning(f"### there is some error :  {e}")

    return ret_out


def function_caller(data, path, access_token):
    """
    Main function caller that handles database configuration setup and routes requests.

    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler

    Parameters :
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts

    Returns:
        Result of the called endpoint function or error response
    """
    # Access global db_config variable
    global db_config
    # Initialize base database configuration from environment variables
    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema": False,
    }
    # Extract username from request data (handling different field names)

    # Route to appropriate endpoint handler
    # Define path-to-function mapping
    path_function_map = {
        "/get_centralized_list_view_data": get_centralized_list_view_data,
        "/get_tenants_list": get_tenants_list,
        "/count_bulk_change_total_records": count_bulk_change_total_records,
        "/count_bulk_change_successful_records": count_bulk_change_successful_records,
        "/count_bulk_change_progress_records": count_bulk_change_progress_records,
        "/count_bulk_change_failed_records": count_bulk_change_failed_records,
        "/bargraph_bulk_change_process_status": bargraph_bulk_change_process_status,
        "/pie_chart_bulk_change_sync_status": pie_chart_bulk_change_sync_status,
        "/stackbar_bulk_change_change_request": stackbar_bulk_change_change_request,
        "/count_optimization_total_records":count_optimization_total_records,
        "/count_optimization_inprogress_records":count_optimization_inprogress_records,
        "/count_optimization_completed_records":count_optimization_completed_records,
        "/count_optimization_charges_to_be_pushed_records":count_optimization_charges_to_be_pushed_records,
        "/linechart_monthly_optimization_volume":linechart_monthly_optimization_volume,
        "/stackbar_optimization_total_vs_pushed_charges":stackbar_optimization_total_vs_pushed_charges,
    }

    # Use the map to call the corresponding function
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.info(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result


def get_tenants_list(data):
    """
    Retrieves the list of distinct and active tenant names from the database.

    Parameters :
        data (dict): Request data containing audit-related fields.

    Returns:
        dict: A dictionary containing:
            - "flag" (bool): Indicates success or failure.
            - "tenant_list" (list): A list of active tenant names.
    """
    username = data.get("username", "")
    session_id = data.get("session_id", "")
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at", "")

    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        query = "SELECT DISTINCT tenant_name FROM tenant WHERE is_active = TRUE"
        tenants_df = common_utils_database.execute_query(query, True)
        tenant_list = tenants_df["tenant_name"].to_list() if not tenants_df.empty else []

        try:
            response = {"flag": True, "tenant_list": tenant_list}
            audit_data_user_actions = {
                "service_name": "get_tenants_list",
                "created_by": username,
                "status": str(response["flag"]),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "module_name": "Centralized View",
                "comments": "Fetched active tenant list successfully",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception while updating audit - {e}")

        return response

    except Exception as e:
        logging.exception(f"### get_tenants_list exception: {e}")
        message = f"Unable to fetch active tenant list: {e}"

        try:
            error_data = {
                "service_name": "get_tenants_list",
                "error_message": message,
                "error_type": str(type(e).__name__),
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": "Failed to fetch tenant list",
                "module_name": "Centralized View",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as err:
            logging.warning(f"### Exception while auditing error - {err}")

        return {"flag": False, "tenant_list": []}


def build_query(base_query: str, data: dict):
    """
    Builds a SQL query by appending optional filters for tenant and date range.

    Parameters :
        base_query (str): The base SQL query to build on (should already include a WHERE or be ready for AND conditions).
        data (dict): Dictionary containing optional filters:
            - selected_tenant (str): Tenant name to filter by (skipped if "All").
            - start_date (str): Start date in 'YYYY-MM-DD' format.
            - end_date (str): End date in 'YYYY-MM-DD' format (inclusive).

    Returns:
        tuple: A tuple containing:
            - final_query (str): The modified SQL query with added conditions.
            - params (tuple): Tuple of parameters to safely inject into the query.
    """

    tenant = data.get("selected_tenant", "All")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")

    params = []
    if tenant != "All":
        base_query += " AND tenant = %s"
        params.append(tenant)
    if start_date and end_date:
        base_query += " AND created_date >= %s AND created_date < %s"
        params.append(start_date)
        next_day = (datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")
        params.append(next_day)
    elif start_date:
        base_query += " AND created_date >= %s"
        params.append(start_date)
    elif end_date:
        base_query += " AND created_date <= %s"
        params.append(end_date)
    return base_query, tuple(params)


##################  Lambda Core Functions  ##################
def get_centralized_list_view_data(data):
    """
    Retrieves bulk change and optimization data for all tenants from the central database.
    Parameters :
        data (dict): Input data containing necessary parameters for querying the database.
    Returns:
        dict: Response data containing success or failure status, a message, and the requested data.
    """
    logging.info(f"### Request Data for get_centralized_list_view_data: {data}")
    username = data.get("username", None)
    role_name = data.get("role_name", None)
    db_name = data.get("db_name", "central_db")
    request_received_at = data.get("request_received_at", None)
    session_id = data.get("session_id", None)
    module_name = data.get("module_name", None)
    table_name = data.get("table_name", "vw_all_device_bulk_changes")
    if role_name != "Super Admin":
        return {"flag": False, "message": "You are not authorized to access."}
    # Database connection parameters
    database = DB(db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    Partner = data.get("partner")
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    module_name = data.get("module_name", "")
    sub_module = data.get("sub_module", "")
    request_received_at = data.get("request_received_at", "")
    col_sort = data.get("col_sort", "")
    limit = data.get("limit", 100)
    return_json_data = {}
    start_page = data.get("mod_pages", {}).get("start", 0)
    end_page = data.get("mod_pages", {}).get("end", 100)
    try:
        pages = {}
        module_query_df = common_utils_database.get_data(
            "module_view_queries", {"module_name": module_name}, ["module_query"]
        )

        if module_query_df.empty:
            logging.error(f"### No module query found for module: {module_name}")
            return {
                "flag": False,
                "message": f"No module query found for module: {module_name}",
            }
        query = module_query_df["module_query"].to_list()[0]
        params = []
        if module_name == "Centralized Optimization Insights View":
            query,params = build_query(query,data)
            order_condition = " ORDER BY created_date DESC"
        elif module_name == "Centralized Bulk Change View":
            order_condition = " ORDER BY processed_date DESC NULLS LAST "
        else:
            order_condition = " ORDER BY run_start_time DESC NULLS LAST "
        if col_sort:
            # If col_sort is provided, use it to create the order condition
            key, value = list(col_sort.items())[0]
            order_condition = f"ORDER BY {key} {value.upper()} NULLS LAST  "
        order_condition += f" LIMIT {limit} OFFSET {start_page} "

        logging.info(f"### Module query for {module_name}: {query}")


        logging.info(f"### Module name: {module_name}, Role name: {role_name}, Start page: {start_page}")

        # Modify the query to include pagination and sorting
        query = f"""
            {query}
            {order_condition}
        """

        count_query = f"""
            SELECT COUNT(id) as total_count FROM {table_name}
        """

        # Execute the query using the existing execute_query function
        result = database.execute_query(query, params=params)
        if "session_id" in result.columns:
            result["session_id"] = result["session_id"].astype(str)
        total_count_result = database.execute_query(count_query, True)
        total_count = (
            total_count_result["total_count"].iloc[0]
            if not total_count_result.empty
            else 0
        )
        pages = {"start": start_page, "end": end_page, "total": int(total_count)}
        logging.info("### Query executed for  Super Admin Banners data retrieval")
        logging.info(f"### Total records fetched: {len(result)}")

        # Final result
        tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)

        headers_map = get_headers_mappings(
            db_name,
            [sub_module],
            role_name,
            "",
            "",
            "",
            "",
            data,
            common_utils_database,
        )

        if not result.empty:
            df_dict = result.to_dict(orient="records")
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            df_dict = serialize_data(df_dict)

            logging.info(f"### Data fetched for banners : {len(df_dict)} records found")

            # Prepare final response
            return_json_data.update(
                {
                    "flag": True,
                    "message": "Data fetched successfully",
                    "data": df_dict,
                    "headers_map": headers_map,
                    "pages": pages,
                    "tenant_name": tenant_name,
                }
            )
            # return return_json_data
        else:
            return_json_data.update(
                {
                    "flag": True,
                    "data": [],
                    "message": "No data found!",
                    "headers_map": headers_map,
                }
            )
            logging.warning("### No data found for  Banners")
            # return return_json_data
        logging.info("### Returning data response")
        ##Audit log for user actions
        try:
            audit_data_user_actions = {
                "service_name": "get_centralized_list_view_data",
                "created_by": username,
                "status": str(return_json_data["flag"]),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "module_name": sub_module,
                "comments": "Centralized Module List View",
                "request_received_at": request_received_at,
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception while updating audit : {e}")
        return return_json_data

    except Exception as e:
        logging.exception(f"### An error occurred: {e}")
        headers_map = get_headers_mappings(
            db_name,
            [sub_module],
            role_name,
            "",
            "",
            "",
            "",
            data,
            common_utils_database,
        )
        message = f"Unable to fetch the Centralized list view data: {e}"
        return_json_data = {
            "flag": True,
            "data": [],
            "headers_map": headers_map,
            "pages": pages,
        }
        error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "get_centralized_list_view_data",
            "error_message": message,
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "Failed to get the Centralized list view data",
            "module_name": "Centralized View",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return return_json_data

def count_bulk_change_total_records(data):
    """
    Counts bulk change records for one or more tenants within an optional date range.
    Parameters:
        data (dict): Input data containing the following important keys:
            - tenant_name (str or list): Name(s) of the tenant(s) to filter by. (Required)
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) to filter records by creation date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) to filter records by creation date.
            - request_received_at (str): Timestamp when the request was received.

    Returns:
        dict: A dictionary containing:
            - success (bool): True if the operation was successful; False otherwise.
            - count (int): Number of records matching the criteria.
            - message (str): Success or error message describing the outcome.

    """

    logging.info(f"### count_bulk_change_total_records data : {data}")
    db_name = data.get("db_name", "central_db")
    username = data.get("username", "")
    session_id = data.get("sessionID", "")
    partner_name = data.get("Partner", "")
    request_time = data.get("request_received_at", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        central_db = DB(db_name, **db_config)

        base_query = """
            SELECT COUNT(id) as record_count
            FROM vw_all_device_bulk_changes
            WHERE is_deleted = false
        """
        query, params = build_query(base_query, data)
        result = central_db.execute_query(query, params=params)
        logging.info(f"### count_bulk_change_total_records {result}")
        record_count = int(result.iloc[0]["record_count"]) if not result.empty else 0
        response = {
            "flag": True,
            "data": {"count": record_count, "title": "Total"},
            "message": "Successfully counted records",
        }

    except Exception as error:
        # Single error logging → only on failure
        logging.exception(f"### count_bulk_change_total_records exception {error}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "count_bulk_change_total_records",
                "error_message": str(error),
                "error_type": type(error).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner_name,
                "comments": "Execution failed while getting bulk change total records",
                "module_name": "Centralized View",
                "request_received_at": request_time,
            },
            "error_log_table",
        )
        response = {"flag": False, "message": "Something went wrong while fetching count"}

    return response


def count_bulk_change_successful_records(data):
    """
    Counts total number of bulk changes that are successfully processed.

     Parameters:
        data (dict): Dictionary of input parameters, with the following important keys:
            - tenant_name (str or list): Name(s) of the tenant(s) to filter by. (Required)
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) for filtering by created_date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) for filtering by created_date.
            - request_received_at (str): Timestamp indicating when the request was received, for auditing.

    Returns:
        dict: A dictionary containing:
            - success (bool): True if the query executed successfully; False otherwise.
            - count (int): Number of successfully synchronized SIM records.
            - message (str): A descriptive message about the result or error.
    """

    logging.info(f"### count_bulk_change_successful_records data - {data}")
    db_name = data.get("db_name", "central_db")
    username = data.get("username", "")
    session_id = data.get("sessionID", "")
    partner_name = data.get("Partner", "")
    request_time = data.get("request_received_at", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        central_db = DB(db_name, **db_config)

        base_query = """
            SELECT COUNT(id) AS record_count
            FROM vw_all_device_bulk_changes
            WHERE is_deleted = false
            AND status = 'PROCESSED'
        """
        query, params = build_query(base_query, data)
        result = central_db.execute_query(query, params=params)

        if result is None or not hasattr(result, "iloc"):
            raise Exception("Query execution failed")

        record_count = int(result.iloc[0]["record_count"]) if not result.empty else 0

        response = {
            "flag": True,
            "data": {"count": record_count, "title": "Successful"},
            "message": "Successfully fetched the count of successful records",
        }

    except Exception as error:
        # Single error logging → only on failure
        logging.exception(f"### count_successful_bulkchange_records exception {error}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "count_bulk_change_successful_records",
                "error_message": str(error),
                "error_type": type(error).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner_name,
                "comments": "Execution failed while getting count of bulk change successful records",
                "module_name": "Centralized View",
                "request_received_at": request_time,
            },
            "error_log_table",
        )
        response = {"flag": False, "message": "Something went wrong while fetching the count of records"}

    return response


def count_bulk_change_progress_records(data):
    """
    Counts total number of bulk changes in progress (status = ('NEW','PROCESSING')) , within an optional date range

     Parameters:
        data (dict): Dictionary of input parameters with the following important keys:
            - selected_tenant (str): Name of the tenant to filter records by.
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) to filter by created_date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) to filter by created_date.
            - request_received_at (str): Timestamp of when the request was received, used in audit logging.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if the query was successful; False if an error occurred.
            - count (int): Number of SIM records currently in progress.
            - message (str): Descriptive message indicating the result of the operation or any encountered error.
    """

    logging.info(f"### Request data received count_bulk_change_progress_records data - {data}")
    db_name = data.get("db_name", "central_db")
    username = data.get("username", "")
    session_id = data.get("sessionID", "")
    partner_name = data.get("Partner", "")
    request_time = data.get("request_received_at", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        central_db = DB(db_name, **db_config)
        base_query = """
            SELECT COUNT(id) AS record_count
            FROM public.vw_all_device_bulk_changes
            WHERE is_deleted = false
            AND status in ('NEW','PROCESSING')
        """
        query, params = build_query(base_query, data)
        result = central_db.execute_query(query, params=params)

        if result is None or not hasattr(result, "iloc"):
            raise Exception("Query execution failed")

        record_count = int(result.iloc[0]["record_count"]) if not result.empty else 0

        response = {
            "flag": True,
            "data": {"count": record_count, "title": "Progress"},
            "message": "Successfully fetched the count of inprogress records",
        }

    except Exception as error:
        # Single error logging → only on failure
        logging.exception(f"### something went wrong count_bulk_change_progress_records exception {error}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "count_bulk_change_progress_records",
                "error_message": str(error),
                "error_type": type(error).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner_name,
                "comments": "Execution failed while getting count of bulk change progress records ",
                "module_name": "Centralized View",
                "request_received_at": request_time,
            },
            "error_log_table",
        )
        response = {"flag": False, "message": "Something went wrong while fetching the count of records"}
    return response


def count_bulk_change_failed_records(data):
    """
    Counts total number of failed sims (status = ERROR for one or more tenants within an optional date range

        Parameters:
        data (dict): Dictionary of input parameters with the following important keys:
            - selected_tenant (str): Name of the tenant to filter records by.
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) to filter by created_date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) to filter by created_date.
            - request_received_at (str): Timestamp of when the request was received, used in audit logging.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if the query was successful; False if an error occurred.
            - count (int): Number of failed SIM synchronization records.
            - message (str): Descriptive message indicating the result of the operation or any encountered error.

    """

    logging.info(f"### Received request data for count_bulk_change_failed_records data - {data}")
    db_name = data.get("db_name", "central_db")
    username = data.get("username", "")
    session_id = data.get("sessionID", "")
    partner_name = data.get("Partner", "")
    request_time = data.get("request_received_at", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        central_db = DB(db_name, **db_config)
        base_query = """
            SELECT COUNT(id) AS record_count
            FROM vw_all_device_bulk_changes
            WHERE is_deleted = false
            AND status = 'ERROR'
        """

        query, params = build_query(base_query, data)
        result = central_db.execute_query(query, params=tuple(params))

        if result is None or not hasattr(result, "iloc"):
            raise Exception("Query execution failed")

        record_count = int(result.iloc[0]["record_count"]) if not result.empty else 0
        response = {
            "flag": True,
            "data": {"count": record_count, "title": "Failed"},
            "message": "Successfully fetched the count of inprogress records"
        }

    except Exception as error:
        # Single error logging → only on failure
        logging.exception(f"### count_bulkchange_failed_records exception {error}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "count_bulk_change_failed_records",
                "error_message": str(error),
                "error_type": type(error).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner_name,
                "comments": "Execution failed while getting count of bulk change failed records",
                "module_name": "Centralized View",
                "request_received_at": request_time,
            },
            "error_log_table",
        )
        response = {"flag": False, "message": "Something went wrong while fetching the count of records"}

    return response


def bargraph_bulk_change_process_status(data):
    """
    Generates a bar chart summary of UI and API processed device bulk change records per tenant.

    Parameters:
        data (dict): Dictionary containing the following keys:
            - selected_tenant (str): Name of the tenant to filter records by.
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) to filter by created_date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) to filter by created_date.
            - username (str): Username making the request.
            - sessionID (str): Unique session identifier.
            - Partner (str): Partner or tenant name.
            - request_received_at (str): Timestamp of the request.

    Returns:
        dict: A dictionary with the following structure:
            {
                "flag": bool,  # Indicates success or failure
                "data": {
                    "title": str,
                    "chart_type": str,
                    "data": list[dict],
                    "xField": str,
                    "yField": str,
                    "smooth": bool,
                    "height": int,
                    "width": int
                }  # Present only on success
                "message": str  # Present only on failure
            }

    Exceptions:
        All exceptions are caught and logged to the error log table, with relevant request context.
    """

    logging.info(f"### Request data received for bargraph_bulk_change_process_status : {data}")
    db_name = data.get("db_name", "central_db")
    username = data.get("username", "")
    session_id = data.get("sessionID", "")
    partner_name = data.get("Partner", "")
    request_time = data.get("request_received_at", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        central_db = DB(db_name, **db_config)
        base_query = """
            SELECT
                tenant AS name,
                COUNT(*) FILTER (WHERE readme_flag = false) AS ui,
                COUNT(*) FILTER (WHERE readme_flag = true) AS api
            FROM vw_all_device_bulk_changes
            WHERE is_deleted = false
        """
        query, params = build_query(base_query, data)
        query += " GROUP BY tenant;"
        chart_df = central_db.execute_query(query, params=params)
        if chart_df is None or chart_df.empty:
            chart_data = []
        else:
            chart_df.rename(columns={"ui": "UI", "api": "API"}, inplace=True)
            chart_data = chart_df.to_dict(orient="records")
        logging.info(f"### bargraph_bulk_change_process_status chart_data : {chart_data}")
        response = {
            "flag": True,
            "data": {
                "title": "UI/API Process Count",
                "chart_type": "bar",
                "data": chart_data,
                "xField": "Type",
                "yField": "Tenant",
                "smooth": True,
                "height": 300,
                "width": 500,
            },
        }

    except Exception as e:
        logging.exception(f"### bulkchange_process_chart exception - {e}")
        response = {"flag": False, "message": "Something went wrong while fetching data for bulk change process status"}
        common_utils_database.log_error_to_db(
            {
                "service_name": "bargraph_bulk_change_process_status",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner_name,
                "comments": "Execution failed while getting bulk change process status bargraph data",
                "module_name": "Centralized View",
                "request_received_at": request_time,
            },
            "error_log_table",
        )

    return response


def pie_chart_bulk_change_sync_status(request_data):
    """
    Fetches the sync status data for bulk changes and prepares pie chart data.
    Parameters:
        data (dict): Dictionary containing the following keys:
            - selected_tenant (str): Name of the tenant to filter records by.
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) to filter by created_date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) to filter by created_date.
            - username (str): Username making the request.
            - sessionID (str): Unique session identifier.
            - Partner (str): Partner or tenant name.
            - request_received_at (str): Timestamp of the request.

    Returns:
        dict: A dictionary with the following structure:
            {
                "flag": bool,  # Indicates success or failure
                "data": {
                    "title": "Sync Status",
                    "chart_type": "pie",
                    "data": list[dict],
                    "angleField": "count",
                    "colorField": "status",
                    "height": 300,
                    "width": 300
                }
                "message": str  # Present only on failure
            }

    Exceptions:
        All exceptions are caught and logged to the error log table, with relevant request context.
    """

    logging.info(f"### Request Data for pie_chart_bulk_change_sync_status: {request_data}")
    db_name = request_data.get("db_name", "central_db")
    username = request_data.get("username", "")
    session_id = request_data.get("sessionID", "")
    partner_name = request_data.get("Partner", "")
    request_time = request_data.get("request_received_at", "")
    common_utils_db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        central_db = DB(db_name, **db_config)
        # Query for sync completed records
        complete_query = (
            "SELECT count(*) as record_count FROM public.vw_all_device_bulk_changes "
            "WHERE is_active = true AND sync_status IN ('Sync Completed', 'Sync Complete')"
        )
        complete_query, complete_params = build_query(complete_query, request_data)
        complete_result = central_db.execute_query(
            complete_query, params=complete_params
        )

        if complete_result is None or not hasattr(complete_result, "iloc"):
            raise ValueError("Failed to retrieve sync completed data")

        # Query for sync error records
        error_query = (
            "SELECT count(*) as record_count FROM public.vw_all_device_bulk_changes "
            "WHERE is_active = true AND sync_status IN ('ERROR', 'Sync Error', 'Error in Sync')"
        )
        error_query, error_params = build_query(error_query, request_data)
        error_result = central_db.execute_query(error_query, params=error_params)

        if error_result is None or not hasattr(error_result, "iloc"):
            raise ValueError("Failed to retrieve sync error data")
        
        sync_inprogress_query = """
            SELECT count(*) as record_count FROM public.vw_all_device_bulk_changes
            WHERE is_active = true AND sync_status='Sync In Progress'
        """
        sync_inprogress_query, sync_inprogress_params = build_query(sync_inprogress_query, request_data)
        sync_inprogress_result = central_db.execute_query(sync_inprogress_query, params=sync_inprogress_params)

        if sync_inprogress_result is None or not hasattr(sync_inprogress_result, "iloc"):
            raise ValueError("Failed to retrieve Sync In Progress data")

        # Extract counts from results
        sync_complete_count = (
            int(complete_result.iloc[0]["record_count"])
            if not complete_result.empty
            else 0
        )
        sync_error_count = (
            int(error_result.iloc[0]["record_count"]) if not error_result.empty else 0
        )

        sync_inprogress_count = (
            int(sync_inprogress_result.iloc[0]["record_count"]) if not sync_inprogress_result.empty else 0
        )

        return {
            "flag": True,
            "data": {
                "title": "Sync Status",
                "chart_type": "pie",
                "data": [
                    {"status": "Sync Completed", "count": sync_complete_count},
                    {"status": "Error in Sync", "count": sync_error_count},
                    {"status": "Sync In Progress", "count": sync_inprogress_count},
                ],
                "angleField": "count",
                "colorField": "status",
                "height": 300,
                "width": 300,
            },
        }

    except Exception as error:
        logging.exception(
            f"### Something went wrong while processing sync_status_pie_chart {error}"
        )
        common_utils_db.log_error_to_db(
            {
                "service_name": "pie_chart_bulk_change_sync_status",
                "error_message": str(error),
                "error_type": type(error).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner_name,
                "comments": "Execution failed while fetching sync status pie chart data",
                "module_name": "Centralized View",
                "request_received_at": request_time,
            },
            "error_log_table",
        )
        return {"flag": False, "message": "Something went wrong while processing"}


def stackbar_bulk_change_change_request(data):
    """
    Generates a stackbar chart summary of change_request_type and tenant processed device bulk change records per tenant..
    Parameters:
        data (dict): Dictionary containing the following keys:
            - selected_tenant (str): Name of the tenant to filter records by.
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) to filter by created_date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) to filter by created_date.
            - username (str): Username making the request.
            - sessionID (str): Unique session identifier.
            - Partner (str): Partner or tenant name.
            - request_received_at (str): Timestamp of the request.

    Returns:
        dict: A dictionary with the following structure:
            {
                "flag": bool,  # Indicates success or failure
                "data": {
                    "title": "Change Request Types By Tenant",
                    "chart_type": "stackedBar",
                    "data": list[dict],
                    "xField": "tenant",
                    "yField": "count",
                    "seriesField": "change_request_type",
                    "height": 300,
                    "width": 500
                }
                "message": str  # Present only on failure
            }

    Exceptions:
        All exceptions are caught and logged to the error log table, with relevant request context.
    """

    logging.info(f"### Request received data stackbar_bulk_change_change_request data - {data}")
    db_name = data.get("db_name", "central_db")
    username = data.get("username", "")
    session_id = data.get("sessionID", "")
    partner_name = data.get("Partner", "")
    request_time = data.get("request_received_at", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        central_db = DB(db_name, **db_config)
        base_query = "SELECT tenant, change_request_type, COUNT(*) AS count FROM vw_all_device_bulk_changes WHERE is_deleted = false"
        query, params = build_query(base_query, data)
        query += " GROUP BY tenant, change_request_type;"
        chart_df = central_db.execute_query(query, params=params)

        if chart_df is None or chart_df.empty:
            chart_data = []
        else:
            chart_data = chart_df.to_dict(orient="records")

        response = {
            "flag": True,
            "data": {
                "title": "Change Request Types By Tenant",
                "chart_type": "stackedBar",
                "data": chart_data,
                "xField": "tenant",
                "yField": "count",
                "seriesField": "change_request_type",
                "height": 300,
                "width": 500,
            },
        }

    except Exception as e:
        logging.exception(f"### stackbar_bulk_change_change_request exception - {e}")
        response = {"flag": False, "message": "Something went wrong while fetching data for change request types by tenant"}
        common_utils_database.log_error_to_db(
            {
                "service_name": "stackbar_bulk_change_change_request",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner_name,
                "comments": "Execution failed while getting bulk change request stackbar data ",
                "module_name": "Centralized View",
                "request_received_at": request_time,
            },
            "error_log_table",
        )
    return response

def count_optimization_total_records(data):
       
    """
    Counts the Total records of optimization data for one or more tenants within an optional date range

        Parameters:
        data (dict): Dictionary of input parameters with the following important keys:
            - selected_tenant (str): Name of the tenant to filter records by.
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) to filter by created_date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) to filter by created_date.
            - request_received_at (str): Timestamp of when the request was received, used in audit logging.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if the query was successful; False if an error occurred.
            - data (dict): Number of records along with title
            - message (str): Success or error message describing the outcome.

    """
       
    logging.info(f"### Fetching count_optimization_total_records  - {data}")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", None)
    db_name = data.get("db_name","central_db")
    session_id = data.get("session_id", None)
    partner = data.get("partner")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        # connecting to the central database
        database = DB(db_name, **db_config)
        # Query to fetch optimization data
        base_query = """
            SELECT COUNT(id) AS record_count FROM vw_all_combined_optimization
        """
        query,params = build_query(base_query,data)
        # Handle WHERE clause properly # if AND in query and WHERE not in query replace first AND with WHERE
        if "WHERE" not in query and "AND" in query:
            query = query.replace("AND", "WHERE", 1)  # Only replace first occurrence
        # Execute the query and fetch the data
        result = database.execute_query(query, params=params)
        if result is None or not hasattr(result, "iloc"):
            raise Exception("Query execution failed")

        record_count = int(result.iloc[0]["record_count"]) if not result.empty else 0
        response = {
            "flag": True,
            "data": {"count": record_count, "title": "Total"},
            "message": "Successfully fetched the count of Total records",
        }
 
    except Exception as e:
        logging.exception(f"Error fetching count_optimization_total_records: {e}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "count_optimization_total_records",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner,
                "comments": "Execution failed while getting total count of optimization records",
                "module_name": "Centralized View",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        response = {
                "flag": False,
                "message": "something went wrong while fetching optmization total count"
            }
    return response

def count_optimization_inprogress_records(data):
    """
    Counts the Inprogress records of optimization data for one or more tenants within an optional date range

        Parameters:
        data (dict): Dictionary of input parameters with the following important keys:
            - selected_tenant (str): Name of the tenant to filter records by.
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) to filter by created_date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) to filter by created_date.
            - request_received_at (str): Timestamp of when the request was received, used in audit logging.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if the query was successful; False if an error occurred.
            - data (dict): Number of records along with title
            - message (str): Success or error message describing the outcome.

    """
       
    logging.info(f"### Fetching count_optimization_inprogress_records  - {data}")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", None)
    db_name = data.get("db_name","central_db")
    session_id = data.get("session_id", None)
    db_name = data.get("db_name", "central_db")
    partner = data.get("partner")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        # connecting to the central database
        database = DB(db_name, **db_config)
        # Query to fetch optimization data
        base_query = """
            SELECT COUNT(id) AS record_count FROM vw_all_combined_optimization where progress::int < 100
        """
        query,params = build_query(base_query,data)
        # Execute the query and fetch the data
        result = database.execute_query(query, params=params)
        if result is None or not hasattr(result, "iloc"):
            raise Exception("Query execution failed")

        record_count = int(result.iloc[0]["record_count"]) if not result.empty else 0
        response = {
            "flag": True,
            "data": {"count": record_count, "title": "Inprogress"},
            "message": "Successfully fetched the count of Inprogress records",
        }
 
    except Exception as e:
        logging.exception(f"Error fetching count_optimization_inprogress_records : {e}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "count_optimization_inprogress_records",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner,
                "comments": "Execution failed while getting count of optimization inprogress records",
                "module_name": "Centralized View",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        response = {
                "flag": False,
                "message": "something went wrong while fetching optmization inprogress count"
            }
    return response

def count_optimization_completed_records(data):
    """
    Counts the Completed records of optimization data for one or more tenants within an optional date range

        Parameters:
        data (dict): Dictionary of input parameters with the following important keys:
            - selected_tenant (str): Name of the tenant to filter records by.
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) to filter by created_date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) to filter by created_date.
            - request_received_at (str): Timestamp of when the request was received, used in audit logging.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if the query was successful; False if an error occurred.
            - data (dict): Number of records along with title
            - message (str): Success or error message describing the outcome.

    """
       
    logging.info(f"### Fetching count_optimization_completed_records :{data}")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", None)
    db_name = data.get("db_name","central_db")
    session_id = data.get("session_id", None)
    db_name = data.get("db_name", "central_db")
    partner = data.get("partner")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        # connecting to the central database
        database = DB(db_name, **db_config)
        # Query to fetch optimization data
        base_query = """
            SELECT COUNT(id) AS record_count FROM vw_all_combined_optimization where progress::int = 100
        """
        query,params = build_query(base_query,data)
        # Execute the query and fetch the data
        result = database.execute_query(query, params=params)
        if result is None or not hasattr(result, "iloc"):
            raise Exception("Query execution failed")

        record_count = int(result.iloc[0]["record_count"]) if not result.empty else 0
        response = {
            "flag": True,
            "data": {"count": record_count, "title": "Completed"},
            "message": "Successfully fetched the count of Completed records",
        }
 
    except Exception as e:
        logging.exception(f"Error fetching count_optimization_completed_records : {e}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "count_optimization_completed_records",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner,
                "comments": "Execution failed while getting count of optimization completed records",
                "module_name": "Centralized View",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        response = {
                "flag": False,
                "message": "something went wrong fetching  completed count"
            }
    return response

def count_optimization_charges_to_be_pushed_records(data):
    """
    Counts the Charges to be pushed records of optimization data for one or more tenants within an optional date range

        Parameters:
        data (dict): Dictionary of input parameters with the following important keys:
            - selected_tenant (str): Name of the tenant to filter records by.
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) to filter by created_date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) to filter by created_date.
            - request_received_at (str): Timestamp of when the request was received, used in audit logging.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if the query was successful; False if an error occurred.
            - data (dict): Number of records along with title
            - message (str): Success or error message describing the outcome.

    """
       
    logging.info(f"### Fetching count_optimization_charges_to_be_pushed_records : {data}")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", None)
    db_name = data.get("db_name","central_db")
    session_id = data.get("session_id", None)
    db_name = data.get("db_name", "central_db")
    partner = data.get("partner")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        # connecting to the central database
        database = DB(db_name, **db_config)
        # Query to fetch optimization data
        base_customer_query = """
            SELECT COUNT(id) AS record_count FROM vw_all_customer_optimization where pushed_charges = false
        """
        base_carrier_query = """
            SELECT COUNT(id) AS record_count FROM vw_all_carrier_optimization where pushed_charges = false
        """
        customer_query,customer_params  = build_query(base_customer_query,data)
        carrier_query,carrier_params  = build_query(base_carrier_query, data)
        # Execute the query and fetch the data

        # Function to execute one query
        def run_query(query, params):
            """Function to execute one query"""
            result_df = database.execute_query(query, params=params)
            logging.info(f"### result_df: {result_df}")
            record_count = int(result_df.iloc[0]["record_count"]) if not result_df.empty else 0
            return record_count
        
        # Run both queries in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            future_customer = executor.submit(run_query, customer_query, customer_params)
            future_carrier = executor.submit(run_query, carrier_query, carrier_params)
            logging.info(f"### future_customer - {future_customer}")
            logging.info(f"### future_carrier - {future_carrier}")
            customer_count = future_customer.result()
            carrier_count = future_carrier.result()

        # Total
        record_count = customer_count + carrier_count
        logging.info(f"### count_optimization_charges_to_be_pushed_records Customer: {customer_count}, Carrier: {carrier_count}, Total: {record_count}")

        response = {
            "flag": True,
            "data": {"count": record_count, "title": "Charges to be Pushed"},
            "message": "Successfully fetched the count of Completed records",
        }
 
    except Exception as e:
        logging.exception(f"Error fetching count_optimization_charges_to_be_pushed_records : {e}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "count_optimization_charges_to_be_pushed_records",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner,
                "comments": "Execution failed while getting count of optimization charges to be pushed records",
                "module_name": "Centralized View",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        response = {
                "flag": False,
                "message": "something went wrong while fetching optmization charges to be pushed count"
            }
    return response

def linechart_monthly_optimization_volume(data):

    """
    Generates a line chart summary of monthly optimization volume..

    Parameters:
        data (dict): Dictionary containing the following keys:
            - selected_tenant (str): Name of the tenant to filter records by.
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) to filter by created_date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) to filter by created_date.
            - username (str): Username making the request.
            - sessionID (str): Unique session identifier.
            - Partner (str): Partner or tenant name.
            - request_received_at (str): Timestamp of the request.

    Returns:
        dict: A dictionary with the following structure:
            {
                "flag": bool,  # Indicates success or failure
                "data": {
                    title": "Monthly Optmization Volume",
                    "chart_type": "line",
                    data: [{}],
                    "angleField": "count",
                    "colorField": "status",
                    "height": 300,
                    "width": 300
                }
                "message": str  # Present only on failure
            }

    Exceptions:
        All exceptions are caught and logged to the error log table, with relevant request context.
    """

    logging.info(f"### Fetching linechart_monthly_optimization_volume : {data}")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", None)
    db_name = data.get("db_name","central_db")
    session_id = data.get("session_id", None)
    partner = data.get("partner")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        database = DB(db_name, **db_config)
        base_query = """
            SELECT 
                TO_CHAR(created_date, 'Mon') AS month,
                COUNT(CASE WHEN progress = '100' THEN 1 END) AS "completed",
                COUNT(CASE WHEN progress != '100' THEN 1 END) AS "inprogress"
            FROM 
                public.vw_all_combined_optimization
        """
        query, params = build_query(base_query, data)
        # Handle WHERE clause properly # if AND in query and WHERE not in query replace first AND with WHERE
        if "WHERE" not in query and "AND" in query:
            query = query.replace("AND", "WHERE", 1)  # Only replace first occurrence
        query += " GROUP BY TO_CHAR(created_date, 'Mon'), EXTRACT(MONTH FROM created_date) ORDER BY EXTRACT(MONTH FROM created_date);"
        chart_df = database.execute_query(query, params=params)

        if chart_df is None or chart_df.empty:
            chart_data = []
        else:
            chart_df.rename(columns={"completed": "Completed", "inprogress": "Inprogress"}, inplace=True)
            chart_data = chart_df.to_dict(orient="records")

        response = {
            "flag": True,
            "data": {
                "title": "Monthly Optmization Volume",
                "chart_type": "line",
                "data": chart_data,
                "angleField": "count",
                "colorField": "status",
                "height": 300,
                "width": 300
                }
            }

    except Exception as e:
        logging.exception(f"Error fetching linechart_monthly_optimization_volume : {e}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "linechart_monthly_optimization_volume",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner,
                "comments": "Execution failed while getting monthly optimization volume linechart data",
                "module_name": "Centralized View",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        response = {
                "flag": False,
                "message": "something went wrong while generating monthly optimization volume"
            }
    return response

def stackbar_optimization_total_vs_pushed_charges(data):
    """
    Generates a stackbar chart summary of Total charges vs pushed charges..
    Parameters:
        data (dict): Dictionary containing the following keys:
            - selected_tenant (str): Name of the tenant to filter records by.
            - db_name (str): Name of the database to connect to. Defaults to 'central_db'.
            - start_date (str): (Optional) Start date (YYYY-MM-DD) to filter by created_date.
            - end_date (str): (Optional) End date (YYYY-MM-DD) to filter by created_date.
            - username (str): Username making the request.
            - sessionID (str): Unique session identifier.
            - Partner (str): Partner or tenant name.
            - request_received_at (str): Timestamp of the request.

    Returns:
        dict: A dictionary with the following structure:
            {
                "flag": bool,  # Indicates success or failure
                "data": {
                    "title": "Total Changes vs Charges Pushed",
                    "chart_type": "stackedBar",
                    "data": list[dict],
                    "xField": "serviceprovider",
                    "yField": "count",
                    "seriesField": "type",
                    "height": 300,
                    "width": 500
                }
                "message": str  # Present only on failure
            }

    Exceptions:
        All exceptions are caught and logged to the error log table, with relevant request context.
    """

    logging.info(f"### Request received data stackbar_optimization_total_vs_pushed_charges:{data}")
    tenant = data.get("selected_tenant", "All")
    db_name = data.get("db_name", "central_db")
    username = data.get("username", "")
    session_id = data.get("sessionID", "")
    partner_name = data.get("Partner", "")
    request_time = data.get("request_received_at", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")

    try:
        central_db = DB(db_name, **db_config)
        where_clause = " WHERE serviceprovider IS NOT NULL "

        if tenant != 'All':
            where_clause += f" AND tenant = '{tenant}' "
        if start_date and end_date:
            where_clause += f" AND created_date BETWEEN '{start_date}' AND '{end_date}' "
        elif start_date:
            where_clause += f" AND created_date >= '{start_date}' "
        elif end_date:
            where_clause += f" AND created_date <= '{end_date}' "
        query = f"""
            SELECT 
                serviceprovider,
                'Charges Pushed' AS type,
                SUM(pushed_charges_amount) AS count
            FROM 
                vw_all_combined_optimization
            {where_clause}
            GROUP BY 
                serviceprovider
            UNION ALL
            SELECT 
                serviceprovider,
                'Total Charges' AS type,
                SUM(total_charges) AS count
            FROM 
                vw_all_combined_optimization
            {where_clause}
            GROUP BY 
                serviceprovider
            ORDER BY 
                serviceprovider, type;
        """
        chart_df = central_db.execute_query(query,True)

        if chart_df is None or chart_df.empty:
            chart_data = []
        else:
            chart_data = chart_df.to_dict(orient="records")

        response = {
            "flag": True,
            "data": {
                "title": "Total Changes vs Charges Pushed",
                "chart_type": "stackedBar",
                "data": chart_data,
                "xField": "serviceprovider",
                "yField": "count",
                "seriesField": "type",
                "height": 300,
                "width": 500
            }
        }

    except Exception as e:
        logging.exception(f"### stackbar_optimization_total_vs_pushed_charges exception - {e}")
        response = {"flag": False, "message": "Something went wrong while fetching Total vs Pushed charges"}
        common_utils_database.log_error_to_db(
            {
                "service_name": "stackbar_optimization_total_vs_pushed_charges",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "session_id": session_id,
                "tenant_name": partner_name,
                "comments": "Execution failed while getting optimization total vs pushed charges stackbar data ",
                "module_name": "Centralized View",
                "request_received_at": request_time,
            },
            "error_log_table",
        )
    return response