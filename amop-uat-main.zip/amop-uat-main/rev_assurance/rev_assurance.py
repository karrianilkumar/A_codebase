"""
@Author1 : Mohammad Burhan

Created Date: 20-05-25
"""

import base64
import io
import json
import os
import re
import time
from datetime import datetime, timezone
from io import BytesIO
from collections import defaultdict

# Importing the necessary Libraries
import boto3
import numpy as np
import pandas as pd
import requests
from data_transfer_main import DataTransfer
from dateutil.relativedelta import relativedelta
from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.worksheet.worksheet import Worksheet

from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import binascii



logging = Logging(name="sim_management")

db_config_withoutfilter = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}


##to fetch the service providers ids for each tenants separately used to get the serviceprovider ids in generic way
def load_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    # FILE_PATH = "tenant_based_serviceproviders.json"
    file_path = "tenant_based_serviceproviders.json"
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"### Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs


def load_integration_authentication_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    # FILE_PATH = "tenant_based_integration_authentication_id.json"
    file_path = "tenant_based_integration_authentication_id.json"
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"### Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs


def get_integration_authentication_id_by_unique_name(json_data, tenant_name):
    logging.info(f"### Tenant Name: {tenant_name}")
    """Fetches 'main_name' of a provider based on its unique name."""
    return json_data.get(tenant_name, {}).get("INTEGRATION_AUTHENTICATION_ID", None)


def get_integration_id_by_unique_name(json_data, tenant_name, unique_name):
    """Fetches 'main_name' of a provider based on its unique name."""
    return (
        json_data.get(tenant_name, {}).get(unique_name, {}).get("integration_id", None)
    )


def clean_tuple(tpl):
    """
    Cleans and formats a tuple input into a string representation.

    Args:
        tpl (tuple or None): The input tuple to clean. Can be None, a single-item tuple, or a normal tuple.

    Returns:
        str or tuple: 
            - If input is None or not a tuple, returns an empty tuple `()`.
            - If it's a single-item tuple, returns a string like "('item')".
            - If it's a valid multi-item tuple, returns its string representation.
            - If an exception occurs, returns an empty tuple.
    """
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        logging.info(f"### Exception while converting {e}")
        return ()


def db_config_maker(
    user, db_config_making, tenant_database, tenant_name, role_name, readme_flag
):
    """
    Generates and updates the database configuration dictionary for a user based on their role, tenant, and associated data.
    This function retrieves and processes customer, service provider, customer group, rate plan, and feature code information
    for a given user and tenant. It updates the provided database configuration dictionary (`db_config_making`) with the relevant
    access and filtering information required for subsequent database operations.

    Args:
        user (str): The username or client ID of the user for whom the configuration is being generated.
        db_config_making (dict): The initial database configuration dictionary to be updated.
        tenant_database (str): The name of the tenant-specific database.
        tenant_name (str): The name of the tenant.
        role_name (str): The role of the user (e.g., 'Super Admin', 'Partner Admin', etc.).
        readme_flag (bool): Flag to determine the query logic for user identification.
    Returns:
        dict: The updated database configuration dictionary containing user-specific access filters such as customers,
                service providers, service provider IDs, customer rate plan names, feature codes, and billing account numbers.
    Notes:
        - If the user has a 'Super Admin' or 'Partner Admin' role, the function returns the original configuration without modification.
        - The function interacts with both the common utilities database and the tenant-specific database to gather required information.
        - Handles various data extraction and transformation scenarios, including JSON parsing and tuple/list conversions.
        - Logs exceptions and information for debugging and traceability.
    """
    if role_name in ("Super Admin", "Partner Admin"):
        return db_config_making
    common_utils_database = DB("common_utils", **db_config_making)
    tenant_data = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"]
    )

    tenant_id = tenant_data["id"].to_list()[0]
    # parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    if tenant_id:
        tenant_id = int(tenant_id)
    if readme_flag:
        query = "select customers,service_provider,customer_group from user_module_tenant_mapping where client_id = %s and tenant_id= %s"
    else:
        query = "select customers,service_provider,customer_group from user_module_tenant_mapping where user_name = %s and tenant_id= %s"

    filters = common_utils_database.execute_query(query, params=[user, tenant_id])

    database = DB(tenant_database, **db_config)
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except Exception as e:
        logging.error(f"Exception while extracting 'customer_group' from filters: {e}")
        customer_group = None    

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name = None
    customer_names = None
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups",
            {"name": customer_group},
            [
                "customer_names",
                "rate_plan_name",
                "billing_account_number",
                "feature_codes",
            ],
        )

        if not customer_group_data.empty:
            try:
                customer_rate_plan_name = tuple(
                    json.loads(customer_group_data["rate_plan_name"].to_list()[0])
                )
            except Exception as e:
                logging.exception(f"### Error extracting rate_plan_name: {e}")
            try:
                customer_names = tuple(
                    json.loads(customer_group_data["customer_names"].to_list()[0])
                )

            except Exception as e:
                logging.exception(f"### Error extracting rate_plan_name: {e}")
                customer_names = None

            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[
                    0
                ]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number = None

            except Exception as e:
                logging.exception(f"### Error extracting billing_account_number: {e}")
                billing_account_number = None

            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception(f"### Error extracting feature_codes: {e}")
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))

        except Exception as e:
            logging.error(f"Exception while extracting 'customer' from filters: {e}")
            customer = None     
    else:
        customer = customer_names
    customer = clean_tuple(customer)
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = "SELECT id FROM serviceprovider WHERE service_provider_name = %s"
            params = [service_provider[0],]
        else:
            query = "SELECT id FROM serviceprovider WHERE service_provider_name IN %s"
            params = (safe_in_clause(service_provider),)

        service_provider_id = tuple(
            database.execute_query(query, params=params)["id"].to_list()
        )

    except Exception as e:
        logging.error(f"Exception while extracting 'service_provider' and  service_provider_id : {e}")
        service_provider = None
        service_provider_id = None  
    try:
        customers_query = """select customer_name from customers where tenant_id= %s and is_active=True and created_by=%s
        """
        customers_df = database.execute_query(customers_query, params=[tenant_id,user])
        if not customers_df.empty:
            existing_customers = customers_df["customer_name"].to_list()
            if existing_customers:
                # Clean the customer value
                if isinstance(customer, str):
                    customer = customer.strip(
                        "()'"
                    )  # Clean customer from extra parentheses and quotes
                    customer = (customer,)  # Convert it into a tupl

                # Now convert tuple to list
                customer_list = list(customer)
                # Clean and fix the list by splitting the elements and ensuring they are correctly quoted
                fixed_customer_list = []

                # Split the string into items and strip any unwanted characters
                for item in customer_list[0].split("', '"):
                    fixed_customer_list.append(
                        item.strip("',")
                    )  # Remove extra quotes and commas
                logging.info(f"### customer_list before extend: { fixed_customer_list}")

                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info(f"### customer_list after extend: {fixed_customer_list}")

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info(f"### final customer tuple:{customer}")
                customer = clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(
            f"### Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}"
        )
    try:
        customer_rate_plan_query = """select rate_plan_name from customerrateplan where tenant_id= %s and is_active=True and created_by= %s
        """
        customer_rate_plan_df = database.execute_query(customer_rate_plan_query, params=[tenant_id,user])
        if not customer_rate_plan_df.empty:
            existing_rate_plans = customer_rate_plan_df["rate_plan_name"].to_list()
            if existing_rate_plans:
                # Clean the customer value
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_name = customer_rate_plan_name.strip(
                        "()'"
                    )  # Remove ( and ) and ' from start and end
                    customer_rate_plan_name = (
                        customer_rate_plan_name,
                    )  # Now correctly convert it to tuple

                # Now convert tuple to list
                customer_rate_plan_list = list(customer_rate_plan_name)
                fixed_customer_rate_plan_list = []

                # Split the string into items and strip any unwanted characters
                for item in customer_rate_plan_list[0].split("', '"):
                    fixed_customer_rate_plan_list.append(
                        item.strip("',")
                    )  # Remove extra quotes and commas
                logging.info(f"### customer_list before extend :  {customer_rate_plan_list}")

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info(f"### customer_list after extend:  {fixed_customer_rate_plan_list}")

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info(f"### final customer tuple : {customer_rate_plan_name}")

    except Exception as e:
        logging.exception(
            f"### Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}"
        )

    logging.info(f"### customer at the end of customer : {customer}")
    db_config_making["customers"] = customer
    db_config_making["service_providers"] = service_provider
    db_config_making["service_provider_id"] = service_provider_id
    db_config_making["customer_rate_plan_name"] = customer_rate_plan_name
    db_config_making["feature_codes"] = feature_codes
    db_config_making["billing_account_number"] = billing_account_number
    return db_config_making


### Main function to call the respective function based on the path
def function_caller(data, path , access_token):
    """
    Main function caller that handles database configuration setup and routes service-related requests.

    This function:
    1. Initializes database configuration from environment variables.
    2. Determines the user and tenant-specific configuration depending on auth type (access token, SQS call, or service account).
    3. Routes the request to the appropriate handler function based on the given path.

    Args:
        data (dict): Request payload containing user/tenant information (e.g., username, db_name, etc.).
        path (str): API endpoint path being invoked.
        access_token (str): Access token used to determine auth flow.

    Returns:
        dict: Result of the invoked handler function, or error message if path is invalid.
    """
    global db_config

    # Step 1: Initialize base DB config
    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

    user = data.get("username") or data.get("user_name")
    tenant_database = data.get("db_name")
    sqs_call = data.get("sqs_call", False)

    logging.info(f"### Received data: {data}")
    logging.info(f"### Received path: {path}")

    # Step 2: Build DB config based on auth flow
    if not access_token:
        role_name = data.get("role_name") or data.get("role") or "Super Admin"
        tenant_name = data.get("tenant_name") or data.get("tenant") or data.get("Partner") or ""
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"

        db_config = db_config_maker(user, db_config, tenant_database, tenant_name, role_name, readme_flag=False)
        logging.info("### db_config created for user-based flow")
    elif sqs_call:
        logging.info("### SQS call detected, skipping auth-based DB setup")
    else:
        logging.info("### Using service account for DB config")
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        user = data.get("client_id", "")
        service_data = common_utils_database.get_data("service_accounts", {"client_id": user})

        if service_data.empty:
            logging.warning(f"### Invalid client ID: {user}")
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        role_name = service_data["role"].to_list()[0]
        tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name})
        tenant_database = tenant_data["db_name"].to_list()[0]

        db_config = db_config_maker(user, db_config, tenant_database, tenant_name, role_name, readme_flag=False)

    # Step 3: Map API paths to handler functions
    path_function_map = {
        "/add_service_line_data": add_service_line_data,
        "/submit_service_product_data": submit_service_product_data,
        "/submit_assign_service_data": submit_assign_service_data,
        "/deactivate_service_product": deactivate_service_product,
        "/rev_assurance_button_upload_download": rev_assurance_button_upload_download,
        "/handle_add_service_line_upload": handle_add_service_line_upload,
        "/handle_add_service_product_upload": handle_add_service_product_upload,
        "/handle_deactivate_service_product": handle_deactivate_service_product_upload,
        "/handle_assign_service_upload": handle_assign_service_upload,
        "/handle_assign_service": handle_assign_service_upload,
        "/assign_service_data": assign_service_data,
        "/add_service_product": add_service_product,
        "/add_service_line": add_service_line,
    }

    # Step 4: Route request to appropriate handler
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result


def get_user_acess_filters(username, database, tenant_name, role_name):
    """
    Fetches customer-related access filters for a user based on their role, tenant, 
    and configured access control mappings. Used to control data visibility 
    for modules where user access is restricted.

    Args:
        username (str): The username of the logged-in user.
        database (DB): The initial database object (may be overwritten after tenant fetch).
        tenant_name (str): The tenant name to identify access context.
        role_name (str): The role of the user (e.g., "Only Use", "Super Admin").

    Returns:
        tuple: A tuple of filter values:
            - customers (tuple or None): List of allowed customer names.
            - service_providers (tuple or None): List of accessible service providers.
            - billing_account_number (tuple or None): Billing account numbers allowed.
            - feature_codes (tuple or None): Feature codes visible to the user.
            - customer_rate_plan_name (tuple or None): Associated rate plans for the user.
"""
    common_utils_database = DB(
        os.environ["COMMON_UTILS_DATABASE"], **db_config_withoutfilter
    )
    if role_name in ("Super Admin", "Partner Admin"):
        return None, None, None, None, None
    tenant_data = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id", "db_name", "parent_tenant_id"]
    )

    tenant_id = tenant_data["id"].to_list()[0]
    db_name = tenant_data["db_name"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    database = DB(db_name, **db_config_withoutfilter)
    if tenant_id:
        tenant_id = int(tenant_id)
    if parent_tenant_id and role_name in ("Only Use"):
        try:
            # Sample query execution
            query = """SELECT customers, service_provider, customer_names, rate_plan_name, feature_codes, billing_account_number FROM tenant_based_partner_admin_filters WHERE tenant_id=%s
            """
            df = common_utils_database.execute_query(query, params=[tenant_id])

            # Initialize sets to accumulate unique values
            merged_customers = set()
            merged_service_provider = set()
            merged_rate_plan_name = set()
            merged_feature_codes = set()
            merged_billing_account_number = set()

            # Iterate over each row and collect values
            for index, row in df.iterrows():
                # Merge customers and customer_names
                for col in ["customers", "customer_names"]:
                    try:
                        values = json.loads(row[col]) if row[col] else []
                        merged_customers.update(values)
                    except Exception as e:
                        logging.info(f"Error parsing {col}: {e}")

                # Process other columns
                for col, target in [
                    ("service_provider", merged_service_provider),
                    ("rate_plan_name", merged_rate_plan_name),
                    ("feature_codes", merged_feature_codes),
                ]:
                    try:
                        values = json.loads(row[col]) if row[col] else []
                        target.update(values)
                    except Exception as e:
                        logging.info(f"Error parsing {col}: {e}")

                # Handle billing_account_number separately (not a list)
                billing_value = row["billing_account_number"]
                if pd.notna(billing_value):
                    merged_billing_account_number.add(str(billing_value))

            # Final variables
            customers = tuple(sorted(merged_customers)) if merged_customers else None
            service_providers = (
                tuple(sorted(merged_service_provider))
                if merged_service_provider
                else None
            )
            customer_rate_plan_name = (
                tuple(sorted(merged_rate_plan_name)) if merged_rate_plan_name else None
            )
            feature_codes = (
                tuple(sorted(merged_feature_codes)) if merged_feature_codes else None
            )
            billing_account_number = (
                tuple(sorted(merged_billing_account_number))
                if merged_billing_account_number
                else None
            )
            return (
                customers,
                service_providers,
                billing_account_number,
                feature_codes,
                customer_rate_plan_name,
            )
        except Exception as e:
            logging.exception(f"### Error while fetching filters of Partner for the tenant: {e}" )
            return None, None, None, None, None
    # filters = common_utils_database.get_data(
    #     "users", {"username": username}, ["customers", "service_provider", "customer_group"]
    # )
    query = "select customers,service_provider,customer_group from user_module_tenant_mapping where user_name =%s and tenant_id= %s"
    filters = common_utils_database.execute_query(query, params=[username,tenant_id])

    try:
        customer_group = filters["customer_group"].to_list()[0]
    except Exception as e:
        logging.error(f"Exception while extracting 'customer_group' from filters: {e}")
        customer_group = None

    customer_group_data = None
    customer_rate_plan_name = None
    billing_account_number = None
    feature_codes = None
    customer_names = None

    if customer_group:
        customer_group_data = database.get_data(
            "customergroups",
            {"name": customer_group},
            [
                "customer_names",
                "rate_plan_name",
                "billing_account_number",
                "feature_codes",
            ],
        )
        logging.info(f"### customer_group_data  : {customer_group_data}")

        if not customer_group_data.empty:
            try:
                customer_rate_plan_name = tuple(
                    json.loads(customer_group_data["rate_plan_name"].to_list()[0])
                )
            except Exception as e:
                logging.exception(f"### Error extracting rate_plan_name: {e}")
            try:
                customer_names = tuple(
                    json.loads(customer_group_data["customer_names"].to_list()[0])
                )
            except Exception as e:
                logging.exception(f"### Error extracting rate_plan_name:  {e}")
                customer_names = None

            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[
                    0
                ]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number = None

            except Exception as e:
                logging.exception(f"### Error extracting billing_account_number: {e}")
                billing_account_number = None

            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception(f"### Error extracting feature_codes: {e}")
    if customer_names is None:
        try:
            customers = tuple(json.loads(filters["customers"].to_list()[0]))
        except Exception as e:
            logging.error(f"Exception while extracting 'customers' from filters: {e}")
            customers = None    
    else:
        customers = customer_names

    try:
        service_providers = tuple(json.loads(filters["service_provider"].to_list()[0]))

    except Exception as e:
        logging.error(f"Exception while extracting 'service_providers' from filters: {e}")
        service_providers = None    
    logging.info(f"### customers : {customers}")
    try:
        customers_query = """
        select customer_name from customers where tenant_id=%s and is_active=True and created_by=%s
        """
        customers_df = database.execute_query(customers_query, params=[tenant_id,username])
        if not customers_df.empty:
            existing_customers = customers_df["customer_name"].to_list()
            if existing_customers:
                # Correct merge without corruption
                if not customers:
                    customers = tuple(existing_customers)
                else:
                    customers = tuple(sorted(set(customers).union(existing_customers)))
                logging.info(f"### final customers tuple: : {customers}")
    except Exception as e:
        logging.exception(
            f"### Error while fetching the customers for the user {username} in tenant {tenant_name}: {e}"
        )
    # customers=clean_tuple(customers)
    try:
        customer_rate_plan_query = """select rate_plan_name from customerrateplan where tenant_id=%s and is_active=True and created_by=%s
        """
        customer_rate_plan_df = database.execute_query(customer_rate_plan_query, params=[tenant_id,username])
        if not customer_rate_plan_df.empty:
            existing_rate_plans = customer_rate_plan_df["rate_plan_name"].to_list()
            if existing_rate_plans:
                # Clean the customer value
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_name = customer_rate_plan_name.strip(
                        "()'"
                    )  # Remove ( and ) and ' from start and end
                    customer_rate_plan_name = (
                        customer_rate_plan_name,
                    )  # Now correctly convert it to tuple

                # Now convert tuple to list
                customer_rate_plan_list = list(customer_rate_plan_name)
                fixed_customer_rate_plan_list = []

                # Split the string into items and strip any unwanted characters
                for item in customer_rate_plan_list[0].split("', '"):
                    fixed_customer_rate_plan_list.append(
                        item.strip("',")
                    )  # Remove extra quotes and commas
                logging.info(f"### customer_list before extend:  {customer_rate_plan_list}")

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info(f"### customer_list after extend: {fixed_customer_rate_plan_list}")

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info(f"### final customer tuple: {customer_rate_plan_name}")

    except Exception as e:
        logging.exception(
            f"### Error while fetching the customers for the user {username} in tenant {tenant_name}: {e}"
        )
    # customer_rate_plan_name=clean_tuple(customer_rate_plan_name)
    return (
        customers,
        service_providers,
        billing_account_number,
        feature_codes,
        customer_rate_plan_name,
    )

def get_service_account_context(username):
    """
    Extracts the service account details from the provided client id
    and returns a dictionary containing the service account, user details and tenant details.
    Args:
        username : (str): The username or client ID of the service account.
    Returns:
        dict: A dictionary containing the service account, user details, and tenant details in succsess.
        None: If the username is not provided or if an error occurs while fetching the service account details.
    """

    if not username:
        logging.error(f"### get_service_account_context function: No username provided - {username}")
        return None
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        service_account = common_utils_database.get_data(
            "service_accounts", {"client_id": username}
        ).to_dict(orient="records")[0]
        logging.info(
            f"### add_service_line_data function: service_account: {service_account}"
        )
        role = service_account.get("role", "")
        tenant_name = service_account["tenant"]
        tenant_name = "Altaworx" if tenant_name == "Altaworx Test" else tenant_name
        tenant_database = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["db_name"]
        )["db_name"].to_list()[0]
        database = DB(tenant_database, **db_config_withoutfilter)
        user_details = common_utils_database.get_data(
            "users", {"username": username}, ["first_name", "last_name"]
        )
        if user_details.empty:
            first_name = ""
            last_name = ""
        else:
            first_name = user_details["first_name"].to_list()[0]
            last_name = user_details["last_name"].to_list()[0]
        return {
            "service_account": service_account,
            "role": role,
            "tenant_name": tenant_name,
            "database": database,
            "db_name": tenant_database,
            "first_name": first_name,
            "last_name": last_name,
        }
    except Exception as e:
        logging.exception(
            f"### get_service_account_context function: Error while fetching service account details for username {username}: {e}"
        )
        return None


# Helper: Ensure tuple formatting is always safe
def safe_in_clause(value_or_list):
    """
    Ensures the input is returned as a tuple, useful for safely constructing SQL 'IN' clauses.

    Args:
        value_or_list (Any): A single value or a list/tuple of values.

    Returns:
        tuple: A tuple containing the input values. If a single value is provided,
               it is wrapped in a tuple.
    """
    if isinstance(value_or_list, (list, tuple)):
        return tuple(value_or_list)
    return (value_or_list,)





def add_service_line_dropdown_data(data):
    """
    Fetches and constructs dropdown data for the "Add Service Line" UI component.
    This function retrieves various dropdown options and dependent dropdown mappings required for the "Add Service Line" feature, based on the provided tenant, user, and service provider context. It performs multiple database queries to gather data such as customer rate plans, providers, service types, products, usage plan groups, and their relationships. The function also handles parent tenant resolution, integration authentication, and logs audit and error information.
    Args:
        data (dict): Input data containing context for the dropdowns. Expected keys include:
            - "username" (str): The username of the requester.
            - "tenant_name" (str): The name of the tenant.
            - "session_id" (str): The session identifier.
            - "module_name" (str): The module name.
            - "service_provider" (str): The service provider name.
            - "db_name" (str): The tenant-specific database name.
            - "customer_name" (str): The customer name.
            - "request_received_at" (str/datetime): Timestamp when the request was received.
    Returns:
        dict: A response dictionary with the following structure:
            - "flag" (bool): Indicates success or failure.
            - "message" (str): Success or error message.
            - "response_data" (dict): Contains dropdown data if successful, otherwise empty.
    Dropdown data keys in "response_data" may include:
        - "customer_rate_plan_dropdown": List of customer rate plan names.
        - "rev_provider": List of provider descriptions or dicts with provider info.
        - "service_type": List of service type descriptions with IDs.
        - "rev_product": List of product descriptions with IDs.
        - "rev_usage_plan_group": List of usage plan group descriptions.
        - "rev_provider_id_map": Mapping of provider descriptions to provider IDs.
        - "rev_package": Dependent dropdown structure for packages.
        - "rate": Dependent dropdown structure for rates.
        - "rev_product_rate": List of products with rates.
        - "rev_package_rate": Structured list of packages with associated products and rates.
    Raises:
        Logs exceptions and errors internally, returning a failure response if any error occurs.
    Side Effects:
        - Logs audit information and errors to the database.
        - Writes informational and error logs.
    """
    logging.info(f"### add_service_line_dropdown_data function called with data: {data}")

    # Validate db_config for required keys
    required_db_keys = {"host", "port", "user", "password"}
    if not all(k in db_config for k in required_db_keys):
        logging.error("### db_config is missing required keys.")
        return {"flag": False, "response_data": {}, "message": "Database configuration is invalid."}

    try:
        del db_config["tenant_ids"]
    except Exception as e:
        logging.warning(
            f"### add_service_line_dropdown_data function: Exception deleting tenant_ids from db_config: {e}"
        )
    # Start time and date calculation
    start_time = time.time()
    username = data.get("username", None)
    tenant_name = data.get("tenant_name", None)
    session_id = data.get("session_id", None)
    module_name = data.get("module_name", None)
    service_provider = data.get("service_provider", None)
    request_received_at = data.get("request_received_at")

    # Database Connection
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        response_data = {}
        service_provider = data.get("service_provider", None)

        parent_tenant_id_df = common_utils_database.execute_query(
            "SELECT parent_tenant_id FROM tenant WHERE tenant_name = %s",
            params=[tenant_name]
        )
        logging.info(f"### add_service_line_dropdown_data function: parent_tenant_id_df: {parent_tenant_id_df}")
        if not parent_tenant_id_df.empty:
            parent_tenant_id = parent_tenant_id_df["parent_tenant_id"].to_list()[0]

            if parent_tenant_id is not None:
                parent_tenant_id = int(parent_tenant_id)
                parent_tenant_name_query = """
                    SELECT tenant_name
                    FROM tenant
                    WHERE id = %s
                """
                parent_tenant_name = common_utils_database.execute_query(
                    parent_tenant_name_query, params = [parent_tenant_id]
                )["tenant_name"].to_list()[0]
                logging.info(
                    f"### add_service_line_dropdown_data function: parent_tenant_name: {parent_tenant_name}"
                )
                tenant_name = parent_tenant_name
        integration_authentication_json_data = load_integration_authentication_json()
        authentication_ids = get_integration_authentication_id_by_unique_name(
            integration_authentication_json_data, tenant_name
        )
        authentication_ids = str(authentication_ids)

        logging.info(
            f"### add_service_line_dropdown_data function in tenant {tenant_name} checkpoint authentication_ids {authentication_ids}"
        )

        # Get customer rate plan dropdown data
        logging.info(
            "### add_service_line_dropdown_data function: Fetching customer rate plan dropdown data..."
        )
        response_data["customer_rate_plan_dropdown"] = sorted(
            set(
                database.get_data(
                    "customerrateplan",
                    {"service_provider_name": service_provider, "is_active": True},
                    ["rate_plan_name"],
                )["rate_plan_name"].to_list()
            )
        )

        # Get rev provider data
        logging.info(
            "### add_service_line_dropdown_data function: Fetching rev provider data..."
        )
        response_data["rev_provider"] = sorted(
            set(
                database.get_data(
                    "rev_provider",
                    {
                        "integration_authentication_id": authentication_ids,
                        "is_active": True,
                    },
                    ["description"],
                )["description"].to_list()
            )
        )

        # Get service type data
        logging.info(
            "### add_service_line_dropdown_data function: Fetching service type data..."
        )
        response_data["service_type"] = sorted(
            set(
                database.get_data(
                    "rev_service_type",
                    {
                        "integration_authentication_id": authentication_ids,
                        "is_active": True,
                    },
                    ["description", "service_type_id"],
                )
                .apply(
                    lambda row: f"{row['description']}-{row['service_type_id']}", axis=1
                )
                .to_list()
            )
        )

        # Get rev product data
        logging.info(
            "### add_service_line_dropdown_data function: Fetching rev product data..."
        )
        response_data["rev_product"] = sorted(
            set(
                database.get_data(
                    "rev_product",
                    {
                        "integration_authentication_id": authentication_ids,
                        "is_active": True,
                    },
                    ["description", "product_id"],
                )
                .apply(lambda row: f"{row['description']}-{row['product_id']}", axis=1)
                .to_list()
            )
        )

        # Get rev usage plan group data
        logging.info(
            "### add_service_line_dropdown_data function: Fetching rev usage plan group data..."
        )
        response_data["rev_usage_plan_group"] = sorted(
            set(
                database.get_data(
                    "rev_usage_plan_group",
                    {
                        "integration_authentication_id": authentication_ids,
                        "is_active": True,
                    },
                    ["description"],
                )["description"].to_list()
            )
        )

        # Dependent dropdowns
        logging.info(
            "### add_service_line_dropdown_data function: Fetching rev_provider_id_map..."
        )
        response_data["rev_provider_id_map"] = {
            item["description"]: item["provider_id"]
            for item in sorted(
                database.get_data(
                    "rev_provider",
                    {
                        "integration_authentication_id": authentication_ids,
                        "is_active": True,
                    },
                    ["description", "provider_id"],
                ).to_dict(orient="records"),
                key=lambda x: x["description"],
            )
        }

        logging.info(
            "### add_service_line_dropdown_data function: Fetching rev_package dependent dropdown..."
        )
        response_data["rev_package"] = form_depandent_dropdown_format(
            sorted(
                database.get_data(
                    "rev_package",
                    {
                        "integration_authentication_id": authentication_ids,
                        "is_active": True,
                    },
                    ["description", "provider_id"],
                ).to_dict(orient="records"),
                key=lambda x: x["description"],
            ),
            "provider_id",
            "description",
        )

        logging.info(
            "### add_service_line_dropdown_data function: Fetching rate dependent dropdown..."
        )
        response_data["rate"] = form_depandent_dropdown_format(
            sorted(
                database.get_data(
                    "rev_product",
                    {
                        "integration_authentication_id": authentication_ids,
                        "is_active": True,
                    },
                    columns=["rate", "provider_id"],
                ).to_dict(orient="records"),
                key=lambda x: x["rate"],
            ),
            "provider_id",
            "rate",
        )
        # Step 2: Get the product list based on the authentication IDs

        logging.info(
            "### add_service_line_dropdown_data function: Fetching updated_product_list for rev_product_rate..."
        )
        updated_product_list = database.execute_query(
            """SELECT product_id, CONCAT(description, ' - ', product_id) AS description, rate FROM rev_product WHERE integration_authentication_id IN %s AND is_active = true AND is_deleted = false order by description asc""",
            params=[safe_in_clause(authentication_ids)]
        ).to_dict(orient="records")

        response_data["rev_product_rate"] = updated_product_list

        logging.info(
            "### add_service_line_dropdown_data function: Fetching package_data for rev_package_rate..."
        )
        package_data = database.execute_query(
            "SELECT package_id, MAX(description) AS description FROM rev_package GROUP BY package_id;",
            True,
        ).to_dict(orient="records")

        # Step 1: Extract the unique package_ids from package_data
        package_ids = list({package["package_id"] for package in package_data})

        package_ids = list(set(package_ids))

        # Step 2: Construct the package_data_mapping query
        package_data_mapping_query = """
            SELECT
                rp.description AS description, rp.rate AS rate, rpp.package_id AS package_id,
                rpp.product_id AS product_id, rp.provider_id AS provider_id
            FROM public.rev_package_product rpp
            INNER JOIN rev_product rp ON rp.product_id = rpp.product_id
            WHERE rpp.package_id IN %s
            AND rp.integration_authentication_id IN %s
            AND rpp.integration_authentication_id IN %s
            AND rp.is_active = TRUE AND rpp.is_active = TRUE
        """

        # Step 3: Fetch the subdescription (rate) from the database
        logging.info(
            "### add_service_line_dropdown_data function: Fetching package_product_data for rev_package_rate..."
        )
        package_product_data = database.execute_query(
            package_data_mapping_query,
            params=[
                safe_in_clause(package_ids),
                safe_in_clause(authentication_ids),
                safe_in_clause(authentication_ids),
            ]
        )

        # Check if package_product_data is a Pandas DataFrame
        if isinstance(package_product_data, pd.DataFrame):
            # Step 4: Initialize a dictionary to hold the structured result
            result = []

            # Step 5: Remove duplicate rows from package_product_data
            package_product_data = package_product_data.drop_duplicates()

            # Step 6: Process each unique package_id
            package_ids = package_product_data["package_id"].unique()

            for package_id in package_ids:
                # Extract the description for the current package_id
                package_desc = package_product_data[
                    package_product_data["package_id"] == package_id
                ]["description"].iloc[0]

                provider_id = package_product_data.loc[
                    package_product_data["package_id"] == package_id, "provider_id"
                ].iloc[0]

                # Step 6: Create a list for subdescriptions and rates for the current package_id
                subdescription_data = []

                for _, row in package_product_data[
                    package_product_data["package_id"] == package_id
                ].iterrows():
                    subdescription_data.append(
                        {
                            "subdescription": row["description"],
                            "rate": row["rate"],
                            "product_id": row["product_id"],
                        }
                    )
                # Step 8: Create the structure for this package_id
                result.append(
                    [
                        {
                            "package_id": str(package_id),
                            "description": f"{package_desc} -{package_id}",
                            "provider_id": int(provider_id),
                        },
                        subdescription_data,
                    ]
                )
        else:
            logging.warning(
                "### add_service_line_dropdown_data function: Error: The data is not a Pandas DataFrame."
            )
            result = []

        # Final response data
        response_data["rev_package_rate"] = result

        logging.info(
            "### add_service_line_dropdown_data function: Fetching rev_provider for dropdown..."
        )
        response_data["rev_provider"] = database.get_data(
            "rev_provider",
            {
                "integration_authentication_id": authentication_ids,
                "is_active": True,
            },
            ["description", "provider_id"],
        ).to_dict(orient="records")
        response_data["rev_provider"] = sorted(
            response_data["rev_provider"], key=lambda x: x["description"]
        )
        logging.info(
            "### add_service_line_dropdown_data function: The drop down data is fetched"
        )
        message = "add_service_line data sent successfully"
        response = {"flag": True, "message": message, "response_data": response_data}

        
        return response
    except Exception as e:
        logging.exception(
            f"### add_service_line_dropdown_data function: Something went wrong and error is {e}"
        )
        message = "Something went wrong while getting add service line dropdown data"
        # Error Management
        error_data = {
            "service_name": "add_service_line_dropdown_data",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": username,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": f"Error while fetching add service line dropdown data for tenant {tenant_name}",
            "module_name": module_name,
            "request_received_at": request_received_at ,
        }
        logging.info(
            f"### add_service_line_dropdown_data function: Logging error to DB: {error_data}"
        )
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "response_data": {}, "message": message}


def validate_required(var, var_name):
    """
    Validates that a required variable is present and not empty.

    Args:
        var: The variable to validate (can be of any type).
        var_name (str): The name of the variable (used for error messaging).

    Raises:
        ValueError: If the variable is None or an empty string, list, or dictionary.
    """
    if var is None or (isinstance(var, (str, list, dict)) and not var):
        raise ValueError(f"Missing or invalid value for required field: {var_name}")

# Helper to normalize values (handle both single values and lists)
def normalize_value(value, default=None, as_list=False):
    """
    Normalizes the input value based on expected output format.

    - If the value is None, returns the default (as a list if as_list=True).
    - If the value is a list:
        - Returns the list as-is if as_list=True.
        - Returns the first element if as_list=False.
        - If the list is empty, uses the default or returns an empty list.
    - If the value is a single item:
        - Wraps it in a list if as_list=True.
        - Returns it as-is otherwise.

    Args:
        value: The value to normalize (can be None, single item, or list).
        default: The fallback value if `value` is None or an empty list.
        as_list (bool): Whether to always return a list.

    Returns:
        The normalized value based on input and `as_list` flag.
    """
    if value is None:
        return default if not as_list else [default] if default is not None else []
    
    if isinstance(value, list):
        if not value:  # Empty list
            return default if not as_list else []
        return value if as_list else value[0]
    
    return [value] if as_list else value

def process_activation_date(use_carrier_activation, activation_dict, service_number, submitted_data,activation_date=None):
    """
    Processes and formats the activation date based on configuration.

    If carrier-based activation is enabled, it fetches the activation date from the given dictionary.
    Otherwise, it uses the submitted activation date or falls back to a normalized date from user input.

    Args:
        use_carrier_activation (bool): Flag to determine which source of activation date to use.
        activation_dict (dict): Dictionary mapping ICCIDs to activation dates (for carrier-based activation).
        service_number (str): The ICCID of the SIM whose activation date is being processed.
        submitted_data (dict): Data submitted from the client, possibly containing activation_date.
        activation_date (str or pd.Timestamp, optional): Optional direct activation date override.

    Returns:
        tuple:
            - carrier_activation_date (str or None): ISO-formatted string if carrier activation is used.
            - default_activation_date (str or None): ISO-formatted string if user-supplied activation is used.
    """
    if use_carrier_activation:
        activation_date_val = activation_dict.get(service_number, None)
        carrier_activation_date = None
        if isinstance(activation_date_val, pd.Timestamp):
            carrier_activation_date = (
                activation_date_val.strftime("%Y-%m-%dT%H:%M:%S.")
                + f"{activation_date_val.microsecond // 1000:03d}"
            )
        return carrier_activation_date, None
    else:
        activation_date_val = activation_date if activation_date else normalize_value(submitted_data.get("activation_date", None))
        default_activation_date = None
        if activation_date_val:
            try:
                activation_date_val = pd.to_datetime(activation_date_val)
                default_activation_date = (
                    activation_date_val.strftime("%Y-%m-%dT%H:%M:%S.")
                    + f"{activation_date_val.microsecond // 1000:03d}"
                )
            except Exception as e:
                logging.warning(f"### Error formatting activation_date: {e}")
        return None, default_activation_date

def process_rate(rate_value):
    """
    Converts rate value to integer if it's a float equivalent to 0.0, else returns the original value.
    Args:
        rate_value (str | float | int): The rate value to process.
    Returns:
        int | str | float: Returns 0 as an integer if the value is 0.0, otherwise returns the original value.
    """
    return int(float(rate_value)) if rate_value and float(rate_value) == 0.0 else rate_value

def create_change_request_base(iccid, service_number, device_id, integration_authentication_id, 
                              customer_id, add_rate_plan, rate_plan_id, rev_customer_id, 
                              rev_provider_id, rev_service_type_id, rev_usage_plan_group_id,
                              carrier_activation_date, default_activation_date):
    """Create base change request dictionary with common fields"""
    return {
        "Number": service_number or None,
        "ICCID": iccid,
        "CreateRevService": True,
        "IntegrationAuthenticationId": int(integration_authentication_id),
        "AddCarrierRatePlan": False,
        "CarrierRatePlan": None,
        "CommPlan": None,
        "UseAgentAccount": False,
        "JasperDeviceID": str(float(device_id)) if device_id is not None else None,
        "SiteId": customer_id,
        "AddCustomerRatePlan": add_rate_plan,
        "CustomerRatePlan": str(rate_plan_id) if rate_plan_id else None,
        "CustomerRatePool": None,
        "DeviceId": int(float(device_id)) if device_id is not None else None,
        "RevCustomerId": str(rev_customer_id),
        "ProviderId": rev_provider_id,
        "ServiceTypeId": rev_service_type_id,
        "Prorate": True,
        "EffectiveDate": carrier_activation_date if carrier_activation_date else default_activation_date,
        "ActivatedDate": carrier_activation_date if carrier_activation_date else default_activation_date,
        "UsagePlanGroupId": rev_usage_plan_group_id,
    }

def create_bulk_change_request_dict(iccid, bulkchangeid, tenant_id, username, device_id, 
                                   service_number, subscriber_number, change_request):
    """Create bulk change request dictionary"""
    return {
        "iccid": iccid,
        "bulk_change_id": bulkchangeid,
        "tenant_id": tenant_id,
        "created_by": username,
        "status": "NEW",
        "device_id": device_id,
        "is_active": True,
        "is_deleted": False,
        "processed_by": username,
        "service_number": service_number,
        "subscriber_number": subscriber_number,
        "change_request": json.dumps(change_request),
    }

def get_package_product_mapping(revio_package_ids, integration_authentication_id, database):
    """
    Retrieves a mapping of package IDs to their associated product IDs from the database.

    Args:
        revio_package_ids (list): List of package IDs to query.
        integration_authentication_id (int): ID to filter products by integration authentication.
        database (object): Database connection object with an 'execute_query' method.

    Returns:
        dict: A dictionary mapping each package ID (int) to a list of associated product IDs (int).
              Example: {123: [456, 789], 124: [654]}
    """
    if not revio_package_ids:
        return {}
    
    placeholders = ", ".join(["%s"] * len(revio_package_ids))
    package_data_mapping_query = f"""
        SELECT DISTINCT
            rpp.package_id AS package_id,
            rpp.product_id AS product_id
        FROM public.rev_package_product rpp
        INNER JOIN rev_product rp ON rp.product_id = rpp.product_id
        WHERE rpp.package_id IN ({placeholders})
        AND rp.integration_authentication_id = %s
        AND rp.is_active = true
    """
    
    params = revio_package_ids + [integration_authentication_id]
    package_product_data = database.execute_query(
        package_data_mapping_query, params=params
    ).to_dict(orient="records")

    package_to_products = defaultdict(list)
    for entry in package_product_data:
        package_to_products[entry['package_id']].append(entry['product_id'])
    
    return package_to_products

def add_service_line_data(data):
    
    """
    Processes the submission for adding a new service line.

    This function handles two main flows based on authentication:
    1. Service Account (via z_access_token): For Readme processes.
       - Performs role checks.
       - Uses `db_config_withoutfilter` for database access.
    2. Regular User Session: For UI-driven actions.
       - Uses `db_config` (which might include user-specific filters).

    Core Logic:
    - Extracts request parameters and submitted data.
    - Fetches various IDs required for creating RevIO service records:
        - Tenant ID, Integration Authentication ID.
        - Change Type ID for "Create Rev Service".
        - Customer ID, RevIO Service Type ID, RevIO Provider ID, RevIO Usage Plan Group ID.
        - Service Provider ID (internal), Customer Rate Plan ID.
        - RevIO Customer ID.
        - RevIO Package ID and RevIO Product ID(s) based on inputs.
    - Validates that the number of ICCIDs matches the number of service numbers.
    - Creates a `sim_management_bulk_change` record to track the overall operation.
    - For each ICCID/service number pair:
        - Determines the activation date (carrier-based or user-provided).
        - Fetches associated device and subscriber information.
        - Constructs a `change_request` JSON payload for the RevIO API.
        - Creates `sim_management_bulk_change_request` records for individual line items.
    - Handles backdating logic:
        - For regular users, updates `rev_service_false` table directly.
        - For service accounts, forks separate processes for:
            - Updating backdating information.
            - Processing service numbers (`process_service_numbers`).
            - Running a DB script (`run_db_script`).
    - Logs audit information and returns a success or error response.

    Parameters:
        data (dict): The input data dictionary. Expected keys vary based on auth type but generally include:
            - For Service Account:
                - 'z_access_token' (str): The service account token.
                - 'client_id' (str): The client ID (used as username).
                - 'module_name' (str, optional): Name of the calling module.
                - 'service_provider' (str, optional): Service provider name.
                - 'revio_product', 'service_type', 'provider_name', etc. (direct in `data`).
            - For Regular User:
                - 'tenant_name' (str): Tenant name.
                - 'username' (str): User's username.
                - 'session_id' (str): User's session ID.
                - 'module_name' (str, optional): Name of the calling module.
                - 'service_provider' (str, optional): Service provider name.
                - 'db_name' (str): Tenant-specific database name.
                - 'submit_data' (dict): Contains fields like 'revio_product', 'service_type', etc.
            - Common submitted fields (either direct or within 'submit_data'):
                - 'revio_product' (list of str or str): RevIO product description(s).
                - 'service_type' (str): Service type description.
                - 'provider_name' (str): RevIO provider name.
                - 'rev_usage_plan_group' (str): RevIO usage plan group description.
                - 'customer_name' (list of str or str): Customer name(s).
                - 'revio_package' (str, optional): RevIO package description.
                - 'iccid' (list of str): List of ICCIDs.
                - 'description' (str, optional): Service line description.
                - 'rate' (list of str/float): List of rates.
                - 'quantity' (int): Quantity of service lines (often derived from len(iccids)).
                - 'activation_date' (str, optional): Activation date in ISO format if not using carrier activation.
                - 'add_rate_plan' (bool): Flag to add customer rate plan.
                - 'rate_plan' (str, optional): Customer rate plan name.
                - 'prorate' (bool): Flag for proration.
                - 'use_carrier_activation' (bool): Flag to use carrier's activation date.
                - 'service_number' (list of str): List of service numbers (MSISDNs).
                - 'backdating_id' (list, optional): IDs for backdating (for regular users).
            - 'request_received_at' (str, optional): Timestamp of request receipt.

    Returns:
        dict: A response dictionary:
            - 'flag' (bool): True for success, False for failure.
            - 'message' (str): Status message.
            - 'data' (dict, optional): On success, contains 'sim_management_bulk_change' and
                                       'sim_management_bulk_change_request' records.
            - 'bulk_chnage_id_20' (int, optional): The ID of the created bulk change record.
            - 'status_code' (int, optional): HTTP-like status code (e.g., 400, 500 on error).

    """
    logging.info(f"### add_service_line_data function called with data: {data}")
    def validate_required(var, var_name):
        if var is None or (isinstance(var, (str, list, dict)) and not var):
            raise ValueError(f"Missing or invalid value for required field: {var_name}")

    try:
        for key in ["tenant_ids", "feature_codes", "customer_rate_plan_name", "billing_account_number"]:
            try:
                del db_config[key]
            except KeyError:
                pass

    except Exception as e:
        logging.warning(
            f"### add_service_line_data function: Exception deleting tenant_ids from db_config: {e}"
        )

    z_access_token = data.get("z_access_token", "")
    start_time = time.time()
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    request_received_at = data.get("request_received_at", None)
    is_file_upload = data.get("is_file_upload", False)

    try:
        # Normalize top-level parameters
        tenant_name = normalize_value(data.get("tenant_name", None))
        username = normalize_value(data.get("firstLastName", None))
        session_id = normalize_value(data.get("session_id", None))
        service_provider = normalize_value(data.get("service_provider", None))
        tenant_database = normalize_value(data.get("db_name", ""))
        database = DB(tenant_database, **db_config)
        
        submitted_data = data.get("submit_data", {})
        
        # Normalize all submitted data fields
        revio_product = normalize_value(submitted_data.get("revio_product", None), as_list=True)
        package_description = normalize_value(submitted_data.get("description", None),as_list=True)
        service_type = normalize_value(submitted_data.get("service_type", None))
        provider_name = normalize_value(submitted_data.get("provider_name", None))
        rev_usage_plan_group = normalize_value(submitted_data.get("rev_usage_plan_group", None))
        customer_name = [normalize_value(submitted_data.get("customer_name", None))]  # Always use first element
        revio_package = normalize_value(submitted_data.get("revio_package", None))
        iccids = normalize_value(submitted_data.get("iccid", []), as_list=True)
        description = normalize_value(submitted_data.get("description", None))
        rate = normalize_value(submitted_data.get("rate", []), as_list=True)
        customer_ids = normalize_value(submitted_data.get("customer_ids", None), as_list=True)
        
        # Handle boolean flags (convert from list if needed)
        add_rate_plan = bool(normalize_value(submitted_data.get("add_rate_plan", False)))
        rate_plan = normalize_value(submitted_data.get("rate_plan", None))
        use_carrier_activation = bool(normalize_value(submitted_data.get("use_carrier_activation", False)))
        service_numbers = normalize_value(submitted_data.get("service_number", []), as_list=True)
        backdating_id = normalize_value(submitted_data.get("backdating_id", []), as_list=True)
        # prorate = bool(normalize_value(submitted_data.get("prorate", True)))
        
        # Special handling for activation_date (could be empty list)
        activation_date_val = normalize_value(submitted_data.get("activation_date", None))
        if activation_date_val == []: 
            activation_date_val = None

        # Input validation - use normalized values
        validate_required(tenant_name, "tenant_name")
        validate_required(service_provider, "service_provider")
        validate_required(customer_name, "customer_name")
        validate_required(iccids, "iccid")
        validate_required(service_numbers, "service_number")

        # Tenant and Integration Authentication ID
        if tenant_name == "Altaworx Test":
            tenant_id = 1
            tenant_name = "Altaworx"
        else:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
        logging.info(f"### add_service_line_data function: tenant_id is {tenant_id}")

        integration_authentication_json_data = load_integration_authentication_json()
        integration_authentication_id = (
            get_integration_authentication_id_by_unique_name(
                integration_authentication_json_data, tenant_name
            )
        )
        if not integration_authentication_id:
            query = f"select parent_tenant_id from tenant where tenant_name='{tenant_name}'"
            parent_tenant_id = common_utils_database.execute_query(query, True)[
                "parent_tenant_id"
            ].to_list()[0]
            if parent_tenant_id:
                parent_tenant_id = int(parent_tenant_id)
            parent_tenant_query = f"select tenant_name from tenant where id={parent_tenant_id}"
            parent_tenant_name = common_utils_database.execute_query(
                parent_tenant_query, True
            )["tenant_name"].to_list()[0]
            integration_authentication_id = (
                get_integration_authentication_id_by_unique_name(
                    integration_authentication_json_data, parent_tenant_name
                )
            )
        validate_required(
            integration_authentication_id, "integration_authentication_id"
        )

        # Change Type ID for Bulk Change
        Change_type_id = database.get_data(
            "sim_management_bulk_change_type",
            {"display_name": "Create Rev Service"},
            ["id"],
        )["id"].to_list()[0]

        # Fetch Customer ID
        customer_id = None
        try:
            rev_customer_query = """
                SELECT customers.id
                FROM customers
                INNER JOIN revcustomer
                    ON customers.rev_customer_id = revcustomer.id
                WHERE customers.is_active = TRUE
                AND revcustomer.is_active = TRUE
                AND revcustomer.customer_name = %s
            """
            params = [
                customer_name if isinstance(customer_name, str) else customer_name[0],
            ]
            customer_data = database.execute_query(rev_customer_query, params=params)
            if not customer_data.empty:
                customer_id = int(customer_data["id"].iloc[0])
        except Exception as e:
            logging.warning(f"### Error fetching customer_id: {e}")
        validate_required(customer_id, "customer_id")

        # Fetch Service Type ID
        rev_service_type_id = None
        try:
            service_type_val = service_type
            if service_type_val:
                rev_service_type_id = database.get_data(
                    "rev_service_type",
                    {"description": service_type_val, "is_active": True},
                    ["service_type_id"],
                )["service_type_id"].to_list()[0]
                rev_service_type_id = int(rev_service_type_id)
        except Exception as e:
            logging.warning(f"### Error fetching rev_service_type_id: {e}")
        validate_required(rev_service_type_id, "rev_service_type_id")

        # Fetch Provider ID
        rev_provider_id = None
        try:
            rev_provider_id = database.get_data(
                "rev_provider",
                {"description": provider_name, "is_active": True},
                ["provider_id"],
            )["provider_id"].to_list()[0]
            rev_provider_id = int(rev_provider_id)
        except Exception as e:
            logging.warning(f"### Error fetching rev_provider_id: {e}")
        # validate_required(rev_provider_id, "rev_provider_id")

        # Fetch Usage Plan Group ID
        rev_usage_plan_group_id = None
        try:
            if rev_usage_plan_group:
                rev_usage_plan_group_id = database.get_data(
                    "rev_usage_plan_group",
                    {"description": rev_usage_plan_group, "is_active": True},
                    ["usage_plan_group_id"],
                )["usage_plan_group_id"].to_list()[0]
                rev_usage_plan_group_id = int(rev_usage_plan_group_id)
        except Exception as e:
            logging.warning(f"### Error fetching rev_usage_plan_group_id: {e}")

        # Fetch Service Provider ID (internal)
        service_provider_id = None
        try:
            service_provider_id = database.get_data(
                "serviceprovider", {"service_provider_name": service_provider}, ["id"]
            )["id"].to_list()[0]
            service_provider_id = int(service_provider_id)
        except Exception as e:
            logging.warning(f"### Error fetching service_provider_id: {e}")
        validate_required(service_provider_id, "service_provider_id")

        # Fetch Customer Rate Plan ID
        rate_plan_id = None
        try:
            if rate_plan:
                rate_plan_id = database.get_data(
                    "customerrateplan", {"rate_plan_name": rate_plan}, ["id"]
                )["id"].to_list()[0]
        except Exception as e:
            logging.warning(f"### Error fetching rate_plan_id: {e}")

        # Fetch RevIO Customer ID
        rev_customer_id = None
        try:
            rev_customer_id_query = """
                SELECT rev_customer_id
                FROM revcustomer
                WHERE is_active = TRUE
                AND integration_authentication_id = %s
                AND customer_name = %s
            """
            params = [
                integration_authentication_id,
                customer_name if isinstance(customer_name, str) else customer_name[0],
            ]
            rev_customer_data = database.execute_query(
                rev_customer_id_query, params=params
            )
            if not rev_customer_data.empty:
                rev_customer_id = int(rev_customer_data["rev_customer_id"].iloc[0])
        except Exception as e:
            logging.warning(f"### Error fetching rev_customer_id: {e}")
        validate_required(rev_customer_id, "rev_customer_id")

        # Fetch Package/Product IDs
        rev_package_id = None
        rev_product_id = []
        try:
            if revio_package:
                # --- If package is provided, get package and product IDs ---
                package_parts = revio_package.split("-")
                package_id = int(package_parts[-1].strip())
                description = " ".join(package_parts[:-1]).strip()
                package_data_mapping_query = """
                    SELECT DISTINCT
                        rp.description AS description,
                        rp.rate AS rate,
                        rpp.package_id AS package_id,
                        rpp.product_id AS product_id,
                        rp.provider_id AS provider_id
                    FROM public.rev_package_product rpp
                    INNER JOIN rev_product rp ON rp.product_id = rpp.product_id
                    WHERE rpp.package_id = %s
                    AND rp.integration_authentication_id = %s
                    AND rp.is_active = true
                """
                params = [package_id, integration_authentication_id]
                package_product_data = database.execute_query(
                    package_data_mapping_query, params=params
                )
                if not package_product_data.empty:
                    rev_package_id = int(package_product_data["package_id"].iloc[0])
                    rev_product_id = list(
                        set(package_product_data["product_id"].tolist())
                    )
                    if not rev_product_id:
                        logging.warning(
                            f"### add_service_line_data function: Warning: No products found for package {package_id}"
                        )
                else:
                    logging.warning(
                        f"### add_service_line_data function: Warning: No package data found for package_id {package_id}"
                    )
                    rev_package_id = None
                    rev_product_id = []
            else:
                # --- If product(s) provided directly ---
                rev_package_id = None
                if revio_product:
                    product_names = [
                        product.rsplit(" - ", 1)[0] for product in revio_product
                    ]
                    if product_names:
                        rev_product_id_query = """
                            SELECT DISTINCT product_id
                            FROM rev_product
                            WHERE is_active = true
                            AND integration_authentication_id = %s
                            AND description = ANY(%s)
                        """
                        params = [integration_authentication_id, product_names]
                        rev_product_data = database.execute_query(
                            rev_product_id_query, params=params
                        )
                        rev_product_id = list(
                            set(rev_product_data["product_id"].tolist())
                        )
                    else:
                        rev_product_id = []
                else:
                    rev_product_id = []
        except Exception as e:
            logging.warning(f"### Error fetching rev_package_id/rev_product_id: {e}")
        # validate_required(rev_product_id, "rev_product_id")

        # Validate ICCID and Service Number Counts
        
        if len(service_numbers) != len(iccids):
            logging.info(
                "### add_service_line_data function: The iccid or service number is missing."
            )
        none_indexes = [i for i, iccid in enumerate(iccids) if iccid is None]
        valid_indexes = [i for i, iccid in enumerate(iccids) if iccid is not None]
        invalid_service_numbers = [service_numbers[i] for i in none_indexes]
        msisdn_activation_dict = {}
        msisdn_device_dict = {}
        if none_indexes:
            service_df = database.get_data(
                "sim_management_inventory",
                {"msisdn": invalid_service_numbers, "is_active": True,"tenant_id":tenant_id},
                ["msisdn", "last_activated_date","date_activated","device_id", "mobility_device_id"],
            ).to_dict(orient="records")
            for record in service_df:
                msisdn = record["msisdn"]
                # Use last_activated_date if available, else fallback to date_activated
                activation_date = record.get("last_activated_date") or record.get("date_activated")
                msisdn_activation_dict[msisdn] = activation_date
            msisdn_device_dict = {
                record["msisdn"]: record.get("device_id") or record.get("mobility_device_id")
                for record in service_df
            }
        activation_dict = {}
        activation_data = database.get_data(
            "sim_management_inventory",
            {"iccid": iccids, "is_active": True,"tenant_id": tenant_id},
            ["iccid", "last_activated_date","date_activated"],
        ).to_dict(orient="records")
        for record in activation_data:
            iccid = record["iccid"]
            # Use last_activated_date if available, else fallback to date_activated
            activation_date = record.get("last_activated_date") or record.get("date_activated")
            activation_dict[iccid] = activation_date
            
        subscriber_data = database.get_data(
            "sim_management_inventory", {"iccid": iccids,"tenant_id": tenant_id,"is_active": True,}, ["iccid", "msisdn"]
        ).to_dict(orient="records")
        subscriber_dict = {
            record["iccid"]: record.get("msisdn") for record in subscriber_data
        }
        # Fetch Device IDs for ICCIDs
        device_data = database.get_data(
            "sim_management_inventory",
            {"iccid": iccids, "is_active": True, "tenant_id": tenant_id},
            ["iccid", "device_id", "mobility_device_id"],
        ).to_dict(orient="records")
        device_dict = {
            record["iccid"]: record.get("device_id") or record.get("mobility_device_id")
            for record in device_data
        }



        # Prepare Bulk Change Record
        return_dict = {}
        logging.info(
            f"### add_service_line_data function: customer_id: {customer_id}, rev_product_id: {rev_product_id}, rev_service_type_id: {rev_service_type_id}, rev_provider_id: {rev_provider_id}, rev_usage_plan_group_id: {rev_usage_plan_group_id}, rev_customer_id: {rev_customer_id}, rev_package_id: {rev_package_id}, integration_id: {integration_authentication_id}"
        )
        Device_Bulk_Change = {
            "change_request_type_id": Change_type_id,
            "service_provider_id": service_provider_id,
            "tenant_id": tenant_id,
            "status": "NEW",
            "created_by": username,
            "is_active": True,
            "is_deleted": False,
            "service_provider": service_provider,
            "change_request_type": "Create Rev Service",
            "modified_by": username,
            "uploaded": len(service_numbers),
            "processed_by": username,
            "service_number": service_numbers,
        }
        bulkchangeid = database.insert_data(
            Device_Bulk_Change, "sim_management_bulk_change"
        )
        return_dict["sim_management_bulk_change"] = [Device_Bulk_Change]
        create_new_bulk_change_request_dict_all = []

        # Fetch Subscriber Numbers for ICCIDs
        

        # Fetch Activation Dates for ICCIDs (if carrier activation)
        
        # if use_carrier_activation:

        logging.info(f"### is_file_upload - {is_file_upload} - revio_product - {revio_product} - revio_package - {revio_package}")
        # Main optimized processing logic
        if is_file_upload:
            # Process revio products
            use_carrier_activation_flags = normalize_value(submitted_data.get("use_carrier_activation", None),as_list=True)
            activation_dates_list = normalize_value(submitted_data.get("activation_date", None),as_list=True)
            provider_name_list = normalize_value(submitted_data.get("provider_name", None),as_list=True)
            revio_service_providers_map = submitted_data.get("revio_service_providers_map", None)
            if revio_product and any(p and p != "None" for p in revio_product):
                revio_product_ids = [product.rsplit(" - ", 1)[-1] for product in revio_product]
                logging.info(f"### revio_product_ids - {revio_product_ids}")
                
                # Process each ICCID with product-specific logic
                for iccid,service_number, r, rev_product, rev_description, rev_customer_id,use_carrier_activation,activation_date,revio_provider in zip(
                     iccids,service_numbers, rate, revio_product_ids, package_description, customer_ids,use_carrier_activation_flags,activation_dates_list,provider_name_list
                ):
                    if not iccid:
                        subscriber_number = service_number
                        device_id = msisdn_device_dict.get(service_number, None)
                        carrier_activation_date, default_activation_date = process_activation_date(
                        use_carrier_activation, msisdn_activation_dict, service_number, submitted_data,activation_date=activation_date
                    )
                    else:
                        subscriber_number = subscriber_dict.get(iccid, None)
                        device_id = device_dict.get(service_number, None)
                        carrier_activation_date, default_activation_date = process_activation_date(
                            use_carrier_activation, activation_dict, iccid, submitted_data,activation_date=activation_date
                        )
                    processed_rate = process_rate(r)
                    processed_product_id = int(rev_product) if rev_product else None

                    rev_provider_id = revio_service_providers_map.get(revio_provider, None)
                    
                    # Create base change request
                    change_request = create_change_request_base(
                        iccid, service_number, device_id, integration_authentication_id,
                        customer_id, add_rate_plan, rate_plan_id, rev_customer_id,
                        rev_provider_id, rev_service_type_id, rev_usage_plan_group_id,
                        carrier_activation_date, default_activation_date
                    )
                    
                    # Add product-specific fields
                    change_request.update({
                        "RevPackageId": rev_package_id,
                        "RevProductIdList": [str(processed_product_id)],
                        "Description": None if not rev_description else rev_description,
                        "RateList": [processed_rate],
                    })
                    
                    create_new_bulk_change_request_dict_all.append(
                        create_bulk_change_request_dict(
                            iccid, bulkchangeid, tenant_id, username, device_id,
                            service_number, subscriber_number, change_request
                        )
                    )
            
            # Process revio packages
            else:
                revio_package_list = submitted_data.get("revio_package", [])
                revio_package_ids = [package.rsplit("-", 1)[-1].strip() for package in revio_package_list if package]
                logging.info(f"### revio_package_ids - {revio_package_ids}")
                
                # Get package to product mapping once
                package_to_products = get_package_product_mapping(
                    revio_package_ids, integration_authentication_id, database
                )
                
                # Process each ICCID with package-specific logic
                for iccid,service_number, r, rev_package, rev_description, rev_customer_id,use_carrier_activation,activation_date in zip(
                    iccids,service_numbers, rate, revio_package_ids, package_description, customer_ids,use_carrier_activation_flags,activation_dates_list
                ):
                    if not iccid:
                        subscriber_number = service_number
                        device_id = msisdn_device_dict.get(service_number, None)
                        carrier_activation_date, default_activation_date = process_activation_date(
                        use_carrier_activation, msisdn_activation_dict, service_number, submitted_data,activation_date=activation_date
                    )
                    else:
                        subscriber_number = subscriber_dict.get(iccid, None)
                        device_id = device_dict.get(service_number, None)
                        carrier_activation_date, default_activation_date = process_activation_date(
                            use_carrier_activation, activation_dict, iccid, submitted_data,activation_date=activation_date
                        )
                    processed_rate = process_rate(r)
                    processed_package_id = int(rev_package) if rev_package else None
                    product_list = package_to_products.get(processed_package_id, [])
                    logging.info(f"### product_list - {product_list} - {type(product_list)}")
                    
                    # Create base change request
                    change_request = create_change_request_base(
                        iccid, service_number, device_id, integration_authentication_id,
                        customer_id, add_rate_plan, rate_plan_id, rev_customer_id,
                        rev_provider_id, rev_service_type_id, rev_usage_plan_group_id,
                        carrier_activation_date, default_activation_date
                    )
                    
                    # Add package-specific fields
                    change_request.update({
                        "RevPackageId": processed_package_id,
                        "RevProductIdList": product_list,
                        "Description": None if not rev_description else rev_description,
                        "RateList": [processed_rate],
                    })
                    
                    create_new_bulk_change_request_dict_all.append(
                        create_bulk_change_request_dict(
                            iccid, bulkchangeid, tenant_id, username, device_id,
                            service_number, subscriber_number, change_request
                        )
                    )

        # Non-file upload processing
        else:
            for service_number,iccid in zip(service_numbers, iccids):
                if not iccid:
                    subscriber_number = service_number
                    device_id = msisdn_device_dict.get(service_number)
                    carrier_activation_date, default_activation_date = process_activation_date(
                        use_carrier_activation, msisdn_activation_dict, service_number, submitted_data
                    )
                else:
                    subscriber_number = subscriber_dict.get(iccid, None)
                    device_id = device_dict.get(iccid)
                    carrier_activation_date, default_activation_date = process_activation_date(
                        use_carrier_activation, activation_dict, iccid, submitted_data
                    )

                # Create base change request
                change_request = create_change_request_base(
                    iccid, service_number, device_id, integration_authentication_id,
                    customer_id, add_rate_plan, rate_plan_id, rev_customer_id,
                    rev_provider_id, rev_service_type_id, rev_usage_plan_group_id,
                    carrier_activation_date, default_activation_date
                )
                
                # Add non-upload specific fields
                change_request.update({
                    "RevPackageId": rev_package_id,
                    "RevProductIdList": (
                        [str(rev_product_id)]
                        if isinstance(rev_product_id, int)
                        else [str(i) for i in rev_product_id]
                    ),
                    "Description": None if not description else description,
                    "RateList": [process_rate(r) for r in rate],
                })
                
                create_new_bulk_change_request_dict_all.append(
                    create_bulk_change_request_dict(
                        iccid, bulkchangeid, tenant_id, username, device_id,
                        service_number, subscriber_number, change_request
                    )
                )
        logging.info(
            f"### add_service_line_data function: Bulk Change Request Data: {create_new_bulk_change_request_dict_all}"
        )
        change_request_id = database.insert_data(
            create_new_bulk_change_request_dict_all,
            "sim_management_bulk_change_request",
        )
        return_dict["sim_management_bulk_change_request"] = change_request_id

        # Final Response and Audit Logging
        message = "Add Service Line data submitted successfully"
        response = {"flag": True, "message": message}
        response["data"] = return_dict
        response["bulk_chnage_id_20"] = bulkchangeid

        # # Audit log
        # audit_data_user_actions = {
        #     "service_name": "add_service_line_data",
        #     "created_by": data.get("username", ""),
        #     "status": str(response["flag"]),
        #     "session_id": data.get("session_id", ""),
        #     "tenant_name": data.get("tenant_name", ""),
        #     "comments": "submitting the add service line data",
        #     "module_name": "Rev Assuarance",
        #     "request_received_at": data.get("request_received_at"),
        # }
        # logging.info(
        #     f"### add_service_line_data function: Logging audit data: {audit_data_user_actions}"
        # )
        # common_utils_database.update_audit(
        #     audit_data_user_actions, "audit_user_actions"
        # )

        # --- Backdating Logic ---
        if not z_access_token:
            # --- For Regular Users: Update rev_service_false table directly ---
            try:
                result = database.get_data(
                    "rev_service_false", {"id": 1}, ["rev_service_ids"]
                )
                existing_data = (
                    result["rev_service_ids"].iloc[0] if not result.empty else None
                )
            except Exception as e:
                logging.info(
                    f"### add_service_line_data function: Error fetching data: {e}"
                )
                existing_data = None

            existing_ids = []
            try:
                if existing_data and not pd.isna(existing_data):
                    parsed_data = (
                        json.loads(existing_data)
                        if isinstance(existing_data, str)
                        else existing_data
                    )
                    if isinstance(parsed_data, dict):
                        existing_ids = parsed_data.get("id", [])
                    elif isinstance(parsed_data, list):
                        existing_ids = parsed_data
                    else:
                        logging.info(
                            f"### add_service_line_data function: Unexpected data type: {type(parsed_data)}. Resetting to default."
                        )
                        existing_ids = []
                else:
                    logging.info(
                        "### add_service_line_data function: No existing data found. Using only backdating_id."
                    )
            except Exception as e:
                logging.info(
                    f"### add_service_line_data function: Error parsing data: {e}"
                )
                existing_ids = []

            merged_ids = (
                list(set(existing_ids + backdating_id))
                if existing_data
                else backdating_id
            )
            logging.info(
                f"### add_service_line_data function: merged_ids: {merged_ids}"
            )

            if merged_ids:
                try:
                    database.update_dict(
                        "rev_service_false",
                        {"rev_service_ids": json.dumps({"id": merged_ids})},
                        {"id": 1},
                    )
                    logging.info(
                        "### add_service_line_data function: Update successful!"
                    )
                except Exception as e:
                    logging.info(
                        f"### add_service_line_data function: Update failed: {e}"
                    )
            else:
                logging.info(
                    "### add_service_line_data function: No valid IDs to update. Skipping database update."
                )

        else:
            # --- For Service Accounts: Fork processes for async backdating and DB scripts ---
            backdating_pid = os.fork()
            if backdating_pid == 0:
                try:
                    iccids_str = ", ".join(map(str, iccids))
                    backdating_id_query = f"""Select id from vw_combined_rev_service_products where iccid in ('{iccids_str}')"""
                    backdating_result = database.execute_query(
                        backdating_id_query, True
                    )
                    backdating_id = (
                        backdating_result["id"].tolist()
                        if not backdating_result.empty
                        else []
                    )

                    if backdating_id:
                        try:
                            result = database.get_data(
                                "rev_service_false", {"id": 1}, ["rev_service_ids"]
                            )
                            existing_data = (
                                result["rev_service_ids"].iloc[0]
                                if not result.empty
                                else None
                            )
                        except Exception as e:
                            logging.info(
                                f"### add_service_line_data function: Error fetching data: {e}"
                            )
                            existing_data = None

                        existing_ids = []
                        try:
                            if existing_data and not pd.isna(existing_data):
                                parsed_data = (
                                    json.loads(existing_data)
                                    if isinstance(existing_data, str)
                                    else existing_data
                                )
                                if isinstance(parsed_data, dict):
                                    existing_ids = parsed_data.get("id", [])
                                elif isinstance(parsed_data, list):
                                    existing_ids = parsed_data
                                else:
                                    logging.info(
                                        f"### add_service_line_data function: Unexpected data type: {type(parsed_data)}. Resetting to default."
                                    )
                                    existing_ids = []
                        except Exception as e:
                            logging.info(
                                f"### add_service_line_data function: Error parsing data: {e}"
                            )
                            existing_ids = []

                        merged_ids = list(set(existing_ids + backdating_id))
                        try:
                            database.update_dict(
                                "rev_service_false",
                                {"rev_service_ids": json.dumps({"id": merged_ids})},
                                {"id": 1},
                            )
                            logging.info(
                                "### add_service_line_data function: Backdating ID update successful!"
                            )
                        except Exception as e:
                            logging.info(
                                f"### add_service_line_data function: Update failed: {e}"
                            )
                    else:
                        logging.info(
                            "### add_service_line_data function: No backdating IDs found. Skipping update."
                        )
                except Exception as e:
                    logging.info(
                        f"### add_service_line_data function: Error in backdating process: {e}"
                    )
                finally:
                    os._exit(0)  # Ensure child process exits
            else:
                logging.info(
                    "### add_service_line_data function: Backdating ID processing triggered asynchronously."
                )

            # --- Fork for process_service_numbers ---
            data_process = {
                "tenant_name": tenant_name,
                "username": username,
                "firstLastName": username,
                "path": "/process_service_numbers",
                "role_name": "Super Admin",
                "module_name": "Revenue Assurance",
                "access_token": z_access_token,
                "db_name": tenant_database,
                "sessionID": session_id,
                "request_received_at": request_received_at,
                "Partner": tenant_name,
                "bulkchange_id": bulkchangeid,
                "service_ids": service_numbers,
            }
            lambda_client = boto3.client("lambda")
            service_pid = os.fork()
            if service_pid == 0:
                payload = {"data": {"data": data_process}}
                try:
                    response = lambda_client.invoke(
                        FunctionName="sim_management_uat",
                        InvocationType="Event",
                        Payload=json.dumps(payload),
                    )
                    logging.info(
                        f"### add_service_line_data function: Lambda async invoke response: {response}"
                    )

                except Exception as e:
                    logging.exception(
                        f"### add_service_line_data function: Unexpected error while reading calling lambda: {e}"
                    )
                finally:
                    os._exit(0)
            else:
                logging.info(
                    "### add_service_line_data function: DB script (process_service_numbers) triggered asynchronously."
                )

            # --- Fork for run_db_script ---
            data = {
                "tenant_name": tenant_name,
                "username": username,
                "path": "/run_db_script",
                "module_name": "Bulk Change",
                "mod_pages": {"start": 0, "end": 100},
                "access_token": z_access_token,
                "db_name": tenant_database,
                "sessionID": session_id,
                "request_received_at": request_received_at,
                "Partner": tenant_name,
                "bulkchange_id": bulkchangeid,
                "data": return_dict,
                "bulk_chnage_id_20": bulkchangeid,
            }
            script_pid = os.fork()
            lambda_client = boto3.client("lambda")
            if script_pid == 0:
                payload = {"data": {"data": data}}
                try:
                    response = lambda_client.invoke(
                        FunctionName="sim_management_uat",
                        InvocationType="Event",
                        Payload=json.dumps(payload),
                    )
                    logging.info(
                        f"### add_service_line_data function: Lambda async invoke response: {response}"
                    )

                except Exception as e:
                    logging.exception(
                        f"### add_service_line_data function: Unexpected error while reading calling lambda: {e}"
                    )
                finally:
                    os._exit(0)
            else:
                logging.info(
                    "### add_service_line_data function: DB script (run_db_script) triggered asynchronously."
                )
        try:
        # Audit log
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "add_service_line_data",
                "created_by": data.get("username", ""),
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Submitting the add service line data with {len(iccids)} ICCIDs for tenant {tenant_name}",
                "module_name": "Rev Assuarance",
                "request_received_at":request_received_at,
            }
            logging.info(
                f"### add_service_line_data function: Logging audit data: {audit_data_user_actions}"
            )
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.info(f"### add_service_line audit_data_user_actions exception : {e}")

        return response

    except Exception as e:
        logging.exception(
            f"### add_service_line_data function: Something went wrong and error is {e}"
        )
        
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "add_service_line_data",
            "error_message": str(e),
            "error_type": error_type ,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"Error while adding service line data for tenant {tenant_name}",
            "module_name": data.get("module_name", ""),
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "something wrong adding service line", "status_code": 500}



def form_depandent_dropdown_format(data, main_col, sub_col):
    """
    Formats a list of dictionaries into a nested dictionary suitable for dependent dropdowns.
    Given a list of dictionaries (`data`), this function groups the values of `sub_col` by the values of `main_col`.
    The result is a dictionary where each key is a unique value from `main_col`, and the corresponding value is a sorted
    list of unique `sub_col` values associated with that key. The outer dictionary is also sorted by its keys.
    Args:
        data (list of dict): The input data, where each item is a dictionary containing at least `main_col` and `sub_col`.
        main_col (str): The key in each dictionary to group by (e.g., the main dropdown category).
        sub_col (str): The key in each dictionary to use as the dependent dropdown values.
    Returns:
        dict: A sorted dictionary mapping each unique `main_col` value to a sorted list of unique `sub_col` values.
    Example:
        data = [
            {"country": "USA", "city": "New York"},
            {"country": "USA", "city": "Los Angeles"},
            {"country": "Canada", "city": "Toronto"}
        ]
        form_depandent_dropdown_format(data, "country", "city")
        # Returns: {'Canada': ['Toronto'], 'USA': ['Los Angeles', 'New York']}
    """
    logging.info(
        f"### form_depandent_dropdown_format function called with main_col: {main_col}, sub_col: {sub_col}"
    )
    result = {}
    for item in data:
        main_col_value = item[main_col]
        sub_col_value = item[sub_col]
        if main_col_value in result:
            if sub_col_value not in result[main_col_value]:
                result[main_col_value].append(sub_col_value)
        else:
            result[main_col_value] = [sub_col_value]
    for key in result:
        result[key] = sorted(result[key])
    sorted_dict = {key: result[key] for key in sorted(result.keys())}
    logging.info(f"### form_depandent_dropdown_format function result: {sorted_dict}")
    return sorted_dict




def get_headers(tenant_name):
    """
    Constructs headers for API requests based on the tenant name.
    Args:
        tenant_name (str): The name of the tenant.
    Returns:
        dict: A dictionary containing the headers.
    """
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    # Get parent tenant information
    query = f"select parent_tenant_id from tenant where tenant_name='{tenant_name}'"
    parent_tenant_id = common_utils_database.execute_query(query, True)['parent_tenant_id'].to_list()[0]
    
    # Determine which tenant name to use for credentials
    if parent_tenant_id is None:
        # This is a main tenant
        credential_tenant_name = tenant_name
    else:
        # This is a sub tenant, get the parent tenant name
        parent_query = f"select tenant_name from tenant where id='{parent_tenant_id}'"
        credential_tenant_name = common_utils_database.execute_query(parent_query, True)['tenant_name'].to_list()[0]
    
    # Apply special case mapping
    if credential_tenant_name in ["Altaworx Test", "Altaworx"]:
        credential_tenant_name = "ALTAWORX"
    
    # Normalize tenant name to uppercase and replace spaces with underscores
    normalized_tenant = credential_tenant_name.upper().replace(" ", "_")
    logging.info(f"### normalized_tenant : {normalized_tenant}")
    
    # Construct environment variable names
    subscription_key_var = f"REVIO_Subscription_Key_{normalized_tenant}"
    access_token_var = f"{normalized_tenant}_REVIO_acess_token"

    logging.info(f"### access_token_var : {access_token_var}")
    
    # Retrieve environment variables with defaults
    subscription_key = os.getenv(subscription_key_var, "").strip()
    access_token = os.getenv(access_token_var, "").strip()
    logging.info(f"### subscription_key : {subscription_key}")
    logging.info(f"### access_token : {access_token}")
    
    # Construct headers
    headers = {
        "Ocp-Apim-Subscription-Key": subscription_key,
        "Authorization": f"Basic {access_token}",
        "Accept": "application/json",
    }
    return headers


def submit_service_product_data(data):
  
    """
    Submits data to add a new service product to an existing RevIO service.

    This function orchestrates the process of adding a product 
    to one or more existing services associated with a customer. It handles different
    authentication flows (Readme  vs. ui user) and interacts with an
    external API  to perform the addition.

    Key Operations:
    1.  Authentication and Initialization:
        - Determines if the call is from a service account (using `z_access_token`) or a regular user.
        - Initializes database connections (`common_utils_database` for shared data, `database` for tenant-specific data).
        - Extracts input parameters from the `data` dictionary.
    2.  Data Extraction and Flattening:
        - Retrieves customer name, product details (name, rate, quantity, etc.), effective date, and description.
        - Handles potentially nested structures for ICCIDs and service IDs, flattening them for processing.
          The function expects these to be mapped per customer if multiple customers are implicitly handled.
          However, current logic seems to focus on the first customer in `customer_name` list for flattening.
    3.  ID Retrievals and Validation:
        - Fetches `tenant_id` and `integration_authentication_id` (crucial for API calls).
        - Retrieves device information (device_id, mobility_device_id) from `sim_management_inventory`
          based on provided ICCIDs and MSISDNs.
        - Validates that `customer_name` is provided.
        - Fetches `rev_product_id` (for the product being added) and `rev_customer_id` (RevIO's customer identifier).
        - Fetches internal `service_provider_id` and `change_request_type_id` for "Add Service Product".
    4.  Bulk Change Tracking:
        - Creates a master record in `sim_management_bulk_change` to track the overall operation.
    5.  API Interaction and Per-Item Processing:
        - Iterates through each `service_id` to which the product needs to be added.
        - Constructs a JSON payload for the external API (e.g., RevIO's serviceProduct endpoint).
        - Makes a POST request to the API to add the product to the service.
    6.  Database Updates and Logging:
        - If the API call is successful:
            - Collects data for a new record in `rev_service_product` (though insertion seems to happen in bulk later).
        - Creates individual records in `sim_management_bulk_change_request` for each processed service_id,
          storing the API request payload and response status.
        - Creates log entries in `sim_management_bulk_change_log` for each API call.
        - Performs a bulk insert of successful `rev_service_product` data.
        - Updates the master `sim_management_bulk_change` record with success/error counts.
    7.  Caching (Placeholder): Includes a section for caching, but the actual implementation is commented out.
    8.  Audit Logging: Records the action in `audit_user_actions`.

    Parameters:
    - data (dict): A dictionary containing input data.
        - Authentication & Context (common):
            - 'z_access_token' (str, optional): Service account token.
            - 'client_id' (str, optional): Client ID if `z_access_token` is present.
            - 'username' (str, optional): Username for regular session.
            - 'session_id' (str, optional): Session ID.
            - 'tenant_name' (str): The name of the tenant.
            - 'db_name' (str, optional): Tenant database name (for regular session).
            - 'request_received_at' (str): Timestamp of request.
            - 'firstLastName' (str): Name of the user/actor.
            - 'module_name' (str, optional): Calling module.
            - 'service_provider' (str): Name of the service provider.
            - 'integration_authentication_id' (str, optional for service account if passed in `data`): For API calls.
        - Submitted Data (`submit_data` dictionary for regular users, or direct in `data` for service accounts):
            - 'customer_name' (list of str or str): The customer(s) to whom the service product is being added.
                                                   Current logic primarily uses the first customer for some operations.
            - 'product_name' (str): The name/description of the RevIO product to add.
            - 'rate' (float/int): The rate for the product.
            - 'quantity' (int/str): The quantity of the product.
            - 'prorate' (bool): Whether to prorate charges.
            - 'effective_date' (str): The date the product addition becomes effective (ISO format like "YYYY-MM-DDTHH:MM:SS.sssZ").
                                     If empty, it's calculated based on the service provider's bill period end day.
            - 'description' (str, optional): A description for this service product instance.
            - 'revio_service' (dict or list): Mapping of customer to list of RevIO service IDs (or a flat list if single customer context).
                                              These are the existing services to which the product will be added.
            - 'iccids' (dict or list, optional): Mapping of customer to list of ICCIDs (or flat list). Used for fetching device info.
            - 'msisdn' (dict or list, optional): Mapping of customer to list of MSISDNs (or flat list). Used for fetching device info.

    Returns:
    - dict: A dictionary containing:
        - 'flag' (bool): True if the operation (or at least part of it) was successful, False otherwise.
        - 'message' (str): A summary message of the operation.
        - 'time_consumed' (str, optional): Time taken for the operation.
        - 'responses' (list, optional): A list of dictionaries, each representing the outcome of adding the product
                                       to a specific service_id (contains status, API response/error).
        - 'bulk_change_id' (int, optional): The ID of the master bulk change record.
        - 'status_code' (int, optional): HTTP-like status code (e.g., 400, 500 on error).
        - 'error_details' (str, optional): Detailed error message if an exception occurs.
    """
    logging.info(f"### submit_service_product_data function called with data: {data}")
    logging.info(
        "### submit_service_product_data function checkpoint: initializing DB and extracting context"
    )
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    request_received_at = data.get("request_received_at", "")
    firstLastName = data.get("firstLastName", "")
    session_id = data.get("session_id", None)
    module_name = data.get("module_name", None)
    start_time = time.time()
    insert_data = []
    responses = []

    try:
        # --- Authentication and Data Extraction --
        tenant_name = data.get("tenant_name", None)
        username = data.get("username", None)
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        databasewithoutfilters = DB(tenant_database, **db_config_withoutfilter)
        submit_data = data.get("submit_data", {})
        integration_authentication_json_data = load_integration_authentication_json()
        integration_authentication_id = get_integration_authentication_id_by_unique_name(
            integration_authentication_json_data, tenant_name
        )
        if not integration_authentication_id:
            parent_tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["parent_tenant_id"]
            )["parent_tenant_id"].to_list()[0]
            parent_tenant_name = common_utils_database.get_data(
                "tenant", {"id": parent_tenant_id}, ["tenant_name"]
            )["tenant_name"].to_list()[0]
            integration_authentication_id = get_integration_authentication_id_by_unique_name(
                integration_authentication_json_data, parent_tenant_name
            )

        # --- Flatten and Extract Data ---
        customer_name = submit_data.get("customer_name", [])
        # Ensure customer_name is a list
        if isinstance(customer_name, str):
            customer_name = [customer_name]
        
        product_name = submit_data.get("product_name")
        rate = submit_data.get("rate")
        quantity = submit_data.get("quantity")
        prorate = submit_data.get("prorate")
        effective_date = submit_data.get("effective_date")
        description = submit_data.get("description")
        revio_services_map = submit_data.get("revio_service", {})
        iccids_map = submit_data.get("iccids", {})
        msisdn_map = submit_data.get("msisdn", {})
        service_provider = data.get("service_provider", "")

        # --- Build customer_rev_id_map ---
        customer_rev_id_map = {}
        for customer in customer_name:
            rev_id = database.get_data(
                "revcustomer",
                {"customer_name": customer, "is_active": True},
                ["rev_customer_id"],
            )
            if not rev_id.empty:
                customer_rev_id_map[customer] = rev_id["rev_customer_id"].to_list()[0]
            else:
                logging.error(f"### Rev customer ID not found for customer: {customer}")
                customer_rev_id_map[customer] = None
        # --- Effective Date Handling ---
        if not effective_date:
            logging.info("checking the rev customer id  and effective dates for each customer")
            # Step 1: Get customer_name → rev_customer_id
            customer_data = databasewithoutfilters.get_data(
                'revcustomer',
                {'customer_name': customer_name,"integration_authentication_id":integration_authentication_id},
                ['customer_name', 'id']
            )
            df_customers = pd.DataFrame(customer_data)

            # Step 2: Fetch customer billing info (now using customer_bill_period_end_day)
            customers_df = pd.DataFrame(databasewithoutfilters.get_data(
                'customers',
                {'rev_customer_id': df_customers['id'].tolist()},
                ['rev_customer_id', 'customer_bill_period_end_day']
            ))

            # Step 3: Clean and ensure numeric field
            # Convert non-numeric or missing values to None
            customers_df['customer_bill_period_end_day'] = pd.to_numeric(
                customers_df['customer_bill_period_end_day'], errors='coerce'
            ).astype('Int64')  # Nullable integer type

            # Step 4: Merge both DataFrames
            merged_df = pd.merge(
                df_customers,
                customers_df,
                left_on='id',
                right_on='rev_customer_id',
                how='left'
            )

            # Step 5: Map customer_name → customer_bill_period_end_day
            mapping = dict(zip(
                merged_df['customer_name'],
                merged_df['customer_bill_period_end_day']
            ))
            logging.info(f"mapping is {mapping}")
        else:
            if isinstance(effective_date, str) and effective_date:
                try:
                    effective_date = datetime.datetime.strptime(
                        effective_date, "%Y-%m-%dT%H:%M:%S.%fZ"
                    )
                except Exception:
                    try:
                        effective_date = datetime.datetime.strptime(
                            effective_date, "%Y-%m-%dT%H:%M:%S"
                        )
                    except Exception:
                        effective_date = pd.to_datetime(effective_date)
            effective_date = effective_date.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

        # --- Tenant and Integration IDs ---
        if tenant_name in ["Altaworx Test", "Altaworx"]:
            tenant_id = 1
        else:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]

        # --- Collect all ICCIDs and MSISDNs across customers ---
        all_iccids = []
        all_msisdns = []
        for customer in customer_name:
            all_iccids.extend(iccids_map.get(customer, []))
            all_msisdns.extend(msisdn_map.get(customer, []))

        # --- Device Info Map ---
        device_info_map = {}
        device_ids = {}
        device_ids_df = []
        if all_iccids:
            iccid_records = database.get_data(
                "sim_management_inventory",
                {"iccid": all_iccids, "is_active": True, "tenant_id": tenant_id},
                ["device_id", "mobility_device_id", "iccid", "msisdn", "imei"],
            ).to_dict(orient="records")
            device_ids_df += iccid_records
        if all_msisdns:
            msisdn_records = database.get_data(
                "sim_management_inventory",
                {"msisdn": all_msisdns, "is_active": True, "tenant_id": tenant_id},
                ["device_id", "mobility_device_id", "iccid", "msisdn", "imei"],
            ).to_dict(orient="records")
            device_ids_df += msisdn_records
        for ids in device_ids_df:
            if ids.get("iccid"):
                device_info_map[ids["iccid"]] = ids
                device_ids[ids["iccid"]] = ids["device_id"] or ids["mobility_device_id"]
            if ids.get("msisdn"):
                device_info_map[ids["msisdn"]] = ids
                device_ids[ids["msisdn"]] = ids["device_id"] or ids["mobility_device_id"]

        # --- Validation and ID Fetches ---
        if not customer_name:
            return {"flag": False, "message": "Customer name is required."}
        rev_product_id = database.get_data(
            "rev_product",
            {"description": product_name, "is_active": True},
            ["product_id"],
        )["product_id"].to_list()[0]
        
        service_provider_id = database.get_data(
            "serviceprovider",
            {"service_provider_name": service_provider, "is_active": True},
            ["id"],
        )["id"].to_list()[0]
        change_request_type = "Add Service Product"
        change_request_type_id = database.get_data(
            "sim_management_bulk_change_type",
            {"display_name": change_request_type, "is_active": True},
            ["id"],
        )["id"].to_list()[0]

        # --- Bulk Change Tracking ---
        bulk_change_data = {
            "service_provider_id": service_provider_id,
            "service_provider": service_provider,
            "tenant_id": tenant_id,
            "change_request_type_id": change_request_type_id,
            "change_request_type": change_request_type,
            "status": "PROCESSED",
            "uploaded": sum(len(revio_services_map.get(cust, [])) for cust in customer_name),
            "processed_date": None,
            "processed_by": None,
            "created_by": firstLastName,
            "created_date": request_received_at,
            "modified_by": firstLastName,
            "modified_date": request_received_at,
            "is_deleted": False,
            "is_active": True,
            "errors": 0,
            "success": 0,
        }
        bulk_change_id = database.insert_data(
            bulk_change_data, "sim_management_bulk_change"
        )
        bulk_change_requests = []
        bulk_change_logs = []
        bulk_service_product_data = []
        success_count = 0
        error_count = 0

        url = os.getenv("SERVICEPRODUCT", "")
        headers = get_headers(tenant_name)

        # --- Prepare Processing Items ---
        processing_items = []
        for customer in customer_name:
            rev_customer_id = customer_rev_id_map[customer]
            if rev_customer_id is None:
                continue  # Skip if Rev customer ID not found
            services = revio_services_map.get(customer, [])
            iccids = iccids_map.get(customer, [])
            msisdns = msisdn_map.get(customer, [])
            # Pair each service with an ICCID and/or MSISDN
            for idx, service_id in enumerate(services):
                iccid = iccids[idx] if idx < len(iccids) else None
                msisdn = msisdns[idx] if idx < len(msisdns) else None
                processing_items.append((customer, rev_customer_id, service_id, iccid, msisdn))

        # --- API Interaction and Per-Item Processing ---
        for item in processing_items:
            customer, rev_customer_id, service_id, iccid, msisdn = item
            device_info = device_info_map.get(iccid) or device_info_map.get(msisdn) or {}
            device_id = device_ids.get(iccid) or device_ids.get(msisdn)
            if effective_date:  # already set earlier
                effective_date_for_customer = effective_date
            else:
                # Get from mapping (customer_bill_period_end_day)
                bill_day = mapping.get(customer)
                if pd.notna(bill_day):
                    bill_day = int(bill_day)
                    logging.info(f"bill_day is {bill_day}")
                    today = datetime.utcnow()
                    try:
                        effective_date_for_customer = datetime(
                            today.year, today.month, bill_day
                        ).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
                    except ValueError:
                        effective_date_for_customer = None
                else:
                    effective_date_for_customer = None
            logging.info(
                f"### submit_service_product_data function checkpoint: effective_date_for_customer is {effective_date_for_customer}"
            )
            params = {
                "customer_id": int(rev_customer_id),
                "product_id": int(rev_product_id),
                "rate": float(rate),  # Changed to float to preserve decimal precision
                "quantity": int(quantity),
                "generate_proration": prorate,
                "effective_date": str(effective_date_for_customer),
                "description": description,
                "service_id": int(service_id),
                "integration_authentication_id": integration_authentication_id,
            }
            logging.info(
                f"### submit_service_product_data function checkpoint: posting to API for service_id {service_id} with params {params}"
            )
            logging.info(f"### submit_service_product_data function checkpoint: API URL {url} - headers - {headers}")
            api_response = requests.post(url, headers=headers, json=params)
            if api_response.status_code in [200, 201]:
                success_count += 1
                service_product_data = {
                    "customer_id": str(rev_customer_id),
                    "product_id": int(rev_product_id),
                    "rate": float(rate),  # Changed to float to preserve decimal precision
                    "quantity": int(quantity),
                    "pro_rate": prorate,
                    "created_by": firstLastName,
                    "is_active": True,
                    "is_deleted": False,
                    "created_date": request_received_at,
                    "description": description,
                }
                bulk_service_product_data.append(service_product_data)
                responses.append(
                    {
                        "service_id": service_id,
                        "status": "PROCESSED",
                        "response": api_response.json(),
                    }
                )
                request_status = "PROCESSED"
                has_errors = False
                logging.info(
                    f"### submit_service_product_data function checkpoint: API call success for service_id {service_id}"
                )
            else:
                error_count += 1
                responses.append(
                    {
                        "service_id": service_id,
                        "status": "ERROR",
                        "error": api_response.text,
                    }
                )
                request_status = "ERROR"
                has_errors = True
                logging.info(
                    f"### submit_service_product_data function checkpoint: API call failed for service_id {service_id} with status {api_response.status_code}"
                )

            # --- Bulk Change Request and Log ---
            bulk_change_requests.append({
                "mobility_id": device_info.get("mobility_device_id"),
                "bulk_change_id": bulk_change_id,
                "iccid": iccid,
                "subscriber_number": device_info.get("msisdn") or msisdn,
                "change_request": json.dumps(params),
                "device_id": device_id,
                "is_processed": api_response.status_code in [200, 201],
                "has_errors": has_errors,
                "status": request_status,
                "status_details": api_response.text,
                "processed_date": request_received_at if api_response else None,
                "processed_by": firstLastName if api_response else None,
                "created_by": firstLastName,
                "created_date": request_received_at,
                "is_deleted": False,
                "is_active": True,
                "tenant_id": tenant_id,
                "tenant_name": tenant_name,
                "modified_by": firstLastName,
                "modified_date": request_received_at,
            })
            identifier_info = ""
            if iccid:
                identifier_info += f" (ICCID: {iccid})"
            if msisdn and msisdn != device_info.get("msisdn"):
                identifier_info += f" (MSISDN: {msisdn})"
            bulk_change_logs.append({
                "bulk_change_id": bulk_change_id,
                "log_entry_description": f"API Request for Service ID {service_id}{identifier_info}",
                "request_text": str(params),
                "has_errors": has_errors,
                "response_status": api_response.status_code,
                "response_text": api_response.text,
                "error_text": api_response.text if has_errors else None,
                "processed_date": request_received_at,
                "processed_by": firstLastName,
                "created_by": firstLastName,
                "created_date": request_received_at,
                "modified_by": firstLastName,
                "modified_date": request_received_at,
                "is_deleted": False,
                "is_active": True,
            })

        # --- DB Inserts ---
        if bulk_service_product_data:
            database.insert_data(bulk_service_product_data, "rev_service_product")
            inserted_records = database.get_data(
                "rev_service_product",
                {
                    "created_by": firstLastName,
                    "created_date": request_received_at,
                    "customer_id": [customer_rev_id_map[c] for c in customer_name],
                    "product_id": rev_product_id,
                },
            ).to_dict(orient="records")
            insert_data.extend(inserted_records)
        if bulk_change_requests:
            first_id = database.insert_data(bulk_change_requests, "sim_management_bulk_change_request")
            logging.info(f"### first_id : {first_id}")
            logging.info("### submit_service_product function checkpoint: bulk_change_requests inserted")

        # Calculate all inserted IDs (sequential)
        request_ids = list(range(first_id, first_id + len(bulk_change_requests)))

        # Add bulk_change_request_id to each log entry
        for i, log_entry in enumerate(bulk_change_logs):
            log_entry["bulk_change_request_id"] = request_ids[i]
        logging.info(f"### submit_service_product function checkpoint: request_ids {request_ids}")

        
        if bulk_change_logs:
            database.insert_data(bulk_change_logs, "sim_management_bulk_change_log")
        update_data = {
            "success": success_count,
            "errors": error_count,
            "status": "PROCESSED" if error_count == 0 else "ERROR",
            "processed_date": request_received_at,
            "processed_by": firstLastName,
            "progress": "Sync Completed"
        }
        database.update_dict(
            "sim_management_bulk_change", update_data, {"id": bulk_change_id}
        )

        try:
            # common_utils_db_conn = DB("common_utils", **db_config)
            tenant_name_for_cache = (
                "altaworx"
                if tenant_name in ["Altaworx Test", "Altaworx"]
                else tenant_database.lower()
            )
            data = {
                "key-name": f"add_service_product_{tenant_name_for_cache}",
                "rev_service_product": insert_data,
            }
            logging.info(
                f"### submit_service_product_data function checkpoint: caching data for {tenant_name_for_cache}"
            )
        except Exception as e:
            logging.error(
                f"### submit_service_product_data function caching error: {e}"
            )    
            
        # --- Audit Logging ---
        end_time = time.time()
        time_consumed = round(end_time - start_time, 4)
        response = {
            "flag": True,
            "message": "Service product data submitted successfully",
            "time_consumed": time_consumed,
            "responses": responses,
            "bulk_change_id": bulk_change_id,
        } 
        audit_data = {
            "service_name": "submit_service_product_data",
            "created_by": username ,
            "status": str(response['flag']),
            "time_consumed_secs": time_consumed,
            "session_id": session_id ,
            "tenant_name": tenant_name ,
            "comments": f"Submitting the service product data for tenant {tenant_name} with {len(responses)} responses",
            "module_name": "Rev Assuarance",
            "request_received_at": request_received_at ,
        }
        common_utils_database.update_audit(audit_data, "audit_user_actions")
        logging.info(
            f"### submit_service_product_data function completed successfully for tenant {tenant_name}"
        )
        return response 

    except Exception as e:
        message = f"Error while submitting service product data: {str(e)}"
        logging.exception(
            f"### submit_service_product_data function exception: {message}"
        )
        error_data = {
            "service_name": "submit_service_product_data",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username ,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": f"Error while submitting service product data for tenant {tenant_name}",
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {
            "flag": False,
            "message": "Internal server error",
            "status_code": 500,
            "error_details": message,
        }


def hit_all_apis(
    customer_id,
    Service_id,
    service_numbers,
    package_id,
    product_ids,
    effective_date,
    quantity,
    tenant_name,
    bulk_change_id,
    request_received_at,
    firstLastName,
    tenant_id,
    bulk_change_logs,
    iccid_list,
    iccid_msisdn_dict,
    iccid_mobility_device_dict,
    bulk_change_requests,
    error_count,
    success_count,
):
    """
    Description:
    This function interacts with external APIs to manage service products and inventory items for a given customer.
    It retrieves service product data based on service ID, package ID, and product IDs, checks the status of inventory items,
    creates new inventory items if they do not exist, assigns inventory items to services, and updates service product details
    like quantity and effective date.

    Parameters:
    - customer_id (int): The unique identifier for the customer.
    - Service_id (int): The unique identifier for the service.
    - service_numbers (list): A list of service numbers (identifiers) for which inventory actions need to be performed.
    - package_id (int): The unique identifier for the package associated with the service products.
    - product_ids (list or None): A list of service product IDs to filter the relevant products. If None, all products are considered.
    - effective_date (str): The effective date to update for the service products.
    - quantity (int): The quantity to add to the existing quantity for the service products.

    Returns:
    - dict: Contains updated bulk_change_requests, bulk_change_logs, success_count, and error_count.
    """
    try:
        logging.info(
            f"### hit_all_apis function in tenant {tenant_name} checkpoint received for customer_id {customer_id}, Service_id {Service_id}, package_id {package_id}, product_ids {product_ids}, effective_date {effective_date}, quantity {quantity}"
        )
        BASE_URL = os.getenv("REVIOAPI", " ")
        general_error = False
        general_error_message = ""

        # Set headers based on tenant
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
        headers = get_headers(tenant_name)

        # 1. Get all active service products for the given service ID
        search_inventory_url = f"{BASE_URL}/ServiceProduct?search.service_id={Service_id}&search.status=ACTIVE"
        logging.info(
            f"### hit_all_apis function in tenant {tenant_name} checkpoint calling GET {search_inventory_url}"
        )
        search_inventory_response = requests.get(search_inventory_url, headers=headers)

        # Create log entries for GET ServiceProduct for each ICCID
        for iccid in iccid_list:
            search_has_errors = search_inventory_response.status_code != 200
            
            log_entry_search = {
                "bulk_change_id": bulk_change_id,
                "log_entry_description": f"GET ServiceProduct for Service ID {Service_id} (ICCID: {iccid})",
                "request_text": search_inventory_url,
                "has_errors": search_has_errors,
                "response_status": search_inventory_response.status_code,
                "response_text": search_inventory_response.text,
                "error_text": search_inventory_response.text if search_has_errors else None,
                "processed_date": request_received_at,
                "processed_by": firstLastName,
                "created_by": firstLastName,
                "created_date": request_received_at,
                "modified_by": firstLastName,
                "modified_date": request_received_at,
                "is_deleted": False,
                "is_active": True,
            }
            bulk_change_logs.append(log_entry_search)

        if search_inventory_response.status_code != 200:
            general_error = True
            general_error_message = f"Failed to fetch service products: {search_inventory_response.text}"
            for iccid in iccid_list:
                bulk_request_entry = {
                    "mobility_id": iccid_mobility_device_dict.get(iccid),
                    "bulk_change_id": bulk_change_id,
                    "iccid": iccid,
                    "subscriber_number": iccid_msisdn_dict.get(iccid),
                    "change_request": "",
                    "device_id": None,
                    "is_processed": True,
                    "has_errors": True,
                    "status": "ERROR",
                    "status_details": general_error_message,
                    "processed_date": request_received_at,
                    "processed_by": firstLastName,
                    "created_by": firstLastName,
                    "created_date": request_received_at,
                    "is_deleted": False,
                    "is_active": True,
                    "tenant_id": tenant_id,
                    "tenant_name": tenant_name,
                    "modified_by": firstLastName,
                    "modified_date": request_received_at,
                }
                bulk_change_requests.append(bulk_request_entry)
            return {
                "bulk_change_requests": bulk_change_requests,
                "bulk_change_logs": bulk_change_logs,
                "success_count": success_count,
                "error_count": error_count + len(iccid_list) * int(quantity),
            }

        service_product_response = search_inventory_response.json()
        service_products = service_product_response["records"]
        logging.info(
            f"### hit_all_apis function in tenant {tenant_name} checkpoint fetched {len(service_products)} service products for Service_id {Service_id}"
        )

        # 2. Filter service products by package_id
        service_products_by_package_id = [
            str(item["service_product_id"])
            for item in service_products
            if str(item["package_id"]) == str(package_id)
        ]
        did_service_products = service_products_by_package_id if product_ids is None else list(product_ids)
        logging.info(
            f"### hit_all_apis function in tenant {tenant_name} checkpoint filtered service products by package_id {package_id}: {did_service_products}"
        )

        inventory_list = []
        # 3. For each service number, check if inventory exists, else create it
        for identifier in service_numbers:
            # Find the corresponding ICCID for this identifier from iccid_msisdn_dict
            corresponding_iccid = None
            for iccid, msisdn in iccid_msisdn_dict.items():
                if msisdn == identifier:  # Assuming identifier matches msisdn
                    corresponding_iccid = iccid
                    break
            
            # If we can't find corresponding ICCID, use the identifier itself in description
            iccid_for_log = corresponding_iccid if corresponding_iccid else identifier
            
            get_search_inventory_url = f"{BASE_URL}/InventoryItem?search.identifier={identifier}"
            logging.info(f"### Checking inventory for identifier {identifier} with GET {get_search_inventory_url}")
            get_search_inventory_response = requests.get(get_search_inventory_url, headers=headers)

            # Create log entry for this specific identifier/ICCID
            get_inventory_has_errors = get_search_inventory_response.status_code not in [200, 201]
            
            log_entry_get_inventory = {
                "bulk_change_id": bulk_change_id,
                "log_entry_description": f"GET InventoryItem for identifier {identifier} (ICCID: {iccid_for_log})",
                "request_text": get_search_inventory_url,
                "has_errors": get_inventory_has_errors,
                "response_status": get_search_inventory_response.status_code,
                "response_text": get_search_inventory_response.text,
                "error_text": get_search_inventory_response.text if get_inventory_has_errors else None,
                "processed_date": request_received_at,
                "processed_by": firstLastName,
                "created_by": firstLastName,
                "created_date": request_received_at,
                "modified_by": firstLastName,
                "modified_date": request_received_at,
                "is_deleted": False,
                "is_active": True,
            }
            bulk_change_logs.append(log_entry_get_inventory)

            inventory_items = get_search_inventory_response.json()
            if inventory_items["record_count"] <= 0:
                create_inventory_url = f"{BASE_URL}/InventoryItem"
                new_inventory_data = {
                    "inventory_type_id": 20,
                    "identifier": identifier,
                    "customer_id": customer_id,
                    "status": "AVAILABLE",
                }
                logging.info(f"### Creating inventory for identifier {identifier} with POST {create_inventory_url}")
                create_inventory_response = requests.post(create_inventory_url, json=new_inventory_data, headers=headers)

                # Create log entry for this specific identifier/ICCID creation
                create_inventory_has_errors = create_inventory_response.status_code not in [200, 201]
                
                log_entry_create_inventory = {
                    "bulk_change_id": bulk_change_id,
                    "log_entry_description": f"POST create InventoryItem for identifier {identifier} (ICCID: {iccid_for_log})",
                    "request_text": json.dumps(new_inventory_data),
                    "has_errors": create_inventory_has_errors,
                    "response_status": create_inventory_response.status_code,
                    "response_text": create_inventory_response.text,
                    "error_text": create_inventory_response.text if create_inventory_has_errors else None,
                    "processed_date": request_received_at,
                    "processed_by": firstLastName,
                    "created_by": firstLastName,
                    "created_date": request_received_at,
                    "modified_by": firstLastName,
                    "modified_date": request_received_at,
                    "is_deleted": False,
                    "is_active": True,
                }
                bulk_change_logs.append(log_entry_create_inventory)

                if create_inventory_response.status_code not in [200, 201]:
                    general_error = True
                    general_error_message += f"Failed to create inventory for {identifier}: {create_inventory_response.text}\n"
                    # Create error entry for the corresponding ICCID only
                    if corresponding_iccid:
                        bulk_request_entry = {
                            "mobility_id": iccid_mobility_device_dict.get(corresponding_iccid),
                            "bulk_change_id": bulk_change_id,
                            "iccid": corresponding_iccid,
                            "subscriber_number": iccid_msisdn_dict.get(corresponding_iccid),
                            "change_request": "",
                            "device_id": None,
                            "is_processed": True,
                            "has_errors": True,
                            "status": "ERROR",
                            "status_details": general_error_message,
                            "processed_date": request_received_at,
                            "processed_by": firstLastName,
                            "created_by": firstLastName,
                            "created_date": request_received_at,
                            "is_deleted": False,
                            "is_active": True,
                            "tenant_id": tenant_id,
                            "tenant_name": tenant_name,
                            "modified_by": firstLastName,
                            "modified_date": request_received_at,
                        }
                        bulk_change_requests.append(bulk_request_entry)
                        error_count += int(quantity)  # Add error count for this specific ICCID
                else:
                    inventory_list.append(identifier)
            
            # Check existing inventory records and add available ones to inventory_list
            if inventory_items["records"]:
                for record in inventory_items["records"]:
                    if record["status"] != "ASSIGNED":
                        inventory_list.append(identifier)

        # Check if there were any critical errors that should stop processing
        if general_error and len(inventory_list) == 0:
            # If we have errors and no inventory to assign, return early
            return {
                "bulk_change_requests": bulk_change_requests,
                "bulk_change_logs": bulk_change_logs,
                "success_count": success_count,
                "error_count": error_count,
            }
        get_dids_url = f"{BASE_URL}/ServiceInventory?search.service_id={Service_id}"
        logging.info(
            f"### hit_all_apis function in tenant {tenant_name} checkpoint calling GET {get_dids_url} for DIDs"
        )
        get_dids_response = requests.get(get_dids_url, headers=headers)

        # Create log entries for GET ServiceInventory for each ICCID
        for iccid in iccid_list:
            get_dids_has_errors = get_dids_response.status_code not in [200, 201]
            
            log_entry_get_dids = {
                "bulk_change_id": bulk_change_id,
                "log_entry_description": f"GET ServiceInventory for Service ID {Service_id} (ICCID: {iccid})",
                "request_text": get_dids_url,
                "has_errors": get_dids_has_errors,
                "response_status": get_dids_response.status_code,
                "response_text": get_dids_response.text,
                "error_text": get_dids_response.text if get_dids_has_errors else None,
                "processed_date": request_received_at,
                "processed_by": firstLastName,
                "created_by": firstLastName,
                "created_date": request_received_at,
                "modified_by": firstLastName,
                "modified_date": request_received_at,
                "is_deleted": False,
                "is_active": True,
            }
            bulk_change_logs.append(log_entry_get_dids)

        # 5. Assign inventory items to the service
        assign_inventory_url = f"{BASE_URL}/InventoryItem/assignService"
        assign_inventory_data = {
            "service_id": Service_id,
            "identifiers": inventory_list,
        }
        logging.info(f"### Assigning inventory to service_id {Service_id} with PATCH {assign_inventory_url}")
        assign_inventory_response = requests.patch(assign_inventory_url, json=assign_inventory_data, headers=headers)

        # Create one log entry for assign inventory PATCH request for each ICCID
        for iccid in iccid_list:
            assign_has_errors = assign_inventory_response.status_code not in [200, 201]
            
            log_entry_assign = {
                "bulk_change_id": bulk_change_id,
                "log_entry_description": f"PATCH assign inventory to Service ID {Service_id} (ICCID: {iccid})",
                "request_text": json.dumps(assign_inventory_data),
                "has_errors": assign_has_errors,
                "response_status": assign_inventory_response.status_code,
                "response_text": assign_inventory_response.text,
                "error_text": assign_inventory_response.text if assign_has_errors else None,
                "processed_date": request_received_at,
                "processed_by": firstLastName,
                "created_by": firstLastName,
                "created_date": request_received_at,
                "modified_by": firstLastName,
                "modified_date": request_received_at,
                "is_deleted": False,
                "is_active": True,
            }
            bulk_change_logs.append(log_entry_assign)

        if assign_inventory_response.status_code not in [200, 201]:
            general_error = True
            general_error_message = f"Failed to assign inventory: {assign_inventory_response.text}"
            for iccid in iccid_list:
                bulk_request_entry = {
                    "mobility_id": iccid_mobility_device_dict.get(iccid),
                    "bulk_change_id": bulk_change_id,
                    "iccid": iccid,
                    "subscriber_number": iccid_msisdn_dict.get(iccid),
                    "change_request": "",
                    "device_id": None,
                    "is_processed": True,
                    "has_errors": True,
                    "status": "ERROR",
                    "status_details": general_error_message,
                    "processed_date": request_received_at,
                    "processed_by": firstLastName,
                    "created_by": firstLastName,
                    "created_date": request_received_at,
                    "is_deleted": False,
                    "is_active": True,
                    "tenant_id": tenant_id,
                    "tenant_name": tenant_name,
                    "modified_by": firstLastName,
                    "modified_date": request_received_at,
                }
                bulk_change_requests.append(bulk_request_entry)
            return {
                "bulk_change_requests": bulk_change_requests,
                "bulk_change_logs": bulk_change_logs,
                "success_count": success_count,
                "error_count": error_count + len(iccid_list) * int(quantity),
            }

        # 6. For each relevant service product, update quantity and effective date
        json_patch = []

        # Track if assign inventory was successful
        assign_inventory_success = assign_inventory_response.status_code in [200, 201]

        for service_product in service_products:
            if str(service_product["service_product_id"]) in did_service_products:
                # Get the current quantity from the service product response
                current_quantity = int(service_product["quantity"])
                # Add the length of inventory_list to current quantity
                new_quantity = current_quantity + len(inventory_list)
                
                patch_data = [
                    {"op": "replace", "path": "/quantity", "value": new_quantity},
                    {"op": "replace", "path": "/effective_date", "value": effective_date},
                ]
                json_patch = json.dumps(patch_data)
                try:
                        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
                        # Get parent tenant information
                        query = f"select parent_tenant_id from tenant where tenant_name='{tenant_name}'"
                        parent_tenant_id = common_utils_database.execute_query(query, True)['parent_tenant_id'].to_list()[0]

                        # Determine which tenant name to use for credentials
                        if parent_tenant_id is None:
                            # This is a main tenant
                            credential_tenant_name = tenant_name
                        else:
                            # This is a sub-tenant, get the parent tenant name
                            parent_query = f"select tenant_name from tenant where id='{parent_tenant_id}'"
                            credential_tenant_name = common_utils_database.execute_query(parent_query, True)['tenant_name'].to_list()[0]

                        # Apply special case mapping
                        if credential_tenant_name in ["Altaworx Test", "Altaworx"]:
                            credential_tenant_name = "ALTAWORX"

                        # Normalize tenant name
                        # normalized_tenant = credential_tenant_name.upper().replace(" ", "_")

                        # Set headers based on final resolved credential tenant
                        if credential_tenant_name == "ALTAWORX":
                            update_request_headers = {
                                "Content-Type": "application/json-patch+json",
                                "Ocp-Apim-Subscription-Key": "bb539cd68dcb4d0ea06a5d407d09e12d",
                                "Authorization": "Basic QU1PUFRvUmV2aW9AYWx0YXdvcnhfc2FuZGJveDpHZW9sb2d5N0BTaG93aW5nQFN0YW5r",
                            }
                        else:
                            update_request_headers = {
                                "Content-Type": "application/json-patch+json",
                                "Ocp-Apim-Subscription-Key": "bb539cd68dcb4d0ea06a5d407d09e12d",
                                "Authorization": "Basic QU1PUFRvUmV2aW9AYWx0YXdvcnhfc2FuZGJveDpHZW9sb2d5N0BTaG93aW5nQFN0YW5r",
                            }
                except Exception as e:
                    logging.info(f"Error in setting headers: {e}")
                
                service_pro_id = int(service_product["service_product_id"])
                update_product_url = f"{BASE_URL}/ServiceProduct/{service_pro_id}"
                logging.info(f"### Updating service_product_id {service_pro_id} with PATCH {update_product_url}")
                update_product_response = requests.patch(update_product_url, headers=update_request_headers, data=json_patch)

                # Track if service product update was successful
                service_product_update_success = update_product_response.status_code in [200, 201]
                
                # Check if ALL APIs were successful (including the initial GET calls)
                all_apis_success = (
                    search_inventory_response.status_code == 200 and
                    assign_inventory_success and
                    service_product_update_success
                )

                # Create entries for each ICCID
                for iccid in iccid_list:
                    # Create one log entry for Service Product Update PATCH
                    log_entry_service = {
                        "bulk_change_id": bulk_change_id,
                        "log_entry_description": f"PATCH update service product {service_pro_id} (ICCID: {iccid})",
                        "request_text": json_patch,
                        "has_errors": not service_product_update_success,
                        "response_status": update_product_response.status_code,
                        "response_text": update_product_response.text,
                        "error_text": update_product_response.text if not service_product_update_success else None,
                        "processed_date": request_received_at,
                        "processed_by": firstLastName,
                        "created_by": firstLastName,
                        "created_date": request_received_at,
                        "modified_by": firstLastName,
                        "modified_date": request_received_at,
                        "is_deleted": False,
                        "is_active": True,
                    }
                    bulk_change_logs.append(log_entry_service)

                    # Create one bulk_request_entry for this ICCID
                    bulk_request_entry = {
                        "mobility_id": iccid_mobility_device_dict.get(iccid),
                        "bulk_change_id": bulk_change_id,
                        "iccid": iccid,
                        "subscriber_number": iccid_msisdn_dict.get(iccid),
                        "change_request": json_patch,
                        "device_id": None,
                        "is_processed": True,
                        "has_errors": not all_apis_success,
                        "status": "PROCESSED" if all_apis_success else "ERROR",
                        "status_details": None if all_apis_success else "One or more API calls failed",
                        "processed_date": request_received_at,
                        "processed_by": firstLastName,
                        "created_by": firstLastName,
                        "created_date": request_received_at,
                        "is_deleted": False,
                        "is_active": True,
                        "tenant_id": tenant_id,
                        "tenant_name": tenant_name,
                        "modified_by": firstLastName,
                        "modified_date": request_received_at,
                    }
                    bulk_change_requests.append(bulk_request_entry)

                # Update counters - 1 count per ICCID based on ALL APIs success
                if all_apis_success:
                    success_count += len(iccid_list)
                else:
                    error_count += len(iccid_list)

        return {
            "bulk_change_requests": bulk_change_requests,
            "bulk_change_logs": bulk_change_logs,
            "success_count": success_count,
            "error_count": error_count,
        }
    except Exception as e:
        logging.error(f"### Error in hit_all_apis: {e}")
        for iccid in iccid_list:
            bulk_request_entry = {
                "mobility_id": iccid_mobility_device_dict.get(iccid),
                "bulk_change_id": bulk_change_id,
                "iccid": iccid,
                "subscriber_number": iccid_msisdn_dict.get(iccid),
                "change_request": "",
                "device_id": None,
                "is_processed": True,
                "has_errors": True,
                "status": "ERROR",
                "status_details": str(e),
                "processed_date": request_received_at,
                "processed_by": firstLastName,
                "created_by": firstLastName,
                "created_date": request_received_at,
                "is_deleted": False,
                "is_active": True,
                "tenant_id": tenant_id,
                "tenant_name": tenant_name,
                "modified_by": firstLastName,
                "modified_date": request_received_at,
            }
            bulk_change_requests.append(bulk_request_entry)
        return {
            "bulk_change_requests": bulk_change_requests,
            "bulk_change_logs": bulk_change_logs,
            "success_count": success_count,
            "error_count": error_count + len(iccid_list) * int(quantity),
        }            



def submit_assign_service_data(data):
   
    """
    Description:
    Processes and submits service assignment requests for SIM management. This function handles the assignment of 
    services, packages, and products to customers by validating input data, creating bulk change records, 
    and executing API calls to process the assignments.

    The function supports two authentication modes:
    1. Service account authentication (z_access_token) - with role-based access control
    2. Regular session-based authentication

    Key operations performed:
    - Validates customer information and service types
    - Ensures mutual exclusivity between packages and products (exactly one must be provided)
    - Creates bulk change tracking records in the database
    - Processes service assignments for multiple customers and their associated ICCIDs
    - Makes API calls to assign services/packages/products
    - Logs all operations and maintains audit trails
    - Updates bulk change status based on success/error counts

    Parameters:
    - data (dict): A dictionary containing input data with the following key fields:
        - z_access_token (str, optional): Service account authentication token
        - client_id (str): Client identifier for service account mode
        - username (str): Username for regular authentication
        - session_id (str): Session identifier
        - tenant_name (str): Name of the tenant
        - service_provider (str): Service provider name
        - submit_data (dict): Core submission data containing:
            - customer_name (list): List of customer names
            - service_number (list): List of service numbers (required, non-empty)
            - service_type (str): Type of service being assigned
            - revio_package (str): Package identifier (mutually exclusive with revio_product)
            - revio_product (list): List of product identifiers (mutually exclusive with revio_package)
            - quantity (dict): Quantity mapping per customer
            - effective_date (str): When the service assignment takes effect
            - iccid_service_dict (dict): ICCID to service mapping
            - customer_iccid_dict (dict): Customer to ICCID mapping
            - iccid_msisdn_dict (dict): ICCID to MSISDN mapping
        - firstLastName (str): Name of the user making the request
        - request_received_at (str): Timestamp when request was received

    Returns:
    - dict: A dictionary containing:
        - 'flag' (bool): Status of the operation (True if successful, False if failed)
        - 'message' (str): A descriptive message indicating the outcome of the operation
        - 'status_code' (int, optional): HTTP status code for errors (400 for validation, 500 for exceptions)
    """
    logging.info(f"### submit_assign_service_data function called with data: {data}")
    logging.info(
        "### submit_assign_service_data function checkpoint: received data for processing"
    )

    start_time = time.time()
    username = data.get("username", None)
    session_id = data.get("session_id", None)
    module_name = data.get("module_name", None)
    firstLastName = data.get("firstLastName", "")
    request_received_at = data.get("request_received_at", "")
    service_provider = data.get("service_provider", "")
    row_count = data.get("row_count", "")
    common_utils_database = DB("common_utils", **db_config)
    logging.info(
        "### submit_assign_service_data function checkpoint: regular session-based authentication flow"
    )
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    submit_data = data.get("submit_data", {})
    tenant_name = data.get("tenant_name", "")
    row_count = data.get("row_count", "")
    customer_name = submit_data.get("customer_name", [])
    quantity = submit_data.get("quantity", {})
    # iccid_service_dict = submit_data.get("iccid_service_dict", {})
    customer_iccid_dict = submit_data.get("customer_iccid_dict", {})
    iccid_msisdn_dict = submit_data.get("iccid_msisdn_dict", {})
    iccids = submit_data.get("iccid", [])
    service_numbers = submit_data.get("service_number", None)
    
    # Validate service_numbers
    if not service_numbers or all(s is None or str(s).strip() == "" for s in service_numbers):
        logging.info(
            "### submit_assign_service_data function checkpoint: empty or invalid service number"
        )
        return {"flag": False, "message": "Empty or Invalid Service Number"}
    
    try:
        # Get tenant_id
        if tenant_name == "Altaworx Test" or tenant_name == "Altaworx":
            tenant_id = 1
        else:
            try:
                tenant_id = common_utils_database.get_data(
                    "tenant", {"tenant_name": tenant_name}, ["id"]
                )["id"].to_list()[0]
            except Exception as e:
                tenant_id = 1
                logging.warning(
                    f"### submit_assign_service_data function exception: {e}"
                )
        
        # Get service_provider_id
        service_provider_id = database.get_data(
            "serviceprovider",
            {"service_provider_name": service_provider, "is_active": True},
            ["id"],
        )["id"].to_list()[0]
        
        # Set change_request_type and get its id
        change_request_type = "Assign Service"
        change_request_type_id = "4"
        try:
            change_request_type_id = database.get_data(
                "change_request_type",
                {"change_request_type": change_request_type, "is_active": True},
                ["id"],
            )["id"].to_list()[0]
        except Exception as e:
            logging.info(
                f"### submit_assign_service_data function exception while getting change_request_type: {e}"
            )
            change_request_type_id = "4"
        
        # Get customer_id_list
        customer_id_list = []
        try:
            customer_id_list = database.get_data(
                "revcustomer",
                {
                    "customer_name": customer_name,
                    "is_active": True,
                },
                ["rev_customer_id"],
            )["rev_customer_id"].to_list()
            if not customer_id_list:
                logging.info(
                    "### submit_assign_service_data function checkpoint: empty customer list"
                )
                return {"flag": False, "message": "Empty Customer List"}
            customer_id_list = set(customer_id_list)
        except Exception as e:
            logging.info(
                f"### submit_assign_service_data function error while getting customer_ids: {e}"
            )
            return {"flag": False, "message": "Error while getting Customer List"}
        
        # Get device_ids_df
        try:
            device_ids_df = database.get_data(
                "sim_management_inventory",
                {"iccid": iccids, "is_active": True, "tenant_id": tenant_id},
                ["device_id", "mobility_device_id", "iccid", "msisdn", "imei"],
            ).to_dict(orient="records")
        except Exception as e:
            logging.info(f"### submit_assign_service_data: exception while getting device_ids_df: {e}")
            device_ids_df = []
        
        iccid_mobility_device_dict = {record["iccid"]: record["mobility_device_id"] for record in device_ids_df}
        device_ids = {}
        device_mssid = {}
        for ids in device_ids_df:
            device_mssid[ids["iccid"]] = ids
            device_ids[ids["iccid"]] = ids["device_id"] if ids["device_id"] else ids["mobility_device_id"]

        # rev_customer_id_list = set(customer_id_list)
        # rev_customer_id = ",".join(map(str, rev_customer_id_list))
        
        # Prepare bulk_change_data
        bulk_change_data = {
            "service_provider_id": service_provider_id,
            "service_provider": service_provider,
            "tenant_id": tenant_id,
            "change_request_type_id": change_request_type_id,
            "change_request_type": change_request_type,
            "status": "NEW",
            "uploaded": row_count,
            "processed_date": None,
            "processed_by": None,
            "created_by": firstLastName,
            "created_date": request_received_at,
            "modified_by": firstLastName,
            "modified_date": request_received_at,
            "is_deleted": False,
            "is_active": True,
            "errors": 0,
            "success": 0,
        }
        
        # Insert bulk_change_data and get bulk_change_id
        try:
            bulk_change_id = database.insert_data(
                bulk_change_data, "sim_management_bulk_change"
            )
            if not bulk_change_id:
                logging.info(
                    "### submit_assign_service_data function checkpoint: empty bulk change id"
                )
                return {"flag": False, "message": "Empty Bulk Change ID"}
        except Exception as e:
            logging.info(
                f"### submit_assign_service_data function error while inserting bulk data: {e}"
            )
            return {"flag": False, "message": "Error while inserting bulk data"}
        
        logging.info(
            f"### submit_assign_service_data function checkpoint: bulk_change_id {bulk_change_id}"
        )
        
        # Map customer_name_id_dict
        customer_name_id_dict = dict(zip(customer_id_list, customer_name))
        logging.info(
            f"### submit_assign_service_data function checkpoint: customer_id's are {customer_id_list}"
        )
        
        service_numbers = submit_data.get("service_number", None)
        effective_date = submit_data.get("effective_date", None)
        quantity = submit_data.get("quantity", 0)
        
        # Extract package_id from revio_package
        package_id = None
        if submit_data.get("revio_package"):
            match2 = re.search(r"package_id:(\d+)", submit_data["revio_package"])
            if match2:
                package_id = match2.group(1)
        
        # Extract Service_id from service_type
        Service_id = None
        if submit_data.get("service_type"):
            match2 = re.search(r"Service_id:(\d+)", submit_data["service_type"])
            if match2:
                Service_id = match2.group(1)
        
        # Validate Service_id
        if not Service_id or str(Service_id).strip() == "":
            logging.error("### submit_assign_service_data function checkpoint: Invalid Service_id")
            return {"flag": False, "message": "Invalid or missing Service_id"}
        
        logging.info(f"### submit_assign_service_data function checkpoint: Service_id is {Service_id}")
        
        # Extract product_ids from revio_product
        product_ids = []
        if submit_data.get("revio_product"):
            for product_id in submit_data["revio_product"]:
                match2 = re.search(r"product_id:(\d+)", product_id)
                if match2:
                    product_id_ = match2.group(1)
                    product_ids.append(product_id_)
        
        bulk_change_requests = []
        bulk_change_logs = []
        success_count = 0
        error_count = 0
        customer_iccid_dict_data = {}
        
        # Map customer_iccid_dict_data
        for name in customer_iccid_dict:
            for cus_id in customer_name_id_dict:
                if customer_name_id_dict[cus_id] == name:
                    customer_iccid_dict_data[cus_id] = customer_iccid_dict[name]
                    break
        
        try:
            # Process each customer_id and call hit_all_apis
            for customer_id in customer_id_list:
                iccid_list = customer_iccid_dict_data.get(customer_id, [])
                logging.info(
                    f"### submit_assign_service_data function checkpoint: processing customer_id {customer_id} with iccid_list {iccid_list}"
                )
                result = hit_all_apis(
                    customer_id,
                    Service_id,
                    service_numbers,
                    package_id,
                    product_ids,
                    effective_date,
                    quantity[customer_name_id_dict[customer_id]],
                    tenant_name,
                    bulk_change_id,
                    request_received_at,
                    firstLastName,
                    tenant_id,
                    bulk_change_logs,
                    iccid_list,
                    iccid_msisdn_dict,
                    iccid_mobility_device_dict,
                    bulk_change_requests,
                    error_count,
                    success_count,
                )
                bulk_change_requests = result["bulk_change_requests"]
                bulk_change_logs = result["bulk_change_logs"]
                success_count = result["success_count"]
                error_count = result["error_count"]
        except Exception as e:
            logging.info(
                f"### submit_assign_service_data function exception during API processing: {e}"
            )
            pass

        # Process bulk change requests if any exist
        if bulk_change_requests:
            res = database.insert_data(
                bulk_change_requests, "sim_management_bulk_change_request"
            )
            logging.info(
                f"### submit_assign_service_data function checkpoint: bulk_change_requests inserted {res}"
            )
            
            # Generate sequential request IDs
            request_ids = list(range(res, res + len(bulk_change_requests)))
            
            # Map request IDs to ICCIDs
            iccid_to_request_id = {req["iccid"]: request_ids[i] for i, req in enumerate(bulk_change_requests) if "iccid" in req}
            
            # Assign bulk_change_request_id to ICCID-specific logs
            for log_entry in bulk_change_logs:
                # Default to None for non-ICCID-specific logs
                log_entry["bulk_change_request_id"] = None
                # Check for ICCID in log_entry_description
                iccid_match = re.search(r"\(ICCID: (\S+)\)", log_entry["log_entry_description"])
                if iccid_match:
                    iccid = iccid_match.group(1)
                    if iccid in iccid_to_request_id:
                        log_entry["bulk_change_request_id"] = iccid_to_request_id[iccid]
                # Handle general logs with ICCID lists (e.g., GET service products)
                elif "GET active service products" in log_entry["log_entry_description"]:
                    # Remove ICCID list from log_entry_description
                    log_entry["log_entry_description"] = re.sub(r", \[.*?\]$", "", log_entry["log_entry_description"])
            
            # Insert logs after assigning request IDs
            if bulk_change_logs:
                log_res = database.insert_data(
                    bulk_change_logs, "sim_management_bulk_change_log"
                )
                logging.info(
                    f"### submit_assign_service_data function checkpoint: bulk_change_logs inserted {log_res}"
                )
        
        # Update bulk_change status
        update_data = {
            "success": success_count,
            "errors": error_count,
            "status": "PROCESSED" if error_count == 0 else "ERROR",
            "processed_date": request_received_at,
            "processed_by": firstLastName,
            "progress": "Sync Completed"
        }
        res = database.update_dict(
            "sim_management_bulk_change", update_data, {"id": bulk_change_id}
        )
        logging.info(
            f"### submit_assign_service_data function checkpoint: bulk_change update_data {res}"
        )
        
        message = "Assign Service data submitted successfully"
        response = {"flag": True, "message": message}
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        
        # Audit log
        audit_data_user_actions = {
            "service_name": "submit_assign_service_data",
            "created_by":username ,
            "status": str(response["flag"]),
            "session_id": session_id ,
            "tenant_name": tenant_name ,
            "comments": f"Assign Service data submitted sucessfully in {time_consumed} seconds",
            "module_name": "Rev Assuarance",
            "request_received_at": request_received_at ,
        }
        logging.info(
            f"### submit_assign_service_data function checkpoint: audit log {audit_data_user_actions}"
        )
        common_utils_database.update_audit(
            audit_data_user_actions, "audit_user_actions"
        )
        return response
    except Exception as e:
        logging.exception(f"### submit_assign_service_data function exception: {e}")
       
        error_data = {
            "service_name": "submit_assign_service_data",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": username,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": f"Error occurred while submitting assign service data: {str(e)}",
            "module_name": module_name,
            "request_received_at": request_received_at ,
        }
        logging.info(
            f"### submit_assign_service_data function checkpoint: error log {error_data}"
        )
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": message, "status_code": 500}


def deactivate_service_product(data):
    
    """
    Deactivates service products for specified customers by making API requests to the Revio service and 
    updating the database with bulk change tracking. This function handles both service account 
    authentication and regular session-based authentication modes.

    The function performs the following operations:
    - Validates input data and authentication credentials
    - Retrieves device information from SIM management inventory
    - Makes DELETE API requests to deactivate service products
    - Creates bulk change tracking records for audit and monitoring
    - Updates service product status in the database
    - Logs all operations and maintains comprehensive audit trails
    - Triggers rev_actions for additional processing

    Authentication Modes:
    1. Service account mode (z_access_token): Role-based access control, denies "User" and "Agent" roles
    2. Regular session mode: Standard username/session authentication

    Returns:
        dict: See docstring above.
    """
    logging.info(f"### deactivate_service_product function called with data: {data}")
    try:
        for key in ["tenant_ids", "feature_codes", "customer_rate_plan_name", "billing_account_number"]:
            try:
                del db_config[key]
            except KeyError:
                pass

    except Exception as e:
        logging.warning(
            f"### add_service_line_data function: Exception deleting tenant_ids from db_config: {e}"
        )
   
    z_access_token = data.get("z_access_token", "")
    start_time = time.time()
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    firstLastName = data.get("firstLastName", "")
    session_id = data.get("session_id", " ")
    Partner = data.get("Partner", " ")
    tenant_database = data.get("db_name", "")
    tenant_name = data.get("tenant_name", "")
    submit_data = data.get("submit_data", {})
    row_count = data.get("row_count", 0)
    service_provider = data.get("service_provider", "")
    customer_name = submit_data.get("customer_name", [])
    customer_ids = data.get("customer_id", [])
    iccids = submit_data.get("iccid", [])
    request_received_at = data.get("request_received_at", " ")

    # Authentication and context extraction
    if z_access_token:
        try:
            logging.info("### deactivate_service_product function checkpoint: service account authentication flow")
            username = data.get("client_id", "")
            request_received_at = datetime.datetime.now()
            context_data = get_service_account_context(username)
            if not context_data:
                logging.error("### deactivate_service_product function: Failed to get context data for username: %s", username)
                return {"flag": False, "message": "Failed to retrieve service account context."}
            role = context_data.get("role", "")
            if role in ["User", "Agent"]:
                return {"flag": False, "message": "You do not have permission to perform this action."}
            tenant_name = context_data.get("tenant_name", "")
            database = context_data.get("database", None)
            deactivate_data_list = data.get("service_product_details", [])
            customer_ids = data.get("customer_ids", [])
            iccids = []
        except Exception as e:
            logging.warning(f"### deactivate_service_product function exception: {e}")
            return {"message": "Invalid details", "status_code": 400}
    else:
        logging.info("### deactivate_service_product function checkpoint: regular session-based authentication flow")
        username = data.get("username", " ")
        session_id = data.get("session_id", " ")
        Partner = data.get("Partner", " ")
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        deactivate_data_list = submit_data.get("deactivate_data", {})
        customer_ids = data.get("customer_id", [])
        tenant_name = data.get("tenant_name", "")
        iccids = submit_data.get("iccid", [])
        
        
    
    validate_required(tenant_name, "tenant_name")
    validate_required(service_provider, "service_provider")
    validate_required(customer_name, "customer_name")

    # Get tenant_id
    if tenant_name == "Altaworx Test" or tenant_name == "Altaworx":
        tenant_id = 1
    else:
        try:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            logging.info(f"### deactivate_service_product function checkpoint: tenant_id {tenant_id}")
        except Exception as e:
            tenant_id = None
            logging.warning(f"### deactivate_service_product function exception: {e}")

    # Fetch device info for ICCIDs
    device_ids_df = database.get_data(
        "sim_management_inventory",
        {"iccid": iccids, "is_active": True, "tenant_id": tenant_id},
        ["device_id", "mobility_device_id", "iccid", "msisdn", "imei", "msisdn"],
    ).to_dict(orient="records")
    device_ids = {}
    device_mssid = {}
    for ids in device_ids_df:
        device_mssid[ids["iccid"]] = ids
        device_ids[ids["iccid"]] = ids["device_id"] if ids["device_id"] else ids["mobility_device_id"]

    try:
        url = os.getenv("SERVICEPRODUCT", " ")
        # Generic header logic: Use environment variable with fallback
        # subscription_key = os.getenv("REVIO_Subscription_Key", "")
        # access_token = os.getenv("REVIO_acess_token", "")
        # If tenant-specific keys exist, use them
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        headers=get_headers(tenant_name)

        bulk_change_requests = []
        response_data = []
        success_flag = True
        message = ""
        total_selected_product = 0
        bulk_change_logs = []
        error_count = 0

        # Validate deactivate_data_list and customer_ids
        if isinstance(deactivate_data_list, dict):
            if len(set(customer_ids)) != len(deactivate_data_list):
                logging.info("### deactivate_service_product function checkpoint: mismatch between customer_id and deactivate_data")
                return {
                    "message": "Mismatch between the number of 'customer_id' and 'deactivate_data' entries.",
                    "status_code": 400,
                }
        else:
            deactivate_data_list = {}

        # Get service_provider_id
        try:
            service_provider_id = database.get_data(
                "serviceprovider",
                {"service_provider_name": service_provider, "is_active": True},
                ["id"],
            )["id"].to_list()[0]
        except Exception as e:
            service_provider_id = None
            logging.warning(f"### deactivate_service_product function exception: {e}")

        # Get change_request_type_id
        change_request_type = "Disconnect Service Product"
        try:
            change_request_type_id = database.get_data(
                "sim_management_bulk_change_type",
                {"display_name": change_request_type, "is_active": True},
                ["id"],
            )["id"].to_list()[0]
        except Exception as e:
            change_request_type_id = None
            logging.warning(f"### deactivate_service_product function exception: {e}")

        # Get rev_customer_id
        try:
            rev_customer_id = database.get_data(
                "revcustomer",
                {"customer_name": customer_name, "is_active": True},
                ["rev_customer_id"],
            )["rev_customer_id"].to_list()
        except Exception as e:
            rev_customer_id = []
            logging.warning(f"### deactivate_service_product function exception: {e}")

        rev_customer_id_list = set(rev_customer_id)
        rev_customer_id = ",".join(map(str, rev_customer_id_list))
        bulk_change_data = {
            "service_provider_id": service_provider_id,
            "service_provider": service_provider,
            "tenant_id": tenant_id,
            "change_request_type_id": change_request_type_id,
            "change_request_type": change_request_type,
            "status": "NEW",
            "uploaded": row_count,
            "customer_id": str(rev_customer_id) if rev_customer_id else None,
            "processed_date": None,
            "processed_by": None,
            "created_by": firstLastName,
            "created_date": request_received_at,
            "modified_by": firstLastName,
            "modified_date": request_received_at,
            "is_deleted": False,
            "is_active": True,
            "errors": 0,
            "success": 0,
        }
        bulk_change_id = database.insert_data(
            bulk_change_data, "sim_management_bulk_change"
        )
        success_count = 0

        # Process each customer and their deactivation data
        for customer_id, data_list in deactivate_data_list.items():
            for deactivate_data in data_list:
                service_product_id = deactivate_data.get("service_product_id")
                effective_date = deactivate_data.get("effective_date")
                generate_proration = deactivate_data.get("generate_proration", True)
                iccid = deactivate_data.get("iccid", "")
                if not service_product_id:
                    logging.info("### deactivate_service_product function checkpoint: missing service_product_id")
                    response_data.append(
                        {
                            "customer_id": customer_id,
                            "status": "Failed",
                            "error_message": "Service Product ID is missing or null.",
                        }
                    )
                    success_flag = False
                    continue
                device_info = device_mssid.get(iccid, {})
                params = {
                    "service_product_id": service_product_id,
                    "effective_date": effective_date,
                    "generate_proration": generate_proration,
                }
                logging.info(f"### deactivate_service_product function checkpoint: calling API for service_product_id {service_product_id}")
                logging.info(f"### url : {url} and headers : {headers} and params : {params} ")
                response = requests.delete(url, headers=headers, json=params)
                logging.info(f"### response : {response} ")
                if response.status_code == 200:
                    success_count += 1
                    request_status = "PROCESSED"
                    has_errors = False
                    response_data.append(
                        {"service_product_id": service_product_id, "status": "Success"}
                    )
                else:
                    request_status = "ERROR"
                    has_errors = True
                    error_count += 1
                    response_data.append(
                        {
                            "service_product_id": service_product_id,
                            "status": "Failed",
                            "error_code": response.status_code,
                            "error_message": response.text,
                        }
                    )
                    success_flag = False

                bulk_request_entry = {
                    "mobility_id": device_info.get("mobility_device_id"),
                    "bulk_change_id": bulk_change_id,
                    "iccid": iccid,
                    "subscriber_number": device_info.get("msisdn"),
                    "change_request": json.dumps(params),
                    "device_id": device_ids.get(iccid) if iccid else None,
                    "is_processed": response.status_code in [200, 201],
                    "has_errors": has_errors,
                    "status": request_status,
                    "status_details": response.text,
                    "processed_date": request_received_at if response else None,
                    "processed_by": firstLastName if response else None,
                    "created_by": firstLastName,
                    "created_date": request_received_at,
                    "is_deleted": False,
                    "is_active": True,
                    "tenant_id": tenant_id,
                    "tenant_name": tenant_name,
                    "modified_by": firstLastName,
                    "modified_date": request_received_at,
                }
                bulk_change_requests.append(bulk_request_entry)
                log_entry = {
                    "bulk_change_id": bulk_change_id,
                    "log_entry_description": f"API Request for Service Product ID {service_product_id}" + (f" (ICCID: {iccid})" if iccid else ""),
                    "request_text": json.dumps(params),
                    "has_errors": has_errors,
                    "response_status": response.status_code,
                    "response_text": response.text,
                    "error_text": response.text if has_errors else None,
                    "processed_date": request_received_at,
                    "processed_by": firstLastName,
                    "created_by": firstLastName,
                    "created_date": request_received_at,
                    "modified_by": firstLastName,
                    "modified_date": request_received_at,
                    "is_deleted": False,
                    "is_active": True,
                }
                bulk_change_logs.append(log_entry)

        # Update rev_service_product status
        update_data = {"status": "DISCONNECTED", "status_date": request_received_at}
        database.update_dict(
            "rev_service_product",
            update_data,
            {
                "service_product_id": service_product_id,
                "is_active": True,
                "customer_id": customer_id,
            },
        )

        # Insert bulk change requests and logs
        if bulk_change_requests:
            first_id = database.insert_data(
                bulk_change_requests, "sim_management_bulk_change_request"
            )
            logging.info(f"### first_id : {first_id}")
            logging.info("### deactivate_service_product function checkpoint: bulk_change_requests inserted")

        # Calculate all inserted IDs (sequential)
        request_ids = list(range(first_id, first_id + len(bulk_change_requests)))
        
        # Add bulk_change_request_id to each log entry
        for i, log_entry in enumerate(bulk_change_logs):
            log_entry["bulk_change_request_id"] = request_ids[i]
        logging.info(f"### deactivate_service_product function checkpoint: request_ids {request_ids}")


        if bulk_change_logs:
            database.insert_data(bulk_change_logs, "sim_management_bulk_change_log")
            logging.info("### deactivate_service_product function checkpoint: bulk_change_logs inserted")
        update_data = {
            "success": success_count,
            "errors": error_count,
            "status": "PROCESSED" if error_count == 0 else "ERROR",
            "processed_date": request_received_at,
            "processed_by": firstLastName,
            "progress":"Sync Completed"
        }
        database.update_dict(
            "sim_management_bulk_change", update_data, {"id": bulk_change_id}
        )

        # Call rev_actions for additional processing
        try:
            common_utils_db_conn = DB("common_utils", **db_config)
            if tenant_name == "Altaworx Test":
                tenant_name_lcase = "altaworx"
            elif tenant_name == "Altaworx":
                tenant_name_lcase = "altaworx"
            else:
                tenant_name_query = "select db_name from tenant where tenant_name= %s"
                tenant_name_df = common_utils_db_conn.execute_query(tenant_name_query, params=[tenant_name])
                tenant_name_lcase = tenant_name_df["db_name"].iloc[0].lower()
            data_transfer = DataTransfer()
            data_transfer.rev_actions({
                "key-name": f"deactivated_service_product_{tenant_name_lcase}",
                "service_product_id": service_product_id,
                "customer_id": customer_id,
            })
        except Exception as e:
            logging.error(f"### deactivate_service_product function exception during rev_actions call: {e}")

        total_selected_product += 1
        if success_flag:
            message = "All service products successfully deactivated."
        else:
            message = "Some service products failed to deactivate."

        response = {
            "flag": success_flag,
            "data": response_data,
            "message": message,
            "total_selected_product": total_selected_product,
            "RevCustomerId": customer_ids,
        }
        if z_access_token:
            response["status_code"] = 200

        # Audit logging
        try:
            end_time = time.time()
            time_consumed = int(float(f"{end_time - start_time:.4f}"))
            audit_data_user_actions = {
                "service_name": "deactivate_service_product",
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f"{message} in {time_consumed} seconds",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at,
            }
            logging.info(f"### deactivate_service_product function checkpoint: audit log {audit_data_user_actions}")
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### deactivate_service_product function exception: {e}")

        return response
    except Exception as e:
        logging.exception(f"### deactivate_service_product function exception: {e}")
        
        error_type = type(e).__name__
        try:
            error_data = {
                "service_name": "deactivate_service_product",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": tenant_database,
                "comments":f"Error occurred while deactivating service product: {str(e)}",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at,
            }
            logging.info(f"### deactivate_service_product function checkpoint: error log {error_data}")
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(f"### deactivate_service_product function failed to log error to database: {logging_error}")
        if z_access_token:
            response = {"status_code": 500, "message": message}
        else:
            response = {"flag": False, "message": message}
        return response


def capitalize_columns(df):
    """Capitalizes the column names of the DataFrame."""
    df.columns = df.columns.str.replace("_", " ").str.title()
    return df


def rev_assurance_button_upload_download(data):
    """
    Generates an Excel template for bulk operations in Revenue Assurance.

    This function generates downloadable Excel templates for various bulk upload operations
    (add service line, add service product, disconnect service product, assign service)
    in the Revenue Assurance module. It dynamically builds the template columns, adds
    sample data, and includes additional reference sheets (such as products, packages, etc.)
    based on the selected operation.

    Args:
        data (dict): Input dictionary containing:
            - button_name (str): The operation type (e.g., "add_service_line").
            - db_name (str): The tenant database name.
            - tenant_name, username, service_provider, etc.: Contextual info.

    Returns:
        dict: {
            "flag": True/False,
            "blob": base64-encoded Excel file (if success),
            "message": Status message
        }
    """
    logging.info(f"### rev_assurance_button_upload_download function called with data: {data}")
    try:
        button_name = data.get("button_name", "")
        db_name = data.get("db_name", "")
        username= data.get("username", "") 
        session_id =  data.get("session_id", "") 
        tenant_name = data.get("tenant_name", "")
        request_received_at = data.get("request_received_at")
        logging.info(
            f"### rev_assurance_button_upload_download function: Generating template for button: {button_name}"
        )

        database = DB(db_name, **db_config)
        common_utils_db = DB(os.environ.get("COMMON_UTILS_DATABASE"), **db_config)

        # Configuration for each button type
        button_configs = {
            "add_service_line": {
                "columns": [
                    "customer_name",
                    "provider_name",
                    "service_type",
                    "revio_product",
                    "revio_package",
                    "rate",
                    "rate_plan",
                    "activation_date",
                    "quantity",
                    "add_rate_plan",
                    "prorate",
                    "use_carrier_activation",
                    "description",
                    "iccid",
                    "usage_plan_group",
                    "service_number",
                    "service_provider",
                ],
                "rename_columns": {"service_number": "msisdn"},
                "sample_data": {
                    "customer_name": "Example Customer Inc.",
                    "provider_name": "RevIO Connect",
                    "service_type": "Mobile Data - 5G",
                    "revio_product": "Smartphone Plan Alpha - Prod001",
                    "revio_package": "Gold Package - Pkg101",
                    "rate": "5.00",
                    "rate_plan": "Standard Corporate Plan",
                    "activation_date": "2024-12-01T00:00:00Z",
                    "quantity": "1",
                    "add_rate_plan": "TRUE",
                    "prorate": "TRUE",
                    "use_carrier_activation": "FALSE",
                    "description": "New service line for marketing team",
                    "iccid": "890123456789012345F",
                    "usage_plan_group": "Default Data Users - UPG01",
                    "service_number": "15551234567",
                    "service_provider_name": "AT&T",
                },
            },
            "add_service_product": {
                "columns": [
                    "iccid",
                    "msisdn",
                    "revio_service",
                    "customer_name",
                    "product_name",
                    "rate",
                    "quantity",
                    "prorate",
                    "effective_date",
                    "description",
                    "service_provider",
                ],
                "sample_data": {
                    "iccid": "890123456789012345F",
                    "msisdn": "15551234567",
                    "revio_service": "96692",
                    "customer_name": "Example Customer Inc.",
                    "product_name": "Iealink CP920 Conference Phone",
                    "rate": "0",
                    "quantity": "1",
                    "prorate": "TRUE",
                    "effective_date": "2024-11-15T00:00:00Z",
                    "description": "Adding roaming for upcoming trip",
                    "service_provider": "AT&T",
                },
            },
            "disconnect_service_product": {
                "columns": [
                    "iccid",
                    "msisdn",
                    "customer_name",
                    "effective_date",
                    "generate_proration",
                ],
                "sample_data": {
                    "iccid": "890123456789012345F",
                    "msisdn": "15551234567",
                    "customer_name": "Example Customer Inc.",
                    "service_product_id_to_disconnect": "SvcProdID789",
                    "effective_date": "2024-12-31T23:59:59Z",
                    "generate_proration": "TRUE",
                },
            },
            "assign_service": {
                "columns": [
                    "iccid",
                    "msisdn",
                    "service_type",
                    "customer_name",
                    "product",
                    "package",
                    "effective_date",
                    "service_provider",
                ],
                "sample_data": {
                    "iccid": "890123456789012345A",
                    "msisdn": "15559876543",
                    "service_type": "Mobile Voice - BasicVoiceSvcID",
                    "customer_name": "Another Customer LLC",
                    "product": "Voicemail Pro - ProdVM01",
                    "package": "Business Voice Bundle - PkgVoice02",
                    "effective_date": "2024-11-20T00:00:00Z",
                    "service_provider": "Verizon",
                },
            },
        }

        config = button_configs.get(button_name)
        if not config:
            logging.info(
                f"### rev_assurance_button_upload_download function: Unsupported button type: {button_name}"
            )
            raise ValueError(f"Unsupported button type: {button_name}")

        # Build template DataFrame and sample data
        columns_df = pd.DataFrame({"column_name": config["columns"]})
        if config.get("rename_columns"):
            columns_df["column_name"] = columns_df["column_name"].replace(
                config["rename_columns"]
            )
        columns_df["column_name"] = (
            columns_df["column_name"].str.replace("_", " ").str.title().str.strip()
        )
        template_df = pd.DataFrame(columns=columns_df["column_name"].tolist())
        sample_df = pd.DataFrame([config["sample_data"]])
        sample_df = capitalize_columns(sample_df)

        additional_sheets = []

        # Add dropdown/reference sheets for each button type
        if button_name == "add_service_line":
            dropdown_payload = {
                "tenant_name": data.get("tenant_name"),
                "username": data.get("username"),
                "db_name": db_name,
                "service_provider": data.get("service_provider"),
                "customer_name": data.get("customer_name"),
            }
            logging.info(
                "### rev_assurance_button_upload_download function: Fetching dropdown data for add_service_line"
            )
            dropdown_response = add_service_line_dropdown_data(dropdown_payload)
            if dropdown_response.get("flag"):
                dropdown_data = dropdown_response.get("response_data", {})

                sp_df = pd.DataFrame(dropdown_data.get("rev_provider", []))
                if not sp_df.empty:
                    sp_df = sp_df[["description", "provider_id"]]
                    sp_df.columns = ["Service Provider Name", "Service Provider ID"]
                    additional_sheets.append(("Service Providers", sp_df))

                product_df = pd.DataFrame(dropdown_data.get("rev_product_rate", []))
                if not product_df.empty:
                    product_df = product_df[["description", "product_id", "rate"]]
                    product_df.columns = ["Product Description", "Product ID", "Rate"]
                    additional_sheets.append(("Products", product_df))

                package_list = []
                for pkg_entry in dropdown_data.get("rev_package_rate", []):
                    pkg_info = pkg_entry[0]
                    package_list.append(
                        {
                            "Package ID": pkg_info.get("package_id"),
                            "Package Description": pkg_info.get("description"),
                            "Provider ID": pkg_info.get("provider_id"),
                        }
                    )
                package_df = pd.DataFrame(package_list)
                if not package_df.empty:
                    additional_sheets.append(("Packages", package_df))

                usage_plan_groups = dropdown_data.get("rev_usage_plan_group", [])
                if usage_plan_groups:
                    usage_plan_df = pd.DataFrame(
                        {"Usage Plan Group": usage_plan_groups}
                    )
                    additional_sheets.append(("Usage Plan Groups", usage_plan_df))

                rate_plans = dropdown_data.get("customer_rate_plan_dropdown", [])
                if rate_plans:
                    rate_plan_df = pd.DataFrame({"Customer Rate Plan": rate_plans})
                    additional_sheets.append(("Customer Rate Plans", rate_plan_df))

        elif button_name == "add_service_product":
            try:
                integration_authentication_json_data = (
                    load_integration_authentication_json()
                )
                integration_authentication_id = (
                    get_integration_authentication_id_by_unique_name(
                        integration_authentication_json_data, data.get("tenant_name")
                    )
                )
                logging.info(
                    f"### rev_assurance_button_upload_download function: Fetching product data for add_service_product for tenant {data.get('tenant_name')} with integration_authentication_id {integration_authentication_id}"
                )

                product_query = """
                    SELECT description, product_id, rate 
                    FROM rev_product
                    WHERE integration_authentication_id = %s
                    AND is_active = TRUE
                """
                product_data = database.execute_query(
                    product_query, params=[integration_authentication_id]
                )

                if not product_data.empty:
                    product_df = product_data[["description", "product_id", "rate"]]
                    product_df.columns = ["Product Description", "Product ID", "Rate"]
                    additional_sheets.append(("Products", product_df))

            except Exception as e:
                logging.error(
                    f"### rev_assurance_button_upload_download function: Failed to fetch add_service_product data: {str(e)}"
                )
                return {"flag": False, "message": f"Data retrieval failed: {str(e)}"}

        elif button_name == "disconnect_service_product":
            logging.info(
                "### rev_assurance_button_upload_download function: Fetching service providers for disconnect_service_product"
            )
            sp_df = database.get_data(
                "serviceprovider",
                {"is_active": True},
                ["id", "service_provider_name"],
                order={"service_provider_name": "asc"},
            )
            sp_df.columns = ["Service Provider Id", "Service Provider Name"]
            additional_sheets.append(("Service Providers", sp_df))

        elif button_name == "assign_service":
            try:
                integration_authentication_json_data = (
                    load_integration_authentication_json()
                )
                integration_authentication_id = (
                    get_integration_authentication_id_by_unique_name(
                        integration_authentication_json_data, data.get("tenant_name")
                    )
                )
                logging.info(
                    f"### rev_assurance_button_upload_download function: Fetching assign_service data for tenant {data.get('tenant_name')} with integration_authentication_id {integration_authentication_id}"
                )

                service_query = """
                    SELECT 
                        rs.number AS service_number,
                        rs.rev_service_id,
                        rst.description AS service_type,
                        CONCAT(rs.number,' - Service_id:',rs.rev_service_id,' - Service_type:',rst.description) AS combined_service
                    FROM rev_service rs
                    JOIN rev_service_type rst ON rs.rev_service_type_id = rst.id
                    WHERE rs.is_active = TRUE
                    AND rs.is_deleted = FALSE
                    AND rs.integration_authentication_id = %s
                    ORDER BY rs.id
                """
                service_df = database.execute_query(service_query, params=[integration_authentication_id])
                if not service_df.empty:
                    service_df = service_df[["combined_service", "rev_service_id"]]
                    service_df.columns = ["Service Description", "Service ID"]
                    additional_sheets.append(("Services", service_df))

                package_query = """
                    SELECT DISTINCT
                        CONCAT(rp.description,' - package_id:',rp.package_id) AS combined_package,
                        SP.service_id
                    FROM rev_package rp
                    INNER JOIN rev_service_product SP ON SP.package_id = CAST(rp.package_id AS INTEGER)
                    WHERE SP.is_active = TRUE
                    AND SP.is_deleted = FALSE
                    AND rp.is_active = TRUE
                    AND rp.is_deleted = FALSE
                    AND SP.integration_authentication_id = %s
                    AND rp.integration_authentication_id = %s
                    AND SP.status = 'ACTIVE'
                    AND SP.package_id <> 0
                """
                package_df = database.execute_query(package_query, params=[integration_authentication_id,integration_authentication_id])
                if not package_df.empty:
                    package_df = package_df[["combined_package", "service_id"]]
                    package_df.columns = ["Package Description", "Service ID"]
                    additional_sheets.append(("Packages", package_df))

                product_query = """
                    SELECT 
                        CONCAT(description,' - product_id:',service_product_id) AS combined_product,
                        service_id
                    FROM rev_service_product
                    WHERE is_active = TRUE
                    AND is_deleted = FALSE
                    AND integration_authentication_id = %s
                    AND status = 'ACTIVE'
                """
                product_df = database.execute_query(product_query, params=[integration_authentication_id])
                if not product_df.empty:
                    product_df = product_df[["combined_product", "service_id"]]
                    product_df.columns = ["Product Description", "Service ID"]
                    additional_sheets.append(("Products", product_df))

            except Exception as e:
                logging.error(
                    f"### rev_assurance_button_upload_download function: Failed to fetch assign service data: {str(e)}"
                )
                return {"flag": False, "message": f"Data retrieval failed: {str(e)}"}

        logging.info(
            f"### rev_assurance_button_upload_download function: Generating Excel blob for button {button_name}"
        )
        blob_data = dataframeto_blob_bulk_upload(
            template_df, sample_data=sample_df, additional_sheets=additional_sheets
        )

        response = {
            "flag": True,
            "blob": blob_data.decode("latin-1"),
            "message": "Template generated successfully",
        }

        # Audit logging (removed created_date from audit_data)
        audit_data = {
            "service_name": "rev_assurance_button_upload_download",
            "created_by": username ,
            "session_id": session_id ,
            "tenant_name": tenant_name ,
            "comments": f"Template generated for {button_name} operation",
            "module_name": "Rev Assuarance",
            "request_received_at": request_received_at ,
            "status": str(response["flag"]),
        }
        logging.info(
            f"### rev_assurance_button_upload_download function: Logging audit data: {audit_data}"
        )
        common_utils_db.update_audit(audit_data, "audit_user_actions")

        return response

    except Exception as e:
        logging.exception(
            f"### rev_assurance_button_upload_download function: Exception occurred: {e}"
        )
       
        error_type = type(e).__name__
        try:
            
            error_data = {
                "service_name": "rev_assurance_button_upload_download",
                "error_message": str(e),
                "error_type": error_type,
                "users": username ,
                "session_id": session_id ,
                "tenant_name": tenant_name ,
                "comments": f"Error occurred while generating template for {button_name}: {str(e)}",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at ,
            }
            logging.info(
                f"### rev_assurance_button_upload_download function: Logging error to DB: {error_data}"
            )
            common_utils_db = DB(os.environ.get("COMMON_UTILS_DATABASE"), **db_config)
            common_utils_db.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(
                f"### Exception while auditing error and exception is :  {logging_error}"
            )

        return {"flag": False, "message": f"Template generation failed: {str(e)}"}


def dataframeto_blob_bulk_upload(template_df, sample_data=None, additional_sheets=None):
    """
    Converts pandas DataFrames into a base64 encoded Excel blob.

    Args:
        template_df (pd.DataFrame): The main template DataFrame.
        sample_data (pd.DataFrame, optional): Sample data DataFrame.
        additional_sheets (list of (str, pd.DataFrame), optional): List of (sheet_name, DataFrame) tuples.

    Returns:
        bytes: Base64 encoded Excel file.
    """

    def write_dataframe(ws: Worksheet, df, bold_header=True):
        """
        Writes a DataFrame to an openpyxl worksheet with optional bold headers.
        Sets number format to text for columns containing ICCID, MSISDN, or ID.
        """
        for col_idx, col in enumerate(df.columns, start=1):
            cell = ws.cell(row=1, column=col_idx, value=str(col))
            if bold_header:
                cell.font = Font(bold=True)
        for row_idx, row in enumerate(df.itertuples(index=False), start=2):
            for col_idx, value in enumerate(row, start=1):
                cell_value = "" if value is None else str(value)
                cell = ws.cell(row=row_idx, column=col_idx, value=cell_value)
                header = str(df.columns[col_idx - 1]).lower()
                if any(
                    k in header
                    for k in ["iccid", "msisdn", "id", "service provider id"]
                ):
                    cell.number_format = "@"

    output = io.BytesIO()
    wb = Workbook()
    default_ws = wb.active
    wb.remove(default_ws)
    ws_template = wb.create_sheet(title="Template")
    write_dataframe(ws_template, template_df)
    if sample_data is not None and not sample_data.empty:
        ws_sample = wb.create_sheet(title="Sample Data")
        write_dataframe(ws_sample, sample_data)
    if additional_sheets:
        for sheet_name, df in additional_sheets:
            if df is not None and not df.empty:
                safe_name = str(sheet_name)[:31]
                safe_name = "".join(c for c in safe_name if c not in r"\\/?*[]:")
                ws = wb.create_sheet(title=safe_name)
                write_dataframe(ws, df)
    wb.save(output)
    output.seek(0)
    logging.info(
        "### dataframeto_blob_bulk_upload function: Excel file generated and encoded"
    )
    return base64.b64encode(output.getvalue())




# Common helper function for blob decoding
def decode_blob_to_dataframe(blob_str: str) -> pd.DataFrame:
    """
    Decodes base64-encoded blob string into a pandas DataFrame.
    
    Handles:
    - Splitting off data URL prefix
    - Adding base64 padding
    - Decoding to BytesIO stream
    - Reading Excel file
    
    Parameters:
    - blob_str (str): Base64 encoded Excel string (with optional data URL prefix)
    
    Returns:
    - pd.DataFrame: Decoded Excel data
    
    Raises:
    - ValueError: If blob data is empty or invalid
    """
    if not blob_str:
        raise ValueError("Blob data not provided")
    
    # Remove data URL prefix if present
    if blob_str.startswith("data:"):
        blob_str = blob_str.split(",", 1)[1]
    
    # Add base64 padding
    blob_str += "=" * (-len(blob_str) % 4)
    
    try:
        # Decode base64 and create file stream
        file_stream = BytesIO(base64.b64decode(blob_str))
    except binascii.Error as e:
        raise ValueError(f"Invalid base64 encoding: {str(e)}")
    
    # Read Excel into DataFrame
    return pd.read_excel(file_stream, engine="openpyxl")


# Refactored handler functions
def handle_add_service_product_upload(data):
    """
    Processes uploaded add_service_product data with validation and payload formatting.

    This function parses an uploaded Excel file for adding products to services,
    validates ICCIDs and service provider, groups data by customer, and prepares
    a payload for downstream processing.

    Parameters:
    - data (dict): Input dictionary with keys like 'db_name', 'blob', etc.

    Returns:
    - dict: Result from submit_service_product_data or error message.
    """
    logging.info(f"### handle_add_service_product_upload function called with data: {data}")
    try:
        username= data.get("username", "") 
        session_id =  data.get("session_id", "") 
        tenant_name = data.get("tenant_name", "")
        request_received_at = data.get("request_received_at")

        tenant_database = data.get("db_name", "")
        logging.info(
            f"### process_add_service_product_upload function in tenant {tenant_database} checkpoint start processing upload"
        )
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **db_config)

        # Use helper for blob decoding
        try:
            uploaded_dataframe = decode_blob_to_dataframe(data.get("blob"))
        except ValueError as e:
            logging.info(
                f"### process_add_service_product_upload function checkpoint {str(e)}"
            )
            return {"flag": False, "message": str(e)}

        logging.info(
            f"### process_add_service_product_upload function checkpoint uploaded dataframe shape {uploaded_dataframe.shape}"
        )

        if uploaded_dataframe.empty:
            logging.info(
                "### process_add_service_product_upload function checkpoint uploaded Excel has no data"
            )
            return {"flag": False, "message": "Uploaded Excel has no data"}
        
        # Check for record count limit
        if len(uploaded_dataframe) > 20000:
            logging.info(
                "### process_add_service_product_upload function checkpoint: too many records (>20000)"
            )
            return {
                "flag": False,
                "message": "Upload limit exceeded: Please upload 20,000 records or fewer at a time.",
            }

        upload_data = uploaded_dataframe.to_dict(orient="records")
        if not upload_data:
            logging.info(
                "### process_add_service_product_upload function checkpoint no valid rows in uploaded Excel"
            )
            return {"flag": False, "message": "No valid rows in uploaded Excel"}

        logging.info(
            f"### process_add_service_product_upload function checkpoint upload_data length {len(upload_data)}"
        )

        # Vectorized ICCID/MSISDN validation
        df = uploaded_dataframe.copy()
        df["Iccid"] = df["Iccid"].astype(str).str.strip()
        df["Msisdn"] = df["Msisdn"].astype(str).str.strip()

        # ICCID: reject scientific notation and check digit/length
        if df["Iccid"].str.contains(r"e\+|e\-", case=False, regex=True).any():
            bad_iccid = df.loc[df["Iccid"].str.contains(r"e\+|e\-", case=False, regex=True), "Iccid"].iloc[0]
            return {"flag": False, "message": f"Please give valid column values: ICCID format is  {bad_iccid} invalid (scientific notation not allowed) ."}

        iccid_mask = df["Iccid"].str.isdigit() & df["Iccid"].str.len().between(18, 22)
        if not iccid_mask.all():
            bad_iccid = df.loc[~iccid_mask, "Iccid"].iloc[0]
            return {"flag": False, "message": f"Please give valid column values: ICCID format is invalid. Offending value: {bad_iccid}"}

        msisdn_mask = df["Msisdn"].str.isdigit() & df["Msisdn"].str.len().between(7, 15)
        if not msisdn_mask.all():
            bad_msisdn = df.loc[~msisdn_mask, "Msisdn"].iloc[0]
            return {"flag": False, "message": f"Please give valid column values: MSISDN format is invalid. Offending value: {bad_msisdn}"}

        # Vectorized customer data extraction
        customer_names = df["Customer Name"].dropna().astype(str).unique().tolist()
        if not customer_names:
            logging.info(
                "### process_add_service_product_upload function checkpoint no Customer Name found in uploaded file"
            )
            return {
                "flag": False,
                "message": "Customer Name is mandatory and not found in the uploaded file",
            }

        # Group by customer for iccids, msisdns, revio_services
        customer_data = {}
        for customer_name, group in df.groupby("Customer Name"):
            customer_data[customer_name] = {
                "iccids": group["Iccid"].dropna().astype(str).tolist(),
                "msisdns": group["Msisdn"].dropna().astype(str).tolist(),
                "revio_services": [int(x) for x in group["Revio Service"].dropna().tolist() if str(x).isdigit()],
            }

        total_iccids = sum(len(data_lists["iccids"]) for data_lists in customer_data.values())
        if total_iccids == 0:
            logging.info(
                "### process_add_service_product_upload function checkpoint no ICCID values found in uploaded file"
            )
            return {
                "flag": False,
                "message": "ICCID is mandatory and not found in the uploaded file",
            }

        total_revio_services = sum(len(data_lists["revio_services"]) for data_lists in customer_data.values())
        if total_revio_services == 0:
            logging.info(
                "### process_add_service_product_upload function checkpoint no Revio Service values found in uploaded file"
            )
            return {
                "flag": False,
                "message": "Revio Service is mandatory and not found in the uploaded file",
            }

        # Vectorized extraction for static fields (use first non-null)
        product_name = df["Product Name"].dropna().astype(str).iloc[0] if df["Product Name"].dropna().any() else None
        rate = float(df["Rate"].dropna().iloc[0]) if df["Rate"].dropna().any() else 0
        quantity = str(int(df["Quantity"].dropna().iloc[0])) if df["Quantity"].dropna().any() else "1"
        prorate = bool(df["Prorate"].dropna().iloc[0]) if df["Prorate"].dropna().any() else False
        effective_date = str(df["Effective Date"].dropna().iloc[0]).strip() if df["Effective Date"].dropna().any() else ""
        description = str(df["Description"].dropna().iloc[0]).strip() if df["Description"].dropna().any() else None
        service_provider = str(df["Service Provider"].dropna().iloc[0]).strip() if df["Service Provider"].dropna().any() else None

        if not service_provider:
            logging.info(
                "### process_add_service_product_upload function checkpoint no service provider is added"
            )
            return {"flag": False, "message": "No service provider is added"}

        if df["Service Provider"].dropna().nunique() > 1:
            logging.info(
                "### process_add_service_product_upload function checkpoint multiple service providers found"
            )
            return {
                "flag": False,
                "message": "Multiple service providers are not allowed",
            }

        if not customer_data:
            logging.info(
                "### process_add_service_product_upload function checkpoint no valid data found in uploaded file"
            )
            return {
                "flag": False,
                "message": "No valid data found in the uploaded file",
            }

        total_iccids = sum(
            len(data_lists["iccids"]) for data_lists in customer_data.values()
        )
        if total_iccids == 0:
            logging.info(
                "### process_add_service_product_upload function checkpoint no ICCID values found in uploaded file"
            )
            return {
                "flag": False,
                "message": "ICCID is mandatory and not found in the uploaded file",
            }

        # Add validation for Revio Service - check if any customer has revio services
        total_revio_services = sum(
            len(data_lists["revio_services"]) for data_lists in customer_data.values()
        )
        if total_revio_services == 0:
            logging.info(
                "### process_add_service_product_upload function checkpoint no Revio Service values found in uploaded file"
            )
            return {
                "flag": False,
                "message": "Revio Service is mandatory and not found in the uploaded file",
            }

        service_providers = []
        for row in upload_data:
            sp_val = row.get("Service Provider")
            if pd.notna(sp_val):
                sp_cleaned = str(sp_val).strip()
                if sp_cleaned and sp_cleaned not in service_providers:
                    service_providers.append(sp_cleaned)

        if not service_providers:
            logging.info(
                "### process_add_service_product_upload function checkpoint no service provider is added"
            )
            return {"flag": False, "message": "No service provider is added"}

        if len(service_providers) > 1:
            logging.info(
                "### process_add_service_product_upload function checkpoint multiple service providers found"
            )
            return {
                "flag": False,
                "message": "Multiple service providers are not allowed",
            }

        service_provider = service_providers[0]
        logging.info(
            f"### process_add_service_product_upload function in tenant {tenant_database} checkpoint service_provider {service_provider}"
        )

        all_iccids = []
        for data_lists in customer_data.values():
            all_iccids.extend(data_lists["iccids"])

        if all_iccids:
            formatted_iccids = ", ".join(f"'{iccid}'" for iccid in all_iccids)
            if service_provider in ["AT&T - Telegence - UAT ONLY","AT&T - Telegence"]:

                validation_query = f"""SELECT iccid, rev_io_status,is_active_status FROM vw_mobility_rev_assurance_bulk_upload_check WHERE  iccid in ({formatted_iccids}) AND service_provider = '{service_provider}' and (is_active_status = true OR rev_is_active_status = true) and (should_have_billed_service = false OR is_active_status <> rev_is_active_status) AND device_status::text <> 'Restored from archive'::text;"""
            else:
                validation_query = f"""
                SELECT iccid, rev_io_status
                FROM vw_m2m_rev_assurance_bulk_upload_check
                WHERE  iccid IN ({formatted_iccids})
                AND service_provider = '{service_provider}' and (is_active_status = true OR rev_is_active_status = true)
                and (should_have_billed_service = false OR is_active_status <> rev_is_active_status) AND device_status::text <> 'Restored from archive'::text; 
                """
            validation_dataframe = database.execute_query(
                validation_query,
                True
            )
            logging.info(f"### safe_in_clause(all_iccids) : {safe_in_clause(all_iccids)} and service_provider : {service_provider}")
            logging.info(
                f"### process_add_service_product_upload function in tenant {tenant_database} checkpoint ICCID validation query executed"
            )

            if validation_dataframe.empty:
                logging.info(
                    "### process_add_service_product_upload function checkpoint none of the ICCIDs were found in the system"
                )
                return {
                    "flag": False,
                    "message": "None of the ICCIDs were found in the system.",
                }

            not_valid_iccids = set(
                str(row["iccid"]).strip()
                for _, row in validation_dataframe.iterrows()
                if str(row["rev_io_status"]).strip().lower() == "ACTIVE"
            )
            logging.info(
                f"### process_add_service_product_upload function in tenant {tenant_database} checkpoint not_valid_iccids {not_valid_iccids}"
            )

            if not_valid_iccids:
                return {
                    "flag": False,
                    "message": f"The following ICCID(s) were not found or not Active: {', '.join(not_valid_iccids)}",
                }

        revio_service_dict = {}
        iccids_dict = {}
        msisdn_dict = {}

        for customer_name, data_lists in customer_data.items():
            if data_lists["revio_services"]:
                revio_service_dict[customer_name] = data_lists["revio_services"]
            if data_lists["iccids"]:
                iccids_dict[customer_name] = data_lists["iccids"]
            if data_lists["msisdns"]:
                msisdn_dict[customer_name] = data_lists["msisdns"]

        submit_payload = {
            "tenant_name": data.get("tenant_name", ""),
            "username": data.get("username"),
            "firstLastName": data.get("firstLastName", ""),
            "path": "/submit_service_product_data",
            "role_name": data.get("role_name", ""),
            "Partner": data.get("Partner", ""),
            "request_received_at": data.get("request_received_at", ""),
            "access_token": data.get("access_token", "null"),
            "db_name": data.get("db_name"),
            "sessionID": data.get("sessionID", None),
            "submit_data": {
                "revio_service": revio_service_dict,
                "customer_name": customer_names,
                "product_name": product_name,
                "rate": rate,
                "quantity": quantity,
                "prorate": prorate,
                "effective_date": effective_date,
                "description": description,
                "iccids": iccids_dict,
                "msisdn": msisdn_dict,
            },
            "service_provider": service_provider,
        }

        logging.info(
            f"### handle_add_service_product_upload function in tenant {tenant_database} checkpoint calling submit_service_product_data"
        )
        response =  submit_service_product_data(submit_payload)
        # Audit log
        try:
            audit_data = {
                "service_name": "handle_add_service_product_upload",
                "created_by": username ,
                "session_id": session_id  ,
                "tenant_name": tenant_name  ,
                "comments": f"Product-service mapping upload processed successfully for {len(customer_names)} customers",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at  ,
                "status": str(response.get("flag", "")),
            }
            logging.info(
                f"### handle_add_service_line_upload function: Logging audit data: {audit_data}"
            )
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_error:
            logging.error(f"### Audit log failed: {audit_error}")

        return response

    except Exception as e:
        logging.exception(
            f"### handle_add_service_product_upload function error: {str(e)}"
        )
        

        # Add error log with comments
        try:
            error_data = {
                "service_name": "handle_add_service_product_upload",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username ,
                "session_id": session_id ,
                "tenant_name": tenant_name ,
                "comments": f"error occurred while processing the add service product upload: {str(e)}",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at ,
            }
            logging.info(
                f"### handle_add_service_product_upload function: Logging error to DB: {error_data}"
            )
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(
                f"### handle_add_service_product_upload function: Failed to log error to database: {logging_error}"
            )
        return {"flag": False, "message": f"Error processing upload: {str(e)}"}


def handle_deactivate_service_product_upload(data):
    """
    Processes an uploaded Excel file for deactivating service products.

    This function parses an Excel file where each row typically represents a service (identified
    by ICCID, MSISDN, or Revio Service ID) to be deactivated. It groups these identifiers by customer,
    validates the ICCIDs and service provider, and then formats a payload to be passed to
    `deactivate_service_product` for the actual deactivation.

    Parameters:
    - data (dict): Input dictionary:
        - 'db_name' (str): Tenant database name.
        - 'blob' (str): Base64 encoded Excel file string.
        - 'tenant_name', 'username', 'firstLastName', 'role_name', 'Partner',
          'request_received_at', 'access_token', 'sessionID': Contextual info.

    Returns:
    - dict: Result from `deactivate_service_product`, or an error dictionary.
    """
    logging.info(f"### handle_deactivate_service_product_upload function called with data: {data}")
    try:
        username= data.get("username", "") 
        session_id =  data.get("session_id", "") 
        tenant_name = data.get("tenant_name", "")
        request_received_at = data.get("request_received_at")

        tenant_database = data.get("db_name", "")
        logging.info(
            f"### process_deactivate_service_product function in tenant {tenant_database} checkpoint start processing upload"
        )
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **db_config)

        # Use helper for blob decoding
        try:
            upload_df = decode_blob_to_dataframe(data.get("blob"))
        except ValueError as e:
            logging.info(
                f"### process_deactivate_service_product function checkpoint {str(e)}"
            )
            return {"flag": False, "message": str(e)}

        upload_df = upload_df.replace({np.nan: None})

        if upload_df.empty:
            logging.info(
                "### process_deactivate_service_product function checkpoint uploaded Excel has no data"
            )
            return {"flag": False, "message": "Uploaded Excel has no data"}
        
        # Check for record count limit
        if len(upload_df) > 20000:
            logging.info(
                "### process_deactivate_service_product function checkpoint: too many records (>20000)"
            )
            return {
                "flag": False,
                "message": "Upload limit exceeded: Please upload 20,000 records or fewer at a time.",
            }

        service_provider_list = upload_df["Service Provider"].dropna().unique().tolist()
        if len(service_provider_list) > 1:
            logging.info(
                "### process_deactivate_service_product function checkpoint multiple service providers found"
            )
            return {
                "flag": False,
                "message": "Multiple service providers are not allowed",
            }
        elif len(service_provider_list) == 0:
            logging.info(
                "### process_deactivate_service_product function checkpoint no service provider is added"
            )
            return {"flag": False, "message": "No service provider is added"}

        service_provider = service_provider_list[0]

        # Normalize column names
        column_mapping = {}
        for col in upload_df.columns:
            normalized_col = col.lower().replace(" ", "_")
            column_mapping[col] = normalized_col

        upload_df = upload_df.rename(columns=column_mapping)
        upload_data = upload_df.to_dict("records")
        logging.info(
            f"### process_deactivate_service_product function checkpoint upload_data length {len(upload_data)}"
        )

        # Check for mandatory columns
        required_fields = ["iccid"]  # Only mandatory column needed for validation
        missing_columns = [field for field in required_fields if field not in upload_df.columns]
        if missing_columns:
            return {
                "flag": False,
                "message": f"Missing mandatory columns: {', '.join(missing_columns)}"
            }

        # Vectorized ICCID/MSISDN validation
        df = upload_df.copy()
        # Ensure columns exist for validation
        if "iccid" in df.columns:
            df["iccid"] = df["iccid"].astype(str).str.strip()
        else:
            df["iccid"] = ""
        if "msisdn" in df.columns:
            df["msisdn"] = df["msisdn"].astype(str).str.strip()
        else:
            df["msisdn"] = ""

        # ICCID: reject scientific notation and check digit/length
        if df["iccid"].str.contains(r"e\+|e\-", case=False, regex=True).any():
            bad_iccid = df.loc[df["iccid"].str.contains(r"e\+|e\-", case=False, regex=True), "iccid"].iloc[0]
            return {"flag": False, "message": f"Please give valid column values: ICCID format is  {bad_iccid} invalid (scientific notation not allowed) ."}

        iccid_mask = df["iccid"].str.isdigit() & df["iccid"].str.len().between(18, 22)
        if not iccid_mask.all():
            bad_iccid = df.loc[~iccid_mask, "iccid"].iloc[0]
            return {"flag": False, "message": f"Please give valid column values: ICCID format is invalid. Offending value: {bad_iccid}"}

        if "msisdn" in df.columns and df["msisdn"].notnull().any():
            msisdn_mask = df["msisdn"].str.isdigit() & df["msisdn"].str.len().between(7, 15)
            if not msisdn_mask[~df["msisdn"].isnull()].all():
                bad_msisdn = df.loc[~msisdn_mask & df["msisdn"].notnull(), "msisdn"].iloc[0]
                return {"flag": False, "message": f"Please give valid column values: MSISDN format is invalid. Offending value: {bad_msisdn}"}

        # Extract and clean ICCIDs
        iccids = []
        for record in upload_data:
            iccid = str(record["iccid"]).strip()
            iccid = iccid.split(".")[0] if "." in iccid else iccid
            if iccid:
                iccids.append(iccid)

        if not iccids:
            return {"flag": False, "message": "No valid ICCIDs found in upload"}

        # Remove duplicates while preserving order
        unique_iccids = list(dict.fromkeys(iccids))
        
        # Format ICCIDs for SQL IN clause
        # formatted_iccids = "'" + "','".join(unique_iccids) + "'"

        # Batch validation query to get service provider and validate ICCIDs
        if "Telegence" in service_provider:
            validation_query = """
                SELECT iccid, rev_io_status, service_provider, customer_id, service_product_id, 
                customer_name, service_number FROM vw_mobility_rev_assurance_bulk_upload_check
                WHERE  iccid IN %s and (is_active_status = true OR rev_is_active_status = true)
                and (should_have_billed_service = false OR is_active_status <> rev_is_active_status) 
                AND device_status::text <> 'Restored from archive'::text;
            """
        else:
            validation_query = """
                SELECT iccid, rev_io_status, service_provider, customer_id, service_product_id, 
                customer_name, service_number FROM vw_m2m_rev_assurance_bulk_upload_check
                WHERE  iccid IN %s and (is_active_status = true OR rev_is_active_status = true)
                and (should_have_billed_service = false OR is_active_status <> rev_is_active_status) AND device_status::text <> 'Restored from archive'::text; 
            """
        
        logging.info(
            f"### process_deactivate_service_product function checkpoint validation query: {validation_query}"
        )

        validation_result = database.execute_query(validation_query, params=[safe_in_clause(unique_iccids),])

        if validation_result.empty:
            return {
                "flag": False,
                "message": "No active services found for provided ICCIDs"
            }

        # Check service provider consistency
        service_providers = validation_result['service_provider'].unique()
        if len(service_providers) > 1:
            return {
                "flag": False,
                "message": "All rows must have the same service provider"
            }
        
        service_provider = service_providers[0]

        # Check if all ICCIDs were found
        found_iccids = set(validation_result['iccid'].tolist())
        missing_iccids = set(unique_iccids) - found_iccids
        
        if missing_iccids:
            return {
                "flag": False,
                "message": f"ICCIDs not found: {', '.join(missing_iccids)}"
            }

        # Build data structures from validation results
        customer_iccid_map = defaultdict(list)
        iccid_msisdn_map = {}
        customer_id_map = defaultdict(list)
        all_customer_ids = set()

        # Map upload data by ICCID for quick lookup
        upload_data_map = {str(record["iccid"]).strip().split(".")[0]: record for record in upload_data}

        for _, row in validation_result.iterrows():
            iccid = row['iccid']
            customer_name = row['customer_name']
            customer_id = str(row['customer_id'])
            service_number = row['service_number']
            
            # Get corresponding upload data
            upload_row = upload_data_map.get(iccid, {})
            
            # Handle effective_date conversion here
            effective_date_val = upload_row.get("effective_date", "")
            if effective_date_val:
                try:
                    effective_date_val = pd.to_datetime(effective_date_val).strftime("%Y-%m-%d")
                except Exception as e:
                    logging.info(
                        f"### process_deactivate_service_product function checkpoint invalid date format in row with ICCID {iccid}: {str(e)}"
                    )
                    return {
                        "flag": False,
                        "message": f"Invalid date format in row with ICCID {iccid}: {str(e)}",
                    }

            customer_iccid_map[customer_name].append(iccid)
            iccid_msisdn_map[iccid] = service_number
            customer_id_map[customer_id].append({
                "service_product_id": int(row['service_product_id']),
                "effective_date": effective_date_val,
                "generate_proration": upload_row.get("generate_proration", True),
                "iccid": iccid,
            })
            all_customer_ids.add(customer_id)

        # Format payload with all original keys
        payload = {
            "tenant_name": data["tenant_name"],
            "username": data["username"],
            "firstLastName": data.get("firstLastName", ""),
            "path": "/deactivate_service_product",
            "role_name": data.get("role_name", ""),
            "parent_module": "Sim Management",
            "module_name": "Rev assurance",
            "customer_id": list(all_customer_ids),
            "submit_data": {
                "customer_name": list(customer_iccid_map.keys()),
                "deactivate_data": dict(customer_id_map),
                "iccid": list(iccid_msisdn_map.keys()),
                "service_number": list(iccid_msisdn_map.values()),
                "quantity": {k: len(v) for k, v in customer_iccid_map.items()},
                "customer_iccid_dict": dict(customer_iccid_map),
                "iccid_msisdn_dict": iccid_msisdn_map,
            },
            "service_provider": service_provider,
            "row_count": len(upload_data),
            "request_received_at": datetime.datetime.now(),
            "Partner": data.get("tenant_name"),
            "access_token": data.get("access_token"),
            "db_name": data["db_name"],
            "sessionID": data.get("sessionID"),
        }

        logging.info(
            f"### process_deactivate_service_product function in tenant {tenant_database} checkpoint calling deactivate_service_product - payload {payload}"
        )
        response =  deactivate_service_product(payload)
 
        try:
            audit_data = {
                "service_name": "handle_deactivate_service_product_upload",
                "created_by": username ,
                "session_id": session_id  ,
                "tenant_name": tenant_name  ,
                "comments": f"Service product deactivation upload processed successfully for {len(customer_iccid_map)} customers",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at  ,
                "status": str(response.get("flag", "")),
            }
            logging.info(
                f"### handle_deactivate_service_product_upload function: Logging audit data: {audit_data}"
            )
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_error:
            logging.error(f"### Audit log failed: {audit_error}")

        return response

    except Exception as e:
        logging.error(
            f"### process_deactivate_service_product function error: {str(e)}",
            exc_info=True,
        )
        

        try:
            error_data = {
                "service_name": "handle_deactivate_service_product_upload",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username ,
                "session_id": session_id ,
                "tenant_name": tenant_name ,
                "comments": f"error occurred while processing the deactivate service product upload: {str(e)}",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at ,
            }
            logging.info(
                f"### handle_deactivate_service_product_upload function: Logging error to DB: {error_data}"
            )
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(
                f"###  Failed to log error to database: {logging_error}"
            )

        return {"flag": False, "message": f"Processing error: {str(e)}"}


def handle_assign_service_upload(data):
    """
    Processes assign service requests and returns payload in required format.

    This function parses an uploaded Excel file for assigning services, validates
    required fields, queries the database for service/product info, and prepares
    a payload for downstream processing.

    Parameters:
    - data (dict): Input dictionary with keys like 'blob_data', 'db_name', etc.

    Returns:
    - dict: Result from submit_assign_service_data or error message.
    """
    logging.info(f"### handle_assign_service_upload function called with data: {data}")
    try:
        username= data.get("username", "") 
        session_id =  data.get("session_id", "") 
        tenant_name = data.get("tenant_name", "")
        request_received_at = data.get("request_received_at")

        # Use helper for blob decoding
        try:
            upload_df = decode_blob_to_dataframe(data.get("blob"))
        except ValueError as e:
            logging.info(
                f"### process_assign_service function checkpoint {str(e)}"
            )
            return {"flag": False, "message": str(e)}
        
        # Check for record count limit
        if len(upload_df) > 20000:
            logging.info(
                "### process_assign_service function checkpoint: too many records (>20000)"
            )
            return {
                "flag": False,
                "message": "Upload limit exceeded: Please upload 20,000 records or fewer at a time.",
            }

        upload_df = upload_df.replace({np.nan: None})
        upload_df.columns = [col.strip().replace(" ", "_").lower() for col in upload_df.columns]
        # Add quantity = 1 for each row
        upload_df["quantity"] = 1
        customer_counts = upload_df["customer_name"].value_counts().to_dict()
        upload_data = upload_df.to_dict("records")
        
        logging.info(f"handle_asign_service_df - {upload_data}")
        logging.info(
            f"### process_assign_service function checkpoint upload_data length {len(upload_data)}"
        )

        # Validate mandatory columns
        required_fields = ["iccid", "msisdn", "customer_name", "effective_date", "service_provider"]
        missing_fields = []
        # Vectorized check for missing required fields
        for field in required_fields:
            if upload_df[field].isnull().any():
                missing_rows = upload_df[upload_df[field].isnull()].index + 1
                for idx in missing_rows:
                    missing_fields.append(f"Row {idx}: {field}")

        if missing_fields:
            logging.info(f"### process_assign_service function checkpoint missing fields: {missing_fields}")
            return {
                "flag": False,
                "message": f"Missing required fields - {'; '.join(missing_fields[:5])}" + 
                          ("..." if len(missing_fields) > 5 else "")
            }

        # Vectorized ICCID/MSISDN validation
        df = upload_df.copy()
        if "iccid" in df.columns and "msisdn" in df.columns:
            df["iccid"] = df["iccid"].astype(str).str.strip()
            df["msisdn"] = df["msisdn"].astype(str).str.strip()

            # ICCID: reject scientific notation and check digit/length
            if df["iccid"].str.contains(r"e\+|e\-", case=False, regex=True).any():
                bad_iccid = df.loc[df["iccid"].str.contains(r"e\+|e\-", case=False, regex=True), "iccid"].iloc[0]
                return {"flag": False, "message": f"Please give valid column values: ICCID format is  {bad_iccid} invalid (scientific notation not allowed) ."}

            iccid_mask = df["iccid"].str.isdigit() & df["iccid"].str.len().between(18, 22)
            if not iccid_mask.all():
                bad_iccid = df.loc[~iccid_mask, "iccid"].iloc[0]
                return {"flag": False, "message": f"Please give valid column values: ICCID format is invalid. Offending value: {bad_iccid}"}

            msisdn_mask = df["msisdn"].str.isdigit() & df["msisdn"].str.len().between(7, 15)
            if not msisdn_mask.all():
                bad_msisdn = df.loc[~msisdn_mask, "msisdn"].iloc[0]
                return {"flag": False, "message": f"Please give valid column values: MSISDN format is invalid. Offending value: {bad_msisdn}"}

        # Extract unique values for validation
        iccids = upload_df["iccid"].astype(str).unique().tolist()
        service_providers = upload_df["service_provider"].dropna().unique().tolist()
        effective_dates = upload_df["effective_date"].dropna().unique().tolist()

        # Check for multiple service providers
        if len(service_providers) > 1:
            logging.info("### process_assign_service function checkpoint multiple service providers found")
            return {"flag": False, "message": "Multiple service providers found in upload"}

        # Check for multiple effective dates
        if len(effective_dates) > 1:
            logging.info("### process_assign_service function checkpoint multiple effective dates found")
            return {"flag": False, "message": "Multiple effective dates found in upload"}

        tenant_db = DB(data["db_name"], **db_config)
        common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **db_config)
        
        # Bulk validation query
        first_service_provider = service_providers[0]
        # formatted_iccids = "'" + "', '".join(iccids) + "'"
        
        # OPTIMIZED: Single SQL query validation - no loops at all
        if "Telegence" in first_service_provider:
            query = """
                SELECT iccid, rev_io_status FROM vw_mobility_rev_assurance_bulk_upload_check
                WHERE  iccid IN %s AND service_provider = %s and (is_active_status = true OR rev_is_active_status = true)
                and (should_have_billed_service = false OR is_active_status <> rev_is_active_status) 
                AND device_status::text <> 'Restored from archive'::text;
            """
        else:
            query = """
                SELECT iccid, rev_io_status, service_provider, customer_id, service_product_id, 
                customer_name, service_number FROM vw_m2m_rev_assurance_bulk_upload_check
                WHERE  iccid IN %s AND service_provider = %s and (is_active_status = true OR rev_is_active_status = true)
                and (should_have_billed_service = false OR is_active_status <> rev_is_active_status) AND device_status::text <> 'Restored from archive'::text; 
            """
        
        logging.info(f"### process_assign_service function checkpoint validation query: {query}")
        result = tenant_db.execute_query(query, params=[safe_in_clause(iccids), first_service_provider])

        if result.empty:
            logging.info("### process_assign_service function checkpoint no active services found")
            return {"flag": False, "message": "No active services found for provided ICCIDs"}

        # Check if all ICCIDs are found
        found_iccids = set(result['iccid'].astype(str))
        missing_iccids = set(iccids) - found_iccids
        
        if missing_iccids:
            logging.info(f"### process_assign_service function checkpoint missing ICCIDs: {missing_iccids}")
            return {
                "flag": False, 
                "message": f"No active services found for ICCIDs: {', '.join(list(missing_iccids)[:5])}" + 
                          ("..." if len(missing_iccids) > 5 else "")
            }

        # Prepare payload
        payload = {
            "tenant_name": data["tenant_name"],
            "username": data["username"],
            "firstLastName": data.get("firstLastName", ""),
            "path": "/submit_assign_service_data",
            "role_name": data.get("role_name", ""),
            "Partner": data["tenant_name"],
            "request_received_at": data.get("request_received_at"),
            "access_token": "null",
            "db_name": data["db_name"],
            "service_provider": first_service_provider,
            "row_count": len(upload_data),
            "sessionID": data.get("session_id"),
            "submit_data": {
                "customer_name": upload_df["customer_name"].dropna().unique().tolist(),
                "service_type": None,
                "revio_product": [],
                "revio_package": None,
                "service_number": upload_df["msisdn"].dropna().astype(str).unique().tolist(),
                "iccid": iccids,
                "effective_date": effective_dates[0].isoformat() if effective_dates else None,
                "quantity": customer_counts,
                "customer_iccid_dict": {},
                "iccid_msisdn_dict": dict(zip(upload_df["iccid"].astype(str), upload_df["msisdn"].astype(str))),
                "service_provider": first_service_provider
            },
        }

        # Build customer_iccid_dict using groupby (no explicit loop)
        customer_iccid_dict = upload_df.groupby("customer_name")["iccid"].apply(lambda x: x.astype(str).tolist()).to_dict()
        payload["submit_data"]["customer_iccid_dict"] = customer_iccid_dict

        logging.info(
            f"### process_assign_service function in tenant {data['db_name']} checkpoint calling submit_assign_service_data"
        )
        logging.info(f"### process_assign_service function payload - {payload}")
        response =  submit_assign_service_data(payload)
        
        try:
            audit_data = {
                "service_name": "handle_assign_service_upload",
                "created_by": username ,
                "session_id": session_id  ,
                "tenant_name": tenant_name  ,
                "comments":  f"Service assignment upload processed successfully for {len(customer_iccid_dict)} customers",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at  ,
                "status": str(response.get("flag", "")),
            }
            logging.info(
                f"### handle_assign_service_upload function: Logging audit data: {audit_data}"
            )
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_error:
            logging.error(f"### Audit log failed: {audit_error}")

        return response     


    except Exception as e:
        logging.error(
            f"### handle_assign_service_upload function error: {str(e)}", exc_info=True
        )
       

        # Add error log with comments
        try:
            error_data = {
                "service_name": "handle_assign_service_upload",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username ,
                "session_id": session_id ,
                "tenant_name": tenant_name ,
                "comments": f"error occurred while processing the assign service upload: {str(e)}",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at ,
            }
            logging.info(
                f"### handle_assign_service_upload function: Logging error to DB: {error_data}"
            )
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(
                f"### handle_assign_service_upload function: Failed to log error to database: {logging_error}"
            )
    
        return {"flag": False, "message": f"Processing error: {str(e)}"}


# Common helper function for blob decoding
def decode_blob_to_dataframe_(blob_str: str, return_all: bool = False):
    """
    Decodes base64-encoded blob string into a pandas DataFrame or dictionary of DataFrames.
    """
    if not blob_str:
        raise ValueError("Blob data not provided")
    
    # Remove data URL prefix if present
    if blob_str.startswith("data:"):
        blob_str = blob_str.split(",", 1)[1]
    
    # Add base64 padding
    blob_str += "=" * (-len(blob_str) % 4)
    
    try:
        # Decode base64 and create file stream
        file_stream = BytesIO(base64.b64decode(blob_str))
    except binascii.Error as e:
        raise ValueError(f"Invalid base64 encoding: {str(e)}")
    
    if return_all:
        # Return dictionary of all sheets
        return pd.read_excel(file_stream, sheet_name=None, engine="openpyxl")
    else:
        # Return first sheet
        return pd.read_excel(file_stream, engine="openpyxl")



def handle_add_service_line_upload(data):
    """
    Processes the uploaded 'add_service_line' Excel file, validates and maps its contents, and prepares a payload for further processing.
    Workflow:
    1. Extracts tenant and database information from the input data.
    2. Decodes and reads the uploaded Excel file from a base64-encoded blob.
    3. Validates that the file contains data and extracts rows as dictionaries.
    4. Aggregates ICCID values from the uploaded data and validates their presence.
    5. Checks that all ICCIDs exist and are active for the specified service provider in the database.
    6. Extracts and formats additional fields (customer name, provider name, service type, rate plan, etc.) from the first row and all rows as needed.
    7. Constructs a payload with all relevant information for submission.
    8. Calls the downstream function to process the payload.
    9. Handles and logs errors, returning appropriate messages on failure.
    Args:
        data (dict): Input data containing tenant info, authentication, and the base64-encoded Excel blob.
    Returns:
        dict: Result of the processing, including a flag and message, or the downstream function's response.
    """
    logging.info(f"### handle_add_service_line_upload function called with data: {data}")
    try:
        username= data.get("username", "") 
        session_id =  data.get("session_id", "") 
        tenant_name = data.get("tenant_name", "")
        request_received_at = data.get("request_received_at")

        tenant_database = data.get("db_name", "")
        logging.info(
            f"### process_add_service_line_upload function in tenant {tenant_database} checkpoint start processing upload"
        )
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **db_config) 

         # Extract all sheets from blob
        try:
            all_sheets = decode_blob_to_dataframe_(data.get("blob"), return_all=True)
            logging.info(f"### Sheets found: {list(all_sheets.keys())}")
        except ValueError as e:
            return {"flag": False, "message": str(e)}
        
        uploaded_dataframe = all_sheets.get("Template")
        products_df = all_sheets.get("Products")
        packages_df = all_sheets.get("Packages")
        revio_service_providers = all_sheets.get("Revio Service Providers")

        logging.info(f"### Uploaded DataFrame: {uploaded_dataframe}")
        if uploaded_dataframe.empty:
            logging.warning(
                "### process_add_service_line_upload function checkpoint uploaded Excel has no data"
            )
            return {"flag": False, "message": "Uploaded Excel has no data"}

        #rename columns
        uploaded_dataframe = uploaded_dataframe.rename(columns={"Customer ID":"Customer Id", 
                                                    "Use Carrier Activation?":"Use Carrier Activation",
                                                    "Add Rate Plan?":"Add Rate Plan",
                                                    "Service ID":"Msisdn","ICCID":"Iccid"})

        # Check for required columns
        required_columns = [
            "Customer Id", "Provider Name", "Service Type", "Revio Product", 
            "Revio Package", "Rate", "Rate Plan", "Activation Date", 
            "Add Rate Plan", "Prorate", "Use Carrier Activation", "Iccid", 
            "Msisdn"
        ]
        missing_columns = [col for col in required_columns if col not in uploaded_dataframe.columns]
        if missing_columns:
            return {
                "flag": False,
                "message": f"Missing required columns: {', '.join(missing_columns)}"
            }

        # Check record count limit
        if len(uploaded_dataframe) > 20000:
            logging.info(
                "### process_add_service_line_upload function checkpoint: too many records (>20000)"
            )
            return {
                "flag": False,
                "message": "Upload limit exceeded: Please upload 20,000 records or fewer at a time.",
            }

        # Create mappings for product and package descriptions
        product_map = {}
        product_rate_map = {}
        if not products_df.empty:
            product_map = dict(zip(
                products_df["Product ID"].astype(str).str.strip(), 
                products_df["Product Description"]
            ))
            product_rate_map = dict(zip(
                products_df["Product ID"].astype(str).str.strip(), 
                products_df["Rate"]
            ))
        
        logging.info(f"### process_add_service_line_upload function in tenant {tenant_database} checkpoint product_map: {product_map}")
        package_map = {}
        if not packages_df.empty:
            package_map = dict(zip(
                packages_df["Package ID"].astype(str).str.strip(), 
                packages_df["Package Description"]
            ))
        logging.info(f"### process_add_service_line_upload function in tenant {tenant_database} checkpoint package_map: {package_map}")

        # Clean and validate data
        uploaded_dataframe = uploaded_dataframe.replace({np.nan: None})
        
        
        service_provider = data.get("service_provider", "")
        # if no service_provider fetch from database
        if not service_provider:
            uploaded_iccid = uploaded_dataframe["Iccid"][0]
            service_provider_df = database.get_data(
                "sim_management_inventory",
                {"iccid": str(uploaded_iccid), "is_active": True},
                ["service_provider_display_name"],
            )
            if not service_provider_df.empty:
                service_provider = service_provider_df["service_provider_display_name"].to_list()[0]
        logging.info(f"### process_add_service_line_upload function checkpoint service_provider: {service_provider}")

        # Process Customer ID column
        uploaded_dataframe["Customer Id"] = uploaded_dataframe["Customer Id"].astype(str).str.strip()
        
        # Process ICCID and MSISDN
        for col in ["Iccid", "Msisdn"]:
            uploaded_dataframe[col] = uploaded_dataframe[col].astype(str).str.strip()
        
        # ICCID validation
        if uploaded_dataframe["Iccid"].str.contains(r"e\+|e\-", case=False, regex=True).any():
            return {"flag": False, "message": "ICCID format invalid (scientific notation not allowed)"}
            
        if not uploaded_dataframe["Iccid"].str.isdigit().all() or \
           not uploaded_dataframe["Iccid"].str.len().between(18, 22).all():
            return {"flag": False, "message": "ICCID must be 18-22 digits"}

        # MSISDN validation
        if not uploaded_dataframe["Msisdn"].str.isdigit().all():
            return {"flag": False, "message": "MSISDN must be Numerical Digits Only"}

        # Get ICCID list for validation
        iccid_list = uploaded_dataframe["Iccid"].tolist()
        
        # Validate ICCIDs exist in system
        if "Telegence" in service_provider or service_provider == 'AT&T - eBonding':
            validation_query = f"""
                SELECT iccid, rev_account_number, customer_name, rev_io_status, service_number
                FROM vw_mobility_rev_assurance_bulk_upload_check
                WHERE  iccid IN ({','.join(f"'{str(iccid)}'" for iccid in iccid_list)}) AND service_provider = %s and (is_active_status = true OR rev_is_active_status = true)
                and (should_have_billed_service = false OR is_active_status <> rev_is_active_status) 
                AND device_status::text <> 'Restored from archive'::text;
            """
        else:
            validation_query = f"""
                SELECT iccid, rev_account_number, customer_name, rev_io_status, service_number 
                FROM vw_m2m_rev_assurance_bulk_upload_check
                WHERE  iccid IN ({','.join(f"'{str(iccid)}'" for iccid in iccid_list)}) AND service_provider = %s and (is_active_status = true OR rev_is_active_status = true)
                and (should_have_billed_service = false OR is_active_status <> rev_is_active_status) AND device_status::text <> 'Restored from archive'::text; 
            """
            
        validation_df = database.execute_query(
            validation_query, 
            params=[service_provider]
        )

        if validation_df.empty:
            logging.info(
                "### process_add_service_line_upload function checkpoint none of the ICCIDs were found in the system"
            )
            return {
                "flag": False,
                "message": "None of the ICCIDs were found in the system.",
            }

        # Create mapping from validation results
        iccid_to_customer = {}
        iccid_to_service_number = {}  # NEW: Map ICCID to expected service number
        valid_iccids = set()
        for _, row in validation_df.iterrows():
            iccid_str = str(row['iccid'])
            rev_account = row['rev_account_number']
            service_number = row['service_number']
            
            if rev_account is None or (isinstance(rev_account, float) and np.isnan(rev_account)):
                continue
                
            valid_iccids.add(iccid_str)
            iccid_to_customer[iccid_str] = str(rev_account).strip()
            # NEW: Store service number mapping
            iccid_to_service_number[iccid_str] = str(service_number).strip() if service_number else None

        invalid_iccids = [iccid for iccid in uploaded_dataframe["Iccid"] if iccid not in valid_iccids]
        if invalid_iccids:
            logging.info(
                f"### process_add_service_line_upload function checkpoint invalid ICCIDs found: {invalid_iccids}"
            )

        # Validation: Check if customer_id from file matches the one from DB for each ICCID
        mismatched_customer_ids = []
        for idx, iccid in enumerate(uploaded_dataframe["Iccid"]):
            if uploaded_dataframe.iloc[idx]["Customer Id"].strip() != iccid_to_customer.get(str(iccid), ""):
                mismatched_customer_ids.append(f"ICCID: {iccid} (File: {uploaded_dataframe.iloc[idx]['Customer Id']}, DB: {iccid_to_customer.get(str(iccid), '')})")

        if mismatched_customer_ids:
            logging.info(
                f"### process_add_service_line_upload function checkpoint customer ID mismatch found: {mismatched_customer_ids}"
            )
            # return {
            #     "flag": False,
            #     "message": f"Customer ID mismatch for ICCIDs: {', '.join(mismatched_customer_ids[:5])} "
            #                f"[Total mismatches: {len(mismatched_customer_ids)}]"
            # }
            
        # NEW VALIDATION: Check if MSISDN matches expected service number
        mismatched_msisdns = []
        for idx, iccid in enumerate(uploaded_dataframe["Iccid"]):
            iccid_str = str(iccid)
            if iccid_str in valid_iccids:
                uploaded_msisdn = str(uploaded_dataframe.iloc[idx]["Msisdn"]).strip()
                expected_msisdn = iccid_to_service_number.get(iccid_str, "")
                
                # Only compare if both values exist
                if expected_msisdn and uploaded_msisdn != expected_msisdn:
                    mismatched_msisdns.append(
                        f"ICCID: {iccid_str} (Uploaded: {uploaded_msisdn}, Expected: {expected_msisdn})"
                    )

        if mismatched_msisdns:
            logging.info(
                f"### MSISDN mismatch found: {mismatched_msisdns}"
            )
            return {
                "flag": False,
                "message": f"MSISDN mismatch for ICCIDs: {', '.join(mismatched_msisdns[:5])} "
                           f"[Total mismatches: {len(mismatched_msisdns)}]"
            }

        # Map Product and Package IDs to descriptions
        def map_id_to_description(value, mapping):
            if value is None:
                return None
            str_val = str(value).strip()
            return mapping.get(str_val, str_val)
        
        # Convert to list and handle missing values
        revio_products = uploaded_dataframe["Revio Product"].astype(str).str.strip().tolist()
        processed_rates = uploaded_dataframe["Rate"].tolist()

        # Updated list to store final rates
        final_rates = []

        for revio_prod, processed_rate in zip(revio_products, processed_rates):
            if pd.isna(processed_rate) or str(processed_rate).strip() == "" or processed_rate is None:
                rate = product_rate_map.get(revio_prod)
            else:
                rate = processed_rate
            final_rates.append(rate)

        uploaded_dataframe["Revio Product"] = uploaded_dataframe["Revio Product"].apply(
            lambda x: map_id_to_description(x, product_map)
        )

        #fetch revio products form uploaded file
        # revio_product_list = uploaded_dataframe["Revio Product"].astype(str).str.strip().tolist()

        uploaded_package_ids = uploaded_dataframe["Revio Package"].astype(str).str.strip().tolist()
        packages_df["Package ID"] = packages_df["Package ID"].astype(str)
        package_map = packages_df.set_index("Package ID")["Package Description"].to_dict()
        # Map each uploaded_package_id to its corresponding description, preserving order and duplicates
        revio_package_list = [package_map.get(pkg_id, None) for pkg_id in uploaded_package_ids]
        logging.info(f"### revio_package_list - {revio_package_list}")
        
        uploaded_dataframe["Revio Package"] = uploaded_dataframe["Revio Package"].apply(
            lambda x: map_id_to_description(x, package_map)
        )


        # Convert boolean fields
        def str_to_bool(value):
            if isinstance(value, bool):
                # Convert NumPy booleans to Python booleans
                return bool(value)
            if isinstance(value, (np.bool_)):
                return bool(value)
            return str(value).strip().upper() == "YES"

        for col in ["Add Rate Plan", "Prorate", "Use Carrier Activation"]:
            uploaded_dataframe[col] = uploaded_dataframe[col].apply(str_to_bool)

        unique_customer_ids = uploaded_dataframe["Customer Id"].dropna().astype(str).str.strip().unique().tolist()
        placeholder = ','.join(['%s'] * len(unique_customer_ids))
        customer_query = f"SELECT customer_name, rev_customer_id FROM revcustomer WHERE rev_customer_id IN ({placeholder})"
        customer_df = database.execute_query(customer_query, params=unique_customer_ids)
        customer_map = dict(zip(customer_df["rev_customer_id"].astype(str), customer_df["customer_name"]))

        customer_names = [customer_map.get(str(cid), "Unknown") for cid in uploaded_dataframe["Customer Id"]]
        customer_ids = uploaded_dataframe["Customer Id"].tolist()

        revio_service_providers_map = {}
        if not revio_service_providers.empty:
            revio_service_providers_map = dict(zip(
                revio_service_providers["Service Provider Name"].astype(str).str.strip(), 
                revio_service_providers["Service Provider ID"]
            ))

        # Format activation dates per row
        activation_dates = []
        for date_val in uploaded_dataframe["Activation Date"]:
            if date_val:
                try:
                    activation_dates.append(pd.to_datetime(date_val).isoformat())
                except Exception as e:
                    logging.error(f"Exception while extracting 'activation_dates' : {e}")
                    activation_dates.append(None)
            else:
                activation_dates.append(None)


        processed_rates = uploaded_dataframe["Rate"].astype(str).tolist()

        # Prepare per-row payload
        submit_payload = {
            "customer_name": customer_names,
            "customer_ids": customer_ids,
            "revio_service_providers_map":revio_service_providers_map,
            "provider_name": uploaded_dataframe["Provider Name"].tolist(),
            "service_type": uploaded_dataframe["Service Type"].tolist(),
            "revio_product": uploaded_dataframe["Revio Product"].fillna('').tolist(),
            "revio_package": uploaded_dataframe["Revio Package"].fillna('').tolist(),
            "rate": final_rates,  # Convert to string
            "rate_plan": uploaded_dataframe["Rate Plan"].fillna('').tolist(),
            "activation_date": activation_dates,
            "quantity": [len(iccid_list)],  # Wrap in list as shown in example
            "add_rate_plan": uploaded_dataframe["Add Rate Plan"].tolist(),
            "prorate": uploaded_dataframe["Prorate"].tolist(),
            "use_carrier_activation": uploaded_dataframe["Use Carrier Activation"].tolist(),
            "description": uploaded_dataframe["Description"].fillna('').tolist(),
            "iccid": iccid_list,
            "usage_plan_group": uploaded_dataframe["Usage Plan Group"].fillna('').tolist(),
            "service_number": uploaded_dataframe["Msisdn"].tolist(),
        }
        
        # Format request timestamp
        request_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

        final_payload = {
            "tenant_name": data["tenant_name"],
            "username": data["username"],
            "firstLastName": data["firstLastName"],
            "path": "/submit_service_line_dropdown_data",
            "role_name": data["role_name"],
            "Partner": data["Partner"],
            "request_received_at": request_time,
            "access_token": data["access_token"],
            "db_name": data["db_name"],
            "sessionID": data["sessionID"],
            "submit_data": submit_payload,
            "service_provider": service_provider.strip(),
            "is_file_upload":True
        }
        logging.info(
            f"### process_add_service_line_upload function in tenant {tenant_database} checkpoint calling add_service_line_data with payload is  {final_payload}"
        )
        response = add_service_line_data(final_payload)

        # Add service_numbers key to response from submit_data
        response["service_numbers"] = submit_payload.get("service_number", [])

        # Audit log
        try:

            audit_data = {
                "service_name": "handle_add_service_line_upload",
                "created_by": username ,
                "session_id": session_id ,
                "tenant_name": tenant_name ,
                "comments": f"Service line upload processed successfully for {len(submit_payload['customer_name'])} customers",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at ,
                "status": str(response.get("flag", "")),
            }
            logging.info(
                f"### handle_add_service_line_upload function: Logging audit data: {audit_data}"
            )
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_error:
            logging.error(f"### Audit log failed: {audit_error}")

        return response

    except Exception as e:
        logging.exception(f"### Upload processing failed: {str(e)}")
       
         
        try:

            error_data = {
                "service_name": "handle_add_service_line_upload",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username ,
                "session_id": session_id ,
                "tenant_name": tenant_name ,
                "comments": f"unexpected error occurred while processing the add service line upload: {str(e)}",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at ,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(f"DB logging failed: {logging_error}")
        return {"flag": False, "message": f"Error processing upload: {str(e)}"}
   
    
def assign_service_data(data):
    """
    Prepares and submits service assignment data for rev customer.

    This function is typically used for API calls (such as from ReadMe or Swagger UI) to assign a product to a customer.
    It validates the required fields, formats the payload, and calls the downstream function to process the assignment.

    Parameters:
        data (dict): Input dictionary containing:
            - customer_name (str or list): Name(s) of the customer(s).
            - service_type (str): The type of service to assign.
            - revio_product (str): The product to assign (will be formatted as 'product_id:<value>').
            - revio_package (str, optional): The package to assign (if any).
            - service_provider (str): The service provider name.
            - iccid (list): List of ICCIDs to assign.
            - service_number (list): List of service numbers (MSISDNs) to assign.

    Returns:
        dict: Result from submit_assign_service_data, or an error message if validation fails.

    Notes:
        - The function ensures that all required fields are present.
        - It enforces that either a product or a package is provided, but not both.
        - The number of ICCIDs and service numbers must match.
        - The payload is formatted to match the expected structure for downstream processing.
    """
    logging.info(f"### assign_service_data function called with data: {data}")
   
    user_name= data.get("username", "") 
    session_id =  data.get("session_id", "") 
    Partner = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at")


    username = data.get("client_id", "")
    context_data = get_service_account_context(username)
    if not context_data:
        logging.error("### submit_assign_service_data: Failed to get context data for username: %s", username)
        return {"flag": False, "message": "Failed to retrieve service account context."}
    role = context_data.get("role", "")
    if role in ["User", "Agent"]:
        logging.info("### submit_assign_service_data: permission denied for role")
        return {"flag": False, "message": "You do not have permission to perform this action."}
    tenant_name = context_data.get("tenant_name", "")
    data["tenant_name"] = tenant_name
    data["username"] = username
    data["firstLastName"] = f"{context_data.get('first_name', '')} {context_data.get('last_name', '')}"
    data["role_name"] = role
    data["Partner"] = tenant_name
    data["request_received_at"] = datetime.datetime.now(timezone.utc)
    tenant_database = context_data.get("db_name")
    data["db_name"] = tenant_database
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **db_config) 

    # Extract and validate required fields
    customer_name = data.get("customer_name", [])
    service_type = data.get("service_type", "")
    revio_product = data.get("revio_product", "")
    revio_product = f"product_id:{revio_product}"
    revio_package = data.get("revio_package")
    service_provider = data.get("service_provider", "")
    iccid = data.get("iccid", [])
    service_number = data.get("service_number", [])
    service_id = data.get("service_id")

    # Basic validation for required fields
    if not customer_name or not service_type or not service_provider or not iccid or not service_number or not service_id:
        return {"flag": False, "message": "Missing required fields in the data"}
    
    # Ensure either product or package is provided, but not both or neither
    if revio_package or not revio_product:
        return {"flag": False, "message": "Revio product or package is required"}
    if len(iccid) != len(service_number):
        return {"flag": False, "message": "ICCID and service number lists must be of the same length"}
    try:
        # Validate customer name and service type
        rev_customer_data = database.get_data(
            "revcustomer",
            {"customer_name": customer_name, "is_active": True},
            ["id"],
        )
        if rev_customer_data.empty:
            logging.info(
                "### submit_assign_service_data function checkpoint: customer name not valid"
            )
            return {"flag": False, "message": "Customer name is not valid"}
        rev_customer_id = rev_customer_data["id"].tolist()
        rev_customer_id = ', '.join(f"'{id_}'" for id_ in rev_customer_id)
        rev_service_query = f"""
            SELECT DISTINCT rst.description AS service_type
            FROM public.rev_service AS rs
            JOIN rev_service_type AS rst ON rst.service_type_id = rs.rev_service_type_id
            WHERE rev_customer_id in ({rev_customer_id})
            """
        service_types_df = database.execute_query(rev_service_query, True)
        if service_types_df.empty:
            logging.info(
                "### submit_assign_service_data function checkpoint: no service types found for customer"
            )
            return {
                "flag": False,
                "message": "No service types found for the given customer.",
            }
        available_service_types = service_types_df["service_type"].tolist()
        if service_type not in available_service_types:
            logging.info(
                f"### submit_assign_service_data function checkpoint: invalid service_type {service_type}"
            )
            return {
                "flag": False,
                "message": f"Invalid service_type. Allowed values for this customer: {available_service_types}",
            }
        # Prepare the payload for submission        
        data["submit_data"] = {
            "customer_name": [customer_name] if isinstance(customer_name, str) else customer_name,
            "service_type": f"Service_id:{service_id} - Service_type:{service_type}",
            "revio_product": [revio_product] if isinstance(revio_product, str) else revio_product,
            "revio_package": revio_package,
            "service_provider": service_provider,
            "iccid": iccid,
            "service_number": service_number,
            "effective_date": data.get("effective_date", None),
            "quantity": {customer_name: len(iccid)},
            "customer_iccid_dict": {
                customer_name: iccid
            },
            "iccid_msisdn_dict": {iccid[i]: service_number[i] for i in range(len(iccid))},
        }
        data["row_count"] = len(iccid)
        logging.info(f"### assign_service_data function payload: {data}")
    
        # Call the downstream function to process the assignment
        response =  submit_assign_service_data(data)
        # Audit log
        try:
            audit_data = {
                "service_name": "assign_service_data",
                "created_by": user_name ,
                "session_id": session_id ,
                "tenant_name": Partner ,
                "comments": f"Service assignment processed successfully for {len(data['submit_data']['customer_name'])} customers",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at ,
                "status": str(response.get("flag", "")),
            }
            logging.info(
                f"### assign_service_data  function: Logging audit data: {audit_data}"
            )
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_error:
            logging.error(f"### Audit log failed: {audit_error}")

        return response
    
    except Exception as e:
        logging.error(
            f"### assign_service_data function error: {str(e)}",
            exc_info=True,
        )
        try:
            error_data = {
                "service_name": "assign_service_data",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name ,
                "session_id": session_id ,
                "tenant_name": Partner  ,
                "comments":  f"error occurred while processing the assign service data: {str(e)}",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at ,
            }
            logging.info(
                f"### assign_service_data function: Logging error to DB: {error_data}"
            )
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(f"DB logging failed: {logging_error}")
        return {"flag": False, "message": "Error processing assign service data"} 
    
def add_service_product(data):
    """
    Prepares and submits service product data for rev customer.
    This function is typically used for API calls (such as from ReadMe or Swagger UI) to add a service product to a customer.
    It validates the required fields, formats the payload, and calls the downstream function to process the addition.
    Parameters:
        data (dict): Input dictionary containing:
            - customer_name (str or list): Name(s) of the customer(s).
            - service_id (str): The type of service to add.
            - product_name (str): The product to add (will be formatted as 'product_id:<value>').
            - sescription (str): Description for service product.
            - service_provider (str): The service provider name.
            - iccid (list): List of ICCIDs to add.
            - service_number (list): List of service numbers (MSISDNs) to add.
    Returns:
        dict: Result from submit_add_service_product_data, or an error message if validation fails.

    """
    logging.info(f"### add_service_product function called with data: {data}")
    user_name= data.get("username", "") 
    session_id =  data.get("session_id", "") 
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at")
    username = data.get("client_id", "")
    # Get context data for the service account
    context_data = get_service_account_context(username)
    if not context_data:
        logging.error("### add_service_product: Failed to get context data for username: %s", username)
        return {"flag": False, "message": "Failed to retrieve service account context."}
    role = context_data.get("role", "")
    if role in ["User", "Agent"]:
        logging.info("### add_service_product: permission denied for role")
        return {"flag": False, "message": "You do not have permission to perform this action."}
    # Prepare data for processing
    tenant_name = context_data.get("tenant_name", "")
    data["tenant_name"] = tenant_name
    data["username"] = username
    data["firstLastName"] = f"{context_data.get('first_name', '')} {context_data.get('last_name', '')}"
    data["role_name"] = role
    data["Partner"] = tenant_name
    data["request_received_at"] = datetime.datetime.now(timezone.utc)
    tenant_database = context_data.get("db_name")
    data["db_name"] = tenant_database
    database = DB(tenant_database, **db_config)
    service_id = data.get("service_number", "")
    common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **db_config)

    # Extract and validate required fields
    customer_name = data.get("customer_name", "")
    try:
        # fetch integration authentication ID based on tenant name
        integration_authentication_json_data = load_integration_authentication_json()
        integration_authentication_id = get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)
        if not integration_authentication_id:
            tenant_details = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["parent_tenant_id"]
            )
            if tenant_details.empty:
                logging.info(f"### add_service_product function checkpoint: Tenant {tenant_name} not found")
                return {"flag": False, "message": f"Tenant {tenant_name} not found"}
            parent_tenant_id= tenant_details["parent_tenant_id"].to_list()[0]
            if parent_tenant_id:
                parent_tenant_id=int(parent_tenant_id)

            parent_tenant_name = common_utils_database.get_data(
                "tenant", {"id": parent_tenant_id}, ["tenant_name"]
            )["tenant_name"].to_list()[0]
            integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, parent_tenant_name)
        if not integration_authentication_id:
            logging.info(f"### add_service_product function checkpoint: Integration authentication ID not found for tenant {tenant_name}")
            return {"flag": False, "message": f"Integration authentication ID not found for tenant {tenant_name}"}
        
        # Validate customer name and service type
        rev_customer_data = database.get_data(
            "revcustomer",
            {"customer_name": customer_name, "is_active": True, "integration_authentication_id": integration_authentication_id},
            ["id"],
        )
        if rev_customer_data.empty:
            logging.info(
                "### add_service_product function checkpoint: customer name not valid"
            )
            return {"flag": False, "message": "Customer name is not valid"}
        rev_customer_id = tuple(str(i) for i in rev_customer_data["id"].tolist())
        rev_customer_ids = ", ".join(f"'{s}'" for s in rev_customer_id)
        logging.info(f"### rev_service_id : {rev_customer_ids}")
        rev_service_query = f"""
            SELECT rs.number, rs.rev_service_id, rst.description
            FROM rev_service rs
            INNER JOIN rev_service_type rst
                ON rs.rev_service_type_id = rst.id
            WHERE rs.rev_customer_id IN ({rev_customer_ids})
            AND rs.number in {tuple(service_id)}
            AND rs.is_deleted = FALSE
            AND rs.is_active = TRUE
            AND rs.disconnected_date IS NULL
            AND rs.integration_authentication_id = {integration_authentication_id}
        """
        # params = (tuple(service_id), integration_authentication_id)
        logging.info(f"### add_service_product function checkpoint: rev_service_query: {rev_service_query}")
        service_types_df = database.execute_query(rev_service_query, True)
        if service_types_df.empty:
            logging.info(
                "### add_service_product function checkpoint: no service types found for customer"
            )
            return {
                "flag": False,
                "message": "No service types found for the given customer.",
            }
        revio_services = service_types_df["rev_service_id"].tolist()

        #prepare the payload for submission
        submit_data = {
            "revio_serive":{
                customer_name: revio_services
            },
            "customer_name": [customer_name] if isinstance(customer_name, str) else customer_name,
            "product_name":data.get("product_name", ""),
            "rate": data.get("rate", ""),
            "quantity": data.get("quantity", 1),
            "prorate": data.get("prorate", False),
            "effective_date": data.get("effective_date", None),
            "description": data.get("description", ""),
            "iccids":{
                customer_name: data.get("iccid", [])
            },
            "msisdn":{
                customer_name: data.get("service_number", [])
            }
        }
        data["submit_data"] = submit_data
        logging.info(f"### add_service_product function payload: {data}")
        # Call the downstream function to process the addition
        response =  submit_service_product_data(data)
        
        try:
            audit_data = {
                "service_name": "add_service_product",
                "created_by": user_name ,
                "session_id": session_id  ,
                "tenant_name": tenant_name  ,
                "comments": f"Service product added successfully for {len(data['submit_data']['customer_name'])} customers",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at  ,
                "status": str(response.get("flag", "")),
            }
            logging.info(
                f"### add_service_product function: Logging audit data: {audit_data}"
            )
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_error:
            logging.error(f"### Audit log failed: {audit_error}")

        return response

    
    except Exception as e:
        logging.error(
            f"### add_service_product function error: {str(e)}",
            exc_info=True,
        )


        # Add error log with comments
        try:
            error_data = {
                "service_name": "add_service_product",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name ,
                "session_id": session_id ,
                "tenant_name": tenant_name ,
                "comments": f"failed to  add service product data: {str(e)}",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at ,
            }
            logging.info(
                f"### add_service_product function: Logging error to DB: {error_data}"
            )
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(
                f"### add_service_product function: Failed to log error to database: {logging_error}"
            )
        return {"flag": False, "message": "Error processing add service product data"}
    
    
def add_service_line(data):
    """
    Prepares and submits service line data for rev customer.
    This function is typically used for API calls (such as from ReadMe or Swagger UI) to add a service line to a customer.
    It validates the required fields, formats the payload, and calls the downstream function to process the addition.
    Parameters:
        data (dict): Input dictionary containing:
            - customer_name (str or list): Name(s) of the customer(s).
            - service_type (str): The type of service to add.
            - revio_product (str): The product to add (will be formatted as 'product_id:<value>').
            - revio_package (str, optional): The package to add (if any).
            - service_provider (str): The service provider name.
            - iccid (list): List of ICCIDs to add.
            - service_number (list): List of service numbers (MSISDNs) to add.
    Returns:
        dict: Result from submit_add_service_line_data, or an error message if validation fails.

    """
    logging.info(f"### add_service_line function called with data:{data}")
    try:
        # user_name= data.get("username", "") 
        session_id =  data.get("session_id", "") 
        tenant_name = data.get("tenant_name", "")
        request_received_at = data.get("request_received_at")

        try : 
            # connecting to database for auditing purpose 
            common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **db_config)
        except Exception as db_error: 
            return {"flag": False, "message": f"Database connection failed: {str(db_error)}"} 

        username = data.get("client_id", "")
        # Get context data for the service account
        context_data = get_service_account_context(username)
        if not context_data:
            logging.error("### add_service_line: Failed to get context data for username: %s", username)
            return {"flag": False, "message": "Failed to retrieve service account context."}
        role = context_data.get("role", "")
        if role in ["User", "Agent"]:
            logging.info("### add_service_line: permission denied for role")
            return {"flag": False, "message": "You do not have permission to perform this action."}
        
        # Prepare data for processing
        tenant_name = context_data.get("tenant_name", "")
        data["tenant_name"] = tenant_name
        data["username"] = username
        data["firstLastName"] = f"{context_data.get('first_name', '')} {context_data.get('last_name', '')}"
        data["role_name"] = role
        data["Partner"] = tenant_name
        data["request_received_at"] = datetime.datetime.now(timezone.utc)
        tenant_database = context_data.get("db_name")
        data["db_name"] = tenant_database
        customer_name = data.get("customer_name", "")
        revio_product = data.get("revio_product", "")
        data["session_id"] = "service_accounts"
        data["submit_data"] = {
            "customer_name": [customer_name] if isinstance(customer_name, str) else customer_name,
            "provider_name": data.get("provider_name", ""),
            "service_type": data.get("service_type", ""),
            "revio_product":[revio_product] if isinstance(revio_product, str) else revio_product,
            "revio_package": data.get("revio_package", None),
            "rate": [data.get("rate", "")],
            "rate_plan": data.get("rate_plan", ""),
            "activation_date": data.get("activation_date", None),
            "quantity": data.get("quantity", 1),
            "add_rate_plan": data.get("add_rate_plan", False),
            "prorate": data.get("prorate", False),
            "use_carrier_activation": data.get("use_carrier_activation", False),
            "description": data.get("description", ""),
            "iccid": data.get("iccid", []),
            "usage_plan_group": data.get("usage_plan_group", None),
            "service_number": data.get("service_number", []),
            "service_provider": data.get("service_provider", "")
        }
        logging.info(f"### add_service_line_function payload: {data}")
        response =  add_service_line_data(data)
       
        try:
            audit_data = {
                "service_name": "add_service_line",
                "created_by": username ,
                "session_id": session_id  ,
                "tenant_name": tenant_name  ,
                "comments":f"Service line added successfully for {len(data['submit_data']['customer_name'])} customers",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at  ,
                "status": str(response.get("flag", "")),
            }
            logging.info(
                f"### add_service_line function: Logging audit data: {audit_data}"
            )
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_error:
            logging.error(f"### Audit log failed: {audit_error}")

        return response
    
    except Exception as e:
        logging.error(
            f"### add_service_line function error: {str(e)}",
            exc_info=True,
        )
   

        # Add error log with comments
        try:
            error_data = {
                "service_name": "add_service_line",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username ,
                "session_id": session_id ,
                "tenant_name": tenant_name ,
                "comments":f"failed to  add service line data: {str(e)}",
                "module_name": "Rev Assuarance",
                "request_received_at": request_received_at ,
            }
            logging.info(
                f"### add_service_line function: Logging error to DB: {error_data}"
            )
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(
                f"### add_service_line function: Failed to log error to database: {logging_error}"
            )
    
        return {"flag": False, "message": "Error processing add service line data"}