# Standard library imports
import os
import re
import copy
import json
import math
import time
import traceback
import uuid
import logging
from datetime import datetime, timedelta

# Third-party library imports
import numpy as np
import pandas as pd
import requests
import boto3
import queue
import psycopg2
from psycopg2 import pool as pg_pool
from psycopg2.extras import execute_values
from sqlalchemy import create_engine, exc, text
from tenacity import retry, stop_after_attempt, wait_fixed
from dotenv import load_dotenv
import pytds

# Local application imports
from common_utils.logging_utils import Logging
logging = Logging()

class DataTransfer:
    pg_connection_pool = None
    mssql_connection_pool = None
    _mssql_max_pool_size = 5
    _pg_pools = {}
    _mssql_pools = {}

    def __init__(self):
        pass

    @classmethod
    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
    def create_connection(
        self,
        db_type="",
        host="",
        db_name="",
        username="",
        password="",
        port="",
        driver="",
        max_retry=3,
    ):
        connection = None
        key = f"{host}:{port}/{db_name}"
        logging.info(f"Creating connection for {key}")

        if db_type == "postgresql":
            logging.info(f"Creating PostgreSQL connection for {key}")
            if key not in self._pg_pools:
                logging.info(f"Creating PostgreSQL pool for {key}")
                self._pg_pools[key] = pg_pool.SimpleConnectionPool(
                    minconn=1,
                    maxconn=5,
                    host=host,
                    port=port,
                    database=db_name,
                    user=username,
                    password=password,
                )
            try:
                return self._pg_pools[key].getconn()
            except Exception as e:
                logging.error(f"Failed to get PostgreSQL connection: {e}")
                raise
        elif db_type == "postgresql__":
            try:
                logging.info(f"creating postgresql connection")

                connection = psycopg2.connect(
                    host=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port,
                )
                logging.info("Connection to PostgreSQL DB successful")
            except Exception as e:
                logging.error(f"Failed to connect to PostgreSQL DB: {e}")

        elif db_type == "mssql":
            # No native pool in pytds, so simulate pooling manually
            if key not in self._mssql_pools:
                logging.info(f"Creating MSSQL connection pool for {key}")
                self._mssql_pools[key] = []

            pool = self._mssql_pools[key]
            if pool:
                logging.info(f"Reusing MSSQL connection from pool: {key}")
                return pool.pop()
            else:
                try:
                    active_conns = len(pool)
                    if active_conns >= self._mssql_max_pool_size:
                        logging.info(f"Creating new MSSQL connection Failed, Pool Size limit reached: {key}")
                        raise Exception(f"MSSQL pool max size ({self._mssql_max_pool_size}) reached for {key}")
                    logging.info(f"Creating new MSSQL connection: {key}")
                    return pytds.connect(
                        server=host,
                        port=port,
                        database=db_name,
                        user=username,
                        password=password,
                    )
                except Exception as e:
                    logging.error(f"Failed to connect to MSSQL DB: {e}")
                    raise
        return connection

    @classmethod
    def release_connection(self, db_type, host, port, db_name, conn):
        key = f"{host}:{port}/{db_name}"

        if db_type == "postgresql" and key in self._pg_pools:
            self._pg_pools[key].putconn(conn)
            logging.info(f"Returned PostgreSQL connection to pool: {key}")

        elif db_type == "mssql":
            if key not in self._mssql_pools:
                self._mssql_pools[key] = []
            self._mssql_pools[key].append(conn)
            logging.info(f"Returned MSSQL connection to simulated pool: {key}")

    @classmethod
    def close_all_pools(self):
        for key, pool in self._pg_pools.items():
            pool.closeall()
            logging.info(f"Closed PostgreSQL pool: {key}")
        self._pg_pools.clear()

        for key, pool in self._mssql_pools.items():
            for conn in pool:
                try:
                    conn.close()
                except Exception as e:
                    logging.warning(f"Failed to close MSSQL connection in pool {key}: {e}")
            logging.info(f"Closed MSSQL simulated pool: {key}")
        self._mssql_pools.clear()

    def send_msg_sim_management_trigger_queue(self, message_body):
        try:
            print("-----------", message_body)
            # Initialize the SQS client
            print("calling SQS QUEUEEEEEEEEEEEEEE")
            sqs_client = boto3.client("sqs", region_name="us-east-1")
            message_body["sqs_flag"] = True
            queue_url = os.getenv("SIM_MANAGEMENT_TRIGGER_QUEUE")
            # queue_url = "https://sqs.us-east-1.amazonaws.com/008971638399/sim_management_trigger_queue_uat.fifo"
            # Send the message to the SQS queue
            message_group_id = str(uuid.uuid4())
            response = sqs_client.send_message(
                QueueUrl=queue_url,
                MessageBody=json.dumps(message_body),
                MessageGroupId=message_group_id,
                MessageDeduplicationId=str(uuid.uuid4()),
            )

            logging.info(
                f"Message sent to SQS queue {queue_url}. Message ID: {response['MessageId']}"
            )
            return response["MessageId"]
        except Exception as e:
            logging.error(f"Error sending message to SQS queue: {e}")
            raise

    def execute_query(self, connection, query, params=None):

        try:
            # Check if params are provided
            start_time = time.time()
            if params:
                # Execute the query with parameters
                logging.info(f"PARAMS are execute_query {params}")
                result_df = pd.read_sql_query(query, connection, params=params)
            else:
                # Execute the query without parameters
                result_df = pd.read_sql_query(query, connection)
            elapsed_time = time.time() - start_time
            logging.info(f"Query executed in {elapsed_time:.3f} seconds")
            return result_df
        except Exception as e:
            elapsed_time = time.time() - start_time
            logging.error(f"Error executing query: {e}")
            logging.info(f"Error executing query :1 {e}")
            logging.info(f"Error executing query 2 after {elapsed_time:.3f} seconds: {e}")
            logging.info(f"Error executing query 3 {elapsed_time:.3f} seconds:{traceback.format_exc()}")
            return None

    def is_valid_table_name(self, table_name):
        pattern = r"^\[\w+\]\.\[\w+\]\.\[\w+\]$"
        return re.match(pattern, table_name) is not None

    def map_cols(self, table_mapping, col_mapping, postgres_data):
        try:
            insert_data = {}

            for table_name, records in postgres_data.items():
                # Get target table names for table_name
                target_tables = table_mapping.get(table_name, [])

                for target_table in target_tables:
                    # Get column mappings for the target table
                    mapping = col_mapping.get(target_table, {})
                    # print(f"Mapiin got for {target_table} is {mapping}")

                    temp_records = [
                        {
                            mapping[key]: value
                            for key, value in record.items()
                            if key in mapping
                        }
                        for record in records
                    ]
                    # print(f"TEmp recs are {temp_records}")
                    insert_data[target_table] = temp_records
            return insert_data
        except Exception as e:
            logging.error(f"Error while mapping columns: {e}")
            return {}

    def replace_nan_with_none(self, data):
        for key, value in data.items():
            if isinstance(
                value, list
            ):  # If the value is a list, loop through each item
                for record in value:
                    for record_key, record_value in record.items():
                        if isinstance(record_value, float) and math.isnan(record_value):
                            record[record_key] = None
            elif isinstance(
                value, dict
            ):  # If the value is a dict, recursively handle it
                self.replace_nan_with_none(value)
            elif isinstance(value, float) and math.isnan(
                value
            ):  # Handle top-level keys
                data[key] = None

    ##to fetch the service providers ids for each tenants separately used to get the serviceprovider ids in generic way
    def load_json(self):
        """
        Loads a JSON file and returns the data.

        :param file_path: Absolute path to the JSON file.
        :return: Parsed JSON data as a dictionary, or None if an error occurs.

        """
        # Define the JSON file path
        FILE_PATH = "tenant_based_serviceproviders.json"
        file_path=FILE_PATH
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                return json.load(file)
        except FileNotFoundError:
            logging.warning(f"Error: JSON file not found at {file_path}")
        except json.JSONDecodeError:
            logging.warning(f"Error: Invalid JSON format in {file_path}")
        except Exception as e:
            logging.exception(f"Unexpected error while reading JSON: {e}")

        return {}  # Return None if an error occurs

    def tenant_load_json(self):
        """
        Loads a JSON file and returns the data.

        :param file_path: Absolute path to the JSON file.
        :return: Parsed JSON data as a dictionary, or None if an error occurs.

        """
        # Define the JSON file path
        FILE_PATH = "tenant_sub_tenant.json"
        file_path=FILE_PATH
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                return json.load(file)
        except FileNotFoundError:
            logging.warning(f"Error: JSON file not found at {file_path}")
        except json.JSONDecodeError:
            logging.warning(f"Error: Invalid JSON format in {file_path}")
        except Exception as e:
            logging.exception(f"Unexpected error while reading JSON: {e}")

        return {}
    def get_provider_ids(self,json_data, tenant_name, provider_names):
        """Fetches only the IDs of specified providers for a given tenant."""
        return [
            details["id"]
            for provider_name, details in json_data.get(tenant_name, {}).items()
            if provider_name in provider_names
        ]

    def get_transfer_name(self,json_data, tenant_name, provider_names):
        """Fetches only the IDs of specified providers for a given tenant."""
        return_data = [
                        details["transfer_name"]
                        for provider_name, details in json_data.get(tenant_name, {}).items()
                        if provider_name in provider_names
                    ]
        if len(return_data) == 0:
            return None
        return return_data[0]

    def insert_data_to_db(
        self, table_name, data_list, mssql_conn, return_col, table_name_10
    ):
        try:
            if not mssql_conn:
                raise ValueError("Invalid MSSQL connection")

            if not data_list:
                raise ValueError("Data list is empty")

            cursor = mssql_conn.cursor()

            # Extract column names and placeholders
            for row in data_list:
                if "Id" in row:
                    cursor = mssql_conn.cursor()
                    print("entered into update part")
                    print(row.items())
                    # column_names = ', '.join([key for key in row.keys() if key != 'Id'])
                    # column_values = ', '.join([f"'{row[key]}'" for key in row.keys() if key != 'Id'])
                    values_section = ""
                    for key in row.keys():
                        if row[key] is None:
                            if values_section:
                                values_section = values_section + ", " + f"{'NULL'}"
                            else:
                                values_section = f"{'NULL'}"
                        else:
                            if values_section:
                                values_section = values_section + ", " + f"'{row[key]}'"
                            else:
                                values_section = f"'{row[key]}'"

                    source_columns = ", ".join([key for key in row.keys()])
                    print(values_section)
                    print(source_columns)

                    source_columns = ", ".join([key for key in row.keys()])
                    id_value = row["Id"]

                    # print("*******************", column_names, column_values)

                    matched_update = ", ".join(
                        [
                            f"target.{key} = source.{key}"
                            for key in row.keys()
                            if key != "Id"
                        ]
                    )

                    insert_columns = ", ".join(
                        [key for key in row.keys() if key != "Id"]
                    )
                    insert_values = ", ".join(
                        [f"source.{key}" for key in row.keys() if key != "Id"]
                    )
                    print("*******************", insert_columns, insert_values)

                    # Construct the SQL MERGE query
                    sql_merge_query = f"""
                    MERGE INTO {table_name} AS target
                    USING (VALUES ({values_section})) AS source ({source_columns})
                    ON target.Id = source.Id
                    WHEN MATCHED THEN
                    UPDATE SET {matched_update}
                    WHEN NOT MATCHED BY TARGET THEN
                    INSERT ({insert_columns}) VALUES ({insert_values});
                    """
                    #print(f"Merge Query {sql_merge_query}")

                    cursor.execute(sql_merge_query)
                    mssql_conn.commit()
                    print("merge query*******************************", sql_merge_query)
                    # return newly_inserted_id

                else:
                    cursor = mssql_conn.cursor()

                    # Extract column names and placeholders
                    columns = ", ".join(row.keys())
                    placeholders = ", ".join(
                        ["%s"] * len(row)
                    )  # Use %s placeholders for pytds
                    if return_col:
                        sql_query = f"INSERT INTO {table_name} ({columns}) OUTPUT INSERTED.{return_col} VALUES ({placeholders})"
                    else:
                        sql_query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"

                    try:
                        return_val = None
                        return_fk_name = None

                        # Convert rows to tuples and execute in a batch
                        # for row in data_list:

                        values = tuple(
                            (
                                None
                                if (
                                    (not row[col] or row[col] is None)
                                    and row[col] != False
                                )
                                else (
                                    row[col]
                                    if isinstance(row[col], (str, int, float, bool))
                                    else json.dumps(
                                        row[col].item()
                                        if isinstance(
                                            row[col], (np.integer, np.floating)
                                        )
                                        else row[col]
                                    )
                                )
                            )
                            for col in row.keys()
                        )
                        logging.info(f"{sql_query}")
                        logging.info(f"{values}")

                        cursor.execute(sql_query, values)

                        if return_col:
                            return_val = cursor.fetchone()[0]
                            return_fk_name = f"{table_name_10}.{return_col}"

                        mssql_conn.commit()
                        logging.info("Insert Successful")

                        if return_col:
                            return return_val, return_fk_name

                    except Exception as e:
                        logging.info(f"Failed to insert row into {table_name}: {e}")
                        mssql_conn.rollback()
                        return None

                    finally:
                        cursor.close()
        except Exception as e:
            logging.info(f"Error while inserting row into {table_name}: {e}")

    def update_table(self, conn, table_name, data_dict, condition_dict):
        """
        Update a PostgreSQL table using a dictionary.

        :param conn: psycopg2 connection object
        :param table_name: Name of the table to update
        :param data_dict: Dictionary containing column-value pairs to update
        :param condition_dict: Dictionary containing column-value pairs for the WHERE condition
        """
        try:
            # Replace NaN with None in data_dict
            data_dict = {
                k: (None if isinstance(v, float) and math.isnan(v) else v)
                for k, v in data_dict.items()
            }

            # Replace NaN with None in condition_dict
            condition_dict = {
                k: (None if isinstance(v, float) and math.isnan(v) else v)
                for k, v in condition_dict.items()
            }
            # Generate the SET part of the SQL query
            set_clause = ", ".join([f"{col} = %s" for col in data_dict.keys()])

            # Handle condition dict with lists or single values
            where_clause = []
            # print(f"in updat_table val dict is {data_dict}")
            values = list(data_dict.values())

            for col, val in condition_dict.items():
                if isinstance(val, list):
                    # Generate the WHERE clause for IN condition
                    placeholders = ", ".join(["%s"] * len(val))
                    where_clause.append(f"{col} IN ({placeholders})")
                    values.extend(val)  # Add the list values to the values list
                else:
                    # Handle single value condition
                    where_clause.append(f"{col} = %s")
                    values.append(val)

            # Combine WHERE conditions
            if where_clause:
                where_clause = " AND ".join(where_clause)
                sql_query = f"UPDATE {table_name} SET {set_clause} WHERE {where_clause}"
            else:
                sql_query = f"UPDATE {table_name} SET {set_clause}"

            # Print the SQL query and values for debugging
            logging.info(f"Conn in update is {conn}")
            logging.info(f"SQL Query: {sql_query}")
            logging.info(f"Values: {values}")

            # Execute the query
            try:
                with conn.cursor() as cursor:
                    cursor.execute(sql_query, values)
                    conn.commit()
                logging.info("Update successful")
            except Exception as e:
                conn.rollback()
                logging.error(f"Error in updating {e}")
            # finally:
            #     if conn:
            #         conn.close()

        except Exception as e:
            conn.rollback()
            logging.error(f"Error while updating table {table_name}: {e}")
        # finally:
        #     if conn:
        #         conn.close()

    def load_env_pgsql(self):
        load_dotenv()
        hostname = os.getenv("LOCAL_DB_HOST")
        port = os.getenv("LOCAL_DB_PORT")
        user = os.getenv("LOCAL_DB_USER")
        password = os.getenv("LOCAL_DB_PASSWORD")
        db_type = os.getenv("LOCAL_DB_TYPE")
        db_name = os.getenv("LOCAL_DB_NAME")
        return hostname, port, user, password, db_type, db_name

    def load_env_mssql(self):
        from_host = os.getenv("FROM_DB_HOST")
        from_port = os.getenv("FROM_DB_PORT")
        from_db = os.getenv("FROM_DB_NAME")
        from_user = os.getenv("FROM_DB_USER")
        from_pwd = os.getenv("FROM_DB_PASSWORD")
        from_db_type = os.getenv("FROM_DB_TYPE")
        from_driver = os.getenv("FROM_DB_DRIVER")
        return (
            from_host,
            from_port,
            from_db,
            from_user,
            from_pwd,
            from_db_type,
            from_driver,
        )

    def delete_from_pgsql(self, mssql_conn, id_10, table_name_10):
        try:
            cursor = mssql_conn.cursor()
            print(f"Going to update id {id_10}")
            delete_query = (
                f"Update {table_name_10} set IsActive=0, IsDeleted=1 where id={id_10}"
            )
            print(f"Delete Query {delete_query}")
            cursor.execute(delete_query)
            mssql_conn.commit()
            print(f"Deleted from 1.0")
        except Exception as e:
            print(f"Error while deleting from 1.0: {e}")

    def delete_from_10_customerrp(self, mssql_conn, id_10, table_name_10):
        try:
            print(f"conn is {mssql_conn}")
            cursor = mssql_conn.cursor()
            delete_query = (
                f"DELETE FROM {table_name_10} WHERE CustomerRatePlanId={id_10}"
            )
            cursor.execute(delete_query)
            mssql_conn.commit()
            print(f"Deleted from 1.0")
        except Exception as e:
            print(f"delete_from_10_customerrp Error while deleting from 1.0: {e}")

    def is_valid_table_name(self, table_name):
        pattern = r"^\[\w+\]\.\[\w+\]\.\[\w+\]$"
        return re.match(pattern, table_name) is not None
    def delete_data_from_10(self, transfer_name, postgres_data, id_10, table_name_10,ssms_db_name,mssql_conn):
        try:


            if not self.is_valid_table_name(table_name_10):
                full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                print(f"full table name {full_from_table}")
            else:
                full_from_table = table_name_10
            if transfer_name.startswith("customer_rate_plan"):
                self.delete_from_10_customerrp(mssql_conn, id_10, full_from_table)
            #else:
                #dd = self.delete_from_pgsql(mssql_conn, id_10, full_from_table)
        except Exception as e:
            print(f"Error while loading env: {e}")

    def save_data_to_10_single_table(
        self, transfer_name, postgres_data, update_flag=False, delete_flag=False
    ):
        try:
            logging.info(f"STARTING {transfer_name}")
            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            logging.info(
                f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}"
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_details_query = f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_name_10,db_config from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get("table_mapping_10_to_20", {})
            db_name_20 = mapping_details.get("db_name_20", {})
            logging.info(f"db_name_20 is {db_name_20}")
            logging.info(type(tables_dict))  # 1.0 to 2.0 table mappings dict
            col_mappings = mapping_details.get("col_mapping_10_to_20", {})
            logging.info(type(col_mappings))  # 1.0 to 2.0 column mappings
            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})  # foreign key columns
            table_name_20 = mapping_details.get("table_mapping_10_to_20").keys()
            table_name_20 = ", ".join(str(key) for key in table_name_20)
            logging.info(f"table_name_20 is {table_name_20}")
            table_name_10 = tables_dict[table_name_20][0]
            logging.info(f"Table Name 1.0 is {table_name_10}")
            # update_flag=True
            hostname = os.getenv("LOCAL_DB_HOST")
            port = os.getenv("LOCAL_DB_PORT")
            db_name = db_name_20
            user = os.getenv("LOCAL_DB_USER")
            password = os.getenv("LOCAL_DB_PASSWORD")
            db_type = os.getenv("LOCAL_DB_TYPE")
            from_driver = os.getenv("LOCAL_DB_DRIVER")
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mssql_config = mapping_details.get("db_config", {})  # ssms db config details
            db_name_10 = mapping_details.get("db_name_10", {})

            postgres_data_copy = copy.deepcopy(postgres_data)
            if delete_flag is True and update_flag is False:
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                update_data["id_10"] = id_10
                logging.info(f"id_10 is {id_10}")
                delete_data = self.delete_data_from_10(
                    transfer_name, postgres_data, id_10, table_name_10
                )
                return True

            elif update_flag is True and delete_flag is False:
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                logging.info(f"id_10 is {id_10}")
                update_data["id_10"] = id_10
                postgres_data_20 = {table_name_20: [update_data]}
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data_20
                )
            else:
                logging.info(f"tables_dict {tables_dict}")
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data
                )
            logging.info(f"total insert dict is {total_insert_dict}")

            if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                logging.info("no mappings present for the configurations so returning the function")
                return True
            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn {mssql_conn}")

            logging.info(f"total insert dict {total_insert_dict}")

            return_ids = []

            fk_track_dict = {}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                # if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"

                if return_params_10:
                    logging.info(f"Heree 2111 {return_params_10}")
                    return_col = return_params_10.get(
                        table_name_10, None
                    )  # get the col whose value should be returned for this table
                    fk_col_dict = fk_cols_10.get(
                        table_name_10, {}
                    )  # get the fk_col dict for this table
                else:
                    return_col = None
                    fk_col_dict = None

                if not return_col and not fk_col_dict:
                    logging.info(
                        "This part is to handle update tables don't have any foreign key columnc"
                    )
                    if update_flag is False:
                        return_col = "ID"
                        return_val, return_fk_name = self.insert_data_to_db(
                            full_from_table,
                            total_insert_dict[table_name_10],
                            mssql_conn,
                            return_col,
                            table_name_10,
                        )
                        logging.info(
                            f"return val is {return_val} return fk name is {return_fk_name}"
                        )
                        update_postgres_data = postgres_data[table_name_20][0]
                        logging.info(
                            f"2.0 data is to be updated is {update_postgres_data}"
                        )
                        update_postgres_data["id_10"] = return_val
                        update_postgres_id = update_postgres_data["id"]
                        update_postgres_data.pop("id")
                        logging.info(f"update_postgres_data is {update_postgres_data}")
                        self.update_table(
                            postgres_conn1,
                            table_name_20,
                            update_postgres_data,
                            {"id": update_postgres_id},
                        )

                    else:
                        update_value, update_condtion = self.insert_data_to_db(
                            full_from_table,
                            total_insert_dict[table_name_10],
                            mssql_conn,
                            None,
                            table_name_10,
                        )
                        logging.info(
                            f"update value is {update_value} update condition is {update_condtion}"
                        )
                        logging.info(postgres_conn)
                        update_data_20 = postgres_data[table_name_20][0]
                        logging.info(f"update data 20 is {update_data_20}")
                        id_10 = int(update_value["id"])
                        update_data_20["id_10"] = id_10
                        id_20 = int(update_data_20["id"])
                        self.update_table(
                            postgres_conn1, table_name_20, update_data_20, {"id": id_20}
                        )

            # DataTransfer.release_connection("postgresql", postgres_conn1)
            # DataTransfer.release_connection("postgresql", postgres_conn)
            # DataTransfer.release_connection("mssql", mssql_conn)
        except Exception as e:
            logging.error(f"Error in single_table_data_insert {e}")

    def service_provider_setting_sync(self, data, transfer_name):
        try:
            print(f"### Received request data: {data}, transfer_name: {transfer_name}")
            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_details_query = f"select db_name_10,db_config from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            mssql_config = mapping_details.get("db_config", {})  # ssms db config details
            db_name_10 = mapping_details.get("db_name_10", {})

            if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                logging.info("no mappings present for the configurations so returning the function")
                return True
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn {mssql_conn}")

            cursor = mssql_conn.cursor()

            # Validate input
            if not isinstance(data, dict) or 'custom_fields' not in data:
                raise ValueError("Invalid input data format")

            # Update records using parameterized queries to prevent SQL injection
            update_query = '''UPDATE serviceprovidersetting
                                    SET settingvalue = %s
                                    WHERE settingkey = %s
                                    AND serviceproviderid = %s'''

            for each in data['custom_fields']:
                print(each)
                cursor.execute(update_query, (each['setting_value'], each['setting_key'], each['service_provider_id']))

            # Commit changes
            mssql_conn.commit()

            print("Finished updating!")
            response = {"flag": True, "message": "Successfully updated the records"}

        except Exception as e:
            print(f"Exception at service_provider_setting_sync: {e}")
            response = {"flag": False, "message": f"Error: {e}"}

        finally:
            # Ensure connection is closed
            if 'mssql_conn' in locals():
                cursor.close()
                mssql_conn.close()

        return response

    def convert_dict_to_dfs(self,data):
        """Converts a dictionary with table-like structure into Pandas DataFrames, handling JSON fields."""

        dfs = {}  # Store DataFrames

        for table_name, records in data.items():
            df = pd.DataFrame(records)  # Convert to DataFrame

            # Flatten any JSON-like columns automatically
            for col in df.columns:
                try:
                    df[col] = df[col].apply(lambda x: json.loads(x) if isinstance(x, str) and x.startswith('{') else x)
                    if df[col].apply(lambda x: isinstance(x, dict)).any():  # If JSON detected, expand
                        df = df.join(pd.json_normalize(df[col])).drop(columns=[col])
                except (json.JSONDecodeError, TypeError):
                    pass  # Ignore non-JSON fields

            dfs[table_name] = df  # Store processed DataFrame

        return dfs

    def insert_dataframe_to_mssql(self,df, table_name, conn):
        """
        Inserts a DataFrame into an MSSQL table using a pytds connection,
        ignoring extra columns in the DataFrame that are not in the table.

        Parameters:
            df (pd.DataFrame): The DataFrame to insert.
            table_name (str): The name of the target table.
            conn (pytds.Connection): The active database connection.

        Returns:
            None
        """
        try:
            # Get column names from the target table
            cursor = conn.cursor()
            cursor.execute(f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table_name}'")
            table_columns = {row[0] for row in cursor.fetchall()}
            logging.info(f"table cols are {table_columns}")

            # Keep only matching columns
            df_filtered = df[[col for col in df.columns if col in table_columns]]

            if df_filtered.empty:
                logging.info("No matching columns to insert. Check table structure.")
                return

            # Convert DataFrame to list of tuples for insertion
            columns_str = ", ".join(df_filtered.columns)
            placeholders = ", ".join(["%s"] * len(df_filtered.columns))
            insert_query = f"INSERT INTO {table_name} ({columns_str}) VALUES ({placeholders})"

            # Execute insert statement for all rows
            cursor.executemany(insert_query, df_filtered.values.tolist())
            conn.commit()

            logging.info(f"Data inserted successfully into {table_name}")

        except Exception as e:
            logging.error(f"Error inserting data: {e}")

    def insert_dataframe_to_mssql_with_sqlalchemy(self, df, table_name, server, database, username, password, port=1433,pytds_conn=None):
        """
        Inserts a DataFrame into an MSSQL table using SQLAlchemy with pyodbc.
        This function ensures that only columns present in the table are inserted.

        Parameters:
            df (pd.DataFrame): The DataFrame to insert.
            table_name (str): The name of the target table.
            server (str): The SQL Server address.
            database (str): The database name.
            username (str): The username for the database connection.
            password (str): The password for the database connection.
            port (int, optional): The SQL Server port (default is 1433).

        Returns:
            None
        """
        try:
            # Create a connection string using the input parameters
            connection_string = f"mssql+pyodbc://{username}:{password}@{server}:{port}/{database}?driver=ODBC+Driver+17+for+SQL+Server"
            logging.info(f"Connection string: {connection_string}")

            # Create the SQLAlchemy engine
            engine = create_engine(connection_string)

            # Retrieve columns of the table to compare with the DataFrame

            cursor = pytds_conn.cursor()
            query = f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table_name}'"
            cursor.execute(query)
            table_columns = {row[0] for row in cursor.fetchall()}
            # with engine.connect() as conn:
            #     result = conn.execute(query)
            #     table_columns = [row[0] for row in result]
            logging.info(f"table cols are {table_columns}")

            # Filter the DataFrame columns to only include those present in the table
            df_columns = df.columns
            columns_to_insert = [col for col in df_columns if col in table_columns]

            # Subset the DataFrame to include only the columns that exist in the table
            df_filtered = df[columns_to_insert]

            # Insert the filtered DataFrame into the table
            df_filtered.to_sql(table_name, con=engine, if_exists='append', index=False)

            logging.info(f"Data inserted successfully into {table_name}.")

        except Exception as e:
            logging.error(f"Error inserting data: {e}")

    def insert_dataframe_to_mssql_4(self, df, table_name, conn, batch_size=100):
        """
        Inserts a DataFrame into an MSSQL table using a pytds connection,
        batching inserts by generating a single INSERT INTO ... VALUES statement per batch.

        Parameters:
            df (pd.DataFrame): The DataFrame to insert.
            table_name (str): The name of the target table.
            conn (pytds.Connection): The active pytds connection.
            batch_size (int): Number of rows per batch.

        Returns:
            None
        """
        try:
            cursor = conn.cursor()
            query = f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table_name}'"
            cursor.execute(query)
            table_columns = {row[0].lower() for row in cursor.fetchall()} #{row[0] for row in cursor.fetchall()}
            logging.info(f"Table columns are {table_columns}")

            df_filtered = df[[col for col in df.columns if col.lower() in table_columns]] #df[[col for col in df.columns if col in table_columns]]

            # Convert <NA> and np.nan to None so pytds doesn't break
            # df_filtered = df_filtered.where(pd.notna(df_filtered), None)
            df_filtered = df_filtered.astype(object).where(pd.notna(df_filtered), None)
            # print(df_filtered)
            logging.info(f"the df going to be inserted is") #{df_filtered.to_dict(orient='records')}

            if df_filtered.empty:
                logging.info("No matching columns to insert. Check table structure.")
                return

            columns_str = ", ".join(f"[{col}]" for col in df_filtered.columns)
            total_rows = len(df_filtered)
            rows = df_filtered.values.tolist()

            for i in range(0, total_rows, batch_size):
                batch = rows[i:i + batch_size]
                logging.info(f"Inserting batch {i // batch_size + 1} ({len(batch)} rows)...")

                # Create one INSERT statement with multiple VALUES
                value_placeholders = []
                flat_values = []

                for row in batch:
                    placeholders = "(" + ", ".join(["%s"] * len(row)) + ")"
                    value_placeholders.append(placeholders)
                    flat_values.extend(row)

                insert_query = f"INSERT INTO {table_name} ({columns_str}) VALUES {', '.join(value_placeholders)}"

                cursor.execute(insert_query, flat_values)

            conn.commit()
            logging.info(f"Data inserted successfully into {table_name} in {((total_rows - 1) // batch_size) + 1} batches.")

        except Exception as e:
            logging.info(f"Error inserting data: {e}")
            logging.error(f"Error inserting data: {e}")

    def bulk_save_data_to_10(self,transfer_name,postgres_data,tenant_name):
        try:
            logging.info(f"STARTING {transfer_name}")
            logging.info(f"postgres_data is {postgres_data}")
            sub_tenants_json=self.tenant_load_json()

            logging.info(f"save_data_10 tenant name is {tenant_name}")
            if transfer_name == "bulk_change":
                data_list = postgres_data["sim_management_bulk_change"]
                service_provider_id = data_list[0]["service_provider_id"]
                logging.info(f"### save_data_to_10 service_provider_id is {service_provider_id}")
                json_data = self.load_json()
                telegence_ids = self.get_provider_ids(json_data, tenant_name, ["Telegence"])
                logging.info(f"### save_data_to_10 telegence_ids is {telegence_ids}")

                if tenant_name.lower() in ('altaworx_test','altaworx'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_bulk_update"
                    else:
                        transfer_name = "bulk_change_m2m_bulk_update"

                elif tenant_name.lower() == 'spectrotel':
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_spectrotel"
                    else:
                        transfer_name = "bulk_change_spectrotel"

                elif tenant_name in ('altaworx_go_tech','Altaworx - Go Tech'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_altaworx_go_tech"
                    else:
                        transfer_name = "bulk_change_altaworx_go_tech"

                elif tenant_name.lower() in ('apitesttenant'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_apitesttenant"
                    else:
                        transfer_name = "bulk_change_apitesttenant"
                else:
                    logging.info("Tenant not found in save_data_20_from_10")
            logging.info(f"starting bulk save data to 10 {type(postgres_data)}")
            start_time = time.time()
            load_dotenv()
            hostname,port,user,password,db_type,db_name=self.load_env_pgsql()
            mapping_table=os.getenv('MAPPING_TABLE')
            postgres_conn = self.create_connection(db_type, hostname, db_name, user, password, port)
            mapping_details_query=f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_config,db_name_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details=self.execute_query(postgres_conn,mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError("No Mappings present for transfer")

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get(
                    "table_mapping_10_to_20", {}
                )
            db_name_20 = mapping_details.get("db_name_20", {})
            logging.info(f"db_name_20 is {db_name_20}")
            col_mappings = mapping_details.get(
                "col_mapping_10_to_20", {}
            )  # 1.0 to 2.0 column mappings
            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})  # foreign key columns
            db_config = mapping_details.get("db_config", {})  # ssms db config details
            logging.info(f"@@@@@@@@@@@@@@@@@@  mapping_details {type(mapping_details)}")
            table_name_20 = mapping_details.get("table_mapping_10_to_20").keys()
            table_name_20 = ", ".join(str(key) for key in table_name_20)
            logging.info(f"table_name_20 is {table_name_20}")
            mssql_config = mapping_details.get("db_config", {})  # ssms db config details
            db_name_10 = mapping_details.get("db_name_10", {})

            # get the data to insert dict for ssms according to mappings
            mapping_start = time.time()
            # print(f"postgres_data---------{postgres_data}")
            # print(f"col_mappings-----------{col_mappings}")
            hostname = os.getenv("LOCAL_DB_HOST")
            port = os.getenv("LOCAL_DB_PORT")
            db_name = db_name_20
            user = os.getenv("LOCAL_DB_USER")
            password = os.getenv("LOCAL_DB_PASSWORD")
            db_type = os.getenv("LOCAL_DB_TYPE")
            from_driver = os.getenv("LOCAL_DB_DRIVER")
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(f"Postgres Conn {postgres_conn1}")
            '''(
                from_host,
                from_port,
                ssms_db_name,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()'''
            if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                logging.info("no mappings present for the configurations so returning the function")
                return True
            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn {mssql_conn}")
            # logging.info(f"tables_dict {tables_dict}")
            total_insert_dict = self.map_cols(
                tables_dict, col_mappings, postgres_data
            )
            logging.info(f"total insert dict is {type(total_insert_dict)}")
            logging.info(f"total insert dict kyes {total_insert_dict.keys()}")
            logging.info(f"DCR: {total_insert_dict['DeviceChangeRequest'][0]}")
            logging.info(f"DeviceChange {total_insert_dict['M2M_DeviceChange'][0]}")
            dfs = self.convert_dict_to_dfs(total_insert_dict)


            prev_return_param = None
            prev_table_main = None
            prev_table_full = None
            prev_df = None

            prev_return_param_dependent = None
            prev_table_main_dependent = None
            prev_table_full_dependent = None
            prev_df_dependent = None


            insert_start = time.time()
            for table_name_10, df in dfs.items():
                # Access individual DataFrames
                logging.info(f"\n{table_name_10} DataFrame:\n", df)



                if not self.is_valid_table_name(table_name_10):
                    full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                if return_params_10:
                        # return_params_10 = json.loads(return_params_10)
                        logging.info(f"Return Params are {return_params_10}")

                        return_col = return_params_10.get(
                            table_name_10
                        )  # get the col whose value should be returned for this table
                        fk_col_dict = fk_cols_10.get(
                            table_name_10, {}
                        )  # get the fk_col dict for this table
                        logging.info(f"return_col are {return_col}")
                else:
                    return_col = None
                    fk_col_dict = None

                logging.info(f"return_col {return_col}")
                logging.info(f"fk_col_dict {fk_col_dict}")
                # Condition 1: for Single Main table
                if not return_col and table_name_10 not in fk_cols_10:
                    # Condition: where the table does not return any fk (single tables which does not have any dependent tables)
                    logging.info(f"#### Single Table: {table_name_10}")


                # condition1: for main tables--these only return an fk
                elif return_col and table_name_10 not in fk_cols_10:
                    logging.info(f"##### Main Table: {table_name_10}")
                    logging.info(f"##### Main Table: {table_name_10}")
                    insert_data=self.insert_dataframe_to_mssql(df,table_name_10,mssql_conn)
                    prev_return_param=return_col
                    prev_table_main=table_name_10
                    prev_table_full=full_from_table
                    prev_df=df



                    # condition2: Tables which have an fk column and also return a col as fk
                elif return_col and table_name_10 in fk_cols_10:
                    prev_return_param_dependent=return_col
                    prev_table_main_dependent=table_name_10
                    prev_table_full_dependent=full_from_table

                    logging.info(f"###### {table_name_10} Table has FK and returns col as FK")
                    logging.info(f"FK is {fk_col_dict[f'{prev_table_main}.{prev_return_param}']}")
                    fk=fk_col_dict[f'{prev_table_main}.{prev_return_param}']
                    id_20=tuple(prev_df.get('id_20').to_list())
                    logging.info(f"Id 20 is {id_20}")

                    # id_20=(6939,)
                    if len(id_20)==1:
                        select_fk_from_10=f"select {prev_return_param} from {prev_table_full} where id_20 = {id_20[0]}"
                    else:
                        select_fk_from_10=f"select {prev_return_param} from {prev_table_full} where id_20 in {id_20}"

                    logging.info(f"select query is {select_fk_from_10}")
                    fk_from_10=self.execute_query(mssql_conn,select_fk_from_10)
                    fk_from_10=fk_from_10.to_dict(orient='records')
                    logging.info(f"fk_from_10 is {fk_from_10}")
                    bulk_change_id=fk_from_10[0][prev_return_param]
                    logging.info(f"Bulk change id is {bulk_change_id}")
                    fk_dict={id_20[0]:fk_dict[prev_return_param] for fk_dict in fk_from_10}
                    logging.info(f"fk_list={fk_dict}")
                    df[fk] = df[fk].replace(fk_dict)
                    insert_df2=self.insert_dataframe_to_mssql_4(df,table_name_10,mssql_conn)

                    prev_df_dependent=df


                    # condition3: where tables don't return any fk but contain fk col that needs to be updated
                elif (
                        table_name_10 in fk_cols_10
                        and table_name_10 not in return_params_10
                    ):
                    df['DeviceChangeRequestID'] = df['DeviceChangeRequestID'].fillna(0).astype(int)
                    logging.info(f"###### {table_name_10} Table has FK")
                    logging.info(f"FK is {fk_col_dict}")
                    # fk_list=[fk_col_dict[f'{prev_table_main_dependent}.{prev_return_param_dependent}'],fk_col_dict[[f'{prev_table_main}.{prev_return_param}']]]
                    logging.info(f"{prev_table_main_dependent}{prev_return_param_dependent} {fk_col_dict[f'{prev_table_main_dependent}.{prev_return_param_dependent}']}")
                    logging.info(f"{prev_table_main}.{prev_return_param} {fk_col_dict[f'{prev_table_main}.{prev_return_param}']}")
                    fk_list=[fk_col_dict[f'{prev_table_main_dependent}.{prev_return_param_dependent}'],fk_col_dict[f'{prev_table_main}.{prev_return_param}']]
                    logging.info(f"fk_list={fk_list}")
                    id_20=tuple(prev_df_dependent.get('id_20').to_list())
                    logging.info(f"Id 20 is {id_20}")
                    fk_prev_table=f'{prev_table_main_dependent}{prev_return_param_dependent}'

                    if len(id_20)==1:

                        select_fk_from_10=f"select {prev_return_param_dependent},BulkChangeId,id_20 from {prev_table_full_dependent} where id_20 = {id_20[0]} and BulkChangeId = {bulk_change_id}"
                        logging.info(f"select query is {select_fk_from_10}")
                    else:
                        select_fk_from_10=f"select {prev_return_param_dependent} as {fk_prev_table},BulkChangeId,id_20 from {prev_table_full_dependent} where id_20 in {id_20} and BulkChangeId = {bulk_change_id}"
                        logging.info(f"select query is {select_fk_from_10}")
                    fk_from_10=self.execute_query(mssql_conn,select_fk_from_10)
                    fk_from_10=fk_from_10.to_dict(orient='records')

                    logging.info(f"fk_from_10 is {fk_from_10}")

                    fk_replace_data=fk_from_10

                    logging.info(f"fk_replace_data is {fk_replace_data}")
                    # print(fk_replace_data)
                    fk_replace_data_df=pd.DataFrame(fk_replace_data)
                    logging.info(f"fk_replace_data_df is {fk_replace_data_df}")

                    # Ensure 'id_20' is the index in both DataFrames
                    fk_replace_data_df = fk_replace_data_df.set_index('id_20')
                    df = df.set_index('id_20', drop=False)  # Keep 'id_20' as a column in `df`

                    # Update `df` with values from `fk_replace_data_df` where 'id_20' matches
                    df.update(fk_replace_data_df)

                    # Reset the index if needed
                    df.reset_index(drop=True, inplace=True)

                    float_cols = df.select_dtypes(include=['float']).columns  # Select columns with float data type
                    # Check if there are any float columns
                    if not float_cols.empty:
                        # Convert float columns to integers
                        df[float_cols] = df[float_cols].apply(lambda x: pd.to_numeric(x, errors='coerce')).astype('Int64')
                        logging.info("Converted float columns to integers.")
                    else:
                        logging.info("No float columns found. Skipping conversion step.")# Convert float columns to integers


                    # Display the updated DataFrame
                    logging.info(f"DF thats going to be inserted is") #{df.to_dict(orient='records')}
                    # df.update(fk_replace_data_df.set_index('id_20'))

                    df3=self.insert_dataframe_to_mssql_4(df,table_name_10,mssql_conn)

            logging.info(
                f"Data insertion time: {time.time() - insert_start:.4f} seconds"
            )

            if transfer_name in ("bulk_change","bulk_change_mobility" ,"bulk_change_mobility_spectrotel", "bulk_change_spectrotel",
                                "bulk_change_mobility_apitesttenant", "bulk_change_apitesttenant",
                                "bulk_change_mobility_altaworx_go_tech", "bulk_change_altaworx_go_tech",
                                "bulk_change_m2m_bulk_update","bulk_change_mobility_bulk_update"):

                total_time = time.time() - start_time
                logging.info(f"Total execution time: {total_time:.4f} seconds")
                return bulk_change_id if bulk_change_id else None

        except Exception as e:
            logging.error(f"Error while saving 2.0 data in 1.0 : {e}")
            logging.info(f"Going to execute")
            error_msg=f'error in bulk_save_data_10 {e}'
            update_data_dict = {"progress": "Error in Sync", "error_msg": error_msg}
            ue = self.update_table(
                    postgres_conn1,
                    "sim_management_bulk_change",
                    update_data_dict,
                    {"id": id_20},
                )

    def get_parent_by_subtenant(self,subtenant_name, tenant_list):
        for tenant in tenant_list:
            for sub in tenant.get("sub_tenants", []):
                if sub.get("tenant_name") == subtenant_name:
                    return tenant.get("parent_tenant_name")
        return None

    def function_to_check_sub_tenant_or_parent_name(self, postgres_conn, tenant_name):
        try:
            # SQL query to check tenant information
            query = """
                SELECT id,tenant_name, parent_tenant_id, db_name
                FROM public.tenant
                WHERE tenant_name = %s
                ORDER BY id DESC
                LIMIT 1;
            """

            # Execute the query with the tenant_id
            cursor = postgres_conn.cursor()
            cursor.execute(query, (tenant_name,))
            result = cursor.fetchone()

            # Check if the result exists
            if result:
                tenant_id, tenant_name, parent_tenant_id, db_name = result

                # Determine the flags based on parent_tenant_id
                if parent_tenant_id is not None:
                    parent_query = """
                    SELECT tenant_name
                    FROM public.tenant
                    WHERE id = %s
                    LIMIT 1;
                    """
                    cursor.execute(parent_query, (parent_tenant_id,))
                    parent_result = cursor.fetchone()
                    sub_tenant_name=tenant_name

                    if parent_result:
                        tenant_name = parent_result[0]  # Overwrite with parent tenant name

                else:
                    parent_tenant_id=tenant_id
                    tenant_id=None

                # parent_tenant_flag = True if parent_tenant_id is None else False
                # sub_tenant_flag = not parent_tenant_flag
                return tenant_name,parent_tenant_id,tenant_id,sub_tenant_name

            else:
                # If no result is found, raise an exception
                raise ValueError(f"No tenant found with tenant_id {tenant_name}")
        except Exception as e:
        # Handle any errors that may occur
            logging.info(f"Error occurred: {e}")
            return None, None, None  # Return None if there's an error


    def save_data_to_10(
        self, transfer_name, postgres_data, update_flag=False, delete_flag=False, tenant_name=None
    ):
        try:
            logging.info(f"STARTING {transfer_name}")
            logging.info(f"postgres_data is {postgres_data}")

            sub_tenants_json=self.tenant_load_json()
            #parent_tenant_name=self.get_parent_by_subtenant(tenant_name,sub_tenants_json)
            #if parent_tenant_name:
                #tenant_name=parent_tenant_name
            # common_utils_db=os.getenv("COMMON_UTILS_DB_NAME")
            # comm_postgres_con= self.create_connection(
            #     db_type, hostname,common_utils_db, user, password, port
            # )
            # if tenant_name:
            #     tenant_name,parent_tenant_id,tenant_id=self.function_to_check_sub_tenant_or_parent_name(comm_postgres_con,tenant_name)

            logging.info(f"save_data_10 tenant name is {tenant_name}")

            if transfer_name == "bulk_change":
                data_list = postgres_data["sim_management_bulk_change"]
                service_provider_id = data_list[0]["service_provider_id"]
                logging.info(f"### save_data_to_10 service_provider_id is {service_provider_id}")
                json_data = self.load_json()
                telegence_ids = self.get_provider_ids(json_data, tenant_name, ["Telegence"])
                logging.info(f"### save_data_to_10 telegence_ids is {telegence_ids}")

                if tenant_name.lower() in ('altaworx_test','altaworx'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility"
                    else:
                        transfer_name = "bulk_change"

                elif tenant_name.lower() == 'spectrotel':
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_spectrotel"
                    else:
                        transfer_name = "bulk_change_spectrotel"

                elif tenant_name in ('altaworx_go_tech','Altaworx - Go Tech'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_altaworx_go_tech"
                    else:
                        transfer_name = "bulk_change_altaworx_go_tech"

                elif tenant_name.lower() in ('apitesttenant'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_apitesttenant"
                    else:
                        transfer_name = "bulk_change_apitesttenant"
                else:
                    logging.info("Tenant not found in save_data_20_from_10")
                #     raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")
                # if str(service_provider_id) in ["6", "20"]:
                #     transfer_name = "bulk_change_mobility"
                # else:
                #     transfer_name = "bulk_change"
            if transfer_name.startswith("customer_rate_plan"):
                json_data = self.load_json()
                telegence_ids = self.get_provider_ids(json_data, tenant_name, ["Telegence"])
            print(f"SAVE DATA TO 10 Starting")
            logging.info(f"STARTING TRANSFER {transfer_name}")
            # establishing postgres connection
            start_time = time.time()
            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            mapping_table = os.getenv("MAPPING_TABLE")
            logging.info(f"postgres_conn to the database of : {db_name}")
            postgres_conn_start = time.time()
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(f"postgres_conn to check the: {postgres_conn}")
            logging.info(
                f"Postgres connection time: {time.time() - postgres_conn_start:.4f} seconds"
            )
            print(
                f"Postgres connection time: {time.time() - postgres_conn_start:.4f} seconds"
            )
            ##getting all the details for a particular transfer
            query_start = time.time()
            mapping_details_query = f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_name_10,db_config from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)
            print(f"Query execution time: {time.time() - query_start:.4f} seconds")
            logging.info(
                f"Query execution time: {time.time() - query_start:.4f} seconds"
            )

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get(
                "table_mapping_10_to_20", {}
            )  # 1.0 to 2.0 table mappings dict
            mssql_config = mapping_details.get("db_config", {})
            db_name_10 = mapping_details.get("db_name_10", {})
            if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                print("no mappings present for the configurations so returning the function")
                return True
            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            if transfer_name.startswith("customer_rate_plan"):
                service_provider_id = postgres_data["customerrateplan"][0][
                    "service_provider_id"
                ]
                #if service_provider_id != 20:
                if int(service_provider_id) not in telegence_ids:
                    # Remove 'automation_rule' key if present
                    logging.info(f"Removing 'automation_rule' from tables_dict")
                    logging.info(f"serviceprovider id in customerrateplan is not  a telegence id")
                    if "automation_rule" in tables_dict:
                        del tables_dict["automation_rule"]

                    # Remove 'CustomerRatePlan_JasperCarrierRatePlan' from the 'customerrateplan' list if present
                    if "customerrateplan" in tables_dict:
                        tables_dict["customerrateplan"] = [
                            item
                            for item in tables_dict["customerrateplan"]
                            if item != "CustomerRatePlan_JasperCarrierRatePlan"
                        ]
                else:
                    logging.info("serviceprovider id in customerrateplan is a telegence id")
                    logging.info("keeping the automation_rule in tables_dict")
                    table_name_arcr = "AutomationRule_CustomerRatePlan"
                    id_10 = postgres_data["customerrateplan"][0]["id"]
                    self.delete_data_from_10(
                            transfer_name, postgres_data, id_10, table_name_arcr,ssms_db_name,mssql_conn
                        )
                    table_name_cjrp="CustomerRatePlan_JasperCarrierRatePlan"
                    logging.info(f"removing the the previous id in {table_name_cjrp}")
                    self.delete_data_from_10(
                            transfer_name, postgres_data, id_10, table_name_cjrp,ssms_db_name,mssql_conn
                        )

            db_name_20 = mapping_details.get("db_name_20", {})
            print(f"db_name_20 is {db_name_20}")
            col_mappings = mapping_details.get(
                "col_mapping_10_to_20", {}
            )  # 1.0 to 2.0 column mappings
            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})  # foreign key columns
            db_config = mapping_details.get("db_config", {})  # ssms db config details
            mssql_config = mapping_details.get("db_config", {})
            db_name_10 = mapping_details.get("db_name_10", {})
            print(f"@@@@@@@@@@@@@@@@@@  mapping_details {mapping_details}")
            table_name_20 = mapping_details.get("table_mapping_10_to_20").keys()
            table_name_20 = ", ".join(str(key) for key in table_name_20)
            print(f"table_name_20 is {table_name_20}")

            # from_host=db_config['hostname']
            # from_port=db_config['port']
            # from_user=db_config['user']
            # from_pwd=db_config['password']
            # from_db_type=db_config['from_db_type']
            # from_driver=os.getenv('FROM_DB_DRIVER')
            # ssms_db_name=os.getenv('FROM_DB_NAME')

            # get the data to insert dict for ssms according to mappings
            mapping_start = time.time()
            print(f"postgres_data---------{postgres_data}")
            print(f"col_mappings-----------{col_mappings}")
            hostname = os.getenv("LOCAL_DB_HOST")
            port = os.getenv("LOCAL_DB_PORT")
            db_name = db_name_20
            user = os.getenv("LOCAL_DB_USER")
            password = os.getenv("LOCAL_DB_PASSWORD")
            db_type = os.getenv("LOCAL_DB_TYPE")
            from_driver = os.getenv("LOCAL_DB_DRIVER")
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            '''# if transfer_name=='customer_rate_plan' and update_flag is True:
            #     update_data=postgres_data['customerrateplan'][0]
            #     id_20=update_data['id']
            #     print(f"id_10 data is {id_20}")
            #     id_10=f"select id_10 from customerrateplan where id='{id_20}'"
            #     result=self.execute_query(postgres_conn1,id_10)
            #     id_10=result['id_10'][0]
            #     print(f"id_10 is {id_10}")
            #     update_data['id_10']=id_10
            #     postgres_data_20={'customerrateplan':[update_data]}
            #     total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data_20)
            # elif transfer_name=='customer_rate_plan' and delete_flag is True:
            #     update_data=postgres_data['customerrateplan'][0]
            #     id_20=update_data['id']
            #     print(f"id_10 data is {id_20}")
            #     id_10=f"select id_10 from customerrateplan where id='{id_20}'"
            #     result=self.execute_query(postgres_conn1,id_10)
            #     id_10=result['id_10'][0]
            #     print(f"id_10 is {id_10}")
            #     delete_data=self.delete_data_from_10(transfer_name,postgres_data,id_10)
            #     return True
            # else:
            #     total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data)
            # # total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data)
            # making mssql_connection'''
            '''(
                from_host,
                from_port,
                ssms_db_name,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()'''
            '''if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                logging.info("no mappings present for the configurations so returning the function")
                return True
            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )'''
            print(f"mssql_conn {mssql_conn}")
            # logging.info(f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds")

            postgres_data_copy = copy.deepcopy(postgres_data)
            logging.info(f"postgres_data_20 before handling data {postgres_data_copy}")
            '''if delete_flag is True and update_flag is False:
                print(f"In this ond {delete_flag} and {update_flag}")
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                update_data["id_10"] = id_10
                logging.info(f"id_10 is {id_10}")
                table_name_10 = tables_dict[table_name_20][0]
                logging.info(f"Table Name 1.0 is {table_name_10}")
                delete_data = self.delete_data_from_10(
                    transfer_name, postgres_data, id_10, table_name_10
                )
                return True

            elif update_flag is True and delete_flag is False:
                print(f"update flag {update_flag} and delete flag {delete_flag}")
                if transfer_name.startswith("customer_rate_plan"):
                    table_name_20 = table_name_20.split(",")[-1].strip()
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                logging.info(f"id_10 is {id_10}")
                update_data["id_10"] = id_10
                postgres_data_20 = {table_name_20: [update_data]}

                # total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data_20)
                if transfer_name.startswith("customer_rate_plan"):
                    service_provider_id = postgres_data["customerrateplan"][0][
                        "service_provider_id"
                    ]
                    if service_provider_id == 20:
                        # Delete the records in [AutomationRule_CustomerRatePlan](1.0)
                        table_name_arcr = "AutomationRule_CustomerRatePlan"
                        id_10 = int(id_10)
                        self.delete_data_from_10(
                            transfer_name, postgres_data, id_10, table_name_arcr
                        )
                        update_data_arcr = postgres_data_copy["automation_rule"]
                        for item in update_data_arcr:
                            item["id_10"] = int(id_10)
                        postgres_data_20["automation_rule"] = update_data_arcr
                        logging.info(
                            f"postgres_data_20 before map cols is {postgres_data_20}"
                        )
                        total_insert_dict = self.map_cols(
                            tables_dict, col_mappings, postgres_data_20
                        )

                        # Update the records in [CustomerRatePlan_JasperCarrierRatePlan] table (1.0)
                        table_name_crjcr = "CustomerRatePlan_JasperCarrierRatePlan"
                        updated_soccode_data = total_insert_dict[table_name_crjcr][0]
                        updated_soccode_data.pop("CustomerRatePlanId")
                        logging.info(f"updated_soccode_data {updated_soccode_data}")
                        total_insert_dict.pop(table_name_crjcr)
                        id_10 = int(id_10)
                        self.update_table(
                            mssql_conn,
                            table_name_crjcr,
                            updated_soccode_data,
                            {"CustomerRatePlanId": id_10},
                        )
                    else:
                        logging.info(
                            f"postgres_data_20 after handling data before map cols is {postgres_data_20}"
                        )
                        total_insert_dict = self.map_cols(
                            tables_dict, col_mappings, postgres_data_20
                        )
                else:
                    logging.info(
                        f"postgres_data_20 before map cols is {postgres_data_20}"
                    )
                    total_insert_dict = self.map_cols(
                        tables_dict, col_mappings, postgres_data_20
                    )
            else:
                logging.info(f"tables_dict {tables_dict}")
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data
                )'''
            logging.info(f"tables_dict {tables_dict}")
            total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data
                )

            logging.info(f"total insert dict is {total_insert_dict}")

            # print(f'total_insert_dict------------{total_insert_dict}')
            # logging.info(f"Data mapping time: {time.time() - mapping_start:.4f} seconds")

            return_ids = []
            fk_track_dict = {}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                print(f"Begining insertion for {table_name_10}")
                # if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"

                if return_params_10:
                    # return_params_10 = json.loads(return_params_10)
                    print(f"Return Params are {return_params_10}")

                    return_col = return_params_10.get(
                        table_name_10
                    )  # get the col whose value should be returned for this table
                    fk_col_dict = fk_cols_10.get(
                        table_name_10, {}
                    )  # get the fk_col dict for this table
                    print(f"return_col are {return_col}")
                else:
                    return_col = None
                    fk_col_dict = None

                print(f"return_col {return_col}")
                print(f"fk_col_dict {fk_col_dict}")
                # logging.info("there is no return_col")
                # logging.info("there is no fk_cols_10")

                if not return_col and not fk_col_dict:
                    print(
                        "This part is to handle update tables don't have any foreign key columnc"
                    )
                    # print(full_from_table)
                    # print(total_insert_dict[table_name_10])
                    # print(table_name_10)
                    # print(mssql_conn)
                    # if transfer_name=='customer_rate_plan' and update_flag is False:
                    #     return_col='ID'
                    #     return_val, return_fk_name=self.insert_data_to_db(full_from_table,total_insert_dict[table_name_10],mssql_conn,return_col,table_name_10)
                    #     print(f"return val is {return_val} return fk name is {return_fk_name}")
                    #     update_postgres_data=postgres_data['customerrateplan'][0]
                    #     update_postgres_data['id_10']=return_val
                    #     update_postgres_id=update_postgres_data['id']
                    #     update_postgres_data.pop('id')
                    #     print(f"update_postgres_data is {update_postgres_data}")
                    #     self.update_table(postgres_conn1,'customerrateplan',update_postgres_data,{'id':update_postgres_id})
                    # else:
                    #     update_value,update_condtion=self.insert_data_to_db(full_from_table,total_insert_dict[table_name_10],mssql_conn,None,table_name_10)
                    #     print(f"update value is {update_value} update condition is {update_condtion}")
                    #     print(postgres_conn)
                    #     if transfer_name=='customer_rate_plan':
                    #         update_data_20=postgres_data['customerrateplan'][0]
                    #         print(f"update data 20 is {update_data_20}")
                    #         id_10=int(update_value['id'])
                    #         update_data_20['id_10']=id_10
                    #         id_20=int(update_data_20['id'])
                    #         self.update_table(postgres_conn1,table_name_20,update_data_20,{'id':id_20})

                    logging.info(
                        "This part is to handle update tables don't have any foreign key columnc"
                    )
                    if update_flag is False:

                        self.insert_data_to_db(
                            full_from_table,
                            total_insert_dict[table_name_10],
                            mssql_conn,
                            return_col,
                            table_name_10,
                        )
                        logging.info(
                            f"customer rate plans insertion got successful {table_name_10}"
                        )

                    else:
                        self.insert_data_to_db(
                            full_from_table,
                            total_insert_dict[table_name_10],
                            mssql_conn,
                            None,
                            table_name_10,
                        )
                        logging.info(
                            f"customer rate plans insertion got successful {table_name_10}"
                        )


                # Condition 1: for Single Main table
                elif not return_col and table_name_10 not in fk_cols_10:
                    # Condition: where the table does not return any fk (single tables which does not have any dependent tables)
                    print(f"#### Single Table: {table_name_10}")
                    return_id = self.insert_data_to_db(
                        full_from_table,
                        total_insert_dict[table_name_10],
                        mssql_conn,
                        None,
                        table_name_10,
                    )

                # condition1: for main tables--these only return an fk
                elif return_col and table_name_10 not in fk_cols_10:
                    print(f"##### Main Table: {table_name_10}")
                    logging.info(f"##### Main Table: {table_name_10}")
                    return_id, return_fk_col = self.insert_data_to_db(
                        full_from_table,
                        total_insert_dict[table_name_10],
                        mssql_conn,
                        return_col,
                        table_name_10,
                    )

                    for table_2, tables_1 in tables_dict.items():
                        if table_name_10 in tables_1:
                            break
                    logging.info(f"Mapping tabel in 2.0 is {table_2}")

                    if table_2:
                        update_data_20 = postgres_data[table_2][0]

                        logging.info(f"update data 20 is {update_data_20}")
                        logging.info(
                            f"return_id data after inserting into 1.0 table: {return_id}"
                        )

                        update_data_20_int = update_data_20
                        if update_flag:
                            if "id" in return_id:
                                return_id = return_id["id"]
                        logging.info(f"id received from 1.0 is: {return_id}")
                        update_data_20["id_10"] = int(return_id)

                        if transfer_name.startswith("customer_rate_plan"):
                            if "soc_code_id" in update_data_20:
                                update_data_20.pop("soc_code_id")
                            id_20 = int(update_data_20["id"])
                            # if 'automation_rule_id' in  update_data_20:
                            #     update_data_20.pop('automation_rule_id')
                            self.update_table(
                                postgres_conn1, table_2, update_data_20, {"id": id_20}
                            )
                        else:
                            self.update_table(
                                postgres_conn1,
                                table_2,
                                update_data_20,
                                update_data_20_int,
                            )

                    return_ids.append(
                        return_id
                    )  # adding the return col value to main return list
                    if "id" in return_fk_col:
                        return_fk_col = return_fk_col["id"]
                    fk_track_dict[str(return_fk_col)] = (
                        return_id  # adding the return fk_col and return fk col value to an fk_tract_dict
                    )

                # condition2: Tables which have an fk column and also return a col as fk
                elif return_col and table_name_10 in fk_cols_10:

                    print(f"###### {table_name_10} Table has FK and returns col as FK")
                    logging.info(
                        f"###### {table_name_10} Table has FK and returns col as FK"
                    )
                    for (
                        key,
                        val,
                    ) in (
                        fk_track_dict.items()
                    ):  # if any fkey present in fk_track_dict present in fk_cols_dict from db then modify cols
                        modify_col = fk_col_dict.get(
                            key, None
                        )  # get the name of the col that we need to modify(fk_col_name)
                        if modify_col:
                            # print(f"modify col got is {modify_col} new val is {val}")
                            for row_item in data_list:
                                row_item[modify_col] = (
                                    val  # updating the fk_col value in data dict which is to be inserted in db
                                )

                    if transfer_name not in ("bulk_change_mobility","bulk_change_mobility_spectrotel","bulk_change_mobility_altaworx_go_tech"):
                        insert_id, fk_col = self.insert_data_to_db(
                            full_from_table,
                            data_list,
                            mssql_conn,
                            return_col,
                            table_name_10,
                        )
                        fk_track_dict[fk_col] = insert_id
                    else:
                        for row_item in data_list:
                            insert_id, fk_col = self.insert_data_to_db(
                                full_from_table,
                                [row_item],
                                mssql_conn,
                                return_col,
                                table_name_10,
                            )
                            if fk_col not in fk_track_dict:
                                fk_track_dict[fk_col] = []
                            fk_track_dict[fk_col].append(insert_id)

                # condition3: where tables don't return any fk but contain fk col that needs to be updated
                elif (
                    table_name_10 in fk_cols_10
                    and table_name_10 not in return_params_10
                ):
                    print(f"###### {table_name_10} Table has FK")
                    logging.info(f"###### {table_name_10} Table has FK")
                    for key, val in fk_track_dict.items():
                        modify_col = fk_col_dict.get(key, None)
                        if modify_col:
                            if isinstance(fk_track_dict[key], list):
                                for i in range(0, len(data_list)):
                                    data_list[i][modify_col] = val[i]
                            else:
                                for row_item in data_list:
                                    row_item[modify_col] = val

                    insert = self.insert_data_to_db(
                        full_from_table,
                        data_list,
                        mssql_conn,
                        return_col,
                        table_name_10,
                    )
            logging.info(
                f"Data insertion time: {time.time() - insert_start:.4f} seconds"
            )

            if (
                transfer_name == "bulk_change"
                or transfer_name == "bulk_change_mobility" or transfer_name == "bulk_change_mobility_spectrotel" or transfer_name == "bulk_change_spectrotel"
                or transfer_name == "bulk_change_mobility_apitesttenant" or transfer_name == "bulk_change_apitesttenant"
                or transfer_name == "bulk_change_mobility_altaworx_go_tech" or transfer_name == "bulk_change_altaworx_go_tech"
            ):
                total_time = time.time() - start_time
                logging.info(f"Total execution time: {total_time:.4f} seconds")
                return return_ids[0] if return_ids else None

        except Exception as e:
            logging.error(f"Error while saving 2.0 data in 1.0 : {e}")

    '''def save_data_to_10_smi(self, transfer_name, postgres_data):
        try:
            # establishing postgres connection
            start_time = time.time()
            if transfer_name == "sim_managment_inventory":
                pg = {}
                data_list = postgres_data["sim_management_inventory"]
                service_provider_id = data_list[0]["service_provider_id"]
                print(f"11111 {service_provider_id}")
                if str(service_provider_id) in ["6", "20"]:
                    transfer_name = "sim_managment_inventory_mobility"
                else:
                    transfer_name = "sim_managment_inventory_m2m"

            logging.info(f"STARTING {transfer_name}")

            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn_start = time.time()
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            # print(f"Postgres connection time: {time.time() - postgres_conn_start:.4f} seconds")
            ##getting all the details for a particular transfer
            query_start = time.time()
            mapping_details_query = f"select table_mapping_10_to_20,col_mapping_10_to_20,return_params_10,fk_cols_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)
            # print(f"Query execution time: {time.time() - query_start:.4f} seconds")

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get("table_mapping_10_to_20", {})
            logging.info(f"SMI- table {tables_dict}")  # 1.0 to 2.0 table mappings dict
            col_mappings = mapping_details.get("col_mapping_10_to_20", {})
            logging.info(f"SMI@@@@@@@@@@ {col_mappings}")  # 1.0 to 2.0 column mappings
            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})  # foreign key columns
            db_config = mapping_details.get("db_config", {})  # ssms db config details

            # from_host=db_config['hostname']
            # from_port=db_config['port']
            # from_user=db_config['user']
            # from_pwd=db_config['password']
            # from_db_type=db_config['from_db_type']
            # from_driver=os.getenv('FROM_DB_DRIVER')
            # ssms_db_name=os.getenv('FROM_DB_NAME')

            # get the data to insert dict for ssms according to mappings
            mapping_start = time.time()

            logging.info(f"postgress_data type {type(postgres_data)} {postgres_data}")
            total_insert_dict = self.map_cols(tables_dict, col_mappings, postgres_data)

            # print(f"Data mapping time: {time.time() - mapping_start:.4f} seconds")

            # making mssql_connection

            (
                from_host,
                from_port,
                ssms_db_name,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()
            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn {mssql_conn}")
            # print(f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds")
            logging.info(f"total insert dict {total_insert_dict}")

            return_ids = []

            fk_track_dict = {}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                # if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"

                if return_params_10:
                    print(f"Heree 2111 {return_params_10}")
                    return_col = return_params_10.get(
                        table_name_10, None
                    )  # get the col whose value should be returned for this table
                    fk_col_dict = fk_cols_10.get(
                        table_name_10, {}
                    )  # get the fk_col dict for this table
                else:
                    return_col = None
                    fk_col_dict = None
                # return_col = return_params_10.get(table_name_10,None) #get the col whose value should be returned for this table
                # fk_col_dict = fk_cols_10.get(table_name_10, {}) #get the fk_col dict for this table

                if not return_col:
                    # Condition: where the table does not return any fk (single tables which does not have any dependent tables)
                    logging.info(f"#### Single Table: {table_name_10}")
                    return_id = self.insert_data_to_db(
                        full_from_table,
                        total_insert_dict[table_name_10],
                        mssql_conn,
                        None,
                        table_name_10,
                    )

                # condition1: for main tables--these only return an fk
                elif return_col and table_name_10 not in fk_cols_10:
                    logging.info(f"##### Main Table: {table_name_10}")
                    return_id, return_fk_col = self.insert_data_to_db(
                        full_from_table,
                        total_insert_dict[table_name_10],
                        mssql_conn,
                        return_col,
                        table_name_10,
                    )
                    return_ids.append(
                        return_id
                    )  # adding the return col value to main return list
                    fk_track_dict[return_fk_col] = (
                        return_id  # adding the return fk_col and return fk col value to an fk_tract_dict
                    )

                # condition2: Tables which have an fk column and also return a col as fk
                elif return_col and table_name_10 in fk_cols_10:
                    logging.info(
                        f"###### {table_name_10} Table has FK and returns col as FK"
                    )
                    for (
                        key,
                        val,
                    ) in (
                        fk_track_dict.items()
                    ):  # if any fkey present in fk_track_dict present in fk_cols_dict from db then modify cols
                        modify_col = fk_col_dict.get(
                            key, None
                        )  # get the name of the col that we need to modify(fk_col_name)
                        if modify_col:
                            # print(f"modify col got is {modify_col} new val is {val}")
                            for row_item in data_list:
                                row_item[modify_col] = (
                                    val  # updating the fk_col value in data dict which is to be inserted in db
                                )

                    insert_id, fk_col = self.insert_data_to_db(
                        full_from_table,
                        data_list,
                        mssql_conn,
                        return_col,
                        table_name_10,
                    )
                    fk_track_dict[fk_col] = insert_id

                # condition3: where tables don't return any fk but contain fk col that needs to be updated
                elif (
                    table_name_10 in fk_cols_10
                    and table_name_10 not in return_params_10
                ):
                    logging.info(f"###### {table_name_10} Table has FK")
                    for key, val in fk_track_dict.items():
                        modify_col = fk_col_dict.get(key, None)
                        if modify_col:
                            for row_item in data_list:
                                row_item[modify_col] = val

                    insert = self.insert_data_to_db(
                        full_from_table,
                        data_list,
                        mssql_conn,
                        return_col,
                        table_name_10,
                    )
            logging.info(
                f"Data insertion time: {time.time() - insert_start:.4f} seconds"
            )

            if transfer_name == "bulk_change":
                total_time = time.time() - start_time
                logging.info(f"Total execution time: {total_time:.4f} seconds")
                return return_ids[0] if return_ids else None

        except Exception as e:
            print(f"Error while saving 2.0 data in 1.0 : {e}")'''

    def replace_tenantid_with_fstring(self,query,tenant_id):
        # Replace any instance like tenantid=1 or tenantid = 1 with tenantid={tenant_id}
        updated_query = re.sub(r"\btenantid\s*=\s*\d+", f"tenantid in {tenant_id}", query, flags=re.IGNORECASE)
        return updated_query

    def get_10_data(
        self,
        transfer_name,
        mssql_conn,
        id_10,
        details_list,
        log_status_check_flag,
        main_flag=None,
        main_result_dict=None,
        tenant_id_str=None
    ):
        try:
            dependent_dict = {}
            where_val_list = []
            stop_flag = False
            skip_table = False
            if main_flag:
                main_result_dict = {}
                status_results_dict = {}
                # logging.info(f"DETAILS LIST IS {details_list}")
                for dict_item in details_list:
                    where_col = dict_item["where_col"]
                    table_10_key = dict_item["table_10"]
                    logging.info(f"@@@@@@@@ table {table_10_key}")
                    select_query = dict_item["select_query"]
                    logging.info(f"CHCK Select query is {select_query}")
                    select_query_p = select_query.replace("?", "%s")
                    logging.info(
                        f"select query is {select_query_p} 1.0 id is {id_10}",
                    )
                    logging.info(
                        f"Processing for table {table_10_key} with id_10: {id_10}"
                    )

                    if "?" in select_query.lower() and where_col == "id_10":
                        params = (id_10,)
                        retries = 10  # Maximum retries
                        delay = 5
                        result_df = self.execute_query(
                            mssql_conn, select_query_p, params=params
                        )
                        logging.info(f"get_10_data : Result df is {result_df}")
                        if transfer_name in ["bulk_change", "bulk_change_mobility", "bulk_change_spectrotel","bulk_change_mobility_spectrotel","bulk_change_bulk_update_mobility","bulk_change_m2m_bulk_update","bulk_change_mobility_apitesttenant","bulk_change_apitesttenant","bulk_change_mobility_altaworx_go_tech","bulk_change_altaworx_go_tech"]:
                            logging.info(f"get_10_data------------{id_10}")
                            if table_10_key == "DeviceBulkChange":
                                status = result_df.get(
                                    "status", result_df.get("Status", [None])
                                )[
                                    0
                                ]  # Get status safely
                                logging.info(
                                    f"get_10_data:{id_10} table is {table_10_key} abd status got us {status}"
                                )
                                status_results_dict[table_10_key] = [status]
                            else:
                                statuses = result_df.get(
                                    "status", result_df.get("Status", [])
                                )
                                if not isinstance(
                                    statuses, list
                                ):  # Convert to a list if it's a pandas Series
                                    statuses = statuses.tolist()
                                logging.info(
                                    f"get_10_data:::Statuses for {id_10} are {statuses}, type is {type(statuses)}"
                                )
                                status_results_dict[table_10_key] = statuses

                        # Process the result
                        if result_df is not None and not result_df.empty:
                            main_result_dict[table_10_key] = result_df.to_dict(
                                orient="records"
                            )
                        else:
                            logging.error(
                                f"Query failed after retries for {table_10_key}"
                            )

                if log_status_check_flag is True:
                    logging.info(
                        f"Need to get status from log table DeviceBulkchnage log {id_10}"
                    )
                    db_name_10=os.getenv('FROM_DB_NAME')
                    select_query_log = f"select ResponseStatus from {db_name_10}.dbo.DeviceBulkChangeLog where BulkChangeId={id_10}"
                    log_query_exec = self.execute_query(mssql_conn, select_query_log)
                    logging.info(f"Result of log Query is {log_query_exec}")
                    log_statuses = log_query_exec.get(
                        "ResponseStatus", log_query_exec.get("ResponseStatus", [])
                    )
                    if not isinstance(
                        log_statuses, list
                    ):  # Convert to a list if it's a pandas Series
                        log_statuses = log_statuses.tolist()
                    logging.info(
                        f"get_10_data:::log_statuses for {id_10} are {log_statuses}, type is {type(log_statuses)}"
                    )
                    status_results_dict["DeviceBulkChangeLog"] = log_statuses

                logging.info(
                    f"get_10_data:::The result statuses are {id_10} ::::{status_results_dict}"
                )
                combined_statuses = [
                    status
                    for statuses in status_results_dict.values()
                    for status in statuses
                ]
                logging.info(
                    f"get_10_data:::: for id 1.0 {id_10} Total statuses are {combined_statuses}"
                )
                # if ("API_FAILED" in combined_statuses or "ERROR" in combined_statuses):
                #     keep_trying = False
                #     logging.info(
                #         f"Error response  came in combined_statuses and flag is {keep_trying} ---------\n:::{main_result_dict}"
                #     )
                #     return main_result_dict, keep_trying

                if (
                    "NEW" in combined_statuses
                    or "PROCESSING" in combined_statuses
                    or "PENDING" in combined_statuses
                ):
                    keep_trying = True
                else:
                    keep_trying = False

                logging.info(
                    f"Final main result dict got is and flag is {keep_trying} ---------\n:::"
                )#{main_result_dict}
                return main_result_dict, keep_trying

            else:
                # print(f"In dependent dict")
                logging.info(
                    f"1111################# Dependent Start Main result dict"
                )# {main_result_dict}
                dependent_dict = {}
                where_val_list = []
                result_df = None
                for dict_item in details_list:
                    table_10_key = dict_item["table_10"]
                    logging.info(f"22  Dependent Table {table_10_key}")
                    where_col = dict_item["where_col"]
                    logging.info(f"Dependent where col {where_col}")
                    if where_col == "id_10":
                        select_query = dict_item["select_query"]
                        # print(f"Before :::Select query is {select_query}")
                        logging.info(
                            f"{table_10_key}--Dependent table but where col is id_10 {id_10}"
                        )
                        select_query_id_1 = select_query.replace("?", "%s")
                        # print(f"select query is {select_query_id_1} 1.0 id is {id_10}", )
                        params = (id_10,)
                        result_df = self.execute_query(
                            mssql_conn, select_query_id_1, params=params
                        )
                        logging.info(f"@##$@#$@#@#@# result {result_df}")

                    else:
                        logging.info(f"In else of dependent dict")
                        select_query = dict_item["select_query"]
                        if tenant_id_str:
                            select_query=self.replace_tenantid_with_fstring(select_query,tenant_id_str)

                        logging.info(f"Before :::Select query is {select_query}")
                        where_table_name, where_col_name = where_col.split(".")
                        logging.info(f"@@@@ where {where_table_name,where_col_name}")
                        # where_table_name=where_split[0]
                        # where_col_name=where_split[1]

                        where_vals = [
                            item[where_col_name]
                            for item in main_result_dict.get(where_table_name, [])
                        ]
                        where_val_list.extend(where_vals)
                        logging.info(f"{table_10_key}-where val list {where_val_list}")

                        if where_vals:
                            where_tuple = tuple(where_vals)
                            logging.info(f"#### where tuple {where_tuple}")
                            if len(where_tuple) == 1:
                                where_tuple_str = str(where_tuple[0])
                                logging.info(
                                    f"where tuple is 1 value {where_tuple_str} type is {type(where_tuple_str)} `('{where_tuple_str}')`"
                                )
                                select_query_p = select_query.replace(
                                    "?", f"('{where_tuple_str}')"
                                )

                            else:
                                # print(f"Tuple len is not 1")
                                # Parameterize query to avoid SQL injection
                                select_query_p = select_query.replace(
                                    "?", str(where_tuple)
                                )
                                logging.info(
                                    f"In else select query is {select_query_p}"
                                )
                            result_df = self.execute_query(mssql_conn, select_query_p)
                            logging.info(f"@##$@#$@#@#@# result {result_df}")

                        else:
                            logging.info(
                                f"No values found for where clause: {where_col}"
                            )

                    if result_df is not None:
                        result_dict = result_df.to_dict(orient="records")
                        dependent_dict[table_10_key] = result_dict
                    else:
                        dependent_dict[table_10_key] = []
                    logging.info(
                        f"@@@@@@@@@@@@@@@@Retruning Final Depedent dict is"
                    )

        except Exception as e:
            logging.info(
                f"Error in Bulk Change get_10_data-Fetching data from 1.0 ---{e}"
            )

        return dependent_dict, where_val_list
    # backing funtion up before bulk insert data
    def get_10_data_bak_5apr25(
        self,
        transfer_name,
        mssql_conn,
        id_10,
        details_list,
        log_status_check_flag,
        main_flag=None,
        main_result_dict=None,
    ):
        try:
            dependent_dict = {}
            where_val_list = []
            stop_flag = False
            skip_table = False
            if main_flag:
                main_result_dict = {}
                status_results_dict = {}
                for dict_item in details_list:
                    where_col = dict_item["where_col"]
                    table_10_key = dict_item["table_10"]
                    logging.info(f"@@@@@@@@ table {table_10_key}")
                    select_query = dict_item["select_query"]
                    logging.info(f"Select query is {select_query}")
                    select_query_p = select_query.replace("?", "%s")
                    logging.info(
                        f"select query is {select_query_p} 1.0 id is {id_10}",
                    )
                    logging.info(
                        f"Processing for table {table_10_key} with id_10: {id_10}"
                    )

                    if "?" in select_query.lower() and where_col == "id_10":
                        params = (id_10,)
                        retries = 10  # Maximum retries
                        delay = 5
                        result_df = self.execute_query(
                            mssql_conn, select_query_p, params=params
                        )
                        logging.info(f"get_10_data : Result df is {result_df}")
                        if transfer_name in ["bulk_change", "bulk_change_mobility", "bulk_change_spectrotel","bulk_change_mobility_spectrotel","bulk_change_bulk_update_mobility","bulk_change_m2m_bulk_update","bulk_change_mobility_apitesttenant","bulk_change_apitesttenant","bulk_change_mobility_altaworx_go_tech","bulk_change_altaworx_go_tech"]:
                            logging.info(f"get_10_data------------{id_10}")
                            if table_10_key == "DeviceBulkChange":
                                status = result_df.get(
                                    "status", result_df.get("Status", [None])
                                )[
                                    0
                                ]  # Get status safely
                                logging.info(
                                    f"get_10_data:{id_10} table is {table_10_key} abd status got us {status}"
                                )
                                status_results_dict[table_10_key] = [status]
                            else:
                                statuses = result_df.get(
                                    "status", result_df.get("Status", [])
                                )
                                if not isinstance(
                                    statuses, list
                                ):  # Convert to a list if it's a pandas Series
                                    statuses = statuses.tolist()
                                logging.info(
                                    f"get_10_data:::Statuses for {id_10} are {statuses}, type is {type(statuses)}"
                                )
                                status_results_dict[table_10_key] = statuses

                        # Process the result
                        if result_df is not None and not result_df.empty:
                            main_result_dict[table_10_key] = result_df.to_dict(
                                orient="records"
                            )
                        else:
                            logging.error(
                                f"Query failed after retries for {table_10_key}"
                            )

                if log_status_check_flag is True:
                    logging.info(
                        f"Need to get status from log table DeviceBulkchnage log {id_10}"
                    )
                    db_name_10=os.getenv('FROM_DB_NAME')
                    select_query_log = f"select ResponseStatus from {db_name_10}.dbo.DeviceBulkChangeLog where BulkChangeId={id_10}"
                    log_query_exec = self.execute_query(mssql_conn, select_query_log)
                    logging.info(f"Result of log Query is {log_query_exec}")
                    log_statuses = log_query_exec.get(
                        "ResponseStatus", log_query_exec.get("ResponseStatus", [])
                    )
                    if not isinstance(
                        log_statuses, list
                    ):  # Convert to a list if it's a pandas Series
                        log_statuses = log_statuses.tolist()
                    logging.info(
                        f"get_10_data:::log_statuses for {id_10} are {log_statuses}, type is {type(log_statuses)}"
                    )
                    status_results_dict["DeviceBulkChangeLog"] = log_statuses

                logging.info(
                    f"get_10_data:::The result statuses are {id_10} ::::{status_results_dict}"
                )
                combined_statuses = [
                    status
                    for statuses in status_results_dict.values()
                    for status in statuses
                ]
                logging.info(
                    f"get_10_data:::: for id 1.0 {id_10} Total statuses are {combined_statuses}"
                )

                if (
                    "NEW" in combined_statuses
                    or "PROCESSING" in combined_statuses
                    or "PENDING" in combined_statuses
                ):
                    keep_trying = True
                else:
                    keep_trying = False

                logging.info(
                    f"Final main result dict got is and flag is {keep_trying} ---------\n:::{main_result_dict}"
                )
                return main_result_dict, keep_trying

            else:
                # print(f"In dependent dict")
                logging.info(
                    f"1111################# Dependent Start Main result dict {main_result_dict}"
                )
                dependent_dict = {}
                where_val_list = []
                result_df = None
                for dict_item in details_list:
                    table_10_key = dict_item["table_10"]
                    logging.info(f"22  Dependent Table {table_10_key}")
                    where_col = dict_item["where_col"]
                    logging.info(f"Dependent where col {where_col}")
                    if where_col == "id_10":
                        select_query = dict_item["select_query"]
                        # print(f"Before :::Select query is {select_query}")
                        logging.info(
                            f"{table_10_key}--Dependent table but where col is id_10 {id_10}"
                        )
                        select_query_id_1 = select_query.replace("?", "%s")
                        # print(f"select query is {select_query_id_1} 1.0 id is {id_10}", )
                        params = (id_10,)
                        result_df = self.execute_query(
                            mssql_conn, select_query_id_1, params=params
                        )
                        logging.info(f"@##$@#$@#@#@# result {result_df}")

                    else:
                        logging.info(f"In else of dependent dict")
                        select_query = dict_item["select_query"]
                        logging.info(f"Before :::Select query is {select_query}")
                        where_table_name, where_col_name = where_col.split(".")
                        logging.info(f"@@@@ where {where_table_name,where_col_name}")
                        # where_table_name=where_split[0]
                        # where_col_name=where_split[1]

                        where_vals = [
                            item[where_col_name]
                            for item in main_result_dict.get(where_table_name, [])
                        ]
                        where_val_list.extend(where_vals)
                        logging.info(f"{table_10_key}-where val list {where_val_list}")

                        if where_vals:
                            where_tuple = tuple(where_vals)
                            logging.info(f"#### where tuple {where_tuple}")
                            if len(where_tuple) == 1:
                                where_tuple_str = str(where_tuple[0])
                                logging.info(
                                    f"where tuple is 1 value {where_tuple_str} type is {type(where_tuple_str)} `('{where_tuple_str}')`"
                                )
                                select_query_p = select_query.replace(
                                    "?", f"('{where_tuple_str}')"
                                )

                            else:
                                # print(f"Tuple len is not 1")
                                # Parameterize query to avoid SQL injection
                                select_query_p = select_query.replace(
                                    "?", str(where_tuple)
                                )
                                logging.info(
                                    f"In else select query is {select_query_p}"
                                )
                            result_df = self.execute_query(mssql_conn, select_query_p)
                            logging.info(f"@##$@#$@#@#@# result {result_df}")

                        else:
                            logging.infos(
                                f"No values found for where clause: {where_col}"
                            )

                    if result_df is not None:
                        result_dict = result_df.to_dict(orient="records")
                        dependent_dict[table_10_key] = result_dict
                    else:
                        dependent_dict[table_10_key] = []
                    logging.info(
                        f"@@@@@@@@@@@@@@@@Retruning Final Depedent dict is {dependent_dict}"
                    )

        except Exception as e:
            logging.info(
                f"Error in Bulk Change get_10_data-Fetching data from 1.0 ---{e}"
            )

        return dependent_dict, where_val_list

    def get_10_data_old(
        self,
        transfer_name,
        mssql_conn,
        id_10,
        details_list,
        main_flag=None,
        main_result_dict=None,
    ):
        try:
            dependent_dict = {}
            where_val_list = []
            stop_flag = False
            skip_table = False
            if main_flag:
                main_result_dict = {}
                for dict_item in details_list:
                    skip_table = False
                    # print(f"Dict item is {dict_item}")
                    where_col = dict_item["where_col"]
                    table_10_key = dict_item["table_10"]
                    logging.info(f"@@@@@@@@ table {table_10_key}")
                    select_query = dict_item["select_query"]
                    logging.info(f"Select query is {select_query}")
                    select_query_p = select_query.replace("?", "%s")
                    logging.info(
                        f"select query is {select_query_p} 1.0 id is {id_10}",
                    )
                    logging.info(
                        f"Processing for table {table_10_key} with id_10: {id_10}"
                    )

                    if "?" in select_query.lower() and where_col == "id_10":
                        # print(f"111111111111111111111")
                        params = (id_10,)
                        retries = 10  # Maximum retries
                        delay = 10  # Delay in seconds between retries
                        for attempt in range(retries):
                            result_df = self.execute_query(
                                mssql_conn, select_query_p, params=params
                            )
                            logging.info(f"#########: Result df is {result_df}")

                            # Handle specific statuses for bulk change transfers
                            if transfer_name in ["bulk_change", "bulk_change_mobility"]:
                                logging.info(
                                    f"#####################################################"
                                )
                                if table_10_key == "DeviceBulkChange":
                                    status = result_df.get(
                                        "status", result_df.get("Status", [None])
                                    )[
                                        0
                                    ]  # Get status safely
                                    logging.info(
                                        f"11111111111111111 table is {table_10_key} abd status got us {status}"
                                    )
                                else:
                                    statuses = result_df.get(
                                        "status", result_df.get("Status", [])
                                    )
                                    logging.info(f"Statuses are {statuses}")

                                if table_10_key == "DeviceBulkChange":
                                    if status in ["NEW"]:
                                        keep_trying = True
                                        logging.info(
                                            f"Skipping table {table_10_key} as it is not ready yet..."
                                        )
                                        break
                                    elif status == "PROCESSING":
                                        keep_trying = True
                                        logging.info(
                                            f"Keep trying flag is {keep_trying}"
                                        )
                                    else:
                                        keep_trying = False
                                        logging.info(
                                            f"Keep trying flag is {keep_trying}"
                                        )
                                    break
                                else:
                                    logging.info(f"Multiple Statses are {statuses}")
                                    # Check if any of the statuses is 'NEW'
                                    if "NEW" in statuses:
                                        keep_trying = True
                                        logging.info(
                                            f"Status is NEW in one or more rows, keeping keep_trying as {keep_trying}"
                                        )
                                        break
                                    else:
                                        keep_trying = False
                                        logging.info(
                                            f"No 'NEW' status found, proceeding with the sync. Keep trying flag is {keep_trying}"
                                        )
                                        break

                            # Exit if valid result is obtained
                            if result_df is not None and not result_df.empty:
                                break

                            logging.info(
                                f"Attempt {attempt + 1}/{retries}: Query returned no results, retrying after {delay} seconds..."
                            )
                            # time.sleep(delay)

                        # Fetch data regardless of status if retries are exhausted
                        if result_df is None or result_df.empty:
                            logging.info(
                                f"Exhausted retries. Fetching data regardless of status (id: {id_10})..."
                            )
                            result_df = self.execute_query(
                                mssql_conn, select_query_p, params=params
                            )

                        # Process the result
                        if result_df is not None and not result_df.empty:
                            main_result_dict[table_10_key] = result_df.to_dict(
                                orient="records"
                            )
                        else:
                            logging.error(
                                f"Query failed after retries for {table_10_key}"
                            )

                        # print(f"Final main result dict got is {main_result_dict}")

                return main_result_dict, keep_trying
            else:
                # print(f"In dependent dict")
                dependent_dict = {}
                where_val_list = []
                result_df = None
                for dict_item in details_list:
                    table_10_key = dict_item["table_10"]
                    logging.info(f"Dependent Table {table_10_key}")
                    where_col = dict_item["where_col"]
                    logging.info(f"Dependent where col {where_col}")
                    if where_col == "id_10":
                        select_query = dict_item["select_query"]
                        # print(f"Before :::Select query is {select_query}")
                        logging.info(
                            f"{table_10_key}--Dependent table but where col is id_10 {id_10}"
                        )
                        select_query_id_1 = select_query.replace("?", "%s")
                        # print(f"select query is {select_query_id_1} 1.0 id is {id_10}", )
                        params = (id_10,)
                        result_df = self.execute_query(
                            mssql_conn, select_query_id_1, params=params
                        )
                        logging.info(f"@##$@#$@#@#@# result {result_df}")

                    else:
                        logging.info(f"In else of dependent dict")
                        select_query = dict_item["select_query"]
                        logging.info(f"Before :::Select query is {select_query}")
                        where_table_name, where_col_name = where_col.split(".")
                        logging.info(f"where {where_table_name,where_col_name}")
                        # where_table_name=where_split[0]
                        # where_col_name=where_split[1]

                        where_vals = [
                            item[where_col_name]
                            for item in main_result_dict.get(where_table_name, [])
                        ]
                        where_val_list.extend(where_vals)
                        logging.info(f"{table_10_key}-where val list {where_val_list}")

                        if where_vals:
                            where_tuple = tuple(where_vals)
                            logging.info(f"where tuple {where_tuple}")
                            if len(where_tuple) == 1:
                                where_tuple_str = str(where_tuple[0])
                                logging.info(
                                    f"where tuple is 1 value {where_tuple_str} type is {type(where_tuple_str)} `('{where_tuple_str}')`"
                                )
                                select_query_p = select_query.replace(
                                    "?", f"('{where_tuple_str}')"
                                )

                            else:
                                # print(f"Tuple len is not 1")
                                # Parameterize query to avoid SQL injection
                                select_query_p = select_query.replace(
                                    "?", str(where_tuple)
                                )
                                logging.info(
                                    f"In else select query is {select_query_p}"
                                )
                            result_df = self.execute_query(mssql_conn, select_query_p)
                            logging.info(f"@##$@#$@#@#@# result {result_df}")

                        else:
                            logging.infos(
                                f"No values found for where clause: {where_col}"
                            )

                    if result_df is not None:
                        result_dict = result_df.to_dict(orient="records")
                        dependent_dict[table_10_key] = result_dict
                    else:
                        dependent_dict[table_10_key] = []
                    # print(f"@@@@@@@@@@@@@@@@ Depedent dict is {dependent_dict}")

        except Exception as e:
            logging.info(f"Error in Bulk Change-Fetching data from 1.0 ---{e}")

        return dependent_dict, where_val_list

    def clean_data_list(self, data_list):
        """Convert NaT values to None for PostgreSQL compatibility."""
        for record in data_list:
            for key, value in record.items():
                if isinstance(value, float) and (math.isnan(value) or value is None):
                    record[key] = None
                if isinstance(
                    value, pd._libs.tslibs.nattype.NaTType
                ):  # Check for NaT type
                    record[key] = None
                if isinstance(value, pd.Timestamp):
                    if pd.isna(value):  # Check if it's NaT
                        record[key] = None
                    else:
                        record[key] = value.strftime(
                            "%Y-%m-%d %H:%M:%S"
                        )  # Convert to string format
                elif isinstance(value, str) and value in [
                    "NaT",
                    "nan",
                    "None",
                    "null",
                ]:  # Handle string cases
                    record[key] = None
        return data_list

    def update_data_history_table_bulk(
        self, postgres_conn, table_name, data_list, conflict_col
    ): # added this line
        """
        Inserts or updates data in a PostgreSQL table based on conflict.

        Parameters:
            postgres_conn: Active PostgreSQL connection
            table_name (str): Name of the target table
            record_dict (dict): Data to insert or update
            conflict_col (str): Column name to check for conflicts
        """
        if not data_list:
            print("No data provided for insertion.")
            return
        try:
            with postgres_conn.cursor() as cursor:
                # Extract column names and values
                columns = list(data_list[0].keys())
                data_list = self.clean_data_list(data_list)

                # Generate column and placeholder strings
                columns_str = ", ".join(columns)
                placeholders = ", ".join(["%s"] * len(columns))
                conflict_cols_str = ", ".join(conflict_col)
                # Generate update set statement excluding the conflict column
                update_set = ", ".join(
                    [
                        f"{col} = EXCLUDED.{col}"
                        for col in columns
                        if col != conflict_col
                    ]
                )
                # Construct the UPSERT query
                # print(columns_str)

                query = f"""
                INSERT INTO {table_name} ({columns_str})
                VALUES %s
                ON CONFLICT ({conflict_cols_str})
                DO UPDATE SET {update_set};
                """
                values = [tuple(record[col] for col in columns) for record in data_list]
                logging.info(f"query going to execute on history tables{query}")
                # print(f"Update values are {values}")

                execute_values(cursor, query, values)
                postgres_conn.commit()
                logging.info(f"Record inserted/updated successfully. {table_name}")

        except Exception as e:
            postgres_conn.rollback()
            logging.info(f"Error in update_data_history_table bulk: {e}")

    def update_data_history_table(
        self, postgres_conn, table_name, data_list, conflict_col
    ):
        """
        Inserts or updates data in a PostgreSQL table based on conflict.

        Parameters:
            postgres_conn: Active PostgreSQL connection
            table_name (str): Name of the target table
            record_dict (dict): Data to insert or update
            conflict_col (str): Column name to check for conflicts
        """
        if not data_list:
            logging.error("No data provided for insertion.")
            return
        try:
            with postgres_conn.cursor() as cursor:
                # Extract column names and values
                columns = list(data_list[0].keys())
                data_list = self.clean_data_list(data_list)

                # Generate column and placeholder strings
                columns_str = ", ".join(columns)
                placeholders = ", ".join(["%s"] * len(columns))
                conflict_cols_str = ", ".join(conflict_col)
                # Generate update set statement excluding the conflict column
                update_set = ", ".join(
                    [
                        f"{col} = EXCLUDED.{col}"
                        for col in columns
                        if col != conflict_col
                    ]
                )
                # Construct the UPSERT query
                # logging.info(columns_str)

                query = f"""
                INSERT INTO {table_name} ({columns_str})
                VALUES %s
                ON CONFLICT ({conflict_cols_str})
                DO UPDATE SET {update_set};
                """
                values = [tuple(record[col] for col in columns) for record in data_list]
                logging.info(f"query going to execute on history tables{query}")
                # logging.info(f"Update values are {values}")

                execute_values(cursor, query, values)
                postgres_conn.commit()
                logging.info(f"Record inserted/updated successfully. {table_name}")

        except Exception as e:
            postgres_conn.rollback()
            logging.error(f"Error in update_data_history_table: {e}")

    def main_save_data_t0_20(
        self,
        main_insert_data,
        main_cond_dict,
        main_multiple_col_conditions,
        id_20,
        postgres_conn,
        dependent_insert_data,
        dependent_cond_dict,
        counter=None,
        tenant_id=None
    ):
        try:
            logging.info(f"PostgresConn{postgres_conn}")
            if main_insert_data:
                for table_name_20, data_list in main_insert_data.items():
                    logging.info(
                        f"{id_20} Data to be updated in table {table_name_20}"
                    ) #{record_dict}
                    if data_list:
                        if table_name_20 in main_cond_dict.keys():
                            where_20_col = main_cond_dict[table_name_20]
                            data_list=self.clean_data_list(data_list)
                            for record_dict in data_list:
                                logging.info(f"{id_20} record_dict is") #{record_dict}
                                update = self.update_table(
                                    postgres_conn,
                                    table_name_20,
                                    record_dict,
                                    {where_20_col: id_20},
                                )

                        elif table_name_20 in main_multiple_col_conditions.keys():
                            logging.info(
                                f"{id_20} in elif condiion table_name {table_name_20}"
                            )
                            where_20_col = main_multiple_col_conditions[table_name_20]
                            split_where_cols = where_20_col.split(",")
                            where_col_0 = split_where_cols[0]
                            where_col_rest = split_where_cols[1:]
                            data_list=self.clean_data_list(data_list)
                            for record_dict in data_list:
                                # Build the where_dict using a dictionary comprehension
                                where_dict = {where_col_0: id_20}
                                where_dict.update(
                                    {
                                        col: record_dict[col]
                                        for col in where_col_rest
                                        if col in record_dict
                                    }
                                )
                                subscriber_number= record_dict.get("subscriber_number")
                                logging.info(f"{id_20} subscriber_number is {subscriber_number}")
                                if subscriber_number:
                                    subscriber_num_present = True
                                else:
                                    subscriber_num_present = False
                                logging.info(f"{id_20} Where dict is {where_dict}")
                                logging.info(f"{id_20} where cond dict {where_dict}")
                                logging.info(
                                    f"{id_20} record_dict passed is {record_dict}"
                                )
                                # Execute the update
                                update = self.update_table(
                                    postgres_conn,
                                    table_name_20,
                                    record_dict,
                                    where_dict,
                                )

                    else:
                        raise ValueError("No records obtained to insert in 2.0")
                return True,subscriber_num_present

            elif dependent_insert_data:
                logging.info(f"Dependent cond dict is {dependent_cond_dict}")
                for table_name_20, data_list in dependent_insert_data.items():
                    logging.info(f"{id_20} Data to be updated in table {table_name_20}")
                    if (
                        table_name_20 == "device_history"
                        or table_name_20 == "mobility_device_history"
                    ):
                        logging.info(
                            f"{id_20} updating device_history table {table_name_20}"
                        )
                        cursor = postgres_conn.cursor()
                        conflict_col = "device_history_id"
                        self.update_data_history_table(
                            postgres_conn, table_name_20, data_list, conflict_col
                        )
                    logging.info(f"{id_20} Table name 20 is {table_name_20}")
                    if not data_list:
                        logging.info(
                            f"{id_20} No Data to Insert, skipping to next iteration"
                        )
                        continue

                    where_20_col = dependent_cond_dict.get(table_name_20)
                    logging.info(f"where 20 col is {where_20_col}")
                    if not where_20_col:
                        logging.info(f"{id_20} Where condition column not found")
                        continue
                    delete_performed = False  # Flag to track delete operation
                    for record_dict in data_list:

                        if where_20_col == "bulk_change_id":
                            where_val = id_20
                            record_dict["bulk_change_id"] = where_val
                            if (
                                table_name_20 == "sim_management_bulk_change_log"
                                and counter == 1
                            ):
                                logging.info(
                                    f"{id_20} Here in sim_management_bulk_change_log record dict is ----"
                                ) #{record_dict}
                                try:
                                    ii = self.insert_data_to_postgres(
                                        table_name_20,
                                        [record_dict],
                                        postgres_conn,
                                        None,
                                    )
                                except Exception as e:
                                    logging.error(f"{id_20} Error in log is {e}")
                            elif (
                                table_name_20 == "sim_management_bulk_change_log"
                                and counter > 1
                            ):
                                logging.info(
                                    f"{delete_performed} checking daelete flag if it is already del records or not "
                                )
                                if not delete_performed:
                                    logging.info(
                                        f" Counter is to insert Log is {counter}"
                                    )
                                    del_query = f"delete from {table_name_20} where bulk_change_id={where_val}"
                                    self.execute_query(postgres_conn, del_query)
                                    delete_performed = True
                                try:
                                    ii = self.insert_data_to_postgres(
                                        table_name_20,
                                        [record_dict],
                                        postgres_conn,
                                        None,
                                    )
                                except Exception as e:
                                    logging.error(f"{id_20} Error in log is {e}")
                            # if table_name_20=='sim_management_bulk_change_log':
                            #     # print(f"Here 111 sim_management_bulk_change_log ----{record_dict}")
                            #     try:
                            #         ii=self.insert_data_to_postgres(table_name_20,[record_dict],postgres_conn,None)
                            #     except Exception as e:
                            #         print(f"Error in log is {e}")

                        else:
                            if table_name_20 == "sim_management_inventory":
                                cursor = postgres_conn.cursor()
                                iccid = record_dict["iccid"]
                                logging.info(f"{id_20} Before ICCID is {iccid}")

                                sql_query = f"select * from {table_name_20} where iccid='{iccid}' and tenant_id={tenant_id}"
                                cursor.execute(sql_query)
                                result = cursor.fetchall()
                                logging.info(f"SMI RESULT IS")  #{result}
                                logging.info(f" SMI 1111 result is ")#{result}
                                if result:
                                    logging.info(f"{id_20} RESELT FROM SMI TRUE")
                                    where_val = record_dict.get(where_20_col)

                                    logging.info(
                                        f"{id_20} where val is for smi {where_val}"
                                    )
                                    if where_val is not None:
                                        # Prepare the update where conditions
                                        where_dict = {
                                            where_20_col: where_val,
                                            "tenant_id": tenant_id,
                                        }

                                        logging.info(
                                            f"{id_20} where dict is {where_dict}"
                                        )
                                        logging.info(
                                            f"{id_20} record dict is just beforreee"
                                        ) #{record_dict}
                                        # Execute the update
                                        self.update_table(
                                            postgres_conn,
                                            table_name_20,
                                            record_dict,
                                            where_dict,
                                        )
                                else:
                                    # print(f"Here 111 sim_management_bulk_change_log ----{record_dict}")
                                    try:
                                        ii = self.insert_data_to_postgres(
                                            table_name_20,
                                            [record_dict],
                                            postgres_conn,
                                            None,
                                        )
                                    except Exception as e:
                                        logging.error(f"{id_20} Error in log is {e}")
                            else:
                                where_val = record_dict.get(where_20_col)

                                logging.info(f"{id_20} where val is {where_val}")
                                if where_val is not None:
                                    # Prepare the update where conditions
                                    where_dict = {where_20_col: where_val}
                                    logging.info(f"{id_20}-where dict is {where_dict}")
                                    logging.info(
                                        f"{id_20}-record dict is "
                                    )#{record_dict}
                                    # Execute the update
                                    self.update_table(
                                        postgres_conn,
                                        table_name_20,
                                        record_dict,
                                        where_dict,
                                    )
                return True
        except Exception as e:
            logging.info(f"{id_20} Error in main_save_data_t0_20: {e}")
            logging.info(f"{id_20} Going to execute update_query")
            # logging.info(f"Going to execute")
            error_msg = f"Error in main_save_data_t0_20: {e}"
            update_data_dict = {"progress": "Error in Sync", "error_msg": error_msg}
            ue = self.update_table(
                postgres_conn,
                "sim_management_bulk_change",
                update_data_dict,
                {"id": id_20},
            )

    def get_subtenant_id_by_name(self,subtenant_name, tenant_list):
        for tenant in tenant_list:
            for sub in tenant.get("sub_tenants", []):
                if sub.get("tenant_name") == subtenant_name:
                    return sub.get("id")
        return None  # Return None if not found

    def get_parent_id_by_subtenant(self,subtenant_name, tenant_list):
        for tenant in tenant_list:
            for sub in tenant.get("sub_tenants", []):
                if sub.get("tenant_name") == subtenant_name:
                    return tenant.get("tenant_id")
        return None


    def save_data_20_from_10(
        self, id_10, id_20, transfer_name, postgres_data, data_all,sqs_falg=False,tenant_name=None,ver_inventory_flag=None
        ,parent_tenant_id=None,sub_tenant_id=None,access_token=None,active_new_service_api_flag=None,role_name=None,api_call_flag=None,sync_count=0
    ):  # commenting this to implement ticket 2266 on 08-01-2025
        try:
            logging.info(f"reverse syncing data from 1.0 to 2.0 for {id_20}")
            if tenant_name=='Altaworx Test': # added this line
                tenant_name='Altaworx' # added this line
            #parent_tenant_id = None  # added this line
            tenant_id=parent_tenant_id
            tenant_id_str=None
            sqs_flag=False
            sync_count+=1
            logging.info(f"sync_count is {id_20} {id_10} {sync_count}")
            #tenant_json=self.load_json()
            #tenant_id_dict=tenant_json.get('TenanatIds')
            #tenant_id=tenant_id_dict.get(tenant_name,None)
            #sub_tenants_json=self.tenant_load_json()
            # common_utils_db=os.getenv("COMMON_UTILS_DB_NAME")
            # comm_postgres_con= self.create_connection(
            #     db_type, hostname,common_utils_db, user, password, port
            # )

            # if tenant_name:
            #     tenant_name,parent_tenant_id,subtenant_id=self.function_to_check_sub_tenant_or_parent_name(comm_postgres_con,tenant_name)
            #     tenant_id=parent_tenant_id
            # logging.info(f"Tenant details after loading from fn function_to_check_sub_tenant_or_parent_name is {tenant_name} and parent_tenant_id is {parent_tenant_id} and tenant_id is {tenant_id}")


            '''if tenant_id is None:
                logging.info(f"save_data_20_from_10 Tenant id is not found in tenant json")
                subtenant_id = self.get_subtenant_id_by_name(tenant_name, sub_tenants_json)
                parent_tenant_id=self.get_parent_id_by_subtenant(tenant_name,sub_tenants_json)
                logging.info(f"Subtenant id is {subtenant_id}")
                if subtenant_id:
                    tenant_id = subtenant_id
            else: # added this line
                parent_tenant_id=tenant_id # added this line'''

            if tenant_id:
                tenant_id_str = f"({', '.join(str(i) for i in [parent_tenant_id, sub_tenant_id] if i is not None)})"



            #parent_tenant_name=self.get_parent_by_subtenant(tenant_name,sub_tenants_json)
            #if parent_tenant_name:
                #tenant_name=parent_tenant_name

            logging.info(f"save_data_20_from_10 tenant_name {id_20} {tenant_name} tenant_id is {tenant_id}")

            logging.info(
                f"devicehistorytable postgress_data,{postgres_data},id_10 is ,{id_10}, id_20 is {id_20}, transfer name is {transfer_name}"
            )
            logging.info(f"Going to save data from 1.0 to 2.0,{postgres_data}")
            logging.info(f"Transfer name is {transfer_name}")
            logging.info(f"ID 10 is {id_10}")
            logging.info(f"ID 20 is {id_20}")


            # if transfer_name == "bulk_change":
            if transfer_name.startswith("bulk_change"):
                data_list = postgres_data["sim_management_bulk_change"]
                service_provider_id = data_list[0]["service_provider_id"]
                logging.info(f"####service_provider_id in save_data_20_from_10 is {service_provider_id}")
                json_data = self.load_json()
                telegence_ids = self.get_provider_ids(json_data, tenant_name, ["Telegence"])

                if tenant_name.lower() in ('altaworx_test','altaworx'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility"
                        inventory_conflict_cols=["mdt_id","mobility_device_id"]
                    else:
                        transfer_name = "bulk_change"
                        inventory_conflict_cols=["dt_id","device_id"]

                elif tenant_name.lower() == 'spectrotel':
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_spectrotel"
                        inventory_conflict_cols=["mdt_id","mobility_device_id"]
                    else:
                        transfer_name = "bulk_change_spectrotel"
                        inventory_conflict_cols=["dt_id","device_id"]

                elif tenant_name in ('altaworx_go_tech','Altaworx - Go Tech'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_altaworx_go_tech"
                        inventory_conflict_cols=["mdt_id","mobility_device_id"]
                    else:
                        transfer_name = "bulk_change_altaworx_go_tech"
                        inventory_conflict_cols=["dt_id","device_id"]

                elif tenant_name.lower() in ('apitesttenant'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_apitesttenant"
                        inventory_conflict_cols=["mdt_id","mobility_device_id"]
                    else:
                        transfer_name = "bulk_change_apitesttenant"
                        inventory_conflict_cols=["dt_id","device_id"]
                else:
                    logging.info("Tenant not found in save_data_20_from_10")
                    raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")


            delay_flag = False
            log_status_check_flag = False
            sqs_postgres_data={"sim_management_bulk_change":postgres_data["sim_management_bulk_change"]}


            # if transfer_name == "bulk_change_mobility":
            change_type_get = postgres_data["sim_management_bulk_change"][0][
                "change_request_type"
            ]
            logging.info(f"Change type got is {change_type_get}")
            if change_type_get == "Activate New Service":
                logging.info(f"Change type is Activate New Service {id_20}")
                ver_inventory_flag=True
                delay_flag = True
                log_status_check_flag = True
            else:
                log_status_check_flag = False
            # else:
            #     log_status_check_flag = False
            #     delay_flag = False

            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            # getting details from db
            mapping_details_query = f"select db_name_20,db_config,reverse_table_mapping,reverse_col_mapping,data_from_10,update_cond_cols,db_name_10,db_config from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn1, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            table_info_dict = mapping_details["data_from_10"]
            update_cond_20 = mapping_details["update_cond_cols"]
            mssql_config = mapping_details.get("db_config", {})  # ssms db config details
            db_name_10 = mapping_details.get("db_name_10", {})
            logging.info("mssql configurations", mssql_config)
            if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                logging.info("no mappings present for the configurations so returning the function")
                return True

            '''(
                from_host,
                from_port,
                from_db,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()'''
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )

            main_details_list = table_info_dict[
                "main"
            ]  # get info list from db which helps in getting data from 10

            # print(f"Main dict {main_result_dict}")

            db_name_20 = mapping_details["db_name_20"]
            logging.info(f"DB Name is {db_name_20}")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name_20, user, password, port
            )
            logging.info(f"Postgres Conn {postgres_conn}")
            main_cond_dict = update_cond_20[
                "main"
            ]  # get the dict from db whic contains condition params
            main_multiple_col_conditions = update_cond_20["main_multi_col"]
            dependent_cond_dict = update_cond_20["dependent"]

            reverse_tables = mapping_details["reverse_table_mapping"]
            reverse_col_mappings = mapping_details["reverse_col_mapping"]
            dependent_info_list = table_info_dict[
                "dependent"
            ]  # get info list from db which helps in getting data from 10

            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            try:
                if tenant_name:
                    common_utils_conn=self.create_connection(db_type,hostname,'common_utils',user,password,port)
                    tenant_name_q=f"select db_name from tenant where tenant_name='{tenant_name}' and is_active=true and is_deleted=false"
                    tenant_name_res=self.execute_query(common_utils_conn,tenant_name_q)
                    # if tenant_name_res is not None and 'db_name' in tenant_name_res and tenant_name_res['db_name']:
                    if tenant_name_res is not None and not tenant_name_res.empty and 'db_name' in tenant_name_res.columns:
                        tenant_name_ = tenant_name_res['db_name'][0]
                        db_name=tenant_name_
                    else:
                        logging.info(f"Tenant '{tenant_name}' not found or inactive.")
                        raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")
                # else:
                #     db_name='altaworx_test'
            except Exception as e:
                logging.error(f"Error in fetching tenant name:{id_20} {e}")
                logging.error(f"{id_10} id_20 {id_20} Error in fetching tenant name: {e}")
                # db_name = "altaworx_test"



            print(f"conn variables {hostname,port,user,password,db_type,db_name}")
            postgres_conn_a = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            main_result_dict, keep_trying_flag = self.get_10_data(
                transfer_name,
                mssql_conn,
                id_10,
                main_details_list,
                log_status_check_flag,
                main_flag=True,
            )
            logging.info(
                f"1.0 data obtained::: id_10 {id_10} and 2.0 id is {id_20} flag is {keep_trying_flag}"
            )
            logging.info(
                f"Data dict obtained from 1.0 for main tables:{id_20} \n {main_result_dict}"
            )

            counter = 0
            loop_start_time = time.time()
            activate_new_service_fn_call=False
            inside_ver_flag=False

            while keep_trying_flag == True and sync_count<15:
                counter = counter + 1
                logging.info(f"Counter is for id_20 {id_20} {counter}")
                logging.info(
                    f"Keep Trying flag is {keep_trying_flag} id_10 {id_10} and 2.0 id is {id_20} {sync_count}"
                )
                main_insert_data = self.map_cols(
                    reverse_tables, reverse_col_mappings, main_result_dict
                )
                insert_main_dict,sub_num = self.main_save_data_t0_20(
                    main_insert_data,
                    update_cond_20["main"],
                    update_cond_20["main_multi_col"],
                    id_20,
                    postgres_conn,
                    {},
                    update_cond_20["dependent"],
                    tenant_id
                )

                main_result_dict, keep_trying_flag = self.get_10_data(
                    transfer_name,
                    mssql_conn,
                    id_10,
                    main_details_list,
                    log_status_check_flag,
                    main_flag=True,
                )
                logging.info(f"Keep trying flag is {keep_trying_flag} {counter} id_10 {id_10} and 2.0 id is {id_20}")
                loop_elapsed_time = time.time() - loop_start_time
                logging.info(f"Loop elapsed time is {loop_elapsed_time} {counter} id_10 {id_10} and 2.0 id is {id_20}")

                if log_status_check_flag is True and not inside_ver_flag:
                    logging.info(f"For this here flags are {id_20} {log_status_check_flag} {inside_ver_flag}")
                    logging.info(
                        f"for This particular type we need to keep syning dependent tables too {counter} id_10 {id_10} and 2.0 id is {id_20}"
                    )
                    dependent_dict, where_val_list = self.get_10_data(
                        transfer_name,
                        mssql_conn,
                        id_10,
                        dependent_info_list,
                        log_status_check_flag,
                        main_flag=False,
                        main_result_dict=main_result_dict,
                        tenant_id_str=tenant_id_str
                    )
                    dependent_insert_data = self.map_cols(
                        reverse_tables, reverse_col_mappings, dependent_dict
                    )
                    logging.info(f"Dependent_dict is and 2.0 id is {counter} id_10 {id_10}  {id_20} {dependent_insert_data}")
                    insert_dependent_data = self.main_save_data_t0_20_bulk_update(
                        {},
                        main_cond_dict,
                        main_multiple_col_conditions,
                        id_20,
                        postgres_conn,
                        dependent_insert_data,
                        dependent_cond_dict,
                        tenant_id,
                        inventory_conflict_cols=inventory_conflict_cols,
                    )
                    try:
                        msisdn_list = [
                                            item.get('msisdn')
                                            for item in dependent_insert_data.get('sim_management_inventory', [])
                                            if isinstance(item, dict) and 'msisdn' in item
                                        ]
                        msisdn_list = [msisdn for msisdn in msisdn_list if msisdn != '']
                        msisdn_list = set(msisdn_list)
                        logging.info(f"bulk change id 2.0: {id_20} msisdn_list is {msisdn_list} {id_10}")
                        msisdn_details_query = f"select subscriber_number from sim_management_bulk_change_request where bulk_change_id ={id_20}"
                        msisdn_details = self.execute_query(postgres_conn_a, msisdn_details_query)
                        msisdn_details = msisdn_details['subscriber_number'].tolist()
                        msisdn_details = [msisdn for msisdn in msisdn_details if msisdn != '']
                        msisdn_details = set(msisdn_details)
                        logging.info(f"bulk change id 2.0: {id_20} msisdn_details is {msisdn_details}")
                        if len(msisdn_list) == len(msisdn_details) and len(msisdn_list) != 0  and len(msisdn_details) != 0:
                            logging.info(f"Need to call sync here once {id_20}")
                            if not inside_ver_flag:
                                try:
                                    logging.info(f"inside ver flag {id_20} {inside_ver_flag}")
                                    # time.sleep(15)
                                    logging.info(f"I1 Need to call sync to update inventory inside is {id_20}")
                                    api_url = os.environ.get("SERVICE_LINE_API_URL", "")
                                    api_payload = {
                                        "data": {
                                            "path": "/lambda_sync_jobs_",
                                            "key_name": "verizon_inventory",
                                            "tenant_name": tenant_name
                                        }
                                    }
                                    response = requests.post(api_url, json=api_payload)
                                    if response.status_code in (200,504):
                                        current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                        logging.info(
                                            f"API call successful for verizon_invntory. Data sync call is successfully done inside {id_20}"
                                        )
                                        inside_ver_flag=True
                                    else:
                                        logging.info(
                                            f"API call failed for verizon inventory with status code:inside {id_20} {response.status_code}"
                                        )
                                except Exception as e:
                                    logging.info(
                                        f"Error occurred while calling the API for service_number verizon inventory inside {id_20} {e}"
                                    )
                            if active_new_service_api_flag is True and not activate_new_service_fn_call:
                                from sim_management import activate_new_service_caller
                                logging.info(f"bulk change id 2.0: {id_20} Activate new service API call {id_10}")
                                fn_call=activate_new_service_caller(id_20,db_name,access_token,tenant_name,role_name,api_call_flag)
                                activate_new_service_fn_call=True
                            else:
                                logging.info(f"bulk change id 2.0: {id_20} active_new_service_api_flag: {active_new_service_api_flag} activate_new_service_fn_call:{activate_new_service_fn_call}")
                        else:
                            logging.info(f"bulk change id 2.0: {id_20} msisdn_list and msisdn_details are not equal ")
                    except Exception as e:
                        logging.info(f"Error in activate new service API call {e}")
                        pass

                # if counter>2500:
                # if loop_elapsed_time > 720:
                #     logging.warning(f"Time exceeded 12 minutes. Breaking the loop forcefully. id_10: {id_10}, id_20: {id_20}")
                #     error_msg=f"Counter exceeded 200. Breaking the loop forcefully. id_10: {id_10}, id_20: {id_20}"
                #     if transfer_name in ('bulk_change','bulk_change_mobility'):
                #         # update_query=f"update sim_management_bulk_change set progress='Error in Sync', error_msg={error_msg} where id={id_20}"
                #         logging.info(f"Going to execute update")
                #         update_data_dict={"progress":"Time limit Exceeded, Sync Stopped","error_msg":f"Time limit exceeded {loop_elapsed_time}"}
                #         ue=self.update_table(postgres_conn_a, 'sim_management_bulk_change', update_data_dict, {'id':id_20})
                #         keep_trying=False
                #         break

                if loop_elapsed_time > 720:
                    # logging.warning(f"Time exceeded 12 minutes. Breaking the loop forcefully. id_10: {id_10}, id_20: {id_20}")
                    # error_msg=f"Counter exceeded 200. Breaking the loop forcefully. id_10: {id_10}, id_20: {id_20}"\

                    #  adding sqs function to continue after 12 min
                    logging.warning(
                        f"Time exceeded 12 minutes. Sending to SQS for continued processing. id_10: {id_10}, id_20: {id_20}"
                    )
                    if transfer_name in ("bulk_change", "bulk_change_mobility", "bulk_change_spectrotel", "bulk_change_mobility_spectrotel", "bulk_change_mobility_altaworx_go_tech", "bulk_change_altaworx_go_tech", "bulk_change_mobility_apitesttenant", "bulk_change_apitesttenant"):
                        # update_query=f"update sim_management_bulk_change set progress='Error in Sync', error_msg={error_msg} where id={id_20}"
                        # logging.info(f"Going to execute update")
                        # update_data_dict={"progress":"Time limit Exceeded, Sync Stopped","error_msg":f"Time limit exceeded {loop_elapsed_time}"}
                        # ue=self.update_table(postgres_conn_a, 'sim_management_bulk_change', update_data_dict, {'id':id_20})
                        # keep_trying=False
                        # break

                        message_body = {
                            "id_10": id_10,
                            "id_20": id_20,
                            "transfer_name": transfer_name,
                            "elapsed_time": loop_elapsed_time,
                            "continuation": True,
                            "path": "/save_data_20_from_10",
                            "access_token": data_all["access_token"],
                            "data_all": {"access_token": data_all["access_token"]},
                            "postgres_data":  sqs_postgres_data,
                            'sqs_call':True,
                            'db_name': data_all.get("db_name",""),
                            'username': data_all.get("username",""),
                            'tenant_name':tenant_name,
                            'parent_tenant_id':parent_tenant_id,
                            'sub_tenant_id':sub_tenant_id,
                            "access_token":access_token,
                            "active_new_service_api_flag":active_new_service_api_flag,
                            "role_name":role_name,
                            'sync_count':sync_count
                        }

                        try:
                            logging.info(
                                f"sqs queue message sending ------- for continued processing"
                            )
                            o = self.send_msg_sim_management_trigger_queue(message_body)
                            logging.info("Successfully queued for continued processing")
                            return True
                        except Exception as e:
                            logging.info(f"Error in SQS Queue Calling {e}")
                            logging.info(f"Going to insert dependent data")
                            ###################### saving dependent data
                            dependent_dict,where_val_list=self.get_10_data(transfer_name,mssql_conn,id_10,dependent_info_list,log_status_check_flag,main_flag=False,main_result_dict=main_result_dict,tenant_id_str=tenant_id_str)
                            # print(f"Data dict obtained from 1.0 for dependent tables: \n {dependent_dict} \n {where_val_list}")
                            dependent_insert_data=self.map_cols(reverse_tables,reverse_col_mappings,dependent_dict)
                            # logging.info(f"Dependent_dict is {dependent_insert_data}")
                            insert_dependent_data=self.main_save_data_t0_20_bulk_update({},main_cond_dict,main_multiple_col_conditions,id_20,postgres_conn,dependent_insert_data,dependent_cond_dict,counter, tenant_id=tenant_id,inventory_conflict_cols=inventory_conflict_cols)
                            keep_trying=False
                            sqs_flag=True
                            update_data_dict={"progress":"sqs has error, Sync Stopped","error_msg":f"Time limit exceeded {loop_elapsed_time} and sqs queue failed"}
                            ue=self.update_table(postgres_conn_a, 'sim_management_bulk_change', update_data_dict, {'id':id_20})
                            return False

            logging.info(
                f"Keep trying flag is {keep_trying_flag} and id_10 {id_10} and 2.0 id is {id_20} doing a final update"
            )
            main_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, main_result_dict
            )
            insert_main_dict,sub_num = self.main_save_data_t0_20(
                main_insert_data,
                update_cond_20["main"],
                update_cond_20["main_multi_col"],
                id_20,
                postgres_conn,
                {},
                update_cond_20["dependent"],
                tenant_id
            )

            logging.info(
                f"Keep Trying flag {keep_trying_flag},id_10 {id_10} and 2.0 id is {id_20} Updating Dependent tables"
            )
            dependent_dict, where_val_list = self.get_10_data(
                transfer_name,
                mssql_conn,
                id_10,
                dependent_info_list,
                log_status_check_flag,
                main_flag=False,
                main_result_dict=main_result_dict,
                tenant_id_str=tenant_id_str
            )
            # print(f"Data dict obtained from 1.0 for dependent tables: \n {dependent_dict} \n {where_val_list}")
            dependent_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, dependent_dict
            )
            logging.info(f"Dependent_dict is {id_20} {dependent_insert_data}")
            insert_dependent_data = self.main_save_data_t0_20_bulk_update(
                {},
                main_cond_dict,
                main_multiple_col_conditions,
                id_20,
                postgres_conn,
                dependent_insert_data,
                dependent_cond_dict,
                tenant_id=tenant_id,
                inventory_conflict_cols=inventory_conflict_cols
            )

            if ver_inventory_flag:
                try:
                    time.sleep(15)
                    logging.info(f"I1 Need to call sync to update inventory outside loop {id_20}")
                    api_url = os.environ.get("SERVICE_LINE_API_URL", "")
                    api_payload = {
                        "data": {
                            "path": "/lambda_sync_jobs_",
                            "key_name": "verizon_inventory",
                            "tenant_name": tenant_name
                        }
                    }
                    response = requests.post(api_url, json=api_payload)
                    if response.status_code == 200:
                        current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        logging.info(
                            f"API call successful for verizon_invntory. Data sync call is successfully done outside {id_20}"
                        )
                    else:
                        logging.info(
                            f"API call failed for verizon inventory with status code:{id_20} {response.status_code}"
                        )
                except Exception as e:
                    logging.info(
                        f"Error occurred while calling the API for service_number verizon inventory {id_20} {e}"
                    )

            if transfer_name in ("bulk_change", "bulk_change_mobility", "bulk_change_spectrotel", "bulk_change_mobility_spectrotel", "bulk_change_mobility_altaworx_go_tech", "bulk_change_altaworx_go_tech", "bulk_change_mobility_apitesttenant", "bulk_change_apitesttenant"):
                update_query = f"update sim_management_bulk_change set progress='Sync Completed' where id={id_20}"
                logging.info(f"Going to execute update")
                update_data_dict = {"progress": "Sync Completed"}
                ue = self.update_table(
                    postgres_conn_a,
                    "sim_management_bulk_change",
                    update_data_dict,
                    {"id": id_20},
                )
                #mssql_conn.close()
            DataTransfer.release_connection("postgresql",hostname,port,'Migration_Test', postgres_conn1)
            DataTransfer.release_connection("postgresql",hostname,port,db_name_20, postgres_conn)
            DataTransfer.release_connection("mssql",from_host,from_port,ssms_db_name, mssql_conn)
            DataTransfer.release_connection("postgresql",hostname,port,'common_utils',common_utils_conn)
            DataTransfer.release_connection("postgresql",hostname,port,db_name,postgres_conn_a)

            return True

        except Exception as e:

            logging.error(
                f"Error while fetching data from 1.0 and saving it int 2.0 {id_20}: {e}"
            )
            error_msg = f"save_data_20_from_10 - Error while fetching data from 1.0 and saving it int 2.0 : {e}"
            if transfer_name in ("bulk_change", "bulk_change_mobility", "bulk_change_spectrotel", "bulk_change_mobility_spectrotel", "bulk_change_mobility_altaworx_go_tech", "bulk_change_altaworx_go_tech", "bulk_change_mobility_apitesttenant", "bulk_change_apitesttenant"):
                # update_query=f"update sim_management_bulk_change set progress='Error in Sync', error_msg={error_msg} where id={id_20}"
                logging.info(f"Going to execute update_query")
                logging.info(f"Going to execute")
                update_data_dict = {"progress": "Error in Sync", "error_msg": error_msg}
                ue = self.update_table(
                    postgres_conn_a,
                    "sim_management_bulk_change",
                    update_data_dict,
                    {"id": id_20},
                )
                mssql_conn.close()

            return False

    def save_data_20_from_10_old(
        self, id_10, id_20, transfer_name, postgres_data
    ):  # commenting this to implement ticket 2266 on 08-01-2025
        try:
            if transfer_name == "bulk_change":
                data_list = postgres_data["sim_management_bulk_change"]
                service_provider_id = data_list[0]["service_provider_id"]
                print(f"11111 {service_provider_id}")
                if str(service_provider_id) in ["6", "20"]:
                    transfer_name = "bulk_change_mobility"
                else:
                    transfer_name = "bulk_change"

            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            # getting details from db
            mapping_details_query = f"select db_name_20,db_config,reverse_table_mapping,reverse_col_mapping,data_from_10,update_cond_cols from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn1, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            table_info_dict = mapping_details["data_from_10"]
            update_cond_20 = mapping_details["update_cond_cols"]

            (
                from_host,
                from_port,
                from_db,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                from_db,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )

            main_details_list = table_info_dict[
                "main"
            ]  # get info list from db which helps in getting data from 10

            main_result_dict = self.get_10_data(
                transfer_name, mssql_conn, id_10, main_details_list, main_flag=True
            )
            logging.info(
                f"Data dict obtained from 1.0 for main tables: \n {main_result_dict}"
            )

            # print(f"Main dict {main_result_dict}")

            dependent_info_list = table_info_dict[
                "dependent"
            ]  # get info list from db which helps in getting data from 10
            dependent_dict, where_val_list = self.get_10_data(
                transfer_name,
                mssql_conn,
                id_10,
                dependent_info_list,
                main_flag=False,
                main_result_dict=main_result_dict,
            )
            logging.info(
                f"Data dict obtained from 1.0 for dependent tables: \n {dependent_dict} \n {where_val_list}"
            )
            # print(f"Depedent data {dependent_dict} \n {where_val_list}")

            reverse_tables = mapping_details["reverse_table_mapping"]
            reverse_col_mappings = mapping_details["reverse_col_mapping"]

            main_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, main_result_dict
            )
            db_name_20 = mapping_details["db_name_20"]
            # print(f"############# Main insert_data {main_insert_data}")

            postgres_conn = self.create_connection(
                db_type, hostname, db_name_20, user, password, port
            )

            main_cond_dict = update_cond_20[
                "main"
            ]  # get the dict from db whic contains condition params
            main_multiple_col_conditions = update_cond_20["main_multi_col"]
            dependent_cond_dict = update_cond_20["dependent"]

            for table_name_20, data_list in main_insert_data.items():
                logging.info(
                    f"Data to be updated in table {table_name_20} is {data_list}"
                )
                if data_list:
                    if table_name_20 in main_cond_dict.keys():
                        where_20_col = main_cond_dict[table_name_20]
                        for record_dict in data_list:
                            print(f"record_dict is {record_dict}")
                            update = self.update_table(
                                postgres_conn,
                                table_name_20,
                                record_dict,
                                {where_20_col: id_20},
                            )

                    elif table_name_20 in main_multiple_col_conditions.keys():
                        # logging.info(f"in elif condiion table_name {table_name_20}")
                        where_20_col = main_multiple_col_conditions[table_name_20]
                        split_where_cols = where_20_col.split(",")
                        where_col_0 = split_where_cols[0]
                        where_col_rest = split_where_cols[1:]

                        for record_dict in data_list:
                            # Build the where_dict using a dictionary comprehension
                            where_dict = {where_col_0: id_20}
                            where_dict.update(
                                {
                                    col: record_dict[col]
                                    for col in where_col_rest
                                    if col in record_dict
                                }
                            )
                            # print(f"where cond dict {where_dict}")
                            # print(f"record_dict passed is {record_dict}")
                            # Execute the update
                            update = self.update_table(
                                postgres_conn, table_name_20, record_dict, where_dict
                            )

                else:
                    raise ValueError("No records obtained to insert in 2.0")

            dependent_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, dependent_dict
            )
            print(f"Dependent_dict is {dependent_insert_data}")

            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            db_name = os.getenv("MAIN_DB")
            print(f"conn variables {hostname,port,user,password,db_type,db_name}")
            postgres_conn_a = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            for table_name_20, data_list in dependent_insert_data.items():
                if not data_list:
                    logging.warning("No Data to Insert")
                    continue

                where_20_col = dependent_cond_dict.get(table_name_20)
                if not where_20_col:
                    logging.info("Where condition column not found")
                    continue

                for record_dict in data_list:
                    if where_20_col == "bulk_change_id":
                        where_val = id_20
                        record_dict["bulk_change_id"] = where_val
                        if table_name_20 == "sim_management_bulk_change_log":
                            try:
                                self.insert_data_to_postgres(
                                    table_name_20, [record_dict], postgres_conn_a, None
                                )
                            except Exception as e:
                                logging.error(
                                    f"Error in inserting log data-{table_name_20} {e}"
                                )
                    else:
                        where_val = record_dict.get(where_20_col)
                    # where_val = record_dict.get(where_20_col)
                    if where_val is not None:
                        # Prepare the update where conditions
                        where_dict = {where_20_col: where_val}
                        # Execute the update
                        self.update_table(
                            postgres_conn, table_name_20, record_dict, where_dict
                        )

            return True

        except Exception as e:

            logging.error(
                f"Error while fetching data from 1.0 and saving it int 2.0 : {e}"
            )
            return False

    def insert_data_to_postgres(self, table_name, data_list, pg_conn, return_col=None):
        """
        Inserts data into a PostgreSQL table using cursor.execute for each row.

        Args:
            table_name (str): The name of the PostgreSQL table.
            data_list (list of dict): List of dictionaries, each representing a row to be inserted.
            pg_conn (psycopg2 connection): Active PostgreSQL connection.
            return_col (str, optional): The column to return after insertion. Defaults to None.

        Returns:
            tuple: If `return_col` is provided, returns (last_return_value, return_column_name).
                Otherwise, returns None.
        """
        try:
            if not pg_conn:
                raise ValueError("Invalid PostgreSQL connection")

            if not data_list:
                raise ValueError("Data list is empty")

            cursor = pg_conn.cursor()

            # Extract column names
            columns = ", ".join(data_list[0].keys())
            placeholders = ", ".join(
                [f"%({col})s" for col in data_list[0].keys()]
            )  # Named placeholders

            # Construct the SQL query
            if return_col:
                sql_query = f"""
                    INSERT INTO {table_name} ({columns})
                    VALUES ({placeholders})
                    RETURNING {return_col};
                """
            else:
                sql_query = f"""
                    INSERT INTO {table_name} ({columns})
                    VALUES ({placeholders});
                """

            try:
                return_val = None
                return_fk_name = None

                # Execute the query for each row
                for row in data_list:
                    # Prepare the row, convert non-serializable objects to JSON strings
                    formatted_row = {
                        col: (json.dumps(val) if isinstance(val, (dict, list)) else val)
                        for col, val in row.items()
                    }
                    logging.info(f"formatted row is {formatted_row}")
                    cursor.execute(sql_query, formatted_row)

                    # Fetch the returned column value if requested
                    if return_col:
                        return_val = cursor.fetchone()[0]
                        return_fk_name = f"{table_name}.{return_col}"

                # Commit the transaction
                pg_conn.commit()
                logging.info("Insert Successful")

                if return_col:
                    return return_val, return_fk_name

            except Exception as e:
                print(f"Failed to insert rows into {table_name}: {e}")
                pg_conn.rollback()
                return None

            finally:
                cursor.close()

        except Exception as e:
            logging.error(f"Error while inserting rows into {table_name}: {e}")
            return None

    def delete_from_pgsql_(self, mssql_conn, id_10, table_name_10):
        try:
            logging.info(f"conn is {mssql_conn}")
            cursor = mssql_conn.cursor()
            delete_query = f"DELETE FROM {table_name_10} WHERE id={id_10}"
            cursor.execute(delete_query)
            mssql_conn.commit()
            print(f"Deleted from 1.0")
        except Exception as e:
            logging.error(f"Error while deleting from 1.0: {e}")

    def is_valid_table_name(self, table_name):
        pattern = r"^\[\w+\]\.\[\w+\]\.\[\w+\]$"
        return re.match(pattern, table_name) is not None

    # def delete_data_from_10(self,transfer_name,postgres_data,id_10,table_name_10):
    #     try:
    #         from_host,from_port,ssms_db_name,from_user,from_pwd,from_db_type,from_driver=self.load_env_mssql()
    #         # mssql_conn_start = time.time()
    #         mssql_conn=self.create_connection(from_db_type,from_host,ssms_db_name,from_user,from_pwd,from_port,from_driver)
    #         if not self.is_valid_table_name(table_name_10):
    #             full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
    #             logging.info(f"full table name {full_from_table}")
    #         else:
    #             full_from_table = table_name_10
    #         dd=self.delete_from_pgsql(mssql_conn,id_10,full_from_table)
    #     except Exception as e:
    #         logging.error(f"Error while loading env: {e}")
    """
    def save_data_to_10_single_table(self,transfer_name,postgres_data,update_flag=False,delete_flag=False):
        try:
            logging.info(f"STARTING {transfer_name}")
            load_dotenv()
            hostname,port,user,password,db_type,db_name=self.load_env_pgsql()
            logging.info(f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}")
            mapping_table=os.getenv('MAPPING_TABLE')
            postgres_conn = self.create_connection(db_type, hostname, db_name, user, password, port)
            mapping_details_query=f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details=self.execute_query(postgres_conn,mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError("No Mappings present for transfer") #raising error if unable to get required data from db

            mapping_details=mapping_details.to_dict(orient='records')[0]
            tables_dict = mapping_details.get('table_mapping_10_to_20', {})
            db_name_20=mapping_details.get('db_name_20',{})
            logging.info(f"db_name_20 is {db_name_20}")
            logging.info(f"type(tables_dict)----------{type(tables_dict)}")  # 1.0 to 2.0 table mappings dict
            col_mappings = mapping_details.get('col_mapping_10_to_20', {})
            print(type(col_mappings))   # 1.0 to 2.0 column mappings
            return_params_10 = mapping_details.get('return_params_10', {})    # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get('fk_cols_10', {})                # foreign key columns
            db_config=mapping_details.get('db_config',{}) #ssms db config details
            table_name_20=mapping_details.get('table_mapping_10_to_20').keys()
            table_name_20 = ', '.join(str(key) for key in table_name_20)
            logging.info(f"table_name_20 is {table_name_20}")
            table_name_10=tables_dict[table_name_20][0]
            logging.info(f"Table Name 1.0 is {table_name_10}")
            # update_flag=True
            hostname = os.getenv('LOCAL_DB_HOST')
            port = os.getenv('LOCAL_DB_PORT')
            db_name=db_name_20
            user = os.getenv('LOCAL_DB_USER')
            password = os.getenv('LOCAL_DB_PASSWORD')
            db_type = os.getenv('LOCAL_DB_TYPE')
            from_driver=os.getenv('LOCAL_DB_DRIVER')
            postgres_conn1 = self.create_connection(db_type, hostname, db_name, user, password, port)

            postgres_data_copy=copy.deepcopy(postgres_data)


            if update_flag is True and delete_flag is False:
                update_data=postgres_data_copy[table_name_20][0]
                id_20=update_data['id']
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query=f"select id_10 from {table_name_20} where id='{id_20}'"
                result=self.execute_query(postgres_conn1,id_10_query)
                id_10=result['id_10'][0]
                logging.info(f"id_10 is {id_10}")
                update_data['id_10']=id_10
                postgres_data_20={table_name_20:[update_data]}
                total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data_20)
            else:
                logging.info(f"tables_dict {tables_dict}")
                total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data)
            logging.info(f"total insert dict is {total_insert_dict}")

            from_host,from_port,ssms_db_name,from_user,from_pwd,from_db_type,from_driver=self.load_env_mssql()
            mssql_conn_start = time.time()
            mssql_conn=self.create_connection(from_db_type,from_host,ssms_db_name,from_user,from_pwd,from_port,from_driver)
            if delete_flag is True and update_flag is False:
                update_data=postgres_data_copy[table_name_20][0]
                id_20=update_data['id']
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query=f"select id_10 from {table_name_20} where id='{id_20}'"
                result=self.execute_query(postgres_conn1,id_10_query)
                id_10=result['id_10'][0]
                update_data['id_10']=id_10
                logging.info(f"id_10 is {id_10}")
                # delete_data=self.delete_data_from_10(transfer_name,postgres_data,id_10,table_name_10)
                query = f"update {table_name_10} set IsDeleted=1,IsActive=0 where id='{id_10}'"
                result=self.execute_query(mssql_conn,query)
                return True
            logging.info(f"mssql_conn {mssql_conn}")
            logging.info(f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds")
            logging.info(f"total insert dict {total_insert_dict}")

            return_ids=[]
            fk_track_dict={}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                #if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table=f'[{ssms_db_name}].[dbo].[{table_name_10}]'

                if return_params_10:
                    logging.info(f"Heree 2111 {return_params_10}")
                    return_col = return_params_10.get(table_name_10,None) #get the col whose value should be returned for this table
                    fk_col_dict = fk_cols_10.get(table_name_10, {}) #get the fk_col dict for this table
                else:
                    return_col=None
                    fk_col_dict=None


                if not return_col and not fk_col_dict:
                    logging.info("This part is to handle update tables don't have any foreign key columnc")
                    if update_flag is False:
                        return_col='ID'
                        return_val, return_fk_name=self.insert_data_to_db(full_from_table,total_insert_dict[table_name_10],mssql_conn,return_col,table_name_10)
                        logging.info(f"return val is {return_val} return fk name is {return_fk_name}")
                        update_postgres_data=postgres_data[table_name_20][0]
                        update_postgres_data['id_10']=return_val
                        update_postgres_id=update_postgres_data['id']
                        update_postgres_data.pop('id')
                        logging.info(f"update_postgres_data is {update_postgres_data}")
                        self.update_table(postgres_conn1,table_name_20,update_postgres_data,{'id':update_postgres_id})

                    else:
                        update_value,update_condtion=self.insert_data_to_db(full_from_table,total_insert_dict[table_name_10],mssql_conn,None,table_name_10)
                        logging.info(f"update value is {update_value} update condition is {update_condtion}")
                        logging.info(postgres_conn)
                        update_data_20=postgres_data[table_name_20][0]
                        logging.info(f"update data 20 is {update_data_20}")
                        id_10=int(update_value['id'])
                        update_data_20['id_10']=id_10
                        id_20=int(update_data_20['id'])
                        self.update_table(postgres_conn1,table_name_20,update_data_20,{'id':id_20})

        except Exception as e:
            logging.error(f"Error in carrier_rate_plan")

    """

    def insert_automation_rule_table_data(self, transfer_name, data_dict):
        load_dotenv()
        hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
        logging.info(f"DB Conn details {hostname,port,user,password,db_type,db_name}")
        postgres_conn1 = self.create_connection(
            db_type, hostname, db_name, user, password, port
        )
        mapping_table = os.getenv("MAPPING_TABLE")

        mapping_details_query = f"select table_mapping_10_to_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_name_10,db_config from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
        # print(f"query {mapping_details_query}")
        mapping_details = self.execute_query(postgres_conn1, mapping_details_query)
        # print(f"mapping_details {mapping_details}")
        mssql_config = mapping_details.get("db_config", {})
        db_name_10 = mapping_details.get("db_name_10", {})
        mapping_details = mapping_details.to_dict(orient="records")[0]

        tables_dict = mapping_details.get("table_mapping_10_to_20", {})
        # print(f"Tables dict is {tables_dict}")  # 1.0 to 2.0 table mappings dict
        col_mappings = mapping_details.get("col_mapping_10_to_20", {})
        # print(f"col_mappings are {col_mappings}")   # 1.0 to 2.0 column mappings
        return_params_10 = mapping_details.get("return_params_10", {})
        # print(f"return params {return_params_10}")   # cols data that we need to return from 1.0
        fk_cols_10 = mapping_details.get("fk_cols_10", {})

        if mssql_config:
            from_host = mssql_config.get("hostname")
            from_port = mssql_config.get("port")
            ssms_db_name = db_name_10
            from_user = mssql_config.get("user")
            from_db_type = mssql_config.get("from_db_type")
            from_pwd = mssql_config.get("password")
            from_driver = os.getenv("FROM_DB_DRIVER")
        else:
            logging.info("no mappings present for the configurations so returning the function")
            return True

        mssql_conn = self.create_connection(
            from_db_type,
            from_host,
            ssms_db_name,
            from_user,
            from_pwd,
            from_port,
            from_driver,
        )

        fk_values_dict = {}
        data_dict_total = data_dict["automation_data"]

        for key, value in data_dict_total.items():
            if key in tables_dict.keys():
                table_name_10 = tables_dict.get(key)
                for table_name in table_name_10:
                    # print(f"info {return_params_10}")
                    return_fk_col = return_params_10.get(table_name)
                    main_pgsql_dict = {key: [value]}
                    # print(f"main {main_pgsql_dict}")
                    data_10_mapping_dict = self.map_cols(
                        tables_dict, col_mappings, main_pgsql_dict
                    )
                    # print(f"data_10_mapping_dict {data_10_mapping_dict}")
                    for table_name_100, value_list in data_10_mapping_dict.items():
                        return_fk_col_val, fk_col_name = self.insert_data_to_db(
                            table_name_100,
                            value_list,
                            mssql_conn,
                            return_fk_col,
                            table_name_100,
                        )
                        fk_values_dict[fk_col_name] = return_fk_col_val
                # print(f"fk_values_dict {fk_values_dict}")
            else:
                if isinstance(value, list):
                    for item in value:
                        print(f"item {item}")

                        data_dict_item = self.ensure_values_are_lists(item)
                        data_mapping_dict = self.map_cols(
                            tables_dict, col_mappings, data_dict_item
                        )
                        # print(f"data mapping dict {data_mapping_dict}")
                        for table_name_10, data_list in data_mapping_dict.items():
                            # print(f"table and lists are {table_name_10},{data_list}")
                            if not data_list or data_list == [{}]:
                                # print(f"should skip {table_name_10}")
                                continue
                            fk_col_ = return_params_10.get(table_name_10)
                            if fk_col_:
                                # print('ifffff',table_name_10)
                                # print(f"daata {data_list}")
                                # print(f"fk cols is {fk_col_}")
                                automation_rule_followup_id, fk_col = (
                                    self.insert_data_to_db(
                                        table_name_10,
                                        data_list,
                                        mssql_conn,
                                        fk_col_,
                                        table_name_10,
                                    )
                                )
                                # print(f"id :{automation_rule_followup_id}, fk_col: {fk_col}")
                                fk_values_dict[fk_col] = automation_rule_followup_id
                            else:
                                fk_col_ = None
                                # print(f"111111111111111: In else:::table name {table_name_10}")
                                if table_name_10 in fk_cols_10.keys():
                                    # print(f"fks for this table {fk_cols_10[table_name_10]}")
                                    fk_cols_tables = fk_cols_10[table_name_10]
                                    reversed_fk_dict = {
                                        value: key
                                        for key, value in fk_cols_tables.items()
                                    }
                                    fk_col_names = [
                                        value
                                        for value in fk_cols_10[table_name_10].values()
                                    ]
                                    # print('############',fk_col_names)
                                    # print('@@@@@@@@@@@@@@@',fk_values_dict)
                                    # print(f"data list before {data_list}")
                                    for item in data_list:
                                        for key_col, data_val in item.items():
                                            # print(f"key {key_col},{data_val}")
                                            if key_col in fk_col_names:
                                                modified_fk_value = fk_values_dict.get(
                                                    reversed_fk_dict.get(key_col, None),
                                                    None,
                                                )
                                                # if modified_fk_value:
                                                item[key_col] = modified_fk_value
                                    # print(f"table name {table_name_10}, data {data_list}")

                                    insert = self.insert_data_to_db(
                                        table_name_10,
                                        data_list,
                                        mssql_conn,
                                        fk_col_,
                                        table_name_10,
                                    )

    def update_data_to_10_db(self, table_name, data_list, mssql_conn):
        try:
            logging.info("trying to insert a row using merge query")

            if not mssql_conn:
                raise ValueError("Invalid MSSQL connection")
            if not data_list:
                raise ValueError("Data list is empty")
            for row in data_list:
                cursor = mssql_conn.cursor()
                logging.info("entered into update part")
                logging.info(row.items())
                # column_names = ', '.join([key for key in row.keys() if key != 'Id'])
                # column_values = ', '.join([f"'{row[key]}'" for key in row.keys() if key != 'Id'])
                values_section = None
                for key in row.keys():
                    if row[key] is None:
                        if values_section:
                            values_section = values_section + ", " + f"{'NULL'}"
                        else:
                            values_section = f"{'NULL'}"
                    else:
                        if values_section:
                            values_section = values_section + ", " + f"'{row[key]}'"
                        else:
                            values_section = f"'{row[key]}'"

                source_columns = ", ".join([key for key in row.keys()])
                logging.info(values_section)
                logging.info(source_columns)

                source_columns = ", ".join([key for key in row.keys()])
                id_value = row["id"]

                # print("*******************", column_names, column_values)

                matched_update = ", ".join(
                    [
                        f"target.{key} = source.{key}"
                        for key in row.keys()
                        if key != "id"
                    ]
                )

                insert_columns = ", ".join([key for key in row.keys() if key != "id"])
                insert_values = ", ".join(
                    [f"source.{key}" for key in row.keys() if key != "id"]
                )
                logging.info("*******************", insert_columns, insert_values)

                # Construct the SQL MERGE query
                sql_merge_query = f"""
                    MERGE INTO {table_name} AS target
                    USING (VALUES ({values_section})) AS source ({source_columns})
                    ON target.id = source.id
                    WHEN MATCHED THEN
                    UPDATE SET {matched_update}
                    WHEN NOT MATCHED BY TARGET THEN
                    INSERT ({insert_columns}) VALUES ({insert_values})
                    OUTPUT INSERTED.id;
                    """
                logging.info(f"Merge Query {sql_merge_query}")

                cursor.execute(sql_merge_query)
                inserted_ids = cursor.fetchall()
                # inserted_ids=30
                if inserted_ids:

                    newly_inserted_id = inserted_ids[0][0]
                    logging.info(f"Newly inserted Id: {newly_inserted_id}")
                    logging.info(f"Newly inserted Id: {inserted_ids}")
                    mssql_conn.commit()
                    logging.info(
                        "merge query*******************************", sql_merge_query
                    )
                    # return newly_inserted_id
                    return {"id": newly_inserted_id}, {"id": id_value}

            cursor = mssql_conn.cursor()

        except Exception as e:
            logging.info(f"Error while inserting row into {table_name}: {e}")

    def save_data_to_10_single_table_db_config(
        self, transfer_name, postgres_data, update_flag=False, delete_flag=False
    ):
        try:
            logging.info(f"STARTING {transfer_name}")
            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            logging.info(
                f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}"
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_details_query = f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_config,db_name_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get("table_mapping_10_to_20", {})
            db_name_20 = mapping_details.get("db_name_20", {})
            db_name_10 = mapping_details.get("db_name_10", {})
            mssql_config = mapping_details.get("db_config")
            logging.info(f"db_name_20 is {db_name_20}")
            logging.info("mssql configurations", mssql_config)

            logging.info(
                f"type(tables_dict)----------{type(tables_dict)}"
            )  # 1.0 to 2.0 table mappings dict
            col_mappings = mapping_details.get("col_mapping_10_to_20", {})
            logging.info(type(col_mappings))  # 1.0 to 2.0 column mappings
            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})  # foreign key columns
            db_config = mapping_details.get("db_config", {})  # ssms db config details
            table_name_20 = mapping_details.get("table_mapping_10_to_20").keys()
            table_name_20 = ", ".join(str(key) for key in table_name_20)
            logging.info(f"table_name_20 is {table_name_20}")
            table_name_10 = tables_dict[table_name_20][0]
            logging.info(f"Table Name 1.0 is {table_name_10}")
            # update_flag=True
            hostname = os.getenv("LOCAL_DB_HOST")
            port = os.getenv("LOCAL_DB_PORT")
            db_name = db_name_20
            user = os.getenv("LOCAL_DB_USER")
            password = os.getenv("LOCAL_DB_PASSWORD")
            db_type = os.getenv("LOCAL_DB_TYPE")
            from_driver = os.getenv("LOCAL_DB_DRIVER")
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            postgres_data_copy = copy.deepcopy(postgres_data)
            logging.info("upadte_flag", update_flag, "delete_flag", delete_flag)

            if update_flag is True and delete_flag is False:
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                logging.info(f"id_10 is {id_10}")
                update_data["id_10"] = id_10
                postgres_data_20 = {table_name_20: [update_data]}
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data_20
                )
            elif update_flag is False and delete_flag is True:
                logging.info("Delete flag is false ")
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                logging.info(f"id_10 is {id_10}")
                update_data["id_10"] = id_10
                postgres_data_20 = {table_name_20: [update_data]}
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data_20
                )
            else:
                logging.info("delete and update flags are false")
                logging.info(f"tables_dict {tables_dict}")
                logging.info(f"postgress_data", postgres_data)
                logging.info(f"mapping_cols", col_mappings)
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data
                )
            logging.info(total_insert_dict)
            if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                logging.info("no mappings present for the configurations so returning the function")
                return True

            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn {mssql_conn}")
            logging.info(
                f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds"
            )
            logging.info(f"total insert dict {total_insert_dict}")

            return_ids = []
            fk_track_dict = {}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                # if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                logging.info(full_from_table)

                if return_params_10:
                    logging.info(f"Heree 2111 {return_params_10}")
                    return_col = return_params_10.get(
                        table_name_10, None
                    )  # get the col whose value should be returned for this table
                    fk_col_dict = fk_cols_10.get(
                        table_name_10, {}
                    )  # get the fk_col dict for this table
                else:
                    return_col = None
                    fk_col_dict = None

                if not return_col and not fk_col_dict:
                    logging.info(
                        "This part is to handle update tables don't have any foreign key columnc"
                    )

                    if update_flag is False and delete_flag is False:
                        logging.info(
                            "This part is used to insert records when update_flag and delete flag are false"
                        )
                        return_col = "ID"
                        return_val, return_fk_name = self.insert_data_to_db(
                            full_from_table,
                            total_insert_dict[table_name_10],
                            mssql_conn,
                            return_col,
                            table_name_10,
                        )
                        logging.info(
                            f"return val is {return_val} return fk name is {return_fk_name}"
                        )

                        update_postgres_data = postgres_data[table_name_20][0]
                        update_postgres_data["id_10"] = return_val
                        update_postgres_id = update_postgres_data["id"]
                        update_postgres_data.pop("id")
                        logging.info(f"update_postgres_data is {update_postgres_data}")
                        self.update_table(
                            postgres_conn1,
                            table_name_20,
                            update_postgres_data,
                            {"id": update_postgres_id},
                        )

                    else:
                        logging.info("update_flag is true ")
                        logging.info("full form table", full_from_table)
                        logging.info("table_name_10")
                        logging.info(total_insert_dict[table_name_10])
                        self.update_data_to_10_db(
                            full_from_table,
                            total_insert_dict[table_name_10],
                            mssql_conn,
                        )

        except Exception as e:
            logging.info(f"Error in carrier_rate_plan")

    def insert_data_cus_rare_plans(self, transfer_name, postgres_data):
        try:
            logging.info(f"STARTING {transfer_name}")
            load_dotenv()
            mapping_table = os.getenv("MAPPING_TABLE")
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_details_query = f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_config,db_name_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)
            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            db_name_10 = mapping_details.get("db_name_10", {})
            mssql_config = mapping_details.get("db_config")
            if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                logging.info("no mappings present for the configurations so returning the function")
                return True

            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            print(f"mssql_conn {mssql_conn}")

            postgres_data_df = pd.DataFrame(postgres_data)
            postgres_data_df["CreatedDate"] = postgres_data_df["CreatedDate"].astype(
                str
            )
            print(
                postgres_data_df.to_dict(),
                "postgres_data_dfpostgres_data_dfpostgres_data_df",
            )
            # Use the existing MSSQL connection
            cursor = (
                mssql_conn.cursor()
            )  # Replace self.mssql_conn with your connection object
            db_name_10 = os.getenv("FROM_DB_NAME")
            if transfer_name.startswith("customer_rate_plan_soc_code"):
                table_name = f"[{db_name_10}].[dbo].[CustomerRatePlan_JasperCarrierRatePlan]"
            elif transfer_name.startswith("customer_rate_planautomation_rule"):
                table_name = (
                    f"[{db_name_10}].[dbo].[AutomationRule_CustomerRatePlan]"
                )
            else:
                table_name = ""
            mssql_dict = postgres_data_df.to_dict(orient="records")[0]
            print(mssql_dict, "mssql_dictmssql_dictmssql_dict")
            columns = ", ".join(mssql_dict.keys())
            placeholders = ", ".join(["%s"] * len(mssql_dict))
            # if return_col:
            #     sql_query = f"INSERT INTO {table} ({columns}) OUTPUT INSERTED.{return_col} VALUES ({placeholders})"
            # else:
            sql_query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
            values = tuple(
                (
                    mssql_dict[col]
                    if isinstance(mssql_dict[col], (str, int, float, bool))
                    else json.dumps(
                        mssql_dict[col].item()
                        if isinstance(mssql_dict[col], (np.integer, np.floating))
                        else mssql_dict[col]
                    )
                )
                for col in mssql_dict.keys()
            )

            logging.info(f"Executing SQL Query: {sql_query}")
            logging.info(f"Values: {values}")
            cursor.execute(sql_query, values)

            # Commit the transaction
            mssql_conn.commit()
            logging.info("Data inserted successfully!")

        except Exception as e:
            logging.error(f"Error in insert_data_cus_rare_plans: {e}")
            mssql_conn.rollback()  # Rollback in case of error

    '''''
    def update_data_to_10_db_mssql_for_users(self,table_name,data_list,mssql_conn,conflict_col):
        try:
            logging.info("trying to insert a row using merge query")

            if not mssql_conn:
                raise ValueError("Invalid MSSQL connection")

            if not data_list:
                raise ValueError("Data list is empty")
            if not conflict_col:
                raise ValueError("Conflict columns list is empty.")
            cursor = mssql_conn.cursor()


            source_columns=', '.join([key for key in data_list.keys() ])
            values_section=None
            for key in data_list.keys():
                        if data_list[key] is None:
                            if values_section:
                                values_section=values_section+', '+f"{'NULL'}"
                            else:
                                values_section=f"{'NULL'}"
                        else:
                            if values_section:
                                values_section=values_section+', '+f"'{data_list[key]}'"
                            else:
                                values_section=f"'{data_list[key]}'"
            matched_update = ', '.join([f"target.{key} = source.{key}" for key in data_list.keys() if key not in conflict_col])
            insert_columns = ', '.join([key for key in data_list.keys() if key != 'id'])
            insert_values = ', '.join([f"source.{key}" for key in data_list.keys() if key != 'id'])
            logging.info("ented into update part **************************")

            logging.info("conflict_col",conflict_col)
            on_condition = ' AND '.join([f"target.{col} = source.{col}" for col in conflict_col])
            sql_merge_query = f"""
                    MERGE INTO {table_name} AS target
                    USING (VALUES ({values_section})) AS source ({source_columns})
                    ON  {on_condition}
                    WHEN MATCHED THEN
                    UPDATE SET {matched_update}
                    WHEN NOT MATCHED BY TARGET THEN
                    INSERT ({insert_columns}) VALUES ({insert_values})
                    OUTPUT INSERTED.id;
                    """
            logging.info(sql_merge_query)
            try:
                cursor.execute(sql_merge_query)
                mssql_conn.commit()  # Commit the transaction
                logging.info(f"Merge query executed successfully {table_name}")
            except Exception as e:
                mssql_conn.rollback()  # Rollback in case of an error
                logging.info(f"Error executing query: {e}",table_name)

            return None

        except Exception as e:
            logging.info(f"An error occurred: {e}")
            raise



        except Exception as e:
            logging.info(f" an error occured in updating {e}")

    def function_to_get_role_id(self, mssq_conn, table_name, column_name, value):
        try:
            sql_query = f'SELECT id FROM {table_name} WHERE {column_name} = %s'
            logging.info(sql_query)
            cursor = mssq_conn.cursor()
            cursor.execute(sql_query ,(value,))
            result = cursor.fetchone()

            if result:
            # If the result exists, return the id
                logging.info("role id is ",result[0])
                return result[0]

            else:
            # If no result is found, return None or a custom value
                return None

        except Exception as e:
            logging.info(f"Error: {e}")
            return None


    def insert_user_to_mssql_for_users(self,mssql_conn, table, mssql_dict,return_col=None):
        """
    Insert user data dynamically into an MSSQL table.

    Args:
        mssql_conn (pyodbc.Connection): The MSSQL connection.
        table (str): The name of the table to insert data into.
        mssql_dict (dict): Dictionary containing column names as keys and their values.
    """
        cursor = mssql_conn.cursor()
        if not mssql_dict or not table:
            raise ValueError("Table name and data dictionary cannot be empty.")
        columns = ', '.join(mssql_dict.keys())
        placeholders = ', '.join(['%s'] * len(mssql_dict))
        if return_col:
            sql_query = f"INSERT INTO {table} ({columns}) OUTPUT INSERTED.{return_col} VALUES ({placeholders})"
        else:
            sql_query = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
        values = tuple(
        mssql_dict[col] if isinstance(mssql_dict[col], (str, int, float, bool))
        else json.dumps(
            mssql_dict[col].item() if isinstance(mssql_dict[col], (np.integer, np.floating)) else mssql_dict[col]
        )
        for col in mssql_dict.keys()
        )
        try:
            logging.info(f"Executing SQL Query: {sql_query}")
            logging.info(f"Values: {values}")
            cursor.execute(sql_query, values)
            if return_col:
                inserted_value = cursor.fetchone()[0]
                mssql_conn.commit()  # Commit the transaction
                logging.info(f"Inserted record with {return_col}: {inserted_value}",table)
                return inserted_value
            else:
                mssql_conn.commit()
                logging.info("Record inserted successfully without returning a column.",table)
                return None
        except Exception as e:
            logging.info(f"Error while inserting record into {table}: {e}")
            mssql_conn.rollback()  # Rollback in case of error
            return None
        finally:
            cursor.close()
    def get_psql_user_id(self,psql_conn,table_name,condition_dict):
        print("Fetching user id from users table")
        conditions = " AND ".join([f"{key} = %s" for key in condition_dict])
        sql_query = f"SELECT id FROM {table_name} WHERE {conditions} ORDER BY id DESC LIMIT 1"
        condition_values = list(condition_dict.values())
        try:
            with psql_conn.cursor() as cursor:
                cursor.execute(sql_query, condition_values)
                result = cursor.fetchone()  # fetchone() returns the first row or None if no rows

            if result:
                print("the result id is ",result[0])
                return result[0]  # Returning the id (first column in the row)
            else:
                print("No matching record found.")
                return None

        except Exception as e:
                psql_conn.rollback()
                print(f"Error in updating {e}")



    def save_data_to_10_single_table_users(self,transfer_name,postgres_data,update_flag=False,delete_flag=False):
        try:
            logging.info(f"STARTING {transfer_name}")
            load_dotenv()
            hostname,port,user,password,db_type,db_name=self.load_env_pgsql()
            logging.info(f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}")
            mapping_table=os.getenv('MAPPING_TABLE')
            postgres_conn = self.create_connection(db_type, hostname, db_name, user, password, port)
            mapping_details_query=f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_config,db_name_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details=self.execute_query(postgres_conn,mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError("No Mappings present for transfer") #raising error if unable to get required data from db

            mapping_details=mapping_details.to_dict(orient='records')[0]
            tables_dict = mapping_details.get('table_mapping_10_to_20', {})
            db_name_20=mapping_details.get('db_name_20',{})
            db_name_10=mapping_details.get("db_name_10",{})
            mssql_config=mapping_details.get("db_config")
            col_mappings_10_to_20=mapping_details.get("col_mapping_10_to_20",{})
            data_container=key_name = list(tables_dict.keys())[0]
            postgres_copy=copy.deepcopy(postgres_data)
            hostname = os.getenv('LOCAL_DB_HOST')
            port = os.getenv('LOCAL_DB_PORT')
            db_name=db_name_20
            user = os.getenv('LOCAL_DB_USER')
            password = os.getenv('LOCAL_DB_PASSWORD')
            db_type = os.getenv('LOCAL_DB_TYPE')
            from_driver=os.getenv('LOCAL_DB_DRIVER')
            postgres_conn1 = self.create_connection(db_type, hostname, db_name, user, password, port)

            if not mssql_config :
                from_host,from_port,ssms_db_name,from_user,from_pwd,from_db_type,from_driver=self.load_env_mssql()
            else:
                from_host=mssql_config.get("hostname")
                from_port=mssql_config.get("port")
                ssms_db_name=db_name_10
                from_user=mssql_config.get("user")
                from_db_type=mssql_config.get("from_db_type")
                from_pwd=mssql_config.get("password")
                from_driver=os.getenv('FROM_DB_DRIVER')

            mssql_conn_start = time.time()
            mssql_conn=self.create_connection(from_db_type,from_host,ssms_db_name,from_user,from_pwd,from_port,from_driver)
            logging.info(f"mssql_conn {mssql_conn}")
            logging.info(f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds")
            data_dict=postgres_data[data_container][0]
            role_value=data_dict.get('role',{})
            role_id=self.function_to_get_role_id(mssql_conn,"role","Name",role_value)
            data_dict['role_id']=role_id

            if update_flag is False and delete_flag is False:
                print("getting id from users table")
                condition_dict={}
                condition_dict['username']=data_dict.get('username',{})
                condition_dict['role']=data_dict.get('role',{})
                condition_dict['email']=data_dict.get('email',{})
                condition_dict['tenant_id']=data_dict.get('tenant_id',{})
                print(condition_dict)
                user_id=self.get_psql_user_id(postgres_conn1,"users",condition_dict)
                id_20=data_dict.get("id",{})

            id_20=data_dict.get("id",{})

            tenant_name=data_dict.get("tenant_name")
            print("getting tenant id based on tenantname",tenant_name)
            tenant_id=self.function_to_get_role_id(mssql_conn,"tenant","Name",tenant_name)

            print("geted tenant ",tenant_id)
            data_dict['tenant_id']=tenant_id

            for table in tables_dict[data_container]:

                table_columns=col_mappings_10_to_20.get(table,{})
                mssql_dict={}
                for postgres_col, mssql_col in table_columns.items():
                    if postgres_col in data_dict:
                        mssql_dict[mssql_col] = data_dict[postgres_col]


                full_from_table=f'[{ssms_db_name}].[dbo].[{table}]'
                logging.info("MSSQL Data:", mssql_dict," MSSQL Table Name",full_from_table)

                if table=='user' and update_flag is False and delete_flag is False:
                    table_name_20='users'
                    logging.info("this part is only for users")
                    logging.info(full_from_table)
                    logging.info(mssql_dict)
                    return_val=self.insert_user_to_mssql_for_users(mssql_conn,full_from_table,mssql_dict,return_col='ID')
                    logging.info(f"return val is {return_val} return fk name is")
                    data_dict['user_id']=return_val
                    update_postgres_data={}
                    update_postgres_data['id']=return_val
                    update_postgres_id=id_20
                    logging.info(f"update_postgres_data is {update_postgres_data}",update_postgres_id)
                    self.update_table(postgres_conn1,table_name_20,update_postgres_data,{'id':update_postgres_id})

                elif update_flag is False and delete_flag is False:
                    self.insert_user_to_mssql_for_users(mssql_conn,full_from_table,mssql_dict,return_col=None)
                if update_flag is True and delete_flag is False:
                    if table=='user':

                        mssql_dict['id']=data_dict.get("id",{})

                        logging.info("to handle parts",table)
                        logging.info("printing data dict",mssql_dict)
                        self.update_data_to_10_db_mssql_for_users(full_from_table,mssql_dict,mssql_conn,conflict_col=["id"])
                    elif table=='user_role_site':
                        mssql_dict['userid']=data_dict.get("id",{})
                        conflict_col=['userid','tenantid']
                        logging.info(conflict_col,table)
                        self.update_data_to_10_db_mssql_for_users(full_from_table,mssql_dict,mssql_conn,conflict_col)
                    else:
                        mssql_dict['userid']=data_dict.get("id",{})
                        conflict_col=['userid']
                        self.update_data_to_10_db_mssql_for_users(full_from_table,mssql_dict,mssql_conn,conflict_col)

            return True

        except Exception as e:
            logging.info(f"Error in carrier_rate_plan {e}")''' ""

    def update_table_mssql(
        self, table_name, data_dict, mssql_conn, where_condition_dict
    ):
        """
        Updates a table in MSSQL based on the provided data_dict and where_condition_dict.

        :param table_name: The name of the table to update.
        :param data_dict: A dictionary where keys are column names and values are the values to update.
        :param mssql_conn: The MSSQL connection object.
        :param where_condition_dict: A dictionary specifying the WHERE clause conditions.
        """
        try:
            # Validate inputs
            if not table_name:
                raise ValueError("Table name cannot be empty.")
            if not data_dict:
                raise ValueError("Data dictionary cannot be empty.")
            if not where_condition_dict:
                raise ValueError("Where condition dictionary cannot be empty.")
            if not mssql_conn:
                raise ValueError("Invalid MSSQL connection.")

            # Prepare SET clause
            set_clause = []
            for col, value in data_dict.items():
                if value is None:
                    set_clause.append(f"{col} = NULL")
                elif isinstance(value, bool):
                    set_clause.append(f"{col} = {1 if value else 0}")
                elif isinstance(value, (int, float)):
                    set_clause.append(f"{col} = {value}")
                # elif isinstance(value, (str, bytes)):
                #     set_clause.append(f"{col} = '{value.replace('\'', '\'\'')}'")  # Escape single quotes
                elif isinstance(value, (datetime.date, datetime.datetime)):
                    set_clause.append(
                        f"{col} = '{value.isoformat()}'"
                    )  # Format date/time as ISO string
                else:
                    raise ValueError(
                        f"Unsupported data type for column {col}: {type(value)}"
                    )

            # Prepare WHERE clause
            where_clause = []
            for col, value in where_condition_dict.items():
                if value is None:
                    where_clause.append(f"{col} IS NULL")
                elif isinstance(value, bool):
                    where_clause.append(f"{col} = {1 if value else 0}")
                elif isinstance(value, (int, float)):
                    where_clause.append(f"{col} = {value}")
                # elif isinstance(value, (str, bytes)):
                #     where_clause.append(f"{col} = '{value.replace('\'', '\'\'')}'")  # Escape single quotes
                elif isinstance(value, (datetime.date, datetime.datetime)):
                    where_clause.append(
                        f"{col} = '{value.isoformat()}'"
                    )  # Format date/time as ISO string
                else:
                    raise ValueError(
                        f"Unsupported data type for WHERE condition {col}: {type(value)}"
                    )

            # Construct SQL query
            set_clause_str = ", ".join(set_clause)
            where_clause_str = " AND ".join(where_clause)
            sql_update_query = (
                f"UPDATE {table_name} SET {set_clause_str} WHERE {where_clause_str};"
            )
            logging.info(f"sql_update_query {sql_update_query}")

            # Execute the query
            try:
                # Create a cursor from the connection
                cursor = mssql_conn.cursor()

                # Execute the query
                cursor.execute(sql_update_query)

                # Commit the transaction
                mssql_conn.commit()
                logging.info(f"Update successful on table '{table_name}'.")
                logging.info("Query executed and committed successfully.")
            except Exception as e:
                # Rollback the transaction in case of an error
                mssql_conn.rollback()

                # Log the error with context
                logging.error(
                    f"Error in executing query: {sql_update_query}. Error: {e}"
                )
            finally:
                # Ensure the cursor is closed
                if cursor:
                    cursor.close()

            return True

        except Exception as e:
            # Rollback in case of an error
            if mssql_conn:
                mssql_conn.rollback()
            logging.error(f"Error executing update: {e}")
            raise

    def update_data_to_10_db_mssql_for_users(
        self, table_name, data_list, mssql_conn, conflict_col
    ):
        try:
            logging.info("trying to insert a row using merge query")

            if not mssql_conn:
                raise ValueError("Invalid MSSQL connection")

            if not data_list:
                raise ValueError("Data list is empty")
            if not conflict_col:
                raise ValueError("Conflict columns list is empty.")
            cursor = mssql_conn.cursor()

            source_columns = ", ".join([key for key in data_list.keys()])
            values_section = None
            for key in data_list.keys():
                if data_list[key] is None:
                    if values_section:
                        values_section = values_section + ", " + f"{'NULL'}"
                    else:
                        values_section = f"{'NULL'}"
                else:
                    if values_section:
                        values_section = values_section + ", " + f"'{data_list[key]}'"
                    else:
                        values_section = f"'{data_list[key]}'"
            matched_update = ", ".join(
                [
                    f"target.{key} = source.{key}"
                    for key in data_list.keys()
                    if key not in conflict_col
                ]
            )
            insert_columns = ", ".join([key for key in data_list.keys() if key != "id"])
            insert_values = ", ".join(
                [f"source.{key}" for key in data_list.keys() if key != "id"]
            )
            print("ented into update part **************************")

            logging.info(f"conflict_col {conflict_col}")
            on_condition = " AND ".join(
                [f"target.{col} = source.{col}" for col in conflict_col]
            )
            sql_merge_query = f"""
                    MERGE INTO {table_name} AS target
                    USING (VALUES ({values_section})) AS source ({source_columns})
                    ON  {on_condition}
                    WHEN MATCHED THEN
                    UPDATE SET {matched_update}
                    WHEN NOT MATCHED BY TARGET THEN
                    INSERT ({insert_columns}) VALUES ({insert_values})
                    OUTPUT INSERTED.id;
                    """
            logging.info(f"{sql_merge_query}")
            try:
                cursor.execute(sql_merge_query)
                mssql_conn.commit()  # Commit the transaction
                logging.info(f"Merge query executed successfully {table_name}")
            except Exception as e:
                mssql_conn.rollback()  # Rollback in case of an error
                logging.error(f"Error executing query: {e} , {table_name}")

            return None

        except Exception as e:
            logging.error(f"An error occurred: {e}")
            raise

        except Exception as e:
            logging.error(f" an error occured in updating {e}")

    def function_to_get_role_id(self, mssq_conn, table_name, column_name, value):
        try:
            sql_query = f"SELECT id FROM {table_name} WHERE {column_name} = %s"
            print(sql_query)
            cursor = mssq_conn.cursor()
            cursor.execute(sql_query, (value,))
            result = cursor.fetchone()

            if result:
                # If the result exists, return the id
                logging.info(f"Get Id is {result[0]}")
                return result[0]

            else:
                # If no result is found, return None or a custom value
                return None

        except Exception as e:
            logging.error(f"Error: {e}")
            return None

    def get_psql_user_id(self, psql_conn, table_name, condition_dict):
        logging.info("Fetching user id from users table")
        conditions = " AND ".join([f"{key} = %s" for key in condition_dict])
        sql_query = (
            f"SELECT id FROM {table_name} WHERE {conditions} ORDER BY id DESC LIMIT 1"
        )
        condition_values = list(condition_dict.values())
        try:
            with psql_conn.cursor() as cursor:
                cursor.execute(sql_query, condition_values)
                result = (
                    cursor.fetchone()
                )  # fetchone() returns the first row or None if no rows

            if result:
                logging.info(f"the result id is {result[0]}")
                return result[0]  # Returning the id (first column in the row)
            else:
                logging.warning("No matching record found.")
                return None

        except Exception as e:
            psql_conn.rollback()
            logging.error(f"Error in updating {e}")

    def insert_user_to_mssql_for_users(
        self, mssql_conn, table, mssql_dict, return_col=None
    ):
        """
        Insert user data dynamically into an MSSQL table.

        Args:
            mssql_conn (pyodbc.Connection): The MSSQL connection.
            table (str): The name of the table to insert data into.
            mssql_dict (dict): Dictionary containing column names as keys and their values.
        """
        cursor = mssql_conn.cursor()
        if not mssql_dict or not table:
            raise ValueError("Table name and data dictionary cannot be empty.")
        columns = ", ".join(mssql_dict.keys())
        placeholders = ", ".join(["%s"] * len(mssql_dict))
        if return_col:
            sql_query = f"INSERT INTO {table} ({columns}) OUTPUT INSERTED.{return_col} VALUES ({placeholders})"
            print(f"SQL Query {sql_query} return")
        else:
            sql_query = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
            print(f"SQL Query {sql_query} no return")
        values = tuple(
            (
                mssql_dict[col]
                if isinstance(mssql_dict[col], (str, int, float, bool))
                else json.dumps(
                    mssql_dict[col].item()
                    if isinstance(mssql_dict[col], (np.integer, np.floating))
                    else mssql_dict[col]
                )
            )
            for col in mssql_dict.keys()
        )
        try:
            logging.info(f"Executing SQL Query: {sql_query}")
            logging.info(f"Values: {values}")
            cursor.execute(sql_query, values)
            if return_col:
                inserted_value = cursor.fetchone()[0]
                mssql_conn.commit()  # Commit the transaction
                logging.info(
                    f"Inserted record with {return_col}: {inserted_value}", table
                )
                return inserted_value
            else:
                mssql_conn.commit()
                logging.info(
                    "Record inserted successfully without returning a column.", table
                )
                return None
        except Exception as e:
            logging.error(f"Error while inserting record into {table}: {e}")
            mssql_conn.rollback()  # Rollback in case of error
            return None
        finally:
            cursor.close()

    def save_data_to_10_single_table_users(
        self, transfer_name, postgres_data, update_flag=False, delete_flag=False
    ):
        try:
            logging.info(f"STARTING {transfer_name}")
            logging.info(f"postgres_data {postgres_data}")
            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            logging.info(
                f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}"
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_details_query = f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_config,db_name_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get("table_mapping_10_to_20", {})
            db_name_20 = mapping_details.get("db_name_20", {})
            db_name_10 = mapping_details.get("db_name_10", {})
            mssql_config = mapping_details.get("db_config")
            col_mappings_10_to_20 = mapping_details.get("col_mapping_10_to_20", {})
            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})
            data_container = key_name = list(tables_dict.keys())[0]
            logging.info(f"Data container{data_container}")
            postgres_copy = copy.deepcopy(postgres_data)
            hostname = os.getenv("LOCAL_DB_HOST")
            port = os.getenv("LOCAL_DB_PORT")
            db_name = db_name_20
            user = os.getenv("LOCAL_DB_USER")
            password = os.getenv("LOCAL_DB_PASSWORD")
            db_type = os.getenv("LOCAL_DB_TYPE")
            from_driver = os.getenv("LOCAL_DB_DRIVER")
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(f"Postgres conn {postgres_conn1}")

            if not mssql_config:
                logging.info("no mappings present for configurations")
                return True
            else:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")

            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn {mssql_conn}")
            #from_db_main = os.getenv("FROM_DB_NAME")
            #from_host_main = os.getenv("FROM_DB_HOST")

            mssql_conn_a = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn_a {mssql_conn_a}")

            print(
                f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds"
            )
            logging.info(f"postgres_data {postgres_data}")
            data_dict = postgres_data[data_container][0]
            logging.info(f"Data dict 1 {data_dict}")
            username = data_dict["username"]

            role_value = data_dict.get("role", {})
            logging.info(f"role value {role_value}")
            role_id = self.function_to_get_role_id(
                mssql_conn, "role", "Name", role_value
            )
            data_dict["role_id"] = role_id
            logging.info(f"Data dict after role id is {data_dict}")

            if "customers" in data_dict:
                # print(f"Customers val list {data_dict['customers']}, {type(data_dict['customers'])}")

                # print(f"json {json.dumps(data_dict['customers'])}")
                customers_json_dumps = data_dict["customers"]
                if customers_json_dumps:
                    customers_json = json.loads(customers_json_dumps)
                    logging.info(f"here {customers_json} type {type(customers_json)}")
                    customer_name = customers_json[0]
                    logging.info(
                        f"Customer name is {customer_name} and type is {type(customer_name)}"
                    )
                    db_name_10 = os.getenv("FROM_DB_NAME")
                    customer_id_query = f"select top 1 id from {db_name_10}.dbo.Site where Name='{customer_name}' and isactive=1 and tenantid=1 order by id desc;"
                    customer_id_query = self.execute_query(
                        mssql_conn_a, customer_id_query
                    )
                    customer_id = customer_id_query["id"][0]
                    logging.info(f"Customer name is {customer_name} and {customer_id}")
                else:
                    customer_id = None

            tenant_name = data_dict.get("tenant_name")
            if (
                tenant_name.lower() == "altaworx"
                or tenant_name.lower() == "altaworx test"
                or tenant_name.lower() == "altaworx_test"
            ):
                data_dict["tenant_id"] = 1
                tenant_id = 1
            else:
                logging.info(f"getting tenant id based on tenantname {tenant_name}")
                tenant_id = self.function_to_get_role_id(
                    mssql_conn, "tenant", "Name", tenant_name
                )

            if "id" not in data_dict:
                get_id_20_query = f"select id from users where username='{username}' and role='{role_value}' and tenant_name='{tenant_name}' and is_active is true"
                logging.info(f"query is {get_id_20_query}")
                get_id_20_query = self.execute_query(postgres_conn1, get_id_20_query)
                get_id_20 = get_id_20_query["id"][0]
                logging.info(f"Id 20 is {get_id_20}")
                data_dict["id"] = int(get_id_20)
            else:
                id_20 = data_dict["id"]

            logging.info(f" tenant id got is {tenant_id} ")
            data_dict["tenant_id"] = tenant_id
            logging.info(f"Data dict aafter adding tenant id {data_dict}")
            id_20 = data_dict.get("id", {})

            total_dict = copy.deepcopy(postgres_data)

            total_dict["users"] = [data_dict]
            logging.info(f"Final Total dict is {total_dict}")
            total_insert_dict = self.map_cols(
                tables_dict, col_mappings_10_to_20, total_dict
            )
            logging.info(f"total mapping dict got is {total_insert_dict}")

            if delete_flag is True and update_flag is False:
                logging.info(f"Delete is {delete_flag}")
                if "id" not in data_dict:
                    get_10_ids_query = f"select user_id_10,user_role_id_10,user_role_site_id_10 from users where username='{username}' and role='{role_value}' and tenant_name='{tenant_name}' and is_active is true order by id desc limit 1"
                else:
                    id_20 = data_dict["id"]
                    get_10_ids_query = f"select user_id_10,user_role_id_10,user_role_site_id_10 from users where id={id_20} order by id desc limit 1"
                get_10_ids_query = self.execute_query(postgres_conn1, get_10_ids_query)
                logging.info(f"get 1.0 ids are {get_10_ids_query}")
                get_10_ids = get_10_ids_query.to_dict(orient="records")
                get_10_ids = get_10_ids[0]
                logging.info(f"1.0 Ids dict is {get_10_ids}")
                tables_10 = tables_dict["users"]
                logging.info(f"Tables in 1.0 are {tables_10}")
                for table_name_10 in tables_10:
                    if not self.is_valid_table_name(table_name_10):
                        full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                        logging.info(f"Full from table is {full_from_table}")
                    table_id_mapping = {
                        "user": "user_id_10",
                        "user_role": "user_role_id_10",
                        "user_role_site": "user_role_site_id_10",
                    }
                    if table_name_10 in table_id_mapping:
                        logging.info(f"Deleting from table {table_name_10}")
                        main_id_10 = get_10_ids[table_id_mapping[table_name_10]]
                        logging.info(f"main id 10 is {main_id_10}")
                        data_dict_update = {"IsActive": 0, "IsDeleted": 1}

                        # Call the update function
                        uu = self.update_table_mssql(
                            full_from_table,
                            data_dict_update,
                            mssql_conn,
                            {"id": main_id_10},
                        )

            elif update_flag is True and delete_flag is False:
                logging.info(f"Code for Update Starting................")
                if "id" not in data_dict:
                    get_10_ids_query = f"select user_id_10,user_role_id_10,user_role_site_id_10 from users where username='{username}' and role='{role_value}' and tenant_name='{tenant_name}' and is_active is true order by id desc limit 1"
                else:
                    id_20 = data_dict["id"]
                    get_10_ids_query = f"select user_id_10,user_role_id_10,user_role_site_id_10 from users where id={id_20} order by id desc limit 1"
                get_10_ids_query = self.execute_query(postgres_conn1, get_10_ids_query)
                logging.info(f"get 1.0 ids are {get_10_ids_query}")
                get_10_ids = get_10_ids_query.to_dict(orient="records")
                logging.info(f"1.0 Ids dict is {get_10_ids}")

                for table_name_10, data_list in total_insert_dict.items():
                    if not self.is_valid_table_name(table_name_10):
                        full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                        logging.info(f"Full from table is {full_from_table}")

                    if table_name_10 == "user":
                        logging.info(f"Updating users data..............")
                        table_name_20 = "users"
                        users_dict = data_list[0]
                        users_dict["id"] = get_10_ids[0]["user_id_10"]
                        logging.info(f"1.0  User is {get_10_ids[0]['user_id_10']}")
                        return_val = self.update_data_to_10_db_mssql_for_users(
                            full_from_table, users_dict, mssql_conn, ["id"]
                        )

                    elif table_name_10 == "user_role":
                        logging.info(f"Updating for table {table_name_10}")
                        user_role_data = data_list[0]
                        if "userid" not in user_role_data:
                            user_role_data["userid"] = get_10_ids[0]["user_id_10"]
                            user_role_data["roleid"] = role_id
                            user_role_data["id"] = get_10_ids[0]["user_role_id_10"]
                        logging.info(
                            f"1.0 user_role table id to be updated is {user_role_data['id']}"
                        )
                        return_val = self.update_data_to_10_db_mssql_for_users(
                            full_from_table, user_role_data, mssql_conn, ["id"]
                        )

                    elif table_name_10 == "user_role_site":
                        logging.info(f"User role site Updating")
                        table_name_20 = "users"
                        user_role_site_data = data_list[0]
                        if (
                            "userid" not in user_role_site_data
                            or "roleid" not in user_role_site_data
                        ):
                            user_role_site_data["userid"] = get_10_ids[0]["user_id_10"]
                            user_role_site_data["roleid"] = role_id
                            user_role_site_data["siteid"] = customer_id
                            user_role_site_data["id"] = get_10_ids[0][
                                "user_role_site_id_10"
                            ]
                        logging.info(
                            f"user_role_site_data update data is {user_role_site_data}"
                        )
                        logging.info(f"Update id is {user_role_site_data['id']}")
                        return_val = self.update_data_to_10_db_mssql_for_users(
                            full_from_table, user_role_site_data, mssql_conn, ["id"]
                        )

            elif update_flag is False and delete_flag is False:
                logging.info(f"In Insert Part--------------")
                return_val_dict = {}

                for table_name_10, data_list in total_insert_dict.items():
                    # if the table name in not mssql format -- modifying it
                    if not self.is_valid_table_name(table_name_10):
                        full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                        logging.info(f"Full from table is {full_from_table}")

                    if return_params_10:
                        logging.info(f"Return params {return_params_10}")
                        return_col = return_params_10.get(
                            table_name_10, None
                        )  # get the col whose value should be returned for this table
                        fk_col_dict = fk_cols_10.get(
                            table_name_10, {}
                        )  # get the fk_col dict for this table
                    else:
                        return_col = None
                        fk_col_dict = None

                    if table_name_10 == "user":
                        logging.info(f"Inserting users data..............")
                        table_name_20 = "users"
                        users_dict = data_list[0]
                        return_val = self.insert_user_to_mssql_for_users(
                            mssql_conn, full_from_table, users_dict, return_col="ID"
                        )
                        logging.info(
                            f"return val is {return_val} return fk name is, return val type is {type(return_val)}"
                        )
                        data_dict["id_10"] = return_val
                        return_val_dict["user"] = return_val
                        update_postgres_data = {}
                        update_postgres_data["user_id_10"] = return_val
                        update_postgres_id = id_20
                        logging.info(
                            f"update_postgres_data is {update_postgres_data} {update_postgres_id}"
                        )
                        self.update_table(
                            postgres_conn1,
                            table_name_20,
                            update_postgres_data,
                            {"id": int(id_20)},
                        )
                        logging.info(f"Update done {id_20}")

                    elif table_name_10 == "user_role":
                        table_name_20 = "users"
                        user_role_data = data_list[0]
                        if "userid" not in user_role_data:
                            logging.info(
                                f"Subbing {return_val_dict['user']} and {role_id}"
                            )
                            user_role_data["userid"] = return_val_dict["user"]
                            user_role_data["roleid"] = role_id
                        logging.info(f"User Role insert data is {user_role_data}")
                        return_value = self.insert_user_to_mssql_for_users(
                            mssql_conn, full_from_table, user_role_data, return_col="ID"
                        )
                        logging.info(
                            f"return val is {return_val} return val type is {type(return_val)}"
                        )
                        logging.info(f"Updating 1.0 id {return_value} in {id_20}")
                        self.update_table(
                            postgres_conn1,
                            table_name_20,
                            {"user_role_id_10": int(return_value)},
                            {"id": int(id_20)},
                        )
                        logging.info(f"Update done {id_20}")

                    elif table_name_10 == "user_role_site":
                        logging.info(f"User role site insertion")
                        table_name_20 = "users"
                        user_role_site_data = data_list[0]
                        if (
                            "userid" not in user_role_site_data
                            or "roleid" not in user_role_site_data
                        ):
                            user_role_site_data["userid"] = return_val_dict["user"]
                            user_role_site_data["roleid"] = role_id
                            user_role_site_data["siteid"] = customer_id
                        logging.info(
                            f"user_role_site_data insert data is {user_role_site_data}"
                        )
                        return_value = self.insert_user_to_mssql_for_users(
                            mssql_conn,
                            full_from_table,
                            user_role_site_data,
                            return_col="ID",
                        )
                        logging.info(
                            f"return val is {return_val} return val type is {type(return_val)}"
                        )
                        logging.info(f"Updating 1.0 id {return_value} in {id_20}")
                        self.update_table(
                            postgres_conn1,
                            table_name_20,
                            {"user_role_site_id_10": int(return_value)},
                            {"id": int(id_20)},
                        )
                        logging.info(f"Update done {id_20}")

            return True

        except Exception as e:
            logging.error(f"Error in Users live sync {e}")

    def saving_revio_push_customer_charge_type(self, data_dict, update_id_dict):
        try:
            logging.info(f"Input data dict is {data_dict}")
            load_dotenv()
            multi_tenant_host = os.getenv("BASE_MULTI_TENANT_HOST")
            port = os.getenv("FROM_DB_PORT")
            user = os.getenv("FROM_DB_USER")
            password = os.getenv("FROM_DB_PASSWORD")
            db_type = os.getenv("FROM_DB_TYPE")
            db_name = os.getenv("BASE_MULTI_TENANT_DB")
            driver = os.getenv("FROM_DB_DRIVER")
            multi_tenant_conn = self.create_connection(
                db_type, multi_tenant_host, db_name, user, password, port, driver
            )
            logging.info(f"multi tenant connn is {multi_tenant_conn}")
            update_value = data_dict["Rev.IO Push Customer Charge Type"]
            logging.info(f"update_value is {update_value}")

            try:
                cursor = multi_tenant_conn.cursor()

                # Loop through the data_dict to update records
                for key, update_value in data_dict.items():
                    if (
                        key in update_id_dict
                    ):  # Check if the key exists in update_id_dict
                        object_id = update_id_dict[
                            key
                        ]  # Get the corresponding ObjectId
                        logging.info(
                            f"Updating ObjectId {object_id} with value {update_value}"
                        )

                        # Update query with parameterized inputs
                        update_query = """
                            UPDATE CustomObject
                            SET CustomName = %s
                            WHERE ObjectId = %s AND TenantId = 1;
                        """
                        cursor.execute(
                            update_query, (update_value, object_id)
                        )  # Parameterized query for safety

                # Commit the transaction after all updates
                multi_tenant_conn.commit()
                logging.info(f"Update successful for all records.")
            except Exception as e:
                # Rollback in case of any error
                multi_tenant_conn.rollback()
                logging.error(f"Error occurred while executing the query: {e}")
            finally:
                # Close the cursor and connection
                cursor.close()
                multi_tenant_conn.close()
        except Exception as e:
            logging.error(
                f"Error occurred while saving_revio_push_customer_charge_type {e}"
            )

    def update_optimization_seetings(self, data_sent, table_name, mssql_conn):
        try:
            logging.info("entered this part")
            logging.info("data_sent", data_sent)
            extract_values = list(data_sent["optimizationsetting"][0].keys())
            logging.info("0000", extract_values)

            keys_to_check = [
                "Rev.IO FTP Password",
                "Rev.IO FTP Username",
                "Rev.IO Push Customer Charge Type",
                "Rev.IO FTP Host",
                "Rev.IO FTP Path",
            ]

            update_id_dict = {
                "Rev.IO FTP Host": 28,
                "Rev.IO FTP Username": 29,
                "Rev.IO FTP Password": 30,
                "Rev.IO FTP Path": 31,
                "Rev.IO Push Customer Charge Type": 32,
            }

            rev_data_setting = {}
            data_sent_copy = copy.deepcopy(data_sent)
            for key_item in keys_to_check:
                if (
                    key_item in extract_values
                ):  # Assuming extract_values is a list or set
                    # Extract the key-value pair for the current key_item
                    extracted_value = {
                        key_item: data_sent_copy["optimizationsetting"][0][key_item]
                    }
                    logging.info(f"Extracted value {extracted_value}")

                    # Update rev_data_setting with the extracted value
                    rev_data_setting.update(extracted_value)

            logging.info(f"The final update dict is {rev_data_setting}")
            if rev_data_setting:
                logging.info(f"ReRouting to save some rev settings")
                ss = self.saving_revio_push_customer_charge_type(
                    rev_data_setting, update_id_dict
                )

            # if 'Rev.IO Push Customer Charge Type' in extract_values:
            #     print(f"Need to re route hereeeeee")
            #     data_sent_copy=copy.deepcopy(data_sent)
            #     rev_data_setting={key: value for key, value in data_sent_copy['optimizationsetting'][0].items() if key == 'Rev.IO Push Customer Charge Type'}
            #     ss=self.saving_revio_push_customer_charge_type(rev_data_setting)
            filtered_keys = [
                key
                for key in extract_values
                if key
                not in [
                    "modifiedBy",
                    "modifiedDate",
                    "deletedBy",
                    "isDeleted",
                    "canOverride",
                    "Rev.IO FTP Password",
                    "Rev.IO FTP Username",
                    "Rev.IO Push Customer Charge Type",
                    "Rev.IO FTP Host",
                    "Rev.IO FTP Path",
                ]
            ]

            logging.info("Filtered Keys:", filtered_keys)
            filtered_values = [
                data_sent["optimizationsetting"][0][key] for key in filtered_keys
            ]
            logging.info("Filtered Values:", filtered_values)
            modified_by = data_sent["optimizationsetting"][0].get(
                "modifiedBy", "default_user"
            )
            modified_date = "CURRENT_TIMESTAMP"
            set_clause = f"modifiedBy = '{modified_by}', modifiedDate = {modified_date}, settingvalue = CASE"
            for key, value in zip(filtered_keys, filtered_values):
                set_clause += f" WHEN settingkey = '{key}' THEN '{value}'"
            set_clause += " END"
            logging.info("SET Clause:", set_clause)
            where_clause = " OR ".join(
                [f"settingkey = '{key}'" for key in filtered_keys]
            )
            logging.info("WHERE Clause:", where_clause)
            update_query = f"UPDATE {table_name} SET {set_clause} WHERE {where_clause};"
            logging.info("Generated Update Query:", update_query)
            with mssql_conn.cursor() as cursor:
                try:
                    cursor.execute(update_query)
                    mssql_conn.commit()  # Commit the changes if successful
                    logging.info("Update successful!")
                except Exception as query_error:
                    logging.info(f"Error during query execution: {query_error}")
                    mssql_conn.rollback()  # Rollback in case of error during query execution
                    logging.info("Rollback executed due to query error.")
            return None
        except Exception as e:
            logging.info(f"an error occured while update {e}")

    def replace_bool_strings(self, data):
        # Check if the current item is a dictionary
        if isinstance(data, dict):
            return {
                key: self.replace_bool_strings(value) for key, value in data.items()
            }
        # Check if the current item is a list
        elif isinstance(data, list):
            return [self.replace_bool_strings(item) for item in data]
        # Replace string 'True'/'False' with boolean True/False
        elif data == "True":
            return 1
        elif data == "False":
            return 0
        # Return the item as is if no replacement is needed
        else:
            return data
    def generate_and_execute_merge_query(self,mssql_con, table_name, insert_data, conflict_cols):
        """
        Generate and execute a SQL Server MERGE statement based on conflict columns.

        :param mssql_con: pyodbc.Connection, active MSSQL connection
        :param table_name: str, name of the table (e.g., 'optimizationsettingtenantoverride')
        :param insert_data: dict, single-row dictionary of column-value pairs
        :param conflict_cols: list of str, columns that define the conflict
        :return: None
        """
        # Build USING source table from VALUES
        columns = list(insert_data.keys())
        values = [f"'{v}'" if isinstance(v, str) else str(v) for v in insert_data.values()]
        source_alias = "src"
        target_alias = "tgt"

        using_clause = f"(VALUES ({', '.join(values)})) AS {source_alias} ({', '.join(columns)})"
        on_clause = " AND ".join([f"{target_alias}.{col} = {source_alias}.{col}" for col in conflict_cols])
        update_cols = [col for col in columns if col not in conflict_cols]
        set_clause = ", ".join([f"{col} = {source_alias}.{col}" for col in update_cols]) if update_cols else "-- no update"
        insert_cols = ", ".join(columns)
        insert_vals = ", ".join([f"{source_alias}.{col}" for col in columns])

        merge_sql = f"""
        MERGE INTO {table_name} AS {target_alias}
        USING {using_clause}
        ON {on_clause}
        WHEN MATCHED THEN
            UPDATE SET {set_clause}
        WHEN NOT MATCHED THEN
            INSERT ({insert_cols})
            VALUES ({insert_vals});
        """
        logging.info(f"constructed merge query is {merge_sql}")

        try:
            cursor = mssql_con.cursor()
            cursor.execute(merge_sql)
            mssql_con.commit()
            logging.info(f" MERGE successful for {insert_data}")
        except Exception as e:
            logging.info(f" Error during MERGE for {insert_data}: {e}")

    def optimization_setting_function(
        self, transfer_name, postgres_data, update_flag, delete_flag,tenant_name,sub_tenant_name
    ):
        try:
            logging.info(f"STARTING {transfer_name}")
            if sub_tenant_name:
                logging.info(f"sub tenant optimization settings sync {sub_tenant_name}")
                transfer_name = f"optimization_setting_tenant_over_ride_{tenant_name.lower()}"
                sub_tenants_json=self.tenant_load_json()
                logging.info(f"save_data_20_from_10 tenant_name is {tenant_name} getting sub tenant {sub_tenants_json}")
                subtenant_id = self.get_subtenant_id_by_name(sub_tenant_name, sub_tenants_json)
                logging.info(f"subtenant_id gotten is {subtenant_id} {transfer_name}")
            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            logging.info(
                f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}"
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_details_query = f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_name_10,db_config from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get("table_mapping_10_to_20", {})
            db_name_20 = mapping_details.get("db_name_20", {})
            mssql_config = mapping_details.get("db_config", {})
            db_name_10 = mapping_details.get("db_name_10", {})
            logging.info(f"db_name_20 is {db_name_20}")
            logging.info(
                f"type(tables_dict)----------{type(tables_dict)}"
            )  # 1.0 to 2.0 table mappings dict

            col_mappings = mapping_details.get("col_mapping_10_to_20", {})
            logging.info(type(col_mappings))  # 1.0 to 2.0 column mappings
            logging.info(col_mappings)

            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})  # foreign key columns
            db_config = mapping_details.get("db_config", {})  # ssms db config details
            table_name_20 = mapping_details.get("table_mapping_10_to_20").keys()
            table_name_20 = ", ".join(str(key) for key in table_name_20)
            logging.info(f"table_name_20 is {table_name_20}")
            table_name_10 = tables_dict[table_name_20][0]
            logging.info(f"Table Name 1.0 is {table_name_10}")
            # update_flag=True
            hostname = os.getenv("LOCAL_DB_HOST")
            port = os.getenv("LOCAL_DB_PORT")
            db_name = db_name_20
            user = os.getenv("LOCAL_DB_USER")
            password = os.getenv("LOCAL_DB_PASSWORD")
            db_type = os.getenv("LOCAL_DB_TYPE")
            from_driver = os.getenv("LOCAL_DB_DRIVER")
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(update_flag)

            postgres_data_copy = copy.deepcopy(postgres_data)
            if delete_flag is True and update_flag is False:
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                update_data["id_10"] = id_10
                logging.info(f"id_10 is {id_10}")
                delete_data = self.delete_data_from_10(
                    transfer_name, postgres_data, id_10, table_name_10
                )
                return True

            elif update_flag is True and delete_flag is False:
                logging.info("update flag is true-------------------------")
                logging.info("postgress data", postgres_data)
                logging.info("col mappings", col_mappings)


                '''(
                    from_host,
                    from_port,
                    ssms_db_name,
                    from_user,
                    from_pwd,
                    from_db_type,
                    from_driver,
                ) = self.load_env_mssql()'''
                if mssql_config:
                    from_host = mssql_config.get("hostname")
                    from_port = mssql_config.get("port")
                    ssms_db_name = db_name_10
                    from_user = mssql_config.get("user")
                    from_db_type = mssql_config.get("from_db_type")
                    from_pwd = mssql_config.get("password")
                    from_driver = os.getenv("FROM_DB_DRIVER")
                else:
                    logging.info("no mappings present for the configurations so returning the function")
                    return True


                mssql_conn_start = time.time()
                mssql_conn = self.create_connection(
                    from_db_type,
                    from_host,
                    ssms_db_name,
                    from_user,
                    from_pwd,
                    from_port,
                    from_driver,
                )
                logging.info(f"mssql_conn {mssql_conn}")
                logging.info(
                    f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds"
                )
                if sub_tenant_name:
                    condition_dict={"SettingKey":"OptIntoContinuousLastDayOptimization"}
                    full_from_table = f"[{ssms_db_name}].[dbo].[OptimizationSetting]"
                    optimization_setting_id=self.function_to_get_user_id_include_null(mssql_conn,full_from_table,condition_dict)
                    logging.info(f"postgres_data is {postgres_data}")
                    if 'optimization_setting' in postgres_data and postgres_data['optimization_setting']:
                        postgres_data['optimization_setting'][0]['optimization_setting_id'] = optimization_setting_id
                        logging.info(f"{postgres_data}")
                    else:
                        logging.info(f"No optimization_setting data found to update.")
                    total_insert_dict = self.map_cols(
                        tables_dict, col_mappings, postgres_data
                    )
                    logging.info(f"total_insert_dict {total_insert_dict}")
                    conflict_columns = ["tenantid", "optimizationsettingid"]
                    for table_name_10, data_list in total_insert_dict.items():
                    # if the table name in not mssql format -- modifying it
                        if not self.is_valid_table_name(table_name_10):
                            full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                        logging.info(f" data list gotten is {data_list}")
                        for data in data_list:
                            self.generate_and_execute_merge_query(
                        mssql_con=mssql_conn,
                        table_name=full_from_table,
                        insert_data=data,
                        conflict_cols=conflict_columns
                        )
                        return True
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data
                )
                logging.info(f"@@@@@@@@@@@@@ {total_insert_dict}")
                updated_data = total_insert_dict.get("optimizationsetting")[0]
                logging.info(f"total insert dict {total_insert_dict}")
                total_insert_data_ = self.replace_bool_strings(total_insert_dict)
                logging.info(f"total insert data {total_insert_data_}")

                for table_name_10, data_list in total_insert_dict.items():
                    # if the table name in not mssql format -- modifying it
                    if not self.is_valid_table_name(table_name_10):
                        full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                logging.info(full_from_table)

                self.update_optimization_seetings(
                    total_insert_data_, full_from_table, mssql_conn
                )
                return None
            else:
                logging.info(f"tables_dict {tables_dict}")
                logging.info("col mappings", col_mappings)
                logging.info(postgres_data)
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data
                )
            logging.info(f"total insert dict is {total_insert_dict}")

            '''(
                from_host,
                from_port,
                ssms_db_name,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()'''
            if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                logging.info("no mappings present for the configurations so returning the function")
                return True
            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn {mssql_conn}")
            logging.info(
                f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds"
            )
            logging.info(f"total insert dict {total_insert_dict}")

            return_ids = []
            fk_track_dict = {}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                # if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"

        except Exception as e:
            logging.info(f"Error in {transfer_name} {e}")
        return None

    def update_data_to_10_db_rules(self, table_name, data_list, mssql_conn):
        try:
            logging.info("trying to insert a row using merge query")
            if not mssql_conn:
                raise ValueError("Invalid MSSQL connection")
            if not data_list:
                raise ValueError("Data list is empty")
            for row in data_list:
                cursor = mssql_conn.cursor()
                logging.info("entered into update part")
                logging.info(row.items())
                values_section = None
                for key in row.keys():
                    if row[key] is None:
                        if values_section:
                            values_section = values_section + ", " + f"{'NULL'}"
                        else:
                            values_section = f"{'NULL'}"
                    else:
                        if values_section:
                            values_section = values_section + ", " + f"'{row[key]}'"
                        else:
                            values_section = f"'{row[key]}'"

                source_columns = ", ".join([key for key in row.keys()])
                logging.info(values_section)
                logging.info(source_columns)
                source_columns = ", ".join([key for key in row.keys()])
                matched_update = ", ".join(
                    [
                        f"target.{key} = source.{key}"
                        for key in row.keys()
                        if key != "id"
                    ]
                )

                insert_columns = ", ".join([key for key in row.keys() if key != "id"])
                insert_values = ", ".join(
                    [f"source.{key}" for key in row.keys() if key != "id"]
                )
                logging.info("*******************", insert_columns, insert_values)

                # Construct the SQL MERGE query
                sql_merge_query = f"""
                    MERGE INTO {table_name} AS target
                    USING (VALUES ({values_section})) AS source ({source_columns})
                    ON target.id = source.id
                    WHEN MATCHED THEN
                    UPDATE SET {matched_update}
                    WHEN NOT MATCHED BY TARGET THEN
                    INSERT ({insert_columns}) VALUES ({insert_values})
                    OUTPUT INSERTED.id;
                    """
                logging.info(f"Merge Query {sql_merge_query}")

                cursor.execute(sql_merge_query)
                inserted_ids = cursor.fetchall()
                if inserted_ids:

                    newly_inserted_id = inserted_ids[0][0]
                    logging.info(f"Newly inserted Id: {newly_inserted_id}")
                    logging.info(f"Newly inserted Id: {inserted_ids}")
                    mssql_conn.commit()
                    logging.info(
                        f"merge query******************************* {sql_merge_query}"
                    )
                    # return newly_inserted_id
                    return {"id": newly_inserted_id}

            cursor = mssql_conn.cursor()

        except Exception as e:
            logging.info(f"Error while inserting row into {table_name}: {e}")

    '''def insert_automation_rule_table_data_with_psql(
        self, transfer_name, data_dict, update_flag=False, delete_flag=False
    ):
        logging.info("starting Automation rule tables sync")
        load_dotenv()
        hostname, port, user, password, db_type, db_name = self.load_env_pgsql()

        postgres_conn1 = self.create_connection(
            db_type, hostname, db_name, user, password, port
        )
        mapping_table = os.getenv("MAPPING_TABLE")

        mapping_details_query = f"select table_mapping_10_to_20,col_mapping_10_to_20,return_params_10,fk_cols_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
        logging.info(f"query {mapping_details_query}")
        mapping_details = self.execute_query(postgres_conn1, mapping_details_query)
        logging.info(f"mapping_details {mapping_details}")
        mapping_details = mapping_details.to_dict(orient="records")[0]

        tables_dict = mapping_details.get("table_mapping_10_to_20", {})
        logging.info(f"Tables dict is {tables_dict}")  # 1.0 to 2.0 table mappings dict
        col_mappings = mapping_details.get("col_mapping_10_to_20", {})
        # print(f"col_mappings are {col_mappings}")   # 1.0 to 2.0 column mappings
        return_params_10 = mapping_details.get("return_params_10", {})
        logging.info(
            f"return params {return_params_10}"
        )  # cols data that we need to return from 1.0
        fk_cols_10 = mapping_details.get("fk_cols_10", {})
        # print(f"fk cols 10 are {fk_cols_10}")            # foreign key columns
        db_config = mapping_details.get("db_config", {})

        (
            from_host,
            from_port,
            ssms_db_name,
            from_user,
            from_pwd,
            from_db_type,
            from_driver,
        ) = self.load_env_mssql()
        mssql_conn = self.create_connection(
            from_db_type,
            from_host,
            ssms_db_name,
            from_user,
            from_pwd,
            from_port,
            from_driver,
        )

        fk_values_dict = {}
        data_dict_total = data_dict["automation_data"]
        automation_rule_id = None
        automation_rule_follow_up_id = None
        load_dotenv()
        hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
        db_name = "altaworx_test"
        postgres_conn_test = self.create_connection(
            db_type, hostname, db_name, user, password, port
        )
        for key, value in data_dict_total.items():
            if key in tables_dict.keys():
                table_name_10 = tables_dict.get(key)
                for table_name in table_name_10:
                    logging.info(f"@@@@@@@@@@@@@@@@@@@@ {table_name}")
                    if table_name == "AutomationRule":

                        full_from_table = f"[{ssms_db_name}].[dbo].[{table_name}]"
                        main_pgsql_dict = {key: [value]}
                        condition_dict = value
                        table_name_20 = key
                        id_20 = self.function_to_get_user_id(
                            postgres_conn_test, table_name_20, condition_dict
                        )
                        data_10_mapping_dict = self.map_cols(
                            tables_dict, col_mappings, main_pgsql_dict
                        )
                        # print(data_10_mapping_dict)
                        # print(data_10_mapping_dict)
                        data_dict = data_10_mapping_dict.get(table_name)
                        if update_flag == False and delete_flag == False:
                            logging.info(
                                "This part is used to insert records when update_flag and delete flag are false"
                            )
                            return_col = "ID"
                            data_dict = data_dict[0]
                            return_val = self.insert_user_to_mssql_for_users(
                                mssql_conn, full_from_table, data_dict, return_col="ID"
                            )
                            logging.info(
                                f"return val is {return_val} return fk name automation rule"
                            )
                            automation_rule_id = return_val
                            update_postgres_data = {"id": return_val}
                            logging.info(
                                f"update_postgres_data is {update_postgres_data}"
                            )
                            self.update_table(
                                postgres_conn_test,
                                table_name_20,
                                update_postgres_data,
                                {"id": id_20},
                            )
                        elif update_flag == True and delete_flag == False:
                            logging.info("This part is used to update records ")
                            data_dict = data_10_mapping_dict.get(table_name)
                            self.update_data_to_10_db_rules(
                                full_from_table, data_dict, mssql_conn
                            )
                            return None
            else:
                for item in value:
                    table_name_20 = None
                    for key in item.keys():
                        logging.info("Key in item:", key)
                        if (
                            key == "automation_rule_detail"
                            and update_flag is False
                            and delete_flag is False
                        ):
                            table_name_20 = key
                            logging.info(f"Found the key: {key}")
                            item["automation_rule_detail"][
                                "automation_rule_id"
                            ] = automation_rule_id
                        elif (
                            key == "automation_rule_followup_effective_data_type"
                            and update_flag is False
                            and delete_flag is False
                        ):
                            item["automation_rule_followup_effective_data_type"][
                                "automation_rule_follow_up_id"
                            ] = automation_rule_follow_up_id

                        else:
                            table_name_20 = key
                            logging.info(f"Other key: {key}")

                    data_dict_item = self.ensure_values_are_lists(item)
                    condition_dict = data_dict_item[table_name_20][0]
                    logging.info(table_name_20)
                    logging.info(condition_dict)
                    id_20 = self.function_to_get_user_id(
                        postgres_conn_test, table_name_20, condition_dict
                    )
                    logging.info(id_20)
                    data_mapping_dict = self.map_cols(
                        tables_dict, col_mappings, data_dict_item
                    )
                    for table_name_10, data_list in data_mapping_dict.items():
                        logging.info(f"table and lists are {table_name_10},{data_list}")
                        full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                        if not data_list or data_list == [{}]:
                            logging.info(f"should skip {table_name_10}")
                            continue
                        elif update_flag is False and delete_flag is False:
                            logging.info("entered into update part for other tables ")
                            data_dict = data_mapping_dict.get(table_name_10)
                            data_dict = data_dict[0]
                            logging.info(data_dict)
                            return_val = self.insert_user_to_mssql_for_users(
                                mssql_conn, full_from_table, data_dict, return_col="ID"
                            )
                            if table_name_20 == "automation_rule_follow_up":
                                automation_rule_follow_up_id = return_val
                            logging.info(
                                f"return val is {return_val} return fk name automation rule"
                            )
                            automation_rule_id = return_val
                            update_postgres_data = {"id": return_val}
                            logging.info(
                                f"update_postgres_data is {update_postgres_data}"
                            )
                            self.update_table(
                                postgres_conn_test,
                                table_name_20,
                                update_postgres_data,
                                {"id": id_20},
                            )
                        elif update_flag is True and delete_flag is False:
                            full_from_table = (
                                f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                            )
                            data_dict = data_mapping_dict.get(table_name_10)
                            self.update_data_to_10_db_rules(
                                full_from_table, data_dict, mssql_conn
                            )'''

    def insert_user_to_mssql_for_users(
        self, mssql_conn, table, mssql_dict, return_col=None
    ):
        """
        Insert user data dynamically into an MSSQL table.

        Args:
            mssql_conn (pyodbc.Connection): The MSSQL connection.
            table (str): The name of the table to insert data into.
            mssql_dict (dict): Dictionary containing column names as keys and their values.
        """
        cursor = mssql_conn.cursor()
        if not mssql_dict or not table:
            raise ValueError("Table name and data dictionary cannot be empty.")
        columns = ", ".join(mssql_dict.keys())
        placeholders = ", ".join(["%s"] * len(mssql_dict))
        if return_col:
            sql_query = f"INSERT INTO {table} ({columns}) OUTPUT INSERTED.{return_col} VALUES ({placeholders})"
        else:
            sql_query = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
        """values = tuple(
        mssql_dict[col] if isinstance(mssql_dict[col], (str, int, float, bool))
        else json.dumps(
            mssql_dict[col].item() if isinstance(mssql_dict[col], (np.integer, np.floating)) else mssql_dict[col]
        )
        for col in mssql_dict.keys()
        )"""
        values = tuple(
            (
                mssql_dict[col]
                if isinstance(mssql_dict[col], (str, int, float, bool))
                else (
                    mssql_dict[col].item()
                    if isinstance(mssql_dict[col], (np.integer, np.floating))
                    else (
                        None if mssql_dict[col] is None else json.dumps(mssql_dict[col])
                    )
                )
            )
            for col in mssql_dict
        )
        try:
            logging.info(f"Executing SQL Query: {sql_query}")
            logging.info(f"Values: {values}")
            cursor.execute(sql_query, values)
            if return_col:
                inserted_value = cursor.fetchone()[0]
                mssql_conn.commit()  # Commit the transaction
                logging.info(
                    f"Inserted record with {return_col}: {inserted_value}", table
                )
                return inserted_value
            else:
                mssql_conn.commit()
                logging.info(
                    "Record inserted successfully without returning a column.", table
                )
                return None
        except Exception as e:
            logging.info(f"Error while inserting record into {table}: {e}")
            mssql_conn.rollback()  # Rollback in case of error
            return None
        finally:
            cursor.close()

    def ensure_values_are_lists(self, d):
        for key, value in d.items():
            if not isinstance(value, list):
                d[key] = [value]
        return d

    def function_to_get_user_id_include_null(
        self, mssq_conn, table_name, condition_dict
    ):
        try:
            conditions = []
            values = []
            for key, value in condition_dict.items():
                if value is None or value == "null":
                    conditions.append(f"{key} IS NULL")
                    # values.append(None)
                else:
                    conditions.append(f"{key} = %s")
                    values.append(value)
            conditions_str = " AND ".join(conditions)
            # conditions = " AND ".join([f"{key} = %s" for key in condition_dict.keys()])
            # sql_query = f'SELECT id FROM {table_name} WHERE {conditions} '
            sql_query = f"SELECT id FROM {table_name} WHERE {conditions_str}"
            logging.info(sql_query)
            # values=condition_dict.values()
            logging.info(values)
            # value = tuple(condition_dict.values())
            # logging.info(sql_query)
            cursor = mssq_conn.cursor()
            cursor.execute(sql_query, tuple(values))
            result = cursor.fetchone()

            if result:
                # If the result exists, return the id
                logging.info("id is ", result[0])
                return result[0]

            else:
                # If no result is found, return None or a custom value
                logging.info("print id_20 is not found")
                return None
        except Exception as e:
            logging.info(f"Error: {e}")
            return None

    def update_data_to_10_db_rules(self, table_name, data_list, mssql_conn):
        try:
            logging.info("trying to insert a row using merge query")
            if not mssql_conn:
                raise ValueError("Invalid MSSQL connection")
            if not data_list:
                raise ValueError("Data list is empty")
            for row in data_list:
                cursor = mssql_conn.cursor()
                logging.info("entered into update part")
                logging.info(row.items())
                values_section = None
                for key in row.keys():
                    if row[key] is None:
                        if values_section:
                            values_section = values_section + ", " + f"{'NULL'}"
                        else:
                            values_section = f"{'NULL'}"
                    else:
                        if values_section:
                            values_section = values_section + ", " + f"'{row[key]}'"
                        else:
                            values_section = f"'{row[key]}'"

                source_columns = ", ".join([key for key in row.keys()])
                logging.info(values_section)
                logging.info(source_columns)
                source_columns = ", ".join([key for key in row.keys()])
                matched_update = ", ".join(
                    [
                        f"target.{key} = source.{key}"
                        for key in row.keys()
                        if key != "id"
                    ]
                )

                insert_columns = ", ".join([key for key in row.keys() if key != "id"])
                insert_values = ", ".join(
                    [f"source.{key}" for key in row.keys() if key != "id"]
                )
                logging.info(f"******************* {insert_columns}, {insert_values}")

                # Construct the SQL MERGE query
                sql_merge_query = f"""
                    MERGE INTO {table_name} AS target
                    USING (VALUES ({values_section})) AS source ({source_columns})
                    ON target.id = source.id
                    WHEN MATCHED THEN
                    UPDATE SET {matched_update}
                    WHEN NOT MATCHED BY TARGET THEN
                    INSERT ({insert_columns}) VALUES ({insert_values})
                    OUTPUT INSERTED.id;
                    """
                logging.info(f"Merge Query {sql_merge_query}")

                cursor.execute(sql_merge_query)
                inserted_ids = cursor.fetchall()
                if inserted_ids:

                    newly_inserted_id = inserted_ids[0][0]
                    logging.info(f"Newly inserted Id: {newly_inserted_id}")
                    logging.info(f"Newly inserted Id: {inserted_ids}")
                    mssql_conn.commit()
                    # logging.info("merge query*******************************", sql_merge_query)
                    # return newly_inserted_id
                    return {"id": newly_inserted_id}

            cursor = mssql_conn.cursor()

        except Exception as e:
            logging.info(f"Error while inserting row into {table_name}: {e}")

    def convert_null(self, value):
        if value == "null" or value is None:
            return None  # This will map to SQL NULL
        return value

    '''def insert_automation_rule_table_data_with_psql(
        self, transfer_name, data_dict, update_flag=False, delete_flag=False
    ):
        logging.info("starting Automation rule tables sync")
        load_dotenv()
        hostname, port, user, password, db_type, db_name = self.load_env_pgsql()

        postgres_conn1 = self.create_connection(
            db_type, hostname, db_name, user, password, port
        )
        mapping_table = os.getenv("MAPPING_TABLE")

        mapping_details_query = f"select table_mapping_10_to_20,col_mapping_10_to_20,return_params_10,fk_cols_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
        logging.info(f"query {mapping_details_query}")
        mapping_details = self.execute_query(postgres_conn1, mapping_details_query)
        logging.info(f"mapping_details {mapping_details}")
        mapping_details = mapping_details.to_dict(orient="records")[0]

        tables_dict = mapping_details.get("table_mapping_10_to_20", {})
        logging.info(f"Tables dict is {tables_dict}")  # 1.0 to 2.0 table mappings dict
        col_mappings = mapping_details.get("col_mapping_10_to_20", {})
        # logging.info(f"col_mappings are {col_mappings}")   # 1.0 to 2.0 column mappings
        return_params_10 = mapping_details.get("return_params_10", {})
        logging.info(
            f"return params {return_params_10}"
        )  # cols data that we need to return from 1.0
        fk_cols_10 = mapping_details.get("fk_cols_10", {})
        # logging.info(f"fk cols 10 are {fk_cols_10}")            # foreign key columns
        db_config = mapping_details.get("db_config", {})

        (
            from_host,
            from_port,
            ssms_db_name,
            from_user,
            from_pwd,
            from_db_type,
            from_driver,
        ) = self.load_env_mssql()
        mssql_conn = self.create_connection(
            from_db_type,
            from_host,
            ssms_db_name,
            from_user,
            from_pwd,
            from_port,
            from_driver,
        )

        fk_values_dict = {}
        data_dict_total = data_dict["automation_data"]
        automation_rule_id = None

        load_dotenv()
        hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
        db_name = "altaworx_test"
        postgres_conn_test = self.create_connection(
            db_type, hostname, db_name, user, password, port
        )
        if delete_flag == True and update_flag is False:
            id_to_delete = data_dict.get("id", {})
            full_from_table = f"[{ssms_db_name}].[dbo].[AutomationRule]"
            self.delete_from_pgsql(mssql_conn, table_name_10, id_to_delete)
            return True
        for key, value in data_dict_total.items():
            if key in tables_dict.keys():
                table_name_10 = tables_dict.get(key)
                for table_name in table_name_10:
                    logging.info(f"@@@@@@@@@@@@@@@@@@@@{table_name}")
                    if table_name == "AutomationRule":
                        full_from_table = f"[{ssms_db_name}].[dbo].[{table_name}]"
                        main_pgsql_dict = {key: [value]}
                        condition_dict = value
                        logging.info(condition_dict)
                        table_name_20 = key
                        # serviceprovider_dict={}
                        # serviceprovider_dict['service_provider_name']=condition_dict.get('service_provider_name',None)
                        # logging.info(serviceprovider_dict)
                        # service_provider_id=self.function_to_get_user_id_include_null(postgres_conn_test,'serviceprovider',serviceprovider_dict)
                        # logging.info("the serviceprovider_id gotten is ",service_provider_id)
                        # condition_dict['service_provider_id']=service_provider_id
                        logging.info(main_pgsql_dict)
                        id_20 = self.function_to_get_user_id_include_null(
                            postgres_conn_test, table_name_20, condition_dict
                        )
                        data_10_mapping_dict = self.map_cols(
                            tables_dict, col_mappings, main_pgsql_dict
                        )
                        # logging.info(data_10_mapping_dict)
                        # logging.info(data_10_mapping_dict)
                        data_dict = data_10_mapping_dict.get(table_name)
                        if update_flag == False and delete_flag == False:
                            logging.info(
                                f"This part is used to insert records when update_flag and delete flag are false for automation rule"
                            )
                            return_col = "ID"
                            data_dict = data_dict[0]
                            return_val = self.insert_user_to_mssql_for_users(
                                mssql_conn, full_from_table, data_dict, return_col="ID"
                            )
                            logging.info(
                                f"return val is {return_val} return fk name automation rule"
                            )
                            automation_rule_id = return_val
                            update_postgres_data = {"id": return_val}
                            logging.info(
                                f"update_postgres_data is {update_postgres_data}"
                            )
                            self.update_table(
                                postgres_conn_test,
                                table_name_20,
                                update_postgres_data,
                                {"id": id_20},
                            )
                        elif update_flag == True and delete_flag == False:
                            logging.info("This part is used to update records ")
                            data_dict = data_10_mapping_dict.get(table_name)
                            self.update_data_to_10_db_rules(
                                full_from_table, data_dict, mssql_conn
                            )
            else:
                for item in value:
                    rule_followup_id = None
                    table_name_20 = None
                    for key in item.keys():
                        logging.info("Key in item:", key)
                        if (
                            key == "automation_rule_detail"
                            and update_flag is False
                            and delete_flag is False
                        ):
                            table_name_20 = key
                            logging.info(f"Found the key: {key}")
                            item["automation_rule_detail"][
                                "automation_rule_id"
                            ] = automation_rule_id
                        elif (
                            key == "automation_rule_followup_detail"
                            and update_flag is False
                            and delete_flag is False
                        ):
                            table_name_20 = key
                            item["automation_rule_followup_detail"][
                                "rule_followup_id"
                            ] = rule_followup_id
                        else:
                            table_name_20 = key
                            logging.info(f"Other key: {key}")
                    data_dict_item = self.ensure_values_are_lists(item)
                    condition_dict = data_dict_item[table_name_20][0]
                    id_20 = self.function_to_get_user_id_include_null(
                        postgres_conn_test, table_name_20, condition_dict
                    )
                    data_mapping_dict = self.map_cols(
                        tables_dict, col_mappings, data_dict_item
                    )
                    for table_name_10, data_list in data_mapping_dict.items():
                        logging.info(f"table and lists are {table_name_10},{data_list}")
                        full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                        if not data_list or data_list == [{}]:
                            logging.info(f"should skip {table_name_10}")
                            continue
                        elif update_flag is False and delete_flag is False:
                            return_col = "ID"
                            logging.info(f"entered into update part for other tables ")
                            data_dict = data_mapping_dict.get(table_name_10)
                            data_dict = data_dict[0]
                            logging.info(data_dict)
                            data_dict = {
                                key: self.convert_null(value)
                                for key, value in data_dict.items()
                            }
                            logging.info(data_dict)
                            logging.info(table_name_20)
                            return_val = self.insert_user_to_mssql_for_users(
                                mssql_conn, full_from_table, data_dict, return_col="ID"
                            )
                            if table_name_20 == "automation_rule_followup":
                                logging.info(
                                    f"*************************************************************entered this part"
                                )
                                rule_followup_id = return_val
                                logging.info(
                                    f"return val is {return_val} return fk name automation rule{rule_followup_id}"
                                )

                            update_postgres_data = {"id": return_val}
                            logging.info(
                                f"update_postgres_data is {update_postgres_data}"
                            )
                            self.update_table(
                                postgres_conn_test,
                                table_name_20,
                                update_postgres_data,
                                {"id": id_20},
                            )
                        elif update_flag is True and delete_flag is False:
                            full_from_table = (
                                f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                            )
                            data_dict = data_mapping_dict.get(table_name_10)
                            self.update_data_to_10_db_rules(
                                full_from_table, data_dict, mssql_conn
                            )'''

    '''def make_status_false_for_automation(self, mssql_conn, full_form_table, data_dict):

        try:
            logging.info("This part is used to make the status false")
            cursor = mssql_conn.cursor()
            # Extract the automation rule ID from the data_dict
            automation_rule_id = data_dict.get("id", None)
            if not automation_rule_id:
                logging.info("No AutomationRuleId provided.")
                return None
            logging.info(automation_rule_id)
            # Step 1: Deactivate AutomationRule
            db_name_10 = os.getenv("FROM_DB_NAME")
            query1 = f"""
            UPDATE [{db_name_10}].[dbo].[AutomationRule]
            SET IsActive = 0
            OUTPUT inserted.Id
            WHERE id = {automation_rule_id} """
            cursor.execute(query1)
            updated_rule = cursor.fetchall()
            mssql_conn.commit()
            cursor = mssql_conn.cursor()
            logging.info("updated_rule id is ", updated_rule)
            if updated_rule:
                logging.info(f"Deactivated AutomationRule with ID {updated_rule[0]}.")
            # Step 2: Deactivate AutomationRule_Detail
            followup_ids = []
            query2 = f"""
            UPDATE [{db_name_10}].[dbo].[AutomationRule_Detail]
            SET IsActive = 0
            OUTPUT inserted.RuleFollowupId
            WHERE AutomationRuleId = {automation_rule_id}"""
            logging.info(query2)
            cursor.execute(query2)
            updated_details = cursor.fetchall()
            mssql_conn.commit()
            logging.info(updated_details)
            for detail in updated_details:
                logging.info(f"Deactivated AutomationRule_Detail with ID {detail[0]}.")
                if detail[0] is not None:
                    followup_ids.append(detail[0])

            cursor = mssql_conn.cursor()
            db_name_10 = os.getenv("FROM_DB_NAME")
            for followup_id in followup_ids:
                query4 = f"""
                UPDATE [{db_name_10}].[dbo].[AutomationRule_Followup]
                SET IsActive = 0
                OUTPUT inserted.id
                WHERE id = {followup_id}"""
                cursor.execute(query4)
            updated_followup = cursor.fetchone()
            if updated_followup:
                logging.info(
                    f"Deactivated AutomationRule_Followup with ID {updated_followup[0]}."
                )
            mssql_conn.commit()
            # Commit all changes
        except Exception as e:
            logging.info(f"Error during the update process: {e}")
            mssql_conn.rollback()'''

    def insert_automation_rule_table_data_with_psql_false(
        self, transfer_name, data_dict, update_flag=False, delete_flag=False
    ):
        logging.info(f"starting Automation rule tables sync {data_dict}")
        load_dotenv()
        hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
        postgres_conn1 = self.create_connection(
            db_type, hostname, db_name, user, password, port
        )
        mapping_table = os.getenv("MAPPING_TABLE")
        mapping_details_query = f"select table_mapping_10_to_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_name_10,db_config from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
        logging.info(f"query {mapping_details_query}")
        mapping_details = self.execute_query(postgres_conn1, mapping_details_query)
        logging.info(f"mapping_details {mapping_details}")
        mapping_details = mapping_details.to_dict(orient="records")[0]
        mssql_config = mapping_details.get("db_config", {})
        db_name_10 = mapping_details.get("db_name_10", {})
        tables_dict = mapping_details.get("table_mapping_10_to_20", {})
        logging.info(f"Tables dict is {tables_dict}")  # 1.0 to 2.0 table mappings dict
        col_mappings = mapping_details.get("col_mapping_10_to_20", {})
        # logging.info(f"col_mappings are {col_mappings}")   # 1.0 to 2.0 column mappings
        return_params_10 = mapping_details.get("return_params_10", {})
        logging.info(
            f"return params {return_params_10}"
        )  # cols data that we need to return from 1.0
        fk_cols_10 = mapping_details.get("fk_cols_10", {})
        # logging.info(f"fk cols 10 are {fk_cols_10}")            # foreign key columns
        db_config = mapping_details.get("db_config", {})

        if mssql_config:
            from_host = mssql_config.get("hostname")
            from_port = mssql_config.get("port")
            ssms_db_name = db_name_10
            from_user = mssql_config.get("user")
            from_db_type = mssql_config.get("from_db_type")
            from_pwd = mssql_config.get("password")
            from_driver = os.getenv("FROM_DB_DRIVER")
        else:
            logging.info("no mappings present for the configurations so returning the function")
            return True
        mssql_conn = self.create_connection(
            from_db_type,
            from_host,
            ssms_db_name,
            from_user,
            from_pwd,
            from_port,
            from_driver,
        )
        if update_flag is False:
            return True

        logging.info(data_dict)
        data_dict = data_dict["input_data"][0]
        logging.info(data_dict)
        fk_values_dict = {}
        data_dict_total = data_dict["automation_data"]
        logging.info(data_dict_total)
        logging.info(tables_dict)
        automation_rule_id = None
        load_dotenv()
        hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
        db_name = "altaworx_test"
        postgres_conn_test = self.create_connection(
            db_type, hostname, db_name, user, password, port
        )
        self.make_status_false_for_automation(mssql_conn, tables_dict, data_dict_total)
        return True

    def rev_actions(self, data):
        try:
            transfer_name = data.get("key_name")
            postgres_data_list = data.get("rev_service_product")
            postgres_data = {}
            postgres_data["rev_service_product"] = postgres_data_list

            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            logging.info(
                f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}"
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_details_query = f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_config,db_name_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get("table_mapping_10_to_20", {})
            db_name_20 = mapping_details.get("db_name_20", {})

            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name_20, user, password, port
            )
            logging.info(f"postgres_conn1 is {postgres_conn1}")

            db_name_10 = mapping_details.get("db_name_10", {})
            mssql_config = mapping_details.get("db_config")
            col_mappings_10_to_20 = mapping_details.get("col_mapping_10_to_20", {})
            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})

            if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                logging.info("no mappings present for the configurations so returning the function")
                return True

            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"Mssql conn is {mssql_conn}")
            if transfer_name.startswith("add_service_product"):
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings_10_to_20, postgres_data
                )
                logging.info(f"Total insert dict is {total_insert_dict}")
                table_name_20 = "rev_service_product"

                for table_name_10, data_list in total_insert_dict.items():
                    # if the table name in not mssql format -- modifying it
                    if not self.is_valid_table_name(table_name_10):
                        full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                        logging.info(f"Full from table is {full_from_table}")

                    if table_name_20 == "rev_service_product":
                        logging.info(f"Inseting rev service product records:")
                        for dict_item in data_list:
                            logging.info(f"Dict item is {dict_item}")
                            if "20_id" in dict_item:
                                id_20 = dict_item.pop("20_id")
                            logging.info(f"20 id is {id_20}")
                            insert_val, insert_col = self.insert_data_to_db(
                                full_from_table,
                                [dict_item],
                                mssql_conn,
                                "ID",
                                "RevServiceProduct",
                            )
                            logging.info(f"Insertion done {insert_val}")
                            if insert_val:
                                update_dict = {"id_10": int(insert_val)}
                                uu = self.update_table(
                                    postgres_conn1,
                                    table_name_20,
                                    update_dict,
                                    {"id": int(id_20)},
                                )
                                logging.info(f"Update done")

            elif transfer_name.startswith("deactivated_service_product"):
                table_name_10 = "RevServiceProduct"
                service_product_id = data.get("service_product_id")
                customer_id = data.get("customer_id")
                if not self.is_valid_table_name(table_name_10):
                    full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                    logging.info(f"Full from table is {full_from_table}")

                update_dict = {
                    "Status": "DISCONNECTED",
                    "StatusDate": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "CanceledDate": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "IsActive": 0,
                }
                uu = self.update_table_mssql(
                    full_from_table,
                    update_dict,
                    mssql_conn,
                    {
                        "ServiceProductId": service_product_id,
                        "CustomerId": customer_id,
                        "IsActive": 1,
                    },
                )

        except Exception as e:
            logging.error(f"Exceptuion in rev actions {e}")

    def update_data_to_10_db_loop(self,table_name,data_list,mssql_conn):
        try:
            logging.info("trying to insert a row using merge query",data_list)

            if not mssql_conn:
                raise ValueError("Invalid MSSQL connection")
            if not data_list:
                raise ValueError("Data list is empty")
            for row in data_list:

                cursor = mssql_conn.cursor()
                print("entered into update part")
                #print(row.items())
                #column_names = ', '.join([key for key in row.keys() if key != 'Id'])
                #column_values = ', '.join([f"'{row[key]}'" for key in row.keys() if key != 'Id'])
                values_section=None
                for key in row.keys():
                    if row[key] is None:
                        if values_section:
                            values_section=values_section+', '+f"{'NULL'}"
                        else:
                            values_section=f"{'NULL'}"
                    else:
                        if values_section:
                            values_section=values_section+', '+f"'{row[key]}'"
                        else:
                            values_section=f"'{row[key]}'"

                source_columns=', '.join([key for key in row.keys() ])
                #print(values_section)
                #print(source_columns)

                source_columns=', '.join([key for key in row.keys() ])
                id_value = row['id']

                #print("*******************", column_names, column_values)


                matched_update = ', '.join([f"target.{key} = source.{key}" for key in row.keys() if key != 'id'])


                insert_columns = ', '.join([key for key in row.keys() if key != 'id'])
                insert_values = ', '.join([f"source.{key}" for key in row.keys() if key != 'id'])
                logging.info("*******************", insert_columns, insert_values)

                    # Construct the SQL MERGE query
                sql_merge_query = f"""
                    MERGE INTO {table_name} AS target
                    USING (VALUES ({values_section})) AS source ({source_columns})
                    ON target.id = source.id
                    WHEN MATCHED THEN
                    UPDATE SET {matched_update}
                    WHEN NOT MATCHED BY TARGET THEN
                    INSERT ({insert_columns}) VALUES ({insert_values})
                    OUTPUT INSERTED.id;
                    """
                logging.info(f"Merge Query {sql_merge_query}")

                cursor.execute(sql_merge_query)
                inserted_ids = cursor.fetchall()

                if inserted_ids:

                    newly_inserted_id = inserted_ids[0][0]
                    logging.info(f"Newly inserted Id: {newly_inserted_id}")
                    logging.info(f"Newly inserted Id: {inserted_ids}")
                    mssql_conn.commit()
                    logging.info("merge query*******************************", sql_merge_query)
                    #return newly_inserted_id
                    #return {"id":newly_inserted_id},{"id":id_value}

            cursor = mssql_conn.cursor()

        except Exception as e:
                logging.info(f"Error while inserting row into {table_name}: {e}")

    def charge_history_setting_function(self,transfer_name,postgres_data,update_flag=False,delete_flag=False):
        try:
            print(f"STARTING {transfer_name}, charge history")
            print(f"charge history postgres_data is {postgres_data}")
            load_dotenv()
            hostname,port,user,password,db_type,db_name=self.load_env_pgsql()
            print(f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}")
            mapping_table=os.getenv('MAPPING_TABLE')
            postgres_conn = self.create_connection(db_type, hostname, db_name, user, password, port)
            mapping_details_query=f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_config,db_name_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details=self.execute_query(postgres_conn,mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError("No Mappings present for transfer") #raising error if unable to get required data from db

            mapping_details=mapping_details.to_dict(orient='records')[0]
            tables_dict = mapping_details.get('table_mapping_10_to_20', {})
            db_name_20=mapping_details.get('db_name_20',{})
            db_name_10=mapping_details.get("db_name_10",{})
            mssql_config=mapping_details.get("db_config")
            print(f"db_name_20 is {db_name_20}")
            print("mssql configurations",mssql_config)

            print(f"type(tables_dict)----------{type(tables_dict)}")  # 1.0 to 2.0 table mappings dict
            col_mappings = mapping_details.get('col_mapping_10_to_20', {})
            print(type(col_mappings))   # 1.0 to 2.0 column mappings
            return_params_10 = mapping_details.get('return_params_10', {})    # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get('fk_cols_10', {})                # foreign key columns
            db_config=mapping_details.get('db_config',{}) #ssms db config details
            table_name_20=mapping_details.get('table_mapping_10_to_20').keys()
            table_name_20 = ', '.join(str(key) for key in table_name_20)
            print(f"table_name_20 is {table_name_20}")
            table_name_10=tables_dict[table_name_20][0]
            print(f"Table Name 1.0 is {table_name_10}")
            # update_flag=True
            hostname = os.getenv('LOCAL_DB_HOST')
            port = os.getenv('LOCAL_DB_PORT')
            db_name=db_name_20
            user = os.getenv('LOCAL_DB_USER')
            password = os.getenv('LOCAL_DB_PASSWORD')
            db_type = os.getenv('LOCAL_DB_TYPE')
            from_driver=os.getenv('LOCAL_DB_DRIVER')
            postgres_conn1 = self.create_connection(db_type, hostname, db_name, user, password, port)

            postgres_data_copy=copy.deepcopy(postgres_data)
            print("upadte_flag123",update_flag,"delete_flag",delete_flag)

            if update_flag is True and delete_flag is False:
                print("Update flag is true")
                print(f"{postgres_data_copy}")
                update_data=postgres_data_copy[table_name_20]
                print(postgres_data_copy[table_name_20])
                print("printing data",postgres_data)
                total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data)
                print(total_insert_dict)
            elif update_flag is False  and delete_flag is True:
                print("Delete flag is false ")
                update_data=postgres_data_copy[table_name_20][0]
                id_20=update_data['id']
                print(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query=f"select id_10 from {table_name_20} where id='{id_20}'"
                result=self.execute_query(postgres_conn1,id_10_query)
                id_10=result['id_10'][0]
                print(f"id_10 is {id_10}")
                update_data['id_10']=id_10
                postgres_data_20={table_name_20:[update_data]}
                total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data_20)
            else:
                print("delete and update flags are false")
                print(f"tables_dict {tables_dict}")
                print(f"postgress_data",postgres_data)
                print(f"mapping_cols",col_mappings)
                total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data)
            print(total_insert_dict)
            if not mssql_config :
                from_host,from_port,ssms_db_name,from_user,from_pwd,from_db_type,from_driver=self.load_env_mssql()
            else:
                from_host=mssql_config.get("hostname")
                from_port=mssql_config.get("port")
                ssms_db_name=db_name_10
                from_user=mssql_config.get("user")
                from_db_type=mssql_config.get("from_db_type")
                from_pwd=mssql_config.get("password")
                from_driver=os.getenv('FROM_DB_DRIVER')
            print(ssms_db_name)
            print(from_host)
            print(from_driver)

            mssql_conn_start = time.time()
            mssql_conn=self.create_connection(from_db_type,from_host,ssms_db_name,from_user,from_pwd,from_port,from_driver)
            print(f"mssql_conn {mssql_conn}")
            print(f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds")
            print(f"total insert dict {total_insert_dict}")

            return_ids=[]
            fk_track_dict={}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                #if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table=f'[{ssms_db_name}].[dbo].[{table_name_10}]'
                print(full_from_table)

                if return_params_10:
                    print(f"Heree 2111 {return_params_10}")
                    return_col = return_params_10.get(table_name_10,None) #get the col whose value should be returned for this table
                    fk_col_dict = fk_cols_10.get(table_name_10, {}) #get the fk_col dict for this table
                else:
                    return_col=None
                    fk_col_dict=None


                if not return_col and not fk_col_dict:
                    print("This part is to handle update tables don't have any foreign key columnc")


                    if update_flag is False and delete_flag is False:
                        print("This part is used to insert records when update_flag and delete flag are false")
                        return_col='ID'
                        return_val, return_fk_name=self.insert_data_to_db(full_from_table,total_insert_dict[table_name_10],mssql_conn,return_col,table_name_10)
                        print(f"return val is {return_val} return fk name is {return_fk_name}")

                        update_postgres_data=postgres_data[table_name_20][0]
                        update_postgres_data['id_10']=return_val
                        update_postgres_id=update_postgres_data['id']
                        update_postgres_data.pop('id')
                        print(f"update_postgres_data is {update_postgres_data}")
                        self.update_table(postgres_conn1,table_name_20,update_postgres_data,{'id':update_postgres_id})

                    else:
                        print("update_flag is true ")
                        print("full form table",full_from_table)
                        print("table_name_10")
                        print("datatogetinsert",total_insert_dict[table_name_10])
                        print(len(total_insert_dict[table_name_10]))


                        self.update_data_to_10_db_loop(full_from_table,total_insert_dict[table_name_10],mssql_conn)


        except Exception as e:
            logging.info(f"Error in charge settings {e}")

    def update_data_history_table_bulk(
        self, postgres_conn, table_name, data_list, conflict_col
    ): # added this line
        """
        Inserts or updates data in a PostgreSQL table based on conflict.

        Parameters:
            postgres_conn: Active PostgreSQL connection
            table_name (str): Name of the target table
            record_dict (dict): Data to insert or update
            conflict_col (str): Column name to check for conflicts
        """
        if not data_list:
            print("No data provided for insertion.")
            return
        try:
            with postgres_conn.cursor() as cursor:
                # Extract column names and values
                columns = list(data_list[0].keys())
                data_list = self.clean_data_list(data_list)

                # Generate column and placeholder strings
                columns_str = ", ".join(columns)
                placeholders = ", ".join(["%s"] * len(columns))
                conflict_cols_str = ", ".join(conflict_col)
                # Generate update set statement excluding the conflict column
                update_set = ", ".join(
                    [
                        f"{col} = EXCLUDED.{col}"
                        for col in columns
                        if col != conflict_col
                    ]
                )
                # Construct the UPSERT query
                # print(columns_str)

                query = f"""
                INSERT INTO {table_name} ({columns_str})
                VALUES %s
                ON CONFLICT ({conflict_cols_str})
                DO UPDATE SET {update_set};
                """
                values = [tuple(record[col] for col in columns) for record in data_list]
                logging.info(f"query going to execute on history tables{query}")
                # print(f"Update values are {values}")

                execute_values(cursor, query, values)
                postgres_conn.commit()
                logging.info(f"Record inserted/updated successfully. {table_name}")

        except Exception as e:
            postgres_conn.rollback()
            logging.info(f"Error in update_data_history_table bulk: {e}")

    def main_save_data_t0_20_bulk_update(
        self,
        main_insert_data,
        main_cond_dict,
        main_multiple_col_conditions,
        id_20,
        postgres_conn,
        dependent_insert_data,
        dependent_cond_dict,
        tenant_id=None,
        inventory_conflict_cols=None
    ):
        start_time = time.time()
        batch_size = 5000
        try:
            logging.info(f"MAIN SAVE START")
            logging.info(f"PostgresConn{postgres_conn}")
            if main_insert_data:
                logging.info(f"111111111111111111 here")
                for table_name_20, data_list in main_insert_data.items():
                    logging.info(
                        f" Data to be updated in table {id_20}-{table_name_20}"
                    )
                    if data_list:
                        if table_name_20 in main_cond_dict.keys():
                            where_20_col = main_cond_dict[table_name_20]
                            logging.info(f"222222222 Where col,where val {where_20_col},{id_20}")
                            for record_dict in data_list:
                                logging.info(f" record_dict is {id_20}")#{record_dict}
                                logging.info(f"GOING TO UPDATE TABLE")
                                update = self.update_table(
                                    postgres_conn,
                                    table_name_20,
                                    record_dict,
                                    {where_20_col: id_20},
                                )

                        elif table_name_20 in main_multiple_col_conditions.keys():
                            df = pd.DataFrame(data_list)
                            df["bulk_change_id"] = id_20
                            data_list = df.to_dict(orient="records")

                            logging.info(
                                f"44444444 @@@@@ in elif condiion table_name {id_20}-{table_name_20}"
                            )
                            logging.info(data_list)
                            conflict_col=["bulk_change_id","id"]
                            # logging.info(f"44444444 Data List is {data_list}")
                            self.update_data_history_table_bulk(
                            postgres_conn, table_name_20, data_list, conflict_col
                        )

                    else:
                        raise ValueError("No records obtained to insert in 2.0")
                return True

            elif dependent_insert_data:
                logging.info(f"Dependent cond dict is {dependent_cond_dict}")
                for table_name_20, data_list in dependent_insert_data.items():
                    logging.info(f"{id_20} Data to be updated in table {table_name_20}")
                    if not data_list:
                        logging.info(
                            f"{id_20} No Data to Insert, skipping to next iteration"
                        )
                        continue
                    if (
                        table_name_20 == "device_history"
                        or table_name_20 == "mobility_device_history"
                    ):
                        batch_size = 5000  # Define batch size

                        logging.info(f"{id_20} updating device_history table {table_name_20}")

                        cursor = postgres_conn.cursor()
                        conflict_col = ["device_history_id"]
                        # Convert list of dicts to Pandas DataFrame
                        df = pd.DataFrame(data_list)
                        # Perform batch updates if more than 5000 records exist
                        if len(df) > batch_size:
                            for i in range(0, len(df), batch_size):
                                batch_df = df.iloc[i:i + batch_size]  # Slice dataframe into batches
                                batch = batch_df.to_dict(orient="records")  # Convert batch back to list of dicts
                                logging.info(f"Processing batch {i // batch_size + 1} for {id_20}")
                                self.update_data_history_table_bulk(postgres_conn, table_name_20, batch, conflict_col)
                        else:
                            # Convert to list of dicts for single update
                            self.update_data_history_table_bulk(postgres_conn, table_name_20, df.to_dict(orient="records"), conflict_col)

                        if len(data_list) > batch_size:
                            for i in range(0, len(data_list), batch_size):
                                batch = data_list[i:i + batch_size]  # Slice data into batches
                                logging.info(f"Processing batch {i // batch_size + 1} for {id_20}")
                                self.update_data_history_table_bulk(postgres_conn, table_name_20, batch, conflict_col)
                        else:
                            # Perform a single update if data_list is within batch size
                            self.update_data_history_table_bulk(postgres_conn, table_name_20, data_list, conflict_col)
                    if table_name_20 == "sim_management_bulk_change_log":
                        #batches include fixed 5000 dfisze batches divide
                        logging.info(f"{id_20} updating bulk_change_log table {table_name_20}")
                        df = pd.DataFrame(data_list)  # Convert list of dicts to DataFrame
                        df["bulk_change_id"] = id_20  # Vectorized update
                        data_list = df.to_dict(orient="records")  # Convert back to list of dicts
                        conflict_col=["id_10","bulk_change_id"]
                        if len(df) > batch_size:
                            for i in range(0, len(df), batch_size):
                                batch_df = df.iloc[i:i + batch_size]  # Slice dataframe into batches
                                batch = batch_df.to_dict(orient="records")  # Convert batch back to list of dicts
                                logging.info(f"Processing batch {i // batch_size + 1} for {id_20}")
                                self.update_data_history_table_bulk(postgres_conn, table_name_20, batch, conflict_col)
                        else:
                            # Convert to list of dicts for single update
                            self.update_data_history_table_bulk(postgres_conn, table_name_20, df.to_dict(orient="records"), conflict_col)

                    if table_name_20=="sim_management_inventory":
                        logging.info(f"{id_20} updating inventory table {table_name_20}")
                        df = pd.DataFrame(data_list)
                        if len(df) > batch_size:
                            for i in range(0, len(df), batch_size):
                                batch_df = df.iloc[i:i + batch_size]  # Slice dataframe into batches
                                batch = batch_df.to_dict(orient="records")  # Convert batch back to list of dicts
                                print(f"Processing batch {i // batch_size + 1} for {id_20}")
                                self.update_data_history_table_bulk(postgres_conn, table_name_20, batch, inventory_conflict_cols)
                        else:
                            batch = df.to_dict(orient="records")  # Convert full dataframe to list of dicts
                            self.update_data_history_table_bulk(postgres_conn, table_name_20, batch, inventory_conflict_cols)


                end_time = time.time()
                time_consumed = f"{end_time - start_time:.4f}"
                logging.info(f"Time consumed at main_save_data_t0_20 is {time_consumed}")
                return True
        except Exception as e:
            logging.info(f"{id_20} Error in main_save_data_t0_20: {e}")
            logging.info(f"{id_20} Going to execute update_query")
            # logging.info(f"Going to execute")
            error_msg = f"Error in main_save_data_t0_20: {e}"
            update_data_dict = {"progress": "Error in Sync", "error_msg": error_msg}
            ue = self.update_table(
                postgres_conn,
                "sim_management_bulk_change",
                update_data_dict,
                {"id": id_20},
            )

    def save_data_20_from_10_bulk_update(
        self, id_10, id_20, transfer_name, postgres_data, data_all,sqs_falg=False,tenant_name=None,service_provider_id=None,
        ver_inventory_flag=None,parent_tenant_id=None,sub_tenant_id=None
    ):  # commenting this to implement ticket 2266 on 08-01-2025
        try:
            logging.info(f"reverse syncing data from 1.0 to 2.0")
            if tenant_name=='Altaworx Test': # added this line
                tenant_name='Altaworx' # added this line
            tenant_id=parent_tenant_id
            tenant_id_str=None
            sqs_flag=False
            start_time = time.time()
            logging.info(f"reverse syncing data from 1.0 to 2.0")
            logging.info(f" reverse syncing data from 1.0 to 2.0 {service_provider_id}")
            logging.info(f"ID ISSUE {service_provider_id},{transfer_name}")
            # sqs_flag=False
            # tenant_json=self.load_json()
            # tenant_id_dict=tenant_json.get('TenanatIds')
            # tenant_id=tenant_id_dict.get(tenant_name,None)
            # sub_tenants_json=self.tenant_load_json()

            # if tenant_id is None:
            #     logging.info(f"save_data_20_from_10_bulk_update Tenant id is not found in tenant json")
            #     subtenant_id = self.get_subtenant_id_by_name(tenant_name, sub_tenants_json)
            #     parent_tenant_id=self.get_parent_id_by_subtenant(tenant_name,sub_tenants_json)
            #     logging.info(f"save_data_20_from_10_bulk_update Subtenant id is {subtenant_id}")
            #     if subtenant_id:
            #         tenant_id = subtenant_id

            # parent_tenant_name=self.get_parent_by_subtenant(tenant_name,sub_tenants_json)
            # if parent_tenant_name:
            #     tenant_name=parent_tenant_name

            '''common_utils_db=os.getenv("COMMON_UTILS_DB_NAME")
            comm_postgres_con= self.create_connection(
                db_type, hostname,common_utils_db, user, password, port
            )

            if tenant_name:
                tenant_name,parent_tenant_id,subtenant_id=self.function_to_check_sub_tenant_or_parent_name(comm_postgres_con,tenant_name)
                tenant_id=parent_tenant_id'''

            logging.info(f"Tenant details after loading from fn function_to_check_sub_tenant_or_parent_name is {tenant_name} and parent_tenant_id is {parent_tenant_id} and tenant_id is {tenant_id}")

            if tenant_id:
                tenant_id_str = f"({', '.join(str(i) for i in [parent_tenant_id, sub_tenant_id] if i is not None)})"


            inventory_conflict_cols=None
            logging.info(
                f"devicehistorytable postgress_data,,id_10 is ,{id_10}, id_20 is {id_20}, transfer name is {transfer_name}"
            )
            logging.info(f"Going to save data from 1.0 to 2.0,{len(postgres_data)}")
            logging.info(f"Transfer name is {transfer_name}")
            logging.info(f"ID 10 is {id_10}")
            logging.info(f"ID 20 is {id_20}")


            # if transfer_name == "bulk_change":
            if transfer_name.startswith("bulk_change"):
                logging.info(f"####service_provider_id in save_data_20_from_10 is {service_provider_id}")
                json_data = self.load_json()
                telegence_ids = self.get_provider_ids(json_data, tenant_name, ["Telegence"])

                if tenant_name.lower() in ('altaworx_test','altaworx','altaworx test'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_bulk_update_mobility"
                        inventory_conflict_cols=["mdt_id","mobility_device_id"]
                        key_name='mobility_bulk_change_history'
                    else:
                        transfer_name = "bulk_change_m2m_bulk_update"
                        inventory_conflict_cols=["dt_id","device_id"]
                        key_name='m2m_bulk_change_history'

                elif tenant_name.lower() == 'spectrotel':
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_spectrotel"
                        inventory_conflict_cols=["mdt_id","mobility_device_id"]
                    else:
                        transfer_name = "bulk_change_spectrotel"
                        inventory_conflict_cols=["dt_id","device_id"]

                elif tenant_name in ('altaworx_go_tech','Altaworx - Go Tech'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_altaworx_go_tech"
                        inventory_conflict_cols=["mdt_id","mobility_device_id"]
                    else:
                        transfer_name = "bulk_change_altaworx_go_tech"
                        inventory_conflict_cols=["dt_id","device_id"]

                elif tenant_name.lower() in ('apitesttenant'):
                    if int(service_provider_id) in telegence_ids:
                        transfer_name = "bulk_change_mobility_apitesttenant"
                    else:
                        transfer_name = "bulk_change_apitesttenant"
                else:
                    logging.info("Tenant not found in save_data_20_from_10")
                    raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")


            delay_flag = False
            log_status_check_flag = False

            sqs_postgres_data={"sim_management_bulk_change":postgres_data["sim_management_bulk_change"]}

            # if transfer_name == "bulk_change_mobility":
            change_type_get = postgres_data["sim_management_bulk_change"][0][
                "change_request_type"
            ]
            logging.info(f"Change type got is {change_type_get}")
            if change_type_get == "Activate New Service":
                logging.info(f"Change type is Activate New Service")
                delay_flag = True
                log_status_check_flag = True
            else:
                log_status_check_flag = False
            # else:
            #     log_status_check_flag = False
            #     delay_flag = False

            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(f"ID ISSUE 1 conn {postgres_conn1}")
            mapping_table = os.getenv("MAPPING_TABLE")
            # getting details from db
            mapping_details_query = f"select db_name_20,db_config,reverse_table_mapping,reverse_col_mapping,data_from_10,update_cond_cols,db_name_10,db_config from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            logging.info(f"ID ISSUE 1.5 {mapping_details_query}")
            mapping_details = self.execute_query(postgres_conn1, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            table_info_dict = mapping_details["data_from_10"]
            logging.info(f"ID ISSUE 2 {table_info_dict}")
            update_cond_20 = mapping_details["update_cond_cols"]
            mssql_config = mapping_details.get("db_config", {})  # ssms db config details
            db_name_10 = mapping_details.get("db_name_10", {})
            logging.info("mssql configurations", mssql_config)

            '''(
                from_host,
                from_port,
                from_db,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()'''
            if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                logging.info("no mappings present for the configurations so returning the function")
                return True


            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )

            main_details_list = table_info_dict[
                "main"
            ]  # get info list from db which helps in getting data from 10
            logging.info(f"ID ISSUE 3 {main_details_list}")

            # logging.info(f"Main dict {main_result_dict}")

            db_name_20 = mapping_details["db_name_20"]
            logging.info(f"DB Name is {db_name_20}")
            #hardcoding from host cuz its taking uat
            # hostname='amoppostoct19.c3qae66ke1lg.us-east-1.rds.amazonaws.com'
            postgres_conn = self.create_connection(
                db_type, hostname, db_name_20, user, password, port
            )
            logging.info(f"Postgres Conn {postgres_conn}")
            main_cond_dict = update_cond_20[
                "main"
            ]  # get the dict from db whic contains condition params
            main_multiple_col_conditions = update_cond_20["main_multi_col"]
            dependent_cond_dict = update_cond_20["dependent"]

            reverse_tables = mapping_details["reverse_table_mapping"]
            reverse_col_mappings = mapping_details["reverse_col_mapping"]
            dependent_info_list = table_info_dict[
                "dependent"
            ]  # get info list from db which helps in getting data from 10
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            try:
                if tenant_name:
                    common_utils_conn=self.create_connection(db_type,hostname,'common_utils',user,password,port)
                    tenant_name_q=f"select db_name from tenant where tenant_name='{tenant_name}' and is_active=true and is_deleted=false"
                    tenant_name_res=self.execute_query(common_utils_conn,tenant_name_q)
                    # if tenant_name_res is not None and 'db_name' in tenant_name_res and tenant_name_res['db_name']:
                    if tenant_name_res is not None and not tenant_name_res.empty and 'db_name' in tenant_name_res.columns:
                        tenant_name_ = tenant_name_res['db_name'][0]
                        db_name=tenant_name_
                    else:
                        raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")
                # else:
                #     db_name='altaworx_test'
            except Exception as e:
                logging.info(f"Error in fetching tenant name: {e}")
                logging.info(f"{id_10} id_20 {id_20} Error in fetching tenant name: {e}")
                # db_name = "altaworx_test"

            logging.info(f"CHCK 11 conn variables {hostname,port,user,password,db_type,db_name}")
            postgres_conn_a = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(f"CONN is {postgres_conn_a}")
            logging.info(f"ID ISSUE 4 CHECK 111 mappings are {main_details_list}")

            main_result_dict, keep_trying_flag = self.get_10_data(
                transfer_name,
                mssql_conn,
                id_10,
                main_details_list,
                log_status_check_flag,
                main_flag=True,
            )
            logging.info(
                f"CheckPoint 1 1.0 data obtained::: id_10 {id_10} and 2.0 id is {id_20} flag is {keep_trying_flag}"
            )
            logging.info(
                f"Data dict obtained from 1.0 for main tables: \n {main_result_dict}"
            )

            loop_start_time = time.time()

            while keep_trying_flag == True:
                logging.info(
                    f"Chenckpoint 2 Keep Trying flag is {keep_trying_flag} id_10 {id_10} and 2.0 id is {id_20} "
                )
                main_insert_data = self.map_cols(
                    reverse_tables, reverse_col_mappings, main_result_dict
                )
                logging.info(f"Main insert data is {main_insert_data}")
                insert_main_dict = self.main_save_data_t0_20_bulk_update(
                    main_insert_data,
                    update_cond_20["main"],
                    update_cond_20["main_multi_col"],
                    id_20,
                    postgres_conn,
                    {},
                    update_cond_20["dependent"],
                    tenant_id
                )
                logging.info(f"insert_main_dict is completed when keep trying flag is true ")
                main_result_dict, keep_trying_flag = self.get_10_data(
                    transfer_name,
                    mssql_conn,
                    id_10,
                    main_details_list,
                    log_status_check_flag,
                    main_flag=True,
                )

                logging.info(f"insert_dependent_data is completed when keep trying flag is true ")

                logging.info(f"Check Point 3 Keep trying flag is {keep_trying_flag}")
                loop_elapsed_time = time.time() - loop_start_time
                logging.info(f"Loop elapsed time is {loop_elapsed_time}")


                if log_status_check_flag is True:
                    logging.info(
                        f"for This particular type we need to keep syning dependent tables too"
                    )
                    dependent_dict, where_val_list = self.get_10_data(
                        transfer_name,
                        mssql_conn,
                        id_10,
                        dependent_info_list,
                        log_status_check_flag,
                        main_flag=False,
                        main_result_dict=main_result_dict,
                        tenant_id_str=tenant_id_str
                    )
                    dependent_insert_data = self.map_cols(
                        reverse_tables, reverse_col_mappings, dependent_dict
                    )
                    logging.info(f"Dependent_dict is") #{dependent_insert_data}
                    insert_dependent_data = self.main_save_data_t0_20_bulk_update(
                        {},
                        main_cond_dict,
                        main_multiple_col_conditions,
                        id_20,
                        postgres_conn,
                        dependent_insert_data,
                        dependent_cond_dict,
                        tenant_id,
                        inventory_conflict_cols
                    )

                if loop_elapsed_time > 720:
                    # logging.info(f"Time exceeded 12 minutes. Breaking the loop forcefully. id_10: {id_10}, id_20: {id_20}")
                    # error_msg=f"Counter exceeded 200. Breaking the loop forcefully. id_10: {id_10}, id_20: {id_20}"\

                    #  adding sqs function to continue after 12 min
                    logging.info(
                        f"Time exceeded 12 minutes. Sending to SQS for continued processing. id_10: {id_10}, id_20: {id_20}"
                    )
                    if transfer_name in ("bulk_change", "bulk_change_mobility", "bulk_change_spectrotel", "bulk_change_mobility_spectrotel","bulk_change_bulk_update_mobility","bulk_change_m2m_bulk_update","bulk_change_altaworx_go_tech","bulk_change_mobility_altaworx_go_tech","bulk_change_apitesttenant","bulk_change_mobility_apitesttenant"):
                        # update_query=f"update sim_management_bulk_change set progress='Error in Sync', error_msg={error_msg} where id={id_20}"
                        # logging.info(f"Going to execute update")
                        # update_data_dict={"progress":"Time limit Exceeded, Sync Stopped","error_msg":f"Time limit exceeded {loop_elapsed_time}"}
                        # ue=self.update_table(postgres_conn_a, 'sim_management_bulk_change', update_data_dict, {'id':id_20})
                        # keep_trying=False
                        # break

                        message_body = {
                            "id_10": id_10,
                            "id_20": id_20,
                            "transfer_name": transfer_name,
                            "elapsed_time": loop_elapsed_time,
                            "continuation": True,
                            "path": "/save_data_20_from_10_bulk_update",
                            "access_token": data_all["access_token"],
                            "data_all": {"access_token": data_all["access_token"]},
                            "postgres_data": sqs_postgres_data,
                            'sqs_call':True,
                            'tenant_name':tenant_name,
                            'service_provider_id':service_provider_id,
                            'parent_tenant_id':parent_tenant_id,
                            'sub_tenant_id':sub_tenant_id
                        }

                        try:
                            logging.info(
                                f"sqs queue message sending ------- for continued processing"
                            )
                            o = self.send_msg_sim_management_trigger_queue(message_body)
                            logging.info("Successfully queued for continued processing")
                            return True
                        except Exception as e:
                            logging.info(f"Error in SQS Queue Calling {e}")
                            logging.info(f"Going to insert dependent data")
                            ###################### saving dependent data
                            dependent_dict,where_val_list=self.get_10_data(transfer_name,mssql_conn,id_10,dependent_info_list,log_status_check_flag,main_flag=False,main_result_dict=main_result_dict,tenant_id_str=tenant_id_str)
                            # logging.info(f"Data dict obtained from 1.0 for dependent tables: \n {dependent_dict} \n {where_val_list}")
                            dependent_insert_data=self.map_cols(reverse_tables,reverse_col_mappings,dependent_dict)
                            # logging.info(f"Dependent_dict is {dependent_insert_data}")
                            insert_dependent_data=self.main_save_data_t0_20_bulk_update({},main_cond_dict,main_multiple_col_conditions,id_20,postgres_conn,dependent_insert_data,dependent_cond_dict, tenant_id=tenant_id,inventory_conflict_cols=inventory_conflict_cols)
                            keep_trying=False
                            sqs_flag=True
                            update_data_dict={"progress":"sqs has error, Sync Stopped","error_msg":f"Time limit exceeded {loop_elapsed_time} and sqs queue failed"}
                            ue=self.update_table(postgres_conn_a, 'sim_management_bulk_change', update_data_dict, {'id':id_20})
                            return False

            logging.info(
                f"CheckPoint 4 Keep trying flag is {keep_trying_flag} and id_10 {id_10} and 2.0 id is {id_20} doing a final update"
            )
            main_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, main_result_dict
            )
            insert_main_dict = self.main_save_data_t0_20(
                main_insert_data,
                update_cond_20["main"],
                update_cond_20["main_multi_col"],
                id_20,
                postgres_conn,
                {},
                update_cond_20["dependent"],
                tenant_id
            )
            dependent_dict, where_val_list = self.get_10_data(
                transfer_name,
                mssql_conn,
                id_10,
                dependent_info_list,
                log_status_check_flag,
                main_flag=False,
                main_result_dict=main_result_dict,
                tenant_id_str=tenant_id_str
            )
            dependent_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, dependent_dict
            )

            insert_dependent_data = self.main_save_data_t0_20_bulk_update(
                        {},
                        main_cond_dict,
                        main_multiple_col_conditions,
                        id_20,
                        postgres_conn,
                        dependent_insert_data,
                        dependent_cond_dict,
                        tenant_id,
                        inventory_conflict_cols
                    )

            logging.info(
                f"Keep Trying flag {keep_trying_flag},id_10 {id_10} and 2.0 id is {id_20} Updating Dependent tables"
            )
            dependent_dict, where_val_list = self.get_10_data(
                transfer_name,
                mssql_conn,
                id_10,
                dependent_info_list,
                log_status_check_flag,
                main_flag=False,
                main_result_dict=main_result_dict,
                tenant_id_str=tenant_id_str
            )
            # logging.info(f"Data dict obtained from 1.0 for dependent tables: \n {dependent_dict} \n {where_val_list}")
            dependent_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, dependent_dict
            )
            logging.info(f"Dependent_dict is") #{dependent_insert_data}
            logging.info(f"inventory conflict cols based on service_provider {inventory_conflict_cols}")
            # logging.info(f"inventory conflict cols based on service_provider {inventory_conflict_cols}")
            logging.info(f"L1 Before sending to main save data dependent dict keys are {dependent_insert_data.keys()}")

            loop_after_elapsed_time=time.time()-start_time
            logging.info(f"Loop after elapsed time {loop_after_elapsed_time}")
            history_data_del = dependent_insert_data.pop("device_history",
                                                            dependent_insert_data.pop("mobility_device_history", None))
            logging.info(f"L2 Before sending to main save data dependent dict keys are {dependent_insert_data.keys()}")

            insert_dependent_data = self.main_save_data_t0_20_bulk_update(
                {},
                main_cond_dict,
                main_multiple_col_conditions,
                id_20,
                postgres_conn,
                dependent_insert_data,
                dependent_cond_dict,
                tenant_id,
                inventory_conflict_cols
            )
            logging.info(f"Calling sync for history data")
            try:

                logging.info(f"L1 Need to call sync to update inventory history")
                api_url = os.environ.get("SERVICE_LINE_API_URL", "")
                api_payload = {
                    "data": {
                        "path": "/lambda_sync_jobs_",
                        "key_name": key_name,
                        "tenant_name": tenant_name
                    }
                }
                response = requests.post(api_url, json=api_payload)
                if response.status_code == 200:
                    current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    logging.info(
                        f"API call successful for history. Data sync call is successfully done"
                    )
                else:
                    logging.info(
                        f"API call failed for history with status code: {response.status_code}"
                    )
            except Exception as e:
                logging.info(
                    f"Error occurred while calling the API for history {e}"
                )

            if transfer_name in ("bulk_change", "bulk_change_mobility", "bulk_change_spectrotel", "bulk_change_mobility_spectrotel","bulk_change_bulk_update_mobility","bulk_change_m2m_bulk_update","bulk_change_altaworx_go_tech","bulk_change_mobility_altaworx_go_tech","bulk_change_apitesttenant","bulk_change_mobility_apitesttenant"):
                # update_query = f"update sim_management_bulk_change set progress='Sync Completed' where id={id_20}"
                logging.info(f"Going to execute update")
                update_data_dict = {"progress": "Sync Completed"}
                logging.info(f"CONN UPDATE {postgres_conn_a}")
                ue = self.update_table(
                    postgres_conn_a,
                    "sim_management_bulk_change",
                    update_data_dict,
                    {"id": id_20},
                )

            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            logging.info(f"Time Consumed at save_data_20_from_10 for {transfer_name} is {time_consumed}")

            return True

        except Exception as e:

            logging.info(
                f"Error while fetching data from 1.0 and saving it int 2.0 : {e}"
            )
            error_msg = f"save_data_20_from_10 - Error while fetching data from 1.0 and saving it int 2.0 : {e}"
            if transfer_name in ("bulk_change", "bulk_change_mobility", "bulk_change_spectrotel", "bulk_change_mobility_spectrotel","bulk_change_bulk_update_mobility","bulk_change_m2m_bulk_update","bulk_change_altaworx_go_tech","bulk_change_mobility_altaworx_go_tech","bulk_change_apitesttenant","bulk_change_mobility_apitesttenant"):
                # update_query=f"update sim_management_bulk_change set progress='Error in Sync', error_msg={error_msg} where id={id_20}"
                logging.info(f"Going to execute update_query")
                logging.info(f"Going to execute")
                update_data_dict = {"progress": "Error in Sync", "error_msg": error_msg}
                ue = self.update_table(
                    postgres_conn_a,
                    "sim_management_bulk_change",
                    update_data_dict,
                    {"id": id_20},
                )

            return False



# if __name__ == "__main__":
#     scheduler = DataTransfer()
#     postgres_data={"sim_management_bulk_change":[{"service_provider_id":1,"tenant_id":1,"device_status_id":1,"status":"NEW","change_request_type_id":1,"processed_by":"vyshnavi","created_by":"vtest"}],"sim_management_bulk_change_request":[{"bulk_change_id":20,"iccid":56789098764,"status":"NEW","change_request":"{\"UpdateStatus\":\"Activated\",\"IsIgnoreCurrentStatus\":false,\"PostUpdateStatusId\":4,\"Request\":{},\"IntegrationAuthenticationId\":0}"},{"bulk_change_id":20,"iccid":1223454556,"status":"NEW","change_request":"{\"UpdateStatus\":\"Activated\",\"IsIgnoreCurrentStatus\":false,\"PostUpdateStatusId\":4,\"Request\":{},\"IntegrationAuthenticationId\":0}"}]}

#     transfer_name='bulk_change'
#     # bc_id=scheduler.save_data_10(transfer_name,postgres_data)
#     # print(f"bd _id is {bc_id}")

#     bulk_change_id=2700 #data present in 10
#     id_20=7560

#     scheduler.save_data_20_from_10(bulk_change_id,id_20,transfer_name)
