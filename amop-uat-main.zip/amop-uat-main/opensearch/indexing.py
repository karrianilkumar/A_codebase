from opensearchpy import OpenSearch, helpers
import psycopg2
from datetime import datetime
import uuid
import math
import ast
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import pandas as pd
import boto3
import psycopg2
import io
import concurrent.futures
import logging
import time
from io import BytesIO
from datetime import datetime, timedelta
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows
import threading  # For asynchronous execution
import time
from io import StringIO
import json
from ast import literal_eval
from decimal import Decimal
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
import re
import pytz
from pytz import timezone
import datetime
from tempfile import TemporaryDirectory  # Add this import
import zipfile
import os
from decimal import Decimal, ROUND_HALF_UP
from functools import reduce
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from requests import get
logging = Logging(name="opensearch")

db_config = {
    'host': os.getenv('HOST'),  
    'port': os.getenv('PORT'),      
    'user': os.getenv('USER'),     
    'password': os.getenv('PASSWORD'),
    "multi_schema":False,
}



# Connect to OpenSearch
es = OpenSearch(
    [os.getenv('Opensearch_URL')],
    http_auth=(os.getenv('Opensearch_USERNAME'), os.getenv('Opensearch_PASSWORD')),
    use_ssl=True,
    verify_certs=True,
    timeout=60
)

def get_tenant_id(tenant_name):
    try:
        # Establish connection
        database = DB("common_utils", **db_config)  # Assuming DB is a predefined class for database connection
        query = f"""
            SELECT id 
            FROM tenant 
            WHERE tenant_name = '{tenant_name}';
        """

        df = database.execute_query(query, True)  # Execute query and return result
        if not df.empty:
            id = df.iloc[0]["id"]  # Extract the "id" value from the first row
            logging.info(f"### get_tenant_id {id}")
            return id  # Return the ID
        logging.info(f"### No tenant found with name: {tenant_name}")
        return None  # Return None if no record is found

    except Exception as e:
        logging.error(f"### Error occured: {e}")
        return None

def get_service_provider_bk(provider_id,database):
    try:
        query = f"""
            SELECT display_name
            FROM serviceprovider
            WHERE id = '{provider_id}';
        """
        df = database.execute_query(query, True)  # Execute query using the passed database
        if not df.empty:
            display_name = df.iloc[0]["display_name"]  # Extract the "display_name" value from the first row
            logging.info(f"### get_service_provider {display_name}")
            return display_name  # Return the display name
        logging.info(f"### No service provider found with id: {provider_id}")
        return None  # Return None if no record is found

    except Exception as e:
        logging.error(f"### Error occurred in get_service_provider: {e}")
        return None

def get_service_provider(provider_id, tenant_database, billing_database):
    try:
        query = f"""
            SELECT display_name
            FROM serviceprovider
            WHERE id = '{provider_id}';
        """
        df = tenant_database.execute_query(query, True)  # Execute query using the passed database
        display_name = None
        if not df.empty:
            display_name = df.iloc[0]["display_name"]  # Extract the "display_name" value from the first row
        # If not found, empty, or only whitespace, try billing_database
        if not display_name or str(display_name).strip() == "":
            df_billing = billing_database.execute_query(query, True)  # Execute query using the billing database
            if not df_billing.empty:
                display_name = df_billing.iloc[0]["display_name"]  # Extract the "display_name" value from the first row
        if display_name and str(display_name).strip() != "":
            logging.info(f"### get_service_provider {display_name}")
            return display_name  # Return the display name
        logging.info(f"### No service provider found with id: {provider_id}")
        return None  # Return None if no record is found

    except Exception as e:
        logging.error(f"### Error occurred in get_service_provider: {e}")
        return None


def get_table_schema(conn, table_name):
    query = """
        SELECT column_name, data_type
        FROM information_schema.columns
        WHERE table_name = %s
        ORDER BY ordinal_position
    """
    with conn.cursor() as cur:
        cur.execute(query, (table_name,))
        columns = cur.fetchall()

    return {column[0]: column[1] for column in columns}

def get_ranges(elements, range_size=20):
    start_range = 0
    end_range = range_size
    ranges = []
    # Loop through the elements to group them into ranges
    while start_range <= elements[-1]:
        # Get all elements that are within the current range
        in_range = [el for el in elements if start_range <= el <= end_range]

        # If there are elements in the range, add the range to the result
        if in_range:
            ranges.append(f"{start_range} - {end_range}")

        # Move to the next range
        start_range = end_range + 1
        end_range = start_range + range_size - 1

    return ranges

def parse_datetime(value):
    if value in (None, 'null', 'NULL', ''):
        return None
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value).isoformat()
        except ValueError:
            try:
                return datetime.strptime(value, '%Y-%m-%d %H:%M:%S.%f').isoformat()
            except ValueError:
                logging.warning(f"### Warning: Unable to parse date time string: {value}\n")
                return value
    elif isinstance(value, datetime):
        return value.isoformat()
    return value

def convert_value(value, data_type):
    if value in (None, 'null', 'NULL', ''):
        return None
    if data_type == 'boolean':
        return str(value).lower() in ('true', '1')
    elif data_type == 'timestamp without time zone':
        return parse_datetime(value)
    elif data_type == ('character varying', 'text'):
        return str(value)
    elif data_type == 'integer':
        return int(value)
    elif data_type == 'real':
        return float(value)
    elif data_type == 'uuid':
        try:
            return str(uuid.UUID(value))
        except ValueError:
            logging.warning(f"### Warning: Invalid UUID format: {value}\n")
            return value
    elif data_type == 'json':
        if isinstance(value, list):
            return value  # Directly return if the value is already a list
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            logging.warning(f"### Warning: Invalid JSON format: {value}\n")
            return value
    return value
    
def determine_query_type(query):
    # Check if the query is a number (integer or float)
    try:
        # Try to convert to float (float will cover both integer and float cases)
        float_value = float(query)
        if '.' in query:
            return 'float'
        else:
            return 'integer'
    except ValueError:
        # If conversion to float fails, check if it's a string of alphabets
        if query.isalpha():
            return 'alphabetic'
        else:
            # Try to parse the query as a date
            try:
                # Attempt to parse the string into a datetime object
                datetime.datetime.fromisoformat(query)
                return 'date'
            except ValueError:
                return 'VARCHAR'

def bulk_index_data(batch_data):
    table_name, rows, schema = batch_data
    actions = []
    for item in rows:
        doc = {}
        for i, column_name in enumerate(schema.keys()):
            value = item[i]
            data_type = schema[column_name]
            converted_value = convert_value(value, data_type)
            doc[column_name] = converted_value

        action = {
            "_op_type": "index",  # Use "update" if you want to update existing documents
            "_index": table_name,
            "_source": doc,
            "_id": doc.get("id")
        }
        actions.append(action)

    try:
        response = helpers.bulk(es, actions)
        logging.info(f"### Successfully indexed {response[0]} documents for {table_name}")
    except Exception as e:
        logging.error(f"### Error indexing documents: {e}")

def fetch_and_bulk_index_data(table_name):
    schema = get_table_schema(conn, table_name)
    columns_list = ', '.join([f'"{col}"' for col in schema.keys()])
    query = f"SELECT {columns_list} FROM {table_name} "

    with conn.cursor() as cur:
        cur.execute(query)
        while True:
            rows = cur.fetchmany(BATCH_SIZE)
            batch_count=batch_count+1
            if not rows:
                break
            yield (table_name, rows, schema)

def fetch_table_names():
    table_query = """
        select search_tables from open_search_index;
        """
    try:
        with conn.cursor() as cur:
            cur.execute(table_query)
            tables= cur.fetchall()
            logging.info(f"### Successfully fetched table names")
    except psycopg2.Error as e:
        logging.error(f"### Error fetching table names: {e}")

    index_tables = []
    for item in tables:
        # Check if the item is a tuple with a single string element
        if isinstance(item, tuple) and len(item) == 1:
            value = item[0]
            if value.startswith("{") and value.endswith("}"):
                # Remove curly braces and split by comma
                value = value.strip("{}").replace("'", "")
                tables = [table.strip() for table in value.split(",")]
                index_tables.extend(tables)
            else:
                index_tables.append(value)

    index_tables = list(set(index_tables))
    return index_tables

def fetch_data_with_pagination(table_name, batch_size, start_row=0):
    schema = get_table_schema(conn, table_name)
    columns_list = ', '.join([f'"{col}"' for col in schema.keys()])
    query = f"SELECT {columns_list} FROM {table_name} LIMIT %s OFFSET %s"

    with conn.cursor() as cur:
        while True:
            cur.execute(query, (batch_size, start_row))
            rows = cur.fetchall()
            if not rows:
                break
            yield (table_name, rows, schema)
            start_row += batch_size

def process_table(table_name):
    batch_size = 25000
    for batch_data in fetch_data_with_pagination(table_name, batch_size):
        logging.info(f"## got data")
        bulk_index_data(batch_data)


def get_list_view_cols(conn):
    query = """
        SELECT db_column_name FROM field_column_mapping where module_name = 'Customer Rate Plan' and table_col = 'yes'
    """
    with conn.cursor() as cur:
        cur.execute(query)

        columns = [row[0] for row in cur.fetchall()]
        return columns
def filter_boolean_fields(fields, field_types):
    """
    Filter out boolean fields from the list of fields to be searched.
    """
    return [field for field in fields if field_types.get(field) != 'boolean']

def remove_field(columns, field_to_remove):
    """
    Remove a specific field from the list of columns if it exists.
    """
    return [col for col in columns if col != field_to_remove]

def get_field_types(index_name):
    try:
        # Retrieve the mapping for the index
        mapping = es.indices.get_mapping(index=index_name)
        # Extract the mapping of the properties/fields
        properties = mapping[index_name]['mappings']['properties']

        field_types = {}
        for field, field_data in properties.items():
            field_types[field] = field_data.get('type', 'unknown')

        return field_types

    except Exception as e:
        logging.error(f"### An error occurred while retrieving field types: {e}")
        return None



def filter_supported_fields(columns, field_types):
    """
    Filters columns to include only those that support prefix queries (keyword or text).
    """
    return [col for col in columns if field_types.get(col) in ['keyword', 'text']]


def reindex_all():
    table_names = fetch_table_names()
    NUM_THREADS=4

    # Use multiprocessing Pool to parallelize the indexing process
    # with Pool(processes=NUM_PROCESSES) as pool:
    #     pool.map(process_table, table_names)
    with ThreadPoolExecutor(max_workers=NUM_THREADS) as executor:
        futures = [executor.submit(process_table, table) for table in table_names]
    conn.close()

    return {'index_Status': 'Indexing for all Docs '}

# def elasticsearch_indexing():
#     index_tables=fetch_table_names()
#     for table in index_tables:
#         fetch_and_bulk_index_data(table)


#def search_data(query, search_all_columns,index_name,):
# def search_data(query, search_all_columns, index_name, start, end,db_name):
#     if db_name == "altaworx_central":
#         index=index_name
#     else:
#         index=f"{index_name}_{db_name}"






#     search_body = {
#         "query": {
#             "bool": {
#                 "must": [
#                     {
#                         "query_string": {
#                             "query": f"{query}*",
#                             "fields": ["*"]  # Search across all fields
#                         }
#                     }
#                 ]
#             }
#         },
#         "from": start,  # Calculate the offset
#         "size": end-start  # Number of results per page
#         }



#     if index_name == "sim_management_inventory_action_history" or index_name == "sim_management_bulk_change_request":
#         custom_filter={}
#     elif index_name == "sim_management_inventory":
#         custom_filter={"is_active": True, "tenant_id": 1 }
#     else:
#         custom_filter={"is_active": True}
#     filter_clause=create_filter_clause(index_name,custom_filter)
#     if filter_clause:
#         search_body["query"]["bool"]["filter"] = filter_clause
#     try:
#         response = es.search(index=index, body=search_body)
#         cleaned_response = replace_none_with_empty(response)
#         return cleaned_response
#     except Exception as e:
#         return None

def create_filter_clause(index_name, custom_filter):
    filter_clauses = []

    # Check if a custom_filter dictionary is provided
    if custom_filter:
        for field, value in custom_filter.items():
            # Only include fields that exist in the index
            if is_field_present(index_name, field):
                filter_clauses.append({"term": {field: value}})

    # If no filters were added, return None
    if not filter_clauses:
        return None

    # Return the filter clauses
    return filter_clauses

def is_date(date_str, input_format="%m-%d-%Y"):
    """
    Checks if a given string is a valid date in the specified format. Returns True if valid, False otherwise.
    """
    try:
        date_str=datetime.datetime.strptime(date_str, input_format)
        logging.info(f"### Valid Date")
        return date_str
    except ValueError:
        logging.exception(f"Invalid Date Format")
        return False

def convert_to_opensearch_date_format(date_str, input_format="%m-%d-%Y"):
    """
    Converts a date string from the specified input format to OpenSearch format (YYYY-MM-DDTHH:mm:ss).
    """
    parsed_date = datetime.datetime.strptime(date_str, input_format)
    return parsed_date.strftime("%Y-%m-%d")

def search_data(query, search_all_columns, index_list,start,end,columns,db_name, custom_filter,page_flag,index_name,col_sort, tenant_name):
    index = index_list
    if index_name == "Inventory":
        columns.append("account_number")
    if '$' in query:
        query = query.replace('$', '')  # Remove dollar sign
    if re.fullmatch(r'[\d,]+', query):
        query = query.replace(',', '')
    if is_date(query):
        query = convert_to_opensearch_date_format(query)
    if index_name == "Inventory":
        database = DB("common_utils", **db_config)

        # Query to check if it's a subtenant
        parent_tenant_query = f'''SELECT parent_tenant_id FROM tenant WHERE tenant_name='{tenant_name}' '''
        parent_tenant_id_df = database.execute_query(parent_tenant_query, True)

        if not parent_tenant_id_df.empty:
            parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

            if parent_tenant_id is not None:
                # Update columns if needed
                updated_columns = []
                for col in columns:
                    if col == 'carrier_rate_plan_name':
                        updated_columns.append('sub_tenant_carrier_rate_plan_name')
                    elif col == 'customer_rate_plan_name':
                        updated_columns.append('sub_tenant_customer_rate_plan_name')
                    else:
                        updated_columns.append(col)
                columns = list(set(updated_columns))  # remove duplicates if any

    columns = [col for col in columns if col and col != "is_active"]
    columns=list(set(columns))
    search_body = {
        "query": {
            "bool": {
                "must": [],
                "should": [
                    
                    {
                        "multi_match": {
                            "query": str(query),
                            "fields": columns,
                            "type": "bool_prefix",
                            "operator": "and",
                            "lenient": True
                        }
                    }
                ],
                "minimum_should_match": 1
            }
        },
        "from": start,
        "size": end - start,
        "track_total_hits": True
    }
    
    
    sort_clause = None
    if index_name == "automation_rule_log":
        if is_field_present(index_list, 'id'):
            sort_clause = [
                {
                    "id": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    elif index_name == "action_history_report":
        # Apply last one year filter
        current_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        last_year_date = (datetime.datetime.utcnow() - timedelta(days=365)).strftime("%Y-%m-%d")

        date_filter = {
            "range": {
                "date_of_change": {
                    "gte": last_year_date,  # From one year ago
                    "lte": current_date     # Up to the present date
                }
            }
        }
        search_body["query"]["bool"]["must"].append(date_filter)
    else:
        if is_field_present(index_list, 'modified_date'):
            sort_clause = [
                {
                    "modified_date": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    if col_sort:
        try:
            # Extract field and order from the key
            field_to_sort, sort_order = next(iter(col_sort.items()))  
            sort_order = sort_order.lower()  # Normalize to lowercase

            # Get the field type (Assuming `get_field_type` is a defined function)
            field_type = get_field_type(index_list, field_to_sort)

            # Modify field_to_sort if it is of type "text"
            if field_type == "text":
                field_to_sort = f'{field_to_sort}.keyword'

            # Check if the field and sort order are valid
            if field_to_sort and sort_order in ["asc", "desc"]:
                sort_clause = [{field_to_sort: {"order": sort_order}}]  # Override default sort with key sorting
            else:
                logging.info("### Invalid sorting key: Ensure the format is {<field_name>: 'asc'/'desc'}.")
        except StopIteration:
            logging.info("### Error: The provided 'key' dictionary is empty or invalid.")
        except Exception as e:
            logging.info(f"### An error occurred: {e}")
    
    # search_body = {
    #     "query": {
    #         "bool": {
    #             "must": [
    #                 {
    #                     "wildcard": {
    #                         "query": f"*{query}*"  # Allows partial matches anywhere in the word
    #                     }
    #                 }
    #             ]
    #         }
    #     },
    #     "from": start,
    #     "size": end - start,
    #     "track_total_hits": True
    # }
    if sort_clause:
        search_body["sort"] = sort_clause
    
    # if page_flag == "Pagination":
    #     search_body["from"] = start  # Calculate the offset
    #     search_body["size"] = end - start  # Number of results per page
    # else:
    #     # If no pagination, use a scroll API or other mechanism to fetch all results
    #     search_body["scroll"] = "1m"   # OpenSearch max size per query (adjust as needed)
    filter_clause=create_filter_clause(index_list,custom_filter)
    if filter_clause:
        search_body["query"]["bool"]["filter"] = filter_clause
    search_body = add_customer_exists_filters(search_body, index_name, tenant_name, db_config)
    logging.info(f"### Query of an OpenSearch {search_body}")
    try:
        if index_name == "sim_management_bulk_change" and page_flag == 'Pagination':
            # Scroll API for "bulk change" index
            scroll_time = "1m"
            scroll_size = 1000
            all_hits = []

            response = es.search(index=index, body=search_body, scroll=scroll_time, size=scroll_size)
            all_hits.extend(response.get("hits", {}).get("hits", []))
            scroll_id = response.get("_scroll_id")

            # Scroll through the results
            while len(response.get("hits", {}).get("hits", [])) > 0:
                response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                all_hits.extend(response.get("hits", {}).get("hits", []))

            # Clear the scroll context
            es.clear_scroll(scroll_id=scroll_id)

            # Group records by `bulk_change_id`
            grouped_sources = {}
            for hit in all_hits:
                source = hit.get("_source", {})
                bulk_id = source.get("bulk_change_id")
                if bulk_id and bulk_id not in grouped_sources:
                    grouped_sources[bulk_id] = hit

            # Prepare paginated results
            grouped_hits = list(grouped_sources.values())
            total_records = len(grouped_hits)
            paginated_hits = grouped_hits[start:end]

            results = {
                "hits": {
                    "hits": paginated_hits,
                    "total": {"value": total_records}
                }
            }
            logging.info(f"## Successfull Pagination Global search of bulk change")
            return results,total_records
        elif start<10000 and page_flag == 'Pagination':
            try:
                response = es.search(index=index_list, body=search_body)
        
                if not response:
                    raise ValueError("No response from Elasticsearch")
                
                total_records = response['hits']['total']['value']

                # Add Inventory logic here if the index is "Inventory"
                if index_name == "Inventory":
                    logging.info("## Checking for Inventory...")

                    # Query the tenant database to check for subtenant
                    # database = DB("common_utils", **db_config)
                    # parent_tenant_query = f'''SELECT parent_tenant_id FROM tenant WHERE tenant_name='{tenant_name}' '''
                    # parent_tenant_id_df = database.execute_query(parent_tenant_query, True)

                    if not parent_tenant_id_df.empty:
                        parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]
                        if parent_tenant_id is not None:
                            # Process each hit and swap the columns if applicable (only if it's a subtenant)
                            for hit in response['hits']['hits']:
                                source = hit.get("_source", {})

                                # Only swap the columns if the tenant is a subtenant
                                if parent_tenant_id:  # If parent_tenant_id exists, treat it as a subtenant
                                    # **Column Swapping Logic for Inventory**
                                    if 'customer_rate_plan_name' in source and 'carrier_rate_plan_name' in source:
                                        # Swap the contents of the two columns
                                        source['customer_rate_plan_name'], source['carrier_rate_plan_name'] = (
                                            source['sub_tenant_customer_rate_plan_name'],
                                            source['sub_tenant_carrier_rate_plan_name']
                                        )

                                # Update the hit with the swapped columns
                                hit["_source"] = source  # Update the _source with swapped data
                            
                    else:
                        logging.info("### No parent tenant ID found for this tenant. Skipping column swap.")
                
                cleaned_response = replace_none_with_empty(response, index_list)
                
                if cleaned_response is None:
                    raise ValueError("The cleaned response is None.")

                logging.info(f"## Got Response from Opensearch")
                return response, total_records
            except Exception as e:
                logging.info(f"## An error occurred while sub tenant searching: {e}")
                return None
    except Exception as e:
        logging.exception(f"## An error occurred while global searching: {e}")
        return None
    try:
        scroll_time = "1m"
        scroll_size = 10000
        search_body.pop("from", None)
        search_body["size"] = scroll_size
        if index_name == "inventory_export" and page_flag == "Nopagination":
            try:
                database = DB("common_utils", **db_config)
                # Query to check if it's a subtenant
                parent_tenant_query = f'''SELECT parent_tenant_id FROM tenant WHERE tenant_name='{tenant_name}' '''
                parent_tenant_id_df = database.execute_query(parent_tenant_query, True)

                if not parent_tenant_id_df.empty:
                    parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

                    if parent_tenant_id is not None:
                        for clause in search_body['query']['bool']['must']:
                            for key in ['term', 'terms']:
                                if key in clause:
                                    term_key = next(iter(clause[key].keys()))
                                    if term_key == 'carrier_rate_plan_name.keyword':
                                        value = clause[key].pop(term_key)
                                        clause[key]['sub_tenant_carrier_rate_plan_name.keyword'] = value
                                    elif term_key == 'customer_rate_plan_name.keyword':
                                        value = clause[key].pop(term_key)
                                        clause[key]['sub_tenant_customer_rate_plan_name.keyword'] = value  

                        # Perform search for inventory index
                        response = es.search(index=index_list, body=search_body)
                        total_records = response['hits']['total']['value']

                        all_hits = response.get("hits", {}).get("hits", [])
                        fetched_records = all_hits
                        while True:
                            if len(fetched_records) >= total_records:
                                fetched_records = fetched_records[:total_records]
                                break

                            scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                            hits = scroll_response.get('hits', {}).get('hits', [])

                            if not hits:
                                logging.info(f"## No more records found.")
                                break

                            fetched_records.extend(hits)

                            # Update scroll_id for the next batch
                            scroll_id = scroll_response.get('_scroll_id')
                            if not scroll_id:
                                logging.info("## No scroll ID found in subsequent response.")
                                break

                    
                        # Process each hit and swap the columns if applicable (only if it's a subtenant)
                        for hit in fetched_records:
                            source = hit.get("_source", {})

                            # Only swap the columns if the tenant is a subtenant
                            if parent_tenant_id:  # If parent_tenant_id exists, treat it as a subtenant
                                
                                if 'customer_rate_plan_name' in source and 'carrier_rate_plan_name' in source:
                                    source['customer_rate_plan_name'], source['carrier_rate_plan_name'] = (
                                        source['sub_tenant_customer_rate_plan_name'],
                                        source['sub_tenant_carrier_rate_plan_name']
                                    )

                            # Update the hit with the swapped columns
                            hit["_source"] = source  # Update the _source with swapped data

                        # Return the modified hits after column swap
                        # cleaned_response = {
                        #     "hits": {
                        #         "hits": fetched_records,  # Return the modified hits with swapped data
                        #         "total": {"value": total_records}
                        #     }
                        # }
                        # return replace_none_with_empty(fetched_records, index_list),total_records
                        logging.info(f"## Got Response from Open Search")
                        return fetched_records,total_records                      
                    else:
                        response = es.search(index=index_list, body=search_body, scroll=scroll_time)
                        response = replace_none_with_empty(response, index_list)
                
                        scroll_id = response.get('_scroll_id')
                        if not scroll_id:
                            logging.info("## No scroll ID returned.")
                            return None

                        # Retrieve the hits
                        all_hits = response['hits']['hits']
                        total_records = response['hits']['total']['value']
                        fetched_records = all_hits
                        while True:
                            if len(fetched_records) >= total_records:
                                fetched_records = fetched_records[:total_records]
                                break

                            scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                            hits = scroll_response.get('hits', {}).get('hits', [])

                            if not hits:
                                logging.info("## No more records found.")
                                break

                            fetched_records.extend(hits)

                            # Update scroll_id for the next batch
                            scroll_id = scroll_response.get('_scroll_id')
                            if not scroll_id:
                                logging.info(f"## Error: No scroll ID found in subsequent response.")
                                break

                        

                        # Inventory Logic for 'Nopagination'
                        
                        total_records = len(fetched_records)
                        es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
                        cleaned_response = replace_none_with_empty(fetched_records, index_list)
                        # return cleaned_response, len(fetched_records)
                        return fetched_records, len(fetched_records)
            
            except Exception as e:
                logging.exception(f"### An error occurred while searching in Whole search data: {e}")
                return None
        else:
            response = es.search(index=index_list, body=search_body, scroll=scroll_time)
            response = replace_none_with_empty(response,index_list)
            
            scroll_id = response.get('_scroll_id')
            if not scroll_id:
                logging.info("## Error: No scroll ID returned.")
                return None

            # Retrieve the hits
            all_hits = response['hits']['hits']
            total_records = response['hits']['total']['value']



        
            if page_flag == "Pagination":  # Check if flag is set for paginated results (scrolling)
                fetched_records = all_hits
                while scroll_id and len(fetched_records) < end:
                    scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                    hits = scroll_response.get('hits', {}).get('hits', [])

                    if not hits:
                        logging.info("## No more records found.")
                        break

                    fetched_records.extend(hits)

                    # Update scroll_id for the next batch
                    scroll_id = scroll_response.get('_scroll_id')
                    if not scroll_id:
                        logging.info("## No scroll ID found in subsequent response.")
                        break

                # Return the records for the pagination range requested (start to end)
                
                paginated_results = fetched_records[start:end]
                es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
                cleaned_response = replace_none_with_empty(paginated_results,index_list)
                # return cleaned_response,total_records
                return paginated_results,total_records
            elif page_flag == "Nopagination":  # Handle fetching all records without pagination
                fetched_records = all_hits
                while True:
                    if len(fetched_records) >= total_records:
                        fetched_records = fetched_records[:total_records]
                        break

                    scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                    hits = scroll_response.get('hits', {}).get('hits', [])

                    if not hits:
                        logging.info("### No more records found.")
                        break

                    fetched_records.extend(hits)

                    # Update scroll_id for the next batch
                    scroll_id = scroll_response.get('_scroll_id')
                    if not scroll_id:
                        logging.info("### No scroll ID found in subsequent response.")
                        break
                if index_name == 'sim_management_bulk_change':
                    grouped_sources = {}
                    for hit in fetched_records:
                        source = hit.get("_source", {})
                        bulk_id = source.get("bulk_change_id")
                        if bulk_id and bulk_id not in grouped_sources:
                            grouped_sources[bulk_id] = hit

                # Prepare paginated results
                if index_name == 'sim_management_bulk_change':
                    fetched_records = list(grouped_sources.values())
                total_records = len(fetched_records)
                es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
                cleaned_response = replace_none_with_empty(fetched_records,index_list)
                # return cleaned_response,len(fetched_records)
                return fetched_records,len(fetched_records)
            else:
                    # If flag is not set, just return the first batch of results
                    return all_hits,total_records

    except Exception as e:
        logging.exception(f"## An error occurred while searching in Global search data: {e}")
        return None
    

def create_filter_clause(index_name, custom_filter):
    filter_clauses = []
    if custom_filter:
        for field, value in custom_filter.items():
            # Skip fields not in index
            if not is_field_present(index_name, field):
                continue
            field_type = get_field_type(index_name, field)
            if field_type == "text":
                field = f"{field}.keyword"
            if isinstance(value, list):
                if len(value) == 1:
                    filter_clauses.append({"term": {field: value[0]}})
                elif len(value) > 1:
                    filter_clauses.append({"terms": {field: value}})
            else:
                filter_clauses.append({"term": {field: value}})
    return filter_clauses if filter_clauses else None

# def create_filter_clause(index_name, custom_filter):
#     filter_clauses = []

#     # Check if a custom_filter dictionary is provided
#     if custom_filter:
#         for field, value in custom_filter.items():
#             # Only include fields that exist in the index
#             if is_field_present(index_name, field):
#                 filter_clauses.append({"term": {field: value}})

#     # If no filters were added, return None
#     if not filter_clauses:
#         return None

#     # Return the filter clauses
#     return filter_clauses


def get_field_type(index_name, field_name):
    """Fetch the type of a field from the OpenSearch index mapping."""
    try:
        index_name=index_name[0]
        mapping = es.indices.get_mapping(index=index_name)

        # Navigate to the properties of the index
        properties = mapping[index_name]['mappings']['properties']

        # Check if the field exists
        if field_name in properties:
            return properties[field_name].get('type', 'unknown')  # Return the field type
        else:
            return None  # Field does not exist
    except Exception as e:
        logging.exception(f"## Error fetching field type: {e}")
        return None

def is_valid_date(date_str):
    # List of possible date formats
    date_formats = ["%d-%m-%Y %H:%M:%S", "%m-%d-%Y %H:%M:%S"]
    
    for date_format in date_formats:
        try:
            # Try parsing the date with each format
            datetime.datetime.strptime(date_str, date_format)
            return date_format
        except ValueError:
            continue  # If this format fails, try the next one
    
    return False  # If none of the formats match, return False

def is_field_present(index_name, field_name):
    try:
        # Get the mapping for the index
        mapping = es.indices.get_mapping(index=index_name)
        # Check if the field exists in the mapping
        fields = mapping[index_name]['mappings']['properties']
        return field_name in fields
    except Exception as e:
        logging.exception(f"### An error occurred while checking field presence: {e}")
        return False

def convert_filter_values(filters, index_name):
    converted_filters = {}
    for field_name, values in filters.items():
        field_type = get_field_type(index_name, field_name)

        # Convert values based on field type
        if field_type == "integer":
            converted_filters[field_name] = [int(v) for v in values]
        elif field_type == "float":
            converted_filters[field_name] = [float(v) for v in values]
        elif field_type == "keyword":
            converted_filters[field_name] = [str(v) for v in values]
        else:
            converted_filters[field_name] = values
    return converted_filters

def get_field_type(index_name, field_name):
    """
    Fetch the field type from the OpenSearch index mappings.
    """
    try:
        mapping = es.indices.get_mapping(index=index_name)
        field_mapping = mapping.get(index_name, {}).get("mappings", {}).get("properties", {})
        return field_mapping.get(field_name, {}).get("type", None)
    except Exception as e:
        logging.exception(f"## An Error fetching mapping for index {index_name}: {e}")
        return None

def convert_date_format(dates, column_name="billing_cycle_end_date", current_format="%m/%d/%Y %H:%M:%S", target_format="%m/%d/%Y %H:%M:%S"):
    if isinstance(dates, list):
        formatted_dates = []
        for date_str in dates:
            try:
                date_obj = datetime.datetime.strptime(date_str, current_format)
                if column_name == "billing_cycle_end_date":
                    if date_obj.time() == pd.Timestamp("23:59:59").time():
                        date_obj = (date_obj + pd.Timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
                formatted_date = date_obj.strftime(target_format)
                formatted_dates.append(formatted_date)
            except ValueError as e:
                raise ValueError(f"Error parsing date '{date_str}': {e}")
        return formatted_dates
    else:
        try:
            date_obj = datetime.datetime.strptime(dates, current_format)
            if column_name == "billing_cycle_end_date":
                if date_obj.time() == pd.Timestamp("23:59:59").time():
                    date_obj = (date_obj + pd.Timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
            return date_obj.strftime(target_format)
        except ValueError as e:
            raise ValueError(f"Error parsing date '{dates}': {e}")

# def convert_to_tenant_timezone(date_str, tenant_time_zone, fetch=None):
#     """Converts date from Asia/Kolkata time zone to tenant's time zone (e.g., America/Chicago)."""
#     try:
#         # Handle input format with milliseconds
#         if '.' in date_str:
#             date_str = date_str.split('.')[0]  # Remove milliseconds

#         # Parse the date string in the format "YYYY-MM-DD HH:MM:SS"
#         date_obj = datetime.datetime.strptime(date_str, "%Y/%m/%d %H:%M:%S")
        
#         # Localize to UTC if no timezone info
#         if date_obj.tzinfo is None:
#             date_obj = pytz.utc.localize(date_obj)
        
#         # Convert to tenant's timezone
#         tenant_timezone = pytz.timezone(tenant_time_zone)
#         date_obj = date_obj.astimezone(tenant_timezone)
#         if fetch:
#             return date_obj.strftime("%m/%d/%Y %H:%M:%S")
#         # Return formatted date in the desired format: %m-%d-%Y %H:%M:%S
#         return date_obj.strftime("%m-%d-%Y %H:%M:%S")
#     except ValueError:
#         # If the date format is invalid, return the original string
#         return date_str

def convert_to_timezone(k, v, tenant_time_zone, index_name):
    """
    Converts a date string from 'yyyy-mm-dd' to 'mm-dd-yyyy' format.
    
    Parameters:
    - k: The key associated with the value (e.g., field name; unused in this implementation).
    - v: The date string in 'yyyy-mm-dd' format.
    - tenant_time_zone: The timezone string (e.g., 'Asia/Kolkata'; unused in this implementation).
    - index_name: The index name (e.g., for logging; unused in this implementation).
    
    Returns:
    - The reformatted date string in 'mm-dd-yyyy' format.
    
    Raises:
    - ValueError: If the input date string is invalid.
    """
    try:
        # Parse the input date string (assumes 'yyyy-mm-dd' format)
        date_obj = datetime.datetime.strptime(v, '%Y-%m-%d')
        
        # Reformat to 'mm-dd-yyyy'
        formatted_date = date_obj.strftime('%m-%d-%Y')
        
        return formatted_date
    except ValueError:
        # Handle invalid date formats (you could log using k, tenant_time_zone, index_name here if needed)
        raise ValueError(f"Invalid date format for key '{k}' in index '{index_name}': '{v}' must be in 'yyyy-mm-dd' format.")


def convert_to_tenant_timezone(k, date_str, tenant_time_zone, index_name,fetch=None):
    """Converts date from Asia/Kolkata time zone to tenant's time zone (e.g., America/Chicago)."""
    try:
        # Handle input format with milliseconds
        if '.' in date_str:
            date_str = date_str.split('.')[0]  # Remove milliseconds

        # Parse the date string in the format "YYYY-MM-DDTHH:MM:SS"
        date_obj = datetime.datetime.strptime(date_str, "%Y-%m-%dT%H:%M:%S")
        
        # Localize to UTC if no timezone info
        if date_obj.tzinfo is None:
            date_obj = pytz.utc.localize(date_obj)
        skip = (
            (index_name in ['Inventory','inventory_export'] and k in ['date_activated','last_activated_date']) or
            (index_name in ['usage_by_line_report', 'usp_report_customer_usage_by_line'] and
            k in ['customer_cycle_end_date', 'billing_cycle_end_date']) or
            (index_name in ['Export Cycle Date Report']) or
            (index_name in ['Customer Profile'] and k in ['bill_cycle_start_date'])
        )
        # Convert to tenant's timezone
        if not skip:
            tenant_timezone = pytz.timezone(tenant_time_zone)
            date_obj = date_obj.astimezone(tenant_timezone)
        if fetch:
            return date_obj.strftime("%m/%d/%Y %I:%M:%S %p")  # 12-hour format with AM/PM
        # Return formatted date in 12-hour format (with AM/PM)
        return date_obj.strftime("%m-%d-%Y %I:%M:%S %p")  # 12-hour format with AM/PM
    except ValueError:
        # If the date format is invalid, return the original string
        return date_str

def convert_to_scientific_notation(value):
    try:
        # Convert the number to scientific notation with 2 decimal points (you can adjust the precision)
        return "{:.2e}".format(float(value))
    except ValueError:
        # Handle the case where the value cannot be converted to a number
        logging.error(f"### Invalid number: {value}")
        return None

def add_customer_exists_filters(search_body, index_name, tenant_name, db_config):
    if index_name in ["inventory_export", "Inventory"]:
        common_utils_database = DB('common_utils', **db_config)
        tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
        tenant_id = tenant_data["id"].to_list()[0]
        parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]

        if parent_tenant_id:
            must_filters = [
                {"exists": {"field": "customer_id"}},
                {"exists": {"field": "customer_name"}}
            ]

            if "filter" in search_body["query"]["bool"]:
                search_body["query"]["bool"]["filter"].extend(must_filters)
            else:
                search_body["query"]["bool"]["filter"] = must_filters

    return search_body


def advance_search_data(filters,index_list,start, end,db_name,index_name,col_sort,tenant_name,is_redirected):
    logging.info(f"## Inside advance_search_data filters: {filters}")
    sort_clause = []
    search_body = {
        "query": {
            "bool": {
                "must": [],
                "should": []
            }
        },
        "from": start ,  # Start from the specified offset
        "size": end-start,
         "track_total_hits": True # Number of results to return
    }
    if index_name == "automation_rule_log":
        if is_field_present(index_list, 'id'):
            sort_clause = [
                {
                    "id.keyword": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    elif index_name == "action_history_report":
        # Apply last one year filter
        current_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        last_year_date = (datetime.datetime.utcnow() - timedelta(days=365)).strftime("%Y-%m-%d")

        date_filter = {
            "range": {
                "date_of_change": {
                    "gte": last_year_date,  # From one year ago
                    "lte": current_date     # Up to the present date
                }
            }
        }
        search_body["query"]["bool"]["must"].append(date_filter)
    else:
        if is_field_present(index_list, 'modified_date'):
            sort_clause = [
                {
                    "modified_date": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    if col_sort:
        try:
            # Extract field and order from the key
            field_to_sort, sort_order = next(iter(col_sort.items()))  
            sort_order = sort_order.lower()  # Normalize to lowercase

            # Get the field type (Assuming `get_field_type` is a defined function)
            field_type = get_field_type(index_list, field_to_sort)

            # Modify field_to_sort if it is of type "text"
            if field_type == "text":
                field_to_sort = f'{field_to_sort}.keyword'

            # Check if the field and sort order are valid
            if field_to_sort and sort_order in ["asc", "desc"]:
                sort_clause = [{field_to_sort: {"order": sort_order}}]  # Override default sort with key sorting
            else:
                logging.info("## Invalid sorting key: Ensure the format is {<field_name>: 'asc'/'desc'}.")
        except StopIteration:
            logging.error("## Error: The provided 'key' dictionary is empty or invalid.")
        except Exception as e:
            logging.exception(f"## An error occurred: {e}")
    
    
    if sort_clause:
        search_body["sort"] = sort_clause
    if filters:
        for field, values in filters.items():
            if values:  # Check if values is not empty
                field_type = get_field_type(index_list, field)
                if isinstance(values, list) and len(values) > 1:
                    if field_type in ["date", "long", "float"]:  # Adjust based on actual types returned by get_field_type
                        values = [v for v in values if v != '']  # Remove empty string
                        
                        # Update filters with cleaned values
                        filters[field] = values
                if isinstance(values, list):  # Handle lists
                    if len(values) == 1:
                        # Single value, handle boolean or other types
                        value = values[0]
                        if field in ["device_count", "total_charges", "total_charge_amount", "base_rate", "rate_charge_amt", "overage_rate_cost", "created_date", "date_activated"] and index_name in ["carrier_optimization_list_view","customer_optimization_list_view", "Customer_Rate_Plan", "Inventory", "inventory_export"]:
                            for value in values:
                                if isinstance(value, str) and ":" in value:
                                    try:
                                        # start_range, end_range = map(int, value.split(':'))
                                        # start_range = round(float(start_range))
                                        # end_range = round(float(end_range))
                                        # search_body["query"]["bool"].setdefault("must", []).append({
                                        #     "range": {
                                        #         f"{field}": {
                                        #             "gte": start_range,  # Greater than or equal to start of range
                                        #             "lte": end_range     # Less than or equal to end of range
                                        #         }
                                        #     }
                                        # })
                                        # search_body["sort"] = [
                                        #         {f"{field}": {"order": "asc"}}
                                        #     ]
                                        if field in ["created_date", "date_activated"] and is_redirected and index_name in ["Inventory", "inventory_export"]:
                                            # Parse as date range
                                            start_range, end_range = value.split(':')
                                            # Optional: validate format
                                            datetime.datetime.strptime(start_range, "%Y-%m-%d")
                                            datetime.datetime.strptime(end_range, "%Y-%m-%d")
                                            if field == "created_date":
                                                earliest_date_query = {
                                                    "size": 0,
                                                    "aggs": {
                                                        "min_date": {"min": {"field": field}}
                                                    }
                                                }
                                                response = es.search(index=index_list, body=earliest_date_query)
                                                start_range = response["aggregations"]["min_date"]["value_as_string"] if response["aggregations"]["min_date"]["value_as_string"] else end_range
                                            logging.info(f"## start_range: {start_range}, end_range: {end_range}")
                                            search_body["query"]["bool"].setdefault("must", []).append({
                                                "range": {
                                                    f"{field}": {
                                                        "gte": start_range,
                                                        "lte": end_range
                                                    }
                                                }
                                            })
                                        else:
                                            # Parse as integer range
                                            start_range, end_range = map(int, value.split(':'))
                                            search_body["query"]["bool"].setdefault("must", []).append({
                                                "range": {
                                                    f"{field}": {
                                                        "gte": start_range,
                                                        "lte": end_range
                                                    }
                                                }
                                            })
                                            search_body["sort"] = [{f"{field}": {"order": "asc"}}]
                                    except ValueError:
                                        logging.exception(f"## Invalid range format for {field}")
                                else:
                                    try:
                                        start_range = int(value)
                                        end_range = int(value)+1
                                        search_body["query"]["bool"].setdefault("must", []).append({
                                            "range": {
                                                f"{field}": {
                                                    "gte": start_range,  # Greater than or equal to start of range
                                                    "lt": end_range     # Less than or equal to end of range
                                                }
                                            }
                                        })
                                        search_body["sort"] = [
                                                {f"{field}": {"order": "asc"}}
                                            ]
                                    except ValueError:
                                        logging.exception(f"## Invalid range format for {field}")
                        elif isinstance(value, str) and value.strip() == "":
                            # Handle case where the single value is an empty string
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "bool": {
                                    "should": [
                                        {"term": {f"{field}.keyword": ""}},  # Empty string
                                        {"bool": {"must_not": {"exists": {"field": field}}}}  # Missing field
                                    ]
                                }
                            })
                        elif field in ['volte_capable', 'assigned'] and isinstance(value, str) and value.lower() in ['yes', 'no']:
                            # Convert 'yes'/'no' to boolean
                            if field == 'assigned' and index_name == 'Rate_Plan_Socs':
                                boolean_value = "Yes" if value.lower() == 'yes' else "No"
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": boolean_value}  # Use the converted boolean value
                                })
                            else:
                                boolean_value = True if value.lower() == 'yes' else False
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}": boolean_value}  # Use the converted boolean value
                                })
                        elif field in ['nsdev',"auto_change_rate_plan", "att_certified","is_billing_advance_eligible","allows_sim_pooling"] and isinstance(value, str) and value.lower() in ['true', 'false']:
                        # Handle boolean as string
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}  # Converts to a boolean
                            })
                        elif field_type == "long" and field=="bulk_change_id":  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif field in ["users", "is_active","vw_customer_rate_plans"] and isinstance(value, str) and value.lower() in ["active", "inactive"]:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": "true" if value.lower() == "active" else "false"}
                            })
                        elif field in ["optimization_type"] and index_name == "Customer_Rate_Plan":
                            # Normalize the "Cross Customer Pooling" values
                            normalized_value = "Cross Customer Pooling" if value.lower() in ["cross customer pooling", "cross customer pooling", "cross customer pooling"] else value
                            
                            if normalized_value == "Cross Customer Pooling":
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}.keyword": ["Cross Customer Pooling", "cross customer pooling", "Cross customer pooling", "Cross customer Pooling"]}
                                })
                            else:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}.keyword": [value, value.lower(), value.upper(), value.capitalize()]}
                                })
                        elif field in ["amop_apis", "carrier_apis", "email_templates"] and isinstance(value, str) and value.lower() in ["enable", "disable"]:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": "true" if value.lower() == "enable" else "disable"}
                            })
                        elif isinstance(values, (list, str)) and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.exception(f"## Invalid date format for item: {item}")
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(value, (list, str)) and field_type != "float":
                            if value is None or (isinstance(value, str) and value == "(Spaces)"):
                                if isinstance(value, str):
                                    stripped_value = ""
                                    if stripped_value == "":
                                        search_body["query"]["bool"]["must"].append({
                                            "terms": {f"{field}.keyword": ["", " ", "  "]}  # Match exact empty string, single space, and double space
                                        })
                            elif field == 'prorate':
                                if isinstance(value, str):
                                    search_body["query"]["bool"]["must"].append({
                                        "term": {f"{field}": value }
                                    })
                            elif value.strip() not in [""," "] and value != "(Spaces)":
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": value }
                                })
                        
                    
                        elif isinstance(value, bool):  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}
                            })
                        elif isinstance(value, (list, str)) and field == "billing_cycle_end_date":
                            try:
                                if isinstance(value, str):
                                    value = [value]
                                formatted_values = convert_date_format(value)
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                            except ValueError:
                                continue            
                        elif isinstance(value, (list, str)):
                            try:
                                if isinstance(value, str):
                                    value = [value]  # Convert single string to a list if it's not already a list
                                for item in value:
                                    if isinstance(item, str):  # Ensure it's a string before adding to the query
                                        # Create a match query for each item in the list
                                        search_body["query"]["bool"]["must"].append({
                                            "match": {
                                                f"{field}": item  # Using match for full-text search
                                            }
                                        })
                            except ValueError:
                                continue
                        elif isinstance(value, (list, str)):  # Single int or float value
                            converted_value = convert_to_scientific_notation(value)
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif isinstance(value, (int, float)):  # Single int or float value
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif isinstance(value, bool):  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}
                            })
                        elif isinstance(value, str) and field == 'status'  and index_list=='sim_management_bulk_change_request':  # Handle integer values
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value}
                             })
                        elif isinstance(value, str):  # Handle integer values
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                             })
                        else:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value}
                            })
                    else:
                        if field in ['nsdev', "auto_change_rate_plan", "att_certified", "is_billing_advance_eligible", "allows_sim_pooling"] and isinstance(values, list):
                            # Ensure all values in the list are lowercase and valid boolean strings
                            lower_values = [v.lower() for v in values if isinstance(v, str) and v.lower() in ['true', 'false']]
                            
                            if lower_values:  # Proceed only if the list has valid boolean strings
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": lower_values}  # Add terms filter with lowercase values
                                })
                        elif any(isinstance(v, str) and v.strip() == "" for v in values):  
                            # Handle empty string or missing field cases
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "bool": {
                                    "should": [
                                        {"term": {f"{field}.keyword": ""}},
                                        {"bool": {"must_not": {"exists": {"field": field}}}},
                                        {"terms": {f"{field}.keyword": [v for v in values if isinstance(v, str) and v.strip() != ""]}}
                                    ]
                                }
                            })
                        
                        elif field_type == "text":
                            search_body["query"]["bool"]["must"].append({
                                "terms": {f"{field}.keyword": values }
                            })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.exception(f"### Invalid date format for item: {item}")
                                        continue
                            # if formatted_values:
                            #     search_body["query"]["bool"]["must"].append({
                            #         "terms": {f"{field}": formatted_values}
                            #     })
                            if formatted_values:
                                if len(formatted_values) > 1024:
                                    # If too many dates, use a range query
                                    min_date = min(formatted_values)
                                    max_date = max(formatted_values)
                                    search_body["query"]["bool"]["filter"] = {
                                        "range": {f"{field}": {"gte": min_date, "lte": max_date}}
                                    }
                                else:
                                    # Use terms query if within limit
                                    search_body["query"]["bool"]["must"].append({
                                        "terms": {f"{field}": formatted_values}
                                    })
                        elif isinstance(values, (list, str)) and field == "billing_cycle_end_date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        formatted_value = convert_date_format(item)
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.exception(f"### An Error Occurred in formatting billing_cycle_end_date")
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.exception(f"## Invalid date format for item: {item}")
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif field in ['is_active'] and isinstance(values, (list, str)):
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str) and item.lower() == 'active':
                                    try:
                                        # Create a match query for each item in the list
                                        formatted_values.append('true')
                                    except ValueError:
                                        continue
                                elif isinstance(values, (list, str)) and item.lower() == 'inactive':
                                    try:
                                        # Create a match query for each item in the list
                                        formatted_values.append('false')
                                    except ValueError:
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(values, (list, str)):
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):  # Ensure it's a string before adding to the query
                                    try:
                                        # Create a match query for each item in the list
                                        formatted_values.append(item)
                                    except ValueError:
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {
                                        f"{field}": formatted_values  # List of values for multiple exact matches
                                    }
                                })
                        if isinstance(values, list) :
                            if all(isinstance(v, (int, float)) for v in values) : 
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {field: values}  
                                })
                        else:
                            # Multiple values in the list
                            search_body["query"]["bool"]["must"].append({
                                "terms": {f"{field}": values}
                            })
                elif isinstance(values, bool):  # Single boolean condition
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
                elif isinstance(values, int):
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
                elif isinstance(values, str):
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}.keyword": values}
                    })
                else:
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
            elif values is False:
                search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
    search_body = add_customer_exists_filters(search_body, index_name, tenant_name, db_config)
    logging.info(f"Open Search query {search_body}")
    logging.info(f"Open Search query {search_body}")
    if index_name == "Active_lines_report":
        search_body["query"]["bool"]["must"].append({
            "terms": {
                "sim_status.keyword": ["Activated", "Active", "A"]
            }
        })
        logging.info(f"Advance Search query {search_body}")
    try:
        if index_name == "sim_management_bulk_change":
            # Scroll parameters
            scroll_time = "1m"
            scroll_size = 10000
            grouped_sources = {}  # Dictionary to store unique `bulk_change_id` records

            search_body.pop('from',None)
            search_body.pop('size', None)

            # Initial search request
            response = es.search(index=index_list, body=search_body, scroll=scroll_time, size=scroll_size)
            hits = response.get("hits", {}).get("hits", [])
            scroll_id = response.get("_scroll_id")

            if not hits or not scroll_id:
                logging.info("### No hits found or scroll_id is missing.")
                return None

            # Variables to track progress
            total_processed = 0  # Number of records processed
            required_records = end - start  # Number of records needed for the current page

            # Scroll through and process records
            while hits:
                for hit in hits:
                    total_processed += 1

                    # Skip records before the `start` index
                    if total_processed <= start:
                        continue

                    # Add records after the `start` index to the grouped_sources
                    source = hit.get("_source", {})
                    bulk_id = source.get("bulk_change_id")
                    if bulk_id and bulk_id not in grouped_sources:
                        grouped_sources[bulk_id] = hit  # Add unique bulk_change_id entry

                    # Stop early if enough records are collected
                    if len(grouped_sources) >= required_records:
                        break

                # Stop scrolling if enough records are collected
                if len(grouped_sources) >= required_records:
                    break

                # Fetch the next batch of records
                response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                hits = response.get("hits", {}).get("hits", [])

            # Clear the scroll context
            if scroll_id:
                es.clear_scroll(scroll_id=scroll_id)

            # Prepare paginated results
            grouped_hits = list(grouped_sources.values())
            total_records = total_processed  # Total records processed across all batches
            paginated_hits = grouped_hits[:required_records]  # Limit to the required page size
            
            results = {
                "hits": {
                    "hits": paginated_hits,
                    "total": {"value": total_records}
                }
            }
            # return replace_none_with_empty(results, index_list)
            return results

        elif index_name == "Inventory":  # Checking for Inventory index
            try:
                
                database = DB("common_utils", **db_config) 
                # Query to check if it's a subtenant
                parent_tenant_query = f'''SELECT parent_tenant_id FROM tenant WHERE tenant_name='{tenant_name}' '''
                parent_tenant_id_df = database.execute_query(parent_tenant_query, True)

                if not parent_tenant_id_df.empty:
                    parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

                    if parent_tenant_id is not None:
                        for clause in search_body['query']['bool']['must']:
                            if 'term' in clause:
                                term_key = next(iter(clause['term'].keys()))
                                if term_key == 'carrier_rate_plan_name.keyword':
                                    # Replace the key
                                    value = clause['term'].pop(term_key)
                                    clause['term']['sub_tenant_carrier_rate_plan_name.keyword'] = value
                                elif term_key == 'customer_rate_plan_name.keyword':
                                    # Replace the key
                                    value = clause['term'].pop(term_key)
                                    clause['term']['sub_tenant_customer_rate_plan_name.keyword'] = value
                        # Perform search for inventory index
                        response = es.search(index=index_list, body=search_body)
                        total_records = response['hits']['total']['value']

                        hits = response.get("hits", {}).get("hits", [])

                        if not hits:
                            logging.info("## No hits found.")
                            return None

                        # Process each hit and swap the columns if applicable (only if it's a subtenant)
                        for hit in hits:
                            source = hit.get("_source", {})

                            # Only swap the columns if the tenant is a subtenant
                            if parent_tenant_id:  # If parent_tenant_id exists, treat it as a subtenant
                                # **Column Swapping Logic for Inventory**
                                if 'customer_rate_plan_name' in source and 'carrier_rate_plan_name' in source:
                                    # Swap the contents of the two columns
                                    source['customer_rate_plan_name'], source['carrier_rate_plan_name'] = (
                                        source['sub_tenant_customer_rate_plan_name'],
                                        source['sub_tenant_carrier_rate_plan_name']
                                    )

                            # Update the hit with the swapped columns
                            hit["_source"] = source  # Update the _source with swapped data

                        # Return the modified hits after column swap
                        cleaned_response = {
                            "hits": {
                                "hits": hits,  # Return the modified hits with swapped data
                                "total": {"value": total_records}
                            }
                        }

                        # return replace_none_with_empty(cleaned_response, index_list)
                        return cleaned_response
                    else:
                        # If parent_tenant_id_df is empty, it means it's a main tenant, not a subtenant
                        logging.info("## Main tenant detected, skipping column swap.")
                        logging.info(f"## Inventory index search_body: {search_body}")
                        logging.info(f"## Inventory index is_redirected: {is_redirected}")
                        # Perform search for main tenant (no column swap)
                        response = es.search(index=index_list, body=search_body)
                        total_records = response['hits']['total']['value']
                        cleaned_response = replace_none_with_empty(response, index_list)
                        # return cleaned_response
                        return response

                else:
                    logging.info("### No parent tenant ID found for this tenant.")
                    return None

            except Exception as e:
                logging.exception(f"### An error occurred during advanced searching for Inventory: {e}")
                return None
        else:
            # Perform regular search for non-bulk-change indices
            response = es.search(index=index_list, body=search_body)
            total_records = response['hits']['total']['value']
            cleaned_response = replace_none_with_empty(response,index_list)
            # return cleaned_response
            return response
    except Exception as e:
        logging.exception(f"### An error occurred advanced searching: {e}")
        return None

def get_service_id(account_number,current_cycle):
    customer_profile_id = int(get_customer_id(account_number))
    created_start_date = current_cycle[0].split("T")[0]  # Extract the date part
    created_end_date = current_cycle[1].split("T")[0]  # Extract the date part
    try:
        # Establish connection
        database = DB(os.getenv('BILLING_PLATFORM'), **db_config)  # Assuming DB is a predefined class for database connection
        query = f"""
            SELECT applied_services
            FROM customer_bills
            WHERE customer_profile_id = '{customer_profile_id}'
                AND created_date >= '{created_start_date}'
                AND created_date <= '{created_end_date}';
        """

        bill_details = database.execute_query(query, True)  # Assuming `fetch_one` fetches a single row
        if not bill_details.empty:
            service_ids_set = set()
            for _, row in bill_details.iterrows():
                applied_services = row["applied_services"]
                if applied_services is None:
                    continue

                if isinstance(applied_services, str):
                    try:
                        applied_services_list = literal_eval(applied_services)
                    except Exception:
                        try:
                            applied_services_list = json.loads(applied_services)
                        except Exception:
                            print(f"Could not parse applied_services: {applied_services}")
                            continue
                else:
                    applied_services_list = applied_services  # Already list-like

                for service_id in applied_services_list:
                    if service_id is not None:
                        service_ids_set.add(service_id)
        distinct_service_ids = sorted(service_ids_set)
        print(f"### Distinct Service IDs: {distinct_service_ids}")
        return distinct_service_ids
    except Exception as e:
        logging.exception(f"## An Error Occured while getting service ids as {e}")
        return None
    
def get_customer_id(account_number):
    try:
        # Establish connection
        database = DB(os.getenv('BILLING_PLATFORM'), **db_config)  # Assuming DB is a predefined class for database connection
        query = f"""
            SELECT id 
            FROM customer_profiles 
            WHERE account_number = '{account_number}';
        """

        df = database.execute_query(query,True)  # Assuming `fetch_one` fetches a single row
        if not df.empty:
            id = df.iloc[0]["id"]  # Extract
            return id  # Return the ID
        logging.info(f"## Return Customer Profile id as {id}")
        return None  # Return None if no record is found

    except Exception as e:
        logging.exception(f"## An Error Occured as {e}")
        return None

def replace_none_with_empty(data,index):
    """
    Recursively replace 'None' values with empty strings in the given dictionary or list.
    """
    
    if isinstance(data, dict):
        return {key: replace_none_with_empty(value, index) for key, value in data.items()}
    elif isinstance(data, list):
        return [replace_none_with_empty(item, index) for item in data]
    elif data is None and any(keyword in index for keyword in ["sim_management_bulk_change_view_altaworx_test"]):
        return data  # Replace None with an empty string
    elif data is None:
        return ""
    else:
        return data


def advanced_search_data(filters, index_list, start, end,flag,db_name,index_name,col_sort,tenant_name,is_redirected,scroll_time='1m'):
    logging.info(f"## Inside advanced_search_data filters: {filters}")
    sort_clause = []
    search_body = {
        "query": {
            "bool": {
                "must": [],
                "should": []
            }
        },
        "size": 10000,  # Fetch up to 10,000 records per scroll batch
        "track_total_hits": True  # Ensure we track the total number of hits
    }
    if index_name == "automation_rule_log":
        if is_field_present(index_list, 'id'):
            sort_clause = [
                {
                    "id.keyword": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    elif index_name == "action_history_report":
        # Apply last one year filter
        current_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        last_year_date = (datetime.datetime.utcnow() - timedelta(days=365)).strftime("%Y-%m-%d")

        date_filter = {
            "range": {
                "date_of_change": {
                    "gte": last_year_date,  # From one year ago
                    "lte": current_date     # Up to the present date
                }
            }
        }
        search_body["query"]["bool"]["must"].append(date_filter)
    else:
        if is_field_present(index_list, 'modified_date'):
            sort_clause = [
                {
                    "modified_date": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    if col_sort:
        try:
            # Extract field and order from the key
            field_to_sort, sort_order = next(iter(col_sort.items()))  
            sort_order = sort_order.lower()  # Normalize to lowercase

            # Get the field type (Assuming `get_field_type` is a defined function)
            field_type = get_field_type(index_list, field_to_sort)


            # Modify field_to_sort if it is of type "text"
            if field_type == "text":
                field_to_sort = f'{field_to_sort}.keyword'

            # Check if the field and sort order are valid
            if field_to_sort and sort_order in ["asc", "desc"]:
                search_body["sort"] = [{field_to_sort: {"order": sort_order}}]  # Override default sort with key sorting
            else:
                logging.info("## Invalid sorting key: Ensure the format is {<field_name>: 'asc'/'desc'}.")
        except StopIteration:
            logging.error("## Error: The provided 'key' dictionary is empty or invalid.")
        except Exception as e:
            logging.exception(f"## An error occurred: {e}")
    if sort_clause:
        search_body["sort"] = sort_clause
    
    if filters:
        for field, values in filters.items():
            if values:  # Check if values is not empty
                field_type = get_field_type(index_list, field)
                
                if isinstance(values, list) and len(values) > 1:
                    if field_type in ["date", "long", "float"]:  # Adjust based on actual types returned by get_field_type
                        values = [v for v in values if v != '']  # Remove empty string
                        
                        # Update filters with cleaned values
                        filters[field] = values
                if isinstance(values, list):  # Handle lists
                    if len(values) == 1:
                        # Single value, handle boolean or other types
                        value = values[0]
                        if field in ["device_count", "total_charges", "total_charge_amount", "base_rate", "rate_charge_amt", "overage_rate_cost", "created_date", "date_activated"] and index_name in ["carrier_optimization_list_view","customer_optimization_list_view", "Customer_Rate_Plan", "Inventory", "inventory_export"]:
                            for value in values:
                                if isinstance(value, str) and ":" in value:
                                    try:
                                        # start_range, end_range = map(int, value.split(':'))
                                        # # start_range = round(float(start_range))
                                        # # end_range = round(float(end_range))
                                        # search_body["query"]["bool"].setdefault("must", []).append({
                                        #     "range": {
                                        #         f"{field}": {
                                        #             "gte": start_range,  # Greater than or equal to start of range
                                        #             "lte": end_range     # Less than or equal to end of range
                                        #         }
                                        #     }
                                        # })
                                        # search_body["sort"] = [
                                        #         {f"{field}": {"order": "asc"}}
                                        #     ]
                                        if field in ["created_date", "date_activated"] and is_redirected and index_name in ["Inventory", "inventory_export"]:
                                            # Parse as date range
                                            start_range, end_range = value.split(':')
                                            # Optional: validate format
                                            datetime.datetime.strptime(start_range, "%Y-%m-%d")
                                            datetime.datetime.strptime(end_range, "%Y-%m-%d")
                                            earliest_date_query = {
                                                "size": 0,
                                                "aggs": {
                                                    "min_date": {"min": {"field": field}}
                                                }
                                            }
                                            response = es.search(index=index_list, body=earliest_date_query)
                                            start_range = response["aggregations"]["min_date"]["value_as_string"] if response["aggregations"]["min_date"]["value_as_string"] else end_range
                                            logging.info(f"## start_range: {start_range}, end_range: {end_range}")
                                            search_body["query"]["bool"].setdefault("must", []).append({
                                                "range": {
                                                    f"{field}": {
                                                        "gte": start_range,
                                                        "lte": end_range
                                                    }
                                                }
                                            })
                                        else:
                                            # Parse as integer range
                                            start_range, end_range = map(int, value.split(':'))
                                            search_body["query"]["bool"].setdefault("must", []).append({
                                                "range": {
                                                    f"{field}": {
                                                        "gte": start_range,
                                                        "lte": end_range
                                                    }
                                                }
                                            })
                                            search_body["sort"] = [{f"{field}": {"order": "asc"}}]
                                    except ValueError:
                                        logging.info(f"## Invalid range format for {field}")
                                else:
                                    try:
                                        start_range = int(value)
                                        end_range = int(value)+1
                                        search_body["query"]["bool"].setdefault("must", []).append({
                                            "range": {
                                                f"{field}": {
                                                    "gte": start_range,  # Greater than or equal to start of range
                                                    "lt": end_range     # Less than or equal to end of range
                                                }
                                            }
                                        })
                                        search_body["sort"] = [
                                                {f"{field}": {"order": "asc"}}
                                            ]
                                    except ValueError:
                                        logging.exception(f"## Invalid range format for {field}")
                        elif isinstance(value, str) and value.strip() == "":
                            # Handle case where the single value is an empty string
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "bool": {
                                    "should": [
                                        {"term": {f"{field}.keyword": ""}},  # Empty string
                                        {"bool": {"must_not": {"exists": {"field": field}}}}  # Missing field
                                    ]
                                }
                            })
                        elif field in ['volte_capable', 'assigned'] and isinstance(value, str) and value.lower() in ['yes', 'no']:
                            # Convert 'yes'/'no' to boolean
                            if field == 'assigned' and index_name == 'Rate_Plan_Socs':
                                boolean_value = "Yes" if value.lower() == 'yes' else "No"
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": boolean_value}  # Use the converted boolean value
                                })
                            else:
                                boolean_value = True if value.lower() == 'yes' else False
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}": boolean_value}  # Use the converted boolean value
                                })
                        elif field in ['nsdev',"auto_change_rate_plan", "att_certified","is_billing_advance_eligible","allows_sim_pooling"] and isinstance(value, str) and value.lower() in ['true', 'false']:
                        # Handle boolean as string
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}  # Converts to a boolean
                            })
                        elif field_type == "long" and field=="bulk_change_id":  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif field in ["users", "is_active","vw_customer_rate_plans"] and isinstance(value, str) and value.lower() in ["active", "inactive"]:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": "true" if value.lower() == "active" else "false"}
                            })
                        elif field in ["optimization_type"] and index_name == "Customer_Rate_Plan":
                            # Normalize the "Cross Customer Pooling" values
                            normalized_value = "Cross Customer Pooling" if value.lower() in ["cross customer pooling", "cross customer pooling", "cross customer pooling"] else value
                            
                            if normalized_value == "Cross Customer Pooling":
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}.keyword": ["Cross Customer Pooling", "cross customer pooling", "Cross customer pooling", "Cross customer Pooling"]}
                                })
                        elif field in ["amop_apis", "carrier_apis", "email_templates"] and isinstance(value, str) and value.lower() in ["enable", "disable"]:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": "true" if value.lower() == "enable" else "disable"}
                            })
                        elif isinstance(values, (list, str)) and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.exception(f"### Invalid date format for item: {item}")
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(value, (list, str)) and field_type != "float":
                            if value is None or (isinstance(value, str) and value == "(Spaces)"):
                                if isinstance(value, str):
                                    stripped_value = ""
                                    if stripped_value == "":
                                        search_body["query"]["bool"]["must"].append({
                                            "terms": {f"{field}.keyword": ["", " ", "  "]}  # Match exact empty string, single space, and double space
                                        })
                            elif field == 'prorate':
                                if isinstance(value, str):
                                    search_body["query"]["bool"]["must"].append({
                                        "term": {f"{field}": value }
                                    })
                            elif value.strip() not in [""," "] and value != "(Spaces)":
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": value }
                                })
                        
                    
                        elif isinstance(value, bool):  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}
                            })
                        elif isinstance(value, (list, str)) and field == "billing_cycle_end_date":
                            try:
                                if isinstance(value, str):
                                    value = [value]
                                formatted_values = convert_date_format(value)
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                            except ValueError:
                                continue            
                        elif isinstance(value, (list, str)):
                            try:
                                if isinstance(value, str):
                                    value = [value]  # Convert single string to a list if it's not already a list
                                for item in value:
                                    if isinstance(item, str):  # Ensure it's a string before adding to the query
                                        # Create a match query for each item in the list
                                        search_body["query"]["bool"]["must"].append({
                                            "match": {
                                                f"{field}": item  # Using match for full-text search
                                            }
                                        })
                            except ValueError:
                                continue
                        elif isinstance(value, (list, str)):  # Single int or float value
                            converted_value = convert_to_scientific_notation(value)
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif isinstance(value, (int, float)):  # Single int or float value
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif isinstance(value, bool):  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}
                            })
                        elif isinstance(value, str) and field == 'status'  and index_list=='sim_management_bulk_change_request':  # Handle integer values
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value}
                             })
                        elif isinstance(value, str):  # Handle integer values
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                             })
                        else:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value}
                            })
                    else:
                        if field in ['nsdev', "auto_change_rate_plan", "att_certified", "is_billing_advance_eligible", "allows_sim_pooling"] and isinstance(values, list):
                            # Ensure all values in the list are lowercase and valid boolean strings
                            lower_values = [v.lower() for v in values if isinstance(v, str) and v.lower() in ['true', 'false']]
                            
                            if lower_values:  # Proceed only if the list has valid boolean strings
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": lower_values}  # Add terms filter with lowercase values
                                })
                        elif any(isinstance(v, str) and v.strip() == "" for v in values):  
                            # Handle empty string or missing field cases
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "bool": {
                                    "should": [
                                        {"term": {f"{field}.keyword": ""}},
                                        {"bool": {"must_not": {"exists": {"field": field}}}},
                                        {"terms": {f"{field}.keyword": [v for v in values if isinstance(v, str) and v.strip() != ""]}}
                                    ]
                                }
                            })
                        
                        elif field_type == "text":
                            search_body["query"]["bool"]["must"].append({
                                "terms": {f"{field}.keyword": values }
                            })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.exception(f"### Invalid date format for item: {item}")
                                        continue
                            # if formatted_values:
                            #     search_body["query"]["bool"]["must"].append({
                            #         "terms": {f"{field}": formatted_values}
                            #     })
                            if formatted_values:
                                if len(formatted_values) > 1024:
                                    # If too many dates, use a range query
                                    min_date = min(formatted_values)
                                    max_date = max(formatted_values)
                                    search_body["query"]["bool"]["filter"] = {
                                        "range": {f"{field}": {"gte": min_date, "lte": max_date}}
                                    }
                                else:
                                    # Use terms query if within limit
                                    search_body["query"]["bool"]["must"].append({
                                        "terms": {f"{field}": formatted_values}
                                    })
                        elif isinstance(values, (list, str)) and field == "billing_cycle_end_date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        formatted_value = convert_date_format(item)
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.exception(f"## An Error Occurred in formatting billing_cycle_end_date")
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.exception(f"## Invalid date format for item: {item}")
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(values, (list, str)):
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):  # Ensure it's a string before adding to the query
                                    try:
                                        # Create a match query for each item in the list
                                        formatted_values.append(item)
                                    except ValueError:
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {
                                        f"{field}": formatted_values  # List of values for multiple exact matches
                                    }
                                })
                        if isinstance(values, list) :
                            if all(isinstance(v, (int, float)) for v in values) :
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {field: values}  
                                })
                        else:
                            # Multiple values in the list
                            search_body["query"]["bool"]["must"].append({
                                "terms": {f"{field}": values}
                            })
                elif isinstance(values, bool):  # Single boolean condition
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
                elif isinstance(values, int):
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
                elif isinstance(values, str):
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}.keyword": values}
                    })
                else:
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
            elif values is False:
                search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
    search_body = add_customer_exists_filters(search_body, index_name, tenant_name, db_config)
    logging.info(f"Advanced Search Query {search_body}")
    logging.info(f"Open Search query {search_body}")
    if index_name == "Active_lines_report":
        search_body["query"]["bool"]["must"].append({
            "terms": {
                "sim_status.keyword": ["Activated", "Active", "A"]
            }
        })
        logging.info(f"Advanced Search query {search_body}")

    try:
        if index_name == "inventory_export" and flag == "Nopagination":
            try:
                database = DB("common_utils", **db_config)
                # Query to check if it's a subtenant
                parent_tenant_query = f'''SELECT parent_tenant_id FROM tenant WHERE tenant_name='{tenant_name}' '''
                parent_tenant_id_df = database.execute_query(parent_tenant_query, True)

                if not parent_tenant_id_df.empty:
                    parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

                    if parent_tenant_id is not None:
                        for clause in search_body['query']['bool']['must']:
                            for key in ['term', 'terms']:
                                if key in clause:
                                    term_key = next(iter(clause[key].keys()))
                                    if term_key == 'carrier_rate_plan_name.keyword':
                                        value = clause[key].pop(term_key)
                                        clause[key]['sub_tenant_carrier_rate_plan_name.keyword'] = value
                                    elif term_key == 'customer_rate_plan_name.keyword':
                                        value = clause[key].pop(term_key)
                                        clause[key]['sub_tenant_customer_rate_plan_name.keyword'] = value  

                        
                        # response = es.search(index=index_list, body=search_body)
                        response = es.search(index=index_list, body=search_body, scroll=scroll_time)
                        total_records = response['hits']['total']['value']
                        scroll_id = response.get('_scroll_id')
                        if not scroll_id:
                            logging.info("## No scroll ID returned.")
                            return None
                        
                        all_hits = response.get("hits", {}).get("hits", [])
                        
                        fetched_records = all_hits
                        while True:
                            if len(fetched_records) >= total_records:
                                fetched_records = fetched_records[:total_records]
                                break

                            scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                            
                            hits = scroll_response.get('hits', {}).get('hits', [])
                            
                            if not hits:
                                logging.info("## No more records found.")
                                break

                            fetched_records.extend(hits)

                            # Update scroll_id for the next batch
                            scroll_id = scroll_response.get('_scroll_id')
                            if not scroll_id:
                                logging.info("### No scroll ID found in subsequent response.")
                                break

                        es.clear_scroll(scroll_id=scroll_id)
                        # Process each hit and swap the columns if applicable (only if it's a subtenant)
                        for hit in fetched_records:
                            source = hit.get("_source", {})
                            # Only swap the columns if the tenant is a subtenant
                            sub_customer = source.get('sub_tenant_customer_rate_plan_name', None)   
                            sub_carrier = source.get('sub_tenant_carrier_rate_plan_name', None)
                            if parent_tenant_id:  # If parent_tenant_id exists, treat it as a subtenant
                                if 'customer_rate_plan_name' in source and 'carrier_rate_plan_name' in source:
                                    source['customer_rate_plan_name'], source['carrier_rate_plan_name'] = (
                                        source['sub_tenant_customer_rate_plan_name'],
                                        source['sub_tenant_carrier_rate_plan_name']
                                    )
                       
                            # Update the hit with the swapped columns
                            hit["_source"] = source  # Update the _source with swapped data
                        
                        
                        # return replace_none_with_empty(fetched_records, index_list),total_records 
                        return fetched_records,total_records                        
                    else:
                        response = es.search(index=index_list, body=search_body, scroll=scroll_time)
                        response = replace_none_with_empty(response, index_list)
                
                        scroll_id = response.get('_scroll_id')
                        if not scroll_id:
                            logging.info("## No scroll ID returned.")
                            return None

                        # Retrieve the hits
                        all_hits = response['hits']['hits']
                        total_records = response['hits']['total']['value']
                        fetched_records = all_hits
                        while True:
                            if len(fetched_records) >= total_records:
                                fetched_records = fetched_records[:total_records]
                                break

                            scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                            hits = scroll_response.get('hits', {}).get('hits', [])

                            if not hits:
                                logging.info("## No more records found.")
                                break

                            fetched_records.extend(hits)

                            # Update scroll_id for the next batc
                            scroll_id = scroll_response.get('_scroll_id')
                            if not scroll_id:
                                logging.info("## No scroll ID found in subsequent response.")
                                break

                        
                        
                        
                        total_records = len(fetched_records)
                        es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
                        
                        cleaned_response = replace_none_with_empty(fetched_records, index_list)
                        
                        # return cleaned_response, len(fetched_records)
                        return fetched_records, len(fetched_records)
            
            except Exception as e:
                logging.exception(f"## An error occurred while searching in Whole search data: {e}")
                return None
        else:
            response = es.search(index=index_list, body=search_body, scroll=scroll_time)
            response = replace_none_with_empty(response,index_list)

            scroll_id = response.get('_scroll_id')
            if not scroll_id:
                logging.info("## No scroll ID returned.")
                return None

            # Retrieve the hits
            all_hits = response['hits']['hits']
            total_records = response['hits']['total']['value']



        
            if flag == "Pagination":  # Check if flag is set for paginated results (scrolling)
                    fetched_records = all_hits
                    while True:
                        scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                        hits = scroll_response.get('hits', {}).get('hits', [])

                        if not hits:
                            logging.info("## No more records found.")
                            break

                        fetched_records.extend(hits)

                        # Update scroll_id for the next batch
                        scroll_id = scroll_response.get('_scroll_id')
                        if not scroll_id:
                            logging.info("## No scroll ID found in subsequent response.")
                            break

                    # Return the records for the pagination range requested (start to end)
                    
                    paginated_results = fetched_records[start:end]
                    es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
                    cleaned_response = replace_none_with_empty(paginated_results,index_list)
                    # return cleaned_response,total_records
                    return paginated_results,total_records
            elif flag == "Nopagination":  # Handle fetching all records without pagination
                fetched_records = all_hits
                while True:
                    if len(fetched_records) >= total_records:
                        fetched_records = fetched_records[:total_records]
                        break

                    scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                    hits = scroll_response.get('hits', {}).get('hits', [])

                    if not hits:
                        logging.info("## No more records found.")
                        break

                    fetched_records.extend(hits)
                
                    # Update scroll_id for the next batch
                    scroll_id = scroll_response.get('_scroll_id')
                    if not scroll_id:
                        logging.info("## No scroll ID found in subsequent response.")
                        break
                if index_name == 'sim_management_bulk_change':
                    grouped_sources = {}
                    for hit in fetched_records:
                        source = hit.get("_source", {})
                        bulk_id = source.get("bulk_change_id",None)
                        if bulk_id and bulk_id not in grouped_sources:
                            grouped_sources[bulk_id] = hit

                # Prepare paginated results
                if index_name == 'sim_management_bulk_change':
                    fetched_records = list(grouped_sources.values())
                total_records = len(fetched_records)
                es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
                cleaned_response = replace_none_with_empty(fetched_records,index_list)
                # return cleaned_response, total_records
                return fetched_records, total_records
            else:
                    # If flag is not set, just return the first batch of results
                    
                    return all_hits,total_records

    except Exception as e:
        logging.exception(f"## An error occurred while searching in Advance search data: {e}")
        return None

# AWS S3 client
s3_client = boto3.client('s3')


def export_inventory(data):
    S3_BUCKET_NAME = 'searchexceluat'
    module_name = data.get("module_name","")
    db = DB("common_utils", **db_config)
    db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name},
    )
    try:
        search = data.get("search")
        cols = data.get("cols")
        start = 0
        end = 10000
        try:
            pages = data.get("pages")
            start = int(pages.get("start", None))
            end = int("10000")
        except Exception as e:
            logging.exception(f"## Pagination parameters missing or invalid: {e}")

        

        tenant_name = data.get("partner", "")
        if not tenant_name:
            raise ValueError("Tenant name is missing.")

        tenant_name = "Altaworx Test"
        tenant_time_zone = get_tenant_timezone(tenant_name)

        data['page_flag']="Nopagination"

        data['path']="/perform_search"


        results = perform_search(data)
        logging.info(f"## Search results: {results}")
        sources = results.get('data', {}).get('table', [])
        total_rows = results.get('pages', {}).get('total', 0)
    
        if sources:
            # Create a DataFrame for the filtered data
            df = pd.DataFrame(sources)
            required_columns = [
                "service_provider_display_name", "msisdn", "iccid", "eid", "imei", "account_number",
                "customer_name", "username", "sim_status", "sms_count", "minutes_used",
                "ip_address", "telegence_feature", "communication_plan", "carrier_rate_plan_name",
                "carrier_rate_plan_mb", "carrier_rate_plan_display_rate",
                "customer_rate_pool_name", "customer_rate_plan_name", "customer_data_allocation_mb",
                "date_activated", "cost_center", "billing_account_number",
                "foundation_account_number", "device_make", "device_model", "service_zip_code",
                "next_bill_cycle_date", "date_added", "modified_by", "modified_date"
            ]

            # Get optimization setting
            db_name = data.get("db_name", "altaworx_test")
            database = DB(db_name, **db_config)
            p = database.execute_query(f"select optino_cross_providercustomer_optimization from optimization_setting", True).iloc[0, 0]
            
            # Add usage columns based on p value
            if p:
                required_columns.extend(["carrier_cycle_usage_mb", "customer_cycle_usage_mb"])
            else:
                required_columns.append("carrier_cycle_usage_mb")

            available_columns = [col for col in required_columns if col in df.columns]
            # Filter the DataFrame to include only the required columns
            df = df[available_columns]

            # Define column renaming mapping
            rename_columns = {
                "service_provider_display_name": "service_provider_name",
                "carrier_rate_plan_name": "rate_plan",
                "carrier_rate_plan_display_rate": "carrier_rate_plan_cost",
                "sim_status": "status",
                "plan_limit_mb": "carrier_data_allocation_mb",
                "telegence_feature": "feature_codes",
                "carrier_rate_plan_mb": "carrier_data_allocation_mb",
                "sms_count": "sms_total"
            }

            # Add usage column renaming based on p value
            if p:
                rename_columns.update({
                    "carrier_cycle_usage_mb": "carrier_cycle_usage",
                    "customer_cycle_usage_mb": "customer_cycle_usage"
                })
            else:
                rename_columns["carrier_cycle_usage_mb"] = "data_usage_mb"

            # Rename columns
            df.rename(columns=rename_columns, inplace=True)

            # Create a list of all columns
            all_columns = list(df.columns)
            
            if "status" in all_columns:
                # Find the position of status_display_name
                status_index = all_columns.index("status")

                # Remove usage columns from their current position and insert after status_display_name
                if p:
                    # Remove usage columns if they exist
                    if "carrier_cycle_usage" in all_columns:
                        all_columns.remove("carrier_cycle_usage")
                    if "customer_cycle_usage" in all_columns:
                        all_columns.remove("customer_cycle_usage")

                    # Insert after status_display_name
                    all_columns.insert(status_index + 1, "carrier_cycle_usage")
                    all_columns.insert(status_index + 2, "customer_cycle_usage")
                else:
                    # Remove data_usage_mb if it exists
                    if "data_usage_mb" in all_columns:
                        all_columns.remove("data_usage_mb")

                    # Insert after status_display_name
                    all_columns.insert(status_index + 1, "data_usage_mb")

            # Reorder the DataFrame columns
            df = df[all_columns]


            # Convert all large integers to strings to avoid scientific notation
            # Ensure all numeric columns are converted to plain strings
            for col in df.columns:
                if df[col].dtype in ['int64', 'float64']:
                    df[col] = df[col].apply(lambda x: str(int(x)) if pd.notnull(x) else '')
            # Filter the DataFrame to include only the required columns
            #df = df[required_columns]
            # df.columns = [col.replace('_', ' ').capitalize() for col in df.columns]
            # df.columns = [" ".join(word.capitalize() for word in col.split("_")) for col in df.columns]
            acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "MSISDN", "IP"}

            # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
            special_replacements = {
                "Att": "AT&T",
                "And": "and"
            }
            # Format column names
            df.columns = [
                " ".join(
                    part.upper() if part.upper() in acronyms else part.capitalize()
                    for part in col.split("_")
                )
                for col in df.columns
            ]

            # Apply special replacements (Att -> AT&T, And -> and)
            df.columns = [
                " ".join([special_replacements.get(word, word) for word in col.split(" ")]) for col in df.columns
            ]




            # df['S.No'] = range(1, len(df) + 1)
            # columns = ['S.No'] + [col for col in df.columns if col != 'S.No']
            # df = df[columns]
            # # Convert to CSV (you can convert to Excel if you prefer)
            # csv_buffer = StringIO()
            # df.to_csv(csv_buffer, index=False)

            # # Upload the CSV file to S3
            # file_name = f"exports/search/Inventory_export.csv"
            # csv_buffer.seek(0)  # Move to the start of the StringIO buffer

            # # Upload to S3 (public or private based on your needs)
            # s3_client.put_object(
            #     Bucket=S3_BUCKET_NAME,
            #     Key=file_name,
            #     Body=csv_buffer.getvalue(),
            #     ContentType='text/csv'
            # )
            # Convert DataFrame to Excel using openpyxl
            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                df.to_excel(writer, index=False, sheet_name="Inventory")
                workbook = writer.book
                sheet = writer.sheets["Inventory"]

                # Write headers with formatting
                for c_idx, column in enumerate(df.columns, start=1):
                    cell = sheet.cell(row=1, column=c_idx, value=column)
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")

                # Write data rows
                for r_idx, row in enumerate(df.itertuples(index=False), start=2):
                    for c_idx, value in enumerate(row, start=1):
                        sheet.cell(row=r_idx, column=c_idx, value=value)

                # Adjust column widths
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

            excel_buffer.seek(0)

            # Define the file name for the Excel file
            file_name = f"exports/search/export/Inventory Export.xlsx"

            # Upload the Excel file to S3
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=file_name,
                Body=excel_buffer.getvalue(),
                ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )

            # Generate URL (public URL or pre-signed URL)
            download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"
            search_result = {
                'flag': True,
                'download_url': download_url  # Return the URL where the file is stored in S3
            }
            db = DB("common_utils", **db_config)
            db.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": module_name},
            )
            return search_result
        else:
            search_result = {
                "flag": True,
                "data": {
                    "table": sources
                },
                "pages": {
                    "start": start,
                    "end": end,
                    "total": total_rows
                }
            }

        return search_result
    except Exception as e:
        logging.exception(f"## Exception is {e}")
        search_result = {
                "flag": False,
                "message": f"No Records found"
            }
        return search_result


def get_tenant_timezone(tenant_name):
    db_name = "common_utils"
    database = DB(db_name, **db_config)
    tenant_timezone_query = f"SELECT time_zone FROM tenant WHERE tenant_name = '{tenant_name}'"
    table_data = database.execute_query(tenant_timezone_query, True)

    tenant_time_zone = "UTC" 
    
    if not table_data.empty and 'time_zone' in table_data.columns:
        tenant_time_zone = table_data['time_zone'].iloc[0]
    if tenant_time_zone is None:
        logging.info(f"## No valid timezone found for tenant '{tenant_name}'. Using UTC as fallback.")
        tenant_time_zone = "UTC"
    
    match = re.search(r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone)
    if match:
        tenant_time_zone = "Asia/Kolkata"

    return tenant_time_zone

# def search_export(data):
#     S3_BUCKET_NAME = "searchexceluat"
#     module_name = data.get("module_name", "")
#     module_name_snake_case = "_".join(module_name.strip().lower().split())
#     try:
#         search = data.get("search")
#         cols = data.get("cols")
#         start = 0
#         end = 10000
#         try:
#             pages = data.get("pages")
#             start = int(pages.get("start", None))
#             end = int(pages.get("end", 10000))
#         except Exception as e:
#             logging.exception(f"Pagination parameters missing or invalid: {e}")

#         tenant_name = data.get("partner", "")
#         if not tenant_name:
#             raise ValueError("Tenant name is missing.")

#         tenant_name = "Altaworx Test"
#         tenant_time_zone = get_tenant_timezone(tenant_name)


#         data['page_flag']="Nopagination"

#         results = perform_search(data)
#         sources = results.get('data', {}).get('table', [])

#         total_rows = results.get('pages', {}).get('total', 0)

#             #return {"flag":True,"results":sources}
#             # Filter the columns if 'cols' are provided

#         if sources:

#             # Create a DataFrame for the filtered data
#             df = pd.DataFrame(sources)
#             # required_columns = [
#             #     "service_provider_display_name", "imei", "rate_plan", "data_usage_mb", "sms_count",
#             #     "cost_center", "account_number", "customer_name", "date_added", "iccid",
#             #     "msisdn", "eid", "username", "data_usage_bytes",
#             #     "customer_rate_pool_name", "customer_rate_plan_name", "status_display_name",
#             #     "date_activated", "ip_address", "billing_account_number", "foundation_account_number",
#             #     "modified_by", "modified_date"
#             # ]
#             # Specify the required columns from the original data
#             # Specify the required columns from the original data (duplicates removed)

#             ##databse connenction
#             database = DB("common_utils", **db_config)
#             # Fetch the query from the database based on the module name
#             module_query_df = database.get_data(
#                 "export_columns", {"module_name": module_name}
#             )

#             ##checking the dataframe is empty or not
#             if module_query_df.empty:
#                 return {
#                     "flag": False,
#                     "message": f"No query found for module name: {module_name}",
#                 }
#           # Extract the required columns from the query result
#             required_columns = module_query_df.iloc[0].get("required_columns")
#             if not required_columns:

#                 return {"flag": False, "message": f"Unknown module name: {module_name}"}

#             # Parse the required columns as a list (assuming they are stored as a comma-separated string)
#             required_columns = [col.strip().strip('"') for col in required_columns.split(",")]

#             # Ensure all required columns exist in the DataFrame
#             df_columns = [col.strip().strip('"') for col in df.columns]  # Normalize column names in DataFrame
#             missing_columns = [col for col in required_columns if col not in df_columns]
#             if missing_columns:
#                 return {
#                     "flag": False,
#                     "message": f"Missing required columns in data: {', '.join(missing_columns)}",
#                 }

#             # Filter the DataFrame to include only the required columns
#             df = df[required_columns]

#             # Rename the columns to match the SQL aliases
#             if module_name == "SimManagement Inventory":
#                 df.rename(
#                     columns={
#                         "service_provider_display_name": "service_provider_name",
#                         "data_usage_bytes": "carrier_cycle_usage",
#                         "status_display_name": "sim_status",
#                         "carrier_rate_plan_display_rate": "carrier_rate_plan_cost",
#                         "plan_limit_mb": "carrier_data_allocation_mb",
#                         "telegence_feature": "feature_codes",
#                     },
#                     inplace=True,
#                 )

#             acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "MSISDN", "IP"}

#             # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
#             special_replacements = {
#                 "Att": "AT&T",
#                 "And": "and"
#             }
#             # Format column names
#             df.columns = [
#                 " ".join(
#                     part.upper() if part.upper() in acronyms else part.capitalize()
#                     for part in col.split("_")
#                 )
#                 for col in df.columns
#             ]

#             # Apply special replacements (Att -> AT&T, And -> and)
#             df.columns = [
#                 " ".join([special_replacements.get(word, word) for word in col.split(" ")]) for col in df.columns
#             ]

#             # Filter the DataFrame to include only the required columns
#             # df = df[required_columns]
#             # df.columns = [col.replace("_", " ").capitalize() for col in df.columns]
#             # df["S.No"] = range(1, len(df) + 1)
#             # columns = ["S.No"] + [col for col in df.columns if col != "S.No"]
#             # df = df[columns]
#             # Create Excel Workbook
#             workbook = Workbook()
#             sheet = workbook.active
#             sheet.title = module_name

#             # Write headers
#             for c_idx, column in enumerate(df.columns, start=1):
#                 cell = sheet.cell(row=1, column=c_idx, value=column)  # Header row (row=1)
#                 cell.alignment = Alignment(horizontal="center", vertical="center")
#                 cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")

#             # Write data rows
#             for r_idx, row in enumerate(df.itertuples(index=False), start=2):  # Start from the second row for data
#                 for c_idx, value in enumerate(row, start=1):
#                     sheet.cell(row=r_idx, column=c_idx, value=value)

#             # Adjust column widths
#             for col_idx, col_cells in enumerate(sheet.columns, 1):
#                 max_length = max(len(str(cell.value or "")) for cell in col_cells)
#                 sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

#             # Save to BytesIO and upload to S3
#             excel_buffer = BytesIO()
#             workbook.save(excel_buffer)
#             file_name = f"exports/search/{module_name_snake_case}.xlsx"
#             excel_buffer.seek(0)

#             # Upload to S3 (public or private based on your needs)
#             s3_client.put_object(
#                 Bucket=S3_BUCKET_NAME,
#                 Key=file_name,
#                 Body=excel_buffer.getvalue(),
#                 ContentType="text/csv",
#             )

#             # Generate URL (public URL or pre-signed URL)
#             download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"
#             search_result = {
#                 "flag": True,
#                 "download_url": download_url,  # Return the URL where the file is stored in S3
#             }
#             return search_result
#         else:
#             search_result = {
#                 "flag": True,
#                 "data": {"table": sources},
#                 "pages": {"start": start, "end": end, "total": total_rows},
#             }

#         return search_result
#     except Exception as e:
#         logging.exception(f"## Exception is {e}")
#         search_result = {"flag": False, "message": "No Records found"}
#         return search_result

def fetch_and_pivot_daily_device_usage(df, device_table, device_id_field, billing_cycle_start, cycle_end_date, billing_cycle_dates, database):
    if df.empty:
        return pd.DataFrame()
    
    try:
        unique_iccid = df["MSISDN"].unique()
        if not unique_iccid.any():
            return pd.DataFrame()
        if len(unique_iccid) == 1:
            iccid_str = f"('{unique_iccid[0]}')"  # no trailing comma
        else:
            iccid_str = str(tuple(unique_iccid))  # normal tuple syntax

        iccid_query = f"""
            SELECT id, msisdn FROM {device_table}
            WHERE msisdn IN {iccid_str} AND is_active = 'true'
        """
        iccid_df = database.execute_query(iccid_query, True).drop_duplicates(subset=["msisdn"])
        iccid_list = iccid_df.set_index("id")["msisdn"].replace('', None).to_dict()
        device_ids = list(iccid_list.keys())
        
        # Avoid empty IN clause
        if not device_ids:
            return pd.DataFrame()
        # Build SQL-safe IN clause
        if len(device_ids) == 1:
            id_str = f"({device_ids[0]})"  # no trailing comma
        else:
            id_str = str(tuple(device_ids))
            
        
        device_usage_query = f"""
            SELECT {device_id_field} AS mobility_device_id, usage_date, data_usage
            FROM device_usage
            WHERE {device_id_field} IN {id_str} 
            AND usage_date BETWEEN '{billing_cycle_start}' AND '{cycle_end_date}'
        """
        logging.info(f"## device_usage_query - {device_usage_query}")
        
        device_usage_df = database.execute_query(device_usage_query, True)
        if device_usage_df.empty:
            return pd.DataFrame()
        
        device_usage_df["usage_date"] = pd.to_datetime(device_usage_df["usage_date"]).dt.strftime("%Y-%m-%d")
        grouped_device_usage_df = device_usage_df.groupby(["mobility_device_id", "usage_date"], as_index=False).sum()
        
        merged_usage_df = pd.merge(
            grouped_device_usage_df, iccid_df,
            left_on="mobility_device_id", right_on="id", how="left"
        ).drop(columns=["id", "mobility_device_id"], errors='ignore').rename(columns={"msisdn": "MSISDN"})
        
        logging.info(f"### merged_usage_df_aft - {merged_usage_df.head()}")
        usage_pivot = merged_usage_df.pivot_table(index="MSISDN", columns="usage_date", values="data_usage", aggfunc="sum")
        return usage_pivot
    except Exception as e:
        logging.exception(f"### fetch_and_pivot_daily_device_usage Error : {e}")
        return pd.DataFrame()

import xlsxwriter


def search_export(data):
    S3_BUCKET_NAME = "searchexceluat"
    module_name = data.get("module_name", "")
    module_name = "Daily usage report Export" if module_name == "Daily usage report" else module_name
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    db_name = data.get("db_name")
    index_name = data.get('index_name', "")

    db = DB("common_utils", **db_config)
    db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name},
    )
    
    filter_data = data.get("filter", {})
    try:
        search = data.get("search")
        cols = data.get("cols")
        start = 0
        end = 10000
        try:
            pages = data.get("pages")
            start = int(pages.get("start", None))
            end = int(pages.get("end", 10000))
        except Exception as e:
            logging.exception(f"## Pagination parameters missing or invalid: {e}")

        tenant_name = data.get("partner", "")
        if not tenant_name:
            raise ValueError("Tenant name is missing.")

        tenant_name = "Altaworx Test"
        tenant_time_zone = get_tenant_timezone(tenant_name)


        data['page_flag']="Nopagination"

        results = perform_search(data)
        logging.info("### results :", results)
        sources = results.get('data', {}).get('table', [])
        total_rows = results.get('pages', {}).get('total', 0)

            #return {"flag":True,"results":sources}
            # Filter the columns if 'cols' are provided

        if sources:

            # Create a DataFrame for the filtered data
            df = pd.DataFrame(sources)
            # required_columns = [
            #     "service_provider_display_name", "imei", "rate_plan", "data_usage_mb", "sms_count",
            #     "cost_center", "account_number", "customer_name", "date_added", "iccid",
            #     "msisdn", "eid", "username", "data_usage_bytes",
            #     "customer_rate_pool_name", "customer_rate_plan_name", "status_display_name",
            #     "date_activated", "ip_address", "billing_account_number", "foundation_account_number",
            #     "modified_by", "modified_date"
            # ]
            # Specify the required columns from the original data
            # Specify the required columns from the original data (duplicates removed)

            ##databse connenction
            database = DB("common_utils", **db_config)
            # Fetch the query from the database based on the module name
            module_query_df = database.get_data(
                "export_columns", {"module_name": module_name}
            )

            # checking the dataframe is empty or not
            if module_query_df.empty:
                return {
                    "flag": False,
                    "message": f"No query found for module name: {module_name}",
                }

            # Extract the required columns from the query result
            required_columns = module_query_df.iloc[0].get("required_columns")
            if not required_columns:
                logging.exception(f"## Unknown module name: {module_name}")
                return {"flag": False, "message": f"Unknown module name: {module_name}"}

            # Parse the required columns as a list (assuming they are stored as a comma-separated string)
            required_columns = [col.strip().strip('"') for col in required_columns.split(",")]

            # Special handling for "Usage By Line Report"
            if module_name == "Usage By Line Report" and "customer_cycle_end_date" in df.columns:
                if "billing_cycle_end_date" in required_columns:
                    idx = required_columns.index("billing_cycle_end_date")
                    required_columns.pop(idx)
                    required_columns.insert(idx, "customer_cycle_end_date")

            # 🔹 Special handling for "Daily usage report Export"
            if module_name == "Daily usage report Export" and index_name != 'daily_usage_report':
                rename_map = {
                    "service_provider_display_name": "service_provider",
                    "customer_rate_pool_name": "customer_pool",
                    "rate_plan_name": "customer_rate_plan",
                    "datausagemb": "data_usage_mb",
                    "status_display_name": "sim_status",
                    "billing_cycle_end_date":"usage_date",
                }
                # 1. Rename df columns
                df.rename(columns=rename_map, inplace=True)
                # 2. Rename required_columns too
                required_columns = [rename_map.get(col, col) for col in required_columns]

            # Ensure all required columns exist in the DataFrame
            df_columns = [col.strip().strip('"') for col in df.columns]  # Normalize column names in DataFrame
            missing_columns = [col for col in required_columns if col not in df_columns]

            if missing_columns:
                return {
                    "flag": False,
                    "message": f"Missing required columns in data: {', '.join(missing_columns)}",
                }

            # Filter the DataFrame to include only the required columns
            df = df[required_columns]

            tenant_name = data.get("partner", "")
            if tenant_name in ('Altaworx', 'Altaworx Test') and module_name in ("Active Customer Rate Plan","Customer Rate Plan"):
                tenant_name = "Altaworx"
            tenant_data = db.get_data("tenant", {"tenant_name": tenant_name}, ["id","billing_platform_flag"])
            tenant_id = tenant_data["id"].to_list()[0]
            
            billing_platform_flag = tenant_data["billing_platform_flag"].to_list()[0]
            if module_name in ("Active Customer Rate Plan","Customer Rate Plan") and billing_platform_flag:
                module_name = module_name + " Billing Platform"
            
            logging.info(f"### search export billing_platform_flag: {billing_platform_flag}")
            logging.info(f"### search export tenant_id: {tenant_id}")
            logging.info(f"### search export module_name: {module_name}")

            if module_name == "Usage By Line Report" and  search == 'advanced'and filter_data.get("billing_cycle_end_date"):
                # Assuming 'df' is already filtered with the required columns
                # You should have two dataframes: df_main and df_secondary
                # You can use the df from df[required_columns] as df_main and create df_secondary by filtering the necessary data

                # Extract 'primary_billing_period' as the first unique value in 'billing_cycle_end_date'
                # Ensure 'data_usage_mb' is numeric
                df['data_usage_mb'] = pd.to_numeric(df['data_usage_mb'], errors='coerce')

                # Extract primary billing period safely
                billing_cycle_period = df['billing_cycle_end_date'].dropna().unique().tolist()
                if not billing_cycle_period:
                    logging.info("## No valid billing cycle dates found.")
                else:
                    primary_billing_period = billing_cycle_period[0]
                    # Create df_secondary with necessary columns
                    df_secondary = df[['iccid', 'billing_cycle_end_date', 'data_usage_mb']].copy()

                    # Group by 'iccid' and 'billing_cycle_end_date', summing 'data_usage_mb'
                    df_secondary = df_secondary.groupby(['iccid', 'billing_cycle_end_date'], as_index=False)['data_usage_mb'].sum()

                    # Pivot the secondary data to make 'billing_cycle_end_date' values as columns
                    df_pivot = df_secondary.pivot(index='iccid', columns='billing_cycle_end_date', values='data_usage_mb').reset_index()

                    # Merge the pivoted data with the main data
                    df_final = df.merge(df_pivot, on='iccid', how='outer')

                    # Rename columns using billing cycle values
                    rename_dict = {date: str(date) for date in billing_cycle_period if date in df_final.columns}
                    df_final.rename(columns=rename_dict, inplace=True)

                    # Rename 'data_usage_mb' to the primary billing period
                    if 'data_usage_mb' in df_final.columns:
                        df_final.rename(columns={'data_usage_mb': str(primary_billing_period)}, inplace=True)

                    df = df_final 

            # Rename the columns to match the SQL aliases
            if module_name == "SimManagement Inventory":
                def truncate_to_2_decimal(x):
                    return math.floor(x * 100) / 100
                if 'carrier_cycle_usage_mb' in df.columns:
                    df['carrier_cycle_usage_mb'] = df['carrier_cycle_usage_mb'].apply(truncate_to_2_decimal)
                df.rename(
                    columns={
                        "service_provider_display_name": "service_provider_name",
                        "data_usage_bytes": "carrier_cycle_usage",
                        "status_display_name": "sim_status",
                        "carrier_rate_plan_display_rate": "carrier_rate_plan_cost",
                        "plan_limit_mb": "carrier_data_allocation_mb",
                        "telegence_feature": "feature_codes",
                    },
                    inplace=True,
                )
            if module_name=='Rate Plan Socs':
                df.rename(
                    columns={
                        "service_provider": "provider","rate_plan_short_name":"soc_code",
                        "base_rate": "base_price",
                        "data_per_overage_charge": "$_mb",
                        "overage_rate_cost": "Overage_$_MB",
                        "plan_mb": "mb_included",
                        "modified_by": "last_modified_by",
                        "modified_date": "last_modified_date"

                    },
                    inplace=True,
                )
            if module_name=='Usage By Line Report':
                df.rename(
                    columns={
                        "status_display_name": "sim_status"

                    },
                    inplace=True,
                )
            if module_name=='Billing Services':
                df.rename(
                    columns={
                        "description": "service_type"

                    },
                    inplace=True,
                )
            if module_name=='Unposted Items':
                df.rename(
                    #columns={"customer_id":"Customer ID","description":"Description","amount":"Amount","mrc":"MRC","calculated_cost":"Usage","sms_cost":"SMS","tax_name":"Tax","start_date":"Start Date","end_date":"End Date","created_date":"Created Date","tn":"Tn","line_id":"Line ID","product_id":"Product ID"},
                    columns={"customer_id":"customer_id","description":"Description","amount":"Amount","mrc":"MRC","calculated_cost":"Usage","sms_cost":"SMS","tax_name":"Tax","start_date":"start_date","end_date":"end_date","created_date":"created_date","tn":"Tn","line_id":"line_id","product_id":"product_id"},
                    inplace=True,
                )
            if module_name == 'Transaction Analysis Report':
                df.rename(
                    #columns={"account_number":"Account Number","customer_name":"Customer Name","iccid":"ICCID","description":"Description","gl_code":"G/L Code","product_id":"Product ID","bill_range":"Bill Range","category":"Category","amount":"Amount","mrc":"MRC","calculated_cost":"Usage","sms_cost":"SMS","tax_name":"Tax","modified_date":"Modified Date"},
                    columns={"account_number":"account_number","customer_name":"customer_name","iccid":"ICCID","description":"description","gl_code":"gl_code","product_id":"product_id","bill_range":"bill_range","category":"Category","amount":"Amount","mrc":"MRC","calculated_cost":"usage","sms_cost":"SMS","tax_name":"Tax","modified_date":"modified_date"},
                    inplace=True,
                )
            if module_name == 'Export Cycle Date':
                df.rename(
                    columns={
                        "sales_person": "agent_name","bill_cycle_start_date": "current_cycle_date"
                    },
                    inplace=True,
                )
            if module_name == 'Export Variance Billing':
                df.rename(
                    columns={
                        "account_number": "customer_id", "customer_name": "customer","prev_mrc":"prevmrc","mrc":"currmrc","diff_mrc":"diffmrc","prev_nrc":"prevnrc","nrc":"currnrc","diff_nrc":"diffnrc"
                    },
                    inplace=True,
                )

            if module_name=='Altaworx Billing Report':
                df.rename(
                    #columns={"account_number":"Account Number","account_type":"Account Type","customer_name":"Customer Name","bill_id":"Bill ID","sales_person":"Sales Person","secondary_sales_person":"Secondary Sales Person","bill_cycle_start_date":"Statement Date","amount_due":"Balance Forward","mrc":"MRC","nrc":"NRC","network_access_fee":"Network Access Fee","cost_recovery_fee":"Admin Recovery Tax","taxes":"Other Taxes","total":"Total","payments":"Payments","bill_due_date":"Bill Due Date","account_balance":"Account Balance","state":"State","timezone":"Timezone"},
                    columns={"bill_cycle_start_date":"statement_date","amount_due":"balance_forward","mrc":"mrc","nrc":"nrc","network_access_fee":"network_access_fee","cost_recovery_fee":"admin_recovery_tax","taxes":"other_taxes","total":"total","payments":"payments","bill_due_date":"payment_date","sales_person":"agent","secondary_sales_person":"secondary_agent","account_balance":"balance","state":"state","timezone":"timezone"},
                    inplace=True,
                )
            if module_name == 'Total MRC For Bill Profiles':
                df.rename(
                    columns={"account_number":"customer_id","customer_name":"name","sales_person":"agent","contract_start_date":"contract_sign_date","customer_creation_date":"customer_created_date","bill_id":"statement_id","bill_generation_date":"statement_created_date","due_date_of_this_bill":"due_date"},
                    inplace=True,
                )
            if module_name == 'Billing Platform Customers':
                df.rename(
                    columns={"tenant_name":"partner","customer_name":"name","bp_account_number":"account_number","bp_account_type":"account_type","bp_billing_cycle_start_date":"billing_cycle_start_date"},
                    inplace=True,
                )
            if module_name in ('Active Customer Rate Plan', 'Customer Rate Plan', 'Active Customer Rate Plan Billing Platform'):
                df.rename(
                    columns={
                        "is_billing_advance_eligible": "uses_bill_in_advance","service_provider_name":"provider","rate_plan_name":"plan_name",
                        "automation_rule_flag":"automation","display_rate":"total_charge"


                    },
                    inplace=True,
                )
                if 'soc_code' in df.columns:
                    df.drop(columns=['soc_code'], inplace=True)
                logging.info(f"columns -- {df.columns}")
                logging.info(f"data -- {df.head()}")
                if "optimization_type" in df.columns:
                    df["optimization_type"] = df["optimization_type"].replace(
                        {"Cross customer pooling": "Cross Customer Pooling"}
                    )
                if "status" in df.columns:
                    df["status"] = df["status"].map({True: "Active", False: "Inactive", "True": "Active", "False": "Inactive"})
                # Function to clean and convert input to float
                def fix_leading_dot_float(x):
                    try:
                        if isinstance(x, str):
                            x = x.strip().replace('$', '').replace(',', '')  # Remove dollar sign and whitespace
                            if not x:  # Handle empty strings
                                return 0.0  # or return None, or return x depending on your needs
                            if x.startswith('.'):
                                x = f"0{x}"
                        return float(x)
                    except Exception as e:
                        logging.exception(f"### search_export fix_leading_dot_float exception {e}: {x}")
                        return x  # Return original value if not convertible

                # Function to format float as string for display
                def format_float_display(x):
                    try:
                        if pd.isnull(x):
                            return ""
                        x = float(x)
                        return f"{int(x)}" if x.is_integer() else f"{x:.2f}"
                    except Exception as e:
                        logging.exception(f"### search_export format_float_display exception {e}: {x}")
                        return ""

                # Column groups
                float_columns = [
                    "base_rate", "rate_charge", "overage_rate_cost",
                    "total_charge", "sms_rate", "mb_included"
                ]

                int_columns = ["min_plan_mb", "max_plan_mb", "data_per_overage_charge"]

                try:
                    # 1. Clean all relevant columns (convert strings like ".49", "$0.68" to float)
                    for col in float_columns + int_columns:
                        if col in df.columns:
                            df[col] = df[col].apply(fix_leading_dot_float)

                    # 2. Format integer columns as nullable Int64 (drop decimals)
                    for col in int_columns:
                        if col in df.columns:
                            df[col] = (
                                df[col]
                                .apply(lambda x: int(x) if pd.notnull(x) and float(x).is_integer() else pd.NA)
                                .astype("Int64")
                            )

                    # 3. Format float columns as strings for export/display
                    for col in float_columns:
                        if col in df.columns:
                            df[col] = df[col].apply(format_float_display)

                except Exception as e:
                    logging.info(f"### search_export column format change exception: {e}")
                logging.info(f"base_rate --- {df['base_rate']}")
                # print product column from df
                # if 'product_cost' in df.columns:
                #     df['product_cost'] = df['product_cost'].apply(
                #         lambda x: json.dumps(x) if isinstance(x, (list, dict)) else x
                #     )
                # if 'product' in df.columns:
                #     if df['product'].apply(lambda x: isinstance(x, list)).any():
                #         df = df.explode('product')
                #     else:
                #         df['product'] = df['product'].apply(lambda x: x.split(',') if isinstance(x, str) else x)
                #         df = df.explode('product')
                if billing_platform_flag:
                    logging.info(f"### search_export billing settings : {billing_platform_flag}")
                    def safe_json_load(x):
                        if isinstance(x, str) and x.strip():
                            try:
                                return json.loads(x)
                            except json.JSONDecodeError:
                                logging.warning(f"Invalid JSON in product_cost: {x}")
                                return []  # or return x, or None depending on how you want to handle bad data
                        return x if isinstance(x, list) else []
                    if 'product' in df.columns and 'product_cost' in df.columns:
                        # Ensure product_cost is a list of dicts
                        df['product_cost'] = df['product_cost'].apply(safe_json_load)
                        # Ensure product is a list
                        df['product'] = df['product'].apply(
                            lambda x: x if isinstance(x, list) else (x.split(',') if isinstance(x, str) else [])
                        )

                        new_rows = []
                        for _, row in df.iterrows():
                            products = row['product']
                            costs = row['product_cost'] if isinstance(row['product_cost'], list) else []
                            for idx, prod in enumerate(products):
                                # Pair by index: first product with first cost dict, etc.
                                cost_dict = costs[idx] if idx < len(costs) else {}
                                new_row = row.to_dict()
                                new_row['Product'] = prod
                                new_row['Product Id'] = cost_dict.get('product_id', '')
                                new_row['Product Description'] = cost_dict.get('description', '')
                                new_row['Product Rate'] = cost_dict.get('rate', '')
                                # Show 0 if cost is None/null, else show value, else empty
                                cost_val = cost_dict.get('cost', '')
                                if cost_val in [None, '', 0, '0']:
                                    new_row['Product Cost'] = ''
                                else:
                                    new_row['Product Cost'] = cost_val
                                
                                new_rows.append(new_row)
                        df = pd.DataFrame(new_rows)
                        df = df.drop(columns=['product', 'product_cost'], errors='ignore')
                        # Reorder columns after "Service Type"
                        after_service_type = [
                            "Product", "Product Id", "Product Description", "Product Rate", "Product Cost",
                            "package", "automation_rule", "automation", "uses_bill_in_advance", "status",
                            "last_modified_by", "last_modified_datetime"
                        ]
                        # Find columns before "Service Type"
                        cols = list(df.columns)
                        logging.info(f"columnsss --- {cols}")
                        if "service_type" in cols:
                            idx = cols.index("service_type")
                            before_service_type = cols[:idx+1]  # includes "service_type"
                            # Only keep columns that exist in df
                            reordered = before_service_type + [c for c in after_service_type if c in df.columns]
                            df = df[reordered]
                        df.rename(columns={"Product Id":"product_id","Product Description":"product_description",
                                           "Product Rate":"product _rate","Product Cost":"product_cost"
                                           })
                else:
                    logging.info(f"### billing settings : {billing_platform_flag}")
                    if 'product' in df.columns:
                        df.drop(columns=['product'], inplace=True)
                    if 'product_cost' in df.columns:
                        df.drop(columns=['product_cost'], inplace=True)
                    if 'package' in df.columns:
                        df.drop(columns=['package'], inplace=True)

                logging.info(f"### columns -- {df.columns}")
                logging.info(f"### data -- {df.head()}")

            if module_name == 'Customer Rate Pool Usage Report':
                # Rename columns for consistency
                df.rename(
                    columns={
                        "subscriber_number": "phone_number_(MSISDN)",
                        "total_used": "%_used",  # Assuming column for used data
                    },
                    inplace=True,
                )
                
                

                

            acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "MSISDN", "IP","MRC","NRC", "ID"}

            # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
            special_replacements = {
                "Tn": "TN",
                "Att": "AT&T",
                "And": "and",
                "Gl": "G/L",
                "Parent": "IsParent", 
                "Child": "IsChild",
                "Prevmrc": "PrevMRC", 
                "Currmrc": "CurrMRC", 
                "Diffmrc": "NetMRC", 
                "Prevnrc": "PrevNRC", 
                "Currnrc": "CurrNRC", 
                "Diffnrc": "NetNRC"
            }
            # Format column names
            df.columns = [
                " ".join(
                    part.upper() if part.upper() in acronyms else part.capitalize()
                    for part in col.split("_")
                )
                for col in df.columns
            ]

            # Apply special replacements (Att -> AT&T, And -> and)
            df.columns = [
                " ".join([special_replacements.get(word, word) for word in col.split(" ")]) for col in df.columns
            ]

            if module_name == "Daily usage report Export" and index_name == 'daily_usage_report':
                # get unique Billing Cycle End Date from df
                billing_periods = []
                billing_cycle_dates = df["Billing Cycle End Date"].unique().tolist()
                billing_cycle_dates = [date for date in billing_cycle_dates if date is not None]
                billing_periods = []
                for date_str in billing_cycle_dates:
                    date = pd.to_datetime(date_str)  # Convert string to Timestamp
                    cycle_start = (date - pd.DateOffset(months=1) + datetime.timedelta(days=1)).date()
                    cycle_end = date.date()
                    billing_periods.append((cycle_start, cycle_end))
                all_results = []  # To accumulate all results across billing cycles
                tenant_db = DB(db_name, **db_config)
                df_telegence = df[df["Service Provider"].str.contains("Telegence", case=False, na=False)]
                df_non_telegence = df[~df["Service Provider"].str.contains("Telegence", case=False, na=False)]
                for billing_cycle_start, cycle_end_date in billing_periods:
                    # Telegence
                    if not df_telegence.empty:
                        usage_pivot_df_telegence = fetch_and_pivot_daily_device_usage(
                            df_telegence,
                            "mobility_device",
                            "mobility_device_id",
                            billing_cycle_start,
                            cycle_end_date,
                            billing_cycle_dates,
                            tenant_db
                        )
                        if not usage_pivot_df_telegence.empty:
                            telegence_data_frame = pd.merge(df_telegence, usage_pivot_df_telegence, on="MSISDN", how="left")
                        else:
                            telegence_data_frame = df_telegence
                    else:
                        telegence_data_frame = pd.DataFrame()

                    # Non-Telegence
                    if not df_non_telegence.empty:
                        usage_pivot_df_non_telegence = fetch_and_pivot_daily_device_usage(
                            df_non_telegence,
                            "device",
                            "m2m_device_id",
                            billing_cycle_start,
                            cycle_end_date,
                            billing_cycle_dates,
                            tenant_db
                        )
                        if not usage_pivot_df_non_telegence.empty:
                            nont_telegence_data_frame = pd.merge(df_non_telegence, usage_pivot_df_non_telegence, on="MSISDN", how="left")
                        else:
                            nont_telegence_data_frame = df_non_telegence
                    else:
                        nont_telegence_data_frame = pd.DataFrame()

                    # Combine for this cycle
                    cycle_df = pd.concat([telegence_data_frame, nont_telegence_data_frame], ignore_index=True)

                    all_results.append(cycle_df)
                
                # Use outer join to preserve all date columns from each billing cycle
                df = reduce(
                    lambda left, right: pd.merge(
                        left, right.drop(columns=[col for col in right.columns if col in left.columns and col not in ["MSISDN"]]),
                        on="MSISDN",
                        how="outer"
                    ),
                    all_results
                )
                df = df.drop_duplicates()
                # Identify columns that match the YYYY-MM-DD format
                date_columns = [col for col in df.columns if re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(col))]
                # Fill NaN only in those date columns
                df[date_columns] = df[date_columns].fillna('-')

            # Filter the DataFrame to include only the required columns
            # df = df[required_columns]
            # df.columns = [col.replace("_", " ").capitalize() for col in df.columns]
            # df["S.No"] = range(1, len(df) + 1)
            # columns = ["S.No"] + [col for col in df.columns if col != "S.No"]
            # df = df[columns]
            # Create Excel Workbook
            df = df.rename(columns={"Soc Code": "SOC","Product Id":"Product ID"})

            # 🔹 Excel Writing using xlsxwriter
            file_name = f"exports/search/{module_name_snake_case}.xlsx"

            if module_name == "Charge history":
                with TemporaryDirectory() as temp_dir:
                    excel_file_path = os.path.join(temp_dir, f"{module_name_snake_case}.xlsx")
                    with pd.ExcelWriter(excel_file_path, engine="xlsxwriter") as writer:
                        df.to_excel(writer, sheet_name="Sheet 1", index=False)
                        worksheet = writer.sheets["Sheet 1"]
                        for i, col in enumerate(df.columns):
                            col_width = max(df[col].astype(str).map(len).max(), len(col)) + 2
                            worksheet.set_column(i, i, min(col_width, 50))

                    zip_file_path = os.path.join(temp_dir, f"{module_name_snake_case}.zip")
                    with zipfile.ZipFile(zip_file_path, "w") as zipf:
                        zipf.write(excel_file_path, os.path.basename(excel_file_path))

                    with open(zip_file_path, "rb") as zipf:
                        s3_client.put_object(
                            Bucket=S3_BUCKET_NAME,
                            Key=f"exports/search/{module_name_snake_case}.zip",
                            Body=zipf,
                            ContentType="application/zip",
                        )

                    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/exports/search/{module_name_snake_case}.zip"
            else:
                excel_buffer = BytesIO()
                with pd.ExcelWriter(excel_buffer, engine="xlsxwriter") as writer:
                    df.to_excel(writer, sheet_name="Sheet 1", index=False)
                    worksheet = writer.sheets["Sheet 1"]
                    for i, col in enumerate(df.columns):
                        col_width = max(df[col].astype(str).map(len).max(), len(col)) + 2
                        worksheet.set_column(i, i, min(col_width, 50))
                excel_buffer.seek(0)

                s3_client.put_object(
                    Bucket=S3_BUCKET_NAME,
                    Key=file_name,
                    Body=excel_buffer.getvalue(),
                    ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                )
                download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

            search_result = {
                "flag": True,
                "download_url": download_url,
            }

            db = DB("common_utils", **db_config)
            db.update_dict(
                "export_status",
                {"status_flag": "Success", "url": download_url},
                {"module_name": module_name},
            )
            return search_result
        else:
            search_result = {
                "flag": True,
                "data": {"table": sources},
                "pages": {"start": start, "end": end, "total": total_rows},
            }

        return search_result
    except Exception as e:
        logging.exception(f"## Exception is {e}")
        message=f"No Records found"
        search_result = {"flag": False, "message": message}
        return search_result




def get_module_name(search_module,db_name):
    database = DB(db_name, **db_config)
    query = f"""
        SELECT module_name
        FROM open_search_index
        WHERE search_module = '{search_module}'
    """
    # Execute the query

    df = database.execute_query(query, True)

    if not df.empty:
        module_name = df.iloc[0]["module_name"]  # Extract the first value of the "module_name" column
        return module_name
    else:
        logging.info("## No results found.")
        return None


def get_columns_from_db( module_name,db_name):
    database = DB("common_utils", **db_config)
    if db_name == os.getenv('BILLING_PLATFORM'):
        database = DB(os.getenv('BILLING_PLATFORM_COMMON_UTILS_DATABASE'), **db_config)
    
    query = f"""
        SELECT db_column_name
        FROM field_column_mapping
        WHERE module_name = '{module_name}' AND table_col = 'yes'
    """
    # Execute the query

    df = database.execute_query(query, True)
    # Convert the column to a list
    return df['db_column_name'].tolist()

   
def combined_search_data(filters,query,columns,index_list, start, end, page_flag, db_name, col_sort,index_name, tenant_name, is_redirected):
    logging.info(f"## Inside combined_search_data filters: {filters}")
    # if db_name == "altaworx_central":
    #     index_list = index_list
    # else:
    #     index_list = index_list
    if '$' in query:
        query = query.replace('$', '')  # Remove dollar sign
    if ',' in query:
        query = query.replace(',', '')
    if index_name == "Inventory":
        database = DB("common_utils", **db_config)

        # Query to check if it's a subtenant
        parent_tenant_query = f'''SELECT parent_tenant_id FROM tenant WHERE tenant_name='{tenant_name}' '''
        parent_tenant_id_df = database.execute_query(parent_tenant_query, True)

        if not parent_tenant_id_df.empty:
            parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

            if parent_tenant_id is not None:
                # Update columns if needed
                updated_columns = []
                for col in columns:
                    if col == 'carrier_rate_plan_name':
                        updated_columns.append('sub_tenant_carrier_rate_plan_name')
                    elif col == 'customer_rate_plan_name':
                        updated_columns.append('sub_tenant_customer_rate_plan_name')
                    else:
                        updated_columns.append(col)
                columns = list(set(updated_columns))  # remove duplicates if any

    columns = [col for col in columns if col and col != "is_active"]
    columns=list(set(columns))
    search_body = {
        "query": {
            "bool": {
                "must": [],   # Exact matches / required conditions
                "should": [
                    # Wildcard search for partial matches in text fields
                    {
                        "multi_match": {
                            "query": str(query),
                            "fields": columns,
                            "type": "bool_prefix",
                            "operator": "and",
                            "lenient": True
                        }
                    }
                ],
                "minimum_should_match": 1  # At least one condition must match
            }
        },
        "from": start,
        "size": end - start,
        "track_total_hits": True
    }
    
    if is_date(query):
        query = convert_to_opensearch_date_format(query)
    sort_clause = []
    #data_type = determine_query_type(query)
    if index_name == "automation_rule_log":
        if is_field_present(index_list, 'id'):
            sort_clause = [
                {
                    "id": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    elif index_name == "action_history_report":
        # Apply last one year filter
        current_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        last_year_date = (datetime.datetime.utcnow() - timedelta(days=365)).strftime("%Y-%m-%d")

        date_filter = {
            "range": {
                "date_of_change": {
                    "gte": last_year_date,  # From one year ago
                    "lte": current_date     # Up to the present date
                }
            }
        }
        search_body["query"]["bool"]["must"].append(date_filter)
    else:
        if is_field_present(index_list, 'modified_date'):
            sort_clause = [
                {
                    "modified_date": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    if col_sort:
        try:
            # Extract field and order from the key
            field_to_sort, sort_order = next(iter(col_sort.items()))  
            sort_order = sort_order.lower()  # Normalize to lowercase

            # Get the field type (Assuming `get_field_type` is a defined function)
            field_type = get_field_type(index_list, field_to_sort)

            # Modify field_to_sort if it is of type "text"
            if field_type == "text":
                field_to_sort = f'{field_to_sort}.keyword'

            # Check if the field and sort order are valid
            if field_to_sort and sort_order in ["asc", "desc"]:
                sort_clause = [{field_to_sort: {"order": sort_order}}]  # Override default sort with key sorting
            else:
                logging.info("## Invalid sorting key: Ensure the format is {<field_name>: 'asc'/'desc'}.")
        except StopIteration:
            logging.error("## Error: The provided 'key' dictionary is empty or invalid.")
        except Exception as e:
            logging.exception(f"## An error occurred: {e}")
    
    if sort_clause:
        search_body["sort"] = sort_clause
    # Apply Filters if Present
    if filters:
        for field, values in filters.items():
            if values:  # Check if values is not empty
                field_type = get_field_type(index_list, field)
                if isinstance(values, list) and len(values) > 1:
                    if field_type in ["date", "integer", "float"]:  # Adjust based on actual types returned by get_field_type
                        values = [v for v in values if v != '']  # Remove empty string
                        
                        # Update filters with cleaned values
                        filters[field] = values
                if isinstance(values, list):  # Handle lists
                    if len(values) == 1:
                        # Single value, handle boolean or other types
                        value = values[0]
                        if field in ["device_count", "total_charges", "total_charge_amount", "base_rate", "rate_charge_amt", "overage_rate_cost", "created_date", "date_activated"] and index_name in ["carrier_optimization_list_view","customer_optimization_list_view", "Customer_Rate_Plan", "Inventory", "inventory_export"]:
                            for value in values:
                                if isinstance(value, str) and ":" in value:
                                    try:
                                        # start_range, end_range = map(int, value.split(':'))
                                        # # start_range = round(float(start_range))
                                        # # end_range = round(float(end_range))
                                        # search_body["query"]["bool"].setdefault("must", []).append({
                                        #     "range": {
                                        #         f"{field}": {
                                        #             "gte": start_range,  # Greater than or equal to start of range
                                        #             "lte": end_range     # Less than or equal to end of range
                                        #         }
                                        #     }
                                        # })
                                        # search_body["sort"] = [
                                        #         {f"{field}": {"order": "asc"}}
                                        #     ]
                                        if field in ["created_date", "date_activated"] and is_redirected and index_name in ["Inventory", "inventory_export"]:
                                            # Parse as date range
                                            start_range, end_range = value.split(':')
                                            # Optional: validate format
                                            datetime.datetime.strptime(start_range, "%Y-%m-%d")
                                            datetime.datetime.strptime(end_range, "%Y-%m-%d")
                                            earliest_date_query = {
                                                "size": 0,
                                                "aggs": {
                                                    "min_date": {"min": {"field": field}}
                                                }
                                            }
                                            response = es.search(index=index_list, body=earliest_date_query)
                                            start_range = response["aggregations"]["min_date"]["value_as_string"] if response["aggregations"]["min_date"]["value_as_string"] else end_range
                                            logging.info(f"## start_range: {start_range}, end_range: {end_range}")
                                            search_body["query"]["bool"].setdefault("must", []).append({
                                                "range": {
                                                    f"{field}": {
                                                        "gte": start_range,
                                                        "lte": end_range
                                                    }
                                                }
                                            })
                                            logging.info(f"## check search_body: {search_body}")
                                        else:
                                            # Parse as integer range
                                            start_range, end_range = map(int, value.split(':'))
                                            search_body["query"]["bool"].setdefault("must", []).append({
                                                "range": {
                                                    f"{field}": {
                                                        "gte": start_range,
                                                        "lte": end_range
                                                    }
                                                }
                                            })
                                            search_body["sort"] = [{f"{field}": {"order": "asc"}}]
                                    except ValueError:
                                        logging.exception(f"### Invalid range format for {field}")
                                else:
                                    try:
                                        start_range = int(value)
                                        end_range = int(value)+1
                                        search_body["query"]["bool"].setdefault("must", []).append({
                                            "range": {
                                                f"{field}": {
                                                    "gte": start_range,  # Greater than or equal to start of range
                                                    "lt": end_range     # Less than or equal to end of range
                                                }
                                            }
                                        })
                                        search_body["sort"] = [
                                                {f"{field}": {"order": "asc"}}
                                            ]
                                    except ValueError:
                                        logging.exception(f"## Invalid range format for {field}")
                        elif isinstance(value, str) and value.strip() == "":
                            # Handle case where the single value is an empty string
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "bool": {
                                    "should": [
                                        {"term": {f"{field}.keyword": ""}},  # Empty string
                                        {"bool": {"must_not": {"exists": {"field": field}}}}  # Missing field
                                    ]
                                }
                            })
                        elif field in ['nsdev', "auto_change_rate_plan", "att_certified","is_billing_advance_eligible","allows_sim_pooling"] and isinstance(value, str) and value.lower() in ['true', 'false']:
                        # Handle boolean as string
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}  # Converts to a boolean
                            })
                        elif field in ['volte_capable', 'assigned'] and isinstance(value, str) and value.lower() in ['yes', 'no']:
                            if field == 'assigned' and index_name == 'Rate_Plan_Socs':
                                boolean_value = "Yes" if value.lower() == 'yes' else "No"
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": boolean_value}  # Use the converted boolean value
                                })
                            else:
                                boolean_value = True if value.lower() == 'yes' else False
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}": boolean_value}  # Use the converted boolean value
                                })
                        elif field_type == "long" and field=="bulk_change_id":  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif field in ["users", "customerrateplan"] and isinstance(value, str) and value.lower() in ["active", "inactive"]:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": "true" if value.lower() == "active" else "false"}
                            })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.exception(f"### Invalid date format for item: {item}")
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(value, (list, str)):
                            if value is None or (isinstance(value, str) and value == "(Spaces)"):
                                if isinstance(value, str):
                                    stripped_value = ""
                                    if stripped_value == "":
                                        search_body["query"]["bool"]["must"].append({
                                            "terms": {f"{field}.keyword": ["", " ", "  "]}  # Match exact empty string, single space, and double space
                                        })
                            elif field == 'prorate':
                                if isinstance(value, str):
                                    search_body["query"]["bool"]["must"].append({
                                        "term": {f"{field}": value }
                                    })
                            elif value.strip() not in [""," "] and value != "(Spaces)" and field_type == 'text':
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": value }
                                })
                            else:
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}": value }
                                })
                        # elif isinstance(value, (list, str)) and field_type == "text" and value.strip() not in [""," "]:
                        #     search_body["query"]["bool"]["must"].append({
                        #         "term": {f"{field}.keyword": value }
                        #     })
                        # for handling empty values
                        
                        
                        elif isinstance(value, bool):  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}
                            })
                        elif isinstance(value, (list, str)) and field == "billing_cycle_end_date":
                            try:
                                if isinstance(value, str):
                                    value = [value]
                                formatted_values = convert_date_format(value)
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                            except ValueError:
                                continue            
                        elif isinstance(value, (list, str)):
                            try:
                                if isinstance(value, str):
                                    value = [value]  # Convert single string to a list if it's not already a list
                                for item in value:
                                    if isinstance(item, str):  # Ensure it's a string before adding to the query
                                        # Create a match query for each item in the list
                                        search_body["query"]["bool"]["must"].append({
                                            "match": {
                                                f"{field}": item  # Using match for full-text search
                                            }
                                        })
                            except ValueError:
                                continue
                        elif isinstance(value, (int, float)):  # Single int or float value
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif isinstance(value, bool):  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}
                            })
                        elif isinstance(value, str) and field == 'status'  and index_list=='sim_management_bulk_change_request':  # Handle integer values
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value}
                             })
                        elif isinstance(value, str):  # Handle integer values
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                             })
                        else:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value}
                            })
                    else:
                        if field in ['nsdev', "auto_change_rate_plan", "att_certified", "is_billing_advance_eligible", "allows_sim_pooling"] and isinstance(values, list):
                            # Ensure all values in the list are lowercase and valid boolean strings
                            lower_values = [v.lower() for v in values if isinstance(v, str) and v.lower() in ['true', 'false']]
                            
                            if lower_values:  # Proceed only if the list has valid boolean strings
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": lower_values}  # Add terms filter with lowercase values
                                })
                        elif any(isinstance(v, str) and v.strip() == "" for v in values):  
                            # Handle empty string or missing field cases
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "bool": {
                                    "should": [
                                        {"term": {f"{field}.keyword": ""}},
                                        {"bool": {"must_not": {"exists": {"field": field}}}},
                                        {"terms": {f"{field}.keyword": [v for v in values if isinstance(v, str) and v.strip() != ""]}}
                                    ]
                                }
                            })
                        elif field_type == "text":
                            search_body["query"]["bool"]["must"].append({
                                "terms": {f"{field}.keyword": values }
                            })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.exception(f"## Invalid date format for item: {item}")
                                        continue
                            # if formatted_values:
                            #     search_body["query"]["bool"]["must"].append({
                            #         "terms": {f"{field}": formatted_values}
                            #     })
                            if formatted_values:
                                if len(formatted_values) > 1024:
                                    # If too many dates, use a range query
                                    min_date = min(formatted_values)
                                    max_date = max(formatted_values)
                                    search_body["query"]["bool"]["filter"] = {
                                        "range": {f"{field}": {"gte": min_date, "lte": max_date}}
                                    }
                                else:
                                    # Use terms query if within limit
                                    search_body["query"]["bool"]["must"].append({
                                        "terms": {f"{field}": formatted_values}
                                    })
                        elif isinstance(values, (list, str)) and field == "billing_cycle_end_date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        formatted_value = convert_date_format(item)
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        
                        elif isinstance(values, (list, str)):
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):  # Ensure it's a string before adding to the query
                                    try:
                                        # Create a match query for each item in the list
                                        formatted_values.append(item)
                                    except ValueError:
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {
                                        f"{field}": formatted_values  # List of values for multiple exact matches
                                    }
                                })
                        if isinstance(values, list) :
                            if all(isinstance(v, (int, float)) for v in values):
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {field: values}  
                                })
                        else:
                            # Multiple values in the list
                            search_body["query"]["bool"]["must"].append({
                                "terms": {f"{field}": values}
                            })
                elif isinstance(values, bool):  # Single boolean condition
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
                elif isinstance(values, int):
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
                elif isinstance(values, str):
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}.keyword": values}
                    })
                else:
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
            elif values is False:
                search_body["query"]["bool"]["must"].append({
                    "term": {f"{field}": values}
                })
    search_body = add_customer_exists_filters(search_body, index_name, tenant_name, db_config)
    logging.info(f"### Query for Open Search {search_body}")
    logging.info(f"Open Search query {search_body}")
    if index_name == "Active_lines_report":
        search_body["query"]["bool"]["must"].append({
            "terms": {
                "sim_status.keyword": ["Activated", "Active", "A"]
            }
        })
        logging.info(f"Combined Search query {search_body}")
    try:
        if index_name == "sim_management_bulk_change" and page_flag == 'Pagination':
            # Scroll API for "bulk change" index
            scroll_time = "1m"
            scroll_size = 10000
            all_hits = []

            response = es.search(index=index_list, body=search_body, scroll=scroll_time, size=scroll_size)
            all_hits.extend(response.get("hits", {}).get("hits", []))
            scroll_id = response.get("_scroll_id")

            # Scroll through the results
            while len(response.get("hits", {}).get("hits", [])) > 0:
                response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                all_hits.extend(response.get("hits", {}).get("hits", []))

            # Clear the scroll context
            es.clear_scroll(scroll_id=scroll_id)

            # Group records by `bulk_change_id`
            grouped_sources = {}
            for hit in all_hits:
                source = hit.get("_source", {})
                bulk_id = source.get("bulk_change_id")
                if bulk_id and bulk_id not in grouped_sources:
                    grouped_sources[bulk_id] = hit

            # Prepare paginated results
            grouped_hits = list(grouped_sources.values())
            total_records = len(grouped_hits)
            paginated_hits = grouped_hits[start:end]

            results = {
                "hits": {
                    "hits": paginated_hits,
                    "total": {"value": total_records}
                }
            }
            # return replace_none_with_empty(results, index_list),total_records
            return results,total_records
        elif index_name == "Inventory" and page_flag == "Pagination":  # Checking for Inventory index
            try:
                if not parent_tenant_id_df.empty:
                    parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

                    if parent_tenant_id is not None:
                        for clause in search_body['query']['bool']['must']:
                            for key in ['term', 'terms']:
                                if key in clause:
                                    term_key = next(iter(clause[key].keys()))
                                    if term_key == 'carrier_rate_plan_name.keyword':
                                        value = clause[key].pop(term_key)
                                        clause[key]['sub_tenant_carrier_rate_plan_name.keyword'] = value
                                    elif term_key == 'customer_rate_plan_name.keyword':
                                        value = clause[key].pop(term_key)
                                        clause[key]['sub_tenant_customer_rate_plan_name.keyword'] = value                           
                        # Perform search for inventory index
                        
                        logging.info(f"## Search Body {search_body}")
                        response = es.search(index=index_list, body=search_body)
                        total_records = response['hits']['total']['value']

                        hits = response.get("hits", {}).get("hits", [])


                        # Process each hit and swap the columns if applicable (only if it's a subtenant)
                        for hit in hits:
                            source = hit.get("_source", {})

                            # Only swap the columns if the tenant is a subtenant
                            if parent_tenant_id:  
                                if 'customer_rate_plan_name' in source and 'carrier_rate_plan_name' in source:
                                    # Swap the contents of the two columns
                                    source['customer_rate_plan_name'], source['carrier_rate_plan_name'] = (
                                        source['sub_tenant_customer_rate_plan_name'],
                                        source['sub_tenant_carrier_rate_plan_name']
                                    )

                            # Update the hit with the swapped columns
                            hit["_source"] = source  # Update the _source with swapped data

                        # Return the modified hits after column swap
                        cleaned_response = {
                            "hits": {
                                "hits": hits,  # Return the modified hits with swapped data
                                "total": {"value": total_records}
                            }
                        }

                        # return replace_none_with_empty(cleaned_response, index_list),total_records
                        return cleaned_response,total_records
                    else:
                        # If parent_tenant_id_df is empty, it means it's a main tenant, not a subtenant
                        logging.info(f"## Main tenant detected, skipping column swap.")
                        
                        # Perform search for main tenant (no column swap)
                        response = es.search(index=index_list, body=search_body)
                        total_records = response['hits']['total']['value']
                        cleaned_response = replace_none_with_empty(response, index_list)
                        # return cleaned_response,total_records
                        return response,total_records

                else:
                    logging.info("## No parent tenant ID found for this tenant.")
                    return None

            except Exception as e:
                logging.exception(f"### An error occurred during advanced searching for Inventory: {e}")
                return None
        elif start<10000 and page_flag == 'Pagination':
            # Regular search for non-bulk-change indices
            response = es.search(index=index_list, body=search_body)
            total_records = response['hits']['total']['value']
            cleaned_response = replace_none_with_empty(response, index_list)
            # return cleaned_response,total_records
            return response,total_records
    except Exception as e:
        logging.info(f"## An error occurred while combine searching: {e}")
        return None
    try:
        scroll_time = "1m"
        scroll_size = 10000
        search_body.pop("from", None)
        search_body["size"] = scroll_size
        if index_name == "inventory_export" and page_flag == "Nopagination":
            try:
                database = DB("common_utils", **db_config)
                # Query to check if it's a subtenant
                parent_tenant_query = f'''SELECT parent_tenant_id FROM tenant WHERE tenant_name='{tenant_name}' '''
                parent_tenant_id_df = database.execute_query(parent_tenant_query, True)

                if not parent_tenant_id_df.empty:
                    parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

                    if parent_tenant_id is not None:
                        for clause in search_body['query']['bool']['must']:
                            for key in ['term', 'terms']:
                                if key in clause:
                                    term_key = next(iter(clause[key].keys()))
                                    if term_key == 'carrier_rate_plan_name.keyword':
                                        value = clause[key].pop(term_key)
                                        clause[key]['sub_tenant_carrier_rate_plan_name.keyword'] = value
                                    elif term_key == 'customer_rate_plan_name.keyword':
                                        value = clause[key].pop(term_key)
                                        clause[key]['sub_tenant_customer_rate_plan_name.keyword'] = value  

                        # Perform search for inventory index
                        response = es.search(index=index_list, body=search_body)
                        total_records = response['hits']['total']['value']

                        all_hits = response.get("hits", {}).get("hits", [])
                        fetched_records = all_hits
                        while True:
                            if len(fetched_records) >= total_records:
                                fetched_records = fetched_records[:total_records]
                                break

                            scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                            hits = scroll_response.get('hits', {}).get('hits', [])

                            if not hits:
                                logging.info("## No more records found.")
                                break

                            fetched_records.extend(hits)

                            # Update scroll_id for the next batch
                            scroll_id = scroll_response.get('_scroll_id')
                            if not scroll_id:
                                logging.info("## No scroll ID found in subsequent response.")
                                break

                    
                        # Process each hit and swap the columns if applicable (only if it's a subtenant)
                        for hit in fetched_records:
                            source = hit.get("_source", {})

                            # Only swap the columns if the tenant is a subtenant
                            if parent_tenant_id:  # If parent_tenant_id exists, treat it as a subtenant
                                sub_customer = source.get('sub_tenant_customer_rate_plan_name')
                                sub_carrier = source.get('sub_tenant_carrier_rate_plan_name')
                                if 'customer_rate_plan_name' in source and 'carrier_rate_plan_name' in source:
                                    source['customer_rate_plan_name'], source['carrier_rate_plan_name'] = (
                                        source['sub_tenant_customer_rate_plan_name'],
                                        source['sub_tenant_carrier_rate_plan_name']
                                    )

                            # Update the hit with the swapped columns
                            hit["_source"] = source  # Update the _source with swapped data

                        # Return the modified hits after column swap
                        cleaned_response = {
                            "hits": {
                                "hits": fetched_records,  # Return the modified hits with swapped data
                                "total": {"value": total_records}
                            }
                        }
                        # return replace_none_with_empty(cleaned_response, index_list),total_records
                        return cleaned_response,total_records                         
                    else:
                        response = es.search(index=index_list, body=search_body, scroll=scroll_time)
                        response = replace_none_with_empty(response, index_list)
                
                        scroll_id = response.get('_scroll_id')
                        if not scroll_id:
                            logging.info("## No scroll ID returned.")
                            return None

                        # Retrieve the hits
                        all_hits = response['hits']['hits']
                        total_records = response['hits']['total']['value']
                        fetched_records = all_hits
                        while True:
                            if len(fetched_records) >= total_records:
                                fetched_records = fetched_records[:total_records]
                                break

                            scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                            hits = scroll_response.get('hits', {}).get('hits', [])

                            if not hits:
                                logging.info("## No more records found.")
                                break

                            fetched_records.extend(hits)

                            # Update scroll_id for the next batch
                            scroll_id = scroll_response.get('_scroll_id')
                            if not scroll_id:
                                logging.info("## No scroll ID found in subsequent response.")
                                break

                        

                        # Inventory Logic for 'Nopagination'
                        
                        total_records = len(fetched_records)
                        es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
                        cleaned_response = replace_none_with_empty(fetched_records, index_list)
                        # return cleaned_response, len(fetched_records)
                        return fetched_records, len(fetched_records)
            
            except Exception as e:
                logging.exception(f"## An error occurred while searching in Whole search data: {e}")
                return None
        else:
            response = es.search(index=index_list, body=search_body, scroll=scroll_time)
            response = replace_none_with_empty(response,index_list)
            
            scroll_id = response.get('_scroll_id')
            if not scroll_id:
                logging.info("## No scroll ID returned.")
                return None

            # Retrieve the hits
            all_hits = response['hits']['hits']
            total_records = response['hits']['total']['value']



        
            if page_flag == "Pagination":  # Check if flag is set for paginated results (scrolling)
                fetched_records = all_hits
                while scroll_id and len(fetched_records) < end:
                    scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                    hits = scroll_response.get('hits', {}).get('hits', [])

                    if not hits:
                        logging.info("## No more records found.")
                        break

                    fetched_records.extend(hits)
            

                    # Update scroll_id for the next batch
                    scroll_id = scroll_response.get('_scroll_id')
                    if not scroll_id:
                        logging.info("## No scroll ID found in subsequent response.")
                        break

                # Return the records for the pagination range requested (start to end)
                
                paginated_results = fetched_records[start:end]
                es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
                cleaned_response = replace_none_with_empty(paginated_results,index_list)
                # return cleaned_response,total_records
                return paginated_results,total_records
            elif page_flag == "Nopagination":  # Handle fetching all records without pagination
                fetched_records = all_hits
                while True:
                    if len(fetched_records) >= total_records:
                        fetched_records = fetched_records[:total_records]
                        break

                    scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                    hits = scroll_response.get('hits', {}).get('hits', [])

                    if not hits:
                        logging.info("## No more records found.")
                        break

                    fetched_records.extend(hits)
                    

                    # Update scroll_id for the next batch
                    scroll_id = scroll_response.get('_scroll_id')
                    if not scroll_id:
                        logging.info("## No scroll ID found in subsequent response.")
                        break
                if index_name == 'sim_management_bulk_change':
                    grouped_sources = {}
                    for hit in fetched_records:
                        source = hit.get("_source", {})
                        bulk_id = source.get("bulk_change_id")
                        if bulk_id and bulk_id not in grouped_sources:
                            grouped_sources[bulk_id] = hit

                # Prepare paginated results
                if index_name == 'sim_management_bulk_change':
                    fetched_records = list(grouped_sources.values())
                total_records = len(fetched_records)
                es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
                cleaned_response = replace_none_with_empty(fetched_records,index_list)
                # return cleaned_response,len(fetched_records)
                return fetched_records,len(fetched_records)
            else:
                # If flag is not set, just return the first batch of results
                return all_hits,total_records

    except Exception as e:
        logging.exception(f"## An error occurred while searching in Combine search data: {e}")
        return None


def process_hits_bk(hits, dollar_fields, tenant_time_zone, index_name):
    sources = []
    datetime_pattern = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?$")
    zero_after_decimal_pattern = re.compile(r"^\d+\.0*$")
    integer_pattern = re.compile(r"^\d+$")
    DATE_ONLY_PATTERN = re.compile(r'^\d{4}-\d{2}-\d{2}$')
    
    for hit in hits:
        source = hit.get('_source', {})
        for k, v in source.items():
            if isinstance(v, (float, Decimal)):  # Check if the value is float or int (you can add more types if needed)
                source[k] = Decimal(str(v))  # Convert to Decimal using string representation
                source[k] = f"{source[k]:f}"
                
        for field in dollar_fields:
            try:
                value = source.get(field, None)
                if value is None:
                    continue 
                if (field in ["carrier_cycle_usage_mb", "plan_mb", "overage_rate_cost", "data_per_overage_charge","account_balance"]) or ((field in ["base_rate", "display_rate", "overage_rate_cost"]) and (index_name == "Rate_Plan_Socs")):
                    # source[field] = round(float(source[field]), 2)
                    source[field] = Decimal(str(value))
                    if source[field] < Decimal("0.001"):
                        source[field] = f"{source[field]:f}"  # Show full value for small numbers
                    else:
                        source[field] = f"{source[field]:,.2f}"
                elif field == 'device_count':
                    source[field] = int(source[field])
                else:
                    # source[field] = float(source[field])
                    # source[field] = f"${source[field]:,.2f}"
                    source[field] = Decimal(str(value))
                    if source[field] < Decimal("0.001"):
                        source[field] = f"${source[field]:f}"  # Show full value for small numbers
                    else:
                        source[field] = f"${source[field]:,.2f}"
            except Exception as e:
                logging.exception(f"### Error processing {field}: {e}")
                continue
        for k, v in source.items():
            if isinstance(v, str) and datetime_pattern.match(v):  # If the value looks like a date
                source[k] = convert_to_tenant_timezone(k, v, tenant_time_zone, index_name)
            elif isinstance(v, str) and DATE_ONLY_PATTERN.match(v):
                source[k] = convert_to_timezone(k, v, tenant_time_zone, index_name)
        # source = {k: str(v) for k, v in source.items()}
        sources.append(source)
    return sources


def process_hits(hits, dollar_fields, tenant_time_zone, index_name,tenant_db_name):
    try:
        sources = []
        datetime_pattern = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?$")
        zero_after_decimal_pattern = re.compile(r"^\d+\.0*$")
        integer_pattern = re.compile(r"^\d+$")
        DATE_ONLY_PATTERN = re.compile(r'^\d{4}-\d{2}-\d{2}$')
        database = None
        if index_name == 'Billing Service':
            try:
                tenant_database = DB(tenant_db_name, **db_config)  # Connect once before the loop
                billing_database = DB(os.getenv('BILLING_PLATFORM'), **db_config)  # Connect once before the loop
            except Exception as e:
                logging.error(f"### Error connecting to database: {e}")
        for hit in hits:
            source = hit.get('_source', {})
            for k, v in source.items():
                if isinstance(v, (float, Decimal)):  # Check if the value is float or int (you can add more types if needed)
                    source[k] = Decimal(str(v))  # Convert to Decimal using string representation
                    source[k] = f"{source[k]:f}"
            for field in dollar_fields:
                try:
                    value = source.get(field, None)
                    if value is None:
                        continue 
                    if (field in ["carrier_cycle_usage_mb", "plan_mb", "overage_rate_cost", "data_per_overage_charge","account_balance"]) or ((field in ["base_rate", "display_rate", "overage_rate_cost"]) and (index_name == "Rate_Plan_Socs")):
                        # source[field] = round(float(source[field]), 2)
                        source[field] = Decimal(str(value))
                        if source[field] < Decimal("0.001") and field != 'account_balance':
                            source[field] = f"{source[field]:f}"  # Show full value for small numbers
                        else:
                            source[field] = f"{source[field]:,.2f}"
                    elif field == 'device_count':
                        source[field] = int(source[field])
                    else:
                        # source[field] = float(source[field])
                        # source[field] = f"${source[field]:,.2f}"
                        source[field] = Decimal(str(value))
                        if source[field] < Decimal("0.001"):
                            source[field] = f"${source[field]:f}"  # Show full value for small numbers
                        else:
                            source[field] = f"${source[field]:,.2f}"
                except Exception as e:
                    logging.exception(f"### Error processing {field}: {e}")
                    continue
            if index_name == 'Customer_Rate_Plan':
                for k, v in source.items():
                    if isinstance(v, str):
                        # Check if it starts with '$' and remember for later
                        has_dollar = v.startswith('$')
                        # Clean potential dollar signs and commas before regex check
                        cleaned_v = v.replace('$', '').replace(',', '').strip()
                        if integer_pattern.match(cleaned_v) or zero_after_decimal_pattern.match(cleaned_v):
                            # Safely convert cleaned string to Decimal first, then to int
                            try:
                                dec = Decimal(cleaned_v)
                                simplified = str(int(dec))
                                # If original had '$', prefix it back
                                if has_dollar:
                                    source[k] = f"${simplified}"
                                else:
                                    source[k] = simplified
                            except (ValueError, InvalidOperation):
                                source[k] = v  # Revert to original if conversion fails
                        else:
                            source[k] = v  # Keep original if no match
                    else:
                        source[k] = v
            if index_name == 'Billing Service':
                if 'provider_id' in source:
                    service_provider = get_service_provider(source['provider_id'],tenant_database,billing_database)  # Use source['provider_id'] directly
                    if service_provider is not None:
                        source['display_name'] = service_provider
                if 'built_in_fields' in source and isinstance(source['built_in_fields'],str):
                    source['built_in_fields'] = ast.literal_eval(source['built_in_fields'])
                if 'custom_fields' in source and isinstance(source['custom_fields'],str):
                    source['custom_fields'] = ast.literal_eval(source['custom_fields'])
                
            for k, v in source.items():
                if isinstance(v, str) and datetime_pattern.match(v):  # If the value looks like a date
                    source[k] = convert_to_tenant_timezone(k, v, tenant_time_zone, index_name)
                elif isinstance(v, str) and DATE_ONLY_PATTERN.match(v):
                    source[k] = convert_to_timezone(k, v, tenant_time_zone, index_name)

                    
            if index_name in ['Unposted Items Report','Billed Through Date Report','Customer Profile']:
                if 'created_date' in source and index_name == 'Unposted Items Report':
                    created_date_val = source['created_date']
                    if isinstance(created_date_val, str):
                        if 'T' in created_date_val:
                            source['created_date'] = created_date_val.split('T')[0]
                        elif ' ' in created_date_val:
                            source['created_date'] = created_date_val.split(' ')[0]
                    elif isinstance(created_date_val, datetime):
                        source['created_date'] = created_date_val.strftime('%m-%d-%Y')
                elif index_name == 'Customer Profile' and 'bill_cycle_start_date' in source:
                    created_date_val = source['bill_cycle_start_date']
                    if isinstance(created_date_val, str):
                        if 'T' in created_date_val:
                            source['bill_cycle_start_date'] = created_date_val.split('T')[0]
                        elif ' ' in created_date_val:
                            source['bill_cycle_start_date'] = created_date_val.split(' ')[0]
                    elif isinstance(created_date_val, datetime):
                        source['bill_cycle_start_date'] = created_date_val.strftime('%m-%d-%Y')

                elif index_name == 'Billed Through Date Report':
                    if 'activation_date' in source:
                        created_date_val = source['activation_date']
                        if isinstance(created_date_val, str):
                            if 'T' in created_date_val:
                                source['activation_date'] = created_date_val.split('T')[0]
                            elif ' ' in created_date_val:
                                source['activation_date'] = created_date_val.split(' ')[0]
                        elif isinstance(created_date_val, datetime):
                            source['activation_date'] = created_date_val.strftime('%Y-%m-%d')

                    if 'billed_through_date' in source:
                        billed_date_val = source['billed_through_date']
                        if isinstance(billed_date_val, str):
                            if 'T' in billed_date_val:
                                source['billed_through_date'] = billed_date_val.split('T')[0]
                            elif ' ' in billed_date_val:
                                source['billed_through_date'] = billed_date_val.split(' ')[0]
                        elif isinstance(billed_date_val, datetime):
                            source['billed_through_date'] = billed_date_val.strftime('%Y-%m-%d')
            # source = {k: str(v) for k, v in source.items()}
            sources.append(source)
        return sources
    except Exception as e:
        logging.exception(f"### Error processing hits: {e}")
        return []

def transform_filters(filters):
    # new_filters = filters.copy()

    start_date = filters.pop("start_date", None)
    end_date = filters.pop("end_date", None)

    if start_date and end_date:
        filters["created_date"] = [f"{start_date}:{end_date}"]

    return filters

def perform_search(data):
    start_time = time.time() 
    search_all_columns = data.get("search_all_columns", "true")
    index_name=data.get('index_name')
    cols=data.get("cols")
    search=data.get("search")
    db_name=data.get("db_name")
    bulk_change_id=data.get("bulk_change_id",None)
    flag=data.get("flag",None)
    account_number = data.get("account_number",None)
    page_flag=data.get("page_flag","Pagination")
    session_id=data.get("session_id",None)
    toggle=data.get("toggle",None)
    username=data.get("username",None)
    col_sort = None
    if index_name != 'Customer Services':
        col_sort = data.get('col_sort',None)
    tenant_name = data.get("partner", "")
    tenant_id = data.get("tenant_id", None)
    current_cycle = data.get("current_cycle", None)
    is_redirected = data.get("is_redirected", False)
    sub_tenant_name = data.get("sub_tenant_name", None)
    partner_name = data.get("Selected_Partner", None)
    tenant_db_name = data.get("tenant_database", "altaworx_test")
    dollar_fields = ['overage_rate_cost', 'rate_charge_amt', 'base_rate', 'sms_rate', 'total_charge_amount', 'total_charges', 'carrier_cycle_usage_mb','plan_mb' ,'device_count','display_rate', 'data_per_overage_charge','account_balance']
    try:
        pages=data.get("pages")
        start=int(pages.get("start",None))
        end=int(pages.get("end",None))
    except:
        pass
    results=None
    if db_name == 'spectrotel':
        tenant_id=162
    elif db_name == "altaworx_go_tech":
        tenant_id=181
    elif db_name == "APITestTenant":
        tenant_id=1189
    elif db_name == os.getenv('BILLING_PLATFORM') and tenant_name != 'Altaworx Test':
        tenant_id = int(tenant_id)
    else:
        tenant_id=1
    sources=[]
    database = DB(db_name, **db_config)
    if index_name == "usage_by_line_report":
        # optimization_query = f"SELECT optino_cross_providercustomer_optimization FROM public.optimization_setting_tenant_override  where tenant_id= '{tenant_id}' LIMIT 1"
        # optimization_data = database.execute_query(optimization_query, True)
        # if optimization_data["optino_cross_providercustomer_optimization"].tolist()[0]:
        #     index_name = "usp_report_customer_usage_by_line"
        index_name = fetching_usage_by_line_table(tenant_name, db_name, username)
    pquery=f"select search_tables,search_cols from open_search_index where search_module='{index_name}'"
    table_data=database.execute_query(pquery, True)
    index_list = table_data['search_tables'].iloc[0]
    search_type=table_data['search_cols'].iloc[0]
    index = index_list
    # search_type="whole"

    tenant_name = data.get("partner", "")  # Assuming 'partner' is the correct key for tenant name
    if not tenant_name:
        raise ValueError("Tenant name is missing.")
    tenant_time_zone = get_tenant_timezone(tenant_name)

    if db_name=="altaworx_central":
        index_list=f"{index_list}_{db_name}"
    elif index in ["users","carrier_apis","amop_apis","email_audit","email_templates", "deployment_tenant_based_banners", "deployment_tenant_based_audit_logs"]:
        index_list=f"{index_list}"
    elif index_name in ["Central_bulk_change", "Central_optimization"]:
        index_list=f"{index_list}_central_db".lower()
    else:
        index_list=f"{index_list}_{db_name}".lower()

    whole_results, advanced_results, combine_results = None, None, None
    whole_total_rows, advanced_total_rows, combine_total_rows = 0, 0, 0
    # t1 = time.time()
    if search == "advanced":
        filters = data.get('filters')
        username=data.get('username',None)
        # Iterate through filters and replace "<Empty spaces>" with an empty string
        customer_columns = ['customer_name']
        service_provider_column = ['service_provider', 'service_provider_name', 'service_provider_display_name', 'service_providers']
        customer_rate_plan_names=["customer_rate_plan_name","rate_plan_name","customer_rate_plan"]
        # user_data={'customer': ['US Vision, Inc.- Mcallen (300006738)'], 'service_provider': ['AT&T - Cisco Jasper']}
        query = f"SELECT customers, service_provider, customer_group, role, first_name, last_name FROM users WHERE username ='{username}'"
        # Create the database connection
        database = DB("common_utils", **db_config)
        user_df = database.execute_query(query, True)
        user_data = {}
        user_data["role"] = user_df['role'].to_list()[0]
        user_data["first_name"] = user_df['first_name'].to_list()[0]
        user_data["last_name"] = user_df['last_name'].to_list()[0]
        logging.info(f"## filters: {filters}")
        if index_name == "Inventory" and is_redirected:
            filters = transform_filters(filters)
        logging.info(f"## transformed filters: {filters}")
        # try:
        #     user_data["customer"]=list(json.loads(user_df['customers'].to_list()[0]))  
        # except:
        #     user_data["customer"] = [] 
        # try:
        #     user_data["service_provider"]=list(json.loads(user_df['service_provider'].to_list()[0]))
        # except:
        #     user_data["service_provider"]=[]
        # try:
        #     user_data["customer_group"] = user_df['customer_group'].to_list()[0]
        # except:
        #     user_data["customer_group"] = []
    
        # if user_data["customer_group"]:  # If customer_group exists in users table
        #     query = f"SELECT customer_names FROM customergroups WHERE name ='{user_data['customer_group']}'"
        #     database = DB(db_name, **db_config)
        #     customer_data = database.execute_query(query, True)
        # group = {"customer": []}
        # try:
        #     group["customer"] = list(json.loads(customer_data['customer_names'].to_list()[0]))
        # except:
        #     group["customer"] = []

        # # Merge customers from users and customer_groups table
        # combined_customers = list(set(user_data["customer"] + group["customer"]))
                    
        # for col in customer_columns:
        #     if is_field_present(index_list, col):
        #         previous_customer_filter = filters.get(col, None)
        #         # Add the column to filter conditions
        #         if user_data['customer']:
        #             filters[col]= user_data['customer']
        #         else:
        #             filters[col] = previous_customer_filter
        #         break  # Use the first valid column found
        # Check for service provider columns in the index mapping
        # for col in customer_columns:
        #     if is_field_present(index_list, col):
        #         previous_customer_filter = filters.get(col, None)
        #         # Add the column to filter conditions
        #         if combined_customers:
        #             filters[col]= combined_customers
        #         else:
        #             filters[col] = previous_customer_filter
        #         break 
        # for col in customer_columns:
        #     if is_field_present(index_list, col):
        #         previous_customer_filter = filters.get(col, None)
        
        #         if previous_customer_filter:  # respect user input
        #             filters[col] = previous_customer_filter
        #         elif combined_customers:  # fallback if nothing provided
        #             filters[col] = combined_customers
        #         break 
    
        # for col in service_provider_column:
        #     if is_field_present(index_list, col):
        #         previous_service_provider_filter = filters.get(col, None)
        #         # Add the column to filter conditions
        #         if user_data['service_provider']:
        #             filters[col] = user_data['service_provider']
        #         else:
        #             filters[col] = previous_service_provider_filter
        #         break
        for key, value in filters.items():
            if value is not None and isinstance(value, list): 
                for i in range(len(value)):
                    if index_name in ["rev_assurance_variance", "rev_assurance"] and key == "customer_name" and value[i] == "Unassigned":
                        value[i] = ""
                        break
                    elif value[i] == "(Blanks)":
                        value[i] = ""  # Replace with empty string
                        break
        logging.info(f"## index {index}")
        if is_field_present(index_list, 'is_active') and index not in ["users","products_list_view","vw_combined_rev_service_products", "vw_combined_rev_service_products_altaworx_test","vw_combined_rev_service_products_with_out_variance","vw_combined_rev_service_products_with_out_variance_altaworx_test", "vw_zero_usage_report", "vw_usage_by_line_report", "vw_newly_activated_report",'vw_status_history_report',"customer_services","gl_code","serviceprovider"]:
            filters['is_active'] = True
            logging.info(f"## index check {index}")
            if index_name in ["action_history_report", "usage_by_line_report", "usp_report_customer_usage_by_line"]:
                filters.pop("is_active", None)
            elif toggle == False:
                filters["is_active"] = ["true", "false"]
        if is_field_present(index_list, 'is_active') and is_field_present(index_list, 'is_deleted') and index == 'transaction_analysis_view':
            filters['is_active'] = False
            filters['is_deleted'] = False
        if account_number:
            if index == 'payment_history':
                filters['account_number'] = account_number
            elif index == 'ledger':
                filters['account'] = account_number
            elif index_name == 'RepostedMRC':
                service_id = get_service_id(account_number,current_cycle) 
                if 'id' not in filters:
                    filters['id'] = service_id
            else:
                id = get_customer_id(account_number)
                filters['customer_profile_id'] = int(id)
        logging.info(f"## filters: {filters}")
        # if is_field_present(index_list, 'tenant_id'):
        #     if any(keyword in index for keyword not in ["users"]):
        #         tenant_id=1
        #         if db_name == "spectrotel":
        #             tenant_id=162
        #         else:
        #             tenant_id=1
        #         filters['tenant_id'] = tenant_id
        #     else:
        #         filters.pop('tenant_id', None)
        if is_field_present(index_list, 'tenant_id'):
            if "users" not in index_list:
                # tenant_id = 162 if db_name == "spectrotel" else 1
                if db_name == 'spectrotel':
                    tenant_id=162
                elif db_name == "altaworx_go_tech":
                    tenant_id=181
                elif db_name == "APITestTenant":
                    tenant_id=1189
                elif db_name == os.getenv('BILLING_PLATFORM') and tenant_name != 'Altaworx Test':
                    tenant_id = int(tenant_id)
                else:
                    tenant_id=1
                filters['tenant_id'] = tenant_id

            if index in ['vw_customer_services_usage_altaworx','customer_services']:   #temproray
                filters.pop('tenant_id', None)
            elif index in ['gl_code','serviceprovider']:
                if index == 'serviceprovider':
                    sub_tenant_name = data.get('sub_partner',None)
                if sub_tenant_name:
                    tenant_name = sub_tenant_name
                elif partner_name:
                    tenant_name =  partner_name
                id = get_tenant_id(tenant_name)
                if index == 'gl_code':
                    filters["sub_tenant_id"] = int(id)
                else:
                    filters["tenant_id"] = int(id)
                    if id == 212: #only for altaworx test/UAT
                        filters["tenant_id"] = 1
        
        if 'bulk_change_id' in filters:
            bulk_change_id=filters['bulk_change_id']
            if any(keyword in index for keyword in ["sim_management_bulk_change_request","sim_management_bulk_change_request_altaworx_test", "sim_management_bulk_change_view"]):
                filters['bulk_change_id'] = bulk_change_id
            else:
                removed_value = filters.pop('bulk_change_id', None)
        if index_name == "Inventory":
            for key, value in filters.items():
                # Check if the value is a list or an iterable before using len()
                if isinstance(value, list):
                    if len(value) > 60000:
                        filters[key] = value[:60000]  # Slice the list to the first 60000 items
                    logging.info(f"## Count of values for '{key}' : {len(filters[key])}")
                else:
                    logging.info(f"## Value for '{key}' is not a list, so it cannot be sliced.")
        
        index_mapping = get_index_mappings_with_types(index_list)
        agent_flag = False
        if index not in ["email_audit","email_templates", "users", "customer_groups_view"] and db_name != os.getenv('BILLING_PLATFORM'):
            agent_rel_data=db_config_maker(username, db_config,db_name,tenant_name,user_data['role'], index_name)
            agent_rel_data = {
                k: list(v) if isinstance(v, tuple) else v
                for k, v in agent_rel_data.items()
            }

            logging.info(f"## agent_data {agent_rel_data}")
            filters.update(agent_rel_data)
            agent_flag = True
        if index in ["email_audit", "email_templates", "customer_groups_view"]:
            database = DB("common_utils", **db_config)

            tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
            if tenant_data.empty:
                raise ValueError(f"No tenant found for tenant_name: {tenant_name}")

            tenant_id = tenant_data["id"].to_list()[0]
            parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]

            if parent_tenant_id is not None:
                filters["tenant_id"] = tenant_id  # Add to filter
            else:
                filters["tenant_id"] = None
        logging.info(f"advanced__tej {filters}")
        if index_name in ['Inventory', 'inventory_export']:
            logging.info("adding service_provider_is_active filter")
            filters['service_provider_is_active'] = True
            filters['tenant_is_active'] = True
            logging.info(f"Advance search filters are -- {filters}")
        query_filters = {}
        for key, value in filters.items():
            if key == "customer":
                customer_field = next((col for col in customer_columns if col in index_mapping), None)
                if customer_field:
                    field_name = customer_field
                    query_filters[field_name] = value
                continue

            if key == "service_provider":
                service_provider_field = next((col for col in service_provider_column if col in index_mapping), None)
                if service_provider_field:
                    field_name = service_provider_field
                    query_filters[field_name] = value
                continue

            if key == "customer_rate_plan_name":
                customer_rate_plan_field = next((col for col in customer_rate_plan_names if col in index_mapping), None)
                if customer_rate_plan_field:
                    field_name = customer_rate_plan_field
                    query_filters[field_name] = value
                continue

            if key in index_mapping:
                field_type = index_mapping[key]
                field_name = key
                query_filters[field_name] = value
        
        if user_data['role'] != 'Super Admin' and index_name in ["rev_assurance_variance", "rev_assurance","sim_management_bulk_change","e911customers","rule_rule_defination"]:
            by_fields = ["created_by", "modified_by", "deleted_by"]
            selected_by_field = next((field for field in by_fields if field in index_mapping), None)
            username = user_data["first_name"]+" "+user_data["last_name"]
            if selected_by_field:
                query_filters[selected_by_field] = username
        if agent_flag:
            for key, value in query_filters.items():
                if filters.get(key) is not None:
                    query_filters[key] = filters[key]

        if index_name in ["Central_bulk_change", "Central_optimization",'GL Code Settings']:
            query_filters.pop('tenant_id', None)
        logging.info(f"query_filters ------ {query_filters}")
        flag="pagination"
        if start > 9999 or page_flag == "Nopagination":
            search="advanced_pro"
            advanced_results,advanced_total_rows =advanced_search_data(query_filters, index_list, start, end,page_flag,db_name,index_name,col_sort,tenant_name,is_redirected,scroll_time='1m')
        else:
            advanced_results=advance_search_data(query_filters,index_list,start, end,db_name,index_name,col_sort, tenant_name, is_redirected)
            if advanced_results:
                advanced_total_rows = advanced_results.get('hits', {}).get('total', {}).get('value', 0)
                
    elif search == "whole":
        query=data.get("search_word")
        username = data.get("username", None)
        module_name=get_module_name(index_name,db_name)
        columns=get_columns_from_db(module_name,db_name)
        customer_columns = ['customer_name']
        service_provider_column = ['service_provider', 'service_provider_name', 'service_provider_display_name', 'service_providers']
        customer_rate_plan_names=["customer_rate_plan_name","rate_plan_name","customer_rate_plan"]
        if any(keyword in index_list for keyword in ["sim_management_inventory_action_history","users","vw_status_history_report"]) or index_name in ['RepostedMRC','GL Code Settings','Billing Service Providers']:
            custom_filter={}
        elif index_name == "sim_management_bulk_change":
            custom_filter={"is_active": True}
            # columns.append("iccid")
            columns.extend(["iccid", "subscriber_number"])
        elif is_field_present(index_list, 'is_active') and index_name not in [
            "partner_users", "Billing Product", "rev_assurance","rev_assurance_variance",
            "zero_usage_report","usage_by_line_report", "newly_activated_report", "status_history_report", "Customer Profile", "GL Code Settings", "vw_customer_services_usage_altaworx"
        ]:
            
            if index_name in ["action_history_report", "usage_by_line_report", "usp_report_customer_usage_by_line"]:
                custom_filter = {}
            elif index_name == 'Transaction Analysis Report':
                custom_filter={"is_active": False, "is_deleted": False}
            elif toggle == False:
                custom_filter = {"is_active": ["true", "false"]}
            else:
                custom_filter = {"is_active": True}
        elif any(keyword in index_list for keyword in ["sim_management_inventory", "vw_combined_device_inventory_export", "sim_management_inventory_altaworx_test","customer_profiles"]):
            custom_filter={"is_active": True, "tenant_id": 1 }
        
        elif index_name in ["action_history_report"]:
            custom_filter.pop("is_active", None)
        elif index in ["customerrateplan","services","product_types","packages_list_view","products_list_view"] and toggle == False:
            custom_filter={}
        else:
            custom_filter={"is_active": True}
        logging.info(f"custom_filter {custom_filter}")
        if flag == "bulk_history" or any(keyword in index_list for keyword in ["sim_management_bulk_change_request","sim_management_bulk_change_request"]):
            if isinstance(bulk_change_id, list):
                bulk_change_id = bulk_change_id[0]
            custom_filter={"bulk_change_id": bulk_change_id }
            columns.append("bulk_change_id")
        
        logging.info(f"## custom_filter {custom_filter}")
        if username:
            try:
                query_user = f"SELECT customers, service_provider, customer_group, role, first_name, last_name FROM users WHERE username ='{username}'"
                database = DB("common_utils", **db_config)
                user_df = database.execute_query(query_user, True)
                user_data = {}
                user_data["role"] = user_df['role'].to_list()[0]
                user_data["first_name"] = user_df['first_name'].to_list()[0]
                user_data["last_name"] = user_df['last_name'].to_list()[0]
                try:
                    index_mapping = get_index_mappings_with_types(index_list)
                    agent_flag = False
                    filters = {}

                    if index not in ["email_audit","email_templates", "users", "customer_groups_view"] and db_name != os.getenv('BILLING_PLATFORM'):
                        agent_rel_data = db_config_maker(username, db_config, db_name, tenant_name, user_data['role'], index_name)
                        agent_rel_data = {
                            k: list(v) if isinstance(v, tuple) else v
                            for k, v in agent_rel_data.items()
                        }
                        logging.info(f"agent_data {agent_rel_data}")
                        filters.update(agent_rel_data)
                        agent_flag = True
                    if index in ["email_audit", "email_templates", "customer_groups_view"]:
                        database = DB("common_utils", **db_config)

                        tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
                        if tenant_data.empty:
                            raise ValueError(f"No tenant found for tenant_name: {tenant_name}")

                        tenant_id = tenant_data["id"].to_list()[0]
                        parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]

                        if parent_tenant_id is not None:
                            filters["tenant_id"] = tenant_id  # Add to filter
                        else:
                            filters["tenant_id"] = None
                    logging.info(f"advanced__tej {filters}")
                    query_filters = {}

                    for key, value in filters.items():
                        if key == "customer":
                            customer_field = next((col for col in customer_columns if col in index_mapping), None)
                            if customer_field:
                                query_filters[customer_field] = value
                            continue

                        if key == "service_provider":
                            service_provider_field = next((col for col in service_provider_column if col in index_mapping), None)
                            if service_provider_field:
                                query_filters[service_provider_field] = value
                            continue

                        if key == "customer_rate_plan_name":
                            customer_rate_plan_field = next((col for col in customer_rate_plan_names if col in index_mapping), None)
                            if customer_rate_plan_field:
                                query_filters[customer_rate_plan_field] = value
                            continue

                        if key in index_mapping:
                            field_type = index_mapping[key]
                            query_filters[key] = value

                    if user_data['role'] != 'Super Admin' and index_name in ["rev_assurance_variance", "rev_assurance", "sim_management_bulk_change", "e911customers","rule_rule_defination"]:
                        by_fields = ["created_by", "modified_by", "deleted_by"]
                        selected_by_field = next((field for field in by_fields if field in index_mapping), None)
                        user_name = user_data['first_name']+" "+user_data['last_name']
                        if selected_by_field:
                            query_filters[selected_by_field] = user_name

                    custom_filter.update(query_filters)

                except Exception as e:
                    logging.exception(f"## Error applying user filters: {e}")
            except Exception as e:
                    logging.exception(f"## Error in select query: {e}")
        
       
        # if is_field_present(index_list, 'tenant_id'):
        #     if "users" not in index_list:
        #         # tenant_id = 162 if db_name == "spectrotel" else 1
        #         if db_name == 'spectrotel':
        #             tenant_id=162
        #         elif db_name == "altaworx_go_tech":
        #             tenant_id=181
        #         elif db_name == "APITestTenant":
        #             tenant_id=1189
        #         else:
        #             tenant_id=1
        #         custom_filter.update({"tenant_id": tenant_id})
        #     else:
        #         custom_filter.pop("tenant_id", None)
        if account_number:
            if index == 'payment_history':
                custom_filter['account_number'] = account_number
            elif index == 'ledger':
                custom_filter['account'] = account_number
            elif index_name == 'RepostedMRC':
                service_id = get_service_id(account_number,current_cycle)
                custom_filter['id'] = service_id
            else:
                id = get_customer_id(account_number)
                custom_filter['customer_profile_id'] = int(id)
        if index_name in ['Billing Service Providers', 'GL Code Settings']:
            if index_name == 'Billing Service Providers':
                sub_tenant_name = data.get('sub_partner', None)
            if sub_tenant_name:
                tenant_name = sub_tenant_name
            elif partner_name:
                tenant_name = partner_name
            tenant_id = get_tenant_id(tenant_name)
            if index_name == 'Billing Service Providers':
                custom_filter['tenant_id'] = int(tenant_id)
                if tenant_id == 212:   #only in UAT
                    custom_filter['tenant_id'] = 1
            else:
                custom_filter['sub_tenant_id'] = int(tenant_id)
        if index_name == 'Collections Summary':
            tenant_id = data.get('tenant_id')
            if tenant_id == "212":
                tenant_id = 1
            custom_filter['tenant_id'] = int(tenant_id)
        date_format = is_valid_date(query)
        if date_format:
            # Parse the input date string into a datetime object
                input_date = datetime.datetime.strptime(query, date_format)

            # Convert the datetime object into the desired ISO format (2023-04-27T19:06:00)
                query = input_date.strftime("%Y-%m-%dT%H:%M:%S")
        
        custom_filter = {k: v for k, v in custom_filter.items() if v is not None}
        if index_name in ["Central_bulk_change", "Central_optimization"]:
            custom_filter.pop('tenant_id', None)
        logging.info(f"custom_filter ------ {custom_filter}")
        if index_name in ['Inventory', 'inventory_export']:
            logging.info("adding service_provider_is_active filter")
            custom_filter['service_provider_is_active'] = True
            custom_filter['tenant_is_active'] = True
            logging.info(f"Whole search custom_filter are -- {custom_filter}")
        whole_results,whole_total_rows = search_data(query, search_all_columns, index_list, start, end, columns, db_name, custom_filter, page_flag, index_name,col_sort,tenant_name)
    elif search == "combined":
        filters = data.get('filters')
        username=data.get('username',None)
        # Iterate through filters and replace "<Empty spaces>" with an empty string
        customer_columns = ['customer_name']
        service_provider_column = ['service_provider', 'service_provider_name', 'service_provider_display_name', 'service_providers']
        customer_rate_plan_names=["customer_rate_plan_name","rate_plan_name","customer_rate_plan","customer_rate_plans"]
        # user_data={'customer': ['US Vision, Inc.- Mcallen (300006738)'], 'service_provider': ['AT&T - Cisco Jasper']}
        query = f"SELECT customers, service_provider, customer_group, role, first_name, last_name FROM users WHERE username ='{username}'"
        # Create the database connection
        database = DB("common_utils", **db_config)
        user_df = database.execute_query(query, True)
        user_data = {}
        user_data["role"] = user_df['role'].to_list()[0]
        user_data["first_name"] = user_df['first_name'].to_list()[0]
        user_data["last_name"] = user_df['last_name'].to_list()[0]
        if db_name != os.getenv('BILLING_PLATFORM'):
            try:
                user_data["customer"]=list(json.loads(user_df['customers'].to_list()[0]))  
            except:
                user_data["customer"] = [] 
            try:
                user_data["service_provider"]=list(json.loads(user_df['service_provider'].to_list()[0]))
            except:
                user_data["service_provider"]=[]
            try:
                user_data["customer_group"] = user_df['customer_group'].to_list()[0]
            except:
                user_data["customer_group"] = []
        
            if user_data["customer_group"]:  # If customer_group exists in users table
                query = f"SELECT customer_names FROM customergroups WHERE name ='{user_data['customer_group']}'"
                database = DB(db_name, **db_config)
                customer_data = database.execute_query(query, True)
            group = {"customer": []}
            try:
                group["customer"] = list(json.loads(customer_data['customer_names'].to_list()[0]))
            except:
                group["customer"] = []

            # Merge customers from users and customer_groups table
            combined_customers = list(set(user_data["customer"] + group["customer"]))
            
                
            # for col in customer_columns:
            #     if is_field_present(index_list, col):
            #         previous_customer_filter = filters.get(col, None)
            #         # Add the column to filter conditions
            #         if user_data['customer']:
            #             filters[col]= user_data['customer']
            #         else:
            #             filters[col] = previous_customer_filter
            #         break  # Use the first valid column found
            for col in customer_columns:
                if is_field_present(index_list, col):
                    previous_customer_filter = filters.get(col, None)
            
                    if previous_customer_filter:  # respect user input
                        filters[col] = previous_customer_filter
                    elif combined_customers:  # fallback if nothing provided
                        filters[col] = combined_customers
                    break  
            # Check for service provider columns in the index mapping
            for col in service_provider_column:
                if is_field_present(index_list, col):
                    previous_service_provider_filter = filters.get(col, None)
                    # Add the column to filter conditions
                    if user_data['service_provider']:
                        filters[col] = user_data['service_provider']
                    else:
                        filters[col] = previous_service_provider_filter
                    break
        for key, value in filters.items():
            if value is not None and isinstance(value, list): 
                for i in range(len(value)):
                    if index_name in ["rev_assurance_variance", "rev_assurance"] and key == "customer_name" and value[i] == "Unassigned":
                        value[i] = ""
                        break
                    elif value[i] == "(Blanks)":
                        value[i] = ""  # Replace with empty string
                        break
        if is_field_present(index_list, 'is_active') and index not in ["users","vw_combined_rev_service_products", "vw_combined_rev_service_products_altaworx_test","vw_combined_rev_service_products_with_out_variance","vw_combined_rev_service_products_with_out_variance_altaworx_test", "vw_zero_usage_report", "vw_usage_by_line_report", "vw_newly_activated_report","customer_services","gl_code","serviceprovider"]:
            filters['is_active'] = True
            if index_name in ["action_history_report", "usage_by_line_report", "usp_report_customer_usage_by_line"]:
                filters.pop("is_active", None)
            elif toggle == False:
                filters["is_active"] = ["true", "false"]
        if is_field_present(index_list, 'is_active') and is_field_present(index_list, 'is_deleted') and index == 'transaction_analysis_view':
            filters['is_active'] = False
            filters['is_deleted'] = False
        if is_field_present(index_list, 'tenant_id') and index_name in ['Customer Profile']:
            filters['tenant_id'] = 1
        if account_number:
            if index == 'payment_history':
                filters['account_number'] = account_number
            elif index == 'ledger':
                filters['account'] = account_number
            elif index_name == 'RepostedMRC':
                service_id = get_service_id(account_number, current_cycle)
                if 'id' not in filters:
                    filters['id'] = service_id
            else:
                id = get_customer_id(account_number)
                filters['customer_profile_id'] = int(id)
        if index_name in ['Billing Service Providers','GL Code Settings']:
            if index_name == 'Billing Service Providers':
                sub_tenant_name = data.get('sub_partner', None)
            if sub_tenant_name:
                tenant_name = sub_tenant_name
            elif partner_name:
                tenant_name = partner_name
            tenant_id = get_tenant_id(tenant_name)
            if index_name == 'Billing Service Providers':
                filters['tenant_id'] = int(tenant_id)
                if tenant_id == 212:   #only in UAT
                    filters['tenant_id'] = 1
            else:
                filters['sub_tenant_id'] = int(tenant_id)
        # if is_field_present(index_list, 'tenant_id'):
        #     # if any(keyword in index for keyword in ["sim_management_inventory", "sim_management_inventory_altaworx_test","vw_combined_rev_service_products", "vw_combined_rev_service_products_altaworx_test","vw_combined_rev_service_products_with_out_variance","vw_combined_rev_service_products_with_out_variance_altaworx_test", "vw_combined_device_inventory_export", "vw_zero_usage_report", "vw_usage_by_line_report", "vw_newly_activated_report", "vw_carrier_search_view", "vw_customer_search_view"]):
        #         # tenant_id=1
        #     if db_name == 'spectrotel':
        #         tenant_id=162
        #     elif db_name == "altaworx_go_tech":
        #         tenant_id=181
        #     elif db_name == "APITestTenant":
        #         tenant_id=1189
        #     else:
        #         tenant_id=1
        #     filters['tenant_id'] = tenant_id
        #     # else:
        #     #     filters.pop('tenant_id', None)
        
        if 'bulk_change_id' in filters:
            bulk_change_id=filters['bulk_change_id']
            if any(keyword in index for keyword in ["sim_management_bulk_change_request","sim_management_bulk_change_request_altaworx_test", "sim_management_bulk_change_view"]):
                filters['bulk_change_id'] = bulk_change_id
            else:
                removed_value = filters.pop('bulk_change_id', None)

        if index_name == "Inventory" or page_flag == 'Nopagination':
            for key, value in filters.items():
                # Check if the value is a list or an iterable before using len()
                if isinstance(value, list):
                    if len(value) > 60000:
                        filters[key] = value[:60000]  # Slice the list to the first 60000 items
                    logging.info(f"## Count of values for '{key}' : {len(filters[key])}")
                else:
                    logging.info(f"## Value for '{key}' is not a list, so it cannot be sliced.")
        query=data.get("search_word")
        module_name=get_module_name(index_name,db_name)
        columns=get_columns_from_db(module_name,db_name)
        index_mapping = get_index_mappings_with_types(index_list)
        agent_flag = False
        if index not in  ["email_audit","email_templates", "users", "customer_groups_view"] and db_name != os.getenv('BILLING_PLATFORM'):
            agent_rel_data=db_config_maker(username, db_config, db_name, tenant_name, user_data['role'], index_name)
            agent_rel_data = {
                k: list(v) if isinstance(v, tuple) else v
                for k, v in agent_rel_data.items()
            }
            logging.info(f"## agent_data {agent_rel_data}")
            filters.update(agent_rel_data)
            agent_flag = True
            filters = {k: v for k, v in filters.items() if v is not None}
        if index in ["email_audit", "email_templates", "customer_groups_view"]:
            database = DB("common_utils", **db_config)

            tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
            if tenant_data.empty:
                raise ValueError(f"No tenant found for tenant_name: {tenant_name}")

            tenant_id = tenant_data["id"].to_list()[0]
            parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]

            if parent_tenant_id is not None:
                filters["tenant_id"] = tenant_id  # Add to filter
            else:
                filters["tenant_id"] = None
        filter = {}
        for key, value in filters.items():
            if key == "customer":
                customer_field = next((col for col in customer_columns if col in index_mapping), None)
                if customer_field:
                    field_name = customer_field
                    filter[field_name] = value
                continue

            if key == "service_provider":
                service_provider_field = next((col for col in service_provider_column if col in index_mapping), None)
                if service_provider_field:
                    field_name = service_provider_field
                    filter[field_name] = value
                continue

            if key == "customer_rate_plan_name":
                customer_rate_plan_field = next((col for col in customer_rate_plan_names if col in index_mapping), None)
                if customer_rate_plan_field:
                    field_name = customer_rate_plan_field
                    filter[field_name] = value
                continue

            if key in index_mapping:
                field_type = index_mapping[key]
                field_name = key
                filter[field_name] = value
            
        # if agent_flag:
        #     contains_customer_or_plan = any(
        #         field in filters
        #         for field in (customer_columns + customer_rate_plan_names)
        #     )
        #     if not contains_customer_or_plan:/
        if user_data['role'] != 'Super Admin' and index_name in ["rev_assurance_variance", "rev_assurance", "sim_management_bulk_change", "e911customers","rule_rule_defination"]:
            by_fields = ["created_by", "modified_by", "deleted_by"]
            selected_by_field = next((field for field in by_fields if field in index_mapping), None)
            username = user_data["first_name"]+" "+user_data["last_name"]
            if selected_by_field:
                filter[selected_by_field] = username
        
        date_format = is_valid_date(query)
        if date_format:
            # Parse the input date string into a datetime object
                input_date = datetime.datetime.strptime(query, date_format)

            # Convert the datetime object into the desired ISO format (2023-04-27T19:06:00)
                query = input_date.strftime("%Y-%m-%dT%H:%M:%S")
        if index_name in ["Central_bulk_change", "Central_optimization"]:
            filter.pop('tenant_id', None)
        if index_name in ['Inventory', 'inventory_export']:
            logging.info("adding service_provider_is_active filter")
            filter['service_provider_is_active'] = True
            filter['tenant_is_active'] = True
            logging.info(f"Combined filters search filters are -- {filter}")
        combine_results,combine_total_rows = combined_search_data(filter, query,columns,index_list, start,end, page_flag, db_name, col_sort,index_name, tenant_name,is_redirected)
    whole_sources = []
    combine_sources = []
    advanced_sources = []
    raw_advanced_sources = []
    raw_whole_sources = []
    raw_combine_sources = []
    total = advanced_total_rows + whole_total_rows + combine_total_rows
    if page_flag == "Nopagination":
        if search in ["advanced_pro","advanced"]:
            for item in advanced_results:
                source = item.get('_source', {})
                source_id = item.get('id', item.get('_id'))  # Fallback to `_id` if `id` is not in `_source`
                if source_id:
                    source['id'] = source_id  # Add `id` into the source dictionary
                    raw_advanced_sources.append(source)
                else:
                    logging.info(f"## Skipping source without 'id': {item}")
            advanced_sources = process_hits(
                advanced_results,
                dollar_fields,
                tenant_time_zone,
                index_name,
                tenant_db_name
            ) if raw_advanced_sources else []
            
        
        elif search == "whole":
            if isinstance(whole_results, dict) and 'hits' in whole_results and 'hits' in whole_results['hits']:
                whole_hits = whole_results['hits']['hits']
            elif isinstance(whole_results, list):
                # If it's a list, assign it directly
                whole_hits = whole_results
            else:
                logging.info("## Invalid response format for whole_results:", whole_results)
                whole_hits = []

            for item in whole_hits:  # Iterate over the actual hits
                source = item.get('_source', {})
                source_id = item.get('id', item.get('_id'))  # Fallback to `_id` if `id` is not in `_source`
                if source_id:
                    source['id'] = source_id  # Add `id` into the source dictionary
                    raw_whole_sources.append(source)
                else:
                    logging.info(f"## Skipping source without 'id': {item}")
            whole_sources = process_hits(
                whole_hits,
                dollar_fields,
                tenant_time_zone,
                index_name,
                tenant_db_name
            ) if raw_whole_sources else []
        elif search == "combined":
            if isinstance(combine_results, dict) and 'hits' in combine_results and 'hits' in combine_results['hits']:
                combine_hits = combine_results['hits']['hits']
            elif isinstance(combine_results, list):
                # If it's a list, assign it directly
                combine_hits = combine_results
            else:
                logging.info(f"## Invalid response format for whole_results: {combine_results}")
                combine_hits = []
            for item in combine_hits:
                # Ensure we handle cases where _source or _id may not exist
                source = item.get('_source', {})
                source_id = item.get('id', item.get('_id'))  # Fallback to `_id` if `id` is not in `_source`
                if source_id:
                    source['id'] = source_id  # Add `id` into the source dictionary
                    raw_combine_sources.append(source)
                else:
                    logging.info(f"## Skipping source without 'id': {item}")
            combine_sources = process_hits(
                combine_hits,
                dollar_fields,
                tenant_time_zone,
                index_name,
                tenant_db_name
            ) if raw_combine_sources else []
    else:
        # In case it's not "Nopagination", advanced_results should be in a `hits`-like format
        if search in ["advanced","advanced_pro"]:
            if isinstance(advanced_results, dict):  # Ensure advanced_results is a dictionary
                advanced_sources = process_hits(
                    advanced_results.get('hits', {}).get('hits', []),
                    dollar_fields,
                    tenant_time_zone,
                    index_name,
                    tenant_db_name
                )
            elif isinstance(advanced_results, list):  # Handle case where advanced_results is a list
                advanced_sources = process_hits(
                    advanced_results,
                    dollar_fields,
                    tenant_time_zone,
                    index_name,
                    tenant_db_name
                )
        elif search == "whole":
        # Handle both list and dictionary formats for `whole_results`
            if isinstance(whole_results, dict):
                hits = whole_results.get('hits', {}).get('hits', [])
            elif isinstance(whole_results, list):
                hits = whole_results
            else:
                logging.info("## Invalid response format for whole_results:", whole_results)
                hits = []

            whole_sources = process_hits(
                hits,
                dollar_fields,
                tenant_time_zone,
                index_name,
                tenant_db_name
            ) if hits else []
        elif search == 'combined':
            if isinstance(combine_results, dict):
                hits = combine_results.get('hits', {}).get('hits', [])
            elif isinstance(combine_results, list):
                hits = combine_results
            else:
                logging.info("## Invalid response format for combined_results:", whole_results)
                hits = []

            combine_sources = process_hits(
                hits,
                dollar_fields,
                tenant_time_zone,
                index_name,
                tenant_db_name
            ) if hits else []
    combined_sources = whole_sources + advanced_sources + combine_sources
    unique_sources = {}
    for source in combined_sources:
        if 'id' in source:  
            unique_sources[source['id']] = source
        else:
            logging.info(f"## Skipping source without -- 'id': {source}")
    final_sources = list(unique_sources.values())
   
    if final_sources:    
        search_result = {
            "flag": True,
            "data": {
                "table": final_sources
            },
            "pages": {
                "start": start,  
                "end": end,  
                "total": total 
            }
        }
    else:
        total_rows=0
        search_result = {
            "flag": True,
            "data": {
                "table": final_sources
            },
            "pages": {
                "start": start,
                "end": end,
                "total": total
            }
        }
    end_time = time.time()  # End timer
    elapsed_time = end_time - start_time  
    logging.info(f"## Total Execution Time: {elapsed_time:.2f} seconds")
    print(f"## length of final records {len(final_sources)}")
    return search_result


def fetch_dropdown_old(data):
    try:
        column_name=data.get("drop_down",None)
        table=data.get("table",None)
        flag=data.get("flag",None)
        db_name=data.get("db_name",None)
        database = DB(db_name, **db_config)

        table_query = f"SELECT search_tables, index_search_type FROM open_search_index WHERE search_module='{table}'"
        table_data=database.execute_query(table_query, True)
        index_name = table_data["search_tables"].tolist()[0]
        table_name=table_data[0][0]

        if  flag == "status_history":
            iccid=data.get("iccid",None)
            iccid=iccid[0]
            query = f"SELECT DISTINCT {column_name} FROM {table_name} where iccid='{iccid}' and  {column_name} IS NOT NULL"
        elif flag == "bulk_history":
            bulk_change_id=data.get("bulk_change_id",None)
            bulk_change_id=bulk_change_id
            query = f"SELECT DISTINCT {column_name} FROM {table_name} where bulk_change_id='{bulk_change_id}' and {column_name} IS NOT NULL"

        else:
            query = f"SELECT DISTINCT {column_name} FROM {table_name} WHERE {column_name} IS NOT NULL"

        # Execute the query
        cursor.execute(query)
        # Fetch all unique values and return them as a list
        unique_values = cursor.fetchall()
        col_data = []
        for value in unique_values:
            val = value[0]
            if isinstance(val, Decimal):
                col_data.append(float(val))  # Convert Decimal to float
            elif isinstance(val, bool):
                col_data.append(str(val).lower())  # Convert boolean to "true"/"false"
            elif isinstance(val, datetime):
                if column_name == "billing_cycle_end_date":
                    formatted_date = (val - pd.Timedelta(days=1)).replace(hour=23, minute=59, second=59) \
                        if val.time() == pd.Timestamp("00:00:00").time() else val
                    col_data.append(formatted_date.strftime("%m/%d/%Y %H:%M:%S"))
                else:
                    col_data.append(val.strftime("%m/%d/%Y %H:%M:%S"))
            else:
                col_data.append(val)

        return {"flag": "true" , column_name:col_data}

    except Exception as e:
        logging.exception(f"## An error occurred: {e}")
    finally:
        # Close the cursor and connection
        cursor.close()
        conn.close()

def convert_to_opensearch_date(date_value):
    """
    Converts a date value to OpenSearch's expected date format (YYYY-MM-DDTHH:mm:ss).
    This handles both string and datetime inputs.
    """
    if isinstance(date_value, str):
        try:
            # Try to parse it to a datetime object first
            datetime_obj = datetime.datetime.strptime(date_value, '%m/%d/%Y')
            return datetime_obj.strftime('%Y-%m-%d')
        except ValueError:
            # If it cannot be parsed, return as is or handle it accordingly
            return date_value
    elif isinstance(date_value, datetime):
        # If it's already a datetime object, format it directly
        return date_value.strftime('%Y-%m-%d')
    return date_value


def convert_timestamp_to_date(value):
    try:
        if isinstance(value, (int, float)) and len(str(int(value))) == 13: 
            human_readable_date = datetime.datetime.fromtimestamp(value / 1000, tz=datetime.timezone.utc).strftime('%m/%d/%Y')
            return human_readable_date
        elif isinstance(value, str):
            # If the value is already a date string (ISO format), keep it as is
            return value
        else:
            # If it's not a timestamp, return it as is
            return value
    except Exception as e:
        logging.exception(f"### Error converting timestamp {value}: {e}")
        return value

# def get_tenant_ids(tenant_name):
#     """
#     Fetches the tenant ID(s) based on the tenant_name in the payload from 'tenant_sub_tenant.json'.

#     :param data: A dictionary containing "tenant_name".
#     :return: A list with tenant_ids (as a single value or a tuple) based on the data.
#     """
#     logging.info("Received tenant_name: %s", tenant_name)

#     if not tenant_name:
#         logging.error("Error: 'tenant_name' is missing in the payload")
#         return []  # Return an empty list for failure

#     tenants = tenant_load_json()
#     # logging.info("Loaded tenants data type: %s", type(tenants))
#     # logging.info("Loaded tenants data: %s", tenants)

#     # If the loaded data is a tuple, extract the first element which should be the list.
#     if isinstance(tenants, tuple):
#         tenants = tenants[0]
#         logging.info("Extracted tenants list from tuple")

#     if not isinstance(tenants, list):
#         logging.error("Error: Expected a list but got %s", type(tenants))
#         return []  # Return an empty list for failure

#     for tenant in tenants:
#         if not isinstance(tenant, dict):
#             logging.error("Unexpected data format for tenant: %s", tenant)
#             continue

#         if tenant.get('parent_tenant_name') == tenant_name:
#             sub_tenant_ids = tuple(sub_tenant['id'] for sub_tenant in tenant.get('sub_tenants', [])
#                                    if isinstance(sub_tenant, dict))

#             all_tenant_ids = (tenant.get('tenant_id', tenant.get('parent_tenant_id')),) + sub_tenant_ids

#             # Return all tenant IDs as a list (if one tenant ID, return a list with that value)
#             tenant_ids=list(all_tenant_ids) if len(all_tenant_ids) > 1 else [all_tenant_ids[0]]
#             return tenant_ids

#         for sub_tenant in tenant.get('sub_tenants', []):
#             if not isinstance(sub_tenant, dict):
#                 logging.error("Unexpected data format for sub_tenant: %s", sub_tenant)
#                 continue

#             if sub_tenant.get('tenant_name') == tenant_name:
#                 tenant_id = (sub_tenant.get('id'),)
#                 tenant_ids=list(tenant_id) if len(tenant_id) > 1 else [tenant_id[0]]
#                 return tenant_ids

#     return []  # Return an empty list if no matching tenant is found

def get_tenant_ids(tenant_name):
    """
    Fetches a single tenant ID based on the tenant_name from 'tenant_sub_tenant.json'.
    If tenant_name matches a parent_tenant_name, return its tenant_id.
    If tenant_name matches a sub_tenant name, return its id.
    """
    logging.info("Received tenant_name: %s", tenant_name)

    if not tenant_name:
        logging.error("Error: 'tenant_name' is missing in the payload")
        return []  # Return an empty list for failure

    tenants = tenant_load_json()

    if isinstance(tenants, tuple):
        tenants = tenants[0]
        logging.info("Extracted tenants list from tuple")

    if not isinstance(tenants, list):
        logging.error("Error: Expected a list but got %s", type(tenants))
        return []

    for tenant in tenants:
        if not isinstance(tenant, dict):
            logging.error("Unexpected data format for tenant: %s", tenant)
            continue

        # Check for parent_tenant_name match
        if tenant.get('parent_tenant_name') == tenant_name:
            tenant_id = tenant.get('tenant_id', tenant.get('parent_tenant_id'))
            return [tenant_id]

        # Check for sub_tenant match
        for sub_tenant in tenant.get('sub_tenants', []):
            if not isinstance(sub_tenant, dict):
                logging.error("Unexpected data format for sub_tenant: %s", sub_tenant)
                continue

            if sub_tenant.get('tenant_name') == tenant_name:
                return [sub_tenant.get('id')]

    return []


def tenant_load_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_sub_tenant.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"#### Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### Unexpected error while reading JSON: {e}")

    return {}

def clean_tuple(tpl):
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        logging.exception(f"### Exception while converting")
        return ()

def db_config_maker(user, db_config_making, tenant_database, tenant_name, role_name, index_name):
    agent_data = {}
    common_utils_database = DB('common_utils', **db_config_making)
    tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]

    if role_name in ('Super Admin'):
        if tenant_name in ["Altaworx Test", "Altaworx"] :
            tenant_id = 1
        agent_data["tenant_id"] = tenant_id
        return agent_data
        # if index_name == "customer_groups":
        #     return agent_data
        # else:
        #     agent_data["tenant_id"] = tenant_id
        #     return agent_data

    if tenant_id:
        tenant_id = int(tenant_id)
    if parent_tenant_id and role_name in ('Only User'):
        try:
            logging.info(f"## Running filter query for tenant_id={tenant_id} and role={role_name}")
            query = f"""
                SELECT customers, service_provider, customer_names, rate_plan_name, feature_codes, billing_account_number
                FROM tenant_based_partner_admin_filters
                WHERE tenant_id={tenant_id}
            """
            df = common_utils_database.execute_query(query, True)

            def extract_json(col): return set(json.loads(col)) if col else set()
    
            merged_customers = set()
            merged_service_provider = set()
            merged_rate_plan_name = set()
            merged_feature_codes = set()
            merged_billing_account_number = set()

            for _, row in df.iterrows():
                merged_customers |= extract_json(row.get('customers', '[]'))
                merged_customers |= extract_json(row.get('customer_names', '[]'))
                merged_service_provider |= extract_json(row.get('service_provider', '[]'))
                merged_rate_plan_name |= extract_json(row.get('rate_plan_name', '[]'))
                merged_feature_codes |= extract_json(row.get('feature_codes', '[]'))
                if row.get('billing_account_number'):
                    merged_billing_account_number.add(str(row['billing_account_number']))

            agent_data.update({
                "customer": list(sorted(merged_customers)) or None,
                "service_provider": list(sorted(merged_service_provider)) or None,
                # "customer_rate_plan_name": list(sorted(merged_rate_plan_name)) if index_name != "Inventory" else None,
                "feature_codes": list(sorted(merged_feature_codes)) or None,
                # "billing_account_number": (
                #     list(sorted(merged_billing_account_number)) if merged_billing_account_number else None
                # )
            })
            if customer_group:
                if index_name not in ["Inventory", "inventory_export"]:
                    agent_data["customer_rate_plan_name"] = list(customer_rate_plan_name) if customer_rate_plan_name else None
            logging.info(f"agent_data check ***********{agent_data}")
        except Exception as e:
            logging.exception("### Error in partner admin filter logic", e)

    else:
        logging.info(f"## Fetching from user_module_tenant_mapping for Agent user={user}")
        query = f"SELECT customers, service_provider, customer_group FROM user_module_tenant_mapping WHERE user_name='{user}' AND tenant_id={tenant_id}"
        filters = common_utils_database.execute_query(query, True)

        database = DB(tenant_database, **db_config_making)

        try:
            customer_group = filters["customer_group"].to_list()[0]
        except Exception:
            customer_group = None

        customer_names = None
        customer_rate_plan_name = None
        billing_account_number = None
        feature_codes = None

        if customer_group:
            cg_data = database.get_data(
                "customergroups",
                {"name": customer_group},
                ["customer_names", "rate_plan_name", "billing_account_number", "feature_codes"]
            )

            if not cg_data.empty:
                try:
                    customer_rate_plan_name = tuple(json.loads(cg_data["rate_plan_name"].to_list()[0]))
                except Exception as e:
                    logging.exception("### Error extracting rate_plan_name", e)

                try:
                    customer_names = tuple(json.loads(cg_data["customer_names"].to_list()[0]))
                except Exception as e:
                    logging.exception("### Error extracting customer_names", e)

                try:
                    billing_data = cg_data["billing_account_number"].to_list()[0]
                    billing_account_number = (billing_data,) if billing_data else None
                except Exception as e:
                    logging.exception("### Error extracting billing_account_number", e)

                try:
                    feature_data = cg_data["feature_codes"].to_list()[0]
                    if isinstance(feature_data, str):
                        feature_codes = tuple(json.loads(feature_data))
                    elif isinstance(feature_data, list):
                        feature_codes = tuple(feature_data)
                    else:
                        feature_codes = (feature_data,) if feature_data else None
                except Exception as e:
                    logging.exception("### Error extracting feature_codes", e)

        if customer_names is None:
            try:
                customer = tuple(json.loads(filters["customers"].to_list()[0]))
            except Exception:
                customer = None
        else:
            customer = customer_names

        # customer = clean_tuple(customer)
        try:
            customers_query = f'''
                SELECT customer_name 
                FROM customers 
                WHERE tenant_id = {tenant_id} 
                AND is_active = TRUE 
                AND created_by = '{user}'
            '''
            customers_df = database.execute_query(customers_query, True)

            if not customers_df.empty:
                existing_customers = customers_df['customer_name'].to_list()

                # If customer is a single string wrapped like "('a', 'b')" — handle it
                if isinstance(customer, str):
                    customer = customer.strip("()' ")
                    customer_list = [c.strip(" '") for c in customer.split(",") if c.strip()]
                elif isinstance(customer, (list, tuple)):
                    customer_list = list(customer)
                else:
                    customer_list = []

                # Combine and deduplicate
                final_customer_set = set(customer_list + existing_customers)
                customer = tuple(final_customer_set)
                

        except Exception as e:
            logging.exception(f"### Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
        try:
            service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
            if len(service_provider) == 1:
                query = f"SELECT id FROM serviceprovider WHERE service_provider_name ='{service_provider[0]}'"
            else:
                formatted_values = "', '".join(service_provider)
                query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
            service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
        except Exception:
            service_provider = None
            service_provider_id = None
        try:
            if customer:
                customer_rate_plan_names = ()
                customer_list = "', '".join(customer)
                formatted_customer_list = f"('{customer_list}')"
                customer_rate_plan_name_query = f"""
                    SELECT DISTINCT customer_rate_plan_name 
                    FROM sim_management_inventory
                    WHERE customer_name IN {formatted_customer_list}
                    AND customer_rate_plan_name IS NOT NULL
                    ORDER BY customer_rate_plan_name ASC
                """
                result = database.execute_query(customer_rate_plan_name_query, True)

                if isinstance(result, pd.DataFrame) and not result.empty:
                    try:
                        customer_rate_plan_names = tuple(result["customer_rate_plan_name"].to_list())
                    except Exception as e:
                        logging.exception(f"### Error processing customer_rate_plan_name: {e}")
                        customer_rate_plan_names = None
                else:
                    customer_rate_plan_names = None

                if customer_rate_plan_names:
                    if customer_rate_plan_name:
                        customer_rate_plan_name += customer_rate_plan_names
                    else:
                        customer_rate_plan_name = customer_rate_plan_names
        except Exception as e:
            logging.exception(f"### Error processing customer_rate_plan_name: {e}")
            customer_rate_plan_name = None

        try:
            customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
            '''
            customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
            if not customer_rate_plan_df.empty:
                existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
                if existing_rate_plans:
                    # Clean the customer value
                    if isinstance(customer_rate_plan_name, str):
                        customer_rate_plan_name = customer_rate_plan_name.strip("()'")  # Remove ( and ) and ' from start and end
                        customer_rate_plan_name = (customer_rate_plan_name,)  # Now correctly convert it to tuple

                    # Now convert tuple to list
                    customer_rate_plan_list = list(customer_rate_plan_name)
                    fixed_customer_rate_plan_list = []

                    # Split the string into items and strip any unwanted characters
                    for item in customer_rate_plan_list[0].split("', '"):
                        fixed_customer_rate_plan_list.append(item.strip("',"))  # Remove extra quotes and commas
                    

                    # Extend with existing customers
                    fixed_customer_rate_plan_list.extend(existing_rate_plans)
                    
                    
                    # Optional: Convert back to tuple if needed
                    customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                    
        except Exception as e:
            logging.exception(f"### Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")

        agent_data.update({
            "customer": list(customer) if customer else None,
            # "customer_rate_plan_name": list(customer_rate_plan_name) if customer_rate_plan_name else None,
            # "billing_account_number": list(billing_account_number) if billing_account_number else None,
            "feature_codes": list(feature_codes) if feature_codes else None,
            "service_provider": list(service_provider) if service_provider else None,
            "service_provider_id": list(service_provider_id) if service_provider_id else None
        })
        if customer_group:
            # if index_name not in ["Inventory", "inventory_export"]:
            if index_name in ["Customer_Rate_Plan", "Customer_Rate_Plan_Report"]:
                agent_data["customer_rate_plan_name"] = list(customer_rate_plan_name) if customer_rate_plan_name else None

        agent_data.update(agent_data)
        logging.info(f"### agent_data test $$$$$$$$$$$$$ {agent_data}")

    tenant_ids = get_tenant_ids(tenant_name)
    if tenant_name == "Altaworx Test":
        tenant_id = 1
    

    agent_data["tenant_id"] = tenant_id

    logging.info(f"### agent_data $$$$$$$$$$$$$ {agent_data}")
    return agent_data


def flatten_field(value):
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return value[0]
        return list(value)
    return value

# def db_config_maker(user, db_config_making, tenant_database, tenant_name, role_name, index_name):
#     agent_data={}
#     common_utils_database = DB('common_utils', **db_config_making)
#     if tenant_name=='Altaworx':
#         tenant_name='Altaworx Test'
#     tenant_id = common_utils_database.get_data(
#         "tenant", {"tenant_name": tenant_name}, ["id"]
#     )["id"].to_list()[0]
#     if tenant_id:
#         tenant_id=int(tenant_id)

#     query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"
#     filters = common_utils_database.execute_query(query, True)

#     try:
#         database = DB(tenant_database, **db_config)
#     except:
#         database = DB('altaworx_central', **db_config)
#     try:
#         customer_group = filters["customer_group"].to_list()[0]
#     except:
#         customer_group = None

#     customer_group_data = None
#     billing_account_number = None
#     feature_codes = None
#     customer_rate_plan_name=None
#     customer_names=None
#     tenant_ids=None
#     if customer_group:
#         customer_group_data = database.get_data(
#             "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
#         )

#         if not customer_group_data.empty:
#             try:
#                 customer_rate_plan_name = list(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
#             except Exception as e:
#                 logging.exception("Error extracting rate_plan_name:", e)
#             try:
#                 customer_names = list(json.loads(customer_group_data["customer_names"].to_list()[0]))

#             except Exception as e:
#                 logging.exception("Error extracting rate_plan_name:", e)
#                 customer_names=None
#             # try:
#             #     billing_data = customer_group_data["billing_account_number"].to_list()[0]
#             #     if billing_data:
#             #         billing_account_number = billing_data  # Wrap int in a tuple
#             #     else:
#             #         billing_account_number=None


#             # except Exception as e:
#             #     logging.exception("Error extracting billing_account_number:", e)
#             #     billing_account_number=None

#             try:
#                 feature_data = customer_group_data["feature_codes"].to_list()[0]

#                 if isinstance(feature_data, str):
#                     feature_codes = list(json.loads(feature_data))
#                 elif isinstance(feature_data, list):
#                     feature_codes = list(feature_data)
#                 else:
#                     feature_codes = feature_data  # Convert non-list types to tuple

#             except Exception as e:
#                 logging.exception("Error extracting feature_codes:", e)
#     if customer_names is None:
#         try:
#             customer = list(json.loads(filters["customers"].to_list()[0]))
#         except:
#             customer = None
#     else:
#         customer=customer_names
#     try:
#         service_provider = list(json.loads(filters["service_provider"].to_list()[0]))
#         if len(service_provider) == 1:
#             query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
#         else:
#             formatted_values = "', '".join(service_provider)
#             query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
#         service_provider_id = list(database.execute_query(query, True)["id"].to_list())
#     except:
#         service_provider = None
#         service_provider_id = None
    
#     try:
#         if customer:
#             # customer = tuple(customer)
#             formatted_customers = ', '.join(f"'{c}'" for c in customer)
#             customer_rate_plan_names=()
#             customer_rate_plan_name_query = f"""
#                 SELECT distinct customer_rate_plan_name FROM sim_management_inventory
#                 WHERE customer_name IN {formatted_customers} and customer_rate_plan_name is not null order by customer_rate_plan_name asc
#             """

#             result = database.execute_query(customer_rate_plan_name_query, True)
#             # Convert the result into a tuple format
#             if not result.empty:
#                 try:
#                     customer_rate_plan_names = list(result["customer_rate_plan_name"].to_list())
#                 except Exception as e:
#                     logging.exception("Error processing customer_rate_plan_name1:", e)
#                     customer_rate_plan_names = None
#             else:
#                 customer_rate_plan_names = None
#             customer_rate_plan_name += customer_rate_plan_names
#     except Exception as e:
#         logging.exception("Error processing customer_rate_plan_name:", e)
#         customer_rate_plan_name = None
#     tenant_ids=get_tenant_ids(tenant_name)
    
#     if tenant_name == "Altaworx Test":
#         tenant_ids = [1]
#     elif tenant_ids:
#         tenant_ids = list(tenant_ids)
#     else:
#         tenant_ids = None
#     agent_data["customer"] = customer
#     agent_data["service_provider"] = service_provider
#     agent_data["service_provider_id"] = service_provider_id
#     if index_name != "Inventory":
#         agent_data["customer_rate_plan_name"] = customer_rate_plan_name
#     agent_data["feature_codes"] = feature_codes
#     agent_data["billing_account_number"] = None
#     if any([customer, customer_rate_plan_name, billing_account_number, feature_codes, service_provider_id, service_provider]) or role_name=='Super Admin':
#         agent_data["tenant_id"] = tenant_ids
#     else:
#         agent_data["tenant_id"] = tenant_ids
#     return agent_data


def get_index_mappings(index_name):
    """
    Fetch the mapping for the specified OpenSearch index.
    :param index_name: Name of the OpenSearch index
    :return: List of column names in the index
    """
    try:
        mappings = es.indices.get_mapping(index=index_name)
        properties = mappings[index_name]['mappings']['properties']
        return list(properties.keys())
    except Exception as e:
        logging.exception(f"### Failed to fetch mappings for index {index_name}: {e}")
        return []

def fetching_usage_by_line_table(tenant_name, db_name, username):
    """ Fetching usage_by_line iews based on the different role and manin tenant and sub tenant"""
    table = "usage_by_line_report" 
    database = DB("common_utils", **db_config)

    # Fetch tenant_id and parent_tenant_id
    tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
    if tenant_data.empty:
        logging.info(f"## No tenant found for tenant_name: {tenant_name}")
        return "usage_by_line_report"

    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]


    # Fetch user role
    user_info = database.get_data("users", {"username": username}, ["role"])
    if user_info.empty:
        logging.info(f"## No user found for username: {username}")
        role = None
    else:
        role = user_info["role"].to_list()[0]

    if parent_tenant_id is not None:
        # It's a subtenant — check the override table
        query = f"SELECT optino_cross_providercustomer_optimization FROM public.optimization_setting_tenant_override WHERE tenant_id = '{tenant_id}' LIMIT 1"

    else:
        # It's a main tenant — check the main table
        if tenant_id == 212:
            tenant_id = 1
        query = f"SELECT optino_cross_providercustomer_optimization FROM public.optimization_setting WHERE tenant_id = '{tenant_id}' LIMIT 1"

    try:
        # params = {"tenant_id": tenant_id}
        database = DB(db_name, **db_config)
        optimization_data = database.execute_query(query, True)
        if optimization_data["optino_cross_providercustomer_optimization"].tolist()[0]:
            if role not in ["Super Admin", "Partner Admin"]:
                return "usp_report_customer_usage_by_line"
            return "usp_report_customer_usage_by_line"
        else:
            if role not in ["Super Admin", "Partner Admin"]:
                return "usage_by_line_report_stored_proc_search"
            return "usage_by_line_report"
    except Exception as e:
        logging.exception(f"### An error occurred while fetching optimization data: {e}")



def get_index_mappings_with_types(index_name):
    """
    Fetch the mapping for the specified OpenSearch index and return field types.
    :param index_name: Name of the OpenSearch index
    :return: Dictionary with column names as keys and their types as values
    """
    try:
        mappings = es.indices.get_mapping(index=index_name)
        properties = mappings[index_name]['mappings']['properties']
        field_types = {field: details['type'] for field, details in properties.items() if 'type' in details}
        return field_types
    except Exception as e:
        logging.exception(f"### Failed to fetch mappings for index {index_name}: {e}")
        return {}

def extract_start_date(date_range):
    try:
        # Split the string and take the first date
        start_date = date_range.split(' - ')[0]
        # Convert the string to a datetime object
        return datetime.datetime.strptime(start_date, '%m/%d/%Y')
    except (ValueError, IndexError):
        # Return None for invalid entries
        return None

def round_to_2_decimal_places(value):
    # Convert to Decimal to preserve precision and avoid float rounding issues
    dec = Decimal(str(value)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    return f"{dec:.2f}"  # Always returns string with 2 decimal places

def fetch_distinct_values_with_composite(index_name, column_name, query_filters,table, tenant_name,batch_size=10000):
    """
    Fetch distinct values for a specified column using composite aggregation with pagination.
    :param index_name: Name of the OpenSearch index
    :param column_name: Name of the column to fetch distinct values for
    :param query_filters: List of filters to apply to the query
    :param tenant_time_zone: Tenant time zone for date conversion
    :param batch_size: Number of buckets to fetch per composite aggregation query
    :return: Dictionary with column name as key and processed list of distinct values as value
    """
    distinct_values = []
    after_key = None  # Initialize the after_key variable for pagination

    try:
        while True:
            if table == "Inventory":
                database = DB("common_utils", **db_config)
                # Query to check if it's a subtenant
                parent_tenant_query = f'''SELECT parent_tenant_id FROM tenant WHERE tenant_name='{tenant_name}' '''
                parent_tenant_id_df = database.execute_query(parent_tenant_query, True)

                if not parent_tenant_id_df.empty:
                    parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]
                    if parent_tenant_id is not None:
                        if column_name == "customer_rate_plan_name":
                            column_name_new = "sub_tenant_customer_rate_plan_name"
                        elif column_name == "carrier_rate_plan_name":
                            column_name_new = "sub_tenant_carrier_rate_plan_name"
                        else:
                            column_name_new = column_name
                        
                        for clause in query_filters:
                            for key in ['term', 'terms']:
                                if key in clause:
                                    field_name = next(iter(clause[key].keys()))
                                    if field_name == 'carrier_rate_plan_name.keyword':
                                        value = clause[key].pop(field_name)
                                        clause[key]['sub_tenant_carrier_rate_plan_name.keyword'] = value
                                    elif field_name == 'customer_rate_plan_name.keyword':
                                        value = clause[key].pop(field_name)
                                        clause[key]['sub_tenant_customer_rate_plan_name.keyword'] = value
                    else:
                        column_name_new = column_name
                else:
                    column_name_new = column_name
            else:
                column_name_new = column_name
                
            # Build the composite aggregation query
            agg_query = build_composite_aggregation_query(index_name, column_name_new, query_filters,table,tenant_name, after_key, batch_size)
            
            # Execute the query
            response = es.search(index=index_name, body=agg_query)
            
            # Extract buckets from the response
            buckets = response["aggregations"]["composite_values"]["buckets"]
            distinct_values.extend([bucket["key"][column_name_new] for bucket in buckets])
    
            # Check if there is more data to paginate through
            after_key = response["aggregations"]["composite_values"].get("after_key")
            if not after_key:
                break  # Exit the loop if there are no more results

        # Fetch index mapping to get the field type for the specified column
        index_mapping = get_index_mappings_with_types(index_name)
        field_type = index_mapping.get(column_name, None)

        # Convert values based on their type
        formatted_values = []
        for value in distinct_values:
            if field_type == 'date':
                formatted_values.append(convert_timestamp_to_date(value))
            elif isinstance(value, (float, Decimal)) :
                formatted_values.append(round_to_2_decimal_places(value))
            else:
                formatted_values.append(value)
        
        distinct_values = formatted_values

        return {"flag": "true", column_name: distinct_values}

    except Exception as e:
        logging.exception(f"### An error occurred while fetching distinct values for {column_name}: {e}")
        return {"flag": "true", column_name: []}


def build_composite_aggregation_query(index_name, column_name, query_filters,table,tenant_name, after_key=None, batch_size=10000):
    """
    Build a composite aggregation query with pagination support using after_key.
    """
    # Get the field type from the index mapping
    index_mapping = get_index_mappings_with_types(index_name)
    

    if column_name not in index_mapping:
        raise ValueError(f"Column {column_name} not found in index mappings")

    field_type = index_mapping[column_name]

    # Dynamically build the aggregation field based on type
    if field_type == "text":

        field_name = f"{column_name}.keyword"

    elif field_type in ["integer", "float", "double", "long"]:

        field_name = column_name  # Use field directly for numeric types

    elif field_type == "boolean":

        field_name = column_name  # Use boolean field directly

    elif field_type == "date":

        field_name = column_name  # Use date field directly

    else:

        field_name = column_name  # Use the field directly for other types

    
    updated_query_filters = []
    for filter_item in query_filters:
        if 'terms' in filter_item:
            for field_, value in filter_item['terms'].items():
                # Check for the field type and handle accordingly
                field_type_ = index_mapping.get(field_)
                # if not isinstance(value, list):
                #     filter_item['terms'][field_] = (
                #         value if isinstance(value, bool) else (value.lower() == "true")
                #     )
                if not field_type_:
                    # If field does not exist in index_mapping, check for .keyword for text fields
                    if field_.endswith('.keyword'):
                        field_type_ = 'text'
                    else:
                        field_type_ = index_mapping.get(f"{field_}.keyword", None)

                if field_type_ == "date":
                    # Convert the date values to OpenSearch date format
                    if isinstance(value, list):
                        value = [convert_to_opensearch_date(v) for v in value]
                    else:
                        value = convert_to_opensearch_date(value)
                    filter_item['terms'][field_] = value
                if field_ in ["optimization_type", "optimization_type.keyword"]:
                    if isinstance(value, list):
                        normalized_values = []
                        for v in value:
                            if isinstance(v, str) and v.lower() in ["Cross Customer Pooling", "cross customer pooling", "Cross customer pooling"]:
                                normalized_values.extend(["Cross Customer Pooling", "cross customer pooling", "Cross customer pooling"])
                            else:
                                normalized_values.append(v)
                        filter_item['terms'][field_] = normalized_values
        elif 'term' in filter_item:
            # If it's a "term" filter (single value)
            for field_, value in filter_item['term'].items():
                field_type_ = index_mapping.get(field_)
                if not field_type_:
                    # If field does not exist in index_mapping, check for .keyword for text fields
                    if field_.endswith('.keyword'):
                        field_type_ = 'text'
                    else:
                        field_type_ = index_mapping.get(f"{field_}.keyword", None)

                if field_type_ == "date":
                    # Convert the date value to OpenSearch date format
                    filter_item['term'][field_] = convert_to_opensearch_date(value)
        
        updated_query_filters.append(filter_item)
    if table == "action_history_report":
        current_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        last_year_date = (datetime.datetime.utcnow() - timedelta(days=365)).strftime("%Y-%m-%d")

        query_filters.append({
            "range": {
                "date_of_change": {
                    "gte": last_year_date,  # From April 1, 2024
                    "lte": current_date      # Up to the present date
                }
            }
        })
    if table == "Active_lines_report":
        query_filters.append({
            "terms": {
                "sim_status.keyword": ["Activated", "Active", "A"]
            }
        })
        logging.info(f"## build composite aggregation query_filters--- {query_filters}")
    # Build the composite aggregation query
    query = {
        "size": 0,  # We only need aggregation results
        "query": {
            "bool": {
                "must": query_filters  # Apply filters to the query
            }
        },
        "aggs": {
            "composite_values": {
                "composite": {
                    "sources": [
                        {
                            column_name: {
                                "terms": {
                                    "field": field_name
                                }
                            }
                        }
                    ],
                    "size": batch_size  # Number of buckets to retrieve per request
                }
            }
        }
    }

    # Add after_key for pagination
    if after_key:
        query["aggs"]["composite_values"]["composite"]["after"] = after_key
    query = add_customer_exists_filters(query, table, tenant_name, db_config)
    logging.info(f"## query body--- {query}")
    return query

def get_user_acess_filters(username, database):
    common_utils_database = DB('common_utils', **db_config)

    filters = common_utils_database.get_data(
        "users", {"username": username}, [ "customer_group"]
    )
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except:
        customer_group = None

    customer_group_data = None
    notification_rules = None

    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["notification_rules"]
        )
        

        if not customer_group_data.empty:
            try:
                notification_rules = tuple(json.loads(customer_group_data["notification_rules"].to_list()[0]))
            except Exception as e:
                logging.exception("### Error extracting rate_plan_name:", e)
                notification_rules=None
    return notification_rules

def get_effective_tenant_ids(tenant_name, db_name):
    """
    Returns a list of tenant_ids to be used in filters based on whether the tenant
    is a main tenant or a sub-tenant.
    
    Args:
        database: DB connection object
        tenant_name (str): Name of the tenant

    Returns:
        List[int]: List of tenant_ids to filter by
    """
    # Fetch tenant_id and parent_tenant_id
    database = DB("common_utils", **db_config)

    if tenant_name in ["Altaworx", "Altaworx Test"]:
        # Get both main tenants
        altaworx_data = database.get_data("tenant", {"tenant_name": ["Altaworx", "Altaworx Test"]}, ["id"])
        altaworx_ids = altaworx_data["id"].to_list()

        # Get sub-tenants of both
        sub_tenant_data = database.get_data("tenant", {"parent_tenant_id": altaworx_ids}, ["id"])
        sub_tenant_ids = sub_tenant_data["id"].to_list()

        return altaworx_ids + sub_tenant_ids

    tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
    if tenant_data.empty:
        raise ValueError(f"No tenant found for tenant_name: {tenant_name}")

    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]

    # Determine if main or sub-tenant
    if parent_tenant_id is not None:
        # Sub-tenant → return only its own tenant_id
        return [tenant_id]
    else:
        # Main tenant → return own ID + all sub-tenant IDs
        sub_tenant_data = database.get_data("tenant", {"parent_tenant_id": tenant_id}, ["id"])
        sub_tenant_ids = sub_tenant_data["id"].to_list()

        return [tenant_id] + sub_tenant_ids

def fetch_dropdown(data):
    column_name = data.get("drop_down", None)
    table = data.get("table", None)
    # if column_name == "progress" and table =="Central_bulk_change":
    #     column_name = "sync_status"
    flag = data.get("flag", None)
    db_name=data.get("db_name","altaworx_central")
    cascade = data.get("cascade", {})
    toggle = data.get("toggle", None)
    tenant_name = data.get("partner", "")  
    tenant_id = data.get("tenant_id", None)
    account_number = data.get("account_number",None)
    partner_name = data.get("Selected_Partner", None)
    sub_tenant_name = data.get("sub_partner") or partner_name
    username=data.get("username",None)
    current_cycle = data.get("current_cycle", None)
    if db_name == 'spectrotel':
        tenant_id=162
    elif db_name == "altaworx_go_tech":
        tenant_id=181
    elif db_name == "APITestTenant":
        tenant_id=1189
    # elif db_name == os.getenv('BILLING_PLATFORM') and tenant_name != 'Altaworx Test':
    #     tenant_id= int(tenant_id)
    else:
        tenant_id=1
    if not tenant_name:
        raise ValueError("Tenant name is missing.")
    tenant_time_zone = get_tenant_timezone(tenant_name)
    database = DB(db_name, **db_config)
    if table == "usage_by_line_report":
        # Fetch the value of optino_cross_providercustomer_optimization
        # optimization_query = f"SELECT optino_cross_providercustomer_optimization FROM public.optimization_setting_tenant_override where tenant_id='{tenant_id}' LIMIT 1"
        # optimization_data = database.execute_query(optimization_query, True)
        # if optimization_data["optino_cross_providercustomer_optimization"].tolist()[0]:
        #     table = "usp_report_customer_usage_by_line"
        table = fetching_usage_by_line_table(tenant_name, db_name, username)
    filter_conditions=cascade
    

    if (
        table == "usage_by_line_report"
        and column_name == "billing_cycle_end_date"
        and filter_conditions.keys() == {"service_provider_display_name"}
        and (service_provider_name_list := filter_conditions.get("service_provider_display_name", []))
    ):
        table = "usage_by_line_billing_period"
        filter_conditions["service_provider"] = service_provider_name_list

    table_query = f"SELECT search_tables, index_search_type FROM open_search_index WHERE search_module='{table}'"
    table_data=database.execute_query(table_query, True)
    index_name = table_data["search_tables"].tolist()[0]
    # tenant_id=1
    if db_name == 'spectrotel':
        tenant_id=162
    elif db_name == "altaworx_go_tech":
        tenant_id=181
    elif db_name == "APITestTenant":
        tenant_id=1189
    # elif db_name == os.getenv('BILLING_PLATFORM') and tenant_name != 'Altaworx Test':
    #     tenant_id= tenant_id
    else:
        tenant_id=1
    index = index_name

    
    if index in ["users","carrier_apis","amop_apis","email_audit","email_templates", "deployment_tenant_based_banners", "deployment_tenant_based_audit_logs"]:
        index_name=f"{index_name}"
    elif table in ["Central_bulk_change", "Central_optimization"]:
        index_name=f"{index_name}_central_db".lower()
    else:
        index_name=f"{index_name}_{db_name}".lower()
    available_columns = get_index_mappings(index_name)
    customer_columns = ['customer_name']
    service_provider_column = ['service_provider', 'service_provider_name', 'service_provider_display_name', 'service_providers']
    customer_rate_plan_names=["customer_rate_plan_name","rate_plan_name","customer_rate_plan","customer_rate_plans"]
        
    query=f"select customers , service_provider, customer_group, role, first_name, last_name from users where username ='{username}'"
    database = DB("common_utils", **db_config)
    # filter_conditions={}
    user_data=database.execute_query(query, True)
    user = {}
    user["role"]=user_data["role"].to_list()[0]
    user["first_name"]=user_data["first_name"].to_list()[0]
    user["last_name"]=user_data["last_name"].to_list()[0]
    flag1=False
    # try:
    #     user["customer"]=list(json.loads(user_data['customers'].to_list()[0]))
    # except:
    #     user["customer"]= []
    # try:
    #     user["service_provider"]=list(json.loads(user_data['service_provider'].to_list()[0]))
    # except:
    #     user["service_provider"]= []
    # try:
    #     user["customer_group"] = user_data['customer_group'].to_list()[0] if 'customer_group' in user_data else ""
    # except:
    #     user["customer_group"] = []

    # if user["customer_group"]:  # If customer_group exists in users table
    #     query = f"SELECT customer_names, rate_plan_name FROM customergroups WHERE name ='{user['customer_group']}'"
    #     database = DB(db_name, **db_config)
    #     customer_data = database.execute_query(query, True)
    # group = {"customer": []}
    # try:
    #     group["customer"] = list(json.loads(customer_data['customer_names'].to_list()[0]))
    # except: 
    #     group["customer"] = []
    # try:
    #     group["rate_plan_names"] = list(json.loads(customer_data['rate_plan_name'].to_list()[0]))
    # except:
    #     group["rate_plan_names"] = []
    # combined_customers = list(set(user["customer"] + group["customer"]))
    # combined_customers=tuple(combined_customers)
    # customer_field_found = False
    # index_mapping = get_index_mappings_with_types(index_name)
    # for col in customer_columns:
    #     if col in index_mapping:
    #         previous_customer_filter = filter_conditions.get(col,None)
    #         if combined_customers:
    #             # filter_conditions['customer'] = user['customer']
    #             filter_conditions['customer'] = combined_customers
    #             flag = True
    #         else:
    #             filter_conditions[col] = previous_customer_filter
    #         break
    # if not customer_field_found and group["rate_plan_names"]:
    #     inventory_index = f"sim_management_inventory"
    #     # query = f"""
    #     #     SELECT DISTINCT customer_rate_plan_name 
    #     #     FROM sim_management_inventory 
    #     #     WHERE customers IN ({','.join(f"'{rp}'" for rp in group['rate_plan_names'])})
    #     # """

    #     query = f"""
    #             SELECT distinct customer_rate_plan_name FROM sim_management_inventory
    #             WHERE customer_name IN {combined_customers} and customer_rate_plan_name is not null order by customer_rate_plan_name asc
    #         """
    #     database = DB(db_name, **db_config)
    #     rate_plan_df = database.execute_query(query, True)

    #     user["customer_rate_plan_name"]=[]
    #     if not rate_plan_df.empty:
    #         rate_plan_filters = rate_plan_df['customer_rate_plan_name'].dropna().tolist()
    #         if rate_plan_filters:
    #             filter_conditions['customer_rate_plan_name'] = rate_plan_filters
    #             flag = True
    #         user["customer_rate_plan_name"]=rate_plan_filters
    #     else:
    #         user["customer_rate_plan_name"]=[]
 
    # for col in service_provider_column:
    #     if col in index_mapping:
    #         previous_customer_filter = filter_conditions.get(col,None)
    #         if user['service_provider']:
    #             filter_conditions['service_provider'] = user['service_provider']
    #             flag1 = True
    #         else:
    #             filter_conditions[col] = previous_customer_filter
    #         break

    # try:
    #     for col in customer_rate_plan_names:
    #         if col in index_mapping:
    #             previous_customer_filter = filter_conditions.get(col,None)
    #             if rate_plan_df['customer_rate_plan_name']:
    #                 filter_conditions['customer_rate_plan_name'] = user['customer_rate_plan_name']
    #                 flag1 = True
    #             else:
    #                 filter_conditions[col] = previous_customer_filter
    #             break
    # except:
    #     pass


    # filter_conditions = {key: value for key, value in filter_conditions.items() if value and key != column_name and key not in ["device_count", "total_charges", "total_charge_amount", "base_rate", "rate_charge_amt", "overage_rate_cost"]}

    # filter_conditions = {
    #         key: " " if value[0] == "(Spaces)" else value
    #         for key, value in filter_conditions.items() 
    #         if value and not (len(value) == 1 and value[0] == "(Blanks)")  # Remove key if value is only "<Empty spaces>"
    #             and key != column_name 
    #         and key not in ["device_count", "total_charges", "total_charge_amount", "base_rate", "rate_charge_amt", "overage_rate_cost"]
    #     }
    # filter_conditions = {
    #     key: (
    #         'true' if value[0] in ["True", "Yes"] else 'false' if value[0] in ["False", "No"] else (" " if value[0] == "(Spaces)" else value)
    #     )
    # for key, value in filter_conditions.items()
    #     if value and not (len(value) == 1 and (value[0] == "(Blanks)" or (
    #             value[0] == "Unassigned" and 
    #             table in ["rev_assurance_variance", "rev_assurance"] and 
    #             key == "customer_name"
    #         )))  # Remove key if value is only "<Empty spaces>"
    #     and (flag or key != column_name) 
    #     and key not in ["device_count", "total_charges", "total_charge_amount", "base_rate", "rate_charge_amt", "overage_rate_cost"]}
    
    filter_conditions = {
    key: (
        'true' if value[0] in ["True", "Yes"]
        else 'false' if value[0] in ["False", "No"]
        else " " if value[0] == "(Spaces)"
        else value
    )
    for key, value in filter_conditions.items()
    if value
    and not (
        len(value) == 1 and (
            value[0] == "(Blanks)" or (
                value[0] == "Unassigned"
                and table in ["rev_assurance_variance", "rev_assurance"]
                and key == "customer_name"
            )
        )
    )
    and (key != column_name)  # Skip this column if it's the one triggering cascade
    and key not in [
        "device_count", "total_charges", "total_charge_amount",
        "base_rate", "rate_charge_amt", "overage_rate_cost"
    ]
    }
    index_mapping = get_index_mappings_with_types(index_name)
    # index_mapping = get_index_mappings_with_types(index_name)
    for key, value in filter_conditions.items():  # No need to use list() if we're not modifying the dictionary during iteration
        # Get the field type from index_mapping
        field_type = index_mapping.get(key, None)
        
        # Check if the field is of type int or float and if the filter condition is a list
        if field_type in ['long', 'float', 'date'] and isinstance(value, list):
            # Remove the "(Blanks)" value from the list if it exists
            filter_conditions[key] = [v for v in value if v != "(Blanks)"]
    logging.info(f"## filter_conditions check -- {filter_conditions}")
    if  "is_active" in available_columns and index not in ["users", "carrier_apis", "amop_apis","vw_status_history_report", "vw_usage_by_line_report""customer_services","gl_code","serviceprovider"]:
        filter_conditions["is_active"] = True
        if table in ["action_history_report", "usage_by_line_report", "usp_report_customer_usage_by_line"]:
            filter_conditions.pop("is_active", None)
        elif toggle == False:
            filter_conditions["is_active"] = ["true", "false"]
    if "is_active" in available_columns and "is_deleted" in available_columns and index == 'transaction_analysis_view':
        filter_conditions["is_active"] = False
        filter_conditions["is_deleted"] = False
    if account_number:
        if index == 'payment_history':
            filter_conditions['account_number'] = account_number
        elif index == 'ledger':
            filter_conditions['account'] = account_number
        elif table == 'RepostedMRC':
            service_ids = get_service_id(account_number,current_cycle)
            filter_conditions['id'] = service_ids
        else:
            id = get_customer_id(account_number)
            filter_conditions['customer_profile_id'] = int(id)
    if "tenant_id" in available_columns and index not in ["users","vw_customer_services_usage_altaworx","customer_services","gl_code"]:  
        filter_conditions["tenant_id"] = tenant_id
    if table in ["GL Code Settings","Billing Service Providers"]:
        if table == "Billing Service Providers":
            sub_tenant_name = data.get("sub_partner", None)
        if sub_tenant_name:
            tenant_name = sub_tenant_name
        elif partner_name:
            tenant_name =  partner_name
        id = get_tenant_id(tenant_name)
        print(f"## tenant_id_from_tenant {id}")
        if table == "GL Code Settings":
            filter_conditions["sub_tenant_id"] = int(id)
        else:
            filter_conditions["tenant_id"] = int(id)
            if id == 212:  #only in UAT
                filter_conditions["tenant_id"] = 1
        if 'is_active' in filter_conditions:
            var = filter_conditions['is_active']
            if isinstance(var, list):
                if var[0] == 'Inactive':
                    filter_conditions['is_active'] = False
                else:
                    filter_conditions['is_active'] = True
            else:
                if var == 'Inactive':
                    filter_conditions['is_active'] = False
                else:
                    filter_conditions['is_active'] = True
    logging.info(f"## filter_conditions ************** {filter_conditions}")
    

    if flag == "status_history" and "iccid" in available_columns:  # Custom filter for status_history flag
        iccid = data.get("iccid", None)
        if iccid:
            filter_conditions["iccid"] = [iccid[0]]

    if flag == "bulk_history" and "bulk_change_id" in available_columns:  # Custom filter for bulk_history flag
        bulk_change_id = data.get("bulk_change_id", None)
        if bulk_change_id:
            filter_conditions["bulk_change_id"] = [bulk_change_id]
    
    for key, value in filter_conditions.items():
            # Check if the value is a list or an iterable before using len()
            if isinstance(value, list):
                if len(value) > 60000:
                    filter_conditions[key] = value[:60000]  # Slice the list to the first 60000 items
                logging.info(f"## Count of values for '{key}' : {len(filter_conditions[key])}")
            else:
                logging.info(f"## Value for '{key}' is not a list, so it cannot be sliced.")
    index_mapping = get_index_mappings_with_types(index_name)
    query_filters = []
    agent_flag = False
    if index not in ["email_audit","email_templates", "users", "customer_groups_view"] and db_name != 'billing_platform':  #temproray
        agent_rel_data=db_config_maker(username, db_config,db_name, tenant_name, user['role'], table)
        logging.info(f"## agent_data {agent_rel_data}")
        filter_conditions.update(agent_rel_data)
        agent_flag = True
    logging.info(f"## filter_conditions_tej {filter_conditions}")
    if table in ['Inventory', 'inventory_export']:
        logging.info("adding service_provider_is_active filter")
        filter_conditions['service_provider_is_active'] = True
        filter_conditions['tenant_is_active'] = True
        logging.info(f"filter_conditions_tej -- {filter_conditions}")
    if index in ["email_audit", "email_templates", "users", "customer_groups_view"]:
        database = DB("common_utils", **db_config)

        tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
        if tenant_data.empty:
            raise ValueError(f"No tenant found for tenant_name: {tenant_name}")

        tenant_id = tenant_data["id"].to_list()[0]
        parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]

        if parent_tenant_id is not None:
            filter_conditions["tenant_id"] = tenant_id  # Add to filter
        else:
            filter_conditions["tenant_id"] = None  # Optional: explicitly say no filter

    logging.info(f"## filter_conditions 2************** {filter_conditions},{index}")
    # filter_conditions = {k: v for k, v in filter_conditions.items() if v is not None}
    filter_conditions = {k: v for k, v in filter_conditions.items() if v not in [None,[]]}
    for key, value in filter_conditions.items():
        if key == "customer":
            # Check if any column from customer_columns exists in index_mapping
            customer_field = next((col for col in customer_columns if col in index_mapping), None)
            if customer_field:
                field_name = f"{customer_field}.keyword" if index_mapping[customer_field] == "text" else customer_field
                if isinstance(value, (list,tuple)):  # Check for multiple values
                    query_filters.append({"terms": {field_name: value}})
                else:
                    query_filters.append({"term": {field_name: value}})
            continue  # Skip further processing for this key
        # Handle service_provider-specific logic
        if key == "service_provider":
            # Check if any column from service_provider_column exists in index_mapping
            service_provider_field = next((col for col in service_provider_column if col in index_mapping), None)
            if service_provider_field:
                field_name = f"{service_provider_field}.keyword" if index_mapping[service_provider_field] == "text" else service_provider_field
                if isinstance(value, list):  # Check for multiple values
                    query_filters.append({"terms": {field_name: value}})
                else:
                    query_filters.append({"term": {field_name: value}})
            continue  # Skip further processing for this key
        if key == "customer_rate_plan_name":
            # Check if any column from service_provider_column exists in index_mapping
            customer_rate_plan_field = next((col for col in customer_rate_plan_names if col in index_mapping), None)
            if customer_rate_plan_field:
                field_name = f"{customer_rate_plan_field}.keyword" if index_mapping[customer_rate_plan_field] == "text" else customer_rate_plan_field
                if isinstance(value, list):  # Check for multiple values
                    query_filters.append({"terms": {field_name: value}})
                else:
                    query_filters.append({"term": {field_name: value}})
            continue 
        # General logic for other keys
        if key in index_mapping:
            field_type = index_mapping[key]
            # Use '.keyword' suffix for text fields in Elasticsearch
            field_name = f"{key}.keyword" if field_type == "text" else key
            if isinstance(value, list):  # Check for multiple values
                query_filters.append({"terms": {field_name: value}})
            else:
                query_filters.append({"term": {field_name: value}})
    # if agent_flag:
    #     all_customer_plan_fields = customer_columns + customer_rate_plan_names
    #     contains_customer_or_plan = any(
    #         any(
    #             any(field == k or f"{field}.keyword" == k for field in all_customer_plan_fields)
    #             for k in list(q.get("term", {}).keys()) + list(q.get("terms", {}).keys())
    #         )
    #         for q in query_filters
    #     )
    #     if not contains_customer_or_plan:
    if user['role'] != 'Super Admin' and table in ["rev_assurance_variance", "rev_assurance","sim_management_bulk_change","e911customers","rule_rule_defination"]:
        by_fields = ["created_by", "modified_by", "deleted_by", "processed_by"]
        selected_by_field = next((field for field in by_fields if field in index_mapping), None)
        username = user["first_name"]+" "+user["last_name"]
        if selected_by_field:
            field_type = index_mapping[selected_by_field]
            field_name = f"{selected_by_field}.keyword" if field_type == "text" else selected_by_field
            query_filters.append({"term": {field_name: username}})

    if table in ["Central_bulk_change", "Central_optimization"]:
        query_filters = [f for f in query_filters if 'tenant_id' not in f.get('term', {})]
    logging.info(f"## query_filters {query_filters}")
    unique_values = fetch_distinct_values_with_composite(index_name, column_name, query_filters,table,tenant_name)
    values = unique_values.get(column_name, [])
    col_data = []
    yes_no_columns = {"volte_capable", "assigned"}
    active_inactive_columns = {"is_active"}
    enable_disable_columns = {"api_state", "email_status"}
    true_false_columns = {"nsdev", "auto_change_rate_plan"}
    index_active_columns = {"users", "vw_customer_rate_plans", "amop_apis", "carrier_apis", "email_templates","products_list_view",'gl_code'}
    capitalization_columns = {"optimization_type"}

    # Iterate over the values once, reducing redundancy
    for val in values:
        # Check for blanks
        if val is None or str(val).strip() == "":
            if "" not in col_data:
                col_data.append("(Spaces)")
        else:
            # Optimize column-specific checks using set lookups
            if column_name in yes_no_columns:
                col_data.append("Yes" if val == 1 or val == "Yes" else "No")
            elif column_name in active_inactive_columns and index in index_active_columns:
                col_data.append("Active" if val == 1 else "Inactive")
            elif column_name in enable_disable_columns and index in index_active_columns:
                col_data.append("Enable" if val == 1 else "Disable")
            elif column_name in true_false_columns and (index == "vw_customer_rate_plans" or index == "imei_master"):
                col_data.append("True" if val == 1 else "False")
            elif column_name in capitalization_columns and (index == "vw_customer_rate_plans"):
                normalized_val = "Cross customer pooling" if val in ["Cross Customer Pooling", "Cross customer pooling", "cross customer pooling", "Cross Customer pooling"] else val
                if normalized_val not in col_data:  # Avoid appending duplicates
                    col_data.append(normalized_val)
            elif isinstance(val, Decimal):
                col_data.append(float(val))  # Convert Decimal to float
            elif isinstance(val, bool):
                col_data.append(str(val).lower())
            else:
                col_data.append(val)
        
    if column_name in index_mapping and index_mapping[column_name] == "date":
        # col_data = [convert_to_tenant_timezone(i, tenant_time_zone) for i in col_data] 
        try:
            col_data = list(set(col_data))
            col_data.sort(
                    key=lambda x: datetime.datetime.strptime(x, "%m/%d/%Y"),
                    reverse=True
                )

        except ValueError as e:
            logging.error(f"## Fetch drop down - Error while parsing dates: {e}")
    
    cols_except=["service_provider","service_provider_display_name","service_provider_name","id","modified_date","order_of_execution","is_active"]
    
    # if column_name not in cols_except:
    #     if index == "vw_combined_rev_service_products" and column_name == "customer_name":
    #         col_data = ["unassigned"] + ["assigned"] + col_data
    #     else:
    #         col_data = ["(Blanks)"] + col_data

    if column_name not in cols_except:
        if table in ["rev_assurance_variance", "rev_assurance"] and column_name == "customer_name":
            # For specific tables and column, add 'unassigned' and 'assigned' at the start
            col_data = ["Unassigned", "Assigned"] + col_data
        else:
            col_data = ["(Blanks)"] + col_data

    if column_name in ["billing_period_duration", "billing_period_duration_dates"] :
        
        filtered_date_ranges = [d for d in col_data if d.strip() and extract_start_date(d) is not None]

        # Sort the list based on the extracted start date, in descending order
        sorted_date_ranges = sorted(filtered_date_ranges, key=extract_start_date, reverse=True)
        
        # Convert the sorted list to the required format: month/day/year
        col_data = [ f"{datetime.datetime.strptime(d.split(' - ')[0], '%m/%d/%Y').strftime('%m/%d/%Y')} - {d.split(' - ')[1]}" 
            for d in sorted_date_ranges]
    # if column_name == "sync_status" and table =="Central_bulk_change":
    #     column_name = "progress"
    unique_values[column_name] = col_data
    return unique_values
