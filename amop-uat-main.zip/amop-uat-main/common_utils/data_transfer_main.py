import os
import copy
import numpy as np
from datetime import datetime, timedelta
from dotenv import load_dotenv
import pandas as pd

import math
import logging
import time
from sqlalchemy import create_engine, exc, text

import time
import psycopg2
import pandas as pd
from tenacity import retry, stop_after_attempt, wait_fixed
from dotenv import load_dotenv
import os
import re
import pytds
import json
from datetime import datetime, timedelta

import time
from psycopg2.extras import execute_values

from common_utils.logging_utils import Logging

# from logging_utils import Logging
logging = Logging()


class DataTransfer:
    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
    def create_connection_oldpyodbc(
        self,
        db_type="",
        host="",
        db_name="",
        username="",
        password="",
        port="",
        driver="",
        max_retry=3,
    ):
        connection = None
        retry = 1
        # print(f"db_type:{db_type}, host--{host}-db_name-{db_name}, username-{username},password-{password},port-{port},driver-{driver}")

        if db_type == "postgresql":
            try:
                logging.info(f"creating postgresql connection")

                connection = psycopg2.connect(
                    host=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port,
                )
                logging.info("Connection to PostgreSQL DB successful")
            except Exception as e:
                logging.error(f"Failed to connect to PostgreSQL DB: {e}")
        elif db_type == "mssql":
            print(
                f"conn : {db_type},{host},{db_name},{username},{password},{driver},{port}"
            )
            print("Creating MSSQL connection")
            logging.info(f"Creating MSSQL connection")
            try:
                # connection_string= f"""DRIVER={driver};SERVER={host};DATABASE={db_name};UID={username};PWD={password};"""

                # connection = pyodbc.connect(connection_string)
                # connection = pymssql.connect(host=host,user=username,password=password,db=db_name,connect_timeout=5)
                logging.info("Connection to MSSQL successful!")
                print("Connection to MSSQL successful!")
            except Exception as e:
                logging.error(f"Failed to connect to MSSQL DB: {e}")
        return connection

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
    def create_connection(
        self,
        db_type="",
        host="",
        db_name="",
        username="",
        password="",
        port="",
        driver="",
        max_retry=3,
    ):
        connection = None

        if db_type == "postgresql":
            try:
                logging.info(f"Creating PostgreSQL connection")
                connection = psycopg2.connect(
                    host=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port,
                )
                logging.info("Connection to PostgreSQL DB successful")
            except Exception as e:
                logging.error(f"Failed to connect to PostgreSQL DB: {e}")
        elif db_type == "mssql":
            print(
                f"conn : {db_type},{host},{db_name},{username},{password},{driver},{port}"
            )
            print("Creating MSSQL connection")
            logging.info(f"Creating MSSQL connection using pytds")
            try:
                connection = pytds.connect(
                    server=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port,
                )
                # connection = pymssql.connect(
                #     server=host,
                #     user=username,
                #     password=password,
                #     database=db_name,
                #     port=port,
                #     timeout=5
                # )
                # connection = pymssql.connect(host=host,user=username,password=password,db_name=db_name,connect_timeout=5)
                logging.info("Connection to MSSQL successful!")
            except Exception as e:
                logging.error(f"Failed to connect to MSSQL DB: {e}")

        return connection

    def execute_query(self, connection, query, params=None):

        try:
            # Check if params are provided
            if params:
                # Execute the query with parameters
                result_df = pd.read_sql_query(query, connection, params=params)
            else:
                # Execute the query without parameters
                result_df = pd.read_sql_query(query, connection)

            return result_df
        except Exception as e:
            logging.error(f"Error executing query: {e}")
            return None

    def is_valid_table_name(self, table_name):
        pattern = r"^\[\w+\]\.\[\w+\]\.\[\w+\]$"
        return re.match(pattern, table_name) is not None

    def map_cols(self, table_mapping, col_mapping, postgres_data):
        try:
            insert_data = {}

            for table_name, records in postgres_data.items():
                # Get target table names for table_name
                target_tables = table_mapping.get(table_name, [])

                for target_table in target_tables:
                    # Get column mappings for the target table
                    mapping = col_mapping.get(target_table, {})
                    print(f"Mapiin got for {target_table} is {mapping}")

                    temp_records = [
                        {
                            mapping[key]: value
                            for key, value in record.items()
                            if key in mapping
                        }
                        for record in records
                    ]
                    print(f"TEmp recs are {temp_records}")
                    insert_data[target_table] = temp_records
            return insert_data
        except Exception as e:
            logging.error(f"Error while mapping columns: {e}")
            return {}

    def replace_nan_with_none(self, data):
        for key, value in data.items():
            if isinstance(
                value, list
            ):  # If the value is a list, loop through each item
                for record in value:
                    for record_key, record_value in record.items():
                        if isinstance(record_value, float) and math.isnan(record_value):
                            record[record_key] = None
            elif isinstance(
                value, dict
            ):  # If the value is a dict, recursively handle it
                self.replace_nan_with_none(value)
            elif isinstance(value, float) and math.isnan(
                value
            ):  # Handle top-level keys
                data[key] = None

    def insert_data_to_db(
        self, table_name, data_list, mssql_conn, return_col, table_name_10
    ):
        try:
            if not mssql_conn:
                raise ValueError("Invalid MSSQL connection")

            if not data_list:
                raise ValueError("Data list is empty")

            cursor = mssql_conn.cursor()

            # Extract column names and placeholders
            for row in data_list:
                '''if "Id" in row:
                logging.info("entered into update part")
                logging.info(row.items())

                logging.info(f'&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&---------{row}')
                # Construct the column names and corresponding placeholders, excluding 'Id'
                update_columns = ', '.join([f"{key} = '{row[key]}'" for key in row.keys() if key != 'Id'])
                id_value = row['Id']
                #logging.info(f'*******************---{update_columns}')
                sql_update_query = f"""
                    UPDATE {table_name}
                    SET {update_columns}
                    WHERE Id = {id_value};
                    """
                logging.info(f'update*******************************-{sql_update_query}')
                cursor.execute(sql_update_query)
                mssql_conn.commit()
                return None'''
                if "Id" in row:
                    cursor = mssql_conn.cursor()
                    print("entered into update part")
                    print(row.items())
                    # column_names = ', '.join([key for key in row.keys() if key != 'Id'])
                    # column_values = ', '.join([f"'{row[key]}'" for key in row.keys() if key != 'Id'])
                    values_section = ""
                    for key in row.keys():
                        if row[key] is None:
                            if values_section:
                                values_section = values_section + ", " + f"{'NULL'}"
                            else:
                                values_section = f"{'NULL'}"
                        else:
                            if values_section:
                                values_section = values_section + ", " + f"'{row[key]}'"
                            else:
                                values_section = f"'{row[key]}'"

                    source_columns = ", ".join([key for key in row.keys()])
                    print(values_section)
                    print(source_columns)

                    source_columns = ", ".join([key for key in row.keys()])
                    id_value = row["Id"]

                    # print("*******************", column_names, column_values)

                    matched_update = ", ".join(
                        [
                            f"target.{key} = source.{key}"
                            for key in row.keys()
                            if key != "Id"
                        ]
                    )

                    insert_columns = ", ".join(
                        [key for key in row.keys() if key != "Id"]
                    )
                    insert_values = ", ".join(
                        [f"source.{key}" for key in row.keys() if key != "Id"]
                    )
                    print("*******************", insert_columns, insert_values)

                    # Construct the SQL MERGE query
                    sql_merge_query = f"""
                    MERGE INTO {table_name} AS target
                    USING (VALUES ({values_section})) AS source ({source_columns})
                    ON target.Id = source.Id
                    WHEN MATCHED THEN
                    UPDATE SET {matched_update}
                    WHEN NOT MATCHED BY TARGET THEN
                    INSERT ({insert_columns}) VALUES ({insert_values})
                    OUTPUT INSERTED.Id;
                    """
                    print(f"Merge Query {sql_merge_query}")

                    cursor.execute(sql_merge_query)
                    inserted_ids = cursor.fetchall()
                    # inserted_ids=30
                    if inserted_ids:

                        newly_inserted_id = inserted_ids[0][0]
                        print(f"Newly inserted Id: {newly_inserted_id}")
                        print(f"Newly inserted Id: {inserted_ids}")
                    mssql_conn.commit()
                    print("merge query*******************************", sql_merge_query)
                    # return newly_inserted_id
                    return {"id": newly_inserted_id}, {"id": id_value}

                else:
                    cursor = mssql_conn.cursor()

                    # Extract column names and placeholders
                    columns = ", ".join(row.keys())
                    placeholders = ", ".join(
                        ["%s"] * len(row)
                    )  # Use %s placeholders for pytds
                    if return_col:
                        sql_query = f"INSERT INTO {table_name} ({columns}) OUTPUT INSERTED.{return_col} VALUES ({placeholders})"
                    else:
                        sql_query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"

                    try:
                        return_val = None
                        return_fk_name = None

                        # Convert rows to tuples and execute in a batch
                        # for row in data_list:

                        values = tuple(
                            (
                                None
                                if (
                                    (not row[col] or row[col] is None)
                                    and row[col] != False
                                )
                                else (
                                    row[col]
                                    if isinstance(row[col], (str, int, float, bool))
                                    else json.dumps(
                                        row[col].item()
                                        if isinstance(
                                            row[col], (np.integer, np.floating)
                                        )
                                        else row[col]
                                    )
                                )
                            )
                            for col in row.keys()
                        )
                        logging.info(sql_query)
                        logging.info(values)

                        cursor.execute(sql_query, values)

                        if return_col:
                            return_val = cursor.fetchone()[0]
                            return_fk_name = f"{table_name_10}.{return_col}"

                        mssql_conn.commit()
                        logging.info("Insert Successful")

                        if return_col:
                            return return_val, return_fk_name

                    except Exception as e:
                        logging.info(f"Failed to insert row into {table_name}: {e}")
                        mssql_conn.rollback()
                        return None

                    finally:
                        cursor.close()
        except Exception as e:
            logging.info(f"Error while inserting row into {table_name}: {e}")

    """def insert_data_to_db(self, table_name, data_list, mssql_conn, return_col, table_name_10):
        print(f"insert data {table_name},{data_list}")
        try:
            if not mssql_conn:
                raise ValueError("Invalid MSSQL connection")

            if not data_list:
                raise ValueError("Data list is empty")

            cursor = mssql_conn.cursor()

            # Extract column names and placeholders
            columns = ', '.join(data_list[0].keys())
            # placeholders = ', '.join(['?'] * len(data_list[0])) #for pyodbc
            placeholders = ', '.join(['%s'] * len(data_list[0]))  # Use %s placeholders for pytds

            # Construct the SQL query
            if return_col:
                sql_query = f"INSERT INTO {table_name} ({columns}) OUTPUT INSERTED.{return_col} VALUES ({placeholders})"
            else:
                sql_query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"

            try:
                return_val = None
                return_fk_name = None

                # Convert rows to tuples and execute in a batch
                for row in data_list:
                    values = tuple(
                        # row[col] if isinstance(row[col], (str, int, float, bool)) else json.dumps(row[col])
                        row[col] if row[col] is None or isinstance(row[col], (str, int, float, bool)) else json.dumps(row[col])
                        for col in row.keys()
                    )
                    cursor.execute(sql_query, values)
                    if return_col:
                        return_val = cursor.fetchone()[0]
                        return_fk_name = f"{table_name_10}.{return_col}"

                mssql_conn.commit()
                logging.info("Insert Successful")

                if return_col:
                    return return_val, return_fk_name

            except Exception as e:
                logging.error(f"Failed to insert row into {table_name}: {e}")
                mssql_conn.rollback()
                return None


            finally:
                cursor.close()
        except Exception as e:
            logging.error(f"Error while inserting row into {table_name} : {e}")"""

    def update_table(self, conn, table_name, data_dict, condition_dict):
        """
        Update a PostgreSQL table using a dictionary.

        :param conn: psycopg2 connection object
        :param table_name: Name of the table to update
        :param data_dict: Dictionary containing column-value pairs to update
        :param condition_dict: Dictionary containing column-value pairs for the WHERE condition
        """
        try:
            # Replace NaN with None in data_dict
            data_dict = {
                k: (None if isinstance(v, float) and math.isnan(v) else v)
                for k, v in data_dict.items()
            }

            # Replace NaN with None in condition_dict
            condition_dict = {
                k: (None if isinstance(v, float) and math.isnan(v) else v)
                for k, v in condition_dict.items()
            }
            # Generate the SET part of the SQL query
            set_clause = ", ".join([f"{col} = %s" for col in data_dict.keys()])

            # Handle condition dict with lists or single values
            where_clause = []
            # print(f"in updat_table val dict is {data_dict}")
            values = list(data_dict.values())

            for col, val in condition_dict.items():
                if isinstance(val, list):
                    # Generate the WHERE clause for IN condition
                    placeholders = ", ".join(["%s"] * len(val))
                    where_clause.append(f"{col} IN ({placeholders})")
                    values.extend(val)  # Add the list values to the values list
                else:
                    # Handle single value condition
                    where_clause.append(f"{col} = %s")
                    values.append(val)

            # Combine WHERE conditions
            if where_clause:
                where_clause = " AND ".join(where_clause)
                sql_query = f"UPDATE {table_name} SET {set_clause} WHERE {where_clause}"
            else:
                sql_query = f"UPDATE {table_name} SET {set_clause}"

            # Print the SQL query and values for debugging
            logging.info(f"SQL Query: {sql_query}")
            logging.info(f"Values: {values}")

            # Execute the query
            try:
                with conn.cursor() as cursor:
                    cursor.execute(sql_query, values)
                    conn.commit()
                logging.info("Update successful")
            except Exception as e:
                conn.rollback()
                print(f"Error in updating {e}")

        except Exception as e:
            conn.rollback()
            logging.error(f"Error while updating table {table_name}: {e}")

    def load_env_pgsql(self):
        load_dotenv()
        hostname = os.getenv("LOCAL_DB_HOST")
        port = os.getenv("LOCAL_DB_PORT")
        user = os.getenv("LOCAL_DB_USER")
        password = os.getenv("LOCAL_DB_PASSWORD")
        db_type = os.getenv("LOCAL_DB_TYPE")
        db_name = os.getenv("LOCAL_DB_NAME")
        return hostname, port, user, password, db_type, db_name

    def load_env_mssql(self):
        from_host = os.getenv("FROM_DB_HOST")
        from_port = os.getenv("FROM_DB_PORT")
        from_db = os.getenv("FROM_DB_NAME")
        from_user = os.getenv("FROM_DB_USER")
        from_pwd = os.getenv("FROM_DB_PASSWORD")
        from_db_type = os.getenv("FROM_DB_TYPE")
        from_driver = os.getenv("FROM_DB_DRIVER")
        return (
            from_host,
            from_port,
            from_db,
            from_user,
            from_pwd,
            from_db_type,
            from_driver,
        )

    def delete_from_pgsql(self, mssql_conn, id_10, table_name_10):
        try:
            cursor = mssql_conn.cursor()
            print(f"Going to update id {id_10}")
            delete_query = (
                f"Update {table_name_10} set IsActive=0, IsDeleted=1 where id={id_10}"
            )
            print(f"Delete Query {delete_query}")
            cursor.execute(delete_query)
            mssql_conn.commit()
            print(f"Deleted from 1.0")
        except Exception as e:
            print(f"Error while deleting from 1.0: {e}")

    # def delete_from_pgsql(self,mssql_conn,id_10,table_name_10):
    #     try:
    #         print(f"conn is {mssql_conn}")
    #         cursor = mssql_conn.cursor()
    #         delete_query=f"DELETE FROM {table_name_10} WHERE id={id_10}"
    #         cursor.execute(delete_query)
    #         mssql_conn.commit()
    #         print(f"Deleted from 1.0")
    #     except Exception as e:
    #         print(f"Error while deleting from 1.0: {e}")

    def delete_from_10_customerrp(self, mssql_conn, id_10, table_name_10):
        try:
            print(f"conn is {mssql_conn}")
            cursor = mssql_conn.cursor()
            delete_query = (
                f"DELETE FROM {table_name_10} WHERE CustomerRatePlanId={id_10}"
            )
            cursor.execute(delete_query)
            mssql_conn.commit()
            print(f"Deleted from 1.0")
        except Exception as e:
            print(f"delete_from_10_customerrp Error while deleting from 1.0: {e}")

    def is_valid_table_name(self, table_name):
        pattern = r"^\[\w+\]\.\[\w+\]\.\[\w+\]$"
        return re.match(pattern, table_name) is not None

    def delete_data_from_10(self, transfer_name, postgres_data, id_10, table_name_10):
        try:
            (
                from_host,
                from_port,
                ssms_db_name,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()
            # mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            if not self.is_valid_table_name(table_name_10):
                full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                logging.info(f"full table name {full_from_table}")
            else:
                full_from_table = table_name_10
            if (
                transfer_name == "customer_rate_plan"
                and full_from_table == "AutomationRule_CustomerRatePlan"
            ):
                self.delete_from_10_customerrp(mssql_conn, id_10, full_from_table)
            else:
                dd = self.delete_from_pgsql(mssql_conn, id_10, full_from_table)
        except Exception as e:
            logging.error(f"Error while loading env: {e}")

    def save_data_to_10_single_table(
        self, transfer_name, postgres_data, update_flag=False, delete_flag=False
    ):
        try:
            logging.info(f"STARTING {transfer_name}")
            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            logging.info(
                f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}"
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_details_query = f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get("table_mapping_10_to_20", {})
            db_name_20 = mapping_details.get("db_name_20", {})
            logging.info(f"db_name_20 is {db_name_20}")
            logging.info(type(tables_dict))  # 1.0 to 2.0 table mappings dict
            col_mappings = mapping_details.get("col_mapping_10_to_20", {})
            logging.info(type(col_mappings))  # 1.0 to 2.0 column mappings
            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})  # foreign key columns
            db_config = mapping_details.get("db_config", {})  # ssms db config details
            table_name_20 = mapping_details.get("table_mapping_10_to_20").keys()
            table_name_20 = ", ".join(str(key) for key in table_name_20)
            logging.info(f"table_name_20 is {table_name_20}")
            table_name_10 = tables_dict[table_name_20][0]
            logging.info(f"Table Name 1.0 is {table_name_10}")
            # update_flag=True
            hostname = os.getenv("LOCAL_DB_HOST")
            port = os.getenv("LOCAL_DB_PORT")
            db_name = db_name_20
            user = os.getenv("LOCAL_DB_USER")
            password = os.getenv("LOCAL_DB_PASSWORD")
            db_type = os.getenv("LOCAL_DB_TYPE")
            from_driver = os.getenv("LOCAL_DB_DRIVER")
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            postgres_data_copy = copy.deepcopy(postgres_data)
            if delete_flag is True and update_flag is False:
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                update_data["id_10"] = id_10
                logging.info(f"id_10 is {id_10}")
                delete_data = self.delete_data_from_10(
                    transfer_name, postgres_data, id_10, table_name_10
                )
                return True

            elif update_flag is True and delete_flag is False:
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                logging.info(f"id_10 is {id_10}")
                update_data["id_10"] = id_10
                postgres_data_20 = {table_name_20: [update_data]}
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data_20
                )
            else:
                logging.info(f"tables_dict {tables_dict}")
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data
                )
            logging.info(f"total insert dict is {total_insert_dict}")

            (
                from_host,
                from_port,
                ssms_db_name,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()
            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn {mssql_conn}")

            logging.info(f"total insert dict {total_insert_dict}")

            return_ids = []

            fk_track_dict = {}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                # if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"

                if return_params_10:
                    logging.info(f"Heree 2111 {return_params_10}")
                    return_col = return_params_10.get(
                        table_name_10, None
                    )  # get the col whose value should be returned for this table
                    fk_col_dict = fk_cols_10.get(
                        table_name_10, {}
                    )  # get the fk_col dict for this table
                else:
                    return_col = None
                    fk_col_dict = None

                if not return_col and not fk_col_dict:
                    logging.info(
                        "This part is to handle update tables don't have any foreign key columnc"
                    )
                    if update_flag is False:
                        return_col = "ID"
                        return_val, return_fk_name = self.insert_data_to_db(
                            full_from_table,
                            total_insert_dict[table_name_10],
                            mssql_conn,
                            return_col,
                            table_name_10,
                        )
                        logging.info(
                            f"return val is {return_val} return fk name is {return_fk_name}"
                        )
                        update_postgres_data = postgres_data[table_name_20][0]
                        logging.info(
                            f"2.0 data is to be updated is {update_postgres_data}"
                        )
                        update_postgres_data["id_10"] = return_val
                        update_postgres_id = update_postgres_data["id"]
                        update_postgres_data.pop("id")
                        logging.info(f"update_postgres_data is {update_postgres_data}")
                        self.update_table(
                            postgres_conn1,
                            table_name_20,
                            update_postgres_data,
                            {"id": update_postgres_id},
                        )

                    else:
                        update_value, update_condtion = self.insert_data_to_db(
                            full_from_table,
                            total_insert_dict[table_name_10],
                            mssql_conn,
                            None,
                            table_name_10,
                        )
                        logging.info(
                            f"update value is {update_value} update condition is {update_condtion}"
                        )
                        logging.info(postgres_conn)
                        update_data_20 = postgres_data[table_name_20][0]
                        logging.info(f"update data 20 is {update_data_20}")
                        id_10 = int(update_value["id"])
                        update_data_20["id_10"] = id_10
                        id_20 = int(update_data_20["id"])
                        self.update_table(
                            postgres_conn1, table_name_20, update_data_20, {"id": id_20}
                        )

        except Exception as e:
            logging.error(f"Error in single_table_data_insert {e}")

    def save_data_to_10(
        self, transfer_name, postgres_data, update_flag=False, delete_flag=False
    ):
        try:
            if transfer_name == "bulk_change":
                data_list = postgres_data["sim_management_bulk_change"]
                service_provider_id = data_list[0]["service_provider_id"]
                print(f"11111 {service_provider_id}")
                if str(service_provider_id) in ["6", "20"]:
                    transfer_name = "bulk_change_mobility"
                else:
                    transfer_name = "bulk_change"
            print(f"SAVE DATA TO 10 Starting")
            logging.info(f"STARTING TRANSFER {transfer_name}")
            # establishing postgres connection
            start_time = time.time()
            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn_start = time.time()
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(
                f"Postgres connection time: {time.time() - postgres_conn_start:.4f} seconds"
            )
            print(
                f"Postgres connection time: {time.time() - postgres_conn_start:.4f} seconds"
            )
            ##getting all the details for a particular transfer
            query_start = time.time()
            mapping_details_query = f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)
            print(f"Query execution time: {time.time() - query_start:.4f} seconds")
            logging.info(
                f"Query execution time: {time.time() - query_start:.4f} seconds"
            )

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get(
                "table_mapping_10_to_20", {}
            )  # 1.0 to 2.0 table mappings dict
            if transfer_name == "customer_rate_plan":
                service_provider_id = postgres_data["customerrateplan"][0][
                    "service_provider_id"
                ]
                if service_provider_id != 20:
                    # Remove 'automation_rule' key if present
                    if "automation_rule" in tables_dict:
                        del tables_dict["automation_rule"]

                    # Remove 'CustomerRatePlan_JasperCarrierRatePlan' from the 'customerrateplan' list if present
                    if "customerrateplan" in tables_dict:
                        tables_dict["customerrateplan"] = [
                            item
                            for item in tables_dict["customerrateplan"]
                            if item != "CustomerRatePlan_JasperCarrierRatePlan"
                        ]
            db_name_20 = mapping_details.get("db_name_20", {})
            print(f"db_name_20 is {db_name_20}")
            col_mappings = mapping_details.get(
                "col_mapping_10_to_20", {}
            )  # 1.0 to 2.0 column mappings
            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})  # foreign key columns
            db_config = mapping_details.get("db_config", {})  # ssms db config details
            print(f"@@@@@@@@@@@@@@@@@@  mapping_details {mapping_details}")
            table_name_20 = mapping_details.get("table_mapping_10_to_20").keys()
            table_name_20 = ", ".join(str(key) for key in table_name_20)
            print(f"table_name_20 is {table_name_20}")

            # from_host=db_config['hostname']
            # from_port=db_config['port']
            # from_user=db_config['user']
            # from_pwd=db_config['password']
            # from_db_type=db_config['from_db_type']
            # from_driver=os.getenv('FROM_DB_DRIVER')
            # ssms_db_name=os.getenv('FROM_DB_NAME')

            # get the data to insert dict for ssms according to mappings
            mapping_start = time.time()
            print(f"postgres_data---------{postgres_data}")
            print(f"col_mappings-----------{col_mappings}")
            hostname = os.getenv("LOCAL_DB_HOST")
            port = os.getenv("LOCAL_DB_PORT")
            db_name = db_name_20
            user = os.getenv("LOCAL_DB_USER")
            password = os.getenv("LOCAL_DB_PASSWORD")
            db_type = os.getenv("LOCAL_DB_TYPE")
            from_driver = os.getenv("LOCAL_DB_DRIVER")
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            # if transfer_name=='customer_rate_plan' and update_flag is True:
            #     update_data=postgres_data['customerrateplan'][0]
            #     id_20=update_data['id']
            #     print(f"id_10 data is {id_20}")
            #     id_10=f"select id_10 from customerrateplan where id='{id_20}'"
            #     result=self.execute_query(postgres_conn1,id_10)
            #     id_10=result['id_10'][0]
            #     print(f"id_10 is {id_10}")
            #     update_data['id_10']=id_10
            #     postgres_data_20={'customerrateplan':[update_data]}
            #     total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data_20)
            # elif transfer_name=='customer_rate_plan' and delete_flag is True:
            #     update_data=postgres_data['customerrateplan'][0]
            #     id_20=update_data['id']
            #     print(f"id_10 data is {id_20}")
            #     id_10=f"select id_10 from customerrateplan where id='{id_20}'"
            #     result=self.execute_query(postgres_conn1,id_10)
            #     id_10=result['id_10'][0]
            #     print(f"id_10 is {id_10}")
            #     delete_data=self.delete_data_from_10(transfer_name,postgres_data,id_10)
            #     return True
            # else:
            #     total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data)
            # # total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data)
            # making mssql_connection
            (
                from_host,
                from_port,
                ssms_db_name,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()
            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            print(f"mssql_conn {mssql_conn}")
            # logging.info(f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds")

            postgres_data_copy = copy.deepcopy(postgres_data)
            logging.info(f"postgres_data_20 before handling data {postgres_data_copy}")
            if delete_flag is True and update_flag is False:
                print(f"In this ond {delete_flag} and {update_flag}")
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                update_data["id_10"] = id_10
                logging.info(f"id_10 is {id_10}")
                table_name_10 = tables_dict[table_name_20][0]
                logging.info(f"Table Name 1.0 is {table_name_10}")
                delete_data = self.delete_data_from_10(
                    transfer_name, postgres_data, id_10, table_name_10
                )
                return True

            elif update_flag is True and delete_flag is False:
                print(f"update flag {update_flag} and delete flag {delete_flag}")
                if transfer_name == "customer_rate_plan":
                    table_name_20 = table_name_20.split(",")[-1].strip()
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                logging.info(f"id_10 is {id_10}")
                update_data["id_10"] = id_10
                postgres_data_20 = {table_name_20: [update_data]}

                # total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data_20)
                if transfer_name == "customer_rate_plan":
                    service_provider_id = postgres_data["customerrateplan"][0][
                        "service_provider_id"
                    ]
                    if service_provider_id == 20:
                        # Delete the records in [AutomationRule_CustomerRatePlan](1.0)
                        table_name_arcr = "AutomationRule_CustomerRatePlan"
                        id_10 = int(id_10)
                        self.delete_data_from_10(
                            transfer_name, postgres_data, id_10, table_name_arcr
                        )
                        update_data_arcr = postgres_data_copy["automation_rule"]
                        for item in update_data_arcr:
                            item["id_10"] = int(id_10)
                        postgres_data_20["automation_rule"] = update_data_arcr
                        logging.info(
                            f"postgres_data_20 before map cols is {postgres_data_20}"
                        )
                        total_insert_dict = self.map_cols(
                            tables_dict, col_mappings, postgres_data_20
                        )

                        # Update the records in [CustomerRatePlan_JasperCarrierRatePlan] table (1.0)
                        table_name_crjcr = "CustomerRatePlan_JasperCarrierRatePlan"
                        updated_soccode_data = total_insert_dict[table_name_crjcr][0]
                        updated_soccode_data.pop("CustomerRatePlanId")
                        logging.info(f"updated_soccode_data {updated_soccode_data}")
                        total_insert_dict.pop(table_name_crjcr)
                        id_10 = int(id_10)
                        self.update_table(
                            mssql_conn,
                            table_name_crjcr,
                            updated_soccode_data,
                            {"CustomerRatePlanId": id_10},
                        )
                    else:
                        logging.info(
                            f"postgres_data_20 after handling data before map cols is {postgres_data_20}"
                        )
                        total_insert_dict = self.map_cols(
                            tables_dict, col_mappings, postgres_data_20
                        )
                else:
                    logging.info(
                        f"postgres_data_20 before map cols is {postgres_data_20}"
                    )
                    total_insert_dict = self.map_cols(
                        tables_dict, col_mappings, postgres_data_20
                    )
            else:
                logging.info(f"tables_dict {tables_dict}")
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data
                )

            logging.info(f"total insert dict is {total_insert_dict}")

            # print(f'total_insert_dict------------{total_insert_dict}')
            # logging.info(f"Data mapping time: {time.time() - mapping_start:.4f} seconds")

            return_ids = []
            fk_track_dict = {}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                print(f"Begining insertion for {table_name_10}")
                # if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"

                if return_params_10:
                    # return_params_10 = json.loads(return_params_10)
                    print(f"Return Params are {return_params_10}")

                    return_col = return_params_10.get(
                        table_name_10
                    )  # get the col whose value should be returned for this table
                    fk_col_dict = fk_cols_10.get(
                        table_name_10, {}
                    )  # get the fk_col dict for this table
                    print(f"return_col are {return_col}")
                else:
                    return_col = None
                    fk_col_dict = None

                print(f"return_col {return_col}")
                print(f"fk_col_dict {fk_col_dict}")
                # logging.info("there is no return_col")
                # logging.info("there is no fk_cols_10")

                if not return_col and not fk_col_dict:
                    print(
                        "This part is to handle update tables don't have any foreign key columnc"
                    )
                    # print(full_from_table)
                    # print(total_insert_dict[table_name_10])
                    # print(table_name_10)
                    # print(mssql_conn)
                    # if transfer_name=='customer_rate_plan' and update_flag is False:
                    #     return_col='ID'
                    #     return_val, return_fk_name=self.insert_data_to_db(full_from_table,total_insert_dict[table_name_10],mssql_conn,return_col,table_name_10)
                    #     print(f"return val is {return_val} return fk name is {return_fk_name}")
                    #     update_postgres_data=postgres_data['customerrateplan'][0]
                    #     update_postgres_data['id_10']=return_val
                    #     update_postgres_id=update_postgres_data['id']
                    #     update_postgres_data.pop('id')
                    #     print(f"update_postgres_data is {update_postgres_data}")
                    #     self.update_table(postgres_conn1,'customerrateplan',update_postgres_data,{'id':update_postgres_id})
                    # else:
                    #     update_value,update_condtion=self.insert_data_to_db(full_from_table,total_insert_dict[table_name_10],mssql_conn,None,table_name_10)
                    #     print(f"update value is {update_value} update condition is {update_condtion}")
                    #     print(postgres_conn)
                    #     if transfer_name=='customer_rate_plan':
                    #         update_data_20=postgres_data['customerrateplan'][0]
                    #         print(f"update data 20 is {update_data_20}")
                    #         id_10=int(update_value['id'])
                    #         update_data_20['id_10']=id_10
                    #         id_20=int(update_data_20['id'])
                    #         self.update_table(postgres_conn1,table_name_20,update_data_20,{'id':id_20})

                    logging.info(
                        "This part is to handle update tables don't have any foreign key columnc"
                    )
                    if update_flag is False:
                        return_col = "ID"
                        return_val, return_fk_name = self.insert_data_to_db(
                            full_from_table,
                            total_insert_dict[table_name_10],
                            mssql_conn,
                            return_col,
                            table_name_10,
                        )
                        logging.info(
                            f"return val is {return_val} return fk name is {return_fk_name}"
                        )
                        update_postgres_data = postgres_data[table_name_20][0]
                        update_postgres_data["id_10"] = return_val
                        update_postgres_id = update_postgres_data["id"]
                        update_postgres_data.pop("id")
                        logging.info(f"update_postgres_data is {update_postgres_data}")
                        self.update_table(
                            postgres_conn1,
                            table_name_20,
                            update_postgres_data,
                            {"id": update_postgres_id},
                        )

                    else:
                        update_value, update_condtion = self.insert_data_to_db(
                            full_from_table,
                            total_insert_dict[table_name_10],
                            mssql_conn,
                            None,
                            table_name_10,
                        )
                        logging.info(
                            f"update value is {update_value} update condition is {update_condtion}"
                        )
                        logging.info(postgres_conn)
                        update_data_20 = postgres_data[table_name_20][0]
                        logging.info(f"update data 20 is {update_data_20}")
                        id_10 = int(update_value["id"])
                        update_data_20["id_10"] = id_10
                        id_20 = int(update_data_20["id"])
                        self.update_table(
                            postgres_conn1, table_name_20, update_data_20, {"id": id_20}
                        )

                # Condition 1: for Single Main table
                elif not return_col and table_name_10 not in fk_cols_10:
                    # Condition: where the table does not return any fk (single tables which does not have any dependent tables)
                    print(f"#### Single Table: {table_name_10}")
                    return_id = self.insert_data_to_db(
                        full_from_table,
                        total_insert_dict[table_name_10],
                        mssql_conn,
                        None,
                        table_name_10,
                    )

                # condition1: for main tables--these only return an fk
                elif return_col and table_name_10 not in fk_cols_10:
                    print(f"##### Main Table: {table_name_10}")
                    logging.info(f"##### Main Table: {table_name_10}")
                    return_id, return_fk_col = self.insert_data_to_db(
                        full_from_table,
                        total_insert_dict[table_name_10],
                        mssql_conn,
                        return_col,
                        table_name_10,
                    )

                    for table_2, tables_1 in tables_dict.items():
                        if table_name_10 in tables_1:
                            break
                    logging.info(f"Mapping tabel in 2.0 is {table_2}")

                    if table_2:
                        update_data_20 = postgres_data[table_2][0]

                        logging.info(f"update data 20 is {update_data_20}")
                        logging.info(
                            f"return_id data after inserting into 1.0 table: {return_id}"
                        )

                        update_data_20_int = update_data_20
                        if update_flag:
                            if "id" in return_id:
                                return_id = return_id["id"]
                        logging.info(f"id received from 1.0 is: {return_id}")
                        update_data_20["id_10"] = int(return_id)

                        if transfer_name == "customer_rate_plan":
                            if "soc_code_id" in update_data_20:
                                update_data_20.pop("soc_code_id")
                            id_20 = int(update_data_20["id"])
                            # if 'automation_rule_id' in  update_data_20:
                            #     update_data_20.pop('automation_rule_id')
                            self.update_table(
                                postgres_conn1, table_2, update_data_20, {"id": id_20}
                            )
                        else:
                            self.update_table(
                                postgres_conn1,
                                table_2,
                                update_data_20,
                                update_data_20_int,
                            )

                    return_ids.append(
                        return_id
                    )  # adding the return col value to main return list
                    if "id" in return_fk_col:
                        return_fk_col = return_fk_col["id"]
                    fk_track_dict[str(return_fk_col)] = (
                        return_id  # adding the return fk_col and return fk col value to an fk_tract_dict
                    )

                # condition2: Tables which have an fk column and also return a col as fk
                elif return_col and table_name_10 in fk_cols_10:

                    print(f"###### {table_name_10} Table has FK and returns col as FK")
                    logging.info(
                        f"###### {table_name_10} Table has FK and returns col as FK"
                    )
                    for (
                        key,
                        val,
                    ) in (
                        fk_track_dict.items()
                    ):  # if any fkey present in fk_track_dict present in fk_cols_dict from db then modify cols
                        modify_col = fk_col_dict.get(
                            key, None
                        )  # get the name of the col that we need to modify(fk_col_name)
                        if modify_col:
                            # print(f"modify col got is {modify_col} new val is {val}")
                            for row_item in data_list:
                                row_item[modify_col] = (
                                    val  # updating the fk_col value in data dict which is to be inserted in db
                                )

                    if transfer_name != "bulk_change_mobility":
                        insert_id, fk_col = self.insert_data_to_db(
                            full_from_table,
                            data_list,
                            mssql_conn,
                            return_col,
                            table_name_10,
                        )
                        fk_track_dict[fk_col] = insert_id
                    else:
                        for row_item in data_list:
                            insert_id, fk_col = self.insert_data_to_db(
                                full_from_table,
                                [row_item],
                                mssql_conn,
                                return_col,
                                table_name_10,
                            )
                            if fk_col not in fk_track_dict:
                                fk_track_dict[fk_col] = []
                            fk_track_dict[fk_col].append(insert_id)

                # condition3: where tables don't return any fk but contain fk col that needs to be updated
                elif (
                    table_name_10 in fk_cols_10
                    and table_name_10 not in return_params_10
                ):
                    print(f"###### {table_name_10} Table has FK")
                    logging.info(f"###### {table_name_10} Table has FK")
                    for key, val in fk_track_dict.items():
                        modify_col = fk_col_dict.get(key, None)
                        if modify_col:
                            if isinstance(fk_track_dict[key], list):
                                for i in range(0, len(data_list)):
                                    data_list[i][modify_col] = val[i]
                            else:
                                for row_item in data_list:
                                    row_item[modify_col] = val

                    insert = self.insert_data_to_db(
                        full_from_table,
                        data_list,
                        mssql_conn,
                        return_col,
                        table_name_10,
                    )
            logging.info(
                f"Data insertion time: {time.time() - insert_start:.4f} seconds"
            )

            if (
                transfer_name == "bulk_change"
                or transfer_name == "bulk_change_mobility"
            ):
                total_time = time.time() - start_time
                logging.info(f"Total execution time: {total_time:.4f} seconds")
                return return_ids[0] if return_ids else None

        except Exception as e:
            logging.error(f"Error while saving 2.0 data in 1.0 : {e}")

    def save_data_to_10_smi(self, transfer_name, postgres_data):
        try:
            # establishing postgres connection
            start_time = time.time()
            if transfer_name == "sim_managment_inventory":
                pg = {}
                data_list = postgres_data["sim_management_inventory"]
                service_provider_id = data_list[0]["service_provider_id"]
                print(f"11111 {service_provider_id}")
                if str(service_provider_id) in ["6", "20"]:
                    transfer_name = "sim_managment_inventory_mobility"
                else:
                    transfer_name = "sim_managment_inventory_m2m"

            logging.info(f"STARTING {transfer_name}")

            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn_start = time.time()
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            # print(f"Postgres connection time: {time.time() - postgres_conn_start:.4f} seconds")
            ##getting all the details for a particular transfer
            query_start = time.time()
            mapping_details_query = f"select table_mapping_10_to_20,col_mapping_10_to_20,return_params_10,fk_cols_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)
            # print(f"Query execution time: {time.time() - query_start:.4f} seconds")

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get("table_mapping_10_to_20", {})
            logging.info("SMI- table", tables_dict)  # 1.0 to 2.0 table mappings dict
            col_mappings = mapping_details.get("col_mapping_10_to_20", {})
            logging.info("SMI@@@@@@@@@@", col_mappings)  # 1.0 to 2.0 column mappings
            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})  # foreign key columns
            db_config = mapping_details.get("db_config", {})  # ssms db config details

            # from_host=db_config['hostname']
            # from_port=db_config['port']
            # from_user=db_config['user']
            # from_pwd=db_config['password']
            # from_db_type=db_config['from_db_type']
            # from_driver=os.getenv('FROM_DB_DRIVER')
            # ssms_db_name=os.getenv('FROM_DB_NAME')

            # get the data to insert dict for ssms according to mappings
            mapping_start = time.time()

            logging.info(f"postgress_data type {type(postgres_data)} {postgres_data}")
            total_insert_dict = self.map_cols(tables_dict, col_mappings, postgres_data)

            # print(f"Data mapping time: {time.time() - mapping_start:.4f} seconds")

            # making mssql_connection

            (
                from_host,
                from_port,
                ssms_db_name,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()
            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn {mssql_conn}")
            # print(f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds")
            logging.info(f"total insert dict {total_insert_dict}")

            return_ids = []

            fk_track_dict = {}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                # if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"

                if return_params_10:
                    print(f"Heree 2111 {return_params_10}")
                    return_col = return_params_10.get(
                        table_name_10, None
                    )  # get the col whose value should be returned for this table
                    fk_col_dict = fk_cols_10.get(
                        table_name_10, {}
                    )  # get the fk_col dict for this table
                else:
                    return_col = None
                    fk_col_dict = None
                # return_col = return_params_10.get(table_name_10,None) #get the col whose value should be returned for this table
                # fk_col_dict = fk_cols_10.get(table_name_10, {}) #get the fk_col dict for this table

                if not return_col:
                    # Condition: where the table does not return any fk (single tables which does not have any dependent tables)
                    logging.info(f"#### Single Table: {table_name_10}")
                    return_id = self.insert_data_to_db(
                        full_from_table,
                        total_insert_dict[table_name_10],
                        mssql_conn,
                        None,
                        table_name_10,
                    )

                # condition1: for main tables--these only return an fk
                elif return_col and table_name_10 not in fk_cols_10:
                    logging.info(f"##### Main Table: {table_name_10}")
                    return_id, return_fk_col = self.insert_data_to_db(
                        full_from_table,
                        total_insert_dict[table_name_10],
                        mssql_conn,
                        return_col,
                        table_name_10,
                    )
                    return_ids.append(
                        return_id
                    )  # adding the return col value to main return list
                    fk_track_dict[return_fk_col] = (
                        return_id  # adding the return fk_col and return fk col value to an fk_tract_dict
                    )

                # condition2: Tables which have an fk column and also return a col as fk
                elif return_col and table_name_10 in fk_cols_10:
                    logging.info(
                        f"###### {table_name_10} Table has FK and returns col as FK"
                    )
                    for (
                        key,
                        val,
                    ) in (
                        fk_track_dict.items()
                    ):  # if any fkey present in fk_track_dict present in fk_cols_dict from db then modify cols
                        modify_col = fk_col_dict.get(
                            key, None
                        )  # get the name of the col that we need to modify(fk_col_name)
                        if modify_col:
                            # print(f"modify col got is {modify_col} new val is {val}")
                            for row_item in data_list:
                                row_item[modify_col] = (
                                    val  # updating the fk_col value in data dict which is to be inserted in db
                                )

                    insert_id, fk_col = self.insert_data_to_db(
                        full_from_table,
                        data_list,
                        mssql_conn,
                        return_col,
                        table_name_10,
                    )
                    fk_track_dict[fk_col] = insert_id

                # condition3: where tables don't return any fk but contain fk col that needs to be updated
                elif (
                    table_name_10 in fk_cols_10
                    and table_name_10 not in return_params_10
                ):
                    logging.info(f"###### {table_name_10} Table has FK")
                    for key, val in fk_track_dict.items():
                        modify_col = fk_col_dict.get(key, None)
                        if modify_col:
                            for row_item in data_list:
                                row_item[modify_col] = val

                    insert = self.insert_data_to_db(
                        full_from_table,
                        data_list,
                        mssql_conn,
                        return_col,
                        table_name_10,
                    )
            logging.info(
                f"Data insertion time: {time.time() - insert_start:.4f} seconds"
            )

            if transfer_name == "bulk_change":
                total_time = time.time() - start_time
                logging.info(f"Total execution time: {total_time:.4f} seconds")
                return return_ids[0] if return_ids else None

        except Exception as e:
            print(f"Error while saving 2.0 data in 1.0 : {e}")

    def get_10_data(
        self,
        transfer_name,
        mssql_conn,
        id_10,
        details_list,
        main_flag=None,
        main_result_dict=None,
    ):
        try:
            dependent_dict = {}
            where_val_list = []
            stop_flag = False
            skip_table = False
            if main_flag:
                main_result_dict = {}
                status_results_dict = {}
                for dict_item in details_list:
                    where_col = dict_item["where_col"]
                    table_10_key = dict_item["table_10"]
                    logging.info(f"@@@@@@@@ table {table_10_key}")
                    select_query = dict_item["select_query"]
                    logging.info(f"Select query is {select_query}")
                    select_query_p = select_query.replace("?", "%s")
                    logging.info(
                        f"select query is {select_query_p} 1.0 id is {id_10}",
                    )
                    logging.info(
                        f"Processing for table {table_10_key} with id_10: {id_10}"
                    )

                    if "?" in select_query.lower() and where_col == "id_10":
                        params = (id_10,)
                        retries = 10  # Maximum retries
                        delay = 5
                        result_df = self.execute_query(
                            mssql_conn, select_query_p, params=params
                        )
                        logging.info(f"get_10_data : Result df is {result_df}")
                        if transfer_name in ["bulk_change", "bulk_change_mobility"]:
                            logging.info(f"get_10_data------------{id_10}")
                            if table_10_key == "DeviceBulkChange":
                                status = result_df.get(
                                    "status", result_df.get("Status", [None])
                                )[
                                    0
                                ]  # Get status safely
                                logging.info(
                                    f"get_10_data:{id_10} table is {table_10_key} abd status got us {status}"
                                )
                                status_results_dict[table_10_key] = [status]
                            else:
                                statuses = result_df.get(
                                    "status", result_df.get("Status", [])
                                )
                                if not isinstance(
                                    statuses, list
                                ):  # Convert to a list if it's a pandas Series
                                    statuses = statuses.tolist()
                                logging.info(
                                    f"get_10_data:::Statuses for {id_10} are {statuses}, type is {type(statuses)}"
                                )
                                status_results_dict[table_10_key] = statuses

                        # Process the result
                        if result_df is not None and not result_df.empty:
                            main_result_dict[table_10_key] = result_df.to_dict(
                                orient="records"
                            )
                        else:
                            logging.error(
                                f"Query failed after retries for {table_10_key}"
                            )

                logging.info(
                    f"get_10_data:::The result statuses are {id_10} ::::{status_results_dict}"
                )
                combined_statuses = [
                    status
                    for statuses in status_results_dict.values()
                    for status in statuses
                ]
                logging.info(
                    f"get_10_data:::: for id 1.0 {id_10} Total statuses are {combined_statuses}"
                )
                if "NEW" in combined_statuses or "PROCESSING" in combined_statuses:
                    keep_trying = True
                else:
                    keep_trying = False

                logging.info(
                    f"Final main result dict got is and flag is {keep_trying} ---------\n:::{main_result_dict}"
                )
                return main_result_dict, keep_trying

            else:
                # print(f"In dependent dict")
                dependent_dict = {}
                where_val_list = []
                result_df = None
                for dict_item in details_list:
                    table_10_key = dict_item["table_10"]
                    logging.info(f"Dependent Table {table_10_key}")
                    where_col = dict_item["where_col"]
                    logging.info(f"Dependent where col {where_col}")
                    if where_col == "id_10":
                        select_query = dict_item["select_query"]
                        # print(f"Before :::Select query is {select_query}")
                        logging.info(
                            f"{table_10_key}--Dependent table but where col is id_10 {id_10}"
                        )
                        select_query_id_1 = select_query.replace("?", "%s")
                        # print(f"select query is {select_query_id_1} 1.0 id is {id_10}", )
                        params = (id_10,)
                        result_df = self.execute_query(
                            mssql_conn, select_query_id_1, params=params
                        )
                        logging.info(f"@##$@#$@#@#@# result {result_df}")

                    else:
                        logging.info(f"In else of dependent dict")
                        select_query = dict_item["select_query"]
                        logging.info(f"Before :::Select query is {select_query}")
                        where_table_name, where_col_name = where_col.split(".")
                        logging.info(f"where {where_table_name,where_col_name}")
                        # where_table_name=where_split[0]
                        # where_col_name=where_split[1]

                        where_vals = [
                            item[where_col_name]
                            for item in main_result_dict.get(where_table_name, [])
                        ]
                        where_val_list.extend(where_vals)
                        logging.info(f"{table_10_key}-where val list {where_val_list}")

                        if where_vals:
                            where_tuple = tuple(where_vals)
                            logging.info(f"where tuple {where_tuple}")
                            if len(where_tuple) == 1:
                                where_tuple_str = str(where_tuple[0])
                                logging.info(
                                    f"where tuple is 1 value {where_tuple_str} type is {type(where_tuple_str)} `('{where_tuple_str}')`"
                                )
                                select_query_p = select_query.replace(
                                    "?", f"('{where_tuple_str}')"
                                )

                            else:
                                # print(f"Tuple len is not 1")
                                # Parameterize query to avoid SQL injection
                                select_query_p = select_query.replace(
                                    "?", str(where_tuple)
                                )
                                logging.info(
                                    f"In else select query is {select_query_p}"
                                )
                            result_df = self.execute_query(mssql_conn, select_query_p)
                            logging.info(f"@##$@#$@#@#@# result {result_df}")

                        else:
                            logging.infos(
                                f"No values found for where clause: {where_col}"
                            )

                    if result_df is not None:
                        result_dict = result_df.to_dict(orient="records")
                        dependent_dict[table_10_key] = result_dict
                    else:
                        dependent_dict[table_10_key] = []
                    # print(f"@@@@@@@@@@@@@@@@ Depedent dict is {dependent_dict}")

        except Exception as e:
            logging.info(f"Error in Bulk Change-Fetching data from 1.0 ---{e}")

        return dependent_dict, where_val_list

    def get_10_data_old(
        self,
        transfer_name,
        mssql_conn,
        id_10,
        details_list,
        main_flag=None,
        main_result_dict=None,
    ):
        try:
            dependent_dict = {}
            where_val_list = []
            stop_flag = False
            skip_table = False
            if main_flag:
                main_result_dict = {}
                for dict_item in details_list:
                    skip_table = False
                    # print(f"Dict item is {dict_item}")
                    where_col = dict_item["where_col"]
                    table_10_key = dict_item["table_10"]
                    logging.info(f"@@@@@@@@ table {table_10_key}")
                    select_query = dict_item["select_query"]
                    logging.info(f"Select query is {select_query}")
                    select_query_p = select_query.replace("?", "%s")
                    logging.info(
                        f"select query is {select_query_p} 1.0 id is {id_10}",
                    )
                    logging.info(
                        f"Processing for table {table_10_key} with id_10: {id_10}"
                    )

                    if "?" in select_query.lower() and where_col == "id_10":
                        # print(f"111111111111111111111")
                        params = (id_10,)
                        retries = 10  # Maximum retries
                        delay = 10  # Delay in seconds between retries
                        for attempt in range(retries):
                            result_df = self.execute_query(
                                mssql_conn, select_query_p, params=params
                            )
                            logging.info(f"#########: Result df is {result_df}")

                            # Handle specific statuses for bulk change transfers
                            if transfer_name in ["bulk_change", "bulk_change_mobility"]:
                                logging.info(
                                    f"#####################################################"
                                )
                                if table_10_key == "DeviceBulkChange":
                                    status = result_df.get(
                                        "status", result_df.get("Status", [None])
                                    )[
                                        0
                                    ]  # Get status safely
                                    logging.info(
                                        f"11111111111111111 table is {table_10_key} abd status got us {status}"
                                    )
                                else:
                                    statuses = result_df.get(
                                        "status", result_df.get("Status", [])
                                    )
                                    logging.info(f"Statuses are {statuses}")

                                if table_10_key == "DeviceBulkChange":
                                    if status in ["NEW"]:
                                        keep_trying = True
                                        logging.info(
                                            f"Skipping table {table_10_key} as it is not ready yet..."
                                        )
                                        break
                                    elif status == "PROCESSING":
                                        keep_trying = True
                                        logging.info(
                                            f"Keep trying flag is {keep_trying}"
                                        )
                                    else:
                                        keep_trying = False
                                        logging.info(
                                            f"Keep trying flag is {keep_trying}"
                                        )
                                    break
                                else:
                                    logging.info(f"Multiple Statses are {statuses}")
                                    # Check if any of the statuses is 'NEW'
                                    if "NEW" in statuses:
                                        keep_trying = True
                                        logging.info(
                                            f"Status is NEW in one or more rows, keeping keep_trying as {keep_trying}"
                                        )
                                        break
                                    else:
                                        keep_trying = False
                                        logging.info(
                                            f"No 'NEW' status found, proceeding with the sync. Keep trying flag is {keep_trying}"
                                        )
                                        break

                            # Exit if valid result is obtained
                            if result_df is not None and not result_df.empty:
                                break

                            logging.info(
                                f"Attempt {attempt + 1}/{retries}: Query returned no results, retrying after {delay} seconds..."
                            )
                            # time.sleep(delay)

                        # Fetch data regardless of status if retries are exhausted
                        if result_df is None or result_df.empty:
                            logging.info(
                                f"Exhausted retries. Fetching data regardless of status (id: {id_10})..."
                            )
                            result_df = self.execute_query(
                                mssql_conn, select_query_p, params=params
                            )

                        # Process the result
                        if result_df is not None and not result_df.empty:
                            main_result_dict[table_10_key] = result_df.to_dict(
                                orient="records"
                            )
                        else:
                            logging.error(
                                f"Query failed after retries for {table_10_key}"
                            )

                        # print(f"Final main result dict got is {main_result_dict}")

                return main_result_dict, keep_trying
            else:
                # print(f"In dependent dict")
                dependent_dict = {}
                where_val_list = []
                result_df = None
                for dict_item in details_list:
                    table_10_key = dict_item["table_10"]
                    logging.info(f"Dependent Table {table_10_key}")
                    where_col = dict_item["where_col"]
                    logging.info(f"Dependent where col {where_col}")
                    if where_col == "id_10":
                        select_query = dict_item["select_query"]
                        # print(f"Before :::Select query is {select_query}")
                        logging.info(
                            f"{table_10_key}--Dependent table but where col is id_10 {id_10}"
                        )
                        select_query_id_1 = select_query.replace("?", "%s")
                        # print(f"select query is {select_query_id_1} 1.0 id is {id_10}", )
                        params = (id_10,)
                        result_df = self.execute_query(
                            mssql_conn, select_query_id_1, params=params
                        )
                        logging.info(f"@##$@#$@#@#@# result {result_df}")

                    else:
                        logging.info(f"In else of dependent dict")
                        select_query = dict_item["select_query"]
                        logging.info(f"Before :::Select query is {select_query}")
                        where_table_name, where_col_name = where_col.split(".")
                        logging.info(f"where {where_table_name,where_col_name}")
                        # where_table_name=where_split[0]
                        # where_col_name=where_split[1]

                        where_vals = [
                            item[where_col_name]
                            for item in main_result_dict.get(where_table_name, [])
                        ]
                        where_val_list.extend(where_vals)
                        logging.info(f"{table_10_key}-where val list {where_val_list}")

                        if where_vals:
                            where_tuple = tuple(where_vals)
                            logging.info(f"where tuple {where_tuple}")
                            if len(where_tuple) == 1:
                                where_tuple_str = str(where_tuple[0])
                                logging.info(
                                    f"where tuple is 1 value {where_tuple_str} type is {type(where_tuple_str)} `('{where_tuple_str}')`"
                                )
                                select_query_p = select_query.replace(
                                    "?", f"('{where_tuple_str}')"
                                )

                            else:
                                # print(f"Tuple len is not 1")
                                # Parameterize query to avoid SQL injection
                                select_query_p = select_query.replace(
                                    "?", str(where_tuple)
                                )
                                logging.info(
                                    f"In else select query is {select_query_p}"
                                )
                            result_df = self.execute_query(mssql_conn, select_query_p)
                            logging.info(f"@##$@#$@#@#@# result {result_df}")

                        else:
                            logging.infos(
                                f"No values found for where clause: {where_col}"
                            )

                    if result_df is not None:
                        result_dict = result_df.to_dict(orient="records")
                        dependent_dict[table_10_key] = result_dict
                    else:
                        dependent_dict[table_10_key] = []
                    # print(f"@@@@@@@@@@@@@@@@ Depedent dict is {dependent_dict}")

        except Exception as e:
            logging.info(f"Error in Bulk Change-Fetching data from 1.0 ---{e}")

        return dependent_dict, where_val_list

    def main_save_data_t0_20(
        self,
        main_insert_data,
        main_cond_dict,
        main_multiple_col_conditions,
        id_20,
        postgres_conn,
        dependent_insert_data,
        dependent_cond_dict,
    ):
        try:
            logging.info(f"PostgresConn{postgres_conn}")
            if main_insert_data:
                for table_name_20, data_list in main_insert_data.items():
                    logging.info(
                        f"Data to be updated in table {table_name_20} is {data_list}"
                    )
                    if data_list:
                        if table_name_20 in main_cond_dict.keys():
                            where_20_col = main_cond_dict[table_name_20]
                            for record_dict in data_list:
                                logging.info(f"record_dict is {record_dict}")
                                update = self.update_table(
                                    postgres_conn,
                                    table_name_20,
                                    record_dict,
                                    {where_20_col: id_20},
                                )

                        elif table_name_20 in main_multiple_col_conditions.keys():
                            logging.info(f"in elif condiion table_name {table_name_20}")
                            where_20_col = main_multiple_col_conditions[table_name_20]
                            split_where_cols = where_20_col.split(",")
                            where_col_0 = split_where_cols[0]
                            where_col_rest = split_where_cols[1:]
                            for record_dict in data_list:
                                # Build the where_dict using a dictionary comprehension
                                where_dict = {where_col_0: id_20}
                                where_dict.update(
                                    {
                                        col: record_dict[col]
                                        for col in where_col_rest
                                        if col in record_dict
                                    }
                                )
                                logging.info(f"Where dict is {where_dict}")
                                logging.info(f"where cond dict {where_dict}")
                                logging.info(f"record_dict passed is {record_dict}")
                                # Execute the update
                                update = self.update_table(
                                    postgres_conn,
                                    table_name_20,
                                    record_dict,
                                    where_dict,
                                )

                    else:
                        raise ValueError("No records obtained to insert in 2.0")
                return True
            elif dependent_insert_data:
                for table_name_20, data_list in dependent_insert_data.items():
                    print(f"Table name 20 is {table_name_20}")
                    print(f"Data list is {data_list}")
                    if not data_list:
                        print("No Data to Insert, skipping to next iteration")
                        continue

                    where_20_col = dependent_cond_dict.get(table_name_20)
                    print(f"where 20 col is {where_20_col}")
                    if not where_20_col:
                        print("Where condition column not found")
                        continue

                    for record_dict in data_list:

                        if where_20_col == "bulk_change_id":
                            where_val = id_20
                            record_dict["bulk_change_id"] = where_val
                            if table_name_20 == "sim_management_bulk_change_log":
                                # print(f"Here 111 sim_management_bulk_change_log ----{record_dict}")
                                try:
                                    ii = self.insert_data_to_postgres(
                                        table_name_20,
                                        [record_dict],
                                        postgres_conn,
                                        None,
                                    )
                                except Exception as e:
                                    print(f"Error in log is {e}")

                        else:
                            if table_name_20 == "sim_management_inventory":
                                cursor = postgres_conn.cursor()
                                iccid = record_dict["iccid"]
                                sql_query = f"select * from {table_name_20} where iccid='{iccid}'"
                                cursor.execute(sql_query)
                                result = cursor.fetchall()
                                print(f"result is {result}")
                                if result:
                                    where_val = record_dict.get(where_20_col)

                                    print(f"where val is {where_val}")
                                    if where_val is not None:
                                        # Prepare the update where conditions
                                        where_dict = {where_20_col: where_val}
                                        print(f"where dict is {where_dict}")
                                        print(f"record dict is {record_dict}")
                                        # Execute the update
                                        self.update_table(
                                            postgres_conn,
                                            table_name_20,
                                            record_dict,
                                            where_dict,
                                        )
                                else:
                                    # print(f"Here 111 sim_management_bulk_change_log ----{record_dict}")
                                    try:
                                        ii = self.insert_data_to_postgres(
                                            table_name_20,
                                            [record_dict],
                                            postgres_conn,
                                            None,
                                        )
                                    except Exception as e:
                                        print(f"Error in log is {e}")
                            else:
                                where_val = record_dict.get(where_20_col)

                                print(f"where val is {where_val}")
                                if where_val is not None:
                                    # Prepare the update where conditions
                                    where_dict = {where_20_col: where_val}
                                    print(f"where dict is {where_dict}")
                                    print(f"record dict is {record_dict}")
                                    # Execute the update
                                    self.update_table(
                                        postgres_conn,
                                        table_name_20,
                                        record_dict,
                                        where_dict,
                                    )
                return True
        except Exception as e:
            logging.info(f"Error in main_save_data_t0_20: {e}")

    def save_data_20_from_10(
        self, id_10, id_20, transfer_name, postgres_data
    ):  # commenting this to implement ticket 2266 on 08-01-2025
        try:
            if transfer_name == "bulk_change":
                data_list = postgres_data["sim_management_bulk_change"]
                service_provider_id = data_list[0]["service_provider_id"]
                print(f"11111 {service_provider_id}")
                if str(service_provider_id) in ["6", "20"]:
                    transfer_name = "bulk_change_mobility"
                else:
                    transfer_name = "bulk_change"

            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            # getting details from db
            mapping_details_query = f"select db_name_20,db_config,reverse_table_mapping,reverse_col_mapping,data_from_10,update_cond_cols from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn1, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            table_info_dict = mapping_details["data_from_10"]
            update_cond_20 = mapping_details["update_cond_cols"]

            (
                from_host,
                from_port,
                from_db,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                from_db,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )

            main_details_list = table_info_dict[
                "main"
            ]  # get info list from db which helps in getting data from 10

            # print(f"Main dict {main_result_dict}")

            db_name_20 = mapping_details["db_name_20"]
            logging.info(f"DB Name is {db_name_20}")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name_20, user, password, port
            )
            logging.info(f"Postgres Conn {postgres_conn}")
            main_cond_dict = update_cond_20[
                "main"
            ]  # get the dict from db whic contains condition params
            main_multiple_col_conditions = update_cond_20["main_multi_col"]
            dependent_cond_dict = update_cond_20["dependent"]

            reverse_tables = mapping_details["reverse_table_mapping"]
            reverse_col_mappings = mapping_details["reverse_col_mapping"]
            dependent_info_list = table_info_dict[
                "dependent"
            ]  # get info list from db which helps in getting data from 10

            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            db_name = "altaworx_test"
            print(f"conn variables {hostname,port,user,password,db_type,db_name}")
            postgres_conn_a = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            main_result_dict, keep_trying_flag = self.get_10_data(
                transfer_name, mssql_conn, id_10, main_details_list, main_flag=True
            )
            logging.info(
                f"1.0 data obtained::: id_10 {id_10} and 2.0 id is {id_20} flag is {keep_trying_flag}"
            )
            logging.info(
                f"Data dict obtained from 1.0 for main tables: \n {main_result_dict}"
            )

            while keep_trying_flag == True:
                logging.info(
                    f"Keep Trying flag is {keep_trying_flag} id_10 {id_10} and 2.0 id is {id_20} "
                )
                main_insert_data = self.map_cols(
                    reverse_tables, reverse_col_mappings, main_result_dict
                )
                insert_main_dict = self.main_save_data_t0_20(
                    main_insert_data,
                    update_cond_20["main"],
                    update_cond_20["main_multi_col"],
                    id_20,
                    postgres_conn,
                    {},
                    update_cond_20["dependent"],
                )

                main_result_dict, keep_trying_flag = self.get_10_data(
                    transfer_name, mssql_conn, id_10, main_details_list, main_flag=True
                )
                print(f"Keep trying flag is {keep_trying_flag}")

            logging.info(
                f"Keep trying flag is {keep_trying_flag} and id_10 {id_10} and 2.0 id is {id_20} doing a final update"
            )
            main_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, main_result_dict
            )
            insert_main_dict = self.main_save_data_t0_20(
                main_insert_data,
                update_cond_20["main"],
                update_cond_20["main_multi_col"],
                id_20,
                postgres_conn,
                {},
                update_cond_20["dependent"],
            )

            logging.info(
                f"Keep Trying flag {keep_trying_flag},id_10 {id_10} and 2.0 id is {id_20} Updating Dependent tables"
            )
            dependent_dict, where_val_list = self.get_10_data(
                transfer_name,
                mssql_conn,
                id_10,
                dependent_info_list,
                main_flag=False,
                main_result_dict=main_result_dict,
            )
            # print(f"Data dict obtained from 1.0 for dependent tables: \n {dependent_dict} \n {where_val_list}")
            dependent_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, dependent_dict
            )
            logging.info(f"Dependent_dict is {dependent_insert_data}")
            insert_dependent_data = self.main_save_data_t0_20(
                {},
                main_cond_dict,
                main_multiple_col_conditions,
                id_20,
                postgres_conn,
                dependent_insert_data,
                dependent_cond_dict,
            )

            return True

        except Exception as e:

            logging.error(
                f"Error while fetching data from 1.0 and saving it int 2.0 : {e}"
            )
            return False

    def save_data_20_from_10_old(
        self, id_10, id_20, transfer_name, postgres_data
    ):  # commenting this to implement ticket 2266 on 08-01-2025
        try:
            if transfer_name == "bulk_change":
                data_list = postgres_data["sim_management_bulk_change"]
                service_provider_id = data_list[0]["service_provider_id"]
                print(f"11111 {service_provider_id}")
                if str(service_provider_id) in ["6", "20"]:
                    transfer_name = "bulk_change_mobility"
                else:
                    transfer_name = "bulk_change"

            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            # getting details from db
            mapping_details_query = f"select db_name_20,db_config,reverse_table_mapping,reverse_col_mapping,data_from_10,update_cond_cols from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn1, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            table_info_dict = mapping_details["data_from_10"]
            update_cond_20 = mapping_details["update_cond_cols"]

            (
                from_host,
                from_port,
                from_db,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                from_db,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )

            main_details_list = table_info_dict[
                "main"
            ]  # get info list from db which helps in getting data from 10

            main_result_dict = self.get_10_data(
                transfer_name, mssql_conn, id_10, main_details_list, main_flag=True
            )
            logging.info(
                f"Data dict obtained from 1.0 for main tables: \n {main_result_dict}"
            )

            # print(f"Main dict {main_result_dict}")

            dependent_info_list = table_info_dict[
                "dependent"
            ]  # get info list from db which helps in getting data from 10
            dependent_dict, where_val_list = self.get_10_data(
                transfer_name,
                mssql_conn,
                id_10,
                dependent_info_list,
                main_flag=False,
                main_result_dict=main_result_dict,
            )
            logging.info(
                f"Data dict obtained from 1.0 for dependent tables: \n {dependent_dict} \n {where_val_list}"
            )
            # print(f"Depedent data {dependent_dict} \n {where_val_list}")

            reverse_tables = mapping_details["reverse_table_mapping"]
            reverse_col_mappings = mapping_details["reverse_col_mapping"]

            main_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, main_result_dict
            )
            db_name_20 = mapping_details["db_name_20"]
            # print(f"############# Main insert_data {main_insert_data}")

            postgres_conn = self.create_connection(
                db_type, hostname, db_name_20, user, password, port
            )

            main_cond_dict = update_cond_20[
                "main"
            ]  # get the dict from db whic contains condition params
            main_multiple_col_conditions = update_cond_20["main_multi_col"]
            dependent_cond_dict = update_cond_20["dependent"]

            for table_name_20, data_list in main_insert_data.items():
                logging.info(
                    f"Data to be updated in table {table_name_20} is {data_list}"
                )
                if data_list:
                    if table_name_20 in main_cond_dict.keys():
                        where_20_col = main_cond_dict[table_name_20]
                        for record_dict in data_list:
                            print(f"record_dict is {record_dict}")
                            update = self.update_table(
                                postgres_conn,
                                table_name_20,
                                record_dict,
                                {where_20_col: id_20},
                            )

                    elif table_name_20 in main_multiple_col_conditions.keys():
                        # logging.info(f"in elif condiion table_name {table_name_20}")
                        where_20_col = main_multiple_col_conditions[table_name_20]
                        split_where_cols = where_20_col.split(",")
                        where_col_0 = split_where_cols[0]
                        where_col_rest = split_where_cols[1:]

                        for record_dict in data_list:
                            # Build the where_dict using a dictionary comprehension
                            where_dict = {where_col_0: id_20}
                            where_dict.update(
                                {
                                    col: record_dict[col]
                                    for col in where_col_rest
                                    if col in record_dict
                                }
                            )
                            # print(f"where cond dict {where_dict}")
                            # print(f"record_dict passed is {record_dict}")
                            # Execute the update
                            update = self.update_table(
                                postgres_conn, table_name_20, record_dict, where_dict
                            )

                else:
                    raise ValueError("No records obtained to insert in 2.0")

            dependent_insert_data = self.map_cols(
                reverse_tables, reverse_col_mappings, dependent_dict
            )
            print(f"Dependent_dict is {dependent_insert_data}")

            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            db_name = os.getenv("MAIN_DB")
            print(f"conn variables {hostname,port,user,password,db_type,db_name}")
            postgres_conn_a = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            for table_name_20, data_list in dependent_insert_data.items():
                if not data_list:
                    logging.warning("No Data to Insert")
                    continue

                where_20_col = dependent_cond_dict.get(table_name_20)
                if not where_20_col:
                    logging.info("Where condition column not found")
                    continue

                for record_dict in data_list:
                    if where_20_col == "bulk_change_id":
                        where_val = id_20
                        record_dict["bulk_change_id"] = where_val
                        if table_name_20 == "sim_management_bulk_change_log":
                            try:
                                self.insert_data_to_postgres(
                                    table_name_20, [record_dict], postgres_conn_a, None
                                )
                            except Exception as e:
                                logging.error(
                                    f"Error in inserting log data-{table_name_20} {e}"
                                )
                    else:
                        where_val = record_dict.get(where_20_col)
                    # where_val = record_dict.get(where_20_col)
                    if where_val is not None:
                        # Prepare the update where conditions
                        where_dict = {where_20_col: where_val}
                        # Execute the update
                        self.update_table(
                            postgres_conn, table_name_20, record_dict, where_dict
                        )

            return True

        except Exception as e:

            logging.error(
                f"Error while fetching data from 1.0 and saving it int 2.0 : {e}"
            )
            return False

    def insert_data_to_postgres(self, table_name, data_list, pg_conn, return_col=None):
        """
        Inserts data into a PostgreSQL table using cursor.execute for each row.

        Args:
            table_name (str): The name of the PostgreSQL table.
            data_list (list of dict): List of dictionaries, each representing a row to be inserted.
            pg_conn (psycopg2 connection): Active PostgreSQL connection.
            return_col (str, optional): The column to return after insertion. Defaults to None.

        Returns:
            tuple: If `return_col` is provided, returns (last_return_value, return_column_name).
                Otherwise, returns None.
        """
        try:
            if not pg_conn:
                raise ValueError("Invalid PostgreSQL connection")

            if not data_list:
                raise ValueError("Data list is empty")

            cursor = pg_conn.cursor()

            # Extract column names
            columns = ", ".join(data_list[0].keys())
            placeholders = ", ".join(
                [f"%({col})s" for col in data_list[0].keys()]
            )  # Named placeholders

            # Construct the SQL query
            if return_col:
                sql_query = f"""
                    INSERT INTO {table_name} ({columns})
                    VALUES ({placeholders})
                    RETURNING {return_col};
                """
            else:
                sql_query = f"""
                    INSERT INTO {table_name} ({columns})
                    VALUES ({placeholders});
                """

            try:
                return_val = None
                return_fk_name = None

                # Execute the query for each row
                for row in data_list:
                    # Prepare the row, convert non-serializable objects to JSON strings
                    formatted_row = {
                        col: (json.dumps(val) if isinstance(val, (dict, list)) else val)
                        for col, val in row.items()
                    }
                    logging.info(f"formatted row is {formatted_row}")
                    cursor.execute(sql_query, formatted_row)

                    # Fetch the returned column value if requested
                    if return_col:
                        return_val = cursor.fetchone()[0]
                        return_fk_name = f"{table_name}.{return_col}"

                # Commit the transaction
                pg_conn.commit()
                logging.info("Insert Successful")

                if return_col:
                    return return_val, return_fk_name

            except Exception as e:
                print(f"Failed to insert rows into {table_name}: {e}")
                pg_conn.rollback()
                return None

            finally:
                cursor.close()

        except Exception as e:
            logging.error(f"Error while inserting rows into {table_name}: {e}")
            return None

    def delete_from_pgsql_(self, mssql_conn, id_10, table_name_10):
        try:
            logging.info(f"conn is {mssql_conn}")
            cursor = mssql_conn.cursor()
            delete_query = f"DELETE FROM {table_name_10} WHERE id={id_10}"
            cursor.execute(delete_query)
            mssql_conn.commit()
            print(f"Deleted from 1.0")
        except Exception as e:
            logging.error(f"Error while deleting from 1.0: {e}")

    def is_valid_table_name(self, table_name):
        pattern = r"^\[\w+\]\.\[\w+\]\.\[\w+\]$"
        return re.match(pattern, table_name) is not None

    # def delete_data_from_10(self,transfer_name,postgres_data,id_10,table_name_10):
    #     try:
    #         from_host,from_port,ssms_db_name,from_user,from_pwd,from_db_type,from_driver=self.load_env_mssql()
    #         # mssql_conn_start = time.time()
    #         mssql_conn=self.create_connection(from_db_type,from_host,ssms_db_name,from_user,from_pwd,from_port,from_driver)
    #         if not self.is_valid_table_name(table_name_10):
    #             full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
    #             logging.info(f"full table name {full_from_table}")
    #         else:
    #             full_from_table = table_name_10
    #         dd=self.delete_from_pgsql(mssql_conn,id_10,full_from_table)
    #     except Exception as e:
    #         logging.error(f"Error while loading env: {e}")
    """
    def save_data_to_10_single_table(self,transfer_name,postgres_data,update_flag=False,delete_flag=False):
        try:
            logging.info(f"STARTING {transfer_name}")
            load_dotenv()
            hostname,port,user,password,db_type,db_name=self.load_env_pgsql()
            logging.info(f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}")
            mapping_table=os.getenv('MAPPING_TABLE')
            postgres_conn = self.create_connection(db_type, hostname, db_name, user, password, port)
            mapping_details_query=f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details=self.execute_query(postgres_conn,mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError("No Mappings present for transfer") #raising error if unable to get required data from db

            mapping_details=mapping_details.to_dict(orient='records')[0]
            tables_dict = mapping_details.get('table_mapping_10_to_20', {})
            db_name_20=mapping_details.get('db_name_20',{})
            logging.info(f"db_name_20 is {db_name_20}")
            logging.info(f"type(tables_dict)----------{type(tables_dict)}")  # 1.0 to 2.0 table mappings dict
            col_mappings = mapping_details.get('col_mapping_10_to_20', {})
            print(type(col_mappings))   # 1.0 to 2.0 column mappings
            return_params_10 = mapping_details.get('return_params_10', {})    # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get('fk_cols_10', {})                # foreign key columns
            db_config=mapping_details.get('db_config',{}) #ssms db config details
            table_name_20=mapping_details.get('table_mapping_10_to_20').keys()
            table_name_20 = ', '.join(str(key) for key in table_name_20)
            logging.info(f"table_name_20 is {table_name_20}")
            table_name_10=tables_dict[table_name_20][0]
            logging.info(f"Table Name 1.0 is {table_name_10}")
            # update_flag=True
            hostname = os.getenv('LOCAL_DB_HOST')
            port = os.getenv('LOCAL_DB_PORT')
            db_name=db_name_20
            user = os.getenv('LOCAL_DB_USER')
            password = os.getenv('LOCAL_DB_PASSWORD')
            db_type = os.getenv('LOCAL_DB_TYPE')
            from_driver=os.getenv('LOCAL_DB_DRIVER')
            postgres_conn1 = self.create_connection(db_type, hostname, db_name, user, password, port)

            postgres_data_copy=copy.deepcopy(postgres_data)


            if update_flag is True and delete_flag is False:
                update_data=postgres_data_copy[table_name_20][0]
                id_20=update_data['id']
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query=f"select id_10 from {table_name_20} where id='{id_20}'"
                result=self.execute_query(postgres_conn1,id_10_query)
                id_10=result['id_10'][0]
                logging.info(f"id_10 is {id_10}")
                update_data['id_10']=id_10
                postgres_data_20={table_name_20:[update_data]}
                total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data_20)
            else:
                logging.info(f"tables_dict {tables_dict}")
                total_insert_dict=self.map_cols(tables_dict,col_mappings,postgres_data)
            logging.info(f"total insert dict is {total_insert_dict}")

            from_host,from_port,ssms_db_name,from_user,from_pwd,from_db_type,from_driver=self.load_env_mssql()
            mssql_conn_start = time.time()
            mssql_conn=self.create_connection(from_db_type,from_host,ssms_db_name,from_user,from_pwd,from_port,from_driver)
            if delete_flag is True and update_flag is False:
                update_data=postgres_data_copy[table_name_20][0]
                id_20=update_data['id']
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query=f"select id_10 from {table_name_20} where id='{id_20}'"
                result=self.execute_query(postgres_conn1,id_10_query)
                id_10=result['id_10'][0]
                update_data['id_10']=id_10
                logging.info(f"id_10 is {id_10}")
                # delete_data=self.delete_data_from_10(transfer_name,postgres_data,id_10,table_name_10)
                query = f"update {table_name_10} set IsDeleted=1,IsActive=0 where id='{id_10}'"
                result=self.execute_query(mssql_conn,query)
                return True
            logging.info(f"mssql_conn {mssql_conn}")
            logging.info(f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds")
            logging.info(f"total insert dict {total_insert_dict}")

            return_ids=[]
            fk_track_dict={}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                #if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table=f'[{ssms_db_name}].[dbo].[{table_name_10}]'

                if return_params_10:
                    logging.info(f"Heree 2111 {return_params_10}")
                    return_col = return_params_10.get(table_name_10,None) #get the col whose value should be returned for this table
                    fk_col_dict = fk_cols_10.get(table_name_10, {}) #get the fk_col dict for this table
                else:
                    return_col=None
                    fk_col_dict=None


                if not return_col and not fk_col_dict:
                    logging.info("This part is to handle update tables don't have any foreign key columnc")
                    if update_flag is False:
                        return_col='ID'
                        return_val, return_fk_name=self.insert_data_to_db(full_from_table,total_insert_dict[table_name_10],mssql_conn,return_col,table_name_10)
                        logging.info(f"return val is {return_val} return fk name is {return_fk_name}")
                        update_postgres_data=postgres_data[table_name_20][0]
                        update_postgres_data['id_10']=return_val
                        update_postgres_id=update_postgres_data['id']
                        update_postgres_data.pop('id')
                        logging.info(f"update_postgres_data is {update_postgres_data}")
                        self.update_table(postgres_conn1,table_name_20,update_postgres_data,{'id':update_postgres_id})

                    else:
                        update_value,update_condtion=self.insert_data_to_db(full_from_table,total_insert_dict[table_name_10],mssql_conn,None,table_name_10)
                        logging.info(f"update value is {update_value} update condition is {update_condtion}")
                        logging.info(postgres_conn)
                        update_data_20=postgres_data[table_name_20][0]
                        logging.info(f"update data 20 is {update_data_20}")
                        id_10=int(update_value['id'])
                        update_data_20['id_10']=id_10
                        id_20=int(update_data_20['id'])
                        self.update_table(postgres_conn1,table_name_20,update_data_20,{'id':id_20})

        except Exception as e:
            logging.error(f"Error in carrier_rate_plan")

    """

    def insert_automation_rule_table_data(self, transfer_name, data_dict):
        load_dotenv()
        hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
        logging.info(f"DB Conn details {hostname,port,user,password,db_type,db_name}")
        postgres_conn1 = self.create_connection(
            db_type, hostname, db_name, user, password, port
        )
        mapping_table = os.getenv("MAPPING_TABLE")

        mapping_details_query = f"select table_mapping_10_to_20,col_mapping_10_to_20,return_params_10,fk_cols_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
        # print(f"query {mapping_details_query}")
        mapping_details = self.execute_query(postgres_conn1, mapping_details_query)
        # print(f"mapping_details {mapping_details}")
        mapping_details = mapping_details.to_dict(orient="records")[0]

        tables_dict = mapping_details.get("table_mapping_10_to_20", {})
        # print(f"Tables dict is {tables_dict}")  # 1.0 to 2.0 table mappings dict
        col_mappings = mapping_details.get("col_mapping_10_to_20", {})
        # print(f"col_mappings are {col_mappings}")   # 1.0 to 2.0 column mappings
        return_params_10 = mapping_details.get("return_params_10", {})
        # print(f"return params {return_params_10}")   # cols data that we need to return from 1.0
        fk_cols_10 = mapping_details.get("fk_cols_10", {})
        # print(f"fk cols 10 are {fk_cols_10}")            # foreign key columns
        db_config = mapping_details.get("db_config", {})

        (
            from_host,
            from_port,
            ssms_db_name,
            from_user,
            from_pwd,
            from_db_type,
            from_driver,
        ) = self.load_env_mssql()
        mssql_conn = self.create_connection(
            from_db_type,
            from_host,
            ssms_db_name,
            from_user,
            from_pwd,
            from_port,
            from_driver,
        )

        fk_values_dict = {}
        data_dict_total = data_dict["automation_data"]

        for key, value in data_dict_total.items():
            if key in tables_dict.keys():
                table_name_10 = tables_dict.get(key)
                for table_name in table_name_10:
                    # print(f"info {return_params_10}")
                    return_fk_col = return_params_10.get(table_name)
                    main_pgsql_dict = {key: [value]}
                    # print(f"main {main_pgsql_dict}")
                    data_10_mapping_dict = self.map_cols(
                        tables_dict, col_mappings, main_pgsql_dict
                    )
                    # print(f"data_10_mapping_dict {data_10_mapping_dict}")
                    for table_name_100, value_list in data_10_mapping_dict.items():
                        return_fk_col_val, fk_col_name = self.insert_data_to_db(
                            table_name_100,
                            value_list,
                            mssql_conn,
                            return_fk_col,
                            table_name_100,
                        )
                        fk_values_dict[fk_col_name] = return_fk_col_val
                # print(f"fk_values_dict {fk_values_dict}")
            else:
                if isinstance(value, list):
                    for item in value:
                        print(f"item {item}")

                        data_dict_item = self.ensure_values_are_lists(item)
                        data_mapping_dict = self.map_cols(
                            tables_dict, col_mappings, data_dict_item
                        )
                        # print(f"data mapping dict {data_mapping_dict}")
                        for table_name_10, data_list in data_mapping_dict.items():
                            # print(f"table and lists are {table_name_10},{data_list}")
                            if not data_list or data_list == [{}]:
                                # print(f"should skip {table_name_10}")
                                continue
                            fk_col_ = return_params_10.get(table_name_10)
                            if fk_col_:
                                # print('ifffff',table_name_10)
                                # print(f"daata {data_list}")
                                # print(f"fk cols is {fk_col_}")
                                automation_rule_followup_id, fk_col = (
                                    self.insert_data_to_db(
                                        table_name_10,
                                        data_list,
                                        mssql_conn,
                                        fk_col_,
                                        table_name_10,
                                    )
                                )
                                # print(f"id :{automation_rule_followup_id}, fk_col: {fk_col}")
                                fk_values_dict[fk_col] = automation_rule_followup_id
                            else:
                                fk_col_ = None
                                # print(f"111111111111111: In else:::table name {table_name_10}")
                                if table_name_10 in fk_cols_10.keys():
                                    # print(f"fks for this table {fk_cols_10[table_name_10]}")
                                    fk_cols_tables = fk_cols_10[table_name_10]
                                    reversed_fk_dict = {
                                        value: key
                                        for key, value in fk_cols_tables.items()
                                    }
                                    fk_col_names = [
                                        value
                                        for value in fk_cols_10[table_name_10].values()
                                    ]
                                    # print('############',fk_col_names)
                                    # print('@@@@@@@@@@@@@@@',fk_values_dict)
                                    # print(f"data list before {data_list}")
                                    for item in data_list:
                                        for key_col, data_val in item.items():
                                            # print(f"key {key_col},{data_val}")
                                            if key_col in fk_col_names:
                                                modified_fk_value = fk_values_dict.get(
                                                    reversed_fk_dict.get(key_col, None),
                                                    None,
                                                )
                                                # if modified_fk_value:
                                                item[key_col] = modified_fk_value
                                    # print(f"table name {table_name_10}, data {data_list}")

                                    insert = self.insert_data_to_db(
                                        table_name_10,
                                        data_list,
                                        mssql_conn,
                                        fk_col_,
                                        table_name_10,
                                    )

    def update_data_to_10_db(self, table_name, data_list, mssql_conn):
        try:
            logging.info("trying to insert a row using merge query")

            if not mssql_conn:
                raise ValueError("Invalid MSSQL connection")

            if not data_list:
                raise ValueError("Data list is empty")
            for row in data_list:
                cursor = mssql_conn.cursor()
                logging.info("entered into update part")
                logging.info(row.items())
                # column_names = ', '.join([key for key in row.keys() if key != 'Id'])
                # column_values = ', '.join([f"'{row[key]}'" for key in row.keys() if key != 'Id'])
                values_section = None
                for key in row.keys():
                    if row[key] is None:
                        if values_section:
                            values_section = values_section + ", " + f"{'NULL'}"
                        else:
                            values_section = f"{'NULL'}"
                    else:
                        if values_section:
                            values_section = values_section + ", " + f"'{row[key]}'"
                        else:
                            values_section = f"'{row[key]}'"

                source_columns = ", ".join([key for key in row.keys()])
                logging.info(values_section)
                logging.info(source_columns)

                source_columns = ", ".join([key for key in row.keys()])
                id_value = row["id"]

                # print("*******************", column_names, column_values)

                matched_update = ", ".join(
                    [
                        f"target.{key} = source.{key}"
                        for key in row.keys()
                        if key != "id"
                    ]
                )

                insert_columns = ", ".join([key for key in row.keys() if key != "id"])
                insert_values = ", ".join(
                    [f"source.{key}" for key in row.keys() if key != "id"]
                )
                logging.info("*******************", insert_columns, insert_values)

                # Construct the SQL MERGE query
                sql_merge_query = f"""
                    MERGE INTO {table_name} AS target
                    USING (VALUES ({values_section})) AS source ({source_columns})
                    ON target.id = source.id
                    WHEN MATCHED THEN
                    UPDATE SET {matched_update}
                    WHEN NOT MATCHED BY TARGET THEN
                    INSERT ({insert_columns}) VALUES ({insert_values})
                    OUTPUT INSERTED.id;
                    """
                logging.info(f"Merge Query {sql_merge_query}")

                cursor.execute(sql_merge_query)
                inserted_ids = cursor.fetchall()
                # inserted_ids=30
                if inserted_ids:

                    newly_inserted_id = inserted_ids[0][0]
                    logging.info(f"Newly inserted Id: {newly_inserted_id}")
                    logging.info(f"Newly inserted Id: {inserted_ids}")
                    mssql_conn.commit()
                    logging.info(
                        "merge query*******************************", sql_merge_query
                    )
                    # return newly_inserted_id
                    return {"id": newly_inserted_id}, {"id": id_value}

            cursor = mssql_conn.cursor()

        except Exception as e:
            logging.info(f"Error while inserting row into {table_name}: {e}")

    def save_data_to_10_single_table_db_config(
        self, transfer_name, postgres_data, update_flag=False, delete_flag=False
    ):
        try:
            logging.info(f"STARTING {transfer_name}")
            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            logging.info(
                f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}"
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_details_query = f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_config,db_name_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get("table_mapping_10_to_20", {})
            db_name_20 = mapping_details.get("db_name_20", {})
            db_name_10 = mapping_details.get("db_name_10", {})
            mssql_config = mapping_details.get("db_config")
            logging.info(f"db_name_20 is {db_name_20}")
            logging.info("mssql configurations", mssql_config)

            logging.info(
                f"type(tables_dict)----------{type(tables_dict)}"
            )  # 1.0 to 2.0 table mappings dict
            col_mappings = mapping_details.get("col_mapping_10_to_20", {})
            logging.info(type(col_mappings))  # 1.0 to 2.0 column mappings
            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})  # foreign key columns
            db_config = mapping_details.get("db_config", {})  # ssms db config details
            table_name_20 = mapping_details.get("table_mapping_10_to_20").keys()
            table_name_20 = ", ".join(str(key) for key in table_name_20)
            logging.info(f"table_name_20 is {table_name_20}")
            table_name_10 = tables_dict[table_name_20][0]
            logging.info(f"Table Name 1.0 is {table_name_10}")
            # update_flag=True
            hostname = os.getenv("LOCAL_DB_HOST")
            port = os.getenv("LOCAL_DB_PORT")
            db_name = db_name_20
            user = os.getenv("LOCAL_DB_USER")
            password = os.getenv("LOCAL_DB_PASSWORD")
            db_type = os.getenv("LOCAL_DB_TYPE")
            from_driver = os.getenv("LOCAL_DB_DRIVER")
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            postgres_data_copy = copy.deepcopy(postgres_data)
            logging.info("upadte_flag", update_flag, "delete_flag", delete_flag)

            if update_flag is True and delete_flag is False:
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                logging.info(f"id_10 is {id_10}")
                update_data["id_10"] = id_10
                postgres_data_20 = {table_name_20: [update_data]}
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data_20
                )
            elif update_flag is False and delete_flag is True:
                logging.info("Delete flag is false ")
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                logging.info(f"id_10 is {id_10}")
                update_data["id_10"] = id_10
                postgres_data_20 = {table_name_20: [update_data]}
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data_20
                )
            else:
                logging.info("delete and update flags are false")
                logging.info(f"tables_dict {tables_dict}")
                logging.info(f"postgress_data", postgres_data)
                logging.info(f"mapping_cols", col_mappings)
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data
                )
            logging.info(total_insert_dict)
            if not mssql_config:
                (
                    from_host,
                    from_port,
                    ssms_db_name,
                    from_user,
                    from_pwd,
                    from_db_type,
                    from_driver,
                ) = self.load_env_mssql()
            else:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            logging.info(ssms_db_name)
            logging.info(from_host)
            logging.info(from_driver)

            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn {mssql_conn}")
            logging.info(
                f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds"
            )
            logging.info(f"total insert dict {total_insert_dict}")

            return_ids = []
            fk_track_dict = {}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                # if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                logging.info(full_from_table)

                if return_params_10:
                    logging.info(f"Heree 2111 {return_params_10}")
                    return_col = return_params_10.get(
                        table_name_10, None
                    )  # get the col whose value should be returned for this table
                    fk_col_dict = fk_cols_10.get(
                        table_name_10, {}
                    )  # get the fk_col dict for this table
                else:
                    return_col = None
                    fk_col_dict = None

                if not return_col and not fk_col_dict:
                    logging.info(
                        "This part is to handle update tables don't have any foreign key columnc"
                    )

                    if update_flag is False and delete_flag is False:
                        logging.info(
                            "This part is used to insert records when update_flag and delete flag are false"
                        )
                        return_col = "ID"
                        return_val, return_fk_name = self.insert_data_to_db(
                            full_from_table,
                            total_insert_dict[table_name_10],
                            mssql_conn,
                            return_col,
                            table_name_10,
                        )
                        logging.info(
                            f"return val is {return_val} return fk name is {return_fk_name}"
                        )

                        update_postgres_data = postgres_data[table_name_20][0]
                        update_postgres_data["id_10"] = return_val
                        update_postgres_id = update_postgres_data["id"]
                        update_postgres_data.pop("id")
                        logging.info(f"update_postgres_data is {update_postgres_data}")
                        self.update_table(
                            postgres_conn1,
                            table_name_20,
                            update_postgres_data,
                            {"id": update_postgres_id},
                        )

                    else:
                        logging.info("update_flag is true ")
                        logging.info("full form table", full_from_table)
                        logging.info("table_name_10")
                        logging.info(total_insert_dict[table_name_10])
                        self.update_data_to_10_db(
                            full_from_table,
                            total_insert_dict[table_name_10],
                            mssql_conn,
                        )

        except Exception as e:
            logging.info(f"Error in save_data_to_10_single_table_ {e}")

    def update_data_to_10_db_mssql_for_users(
        self, table_name, data_list, mssql_conn, conflict_col
    ):
        try:
            logging.info("trying to insert a row using merge query")

            if not mssql_conn:
                raise ValueError("Invalid MSSQL connection")

            if not data_list:
                raise ValueError("Data list is empty")
            if not conflict_col:
                raise ValueError("Conflict columns list is empty.")
            cursor = mssql_conn.cursor()

            source_columns = ", ".join([key for key in data_list.keys()])
            values_section = None
            for key in data_list.keys():
                if data_list[key] is None:
                    if values_section:
                        values_section = values_section + ", " + f"{'NULL'}"
                    else:
                        values_section = f"{'NULL'}"
                else:
                    if values_section:
                        values_section = values_section + ", " + f"'{data_list[key]}'"
                    else:
                        values_section = f"'{data_list[key]}'"
            matched_update = ", ".join(
                [
                    f"target.{key} = source.{key}"
                    for key in data_list.keys()
                    if key not in conflict_col
                ]
            )
            insert_columns = ", ".join([key for key in data_list.keys() if key != "id"])
            insert_values = ", ".join(
                [f"source.{key}" for key in data_list.keys() if key != "id"]
            )
            logging.info("ented into update part **************************")

            logging.info("conflict_col", conflict_col)
            on_condition = " AND ".join(
                [f"target.{col} = source.{col}" for col in conflict_col]
            )
            sql_merge_query = f"""
                    MERGE INTO {table_name} AS target
                    USING (VALUES ({values_section})) AS source ({source_columns})
                    ON  {on_condition}
                    WHEN MATCHED THEN
                    UPDATE SET {matched_update}
                    WHEN NOT MATCHED BY TARGET THEN
                    INSERT ({insert_columns}) VALUES ({insert_values})
                    OUTPUT INSERTED.id;
                    """
            logging.info(sql_merge_query)
            try:
                cursor.execute(sql_merge_query)
                mssql_conn.commit()  # Commit the transaction
                logging.info(f"Merge query executed successfully {table_name}")
            except Exception as e:
                mssql_conn.rollback()  # Rollback in case of an error
                logging.info(f"Error executing query: {e}", table_name)

            return None

        except Exception as e:
            logging.info(f"An error occurred: {e}")
            raise

        except Exception as e:
            logging.info(f" an error occured in updating {e}")

    def function_to_get_role_id(self, mssq_conn, table_name, column_name, value):
        try:
            sql_query = f"SELECT id FROM {table_name} WHERE {column_name} = %s"
            logging.info(sql_query)
            cursor = mssq_conn.cursor()
            cursor.execute(sql_query, (value,))
            result = cursor.fetchone()

            if result:
                # If the result exists, return the id
                logging.info("role id is ", result[0])
                return result[0]

            else:
                # If no result is found, return None or a custom value
                return None

        except Exception as e:
            logging.info(f"Error: {e}")
            return None

    def insert_user_to_mssql_for_users(
        self, mssql_conn, table, mssql_dict, return_col=None
    ):
        """
        Insert user data dynamically into an MSSQL table.

        Args:
            mssql_conn (pyodbc.Connection): The MSSQL connection.
            table (str): The name of the table to insert data into.
            mssql_dict (dict): Dictionary containing column names as keys and their values.
        """
        cursor = mssql_conn.cursor()
        if not mssql_dict or not table:
            raise ValueError("Table name and data dictionary cannot be empty.")
        columns = ", ".join(mssql_dict.keys())
        placeholders = ", ".join(["%s"] * len(mssql_dict))
        if return_col:
            sql_query = f"INSERT INTO {table} ({columns}) OUTPUT INSERTED.{return_col} VALUES ({placeholders})"
        else:
            sql_query = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
        values = tuple(
            (
                mssql_dict[col]
                if isinstance(mssql_dict[col], (str, int, float, bool))
                else json.dumps(
                    mssql_dict[col].item()
                    if isinstance(mssql_dict[col], (np.integer, np.floating))
                    else mssql_dict[col]
                )
            )
            for col in mssql_dict.keys()
        )
        try:
            logging.info(f"Executing SQL Query: {sql_query}")
            logging.info(f"Values: {values}")
            cursor.execute(sql_query, values)
            if return_col:
                inserted_value = cursor.fetchone()[0]
                mssql_conn.commit()  # Commit the transaction
                logging.info(
                    f"Inserted record with {return_col}: {inserted_value}", table
                )
                return inserted_value
            else:
                mssql_conn.commit()
                logging.info(
                    "Record inserted successfully without returning a column.", table
                )
                return None
        except Exception as e:
            logging.info(f"Error while inserting record into {table}: {e}")
            mssql_conn.rollback()  # Rollback in case of error
            return None
        finally:
            cursor.close()

    def save_data_to_10_single_table_users(
        self, transfer_name, postgres_data, update_flag=False, delete_flag=False
    ):
        try:
            logging.info(f"STARTING {transfer_name}")
            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            logging.info(
                f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}"
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_details_query = f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10,db_config,db_name_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get("table_mapping_10_to_20", {})
            db_name_20 = mapping_details.get("db_name_20", {})
            db_name_10 = mapping_details.get("db_name_10", {})
            mssql_config = mapping_details.get("db_config")
            col_mappings_10_to_20 = mapping_details.get("col_mapping_10_to_20", {})
            data_container = key_name = list(tables_dict.keys())[0]
            postgres_copy = copy.deepcopy(postgres_data)
            hostname = os.getenv("LOCAL_DB_HOST")
            port = os.getenv("LOCAL_DB_PORT")
            db_name = db_name_20
            user = os.getenv("LOCAL_DB_USER")
            password = os.getenv("LOCAL_DB_PASSWORD")
            db_type = os.getenv("LOCAL_DB_TYPE")
            from_driver = os.getenv("LOCAL_DB_DRIVER")
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            if not mssql_config:
                (
                    from_host,
                    from_port,
                    ssms_db_name,
                    from_user,
                    from_pwd,
                    from_db_type,
                    from_driver,
                ) = self.load_env_mssql()
            else:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")

            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn {mssql_conn}")
            logging.info(
                f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds"
            )
            data_dict = postgres_data[data_container][0]
            role_value = data_dict.get("role", {})
            role_id = self.function_to_get_role_id(
                mssql_conn, "role", "Name", role_value
            )
            data_dict["role_id"] = role_id
            id_20 = postgres_data[data_container][0].get("id", {})

            for table in tables_dict[data_container]:

                table_columns = col_mappings_10_to_20.get(table, {})
                mssql_dict = {}
                for postgres_col, mssql_col in table_columns.items():
                    if postgres_col in data_dict:
                        mssql_dict[mssql_col] = data_dict[postgres_col]

                full_from_table = f"[{ssms_db_name}].[dbo].[{table}]"
                logging.info(
                    "MSSQL Data:", mssql_dict, " MSSQL Table Name", full_from_table
                )

                if table == "user" and update_flag is False and delete_flag is False:
                    table_name_20 = "users"
                    logging.info("this part is only for users")
                    logging.info(full_from_table)
                    logging.info(mssql_dict)
                    return_val = self.insert_user_to_mssql_for_users(
                        mssql_conn, full_from_table, mssql_dict, return_col="ID"
                    )
                    logging.info(f"return val is {return_val} return fk name is")
                    data_dict["user_id"] = return_val
                    update_postgres_data = {}
                    update_postgres_data["id"] = return_val
                    update_postgres_id = id_20
                    logging.info(
                        f"update_postgres_data is {update_postgres_data}",
                        update_postgres_id,
                    )
                    self.update_table(
                        postgres_conn1,
                        table_name_20,
                        update_postgres_data,
                        {"id": update_postgres_id},
                    )

                elif update_flag is False and delete_flag is False:
                    self.insert_user_to_mssql_for_users(
                        mssql_conn, full_from_table, mssql_dict, return_col=None
                    )
                if update_flag is True and delete_flag is False:
                    if table == "user":

                        mssql_dict["id"] = data_dict.get("id", {})

                        logging.info("to handle parts", table)
                        logging.info("printing data dict", mssql_dict)
                        self.update_data_to_10_db_mssql_for_users(
                            full_from_table, mssql_dict, mssql_conn, conflict_col=["id"]
                        )
                    elif table == "user_role_site":
                        mssql_dict["userid"] = data_dict.get("id", {})
                        conflict_col = ["userid", "tenantid"]
                        logging.info(conflict_col, table)
                        self.update_data_to_10_db_mssql_for_users(
                            full_from_table, mssql_dict, mssql_conn, conflict_col
                        )
                    else:
                        mssql_dict["userid"] = data_dict.get("id", {})
                        conflict_col = ["userid"]
                        self.update_data_to_10_db_mssql_for_users(
                            full_from_table, mssql_dict, mssql_conn, conflict_col
                        )

            return True

        except Exception as e:
            logging.info(f"Error in carrier_rate_plan {e}")

    def saving_revio_push_customer_charge_type(self, data_dict):
        try:
            logging.info(f"Input data dict is {data_dict}")
            load_dotenv()
            multi_tenant_host = os.getenv("BASE_MULTI_TENANT_HOST")
            port = os.getenv("FROM_DB_PORT")
            user = os.getenv("FROM_DB_USER")
            password = os.getenv("FROM_DB_PASSWORD")
            db_type = os.getenv("FROM_DB_TYPE")
            db_name = os.getenv("BASE_MULTI_TENANT_DB")
            driver = os.getenv("FROM_DB_DRIVER")
            multi_tenant_conn = self.create_connection(
                db_type, multi_tenant_host, db_name, user, password, port, driver
            )
            logging.info(f"multi tenant connn is {multi_tenant_conn}")
            update_value = data_dict["Rev.IO Push Customer Charge Type"]
            logging.info(f"update_value is {update_value}")
            try:
                update_query = """
                    UPDATE CustomObject
                    SET CustomName = %s
                    WHERE ObjectId = 32 AND TenantId = 1;
                """
                cursor = multi_tenant_conn.cursor()
                # Use parameterized queries to prevent SQL injection
                cursor.execute(update_query, (update_value,))

                # Commit the transaction
                multi_tenant_conn.commit()
                logging.info(f"Update Sucessful")
            except Exception as e:
                # Rollback in case of an error
                multi_tenant_conn.rollback()
                logging.error(f"Error occurred while executing the query: {e}")
            finally:
                # Close the cursor and connection
                cursor.close()
                multi_tenant_conn.close()
        except Exception as e:
            logging.error(
                f"Error occurred while saving_revio_push_customer_charge_type {e}"
            )

    def replace_bool_strings(self, data):
        # Check if the current item is a dictionary
        if isinstance(data, dict):
            return {
                key: self.replace_bool_strings(value) for key, value in data.items()
            }
        # Check if the current item is a list
        elif isinstance(data, list):
            return [self.replace_bool_strings(item) for item in data]
        # Replace string 'True'/'False' with boolean True/False
        elif data == "True":
            return True
        elif data == "False":
            return False
        # Return the item as is if no replacement is needed
        else:
            return data

    def update_optimization_seetings(self, data_sent, table_name, mssql_conn):
        try:
            logging.info("entered this part")
            logging.info(f"data_sent {data_sent}")
            extract_values = list(data_sent["optimizationsetting"][0].keys())
            logging.info(f"extract_values are {extract_values}")
            if "Rev.IO Push Customer Charge Type" in extract_values:
                logging.info(f"Need to re route hereeeeee")
                data_sent_copy = copy.deepcopy(data_sent)
                rev_data_setting = {
                    key: value
                    for key, value in data_sent_copy["optimizationsetting"][0].items()
                    if key == "Rev.IO Push Customer Charge Type"
                }
                ss = self.saving_revio_push_customer_charge_type(rev_data_setting)
            filtered_keys = [
                key
                for key in extract_values
                if key
                not in [
                    "modifiedBy",
                    "modifiedDate",
                    "deletedBy",
                    "isDeleted",
                    "canOverride",
                    "Rev.IO Push Customer Charge Type",
                ]
            ]
            logging.info(f"Filtered Keys: {filtered_keys}")
            filtered_values = [
                data_sent["optimizationsetting"][0][key] for key in filtered_keys
            ]
            logging.info(f"Filtered Values: {filtered_values}")
            modified_by = data_sent["optimizationsetting"][0].get(
                "modifiedBy", "default_user"
            )
            modified_date = "CURRENT_TIMESTAMP"
            set_clause = f"modifiedBy = '{modified_by}', modifiedDate = {modified_date}, settingvalue = CASE"
            for key, value in zip(filtered_keys, filtered_values):
                set_clause += f" WHEN settingkey = '{key}' THEN '{value}'"
            set_clause += " END"
            logging.info(f"SET Clause: {set_clause}")
            where_clause = " OR ".join(
                [f"settingkey = '{key}'" for key in filtered_keys]
            )
            logging.info(f"WHERE Clause: {where_clause}")
            update_query = f"UPDATE {table_name} SET {set_clause} WHERE {where_clause};"
            logging.info(f"Generated Update Query:{update_query}")
            with mssql_conn.cursor() as cursor:
                try:
                    cursor.execute(update_query)
                    mssql_conn.commit()  # Commit the changes if successful
                    logging.info("Update successful!")
                except Exception as query_error:
                    logging.error(f"Error during query execution: {query_error}")
                    mssql_conn.rollback()  # Rollback in case of error during query execution
                    logging.error(f"Rollback executed due to query error.{query_error}")
            return None
        except Exception as e:
            logging.error(f"an error occured while update {e}")

    def optimization_setting_function(
        self, transfer_name, postgres_data, update_flag, delete_flag
    ):
        try:
            logging.info(f"STARTING {transfer_name}")
            load_dotenv()
            hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
            logging.info(
                f"hostname {hostname} port {port} user {user} password {password} db_type {db_type} db_name {db_name}"
            )
            mapping_table = os.getenv("MAPPING_TABLE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            mapping_details_query = f"select table_mapping_10_to_20,db_name_20,col_mapping_10_to_20,return_params_10,fk_cols_10 from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            tables_dict = mapping_details.get("table_mapping_10_to_20", {})
            db_name_20 = mapping_details.get("db_name_20", {})
            logging.info(f"db_name_20 is {db_name_20}")
            logging.info(
                f"type(tables_dict)----------{type(tables_dict)}"
            )  # 1.0 to 2.0 table mappings dict

            col_mappings = mapping_details.get("col_mapping_10_to_20", {})
            logging.info(type(col_mappings))  # 1.0 to 2.0 column mappings
            logging.info(col_mappings)

            return_params_10 = mapping_details.get(
                "return_params_10", {}
            )  # cols data that we need to return from 1.0
            fk_cols_10 = mapping_details.get("fk_cols_10", {})  # foreign key columns
            db_config = mapping_details.get("db_config", {})  # ssms db config details
            table_name_20 = mapping_details.get("table_mapping_10_to_20").keys()
            table_name_20 = ", ".join(str(key) for key in table_name_20)
            logging.info(f"table_name_20 is {table_name_20}")
            table_name_10 = tables_dict[table_name_20][0]
            logging.info(f"Table Name 1.0 is {table_name_10}")
            # update_flag=True
            hostname = os.getenv("LOCAL_DB_HOST")
            port = os.getenv("LOCAL_DB_PORT")
            db_name = db_name_20
            user = os.getenv("LOCAL_DB_USER")
            password = os.getenv("LOCAL_DB_PASSWORD")
            db_type = os.getenv("LOCAL_DB_TYPE")
            from_driver = os.getenv("LOCAL_DB_DRIVER")
            postgres_conn1 = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(update_flag)

            postgres_data_copy = copy.deepcopy(postgres_data)
            if delete_flag is True and update_flag is False:
                update_data = postgres_data_copy[table_name_20][0]
                id_20 = update_data["id"]
                logging.info(f"id_20 is for table {table_name_20} is {id_20}")
                id_10_query = f"select id_10 from {table_name_20} where id='{id_20}'"
                result = self.execute_query(postgres_conn1, id_10_query)
                id_10 = result["id_10"][0]
                update_data["id_10"] = id_10
                logging.info(f"id_10 is {id_10}")
                delete_data = self.delete_data_from_10(
                    transfer_name, postgres_data, id_10, table_name_10
                )
                return True

            elif update_flag is True and delete_flag is False:
                logging.info("update flag is true-------------------------")
                logging.info(f"postgress data {postgres_data}")
                logging.info(f"col mappings {col_mappings}")
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data
                )
                logging.info(f"@@@@@@@@@@@@@total_insert_dict {total_insert_dict}")
                updated_data = total_insert_dict.get("optimizationsetting")[0]
                (
                    from_host,
                    from_port,
                    ssms_db_name,
                    from_user,
                    from_pwd,
                    from_db_type,
                    from_driver,
                ) = self.load_env_mssql()
                mssql_conn_start = time.time()
                mssql_conn = self.create_connection(
                    from_db_type,
                    from_host,
                    ssms_db_name,
                    from_user,
                    from_pwd,
                    from_port,
                    from_driver,
                )
                logging.info(f"mssql_conn {mssql_conn}")
                logging.info(
                    f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds"
                )
                logging.info(f"total insert dict {total_insert_dict}")
                total_insert_data_ = self.replace_bool_strings(total_insert_dict)
                logging.info(f"total insert data {total_insert_data_}")

                for table_name_10, data_list in total_insert_dict.items():
                    # if the table name in not mssql format -- modifying it
                    if not self.is_valid_table_name(table_name_10):
                        full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"
                logging.info(full_from_table)

                self.update_optimization_seetings(
                    total_insert_data_, full_from_table, mssql_conn
                )
                return None
            else:
                logging.info(f"tables_dict {tables_dict}")
                logging.info(f"col mappings ,{col_mappings}")
                # logging.info(postgres_data)
                total_insert_dict = self.map_cols(
                    tables_dict, col_mappings, postgres_data
                )
            logging.info(f"total insert dict is {total_insert_dict}")

            (
                from_host,
                from_port,
                ssms_db_name,
                from_user,
                from_pwd,
                from_db_type,
                from_driver,
            ) = self.load_env_mssql()
            mssql_conn_start = time.time()
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"mssql_conn {mssql_conn}")
            logging.info(
                f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds"
            )
            logging.info(f"total insert dict {total_insert_dict}")

            return_ids = []
            fk_track_dict = {}

            insert_start = time.time()
            for table_name_10, data_list in total_insert_dict.items():
                # if the table name in not mssql format -- modifying it
                if not self.is_valid_table_name(table_name_10):
                    full_from_table = f"[{ssms_db_name}].[dbo].[{table_name_10}]"

        except Exception as e:
            logging.info(f"Error in {transfer_name} ,{e}")
        return None


# if __name__ == "__main__":
#     scheduler = DataTransfer()
#     postgres_data={"sim_management_bulk_change":[{"service_provider_id":1,"tenant_id":1,"device_status_id":1,"status":"NEW","change_request_type_id":1,"processed_by":"vyshnavi","created_by":"vtest"}],"sim_management_bulk_change_request":[{"bulk_change_id":20,"iccid":56789098764,"status":"NEW","change_request":"{\"UpdateStatus\":\"Activated\",\"IsIgnoreCurrentStatus\":false,\"PostUpdateStatusId\":4,\"Request\":{},\"IntegrationAuthenticationId\":0}"},{"bulk_change_id":20,"iccid":1223454556,"status":"NEW","change_request":"{\"UpdateStatus\":\"Activated\",\"IsIgnoreCurrentStatus\":false,\"PostUpdateStatusId\":4,\"Request\":{},\"IntegrationAuthenticationId\":0}"}]}

#     transfer_name='bulk_change'
#     # bc_id=scheduler.save_data_10(transfer_name,postgres_data)
#     # print(f"bd _id is {bc_id}")

#     bulk_change_id=2700 #data present in 10
#     id_20=7560

#     scheduler.save_data_20_from_10(bulk_change_id,id_20,transfer_name)
