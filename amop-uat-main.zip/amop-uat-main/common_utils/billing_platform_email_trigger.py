"""
Module for sending emails using SendGrid.
This module provides a function to send emails using the SendGrid API.

@Author1 : Phaneendra.Y
@Author2 : Burhan

Created Date: June 06, 2024
"""

import re
import os
import base64
import time
import json
import pandas as pd
import psutil
import boto3
import datetime
from sendgrid import SendGridAPIClient
# from sendgrid.exceptions import SendGridException
from sendgrid.helpers.mail import (
    Mail,
    Content,
    Attachment,
    FileContent,
    FileName,
    FileType,
    Disposition
)
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
# Dictionary to store database configuration settings retrieved from environment variables.
db_config = {
    'host': os.environ['HOST'],
    'port': os.environ['PORT'],
    'user': os.environ['USER'],
    'password': os.environ['PASSWORD']
}
logging = Logging(name="email_trigger")



sns = boto3.client('sns')
cloudwatch = boto3.client('cloudwatch')

def send_sns_email(subject, message):
    """Send an email via SNS when memory are breached."""
    response = sns.publish(
        # TopicArn='arn:aws:sns:us-east-1:008971638399:custom-alert',
        TopicArn=os.environ['ALERT'],
        Message=message,
        Subject=subject)
    return response

def get_memory_usage():
    """Get the current memory usage in MB."""
    process = psutil.Process()
    memory_info = process.memory_info()
    logging.info(memory_info.rss / (1024 * 1024))
    return memory_info.rss / (1024 * 1024)

def memory_sns(memory_limit,memory_used,context):
    if memory_used > 0.8 * memory_limit:
        subject = 'Lambda Memory Usage Alert'
        message = f"Warning: Memory usage has exceeded allocated limit.\n\nDetails:\nMemory Used: {memory_used} MB\nMemory Limit: {memory_limit} MB\nFunction: {context.function_name}\nRequest ID: {context.aws_request_id}"
        template_name="lambda ram exceeded"
        request_received_at=datetime.now()
        send_sns_email(subject, message)
        insert_email_audit( subject,message, request_received_at, template_name)
        logging.info("###mail sent")
        #subject, message, template_name, request_received_at = result


def insert_email_audit(subject, message, template_name, to_emails, comments, partner_name, from_email, email_type,customer_name,account_number):
    """
    Inserts a record into the `email_audit` table for tracking email-related activities.

    Parameters:
        subject (str): Subject of the email.
        message (str): Body/content of the email.
        template_name (str): Name of the email template used.
        to_emails (str): Recipient email addresses (comma-separated if multiple).
        comments (str): Additional comments or context regarding the email.
        partner_name (str): Name of the associated partner or client.
        from_email (str): Sender's email address.
        email_type (str): Type or category of the email (e.g., alert, notification).
        customer_name (str): Name of the customer associated with the email.
        account_number (str): Account number linked to the customer.

    This function connects to the `common_utils` database, constructs an audit entry,
    and inserts it into the `email_audit` table using the `update_audit` method.
    """
    
    # Initialize database connection to the 'common_utils' schema
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    
    try:
        # Construct the email audit data dictionary
        email_audit_data = {
            "template_name": template_name,
            "email_type": email_type,
            "partner_name": partner_name,
            "email_status": "success",  # Default status is 'success'
            "from_email": from_email,
            "to_email": to_emails,
            "comments": comments,
            "subject": subject,
            "body": message,
            "role": "admin",  # Hardcoded role; can be made dynamic if needed
            "action": comments,  # Duplicate of 'comments'; could be renamed or separated
            "customer_name": customer_name,
            "account_number": account_number
        }

        # Insert the audit record into the email_audit table
        common_utils_database.update_audit(email_audit_data, 'email_audit')

        # Log success
        logging.info("Data inserted into email_audit table successfully.")

    except Exception as e:
        # Log any error encountered during insertion
        logging.info(f"Error inserting email audit data: {e}")

def replace_placeholders_with_values(
    text, record_id="", template_type="", username="", data_dict=None, database="",placeholder_value=None
):
    """
    Replace placeholders with actual values from the database and include tabular data based on date range.
 
    :param text: The text containing placeholders and table details in the list format.
    :param record_id: The id to use as the WHERE condition.
 
    :return: Text with placeholders replaced by actual values.
    """
 
    # Find all placeholders using regex, matches patterns like {"table":"column"}
    # placeholders = re.findall(r'\{"(.*?)":"(.*?)"\}', text)
    placeholders = re.findall(r'\{(.*?)\}', text)
    logging.info(f'placeholders--------{placeholders}')
    logging.info(f'placeholder_value--------{placeholder_value}')
    for item in placeholders:
        logging.info(f'item--------{item}')
        placeholder = f"""{{{item}}}"""
        logging.info(f'placeholder--------{placeholder}')
        text = text.replace(placeholder, str(placeholder_value[item]))
        logging.info(f'text--------{text}')
        if item  not in placeholder_value:
            text = text.replace(f"""{{{item}}}""", '')
    return text

def create_attachment_from_blob(blob_data, filename):
    """
    Create an attachment from blob data.

    Args:
        blob_data (bytes): Binary data of the file to attach.
        filename (str): The name of the file being attached.

    Returns:
        Attachment: The SendGrid attachment object.
    """
    encoded_file = base64.b64encode(blob_data).decode()  # Encode blob data to base64

    return Attachment(
        FileContent(encoded_file),
        FileName(filename),  # Provide the filename for the attachment
        FileType('application/octet-stream'),  # Adjust MIME type if necessary
        Disposition('attachment')  # Marks it as an attachment
    )

def prepare_email_message(from_email, to_emails, **kwargs):
    """
    Prepare the email message object.

    Args:
        from_email (str): The sender's email address.
        to_emails (list): List of recipient email addresses.
        subject (str): Email subject.
        content (str): Email content.
        cc_emails (list): List of CC email addresses.
        is_html (bool): Whether the content is HTML or plain text.

    Returns:
        Mail: The SendGrid Mail object.
    """
    subject = kwargs.get('subject')
    content = kwargs.get('content')
    cc_emails = kwargs.get('cc_emails')
    is_html = kwargs.get('is_html')

    message = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=subject
    )
    message.add_content(Content("text/html" if is_html else "text/plain", content))
    for cc_email in cc_emails:
        message.add_cc(cc_email)
    return message

def send_email(template_name, **kwargs):
    logging.info(f"### send_email function called")
    """
    Send an email using SendGrid with retry logic.

    Args:
        template_name (str): Name of the email template.
        content (str): Email content.
        is_html (bool): Whether the content is HTML or plain text.

    Returns:
        bool: True if the email was sent successfully, False otherwise.
    """
    max_retries = 3  # Set the number of retries
    retry_delay = 5  # Delay between retries in seconds

    is_html = kwargs.get("is_html", True)
    record_id = kwargs.get("id", "")
    username = kwargs.get("username", "")
    user_mail = kwargs.get("user_mail", "")
    data_dict = kwargs.get("data_dict", None)
    placeholder_value = kwargs.get("placeholder_value", None)
    logging.info(f'placeholder_value - {placeholder_value}')
    subject_placeholders = kwargs.get("subject_placeholders", None)
    logging.info(f'subject_placeholders - {subject_placeholders}')
    comments = kwargs.get("comments", "")
    #to_email = kwargs.get("to_email", "")
    customer_name = kwargs.get("customer_name", "")
    account_number = kwargs.get("account_number", "")
    # tenant_database = kwargs.get("tenant_database", 'altaworx_test')
    try:
        database = DB(os.environ["dbname"], **db_config)
    except:
        database = DB(os.environ["dbname"], **db_config)


    #common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    common_utils_database = DB('common_utils', **db_config)
    # Retrieve template data
    template_data_dataframe = common_utils_database.get_data(
        "email_templates", {"template_name": template_name}
    )
    email_status = template_data_dataframe.iloc[0]["email_status"]
    if email_status == False:
        response = {"flag": True, "message": "the email template status is disabled"}
        return response
    # Extract data from the template
    cc_emails = template_data_dataframe.iloc[0]["cc_mail"] or []
    partner_name = template_data_dataframe.iloc[0]["partner_name"] or ""
    template_type = template_data_dataframe.iloc[0]["template_type"] or ""
    role_based = template_data_dataframe.iloc[0]["role_based"]
    email_type = template_data_dataframe.iloc[0]["email_type"] or ""
    if role_based:
        # Fetch data from the database where tenant_name is the partner and role is the specified role
        email_dataframe = common_utils_database.get_data(
            "users",
            {"tenant_name": partner_name, "role": role_based, "is_active": True},
            ["email"],
        )
        # Extract the 'email' column and convert it to a list (if it's not already)
        email_list = email_dataframe["email"].tolist()
        # Join the list into a comma-separated string (if needed)
        to_emails = ",".join(email_list)
    else:
        if template_name == "Forgot password":
            to_emails = user_mail
        else:
            to_emails = template_data_dataframe.iloc[0]["to_mail"] or []
    if not to_emails:
        to_emails = kwargs.get("to_email", "")
    common_utils_database = DB('common_utils', **db_config)
    email_credientials = common_utils_database.get_data(
                "tenant",
                {"tenant_name": 'Altaworx', "is_active": True},
                ["from_email","sendgrid_api"],
            )
    sendgrid_email = email_credientials.iloc[0]["from_email"]
    sendgrid_api_key = email_credientials.iloc[0]["sendgrid_api"]
    subject = (
        template_data_dataframe.iloc[0]["subject"]
        or kwargs.get("subject", "")
        or "Default Subject"
    )
    # attachments = template_data_dataframe.iloc[0]['attachments'] or []  #this contains blob data
    body = template_data_dataframe.iloc[0]["body"] or kwargs.get("body", "") or ""
    body = body.replace("\n", "<br>")
    attachments = kwargs.get("attachments", None)
    try:
        body = replace_placeholders_with_values(
            text=body,
            record_id=record_id,
            template_type=template_type,
            username=username,
            data_dict=data_dict,
            database=database,
            placeholder_value = placeholder_value
        )
    except Exception as e:
        logging.info("send_email fucntion Error: 'Issue with the Body replacing the placeholders.'")

    # Add the external user warning at the bottom in red
    external_warning = (
        '<br><br><p style="color: red;">This message is from an external user. Be cautious when opening attachment files or links.</p>'
    )
    body += external_warning  # Append the warning at the bottom

    # Handle missing 'to_emails' or 'subject'
    if not to_emails:
        logging.info("send_email fucntion Error: 'to_emails' is missing.")
        return False

    if not subject:
        logging.info("send_email function Error: 'subject' is missing.")
        return False
    
    subject=replace_placeholders_with_values(
        text=subject,
        placeholder_value=subject_placeholders
    )

    # Prepare email content
    from_email = str(sendgrid_email)
    # from_email = "notifications@amop.services"  # Verified email for SendGrid
    logging.info(f"send_email : from_email--------{from_email}")
    logging.info(f"send_email : to_emails--------{to_emails}")
    logging.info(f"send_email : subject--------{subject}")
    logging.info(f"send_email : body--------{body}")
    logging.info(f"send_email : cc_emails--------{cc_emails}")
    logging.info(f"send_email : email_type--------{email_type}")
    message = prepare_email_message(
        from_email=from_email,
        to_emails=to_emails.split(","),  # Handle multiple emails as a list
        subject=subject,
        content=body,
        cc_emails=cc_emails.split(",") if cc_emails else [],
        is_html=is_html,
    )
    # ##adding the attachments
    if isinstance(attachments, list):
        for attachment in attachments:

            if isinstance(attachment, dict) and 'blob_data' in attachment and 'filename' in attachment:
                blob_data = attachment['blob_data']
                filename = attachment['filename']

                if blob_data and filename:
                    try:
                        # Create and add the attachment
                        attachment_part = create_attachment_from_blob(blob_data, filename)
                        message.add_attachment(attachment_part)
                    except Exception as e:
                        logging.info(f"send_email : Error adding attachment {filename}: {e}")
                        return {"flag": False, "message": f"Failed to add attachment: {filename}"}
            else:
                logging.info(f"Unexpected attachment format: {attachment}")
    if isinstance(attachments, bytes):
        # Handle single attachment case
        try:
            # Add the attachment (blob data is already base64 encoded)
            attachment_part = Attachment(
                FileContent(attachments.decode()),  # Decode base64 bytes to string
                FileName('report.xlsx'),  # Provide the filename for the attachment
                FileType('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),  # Proper MIME type for Excel
                Disposition('attachment')
            )
            message.add_attachment(attachment_part)
        except Exception as e:
            logging.info(f"send_email : Error adding attachment: {e}")
            return {"flag": False, "message": f"Failed to add attachment"}

    # Retry logic
    attempt = 0
    while attempt < max_retries:
        try:
            try:
                # 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   our sendgrid api key
                sendgrid_initialization = SendGridAPIClient(
                    # "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"
                    str(sendgrid_api_key)
                )
                response = sendgrid_initialization.send(message)
                logging.info(f'send_email fucntion : email is sent successfully')
                insert_status = insert_email_audit(subject,body,template_name, to_emails, comments, partner_name, from_email, email_type,customer_name,account_number)
                logging.info(f"send_email function : insert_status: {insert_status}")
                # logging.info(f"Email sent! Status code: {response.status_code}")
                return to_emails, cc_emails, subject, body, from_email, partner_name
            except Exception as e:
                logging.info(f"SendGrid error: {e}")  # Log SendGrid error message
                return {
                        "flag": False,
                        "message": "Email failed to send after retries",
                        "to_emails": to_emails,
                        "cc_emails": cc_emails,
                        "subject": subject,
                        "body": body,
                        "from_email": from_email,
                        "partner_name": partner_name}
        except Exception as error:
            attempt += 1
            logging.info(f"send_email fucntion : Attempt {attempt}: An unexpected error occurred: {error}")
            if attempt < max_retries:
                logging.info(f"send_email fucntion : Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logging.info("send_email fucntion : Max retries reached. Email failed to send.")
                break

    return False

def send_email_without_template(**kwargs):
    """
    Send an email using SendGrid with retry logic.

    Args:
        template_name (str): Name of the email template.
        content (str): Email content.
        is_html (bool): Whether the content is HTML or plain text.

    Returns:
        bool: True if the email was sent successfully, False otherwise.
    """
    max_retries = 3  # Set the number of retries
    retry_delay = 5  # Delay between retries in seconds

    cc_emails = kwargs.get("cc_emails", "")
    partner_name = kwargs.get("partner_name", "")
    to_emails = kwargs.get("to_email", "")
    subject = kwargs.get("subject", "")
    body = kwargs.get("body", "")
    is_html = kwargs.get("is_html", True)
    attachments = kwargs.get("attachments", None)
    comments = kwargs.get("comments", "")
    invoice_links = kwargs.get("invoice_link", '')

    common_utils_database = DB(os.environ["COMMON_UTILS"], **db_config)
    email_credientials = common_utils_database.get_data(
                "tenant",
                {"tenant_name": partner_name, "is_active": True},
                ["from_email","sendgrid_api"],
            )
    sendgrid_email = email_credientials.iloc[0]["from_email"]
    sendgrid_api_key = email_credientials.iloc[0]["sendgrid_api"]
    external_warning = (
        '<br><br><p style="color: red;">This message is from an external user. Be cautious when opening attachment files or links.</p>'
    )
    if isinstance(invoice_links, list) and invoice_links:
        logging.info('##It is a list')
        view_links_section = "<br><br><b>Bill References:</b><ul>"
        for link in invoice_links:
            # Extract bill ID from the link
            bill_id = link.rstrip("/").split("/")[-1]  # gets 'Bill-693' from the URL
            view_links_section += f'<li><a href="{link}" target="_blank">{bill_id}</a></li>'
        view_links_section += "</ul>"
        body += view_links_section + external_warning
    elif isinstance(invoice_links, str) and invoice_links:
        logging.info('##It is a string')
        # If a single string was passed
        view_invoice_line = f'<br><br>To view or download the full invoice, click the link: <a href="{invoice_links}">View Invoice</a>'
        body += view_invoice_line + external_warning
    else:
        logging.info('####Not a list or string')
        body += external_warning

    # Handle missing 'to_emails' or 'subject'
    if not to_emails:
        logging.info("Error: 'to_emails' is missing.")
        return False

    if not subject:
        logging.info("Error: 'subject' is missing.")
        return False
    from_email = str(sendgrid_email)
    # from_email = "notifications@amop.services"  # Verified email for SendGrid
    message = prepare_email_message(
        from_email=from_email,
        to_emails=to_emails.split(","),  # Handle multiple emails as a list
        subject=subject,
        content=body,
        cc_emails=cc_emails.split(",") if cc_emails else [],
        is_html=is_html,
    )
    # ##adding the attachments
    if isinstance(attachments, list):
        for attachment in attachments:

            if isinstance(attachment, dict) and 'blob_data' in attachment and 'filename' in attachment:
                blob_data = attachment['blob_data']
                filename = attachment['filename']

                if blob_data and filename:
                    try:
                        # Create and add the attachment
                        attachment_part = create_attachment_from_blob(blob_data, filename)
                        message.add_attachment(attachment_part)
                    except Exception as e:
                        logging.info(f"Error adding attachment {filename}: {e}")
                        return {"flag": False, "message": f"Failed to add attachment: {filename}"}
            else:
                logging.info(f"Unexpected attachment format: {attachment}")
    if isinstance(attachments, bytes):
        # Handle single attachment case
        try:
            # Add the attachment (blob data is already base64 encoded)
            attachment_part = Attachment(
                FileContent(attachments.decode()),  # Decode base64 bytes to string
                FileName('report.xlsx'),  # Provide the filename for the attachment
                FileType('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),  # Proper MIME type for Excel
                Disposition('attachment')
            )
            message.add_attachment(attachment_part)
        except Exception as e:
            logging.info(f"Error adding attachment: {e}")
            return {"flag": False, "message": f"Failed to add attachment"}

    # Retry logic
    attempt = 0
    while attempt < max_retries:
        try:
            try:
                # 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   our sendgrid api key
                sendgrid_initialization = SendGridAPIClient(
                    # "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"
                    str(sendgrid_api_key)
                )
                response = sendgrid_initialization.send(message)
                logging.info(f'email is sent successfully')
                #insert_status = insert_email_audit(subject,body, to_emails, comments, partner_name, from_email)
                insert_status = insert_email_audit(subject, body, "Collection Email trigger", to_emails, comments, partner_name, from_email, "Billing Platform")
                logging.info(f"insert_status: {insert_status}")
                # logging.info(f"Email sent! Status code: {response.status_code}")
                return to_emails, cc_emails, subject, body, from_email, partner_name
            except Exception as e:
                logging.info(f"SendGrid error: {e}")  # Log SendGrid error message
                return {
                        "flag": False,
                        "message": "Email failed to send after retries",
                        "to_emails": to_emails,
                        "cc_emails": cc_emails,
                        "subject": subject,
                        "body": body,
                        "from_email": from_email,
                        "partner_name": partner_name}
        except Exception as error:
            attempt += 1
            logging.info(f"Attempt {attempt}: An unexpected error occurred: {error}")
            if attempt < max_retries:
                logging.info(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logging.info("Max retries reached. Email failed to send.")
                break

    return False