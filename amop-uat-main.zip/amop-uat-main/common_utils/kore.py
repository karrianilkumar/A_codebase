"""
Module for sending emails using SendGrid.
This module provides a function to send emails using the SendGrid API.

@Author1 : Phaneendra.Y
@Author2 : Burhan

Created Date: Feb 01, 2025
"""

import re
import os
import base64
import time
import json
import pandas as pd
import psutil
import boto3
import datetime
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging

##Database Configuration
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}
logging = Logging(name="kore")


def get_access_token(client_id, client_secret):
    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
    }
    # token_url = "https://api.korewireless.com/Api/api/token"
    token_url = os.environ["KORE_API"]
    try:
        response = requests.post(token_url, data=payload)
        response.raise_for_status()
        token_data = response.json()
        access_token = token_data.get("access_token")
        if access_token:
            logging.info("Access Token Generated Successfully:")
            logging.info(f"Access Token: {access_token}")  # Debugging: Print the token
            return access_token
        else:
            logging.info("Error: Access token not found in response.")
            logging.info(token_data)
            return None
    except requests.exceptions.RequestException as e:
        logging.info(f"Error fetching access token: {e}")
        return None


def get_account_id(api_key=None):
    email = os.environ['KORE_EMAIL']
    # email = "czambrano@spectrotel.com"
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    base_url = database.get_data("integration", {"name": "Kore"})["website"].to_list()[
        0
    ]
    url = f"{base_url}v1/accounts?email={email}"

    tenant_name = os.getenv("KORE_TENANT_NAME", "Spectrotel")
    try:
        tenant_id = database.get_data("tenant", {"tenant_name": tenant_name}, ["id"])[
            "id"
        ].to_list()[0]
    except Exception as e:
        logging.exception(f"An error occurred: {e}")
    details = database.get_data(
        "integration_authentication",
        {"integration_id": os.getenv("KORE_PROVIDER_ID", ""), "tenant_id": tenant_id, "service_provider_id": os.getenv("KORE_PROVIDER_ID", "")},
        ["oauth2_client_id", "oauth2_client_secret", "token_value"],
    )
    client_id = details["oauth2_client_id"].to_list()[0]
    client_secret = details["oauth2_client_secret"].to_list()[0]
    api_key = details["token_value"].to_list()[0]
    access_token = get_access_token(client_id, client_secret)
    headers = {"Accept": "application/json", "Authorization": f"Bearer {access_token}"}
    if api_key:
        headers["x-api-key"] = api_key  # Include API Key if required
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        account_data = response.json()

        # Extract account-id from the list inside 'account'
        accounts = account_data.get("account", [])
        if accounts and isinstance(accounts, list):
            account_id = accounts[0].get(
                "account-id"
            )  # Get the first account's account-id
            logging.info("Account Details:")
            logging.info(account_data)
            return account_id, access_token
        else:
            logging.info("Error: No accounts found or invalid response structure.")
            return None
    except requests.exceptions.RequestException as e:
        logging.info(f"Error fetching account ID: {e}")
        logging.info(f"Response: {response.text}")  # Debugging: Log the raw response
        return None
