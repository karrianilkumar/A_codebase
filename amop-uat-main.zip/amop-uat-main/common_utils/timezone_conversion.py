import re
import pandas as pd
from pytz import timezone
import numpy as np


# Helper function to fetch the tenant's timezone
def fetch_tenant_timezone(common_utils_database, data):
    tenant_name = data.get("tenant_name", "")
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    # tenant_timezone_start_time = time.time()
    tenant_timezone = common_utils_database.execute_query(
        tenant_timezone_query, params=[tenant_name]
    )
    # tenant_timezone_duration = time.time() - tenant_timezone_start_time
    if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
        raise ValueError("No valid timezone found for tenant.")
    tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
    if not re.match(r"^[A-Za-z]+/[A-Za-z_]+$", tenant_time_zone):
        raise ValueError(f"Invalid timezone format: {tenant_time_zone}")

    return tenant_time_zone


def convert_timestamp_data(df_dict, tenant_time_zone, timestamp_columns=None):
    if timestamp_columns is None:
        timestamp_columns = [
            "created_date",
            "modified_date",
            "deleted_date",
            "processed_date",
            "last_login",
            "date_added",
            "run_start_time",
            "session_created_date",
            "optimization_run_end_time",
            "billing_period_start_date",
            "billing_period_end_date",
            "last_email_triggered_at",
            "date_of_change",
        ]
    target_timezone = timezone(tenant_time_zone)
    utc_timezone = timezone("UTC")

    def process_record(record):
        for col in timestamp_columns:
            if col in record and record[col]:  # Ensure column exists and is truthy
                try:
                    # Parse timestamp and assume it's in UTC
                    timestamp = pd.to_datetime(record[col], errors="coerce")
                    if timestamp is not pd.NaT:
                        if timestamp.tz is None:
                            # Localize naive timestamps to UTC
                            timestamp = timestamp.tz_localize(utc_timezone)
                        # Convert to the target timezone
                        record[col] = timestamp.tz_convert(target_timezone).strftime(
                            "%m-%d-%Y %I:%M:%S %p"
                        )
                except Exception as e:
                    print(f"Error processing column '{col}': {record[col]} - {e}")
        return record

    def traverse_data(data):
        if isinstance(data, list):  # Process each item if data is a list
            return [traverse_data(item) for item in data]
        elif isinstance(
            data, dict
        ):  # Process each key-value pair if data is a dictionary
            return process_record(data)
        return data  # Return data as-is for non-dict/non-list

    return traverse_data(df_dict)


def serialize_data(data):
    """Recursively convert pandas objects in the data structure to serializable types."""
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        # Handle pd.Timestamp and NaT
        return data.strftime("%m-%d-%Y %I:%M:%S %p") if pd.notna(data) else None
    elif data is pd.NaT:  # Directly check for pd.NaT
        return None
    elif isinstance(data, np.datetime64):  # Handle numpy datetime64
        return str(data) if pd.notna(data) else None
    elif pd.api.types.is_integer(data):  # Check explicitly for integers
        return int(data)
    elif pd.api.types.is_float(data):  # Check explicitly for floats
        return float(data)
    elif pd.isna(data):  # Handle NaN or missing values
        return None
    else:
        return data  # Return as is for other types
