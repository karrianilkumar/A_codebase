"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil .N
Created Date: 21-06-24
"""

# Importing the necessary Libraries
import re
import os
import json
import psycopg2
import numpy as np
import pandas as pd
from time import time
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import OperationalError
from sqlalchemy import create_engine, exc, text, delete, and_, or_, update, case
from sqlalchemy import (
    Table, MetaData,select,desc,asc,insert,func,Integer,
    String,Float,DateTime,Boolean,Column
)
from sqlalchemy import case, update
from common_utils.logging_utils import Logging

logging = Logging(name="db_utils")


##test jenkins
class DB(object):
    def __init__(
        self,
        database,
        multi_schema=True,
        host="127.0.0.1",
        user="root",
        password="",
        port="3306",
        customers=None,
        service_providers=None,
        service_provider_id=None,
        customer_rate_plan_name=None,
        feature_codes=None,
        billing_account_number=None,
        tenant_ids=None,
        db_type="postgresql",
    ):
        """
        Initialization of databse object.

        Args:
            databse (str): The database to connect to.
            host (str): Host IP address. For dockerized app, it is the name of
                the service set in the compose file.
            user (str): Username of PostgresSQL server. (default = 'root')
            password (str): Password of PostgresSQL server. For dockerized app, the
                password is set in the compose file. (default = '')
            port (str): Port number for PostgresSQL. For dockerized app, the port that
                is mapped in the compose file. (default = '3306')
        """
        # Assigning instance variables with the given arguments or default values
        self.multi_schema = multi_schema
        self.HOST = host
        self.USER = user
        self.PASSWORD = password
        self.PORT = port
        self.DATABASE = f"{database}"
        self.DB_TYPE = db_type
        self.customers = customers
        self.service_providers = service_providers
        self.service_provider_id = service_provider_id
        self.customer_rate_plan_name = customer_rate_plan_name
        self.feature_codes = feature_codes
        self.billing_account_number = billing_account_number
        self.tenant_ids= tenant_ids
        self.connect()
        self.file_path = f"/opt/python/lib/python3.9/site-packages/common_utils/schemas/{database}.json"
        logging.info(
                f"File for '{database}'found. Using '{self.file_path}' instead."
            )
        # Check if the file exists
        if not os.path.exists(self.file_path):
            logging.info(
                f"File for '{database}' not found. Using default 'default_schema' instead."
            )
            # Replace with default database if file is not found
            self.file_path = "/opt/python/lib/python3.9/site-packages/common_utils/schemas/default_schema.json"
        self.metadata, self.tables = self.load_schema(self.file_path)

    def __del__(self):
        # This method is called when the object is about to be destroyed
        try:
            logging.info("############### DETROYING THE DB CONNECTION")
            # Attempting to close the database connection
            self.engine.close()
            # Disposing of the database engine to free up resources
            # if self.engine:
            #     self.engine.dispose()
            logging.info("connections are closed")

        except Exception as e:
            logging.exception("########### Failed to destroy the DB COnenctions", e)

    def connect(self, max_retry=3):
        retry = 1
        try:
            start = time()
            logging.info(f"Making connection to `{self.DATABASE}`...")
            config = f"postgresql://{self.USER}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.DATABASE}"
            # logging.info(f"connection : {config}")
            self.engine = create_engine(
                config, connect_args={"connect_timeout": 10}, pool_recycle=300
            )
            logging.info(f"Engine created for `{self.DATABASE}`")
            while retry <= max_retry:
                try:
                    self.engine = self.engine.connect()
                    self.session = sessionmaker(bind=self.engine)()
                    logging.info(
                        f"Connection established successfully to `{self.DATABASE}`! ({round(time() - start, 2)} secs to connect)"
                    )
                    break
                except Exception as e:
                    logging.warning(f"Connection failed. Retrying... ({retry}) [{e}]")
                    retry += 1
                    self.engine.dispose()
                    if retry > max_retry:
                        raise Exception(
                            "Max retry attempts reached. Could not connect to the database."
                        )
        except Exception as e:
            raise Exception(f"Something went wrong while connecting. Check trace. {e}")

    def type_from_string(self, type_str):
        # Map type strings to SQLAlchemy types
        type_map = {
            "Integer": Integer,
            "String": String,
            "Float": Float,
            "DateTime": DateTime,
            "Boolean": Boolean,
            # Add other types as needed
        }
        return type_map.get(type_str, String)  # Default to String if type is not found

    def load_schema(self, schema_file):
        metadata = MetaData()
        tables = {}

        with open(schema_file, "r") as f:
            schema = json.load(f)

        for table_name, columns in schema.items():
            column_objects = []
            for col in columns:
                col_type = self.type_from_string(
                    col["type"]
                )  # Convert type string to actual type
                column_objects.append(
                    Column(
                        col["name"],
                        col_type,
                        nullable=col["nullable"],
                        primary_key=col["primary_key"],
                    )
                )

            tables[table_name] = Table(table_name, metadata, *column_objects)

        return metadata, tables

    def combine_records_excluding_columns(
        self, data, exclude_columns=["id", "schema_tag"]
    ):
        # Create a DataFrame from the input data
        df = pd.DataFrame(data)

        # Determine which columns to include by excluding the specified columns
        include_columns = df.columns.difference(exclude_columns)

        # Group by the include_columns and perform aggregation
        result = df.groupby(include_columns.tolist(), as_index=False).agg(
            id=("id", lambda x: "-".join(map(str, x))),  # Join original IDs
            schema_tag=(
                "schema_tag",
                lambda x: "-".join(set(x)),
            ),  # Aggregate schema tags
        )

        return result

    def fetch_schemas(self):
        schema_query = """
        SELECT nspname AS schema_name
        FROM pg_catalog.pg_namespace
        WHERE nspname NOT LIKE 'pg_%'
        AND nspname != 'information_schema';
        """

        with self.engine as connection:
            schemas_result = connection.execute(text(schema_query)).fetchall()

        schemas = [
            row[0] for row in schemas_result
        ]  # Getting the result returns a list of schema names
        if not schemas:
            logging.info("### fetch_schemas No schemas found.")
            return []
        return schemas

    def set_shema_path(self, schema):
        # Set the search path to the schema
        set_path = f"SET search_path TO {schema}"
        try:
            if self.engine.closed:
                logging.info("### fetch_schemas Connection is closed. Attempting to reconnect...")
                self.connect()
            pd.read_sql(set_path, self.engine)
        except exc.ResourceClosedError:
            logging.exception("### fetch_schemas Query executed, but it does not have any result to return.")
            return None

    def execute_query_multi_schemas(
        self, query, flag=False, insert=[], update=[], schemas=[], attempt=0, **kwargs
    ):
        """
        Executes an SQL query.

        Args:
            query (str): The query that needs to be executed.
            flag (bool): A flag to indicate if the query should proceed without parameters.
            direct_query (bool): If True, executes the query across all available schemas.
            attempt (int): Number of attempts made for retries in case of connection errors.
            kwargs: Additional arguments like 'params' for the query.

        Returns:
            (DataFrame): A pandas DataFrame containing the result of the query, or None if an error occurs.
        """

        try:
            # Initialize data variable
            # data = None
            logging.info(
                f"Executing Query in execute_query_multi_schemas: {query} and insert is {insert} and update is {update} and schemas is {schemas}"
            )

            combined_results = []
            # Handle direct query for executing across schemas
            if insert:
                schemas = insert
            elif update:
                schemas = update

            for schema in schemas:
                try:
                    # Check if the query is parameterized
                    if "params" not in kwargs and not flag:
                        logging.info("Cannot execute query (Expecting parameterized query).")
                        return None

                    # Extract parameters from kwargs, if available
                    params = tuple(kwargs.get("params", ()))
                    logging.info(f"Params: {params}")

                    logging.info(f"Running query on schema: {schema}")
                    self.set_shema_path(schema)

                    if hasattr(query, "compile"):
                        query_str = str(
                            query.compile(compile_kwargs={"literal_binds": True})
                        )
                    else:
                        query_str = str(query)

                    logging.info(f"####### Query: {query_str}")
                    logging.info(f"####### Params: {params}")

                    # Execute the query using pandas read_sql method
                    try:
                        query_str = query_str.replace("`", "")
                        query_str = query_str.replace('"', "")
                    except Exception as e:
                        logging.exception(f"Exception while removing quotes: {e}")
                        pass

                    if self.engine.closed:
                        logging.info("Connection is closed. Attempting to reconnect...")
                        self.connect()

                    # Execute the query using pandas read_sql method
                    schema_data = pd.read_sql(query_str, self.engine, params=params)
                    logging.info(f"Query executed successfully.and data is {schema_data}")

                    if not insert and not update:
                        schema_data["schema_tag"] = schema
                        combined_results.append(schema_data)
                except exc.ResourceClosedError:
                    logging.exception("Query executed, but it does not have any result to return.")

            # Combine results across schemas and return as one DataFrame
            if combined_results:
                return self.combine_records_excluding_columns(
                    pd.concat(combined_results, ignore_index=True)
                )
            else:
                logging.info("No results obtained across schemas.")
                return True

        except exc.ResourceClosedError:
            logging.exception("Query executed, but it does not have any result to return.")
            return None

        except exc.IntegrityError as e:
            logging.exception(f"Integrity Error: {e}")
            return None

        except (exc.StatementError, OperationalError) as e:
            # Handle statement and operational errors (e.g., connection issues)
            logging.exception(f"Error encountered: {e}. Retrying (attempt #{attempt + 1})...")
            attempt += 1
            if attempt <= 3:
                # Retry the connection and execution
                self.connect()
                return self.execute_query(
                    query,
                    flag=flag,
                    insert=insert,
                    update=update,
                    attempt=attempt,
                    **kwargs,
                )
            else:
                logging.info("Maximum retry attempts reached.")
                return None

        except Exception as e:
            logging.exception(f"Error executing query: {e}")
            return None

    def append_conditions(self, query):

        try:
            exception_tables = ["users"]
            query = query.replace("\n", " ").replace("\t", " ")
            # Remove extra spaces
            query = " ".join(query.split())
            query = query.replace(";", "")
            # 🔥 Skip if JOIN is present
            if re.search(r"\b(join|inner join|left join|right join|full join|cross join)\b", query, re.IGNORECASE):
                logging.info("### append_conditionsJOIN detected – skipping appending conditions.")
                return query
            # tables = re.findall(r'(FROM|JOIN)\s+([a-zA-Z0-9_]+)(?:\s+AS\s+([a-zA-Z0-9_]+))?', query, re.IGNORECASE)
            tables = re.findall(
                r"(FROM|JOIN)\s+([a-zA-Z0-9_]+\.[a-zA-Z0-9_]+|\S+)(?:\s+AS\s+([a-zA-Z0-9_]+))?",
                query,
                re.IGNORECASE,
            )

            # Extract table names and aliases into a list (ignoring 'FROM' and 'JOIN' keywords)
            table_info = [
                (table[1], table[2] if len(table) > 2 else table[1]) for table in tables
            ]
            logging.info(f"### append_conditions TABLES AND ALIASES: {table_info}")

            # Step 2: Define the additional conditions based on the table(s)
            additional_conditions = ""

            # Loop through the list of tables and append conditions for each
            for table_name, alias in table_info:

                if table_name in exception_tables:
                    continue

                customer_columns = ["customer_name"]
                feature_codes_columns=["soc_code"]
                tenant_id_column=['tenant_id']
                billing_account_number_columns = ["billing_account_number"]
                service_provider_column = [
                    "serviceprovider","service_provider","service_provider_display_name",
                    "serviceprovidername",
                    "serviceproviderdisplayname",
                    "serviceproviders",
                ]
                if table_name=='customerrateplan' or table_name=='public.customerrateplan' or table_name=='vw_customer_rate_plans' or table_name=='public.vw_customer_rate_plans':
                    logging.info('### append_conditions customer rate plan table found')
                    customer_rate_plan_name_column = ["customer_rate_plan_name","customer_rate_plan","rate_plan_name"]
                else:
                    customer_rate_plan_name_column = ["customer_rate_plan_name","customer_rate_plan","rate_plan_name"]
                service_provider_id_column = ["serviceproviderid"]

                if self.customers or self.service_providers or self.customer_rate_plan_name or self.customer_rate_plan_name or self.feature_codes or self.billing_account_number or self.tenant_ids:
                    parts = table_name.split(".")
                    if len(parts) > 1:
                        cols = self.get_columns(parts[1])
                    else:
                        cols = self.get_columns(parts[0])
                    logging.info(f"### append_conditions COLUMNS ARE : {cols}, {self.customers}, {self.service_providers}, {self.tenant_ids}")

                    if self.service_providers and self.service_providers[0]:
                        found = False
                        if "vw" in table_name.lower():
                            for col_ in cols:
                                col = re.sub(r"[^a-zA-Z]", "", col_).lower()
                                logging.info(f"### append_conditions servcice provider ids is : {self.service_provider_id} ")
                                if col in service_provider_id_column and (
                                    self.service_provider_id
                                    and self.service_provider_id[0]
                                ):
                                    found = True
                                    logging.info(f"### append_conditions servcice provider id is {self.service_provider_id}")
                                    if len(self.service_provider_id) == 1:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} = '{self.service_provider_id[0]}'"
                                        else:
                                            additional_conditions += f" AND {col_} = '{self.service_provider_id[0]}'"
                                    else:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} IN {self.service_provider_id}"
                                        else:
                                            additional_conditions += f" AND {col_} IN {self.service_provider_id}"
                                    break

                        if not found:
                            for col_ in cols:
                                col = re.sub(r"[^a-zA-Z]", "", col_).lower()
                                if col in service_provider_column:
                                    if len(self.service_providers) == 1:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} = '{self.service_providers[0]}'"
                                        else:
                                            additional_conditions += f" AND {col_} = '{self.service_providers[0]}'"
                                    else:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} IN {self.service_providers}"
                                        else:
                                            additional_conditions += f" AND {col_} IN {self.service_providers}"
                                    break

                    if self.customers and self.customers[0]:
                        for col_ in cols:
                            if col_ in customer_columns:
                                col = re.sub(r"[^a-zA-Z]", "", col_).lower()
                                if len(self.customers) == 1:
                                    if alias:
                                        additional_conditions += f" AND {alias}.{col_} = '{self.customers[0]}'"
                                    else:
                                        additional_conditions += (
                                            f" AND {col_} = '{self.customers[0]}'"
                                        )
                                else:
                                    if alias:
                                        additional_conditions += (
                                            f" AND {alias}.{col_} IN {self.customers}"
                                        )
                                    else:
                                        additional_conditions += (
                                            f" AND {col_} IN {self.customers}"
                                        )
                                break
                    if self.customer_rate_plan_name and self.customer_rate_plan_name[0]:
                        for col_ in cols:
                            if col_ in customer_rate_plan_name_column:
                                col = re.sub(r"[^a-zA-Z]", "", col_).lower()
                                if len(self.customer_rate_plan_name) == 1:
                                    if alias:
                                        additional_conditions += f" AND {alias}.{col_} = '{self.customer_rate_plan_name[0]}'"
                                    else:
                                        additional_conditions += (
                                            f" AND {col_} = '{self.customer_rate_plan_name[0]}'"
                                        )
                                else:
                                    if alias:
                                        additional_conditions += (
                                            f" AND {alias}.{col_} IN {self.customer_rate_plan_name}"
                                        )
                                    else:
                                        additional_conditions += (
                                            f" AND {col_} IN {self.customer_rate_plan_name}"
                                        )
                                break
                    if self.feature_codes and self.feature_codes[0]:
                        for col_ in cols:
                            if col_ in feature_codes_columns:
                                col = re.sub(r"[^a-zA-Z]", "", col_).lower()
                                if len(self.feature_codes) == 1:
                                    if alias:
                                        additional_conditions += f" AND {alias}.{col_} = '{self.feature_codes[0]}'"
                                    else:
                                        additional_conditions += (
                                            f" AND {col_} = '{self.feature_codes[0]}'"
                                        )
                                else:
                                    if alias:
                                        additional_conditions += (
                                            f" AND {alias}.{col_} IN {self.feature_codes}"
                                        )
                                    else:
                                        additional_conditions += (
                                            f" AND {col_} IN {self.feature_codes}"
                                        )
                                break
                    if self.billing_account_number and self.billing_account_number[0]:
                        for col_ in cols:
                            if col_ in billing_account_number_columns:
                                col = re.sub(r"[^a-zA-Z]", "", col_).lower()
                                if len(self.billing_account_number) == 1:
                                    if alias:
                                        additional_conditions += f" AND {alias}.{col_} = '{self.billing_account_number[0]}'"
                                    else:
                                        additional_conditions += (
                                            f" AND {col_} = '{self.billing_account_number[0]}'"
                                        )
                                else:
                                    if alias:
                                        additional_conditions += (
                                            f" AND {alias}.{col_} IN {self.billing_account_number}"
                                        )
                                    else:
                                        additional_conditions += (
                                            f" AND {col_} IN {self.billing_account_number}"
                                        )
                                break
                    if self.tenant_ids and self.tenant_ids[0]:
                        logging.info('### append_conditions entered here in tenantn id condition')
                        found = False
                        tenant_condition_exists = any(
                            re.search(rf"\b{col_}\b\s*=", query, re.IGNORECASE) for col_ in tenant_id_column
                        )

                        if tenant_condition_exists:
                            logging.info("### append_conditions Tenant ID condition already present in query – skipping filter.")
                        else:
                            if "vw" in table_name.lower():
                                logging.info('### append_conditions entered here in view condition')
                                for col_ in cols:
                                    col = re.sub(r"[^a-zA-Z]", "", col_).lower()
                                    logging.info(f"### append_conditions tenant_ids is {self.tenant_ids}")
                                    if col in tenant_id_column and (
                                        self.tenant_ids
                                        and self.tenant_ids[0]
                                    ):
                                        found = True
                                        logging.info(f"### append_conditions servcice provider id is {self.tenant_ids}")
                                        if len(self.tenant_ids) == 1:
                                            if alias:
                                                additional_conditions += f" AND {alias}.{col_} = '{self.tenant_ids[0]}'"
                                            else:
                                                additional_conditions += f" AND {col_} = '{self.tenant_ids[0]}'"
                                        else:
                                            if alias:
                                                additional_conditions += f" AND {alias}.{col_} IN {self.tenant_ids}"
                                            else:
                                                additional_conditions += f" AND {col_} IN {self.tenant_ids}"
                                        break

                            if not found:
                                for col_ in cols:
                                    col=col_
                                    #col = re.sub(r"[^a-zA-Z]", "", col_).lower()
                                    if col in tenant_id_column:
                                        if len(self.tenant_ids) == 1:
                                            if alias:
                                                additional_conditions += f" AND {alias}.{col_} = '{self.tenant_ids[0]}'"
                                            else:
                                                additional_conditions += f" AND {col_} = '{self.tenant_ids[0]}'"
                                        else:
                                            if alias:
                                                additional_conditions += f" AND {alias}.{col_} IN {self.tenant_ids}"
                                            else:
                                                additional_conditions += f" AND {col_} IN {self.tenant_ids}"
                                        break

            query_parts = re.split(r"(\sGROUP\sBY\s.+)", query, flags=re.IGNORECASE)
            order_limit_clause = "".join(query_parts[1:])
            if not order_limit_clause:
                query_parts = re.split(
                    r"(\sORDER\sBY\s.+|\sLIMIT\s\d+)", query, flags=re.IGNORECASE
                )
                order_limit_clause = "".join(query_parts[1:])
                if not order_limit_clause:
                    query_parts = re.split(
                        r"(\sLIMIT\s(?:\d+|\%s)\sOFFSET\s(?:\d+|\%s)|\sLIMIT\s(?:\d+|\%s))",
                        query,
                        flags=re.IGNORECASE,
                    )
                    order_limit_clause = "".join(query_parts[1:])
            logging.info(f"### append_conditions order_limit_clause is : {order_limit_clause}")
            # Remove any WHERE, ORDER BY, and LIMIT clauses to avoid conflicts
            if order_limit_clause:
                query = query_parts[
                    0
                ]  # Base query without ORDER BY/LIMIT   # Remove only ORDER BY and LIMIT
                logging.info(query)

            # Step 4: Add the WHERE clause if additional conditions exist
            if additional_conditions:
                if "WHERE" in query.upper():
                    query += additional_conditions
                else:
                    query += " WHERE 1=1" + additional_conditions

            # Step 5: Re-attach any ORDER BY and LIMIT clauses back to the query
            if order_limit_clause:
                query += order_limit_clause  # Append ORDER BY / LIMIT
        except Exception as e:
            logging.exception(f"### append_conditions Error appending conditions: {e}")

        return query

    def execute_query(
        self,
        query,
        flag=False,
        no_filter_append=False,
        insert=[],
        update=[],
        attempt=0,
        **kwargs,
    ):
        """
        Executes an SQL query.

        Args:
            query (str): The query that needs to be executed.
            params (list/tuple/dict): List of parameters to pass to in the query.

        Returns:
            (DataFrame) A pandas dataframe containing the data from the executed
            query. (None if an error occurs)
        """
        # Initialize data variable
        data = None
        logging.info(f"Query in the execute query is : {query}")
        schemas = []
        if not insert and not update:
            schemas = self.fetch_schemas()
        logging.info(f"schemas: {schemas}")

        if self.multi_schema:
            if len(schemas) > 1 or len(update) > 0 or len(insert) > 1:
                return self.execute_query_multi_schemas(
                    query, flag, insert, update, schemas
                )
        Session = sessionmaker(bind=self.engine)
        session = Session()  # Create a new session
        try:
            # Check if the query is parameterized
            if "params" not in kwargs and not flag:
                logging.info("### execute_query Cannot execute query (Expecting parametarized query).")
                return True
            # Extract parameters from kwargs if available
            params = kwargs["params"] if "params" in kwargs else None
            if params:
                params = tuple(params)
            else:
                params = ()

            if self.engine.closed:
                logging.info("### execute_query Connection is closed. Attempting to reconnect...")
                self.connect()

            if hasattr(query, "compile"):
                query_str = str(query.compile(compile_kwargs={"literal_binds": True}))
            else:
                query_str = str(query)

            logging.info(f"####### Query: {query_str}")
            logging.info(f"####### Params: {params}")
            try:
                # Check and replace newlines only if they exist
                if '\n' in query_str:
                    query_str = query_str.replace('\n', ' ')
            except Exception:
                logging.exception("### execute_query Exception while removing /n")

            # Execute the query using pandas read_sql method
            try:
                query_str = query_str.replace("`", "")
                query_str = query_str.replace('"', "")
            except Exception as e:
                logging.exception(f"### execute_query Exception while removing quotes: {e}")
                pass

            if (
                self.customers
                or self.service_providers or self.customer_rate_plan_name or self.feature_codes or self.billing_account_number or self.tenant_ids
                and "SELECT" in query_str.upper()
                and not no_filter_append
            ):
                query_str = self.append_conditions(query_str)

            logging.info(f"### execute_query after additional add ons Query: {query_str}")

            data = pd.read_sql(query_str, self.engine, params=params)
            # data =  self.engine.execute(query, params=params)
            # logging.info(f"########### Data")
        except exc.ResourceClosedError:
            logging.exception("### execute_query Query does not have any value to return.")
            return True
        except exc.IntegrityError as e:
            logging.exception(f"### execute_query Integrity Error - {e}")
            return None
        except (exc.StatementError, OperationalError) as e:
            # Handle statement errors and operational errors (e.g., connection issues)
            logging.exception(f"### execute_query Creating new connection. Engine/Connection is probably None. [{e}]")
            attempt += 1
            if attempt <= 3:
                # Reconnect to the database
                self.connect()
                logging.info(f"### execute_query Attempt #{attempt}")
                # Execute the query using execute_query
                return self.execute_query(query, attempt=attempt, **kwargs)
            else:
                logging.info(f"### execute_query Maximum attempts reached. ({3})")
                return False
        except Exception as e:
            logging.exception(f"### execute_query Something went wrong executing query. Check trace. {e}")
            params = kwargs["params"] if "params" in kwargs else None
            return False
        finally:
            session.close()
            logging.info("### execute_query connections are closed")
        # Replace NaN values in the resulting DataFrame with None and return
        return data.replace({np.nan: None})

    def _build_filters(self, table, filters, combine_logic=[]):
        """
        Builds SQLAlchemy filter conditions from a dictionary of filters with optional 
        combination logic for each condition.
        
        Args:
            table: SQLAlchemy table object to build filters for
            filters: Dictionary of {column_name: value} pairs to filter on
            combine_logic: List of condition indices that should use OR logic 
                        (default is AND for all conditions)
                        
        Returns:
            SQLAlchemy binary expression combining all the filter conditions with
            the specified AND/OR logic
        """

        filter_conditions = []
        count = 0
        for key, value in filters.items():
            # Check if condition is a tuple (value, logic) e.g., ("not Null", "OR")
            if str(count) in combine_logic:
                logic = "OR"
            else:
                logic = "AND"  # Default logic if not specified

            # Handle NULL and NOT NULL conditions
            if value == "not Null":
                filter_condition = table.c[key].isnot(None)
            elif value == "Null":
                filter_condition = table.c[key].is_(None)
            elif isinstance(value, (list, tuple)):
                # Handle WHERE IN condition
                filter_condition = table.c[key].in_(value)
            else:
                filter_condition = table.c[key] == value
            count = count + 1
            filter_conditions.append((filter_condition, logic))

        # Combine conditions based on the specified logic
        and_conditions = [cond for cond, logic in filter_conditions if logic == "AND"]
        or_conditions = [cond for cond, logic in filter_conditions if logic == "OR"]

        combined_condition = "None"
        if and_conditions:
            combined_condition = and_(*and_conditions)
        if or_conditions:
            or_combined = or_(*or_conditions)

            if combined_condition != "None":
                combined_condition = and_(combined_condition, or_combined)
            else:
                combined_condition = or_combined

        return combined_condition

    def get_data(
        self,
        table_name=None,
        condition=None,
        columns=None,
        order=None,
        combine=[],
        joins=None,
        mod_pages=None,
        concat_columns=None,
        coalesce_columns=None,
    ):
        Session = sessionmaker(bind=self.engine)
        session = Session()  # Create a new session

        try:
            logging.info(
                "Querying table=%s where=%s selecting=%s order_by=%s joins=%s",
                table_name,
                condition,
                columns,
                order,
                joins,
            )

            # Reflect the table from the database schema
            # metadata = MetaData()
            # metadata.reflect(bind=self.engine)
            # table = Table(table_name, metadata, autoload_with=self.engine)
            table = self.tables.get(table_name)

            if columns:
                columns = [
                    table.c[col] if isinstance(col, str) else col for col in columns
                ]
            else:
                columns = [table]

            # Handle concatenation if `concat_columns` is provided
            if concat_columns:
                name_column, id_column = concat_columns
                concat_expr = func.concat(
                    table.c[name_column], str(" -- "), table.c[id_column]
                )
                columns.append(concat_expr.label("concat_column"))

            if coalesce_columns:
                coalesce_expr = func.coalesce(
                    *[table.c[col] for col in coalesce_columns]
                )
                columns.append(coalesce_expr.label("coalesce_column"))

            # Create the base query
            query = select(*columns)

            # Handle joins
            if joins:
                for join_table, on_condition in joins.items():
                    join_table = Table(join_table, self.metadata, autoload_with=self.engine)
                    query = query.join(join_table, on_condition)

            # Apply filters
            if condition:
                where = self._build_filters(table, condition, combine)
                query = query.where(where)

            # Apply ordering
            if order:
                order_by = list(order.keys())[0]
                order_direction = list(order.values())[0]
                order_clause = (
                    asc(order_by) if order_direction == "asc" else desc(order_by)
                )
                query = query.order_by(order_clause)

            # Apply pagination
            if mod_pages:
                start = mod_pages.get("start", 0)
                end = mod_pages.get("end", 500)
                query = query.offset(start).limit(end - start)

            logging.info(f"### get_data Final query that is going to get executed is {query}")
            return self.execute_query(query, True)

        except Exception as e:
            # Logging an exception if any error occurs during the update process
            logging.exception(f"### get_data Error getting data: {e}")
            return False
        finally:
            session.close()  # Ensure the session is closed


    def get_data_bp(self, table_name=None, condition=None, columns=None, order=None, combine=[], joins=None, mod_pages=None, concat_columns=None,coalesce_columns=None):
        Session = sessionmaker(bind=self.engine)
        session = Session()  # Create a new session

        try:
            logging.info(table_name, condition, columns, order, joins)

            # Reflect the table from the database schema
            # metadata = MetaData()
            # metadata.reflect(bind=self.engine)
            # table = Table(table_name, metadata, autoload_with=self.engine)
            table = self.tables.get(table_name)

            if columns:
                columns = [table.c[col] if isinstance(col, str) else col for col in columns]
            else:
                columns = [table]

            # Handle concatenation if `concat_columns` is provided
            if concat_columns:
                name_column, id_column = concat_columns
                concat_expr = func.concat(
                    table.c[name_column],
                    str(' -- '),
                    table.c[id_column]
                )
                columns.append(concat_expr.label('concat_column'))

            if coalesce_columns:
                coalesce_expr = func.coalesce(
                    *[table.c[col] for col in coalesce_columns]
                )
                columns.append(coalesce_expr.label('coalesce_column'))


            # Create the base query
            query = select(*columns)

            # Handle joins
            if joins:
                for join_table, on_condition in joins.items():
                    join_table = Table(join_table, self.metadata, autoload_with=self.engine)
                    query = query.join(join_table, on_condition)

            # Apply filters
            if condition:
                logging.info(f'### get_data_bp condition is {condition}')
                where = self._build_filters_bp(table, condition, combine)
                logging.info(f'### get_data_bp where is {where}')
                query = query.where(where)
                logging.info(f'### get_data_bp query is {query}')

            # Apply ordering
            if order:
                order_by = list(order.keys())[0]
                order_direction = list(order.values())[0]
                order_clause = asc(order_by) if order_direction == 'asc' else desc(order_by)
                query = query.order_by(order_clause)

            # Apply pagination
            if mod_pages:
                start = mod_pages.get('start', 0)
                end = mod_pages.get('end', 500)
                query = query.offset(start).limit(end - start)

            logging.info(f"### get_data_bp Final query that is going to get executed is {query}")
            return self.execute_query(query, True)

        except Exception as e:
            # Logging an exception if any error occurs during the update process
            logging.exception(f'### get_data_bp Error getting data: {e}')
            return False
        finally:
            session.close()  # Ensure the session is closed

    def _build_filters_bp(self, table, filters, combine_logic=[]):
        filter_conditions = []
        count = 0

        for key, value in filters.items():
            logging.info(f'### get_data_bp key is {key} and value is {value}')
            # Determine the logic (AND/OR)
            logic = "OR" if str(count) in combine_logic else "AND"

            col = table.c[key]

            # Handle IS NULL / IS NOT NULL
            if value == "not Null":
                filter_condition = col.isnot(None)
            elif value == "Null":
                filter_condition = col.is_(None)
            elif isinstance(value, (list, tuple)):
                if len(value) == 2 and value[0] in ['>', '<', '>=', '<=', '!=', 'like']:
                    operator, val = value
                    if operator == '>':
                        filter_condition = col > val
                    elif operator == '<':
                        filter_condition = col < val
                    elif operator == '>=':
                        filter_condition = col >= val
                    elif operator == '<=':
                        filter_condition = col <= val
                    elif operator == '!=':
                        filter_condition = col != val
                    elif operator == 'like':
                        filter_condition = col.like(val)
                else:
                    # Handle WHERE IN condition
                    filter_condition = col.in_(value)
            else:
                # Default equality
                filter_condition = col == value

            count += 1
            filter_conditions.append((filter_condition, logic))

        # Combine all conditions
        and_conditions = [cond for cond, logic in filter_conditions if logic == 'AND']
        or_conditions = [cond for cond, logic in filter_conditions if logic == 'OR']

        combined_condition = None
        if and_conditions:
            combined_condition = and_(*and_conditions)
        if or_conditions:
            or_combined = or_(*or_conditions)
            combined_condition = and_(combined_condition, or_combined) if combined_condition else or_combined

        logging.info(f'### _build_filters_bp combined_condition is {combined_condition}')
        return combined_condition

    def update_dict(
        self,
        table_name,
        values,
        and_conditions=None,
        or_conditions=None,
        in_conditions=None,
    ):
        """
        Updates a table in the database using SQLAlchemy.

        Parameters:
        - table_name: The name of the table to update.
        - values: A dictionary of column-value pairs to update.
        - and_conditions: A list of `AND` conditions (tuples of column and value).
        - or_conditions: A list of `OR` conditions (tuples of column and value).
        - in_conditions: A list of `IN` conditions (tuples of column and list of values).

        Example:
        update_table('users', {'name': 'New Name'},
                    and_conditions={'age':30},
                    or_conditions={'city':'New York'},
                    in_conditions={'id':[1, 2, 3]})
        """

        try:
            # Create connection string
            # metadata = MetaData()
            # metadata.bind = self.engine  # Bind the metadata to the engine
            # table = Table(table_name, metadata, autoload_with=self.engine)
            table = self.tables.get(table_name)

            # Create the base update statement
            stmt = update(table).values(**values)

            # Apply AND conditions
            if and_conditions:
                and_clause = and_(
                    *[
                        table.c[column] == value
                        for column, value in and_conditions.items()
                    ]
                )
                stmt = stmt.where(and_clause)

            # Apply OR conditions
            if or_conditions:
                or_clause = or_(
                    *[
                        table.c[column] == value
                        for column, value in or_conditions.items()
                    ]
                )
                stmt = stmt.where(or_clause)

            # Apply IN conditions
            if in_conditions:
                in_clause = and_(
                    *[
                        table.c[column].in_(values)
                        for column, values in in_conditions.items()
                    ]
                )
                stmt = stmt.where(in_clause)
            logging.info("Executing SQL: %s", stmt)
            result = self.engine.execute(stmt)
            self.engine.commit()

            # print("update successful")
            if result.rowcount > 0:
                logging.info("### update_dict Update successful")
                return True
            else:
                logging.info("### update_dict No rows were updated")
                return False

        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            logging.info(f"### update_dict Error updating data: {e}")
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if "conn" in locals() and self.engine:
                self.engine.close()

    def update_dict_back(
        self,
        table_name,
        values,
        and_conditions=None,
        or_conditions=None,
        in_conditions=None,
    ):
        """
        Updates a table in the database using SQLAlchemy.

        Parameters:
        - table_name: The name of the table to update.
        - values: A dictionary of column-value pairs to update.
        - and_conditions: A dictionary of `AND` conditions (tuples of column and value).
        - or_conditions: A dictionary of `OR` conditions (tuples of column and value).
        - in_conditions: A dictionary of `IN` conditions (tuples of column and list of values).

        Example:
        update_dict('users', {'name': 'New Name'},
                    and_conditions={'age': 30, 'id': '123-456-789'},
                    or_conditions={'city': 'New York'},
                    in_conditions={'id': ['123-456-789', '987-654-321']})
        """

        try:
            # Extract and split the schema_tag from values or conditions
            schema_tag = (
                values.pop("schema_tag", None)
                or (and_conditions and and_conditions.pop("schema_tag", None))
                or (or_conditions and or_conditions.pop("schema_tag", None))
                or (in_conditions and in_conditions.pop("schema_tag", None))
            )

            # Split schema_tag by '-' for index use
            schema_tag = schema_tag.split("-") if schema_tag else []
            for ind, tag in enumerate(schema_tag):
                logging.info(f"### update_dict_back schema_tag is {tag} and ind is {ind}")
                # Retrieve the table from the schema specified by schema_tag
                table = self.tables.get(table_name)

                # Function to split the id based on schema_tag index
                def process_id_condition(condition_dict):
                    condition = {}
                    for key, values_list in condition_dict.items():
                        condition[key] = values_list
                        if key == "id" and schema_tag:
                            condition["id"] = condition_dict["id"].split("-")[
                                ind
                            ]  # Use schema_tag index
                    return condition

                # Process the `and_conditions`, `or_conditions`, and `in_conditions`
                and_condition_dict = {}
                if and_conditions:
                    and_condition_dict = process_id_condition(and_conditions)
                or_condition_dict = {}
                if or_conditions:
                    or_condition_dict = process_id_condition(or_conditions)
                in_condition_dict = {}
                if in_conditions:
                    for key, values_list in in_conditions.items():
                        in_condition_dict[key] = values_list
                        if key == "id" and schema_tag:
                            in_condition_dict[key] = [
                                value.split("-")[ind] for value in values_list
                            ]

                logging.info(and_condition_dict, or_condition_dict, in_condition_dict)

                # Create the base update statement
                stmt = update(table).values(**values)

                # Apply AND conditions
                if and_condition_dict:
                    and_clause = and_(
                        *[
                            table.c[column] == value
                            for column, value in and_condition_dict.items()
                        ]
                    )
                    stmt = stmt.where(and_clause)

                # Apply OR conditions
                if or_condition_dict:
                    or_clause = or_(
                        *[
                            table.c[column] == value
                            for column, value in or_condition_dict.items()
                        ]
                    )
                    stmt = stmt.where(or_clause)

                # Apply IN conditions
                if in_condition_dict:
                    in_clause = and_(
                        *[
                            table.c[column].in_(values)
                            for column, values in in_condition_dict.items()
                        ]
                    )
                    stmt = stmt.where(in_clause)

                # Print the statement for debugging purposes
                logging.info(stmt)

                #       Execute the query
                result = self.execute_query(stmt, True, update=[tag])
                self.engine.commit()

            logging.info("### update_dict_back Update successful")
            return True

        except Exception as e:
            # Logging an exception if any error occurs during the process
            logging.exception(f"### update_dict_back Error updating data: {e}")
            return False

        finally:
            # Ensure that the connection is closed
            if "conn" in locals() and self.engine:
                self.engine.close()

    def insert_dict(self, data, table):
        """
        Insert dictionary into a SQL database table.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (bool) True if successfully inserted, else False.
        """
        logging.info(f"Inserting dictionary data into `{table}`...")
        logging.info(f"### insert_dict Data:\n{data}")

        try:

            # metadata = MetaData()
            # metadata.bind = self.engine  # Bind the metadata to the engine
            # table = Table(table, metadata, autoload_with=self.engine)
            table = self.tables.get(table)

            if not isinstance(data, list):
                data = [data]

            stmt = insert(table).values(data)

            # Executing the constructed query with the parameters
            result = self.execute_query(stmt, True, insert=self.fetch_schemas())
            self.engine.commit()

            logging.info("### insert_dict Insert successful")
            return True

        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            logging.exception(f"### insert_dict Error inserting data: {e}")
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if "conn" in locals() and self.engine:
                self.engine.close()

    def update_audit(self, data, table):
        """
        Insert dictionary into a SQL database table.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (bool) True if successfully inserted, else False.
        """
        logging.info(f"### update_audit Inserting dictionary data into `{table}`...")
        logging.info(f"### update_audit Data:\n{data}")

        try:
            # Create connection string
            connection_string = f"{self.DB_TYPE}://{self.USER}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.DATABASE}"

            # Establish database connection
            conn = psycopg2.connect(connection_string)
            cursor = conn.cursor()

            # Extracting column names and values
            column_names = [f'"{column_name}"' for column_name in data.keys()]
            params = list(data.values())

            logging.info(f"### update_audit Column names: {column_names}")
            logging.info(f"### update_audit Params: {params}")

            # Constructing the SQL query dynamically
            columns_string = ", ".join(column_names)
            param_placeholders = ", ".join(["%s"] * len(column_names))
            logging.info(
                f"### update_audit Columns inserting: {columns_string} and values: {param_placeholders}"
            )

            # Making the Insert query
            query = (
                f"INSERT INTO {table} ({columns_string}) VALUES ({param_placeholders})"
            )

            # Executing the constructed query with the parameters
            cursor.execute(query, params)
            conn.commit()

            logging.info("### update_audit Insert successful")
            return True
        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            logging.exception(f"### update_audit Error inserting data: {e}")
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if "cursor" in locals() and cursor:
                cursor.close()
            if "conn" in locals() and conn:
                conn.close()

    def log_error_to_db(self, data, table):
        """
        Insert dictionary into a SQL database table.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (bool) True if successfully inserted, else False.
        """
        logging.info(f"### log_error_to_db Inserting dictionary data into `{table}`...")
        logging.info(f"### log_error_to_db Data:\n{data}")

        try:
            # Create connection string
            connection_string = f"{self.DB_TYPE}://{self.USER}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.DATABASE}"

            # Establish database connection
            conn = psycopg2.connect(connection_string)
            cursor = conn.cursor()

            # Extracting column names and values
            column_names = [f'"{column_name}"' for column_name in data.keys()]
            params = list(data.values())

            logging.info(f"### log_error_to_db Column names: {column_names}")
            logging.info(f"### log_error_to_db Params: {params}")

            # Constructing the SQL query dynamically
            columns_string = ", ".join(column_names)
            param_placeholders = ", ".join(["%s"] * len(column_names))
            logging.info(
                f"### log_error_to_db Columns inserting: {columns_string} and values: {param_placeholders}"
            )

            # Making the Insert query
            query = (
                f"INSERT INTO {table} ({columns_string}) VALUES ({param_placeholders})"
            )

            # Executing the constructed query with the parameters
            cursor.execute(query, params)
            conn.commit()
            # # Send success email
            #     # Create dynamic subject and content for the email
            # service_name = data.get('service_name', '')
            # error_message = data.get('error_message', '')
            # error_type = data.get('error_type', '')
            # timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            #     # Create email subject and content
            # subject = f"Error Notification: {service_name} - {error_type}"
            # content = f"""
            #     <p>Hi,</p>
            #     <p>There was an error reported in the service <strong>{service_name}</strong>:</p>
            #     <p><strong>Error Message:</strong> {error_message}</p>
            #     <p><strong>Error Type:</strong> {error_type}</p>
            #     <p><strong>Timestamp:</strong> {timestamp}</p>
            #     <p>Details:</p>
            #     <pre>{data}</pre>
            #     <p>Please investigate the issue as soon as possible.</p>
            #     """

            #     # Send the email
            # template_name = data.get("template_name", 'Log Errors')
            # to_emails, cc_emails, subject, body, from_email, partner_name = send_email(template_name, content=content, is_html=True)
            # message = "Mail sent successfully"

            logging.info("### log_error_to_db Insert successful")
            return True
        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            logging.exception(f"### log_error_to_db Error inserting data: {e}")
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if "cursor" in locals() and cursor:
                cursor.close()
            if "conn" in locals() and conn:
                conn.close()

    def insert(
        self, data, table, database=None, if_exists="replace", index=False, method=None
    ):
        """
        Write records stored in a DataFrame to a SQL database.

        Args:
            data (DataFrame): The DataFrame that needs to be write to SQL database.
            table (str): The table in which the rcords should be written to.
            kwargs: Keyword arguments for pandas to_sql function.
                See https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.to_sql.html
                to know the arguments that can be passed.

        Returns:
            (bool) True is succesfully inserted, else false.
        """
        # print(f'Inserting into `{table}`')

        try:
            data.to_sql(
                table, self.engine, if_exists=if_exists, index=index, method=method
            )
            return True
        except Exception as e:
            logging.exception(f"### insert exception - {e}")
            return False

    def insert_data(self, data, table):
        """
        Insert dictionary into a SQL database table and return the inserted ID.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (int) The ID of the inserted row if successful, else None.
        """
        logging.info(f"### insert_data Inserting dictionary data into `{table}`...")
        logging.info(f"### insert_data Data:\n{data}")

        try:
            # Get the table object from metadata
            table = self.tables.get(table)

            if not isinstance(data, list):
                data = [data]

            # Assuming the table has an 'id' column to return after insert
            stmt = insert(table).values(data).returning(table.c.id)

            # Executing the constructed query
            result = self.engine.execute(stmt)
            inserted_id = result.scalar()

            # Committing the transaction
            self.engine.commit()

            logging.info(f"### insert_data Insert successful, inserted ID: {inserted_id}")
            return inserted_id

        except Exception as e:
            # Logging any error that occurs during the insertion process
            logging.exception(f"### insert_data Error inserting data: {e}")
            return None

        finally:
            # Ensure that the connection is closed
            if "conn" in locals() and self.engine:
                self.engine.close()

    def get_table_columns(self, table_name):
        query = f"""
        SELECT column_name
        FROM information_schema.columns
        WHERE table_name = '{table_name}'
        ORDER BY ordinal_position;
        """
        return pd.read_sql(query, self.engine)

    def get_columns(self, table):
        """
        Get all column names from an SQL table.
        """
        try:
            logging.info(f"### get_columns Getting column names of table `{table}`")

            # Query to fetch column names from the database schema

            with open(self.file_path, "r") as f:
                schema = json.load(f)

            if table not in schema:
                with open(
                    "/opt/python/lib/python3.9/site-packages/common_utils/schemas/default_schema.json",
                    "r",
                ) as f:
                    schema = json.load(f)

            column_names = []
            for cols in schema[table]:
                column_names.append(cols["name"])

            return column_names

        except Exception as e:
            logging.exception(f"### get_columns Something went wrong getting column names. Error: {e}")
            return []

    def execute_default_index(self, query, **kwargs):
        """
        Executes an SQL query.

        Args:
            query (str): The query that needs to be executed.
            database (str): Name of the database to execute the query in. Leave
                it none if you want use database during object creation.
            params (list/tuple/dict): List of parameters to pass to in the query.

        Returns:
            (DataFrame) A pandas dataframe containing the data from the executed
            query. (None if an error occurs)
        """
        data = None

        try:
            # Execute the SQL query using pandas read_sql function
            data = pd.read_sql(query, self.engine, **kwargs).replace({pd.np.nan: None})
        except exc.ResourceClosedError:
            # Handle the case where the query is executed successfully but returns no data
            return True
        except Exception as e:
            # Log and handle any other exceptions that occur during query execution
            logging.info(f"### execute_default_index Something went wrong while executing query. Check trace. {e}")
            # params = kwargs["params"] if "params" in kwargs else None
            return False

        return data.where((pd.notnull(data)), None)

    def delete_data(
        self, table_name, and_conditions=None, or_conditions=None, in_conditions=None
    ):
        """
        Deletes rows from a table in the database using SQLAlchemy.
        """
        # Fetch the table object
        table = self.tables.get(table_name)
        if table is None:
            raise ValueError(f"Table {table_name} not found.")
        logging.info(f"### delete_data Table found: {table}")

        # Start with a base delete statement
        stmt = delete(table)

        # Construct AND conditions
        if and_conditions:
            and_clauses = [
                table.c[column] == value for column, value in and_conditions.items()
            ]
            stmt = stmt.where(and_(*and_clauses))

        # Construct OR conditions
        if or_conditions:
            or_clauses = [
                table.c[column] == value for column, value in or_conditions.items()
            ]
            stmt = stmt.where(or_(*or_clauses))

        # Construct IN conditions
        if in_conditions:
            in_clauses = [
                table.c[column].in_(values) for column, values in in_conditions.items()
            ]
            stmt = stmt.where(and_(*in_clauses))

        # Debugging: Print the final delete statement
        logging.info(f"### delete_data Final delete statement: {stmt}")

        # Execute the delete statement using self.engine.execute() directly
        result = self.engine.execute(stmt)

        # Commit the changes
        self.engine.commit()

        logging.info("### delete_data Delete operation successful.")
        return True
    
    def bulk_update_data(self, table_name, data_list, search_column="id", static_conditions=None):
        """
        Perform a bulk update on multiple records at once.
        """
        if not data_list:
            logging.info("No data provided for bulk update.")
            return False
    
        try:
            table_obj = self.tables.get(table_name)
            if table_obj is None:
                raise ValueError(f"Table '{table_name}' not found.")
    
            columns_to_update = list(data_list[0].keys())
            if search_column in columns_to_update:
                columns_to_update.remove(search_column)
    
            update_values = {}
            record_ids = [record[search_column] for record in data_list]
    
            for col in columns_to_update:
                # Create list of (condition, value) tuples and unpack as positional args
                cases = [(table_obj.c[search_column] == record[search_column], record[col]) for record in data_list]
                update_values[col] = case(*cases, else_=table_obj.c[col])
    
            stmt = update(table_obj).values(update_values)
            stmt = stmt.where(table_obj.c[search_column].in_(record_ids))
    
            if static_conditions:
                for col, val in static_conditions.items():
                    stmt = stmt.where(table_obj.c[col] == val)
    
            logging.info("### bulk_update_data Final Update Statement:")
    
            # Execute directly without begin() to avoid nested transaction error
            result = self.engine.execute(stmt)
            self.engine.commit()  # commit manually if using plain engine
    
            logging.info(f"### bulk_update_data Update successful. {result.rowcount} rows affected.")
            return result.rowcount > 0
    
        except Exception as e:
            logging.exception(f"### bulk_update_data Error: {e}")
            return False
    
    def bulk_update(
        self,
        table_name,
        column_to_update,
        search_column,
        old_values,
        new_values,
        static_conditions=None
    ):
        '''
        Perform a bulk update on a specified column in a table using a CASE WHEN expression.
        Parameters:
        - table_name: Name of the table to update.
        - column_to_update: The column to update with new values.
        - search_column: The column to search for old values.
        - old_values: List of old values to search for.
        - new_values: List of new values to set in the column_to_update.
        - static_conditions: Optional dictionary of static conditions to apply in the WHERE clause.
        Example:
        bulk_case_update(
            table_name='my_table',
            column_to_update='status',
            search_column='id',
            old_values=[1, 2, 3],
            new_values=['active', 'inactive', 'pending'],
            static_conditions={'is_active': True, 'tenant_name': 'tenant1'}
        )
        '''
        try:
            if not old_values or not new_values or len(old_values) != len(new_values):
                raise ValueError("old_values and new_values must be non-empty and same length")
    
            table_obj = self.tables.get(table_name)
            if table_obj is None:
                raise ValueError(f"Table '{table_name}' not found.")
    
            # Build CASE WHEN expression
            value_mapping = {old: new for old, new in zip(old_values, new_values)}
            case_expr = case(value_mapping, value=table_obj.c[search_column])
    
            # Start building the update statement
            stmt = update(table_obj).values({column_to_update: case_expr})
    
            # Add WHERE search_column IN (...)
            stmt = stmt.where(table_obj.c[search_column].in_(old_values))
    
            # Add static conditions like is_active = TRUE, tenant_name = ...
            if static_conditions:
                for col, val in static_conditions.items():
                    stmt = stmt.where(table_obj.c[col] == val)
    
            logging.info("### bulk_update Final Update Statement:")
            result = self.engine.execute(stmt)
            self.engine.commit()
    
            if result.rowcount > 0:
                logging.info(f"### bulk_update Update successful. {result.rowcount} rows affected.")
                return True
            else:
                logging.info("### bulk_update No rows were updated.")
                return False
    
        except Exception as e:
            logging.exception(f"### bulk_update Error during bulk_case_update: {e}")
            return False
    
        finally:
            if self.engine:
                self.engine.close()
