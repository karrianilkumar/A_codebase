# Importing the necessary Libraries
# from py_zipkin.storage import get_default_tracer
# import logging
# import logging.config
# import logging.handlers
# import subprocess
# import os
# import traceback
# from inspect import getframeinfo, stack


# def sanitize_msg(msg):
#     """Sanitizes the input message by converting it to an ASCII-safe string, ignoring non-ASCII characters."""
#     try:
#         msg = ascii(msg)
#     except Exception as e:
#         logging.warning(f"Failed to sanitize message to ASCII: {e}")
#     return msg


# class Logging(logging.Logger):
#     def __init__(self, name="common_services", **kwargs):
#         """Initializes the logging utility with a custom configuration, log levels, and optional context identifiers."""
#         super().__init__(name)
#         self.log_levels = {
#             "debug": logging.DEBUG,
#             "info": logging.INFO,
#             "warning": logging.WARNING,
#             "error": logging.ERROR,
#             "critical": logging.CRITICAL,
#         }
#         new_conf = "/opt/python/lib/python3.9/site-packages/common_utils/logging.conf"
#         self.load_logging_conf(new_conf)

#         self.extra = {"tenantID": None, "service_name": name}
#         self.set_ids(**kwargs)

#     def load_logging_conf(self, file_path):
#         """Loads logging configuration from the specified file and sets the default log level to INFO."""
#         logging.config.fileConfig(file_path)
#         logging.getLogger().setLevel(self.log_levels["info"])

#     def set_ids(self, **kwargs):
#         """
#         Sets contextual logging identifiers such as service name, file name, line number, 
#         and current function name based on the caller's stack frame. These values are stored 
#         in the `self.extra` dictionary to enrich log entries.
#         """
#         service_name = None
#         line_no = None
#         file_name = None
#         current_func_name = None

#         try:
#             caller = getframeinfo(stack()[2][0])
#             file_name = caller.filename
#             line_no = caller.lineno
#             current_func_name = caller.function
#         except Exception as e:
#             message = "Failed to get caller stack"
#             logging.error("########", message, e)

#         self.service_name = service_name
#         self.line_no = line_no
#         self.file_name = file_name
#         self.current_func_name = current_func_name
#         self.extra = {
#             "service_name": self.service_name,
#             "fileName": self.file_name,
#             "lineNo": self.line_no,
#             "currentFuncName": self.current_func_name,
#         }

#     def basicConfig(self, *args, **kwargs):
#         """Initializes the basic logging configuration using the provided keyword arguments."""
#         logging.basicConfig(**kwargs)

#     def debug(self, msg, *args, **kwargs):
#         """Logs a debug-level message with contextual metadata after sanitizing the message."""
#         self.set_ids()
#         msg = sanitize_msg(msg)
#         logging.debug(msg, extra=self.extra, *args, **kwargs)

#     def info(self, msg, *args, **kwargs):
#         """Logs an info-level message with contextual metadata after sanitizing the message."""
#         self.set_ids()
#         msg = sanitize_msg(msg)
#         logging.info(msg, extra=self.extra, *args, **kwargs)

#     def warning(self, msg, *args, **kwargs):
#         """Logs a warning-level message with contextual metadata after sanitizing the message."""
#         self.set_ids()
#         msg = sanitize_msg(msg)
#         logging.warning(msg, extra=self.extra, *args, **kwargs)

#     def error(self, msg, *args, **kwargs):
#         """Logs an error-level message with contextual metadata after sanitizing the message."""
#         self.set_ids()
#         msg = sanitize_msg(msg)
#         logging.error(msg, extra=self.extra, *args, **kwargs)

#     def critical(self, msg, *args, **kwargs):
#         """Logs a critical-level message with contextual metadata after sanitizing the message."""
#         self.set_ids()
#         msg = sanitize_msg(msg)
#         logging.critical(msg, extra=self.extra, *args, **kwargs)

#     def exception(self, msg, *args, **kwargs):
#         """Logs an error-level message along with exception traceback and contextual metadata."""
#         self.set_ids()
#         msg = sanitize_msg(msg)
#         logging.exception(msg, extra=self.extra, *args, **kwargs)

#     def getLogger(self, name=None):
#         """Returns a logger instance with the specified name."""
#         return logging.getLogger(name=name)

#     def disable(self, level):
#         """Disables all logging calls of severity 'level' and below."""
#         logging.disable(level)


# Importing the necessary Libraries
from py_zipkin.storage import get_default_tracer
import logging
import logging.config
import logging.handlers
import subprocess
import os
import traceback
import common_utils
from inspect import getframeinfo, stack


def sanitize_msg(msg):
    try:
        msg = ascii(msg)
    except:
        pass
    return msg


class Logging:
    def __init__(self, name="common_services", **kwargs):
        self.log_levels = {
            "debug": logging.DEBUG,
            "info": logging.INFO,
            "warning": logging.WARNING,
            "error": logging.ERROR,
            "critical": logging.CRITICAL,
        }
        package_dir = os.path.dirname(__file__)
        new_conf = "/opt/python/lib/python3.9/site-packages/common_utils/logging.conf"
        self.load_logging_conf(new_conf)
        self.logger = logging.getLogger(name)
        self.extra = {"tenantID": None, "service_name": name}
        self.set_ids(**kwargs)

    def load_logging_conf(self, file_path):
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"{file_path} doesn't exist")
        logging.config.fileConfig(file_path, disable_existing_loggers=False)

    def set_ids(self, **kwargs):
        try:
            caller = getframeinfo(stack()[2][0])
            self.extra.update({
                "fileName": os.path.basename(caller.filename),
                "lineNo": caller.lineno,
                "currentFuncName": caller.function,
            })
        except Exception as e:
            self.logger.warning("Could not extract caller context: %s", e)

    def debug(self, msg, *args, **kwargs):
        self.set_ids()
        self.logger.debug(sanitize_msg(msg), extra=self.extra, *args, **kwargs)

    def info(self, msg, *args, **kwargs):
        self.set_ids()
        self.logger.info(sanitize_msg(msg), extra=self.extra, *args, **kwargs)

    def warning(self, msg, *args, **kwargs):
        self.set_ids()
        self.logger.warning(sanitize_msg(msg), extra=self.extra, *args, **kwargs)

    def error(self, msg, *args, **kwargs):
        self.set_ids()
        self.logger.error(sanitize_msg(msg), extra=self.extra, *args, **kwargs)

    def critical(self, msg, *args, **kwargs):
        self.set_ids()
        self.logger.critical(sanitize_msg(msg), extra=self.extra, *args, **kwargs)

    def exception(self, msg, *args, **kwargs):
        self.set_ids()
        self.logger.exception(sanitize_msg(msg), extra=self.extra, *args, **kwargs)
