"""
Module for sending emails using SendGrid.
This module provides a function to send emails using the SendGrid API.

@Author1 : Phaneendra.Y
@Author2 : Burhan

Created Date: June 06, 2024
"""

import re
import os
import base64
import time
import json
import pandas as pd
import psutil
import boto3
import datetime
from sendgrid import SendGridAPIClient

# from sendgrid.exceptions import SendGridException
from sendgrid.helpers.mail import (
    Mail,
    Content,
    Attachment,
    FileContent,
    FileName,
    FileType,
    Disposition,
)
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging

# Dictionary to store database configuration settings retrieved from environment variables.
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}
logging = Logging(name="email_trigger")


sns = boto3.client("sns")
cloudwatch = boto3.client("cloudwatch")


def send_sns_email(subject, message):
    """Send an email via SNS when memory are breached."""
    response = sns.publish(
        # TopicArn='arn:aws:sns:us-east-1:008971638399:custom-alert',
        TopicArn=os.environ["ALERT"],
        Message=message,
        Subject=subject,
    )
    return response


def get_memory_usage():
    """Get the current memory usage in MB."""
    process = psutil.Process()
    memory_info = process.memory_info()
    logging.info(memory_info.rss / (1024 * 1024))
    return memory_info.rss / (1024 * 1024)


def memory_sns(memory_limit, memory_used, context):
    if memory_used > 0.8 * memory_limit:
        subject = "Lambda Memory Usage Alert"
        message = f"Warning: Memory usage has exceeded allocated limit.\n\nDetails:\nMemory Used: {memory_used} MB\nMemory Limit: {memory_limit} MB\nFunction: {context.function_name}\nRequest ID: {context.aws_request_id}"
        template_name = "lambda ram exceeded"
        request_received_at = datetime.now()
        send_sns_email(subject, message)
        insert_email_audit(subject, message, request_received_at, template_name)
        logging.info("###mail sent")
        # subject, message, template_name, request_received_at = result


def insert_email_audit(subject, message, request_received_at, template_name):
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        # Email audit
        email_audit_data = {
            "template_name": template_name,
            "email_type": "AWS",
            "partner_name": "Altaworx",
            "email_status": "success",
            "from_email": "sns.amazon.com",
            "to_email": "AWS sns mails",
            "comments": "update inventory data",
            "subject": subject,
            "body": message,
            "role": "admin",
        }
        common_utils_database.update_audit(email_audit_data, "email_audit")
        logging.info("data inserted into database.")
    except Exception as e:
        logging.info(f"Error inserting email audit data: {e}")


def replace_placeholders_with_table(
    text, record_id="", template_type="", username="", data_dict=None, database=""
):
    """
    Replace placeholders with actual values from the database and include tabular data based on date range.

    :param text: The text containing placeholders and table details in the list format.
    :param record_id: The id to use as the WHERE condition.

    :return: Text with placeholders replaced by actual values.
    """

    # Find all placeholders using regex, matches patterns like {"table":"column"}
    placeholders = re.findall(r'\{"(.*?)":"(.*?)"\}', text)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        database = DB("altaworx_test", **db_config)
    except Exception as e:
        database = DB("altaworx_central", **db_config)
    # Find table structure inside the text: ["users", "username, temp_password", "2024-01-01", "2025-01-01"]
    table_structure = re.findall(r"\[(.*?)\]", text)
    logging.info("enter here", template_type)
    if table_structure:
        # Extract table name, columns, start date, and end date
        for structure in table_structure:
            table_data = structure.replace('"', "").split(",")
            table_name = table_data[0].strip()
            if table_name in [
                "tenant",
                "roles",
                "users",
                "amop_apis",
                "carrier_apis",
                "mapping_table",
                "master_amop_apis",
                "master_carrier_apis",
                "master_roles",
                "module",
                "tenant_module",
                "module_features",
                "service_accounts",
            ]:
                database = common_utils_database  # Use common_utils connection
            else:
                database = database  # Use tenant-specific connection
            columns = table_data[1].strip().split()  # Multiple columns
            start_date = table_data[2].strip()
            end_date = table_data[3].strip()

            # Query to get data from columns in the date range (assuming there's a date column in the table)
            query = f"SELECT {', '.join(columns)} FROM {table_name} WHERE created_date BETWEEN %s AND %s"
            params = [start_date, end_date]
            result = database.execute_query(query, params=params)

            # If the result is not empty, create a table (DataFrame) from the result
            if result is not None and not result.empty:
                # Convert the result to a pandas DataFrame for tabular display
                df = pd.DataFrame(result, columns=columns)

                # Convert the DataFrame to a string format (this can be HTML or plain text)
                table_string = df.to_string(index=False)

                # Replace the table structure in the text with the tabular data
                text = text.replace(f"[{structure}]", f"\n{table_string}\n")
            else:
                # Replace the table structure with an empty string if no data found
                text = text.replace(f"[{structure}]", "")
    if template_type == "Status Template":
        # Handle regular placeholders like {"table":"column"}
        for table_name, column_name in placeholders:
            if table_name in [
                "tenant",
                "roles",
                "users",
                "amop_apis",
                "carrier_apis",
                "mapping_table",
                "master_amop_apis",
                "master_carrier_apis",
                "master_roles",
                "module",
                "tenant_module",
                "module_features",
                "service_accounts",
            ]:
                database = common_utils_database  # Use common_utils connection
            else:
                database = database  # Use tenant-specific connection
            query = f"SELECT {column_name} FROM {table_name} WHERE id = %s"
            params = [record_id]
            result = database.execute_query(query, params=params)

            if result is not None and not result.empty:
                value = result.iloc[0, 0]
                placeholder = f'{{"{table_name}":"{column_name}"}}'
                text = text.replace(placeholder, str(value))
            else:
                text = text.replace(f'{{"{table_name}":"{column_name}"}}', "")
    elif template_type == "User Based":
        # Handle regular placeholders like {"table":"column"}
        for table_name, column_name in placeholders:
            if table_name in [
                "tenant",
                "roles",
                "users",
                "amop_apis",
                "carrier_apis",
                "mapping_table",
                "master_amop_apis",
                "master_carrier_apis",
                "master_roles",
                "module",
                "tenant_module",
                "module_features",
                "service_accounts",
            ]:
                database = common_utils_database  # Use common_utils connection
            else:
                database = database  # Use tenant-specific connection
            query = f"SELECT {column_name} FROM {table_name} WHERE username = %s"
            params = [username]
            result = database.execute_query(query, params=params)

            if result is not None and not result.empty:
                value = result.iloc[0, 0]
                placeholder = f'{{"{table_name}":"{column_name}"}}'
                text = text.replace(placeholder, str(value))
            else:
                text = text.replace(f'{{"{table_name}":"{column_name}"}}', "")
    elif (
        template_type == "Payload Based" and data_dict is not None
    ) or template_type == "Payload Data":
        # logging.info(placeholders, "333333333333333")
        for table_name, column_name in placeholders:
            if table_name in [
                "tenant",
                "roles",
                "users",
                "amop_apis",
                "carrier_apis",
                "mapping_table",
                "master_amop_apis",
                "master_carrier_apis",
                "master_roles",
                "module",
                "tenant_module",
                "module_features",
                "service_accounts",
            ]:
                database = common_utils_database  # Use common_utils connection
            else:
                database = database  # Use tenant-specific connection
            key = column_name  # In this case, we'll assume column_name matches the keys in `data`
            # logging.info(key, "eeeeeeeeeeeeeeeeeeeeeee")

            # If the key exists in data, replace the placeholder
            if key in data_dict:
                value = data_dict[key]
                # logging.info(value, "33333344444444444444444444443333333")
                # Check if the current key is 'sim_info' to format JSON correctly
                # If the key exists in data_dict, replace the placeholder
                # Check if the current key is 'sim_info' to format JSON correctly
                if key == "sim_info":
                    # Convert the JSON string to a Python object (list of dicts)
                    try:
                        # sim_info_list = json.loads(value)  # Parse the JSON string
                        # # Construct the formatted string
                        # json_string = ', '.join(
                        #     f'Carrier: {item["carrier"]}, SIM Size: {item["SIM Size"]}, Quantity: {item["Quantity"]}'
                        #     for item in sim_info_list
                        # )
                        # final_value = json_string  # Set final_value to the constructed json_string
                        sim_info_list = json.loads(value)  # Parse the JSON string

                        # Construct the HTML table
                        html_table = """
                        <table border="1" style="border-collapse: collapse; width: 100%;">
                            <tr>
                                <th style="padding: 10px; background-color: #f2f2f2;">Carrier</th>
                                <th style="padding: 10px; background-color: #f2f2f2;">SIM Size</th>
                                <th style="padding: 10px; background-color: #f2f2f2;">Quantity</th>
                            </tr>
                        """

                        # Add rows to the table
                        for item in sim_info_list:
                            html_table += f"""
                            <tr>
                                <td style="padding: 10px;">{item['carrier']}</td>
                                <td style="padding: 10px;">{item['SIM Size']}</td>
                                <td style="padding: 10px;">{item['Quantity']}</td>
                            </tr>
                            """

                        html_table += "</table>"  # Close the table
                        final_value = (
                            html_table  # Set final_value to the constructed HTML table
                        )
                        # logging.info(f'Formatted sim_info as HTML table:\n{final_value}///////////////////////')  # Debug logging.info
                    except json.JSONDecodeError:
                        final_value = "Invalid JSON"
                        # logging.info(final_value, "mmmmmmmmmmmmmmmmm")  # Error handling for invalid JSON
                else:
                    final_value = str(value)  # Convert other values to string
                    # logging.info(f'Final value for {key}: {final_value};;;;;;;;;;;;;;;;;;;;;;;;;')  # Debug logging.info

                # Replace the placeholder in the text with the final_value
                placeholder = f'{{"{table_name}":"{column_name}"}}'
                text = text.replace(
                    placeholder, final_value
                )  # Use final_value for replacement
                # logging.info(text, "text, qaaaaaaaaaaaaaaaaaaaaaaaaa")

            else:
                # If key does not exist, remove the placeholder
                text = text.replace(f'{{"{table_name}":"{column_name}"}}', "")
    else:
        pass

    return text


def create_attachment_from_blob(blob_data, filename):
    """
    Create an attachment from blob data.

    Args:
        blob_data (bytes): Binary data of the file to attach.
        filename (str): The name of the file being attached.

    Returns:
        Attachment: The SendGrid attachment object.
    """
    encoded_file = base64.b64encode(blob_data).decode()  # Encode blob data to base64

    return Attachment(
        FileContent(encoded_file),
        FileName(filename),  # Provide the filename for the attachment
        FileType("application/octet-stream"),  # Adjust MIME type if necessary
        Disposition("attachment"),  # Marks it as an attachment
    )


def prepare_email_message(from_email, to_emails, **kwargs):
    """
    Prepare the email message object.

    Args:
        from_email (str): The sender's email address.
        to_emails (list): List of recipient email addresses.
        subject (str): Email subject.
        content (str): Email content.
        cc_emails (list): List of CC email addresses.
        is_html (bool): Whether the content is HTML or plain text.

    Returns:
        Mail: The SendGrid Mail object.
    """
    subject = kwargs.get("subject")
    content = kwargs.get("content")
    cc_emails = kwargs.get("cc_emails")
    is_html = kwargs.get("is_html")

    message = Mail(from_email=from_email, to_emails=to_emails, subject=subject)
    message.add_content(Content("text/html" if is_html else "text/plain", content))
    for cc_email in cc_emails:
        message.add_cc(cc_email)
    return message


def send_email(template_name, **kwargs):
    """
    Send an email using SendGrid with retry logic.

    Args:
        template_name (str): Name of the email template.
        content (str): Email content.
        is_html (bool): Whether the content is HTML or plain text.

    Returns:
        bool: True if the email was sent successfully, False otherwise.
    """
    max_retries = 3  # Set the number of retries
    retry_delay = 5  # Delay between retries in seconds

    is_html = kwargs.get("is_html", True)
    record_id = kwargs.get("id", "")
    username = kwargs.get("username", "")
    user_mail = kwargs.get("user_mail", "")
    data_dict = kwargs.get("data_dict", None)
    # tenant_database = kwargs.get("tenant_database", "altaworx_central")
    try:
        database = DB("altaworx_central", **db_config)
    except:
        database = DB("altaworx_test", **db_config)

    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    # Retrieve template data
    template_data_dataframe = common_utils_database.get_data(
        "email_templates", {"template_name": template_name}
    )
    email_status = template_data_dataframe.iloc[0]["email_status"]
    if email_status == False:
        response = {"flag": True, "message": "the email template status is disabled"}
        return response
    # Extract data from the template
    cc_emails = template_data_dataframe.iloc[0]["cc_mail"] or []
    partner_name = template_data_dataframe.iloc[0]["partner_name"] or ""
    template_type = template_data_dataframe.iloc[0]["template_type"] or ""
    role_based = template_data_dataframe.iloc[0]["role_based"]
    if role_based:
        # Fetch data from the database where tenant_name is the partner and role is the specified role
        email_dataframe = common_utils_database.get_data(
            "users",
            {"tenant_name": partner_name, "role": role_based, "is_active": True},
            ["email"],
        )
        # Extract the 'email' column and convert it to a list (if it's not already)
        email_list = email_dataframe["email"].tolist()
        # Join the list into a comma-separated string (if needed)
        to_emails = ",".join(email_list)
    else:
        if template_name == "Forgot password":
            to_emails = user_mail
        else:
            to_emails = template_data_dataframe.iloc[0]["to_mail"] or []
    if not to_emails:
        raise ValueError(
            "Error: 'to_emails' is empty. Cannot proceed with sending the email."
        )
    common_utils_database = DB("common_utils", **db_config)
    email_credientials = common_utils_database.get_data(
        "tenant",
        {"tenant_name": "Altaworx", "is_active": True},
        ["from_email", "sendgrid_api"],
    )
    sendgrid_email = email_credientials.iloc[0]["from_email"]
    sendgrid_api_key = email_credientials.iloc[0]["sendgrid_api"]
    subject = (
        template_data_dataframe.iloc[0]["subject"]
        or kwargs.get("subject", "")
        or "Default Subject"
    )
    # attachments = template_data_dataframe.iloc[0]['attachments'] or []  #this contains blob data
    body = template_data_dataframe.iloc[0]["body"] or kwargs.get("body", "") or ""
    body = body.replace("\n", "<br>")
    attachments = kwargs.get("attachments", None)
    try:
        body = replace_placeholders_with_table(
            text=body,
            record_id=record_id,
            template_type=template_type,
            username=username,
            data_dict=data_dict,
            database=database,
        )
    except Exception as e:
        logging.info("Error: 'Issue with the Body replacing the placeholders.'")

    # Add the external user warning at the bottom in red
    external_warning = '<br><br><p style="color: red;">This message is from an external user. Be cautious when opening attachment files or links.</p>'
    body += external_warning  # Append the warning at the bottom

    # Handle missing 'to_emails' or 'subject'
    if not to_emails:
        logging.info("Error: 'to_emails' is missing.")
        return False

    if not subject:
        logging.info("Error: 'subject' is missing.")
        return False

    # Prepare email content
    from_email = str(sendgrid_email)
    # from_email = "notifications@amop.services"  # Verified email for SendGrid
    message = prepare_email_message(
        from_email=from_email,
        to_emails=to_emails.split(","),  # Handle multiple emails as a list
        subject=subject,
        content=body,
        cc_emails=cc_emails.split(",") if cc_emails else [],
        is_html=is_html,
    )
    # ##adding the attachments
    if isinstance(attachments, list):
        for attachment in attachments:

            if (
                isinstance(attachment, dict)
                and "blob_data" in attachment
                and "filename" in attachment
            ):
                blob_data = attachment["blob_data"]
                filename = attachment["filename"]

                if blob_data and filename:
                    try:
                        # Create and add the attachment
                        attachment_part = create_attachment_from_blob(
                            blob_data, filename
                        )
                        message.add_attachment(attachment_part)
                    except Exception as e:
                        logging.info(f"Error adding attachment {filename}: {e}")
                        return {
                            "flag": False,
                            "message": f"Failed to add attachment: {filename}",
                        }
            else:
                logging.info(f"Unexpected attachment format: {attachment}")
    if isinstance(attachments, bytes):
        # Handle single attachment case
        try:
            # Add the attachment (blob data is already base64 encoded)
            attachment_part = Attachment(
                FileContent(attachments.decode()),  # Decode base64 bytes to string
                FileName("report.xlsx"),  # Provide the filename for the attachment
                FileType(
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                ),  # Proper MIME type for Excel
                Disposition("attachment"),
            )
            message.add_attachment(attachment_part)
        except Exception as e:
            logging.info(f"Error adding attachment: {e}")
            return {"flag": False, "message": f"Failed to add attachment"}

    # Retry logic
    attempt = 0
    while attempt < max_retries:
        try:
            try:
                # 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   our sendgrid api key
                sendgrid_initialization = SendGridAPIClient(
                    # "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"
                    str(sendgrid_api_key)
                )
                response = sendgrid_initialization.send(message)
                # logging.info(f"Email sent! Status code: {response.status_code}")
                return to_emails, cc_emails, subject, body, from_email, partner_name
            except Exception as e:
                logging.warning(f"SendGrid error: {e}")  # Log SendGrid error message
                return {
                    "flag": False,
                    "message": "Email failed to send after retries",
                    "to_emails": to_emails,
                    "cc_emails": cc_emails,
                    "subject": subject,
                    "body": body,
                    "from_email": from_email,
                    "partner_name": partner_name,
                }
        except Exception as error:
            attempt += 1
            logging.warning(f"Attempt {attempt}: An unexpected error occurred: {error}")
            if attempt < max_retries:
                logging.warning(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logging.warning("Max retries reached. Email failed to send.")
                break

    return False
