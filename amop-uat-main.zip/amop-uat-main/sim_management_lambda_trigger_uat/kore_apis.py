"""
@Author1 : Phaneendra.Y
@Author2 : Burhan
@Author3 : Gopi Teja B
@Created Date: 2025-02-03
"""

# Importing the necessary Libraries
import requests
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import *
import json
import base64
from common_utils.kore import *

logging = Logging(name="kore_apis")


def get_access_token(client_id, client_secret):
    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
    }
    token_url = "https://api.korewireless.com/Api/api/token"
    try:
        response = requests.post(token_url, data=payload)
        response.raise_for_status()
        token_data = response.json()
        access_token = token_data.get("access_token")
        if access_token:
            print("Access Token Generated Successfully:")
            print(f"Access Token: {access_token}")  # Debugging: Print the token
            return access_token
        else:
            print("Error: Access token not found in response.")
            print(token_data)
            return None
    except requests.exceptions.RequestException as e:
        print(f"Error fetching access token: {e}")
        return None


def get_account_id(api_key=None):
    # email = os.environ['EMAIL']
    email = "czambrano@spectrotel.com"
    database = DB("common_utils", **db_config)
    base_url = database.get_data("integration", {"name": "Kore"})["website"].to_list()[
        0
    ]
    url = f"{base_url}v1/accounts?email={email}"
    details = database.get_data(
        "integration_authentication",
        {"integration_id": "19", "tenant_id": "1", "service_provider_id": "126"},
        ["oauth2_client_id", "oauth2_client_secret", "token_value"],
    )
    client_id = details["oauth2_client_id"].to_list()[0]
    client_secret = details["oauth2_client_secret"].to_list()[0]
    api_key = details["token_value"].to_list()[0]
    access_token = get_access_token(client_id, client_secret)
    logging.info("Access Token of Kore got Generated")
    headers = {"Accept": "application/json", "Authorization": f"Bearer {access_token}"}
    if api_key:
        headers["x-api-key"] = api_key  # Include API Key if required
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        account_data = response.json()

        # Extract account-id from the list inside 'account'
        accounts = account_data.get("account", [])
        if accounts and isinstance(accounts, list):
            account_id = accounts[0].get(
                "account-id"
            )  # Get the first account's account-id
            print("Account Details:")
            print(account_data)
            return account_id, access_token
        else:
            print("Error: No accounts found or invalid response structure.")
            return None
    except requests.exceptions.RequestException as e:
        print(f"Error fetching account ID: {e}")
        print(f"Response: {response.text}")  # Debugging: Log the raw response
        return None


def send_core_request(cost_center_pk, subscription_id, account_id, access_token):
    try:
        url = f"https://api.korewireless.com/connectivity/v1/accounts/{account_id}/subscription-requests/cost-center"

        payload = json.dumps(
            [{"cost-center-pk": cost_center_pk, "subscription-id": subscription_id}]
        )
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "x-api-key": "FwEO4B4Fqq28VPsaetYh59xZ75wsUpow98XCbUFC",
            "Authorization": f"Bearer {access_token}",
        }

        response = requests.request("POST", url, headers=headers, data=payload)
        return {"flag": True, "response": response.text}
        # print(response.text, "222222")
        # print(response.status_code, "3333333")
    except Exception as e:
        print(f"Exception is {e}")
        message = (
            "Something went wrong fetching sessionid and sessiontoken using  Zitadel"
        )
        response = {"flag": False, "message": message}
        return response


def send_provisioning_request(
    base_url, account_id, action, iccid, subscription_id, mail_to, access_token, api_key
):
    """
    Function to send provisioning requests (terminate, suspend, reactivate, deactivate) to the API.
    Parameters:
        base_url (str): The base URL for the API.
        account_id (str): The account ID.
        action (str): The action to be performed (terminate, suspend, reactivate, deactivate).
        iccid (str): The ICCID of the subscription.
        subscription_id (str): The subscription ID.
        mail_to (str): The email address to send notifications to.
        force_enabled_esim (bool, optional): If the action is "terminate", whether to force terminate eSIM profiles.
    Returns:
        dict: The response JSON from the API.
    """

    try:
        url = f"{base_url}/v1/accounts/{account_id}/provisioning-requests/{action}"
        # Construct the subscription object from iccid and subscription_id
        subscriptions = [{"subscription-id": subscription_id, "iccid": iccid}]
        # Construct the payload
        payload_data = {action: {"subscriptions": subscriptions, "mail-to": mail_to}}
        # Convert payload to JSON
        payload = json.dumps(payload_data)
        # Set headers
        final_headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
            "x-api-key": api_key,
        }
        # Send the request
        response = requests.post(url, headers=final_headers, data=payload)
        # Return the response text (or you could return the JSON response)
        response_data = {
            "flag": True,
            "response": response.text,
            "status_code": response.status_code,
            "response_json": response.json(),
        }
        return response_data
    except Exception as e:
        print(f"Exception is {e}")
        message = f"Something went wrong fetching update status in   korewireless{e}"
        response = {"flag": False, "message": message}
        return response


def activate_provisioning_request(
    base_url,
    account_id,
    subscription_id,
    iccid,
    imei,
    activation_profile_id,
    mail_to,
    access_token,
    api_key,
):
    """
    Activate provisioning request for a given account and subscription.
    :param base_url: The base URL of the API
    :param headers: The headers to include in the request (including Content-Type and Accept)
    :param account_id: The account ID for the provisioning request
    :param activation_state: The activation state (e.g., 'ACTIVATED', 'DEACTIVATED')
    :param subscription_id: The subscription ID to be activated
    :param iccid: The ICCID associated with the subscription
    :param imei: The IMEI associated with the subscription
    :param mail_to: The email address to send activation information to
    :param activation_profile_id: The activation profile ID
    :param sku: The SKU associated with the activation
    :return: JSON response or an error message
    """
    url = f"{base_url}/v1/accounts/{account_id}/provisioning-requests/activate"

    # Construct the payload
    payload = {
        "activate": {
            "activation-state": "active",
            "subscriptions": [
                {"subscription-id": subscription_id, "iccid": iccid, "imei": imei}
            ],
            # "mail-to": mail_to,
            "activation-profile-id": activation_profile_id,
        }
    }
    final_headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
        "x-api-key": api_key,
    }
    try:
        # Make the POST request
        response = requests.post(url, headers=final_headers, data=payload)
        print(
            "Kore Device Status-Activation, Carrier request response",
            response.status_code,
        )
        print(
            "Kore Device Status-Activation, Carrier request response", response.json()
        )
        if response.status_code in (200, 201):
            # Return the JSON response
            response_data = {
                "flag": True,
                "response": response.text,
                "status_code": response.status_code,
                "response_json": response.json(),
            }
            return response_data
        else:
            response_data = {
                "flag": False,
                "response": response.text,
                "status_code": response.status_code,
                "response_json": response.json(),
            }
            return response_data
    except requests.exceptions.RequestException as e:
        print(f"Kore Device Status-Activation, Carrier request an error occurred: {e}")
        response_data = {"flag": False, "response": e}
        return response_data


def base64_encode(plain_text):
    # Convert the plain text to bytes, then encode it in Base64
    plain_text_bytes = plain_text.encode("utf-8")
    base64_encoded = base64.b64encode(plain_text_bytes).decode("utf-8")
    return base64_encoded


def base64_decode(base64_encoded_data):
    # Decode the Base64 string to bytes
    base64_encoded_bytes = base64.b64decode(base64_encoded_data)
    # Convert the bytes back to a UTF-8 string
    decoded_string = base64_encoded_bytes.decode("utf-8")
    return decoded_string


def send_revio_request(service_id, username, password, token, main_url, cost_center):
    """
    Sends a GET request to the Revio API for a specific service ID and updates the CostCenter1 if present.
    Args:
        service_id (str): The service ID for which the request is being made.
        username (str): The username for authentication.
        password (str): The password for authentication (base64 encoded).
        token (str): The subscription key token (base64 encoded).
        main_url (str): The main URL of the Revio API.
        cost_center (str): The cost center value to update if CostCenter1 is present in the response.
    Returns:
        dict: A dictionary containing the result of the operation. The dictionary has a 'flag' key indicating success (True) or failure (False), and a 'message' key with additional information in case of failure.
    """
    # Prepare authentication and headers
    auth_token = base64_encode(f"{username}:{base64_decode(password)}")
    subscription_key = base64_decode(token)
    logging.info(auth_token, subscription_key)

    url = f"{main_url}/{service_id}"
    headers = {
        "Authorization": f"Basic {auth_token}",
        "Ocp-Apim-Subscription-Key": subscription_key,
        "Accept": "application/json",
    }

    # Send the request and handle the response
    try:
        response = requests.get(url, headers=headers)

        if response.status_code == 200:

            logging.info("Request successful:", response.json())

            if "CostCenter1" in response.json():
                # Define the request payload
                data = {"CostCenter1": cost_center}

                # Send the request and handle the response
                response = requests.put(url, headers=headers, json=data)

                if response.status_code in [200, 202]:  # Success responses
                    logging.info(
                        f"CostCenter1 for ICCID {service_id} updated successfully."
                    )
                    return {"flag": True}
                else:
                    logging.info(
                        f"Failed to update CostCenter1 for ICCID {service_id}: {response.status_code} - {response.text}"
                    )
                    return {
                        "flag": False,
                        "message": f"Failed to update CostCenter1 for ICCID {service_id}: {response.status_code} - {response.text} ",
                    }

        else:
            logging.info(
                f"Failed with status code {response.status_code}: {response.text}"
            )
            return {
                "flag": False,
                "message": f"Failed with status code {response.status_code}: {response.text}",
            }
    except Exception as e:
        logging.info(f"Error during request: {str(e)}")
        return {"flag": False, "message": f" Failed to send message due to: {str(e)}"}
