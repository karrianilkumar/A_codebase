"""
@Author1 : Mohammad Burhan
Created Date: 01-07-25
"""

# Importing the necessary Libraries
from collections import defaultdict
from requests.auth import HTTPBasicAuth
import time 
from datetime import datetime, timedelta, timezone, date
import pandas as pd
import numpy as np
from dateutil.parser import parse
import os
from dateutil.parser import parse as dtparse
import pandas as pd
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import logging
import re
import redis
import json
import requests
from common_utils.timezone_conversion import fetch_tenant_timezone, convert_timestamp_data, serialize_data
from calendar import monthrange
from dateutil.relativedelta import relativedelta
import dashboard_old_charts as old

logging = Logging(name="dashboard")

def clean_tuple(tpl):
    """ Cleans and formats a tuple, returning a string representation or an empty tuple if invalid."""
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
       logging.exception(f"###Exception while converting tuple: {e}")
       return ()

def db_config_maker(user, db_config_making, tenant_database,tenant_name,role_name):
    """
    customer and provider info to the DB settings based on user role and tenant.
    """

    if role_name in ('Super Admin','Partner Admin'):
        return db_config_making
    common_utils_database = DB('common_utils', **db_config_making)
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )

    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    if tenant_id:
        tenant_id=int(tenant_id)
    query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"
    filters = common_utils_database.execute_query(query, True)

    database = DB(tenant_database, **db_config)
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except:
        customer_group = None

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception(f"###Error extracting rate_plan_name :{e}")
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception(f"###Error extracting rate_plan_name: {e}")
                customer_names=None

            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None


            except Exception as e:
                logging.exception(f"###Error extracting billing_account_number:{e}")
                billing_account_number=None

            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception(f"###Error extracting feature_codes :{e}")
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except:
            customer = None
    else:
        customer=customer_names
    customer=clean_tuple(customer)
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            formatted_values = "', '".join(service_provider)
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except:
        service_provider = None
        service_provider_id = None
    logging.info(f"###customerscustomerscustomerscustomers:{customer}")
    try:
        customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customers_df=database.execute_query(customers_query,True)
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                if isinstance(customer, str):
                    customer = customer.strip("()'")  # Clean customer from extra parentheses and quotes
                    customer = (customer,)  # Convert it into a tupl


                # Now convert tuple to list
                customer_list = list(customer)
                # Clean and fix the list by splitting the elements and ensuring they are correctly quoted
                fixed_customer_list = []

                # Split the string into items and strip any unwanted characters
                for item in customer_list[0].split("', '"):
                    fixed_customer_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info(f'###customer_list before extend:{fixed_customer_list}')

                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info(f'###customer_list after extend:{fixed_customer_list}')

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info(f'###final customer tuple:{customer}')
                customer=clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(f"Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    try:
        customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_name = customer_rate_plan_name.strip("()'")  # Remove ( and ) and ' from start and end
                    customer_rate_plan_name = (customer_rate_plan_name,)  # Now correctly convert it to tuple

                # Now convert tuple to list
                customer_rate_plan_list = list(customer_rate_plan_name)
                fixed_customer_rate_plan_list = []

                # Split the string into items and strip any unwanted characters
                for item in customer_rate_plan_list[0].split("', '"):
                    fixed_customer_rate_plan_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info(f'###customer_list before extend:{customer_rate_plan_list}')

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info(f'###customer_list after extend:{fixed_customer_rate_plan_list}')

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info(f'###final customer tuple:{customer_rate_plan_name}')

    except Exception as e:
        logging.exception(f"###Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")

    logging.info(f'###customer at the end of customer:{customer}')
    db_config_making["customers"] = customer
    db_config_making["service_providers"] = service_provider
    db_config_making["service_provider_id"] = service_provider_id
    return db_config_making

def function_caller(data, path):
    """
    Main dispatcher function that builds DB config and routes requests.

    This function:
    1. Initializes database configuration from environment variables.
    2. Determines user/tenant-specific configuration (with service account/token support).
    3. Routes the request to the appropriate handler function based on the path.

    Args:
        data (dict): Request payload containing user/tenant information.
        path (str): API endpoint path.

    Returns:
        dict: Result of the invoked handler function or an error response.
    """
    global db_config

    # Step 1: Base DB config
    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema": False
    }

    user = data.get("username") or data.get("user_name")
    tenant_database = data.get("db_name")
    tenant_name = data.get("tenant_name", "") or data.get("tenant", "") or data.get("Partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    
    role_name = data.get("role_name") or data.get("role") or "Super Admin"
    db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name)
    db_config=db_config_making
    logging.info(f"####db_config created is : {db_config}")


    logging.info("### db_config is created")

    # Step 2: Path → Function mapping
    path_function_map = {
        "/count_of_sim_overview": count_of_sim_overview,
        "/get_sim_count_by_service_provider": get_sim_count_by_service_provider,
        "/get_sim_activations_by_service_provider": get_sim_activations_by_service_provider,
        "/get_all_related_tenants": get_all_related_tenants,
        "/get_organization_dropdown_data": get_organization_dropdown_data,
        "/get_service_provider_vs_status": get_service_provider_vs_status,
        "/total_usage_card": total_usage_card,
        "/total_usage_sims_count": total_usage_sims_count,
        "/total_usage_cost": total_usage_cost,
        "/average_usage_card": average_usage_card,
        "/get_usage_trend_by_provider": get_usage_trend_by_provider,
        "/get_service_type_usage_distribution": get_service_type_usage_distribution,
        "/get_usage_by_carrier_weekly_distribution": get_usage_by_carrier_weekly_distribution,
        "/get_plan_utilisation_summary": get_plan_utilisation_summary,
        "/get_revenue_metrics_cards": get_revenue_metrics_cards,
        "/get_revenue_by_carrier": get_revenue_by_carrier,
        "/get_revenue_by_rate_plan": get_revenue_by_rate_plan,
        "/get_profit_margin_trend": get_profit_margin_trend,
        "/get_revenue_by_usage_trend": get_revenue_by_usage_trend,
        "/get_status_count_of_tickets": get_status_count_of_tickets,
        "/insert_new_zendesk_tickets_batch": insert_new_zendesk_tickets_batch,
        "/get_ticket_status_distribution": get_ticket_status_distribution,
        "/get_ticket_resolution_time": get_ticket_resolution_time,
        "/get_ticket_severity_overview": get_ticket_severity_overview,
        "/get_ticket_category_distribution": get_ticket_category_distribution,
        "/sync_usage_insight": sync_usage_insight,
        "/get_dashboard_last_sync_time": get_dashboard_last_sync_time,
        "/refresh_dashboard_all_caches": refresh_dashboard_all_caches,
        "/clear_usage_cache": clear_usage_cache,
        "/get_all_service_providers_and_billing_cycle_dates_dropdown_data": get_all_service_providers_and_billing_cycle_dates_dropdown_data,
        "/get_update_module_features": get_update_module_features,
        "/get_ticket_compilance_by_module": get_ticket_compilance_by_module,
        "/run_populate_revenue_metrics": run_populate_revenue_metrics,
        "/run_populate_revenue_metrics_diff": run_populate_revenue_metrics_diff,
        #### old paths ####
        "/get_service_providers": old.get_service_providers,
        "/count_of_service_provider": old.count_of_service_provider,
        "/count_of_active_sims": old.count_of_active_sims,
        "/count_of_pending_sim_activations": old.count_of_pending_sim_activations,
        "/device_status_chart": old.device_status_chart,
        "/activated_vs_deactivated_pie_chart": old.activated_vs_deactivated_pie_chart,
        "/service_provider_change_request_stack_bar": old.service_provider_change_request_stack_bar,
        "/count_of_active_customers": old.count_of_active_customers,
        "/rev_assurance_record_discrepancy_card": old.rev_assurance_record_discrepancy_card,
        "/daily_sync_card": old.daily_sync_card,
        "/live_sessions_table": old.live_sessions_table,
        "/get_usage_details_card": old.get_usage_details_card,
        "/getm2m_high_usage_chart_data": old.getm2m_high_usage_chart_data,
        "/get_device_status_card": old.get_device_status_card,
        "/generate_empty_excel": old.generate_empty_excel,
        "/mobility_usage_per_group_pool": old.mobility_usage_per_group_pool,
        "/mobility_usage_per_customer_pool": old.mobility_usage_per_customer_pool,
        "/mobility_high_usage_chart": old.mobility_high_usage_chart,
        "/get_carrier_rate_plan_data": old.get_carrier_rate_plan_data,
        "/get_customer_rate_plan_data": old.get_customer_rate_plan_data,
        "/get_rate_plan_data": old.get_rate_plan_data,
        "/get_compare_cards": old.get_compare_cards,
        "/get_high_usage_chart_data": old.get_high_usage_chart_data,
    }

    # Step 3: Route request
    handler = path_function_map.get(path)
    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result


redis_client = redis.Redis(
    host=os.getenv('REDIS_HOST'),
    port=os.getenv('REDIS_PORT'),
    ssl=True,
    ssl_cert_reqs=None,
    decode_responses=True
)

def get_cache_key(db_name, function):
    """
    Generates a unique cache key string for storing or retrieving cached data in Redis.
    """
    return f"sim_provider_count:{db_name}:{function}"

def get_start_date_for_label(label, today):
    """Calculate start date for a given label, considering today and the month boundaries."""
    if label == "1_month":
        # 1st day of current month
        return today.replace(day=1)
    elif label == "3_month":
        # 1st day of month 2 months before current month (for last 3 months including current)
        return (today.replace(day=1) - relativedelta(months=2))
    elif label == "6_month":
        # 1st day of month 5 months before current month (last 6 months including current)
        return (today.replace(day=1) - relativedelta(months=5))
    elif label == "1_year":
        # 1st day of current year
        return today.replace(month=1, day=1)
    else:
        # Default fallback
        return today

def get_time_format_by_label(label, column=None):
    """Return SQL-safe time format for grouping by label."""
    if label == "1_day":
        # Group in 4-hour blocks
        return f"DATE_TRUNC('hour', {column}) + INTERVAL '1 hour' * (FLOOR(EXTRACT(HOUR FROM {column}) / 4) * 4)"
    elif label == "5_day":
        # Daily
        return f"DATE_TRUNC('day', {column})"
    elif label in ["1_month", "3_month", "6_month", "1_year"]:
        # Weekly grouping by week number in the month or year
        # Formula: (day_of_month -1) / 7 + 1 to get week number in month
        # So group by year, month, and week number inside month
        return (
            f"DATE_TRUNC('month', {column}) + "
            f"INTERVAL '1 day' * (FLOOR((EXTRACT(DAY FROM {column}) - 1) / 7) * 7)"
        )
    
    elif label in ["5_years", "max"]:
        # Yearly grouping
        return f"DATE_TRUNC('year', {column})"
   
    else:
        # Default daily grouping
        return f"DATE_TRUNC('day', {column})"

def execute_all_time_buckets(start_date=None, end_date=None, min_date=None, column=None):
    """Return time bucket configurations based on given or predefined ranges."""
    today = datetime.now().date()

    if start_date and end_date:
        days = (end_date - start_date).days
        if days <= 1:
            label = "1_day"
            interval = "4 hours"
            start = start_date
        elif days <= 6:
            label = "5_day"
            interval = "1 day"
            start = start_date
        elif days <= 31:
            label = "1_month"
            interval = "7 days"
            start = get_start_date_for_label("1_month", start_date)
        elif days <= 92:
            label = "3_month"
            interval = "7 days"
            start = get_start_date_for_label("3_month", start_date)
        elif days <= 183:
            label = "6_month"
            interval = "7 days"
            start = get_start_date_for_label("6_month", start_date)
        elif days <= 366:
            label = "1_year"
            interval = "7 days"
            start = get_start_date_for_label("1_year", start_date)
        elif days <= 5 * 366:
            label = "5_years"
            interval = "1 year"
            start = today.replace(year=today.year - 5, month=1, day=1)
        else:
            label = "max"
            interval = "1 year"
            start = min_date or datetime(today.year - 10, 1, 1).date()

        return [
            {
                "start": start,
                "end": end_date,
                "format": get_time_format_by_label(label, column),
                "label": label,
                "interval": interval
            },
            {
                "start": start,
                "end": end_date,
                "format": get_time_format_by_label(label, column),
                "label": "custom_range",
                "interval": interval
            }
        ], label

    # Static buckets if no date range provided
    buckets = [
        {"label": "1_day", "start": today, "interval": "4 hours"},
        {"label": "5_day", "start": today - timedelta(days=4), "interval": "1 day"},
        {"label": "1_month", "start": get_start_date_for_label("1_month", today), "interval": "7 days"},
        {"label": "3_month", "start": get_start_date_for_label("3_month", today), "interval": "7 days"},
        {"label": "6_month", "start": get_start_date_for_label("6_month", today), "interval": "7 days"},
        {"label": "1_year", "start": get_start_date_for_label("1_year", today), "interval": "7 days"},
        {"label": "5_years", "start": datetime(today.year - 5, 1, 1).date(), "interval": "1 year"},
        {"label": "max", "start": min_date or datetime(today.year - 10, 1, 1).date(), "interval": "1 year"},
    ]

    time_buckets = []
    for bucket in buckets:
        time_buckets.append({
            "start": bucket["start"],
            "end": today,
            "format": get_time_format_by_label(bucket["label"], column),
            "label": bucket["label"],
            "interval": bucket["interval"]
        })

    return time_buckets, "max"

########### dropdowns ################

def get_all_related_tenants(data):
    """
    Returns a dictionary mapping tenant names to their IDs, including:
    - the specified tenant
    - other tenants sharing the same parent (siblings)

    Args:
        data (dict): Contains 'tenant_name' (str): Name of the tenant to start from.

    Returns:
        dict: Mapping of tenant_name -> id
    """
    tenant_name = data.get("tenant_name")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    sessionID = data.get("sessionID")
    username = data.get("username")
    request_received_at = parse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.now().date()
    if not tenant_name:
        return {"error": "tenant_name is required"}
    result = {}
    result["All Tenants"] = "All"

    try:
        # Step 1: Get current tenant's ID and parent_tenant_id
        query = f"""SELECT id, parent_tenant_id FROM tenant WHERE tenant_name = '{tenant_name}' and is_active = true"""
        tenant_data = common_utils_database.execute_query(query, True)

        if tenant_data.empty:
            return {}

        tenant_id = tenant_data["id"].iloc[0]
        parent_tenant_id = tenant_data["id"].iloc[0]

        # Override ID for Altaworx Test
        if tenant_name == "Altaworx Test":
            result[tenant_name] = 1
        else:
            result[tenant_name] = int(tenant_id)
            

        # Step 2: Get sibling tenants (other tenants with same parent)
        if parent_tenant_id:
            sibling_query = f"""SELECT tenant_name, id FROM tenant WHERE parent_tenant_id = '{parent_tenant_id}' and is_active = true """
            sibling_data = common_utils_database.execute_query(sibling_query, True)

            for _, row in sibling_data.iterrows():
                sibling_name = row["tenant_name"]
                sibling_id = row["id"]
                if sibling_name != tenant_name:
                    result[sibling_name] = int(sibling_id)

        # return result
        # Prepare response
        response = {
            "flag": True,
            "data": result
        }

        # Auditing success
        try:
 
            audit_data = {
                "service_name": "get_all_related_tenants",
                "created_date": request_received_at,
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Retrieved SIM count for tenant {tenant_name}",
                "module_name": "get_sim_count_by_service_provider",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")

        return response

    except Exception as e:
        logging.warning(f"Error in get_sim_count_by_service_provider: {e}")

        # Generate fallback response
        response = {
            "flag": False,
            "data": [],
            "message": f"Error retrieving SIM count by service_provider : {e}"
        }
 
        # Auditing error
        try:
            error_data = {
                "service_name": "SIM Vs Service Provider",
                "created_date": data.get("request_received_at"),
                "error_messag": f"Error retrieving SIM count: {e}",
                "error_type": str(type(e).__name__),
                "users": data.get("username"),
                "tenant_name": data.get("tenant_name"),
                "comments": str(e),
                "module_name": "get_sim_count_by_service_provider",
                "request_received_at": data.get("request_received_at"),
                "session_id": data.get("sessionID"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as error_logging_exception:
            logging.warning(f"Error logging audit failed: {error_logging_exception}")

        return response

def get_all_service_providers_and_billing_cycle_dates_dropdown_data(data):
    """
  
        Returns dropdown data for service providers and their billing cycle end dates for a given tenant, including:

        - a list of unique service providers (with "All service providers" added at the top)
        - a mapping of each service provider to their billing cycle end dates
       

        Args:
            data (dict): Contains the following keys:
                - 'module' (str): Name of the module requesting the data.
                - 'db_name' (str): Database name of the tenant.
                - 'tenant_name' (str): Name of the tenant.
                

        Returns:
            dict: Contains:
                - 'flag' (bool): True if data retrieval was successful, False otherwise.
                - 'unique_service_providers' (list): Sorted list of unique service providers with "All service providers" at the top.
                - 'billing_period_dates' (dict): Mapping of service_provider -> list of billing_cycle_end_dates (formatted as "YYYY-MM-DD HH:MM:SS").
              
    """

   
    module_name = data.get("module", "")
    tenant_database = data.get("db_name", "")
    tenant_name = data.get("tenant_name", "")
    # database Connection
    try:
        database = DB(database=tenant_database, **db_config)
        dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        if tenant_name == "Altaworx Test":
            tenant_name = 'Altaworx'

        billing_period_query = """
            SELECT service_provider, billing_cycle_end_date
            FROM billing_period
            WHERE is_active = 'true'
            ORDER BY
                CASE
                    WHEN CURRENT_DATE BETWEEN billing_cycle_start_date
                    AND billing_cycle_end_date THEN 0
                    ELSE 1
                END,
                billing_cycle_end_date DESC
        """
        billing_period_dates = database.execute_query(billing_period_query, True)
        billing_period_dates["billing_cycle_end_date"] = pd.to_datetime(
            billing_period_dates["billing_cycle_end_date"], errors="coerce"
        )

        # Remove NaT (null) values before processing
        billing_period_dates = billing_period_dates.dropna(subset=["billing_cycle_end_date"])

        # Format valid dates as YYYY-MM-DD HH:MM:SS
        billing_period_dates["billing_cycle_end_date"] = billing_period_dates["billing_cycle_end_date"].dt.strftime("%Y-%m-%d %H:%M:%S")
        billing_period_dates = billing_period_dates.to_dict(orient="records")

        # Extract only the service_provider values
        service_providers = [row["service_provider"] for row in billing_period_dates]

        # Create a dictionary where the key is service_provider and
        # the value is a list of billing_cycle_end_dates
        service_provider_dict = {}
        for row in billing_period_dates:
            if row["service_provider"] in service_provider_dict:
                service_provider_dict[row["service_provider"]].append(
                    row["billing_cycle_end_date"]
                )
            else:
                service_provider_dict[row["service_provider"]] = [
                    row["billing_cycle_end_date"]
                ]

        # Optionally, remove duplicates
        unique_service_providers = sorted(list(set(service_providers)))

        # Add "All" to the list of unique service providers
        unique_service_providers.insert(0, "All service providers")

        try:
            audit_data_user_actions = {
                "service_name": "get_all_service_providers_and_billing_cycle_dates_dropdown_data",
                "created_by": data.get("username", ""),
                "status": 'True',
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Dashboard",
                "comments": f"dropdown data exported of service providers - {module_name}",
                "request_received_at": data.get("request_received_at", ""),
            }
            dbs.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")

        response = {
            "flag": True,
            "unique_service_providers": unique_service_providers,
            "billing_period_dates": service_provider_dict,
            "cross_provider": False
        }
        return response

    except Exception as e:
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error in reports dropdown data export : {e}")
        message = "Something went wrong while fetching reports dropdown data export"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_all_service_providers_and_billing_cycle_dates_dropdown_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message,
                "module_name": "Dashboard",
                "request_received_at": data.get("request_received_at", ""),
            }
            dbs.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}")

        response = {
            "flag": False,
            "unique_service_providers": [],
            "billing_period_dates": {},
            "cross_provider": False,
            "message": "Something went wrong while fetching service providers dropdown data ",
            "error": str(e)  # Optional: include only in non-production
        }
        return response

def get_organization_dropdown_data(data):
    """
    Fetches organization names and IDs from Zendesk and returns them
    in a dictionary format suitable for a dropdown.

    Returns:
        dict: {organization_name: organization_id}
    """
    sessionID = data.get("sessionID", "")
    username = data.get("username", "")
    organisation_name = data.get("organisation_name", "")
    request_received_at = datetime.now().date()
    #database connection
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)  
    url = f"https://{ZENDESK_SUBDOMAIN}.zendesk.com/api/v2/organizations.json"
    
    headers = {
        "Content-Type": "application/json",
    }
    auth = HTTPBasicAuth(f'{ZENDESK_EMAIL}/token', ZENDESK_API_TOKEN)

    try:
        response = requests.get(url, headers=headers, auth=auth)
        if response.status_code == 200:
            data = response.json()
            organizations = data.get("organizations", [])
            result = {"All Tenants": "All"}  
            for org in organizations:
                org_name = org.get("name")
                org_id = org.get("id")
                if org_name and org_id:
                    result[org_name] = org_id
            return {
                "flag": True,
                "data": result
            }
        else:
            logging.warning(f"Error fetching organizations: {response.status_code} - {response.text}")
            return {
                "flag": False,
                "data": {},
                "message": f"Zendesk API error: {response.status_code}"
            }
    except Exception as exception:
        response["flag"] = False
        response["message"] = "Unexpected error occurred during data preparation"
        logging.error(f"[get_organization_dropdown_data] Unexpected error: {exception}")
        try:
            error_data = {
                "service_name": "get_organization_dropdown_data",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": data.get("tenant_name"),
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                try:
                    common_utils_database.log_error_to_db(error_data, "error_log_table")  
                except:
                    logging.warning("Error table doesn't exist or logging failed.")
        except Exception as exception:
            logging.info(f"Failed to get_organization_dropdown_data: {exception}")
            pass

    return response

def clear_usage_cache(data):
    """
    Manually clears the Redis cache for the usage data (all 4 views and timestamp).
    """
    try:
        cache_key = "sim_provider_count:altaworx_test"
        redis_client.delete(cache_key)
        redis_client.delete(f"{cache_key}:timestamp")
        logging.info(f"Cache cleared for keys: {cache_key}, {cache_key}:timestamp")
        return {"flag": True, "message": "Cache cleared successfully"}
    except Exception as e:
        logging.info(f"Failed to clear cache: {e}")
        return {"flag": False, "message": f"Failed to clear cache: {e}"}

####################################  sim Overview code ########################

def count_of_sim_overview(data):
    """
    Fetches the total number of active SIMs and counts per sim_status from sim_management_inventory.
    Returns only total_active_sims, Activated, Suspended, and Active.
    Adds audit and error logs.
    Uses Redis caching without expiration - data persists until manually cleared.
    When refresh=True, appends new records to existing cache with deduplication.
    """
    tenant_database = data.get("db_name", "")
    start_date = data.get("start_date", None)
    end_date = data.get("end_date", None)
    tenant_id = data.get("tenant_id", "All")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    refresh = str(data.get("refresh", "False")).lower() == "true"
    service_provider = data.get("service_provider", "")
    billing_cycle_end_period = data.get("billing_cycle_end_period", None)

    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exc:
        logging.exception(f"Failed to connect to database in count_of_sim_overview: {db_exc}")
        return {
            "flag": False,
            "data": {"total": 0, "Activated": 0, "Suspended": 0, "Active": 0, "title": "Count of SIM Overview"},
            "message": "Database connection error",
        }

    # Generate cache key
    function = "count_of_sim_overview"
    cache_key = get_cache_key(tenant_database, function)

    # Always try fetching cache (even if refresh=True)
    cached_data = None
    try:
        cached_response = redis_client.get(cache_key)
        if cached_response:
            cached_data = json.loads(cached_response)
            logging.info(f"Cache hit for key: {cache_key}")
    except Exception as cache_exc:
        logging.warning(f"Cache retrieval failed: {cache_exc}")

    # If cache miss or refresh requested, fetch fresh data from DB
    if refresh or cached_data is None:
        try:
            query = """
                SELECT 
                    status_text,
                    count,
                    tenant_id,
                    modified_date,
                    service_provider_display_name
                FROM fn_get_status_counts()
            """
            result_df = database.execute_query(query, True)

            if isinstance(result_df, pd.DataFrame) and not result_df.empty:
                # Optimize datetime conversion
                result_df["modified_date"] = pd.to_datetime(result_df["modified_date"], errors='coerce').dt.date

                # Pre-normalize status_text
                result_df["status_lower"] = result_df["status_text"].astype(str).str.lower().str.strip()

                new_data = result_df.to_dict(orient="records")

                if refresh and cached_data:
                    # Combine old + new with deduplication
                    combined_data = cached_data + new_data
                    df_combined = pd.DataFrame(combined_data)

                    # Deduplicate on key columns - keep the latest records
                    df_combined = df_combined.drop_duplicates(
                        subset=["tenant_id", "status_text", "modified_date", "service_provider_display_name"],
                        keep="last"
                    )

                    cache_response = df_combined.to_dict(orient="records")
                    logging.info(f"Combined {len(cached_data)} existing + {len(new_data)} new records, deduplicated to {len(cache_response)}")
                else:
                    # First time or no existing cache
                    cache_response = new_data
                    logging.info(f"Setting fresh cache with {len(new_data)} records")

                # Store in Redis WITHOUT expiration
                try:
                    redis_client.set(cache_key, json.dumps(cache_response, default=str))
                    logging.info(f"Redis cache {'merged' if (refresh and cached_data) else 'set'} for key: {cache_key} (no expiration)")
                except Exception as redis_exc:
                    logging.warning(f"Redis set failed: {redis_exc}")

                # Audit refresh after setting cache
                try:
                    audit_data = {
                        "function_name": function,
                        "created_date": request_received_at,
                        "created_by": username,
                        "last_synced_by": username,
                    }
                    common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")

                cached_data = cache_response
            else:
                # No new data from DB
                if refresh and cached_data is not None:
                    # Keep existing cache as is
                    logging.info("No new data from DB, keeping existing cache")
                else:
                    # No cache and no DB data
                    cached_data = []
                    logging.info("No data from DB and no existing cache")
        except Exception as db_exc:
            logging.info(f"Database query failed in count_of_sim_overview: {db_exc}")
            if refresh and cached_data is not None:
                # Keep existing cache on DB error during refresh
                logging.info("DB error during refresh, keeping existing cache")
            else:
                cached_data = []

    # Early return if no data
    if not cached_data:
        logging.info("No cached data found, returning zeros")
        response = {
            "flag": True,
            "data": {"total": "0", "Activated": "0", "Suspended": "0", "Active": "0", "title": "Count of SIM Overview"},
        }
        return response

    # Convert to DataFrame once
    df_all = pd.DataFrame(cached_data)

    # Optimize datetime conversion
    if "modified_date" in df_all.columns and not df_all.empty:
        df_all["modified_date"] = pd.to_datetime(df_all["modified_date"], errors='coerce').dt.date

    # Add status_lower column if not exists
    if "status_lower" not in df_all.columns and "status_text" in df_all.columns:
        df_all["status_lower"] = df_all["status_text"].astype(str).str.lower().str.strip()

    original_count = len(df_all)

    # Tenant filter
    if tenant_id != "All" and not df_all.empty:
        try:
            filter_tenant_id = int(tenant_id)
            df_all = df_all[df_all["tenant_id"] == filter_tenant_id]
        except (ValueError, TypeError):
            logging.warning(f"Invalid tenant_id format: {tenant_id}")

    # Service provider filter
    if service_provider and not df_all.empty and "service_provider_display_name" in df_all.columns:
        df_all = df_all[df_all["service_provider_display_name"] == service_provider]

    # Billing cycle filter using modified_date
    if billing_cycle_end_period and not df_all.empty:
        try:
            billing_cycle_date = datetime.strptime(billing_cycle_end_period, "%Y-%m-%d").date()
            df_all = df_all[df_all["modified_date"] == billing_cycle_date]
        except Exception as cycle_exc:
            logging.warning(f"Billing cycle filtering failed: {cycle_exc}")

    # Date filter
    if start_date and end_date and start_date.strip() and end_date.strip() and not df_all.empty:
        try:
            start_date_obj = datetime.strptime(start_date, "%Y-%m-%d").date()
            end_date_obj = datetime.strptime(end_date, "%Y-%m-%d").date()
            df_all = df_all[
                (df_all["modified_date"] >= start_date_obj) & 
                (df_all["modified_date"] <= end_date_obj)
            ]
        except Exception as date_exc:
            logging.warning(f"Date filtering failed: {date_exc}")

    # Early return if filtered data is empty
    if df_all.empty:
        logging.info(f"No data after filtering (started with {original_count} records)")
        response = {
            "flag": True,
            "data": {"total": "0", "Activated": "0", "Suspended": "0", "Active": "0", "title": "Count of SIM Overview"},
        }
        return response

    # STATUS AGGREGATION
    activated_statuses = {"activated"}
    suspended_statuses = {"suspended"}
    active_statuses = {"active", "activation ready", "pending activation", "restore suspended", "a", "activate"}

    activated_mask = df_all["status_lower"].isin(activated_statuses)
    suspended_mask = df_all["status_lower"].isin(suspended_statuses)
    active_mask = df_all["status_lower"].isin(active_statuses)

    status_counts = {
        "Activated": df_all[activated_mask]["count"].sum(),
        "Suspended": df_all[suspended_mask]["count"].sum(),
        "Active": df_all[active_mask]["count"].sum()
    }

    status_counts = {k: int(v) if pd.notna(v) else 0 for k, v in status_counts.items()}
    sum_of_key_statuses = sum(status_counts.values())

    logging.info(f"Processed {len(df_all)} records. Final counts: {status_counts}, Total: {sum_of_key_statuses}")

    response = {
        "flag": True,
        "data": {
            "total": f"{sum_of_key_statuses:,}",
            "Activated": f"{status_counts['Activated']:,}",
            "Suspended": f"{status_counts['Suspended']:,}",
            "Active": f"{status_counts['Active']:,}",
            "title": "Count of SIM Overview",
        },
    }

    # Audit log on success
    try:
        audit_data = {
            "service_name": "count_of_sim_overview",
            "created_date": request_received_at,
            "created_by": username,
            "status": "Success",
            "tenant_name": tenant_name,
            "comments": f"Retrieved SIM overview for tenant {tenant_name}",
            "module_name": "Dashboard",
            "request_received_at": request_received_at,
            "session_id": sessionID,
        }
        common_utils_database.update_audit(audit_data, "audit_user_actions")
    except Exception as audit_exc:
        logging.error(f"Audit logging failed: {audit_exc}")

    return response


def get_sim_count_by_service_provider(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into week cutoffs:
        Week 1 => day 7 (1-7)
        Week 2 => day 14 (8-14)
        Week 3 => day 21 (15-21)
        Week 4 => end of month (22 - EOM)
      For current month the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: now also uses yearly cutoffs (past years = Dec 31, current year = today)
    - Keeps Redis cache, audit logging, filters, and output format used previously.
    """


    # Assumes DB, redis_client, db_config, get_cache_key,  exist in module scope

    response = {"flag": False, "data": {}, "meta": {}, "message": ""}
    try:
        tenant_id = data.get("tenant_id", "All")
        tenant_database = data.get("db_name", "")
        start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
        end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
        sessionID = data.get("sessionID", "")
        username = data.get("username", "")
        tenant_name = data.get("tenant_name", "")
        request_received_at = parse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.utcnow().date()
        refresh = str(data.get("refresh", "False")).lower() == "true"
        service_provider = data.get("service_provider", "")
        billing_cycle_end_period = data.get("billing_cycle_end_period", None)

        # special tenant mapping


        # Cache / DB setup
        function = "get_sim_count_by_service_provider"
        cache_key = get_cache_key(tenant_database, function)
        

        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        cached_data = None

        if not refresh:
            try:
                cached_response = redis_client.get(cache_key)
                if cached_response:
                    cached_parsed = json.loads(cached_response)
                    cached_data = cached_parsed.get("buckets", {})
                    logging.info(f"Cache hit for key: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Redis cache retrieval failed: {cache_exc}")

        if refresh or cached_data is None:
            logging.info("Fetching fresh SIM count data from DB")

            query = """
                SELECT tenant_id, service_provider_id, service_provider_display_name, created_date,
                billing_cycle_end_date
                FROM sim_management_inventory
                WHERE is_active = TRUE AND created_date IS NOT NULL
            """
            df_all = database.execute_query(query, True)

            df_all['created_date'] = pd.to_datetime(df_all['created_date'])
            df_all['billing_cycle_end_date'] = pd.to_datetime(df_all['billing_cycle_end_date'])
            df_all['sim_count'] = 1

            now = pd.Timestamp.now()
            today = now.normalize()
            five_days_ago = today - pd.Timedelta(days=4)
            month_start = now.replace(day=1)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1)
            year_start = pd.Timestamp(year=now.year, month=1, day=1)
            min_date = df_all['created_date'].min()
            min_year = int(min_date.year) if pd.notnull(min_date) else int(now.year)

            def eom(ts: pd.Timestamp) -> pd.Timestamp:
                """Returns the end-of-month timestamp for the given date."""
                return (ts + pd.offsets.MonthEnd(0))

            def month_week_cutoffs_for_month(first_of_month: pd.Timestamp, end_cap: pd.Timestamp, include_today_partial: bool):
                """Generates weekly cutoff dates within a month, optionally including today if partial month."""
                pts = []
                d7 = first_of_month + pd.Timedelta(days=6)
                d14 = first_of_month + pd.Timedelta(days=13)
                d21 = first_of_month + pd.Timedelta(days=20)
                dend = eom(first_of_month)

                for p in (d7, d14, d21, dend):
                    if p.normalize() <= end_cap.normalize():
                        pts.append(p.normalize())

                if include_today_partial and (first_of_month.year == end_cap.year and first_of_month.month == end_cap.month):
                    today_pt = end_cap.normalize()
                    if today_pt not in pts:
                        pts.append(today_pt)

                return sorted(pd.to_datetime(list(dict.fromkeys(pts))))

            def month_week_cutoffs_range(start_month_ts: pd.Timestamp, end_ts: pd.Timestamp, include_today_partial=True):
                """Generates all weekly cutoff dates across multiple months from start to end timestamp."""
                points = []
                cursor = pd.Timestamp(year=start_month_ts.year, month=start_month_ts.month, day=1)
                end_month_first = pd.Timestamp(year=end_ts.year, month=end_ts.month, day=1)

                while cursor <= end_month_first:
                    include_today = include_today_partial and (cursor.year == end_ts.year and cursor.month == end_ts.month)
                    month_pts = month_week_cutoffs_for_month(cursor, end_ts, include_today)
                    points.extend(month_pts)
                    cursor = (cursor + pd.offsets.MonthEnd(0)) + pd.Timedelta(days=1)

                return sorted(pd.to_datetime(list(dict.fromkeys(points))))

            def yearly_points_last_n_years(n_years: int, end_ts: pd.Timestamp):
                """Returns yearly cutoff points for the last n years, using Dec 31 or today for the current year."""
    
                start_year = end_ts.year - (n_years - 1)   # inclusive of current year
                pts = [pd.Timestamp(year=y, month=12, day=31) for y in range(start_year, end_ts.year)]
                
                # current year → today instead of Dec 31
                pts.append(end_ts.normalize())
                
                return sorted(pd.to_datetime(list(dict.fromkeys(pts))))


            def to_datestr(ts: pd.Timestamp, date_only=True, year_only=False) -> str:
                """Formats a timestamp into a date string, full ISO string, or year-only string."""
                if year_only:
                    return str(ts.year)
                return ts.date().isoformat() if date_only else ts.isoformat()


            def cumulative_grouping(time_points, date_only=True, year_only=False):
                """Groups cumulative SIM counts by tenant and service provider for specified time points."""
                providers_map = {}
                if time_points is None:
                    return []
                pts = list(pd.to_datetime(time_points))
                if len(pts) == 0:
                    return []

                df_sorted = df_all.sort_values('created_date')
                for t in pts:
                    subset = df_sorted[df_sorted['created_date'] <= t]
                    if subset.empty:
                        continue
                    grouped = subset.groupby(
                        ['tenant_id', 'service_provider_id', 'service_provider_display_name', 'billing_cycle_end_date'],
                        as_index=False
                    )['sim_count'].sum()

                    # ⬇ Pass year_only here
                    t_str = to_datestr(t, date_only=date_only, year_only=year_only)

                    for _, row in grouped.iterrows():
                        key = (row['tenant_id'], row['service_provider_id'])
                        if key not in providers_map:
                            providers_map[key] = {
                                "tenant_id": row['tenant_id'],
                                "provider_id": row['service_provider_id'],
                                "service_provider": row['service_provider_display_name'],
                                "billing_cycle_end_date": row['billing_cycle_end_date'].date().isoformat() if pd.notnull(row['billing_cycle_end_date']) else None,
                                "records": []
                            }
                        providers_map[key]['records'].append([t_str, int(row['sim_count'])])
                # ✅ Deduplicate by date/year string here
                for provider in providers_map.values():
                    seen = {}
                    for rec in provider["records"]:
                        seen[rec[0]] = rec[1]  # overwrite duplicates with last value
                    provider["records"] = [[k, v] for k, v in sorted(seen.items())]
                return list(providers_map.values())


            buckets = {}
            buckets['1_day'] = cumulative_grouping(pd.date_range(start=today, end=now, freq="4h"), date_only=False)
            buckets['5_day'] = cumulative_grouping(pd.date_range(start=five_days_ago, end=today, freq="D"), date_only=True)
            buckets['1_month'] = cumulative_grouping(month_week_cutoffs_range(month_start, now, include_today_partial=True), date_only=True)
            buckets['3_month'] = cumulative_grouping(month_week_cutoffs_range(three_months_start, now, include_today_partial=True), date_only=True)
            buckets['6_month'] = cumulative_grouping(month_week_cutoffs_range(six_months_start, now, include_today_partial=True), date_only=True)
            buckets['1_year'] = cumulative_grouping(month_week_cutoffs_range(year_start, now, include_today_partial=True), date_only=True)
            buckets['5_years'] = cumulative_grouping(yearly_points_last_n_years(5, now), year_only=True )
            buckets['max'] = cumulative_grouping(
                yearly_points_last_n_years(now.year - min_year + 1, now), 
                year_only=True  #  forces year-only labels
            )

            new_sync_time = datetime.utcnow()
            try:
                cache_payload = {"buckets": buckets}
                redis_client.setex(cache_key, 7200, json.dumps(cache_payload))
                redis_client.set(f"{cache_key}:timestamp", new_sync_time.strftime("%Y-%m-%d %H:%M:%S"))
                logging.info(f"Cache set for key: {cache_key}")
                try:
                    audit_data = {
                        "function_name": function,
                        "created_by": username,
                        "last_synced_by": username,
                    }
                    common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")
            except Exception as redis_exc:
                logging.warning(f"Redis set failed: {redis_exc}")

            cached_data = buckets

        all_data = cached_data.copy() if cached_data else {}

        if tenant_id != "All":
            for bucket_name in list(all_data.keys()):
                all_data[bucket_name] = [
                    provider for provider in all_data[bucket_name]
                    if str(provider.get("tenant_id")) == str(tenant_id)
                ]

        if service_provider and service_provider != "":
            sp_norm = service_provider.strip().lower()
            logging.info(sp_norm, "sp_normsp_normsp_norm")
            for bucket_name in list(all_data.keys()):
                filtered = [
                    provider for provider in all_data[bucket_name]
                    if provider.get("service_provider", "").strip().lower() == sp_norm
                ]
                for p in filtered:
                    logging.info(p.get("service_provider", "").strip().lower(), "1111111111111111111111")
                all_data[bucket_name] = filtered


        # Billing cycle end period filtering ✅ now tolerant of both formats
        if billing_cycle_end_period and billing_cycle_end_period != "":
            try:
                # normalize to date only
                billing_cycle_end_period = pd.to_datetime(str(billing_cycle_end_period)).date().isoformat()
            except Exception:
                billing_cycle_end_period = str(billing_cycle_end_period)

            for bucket_name in list(all_data.keys()):
                filtered = []
                for provider in all_data[bucket_name]:
                    prov_val = provider.get("billing_cycle_end_date")
                    if prov_val:
                        try:
                            prov_val = pd.to_datetime(str(prov_val)).date().isoformat()
                        except Exception:
                            prov_val = str(prov_val)
                    if prov_val == billing_cycle_end_period:
                        filtered.append(provider)
                all_data[bucket_name] = filtered




        if start_date and end_date:
            start_ts = pd.to_datetime(start_date)
            end_ts = pd.to_datetime(end_date)
            date_diff = (end_ts - start_ts).days

            if date_diff <= 1:
                main_bucket = "1_day"
            elif date_diff <= 6:
                main_bucket = "5_day"
            elif date_diff <= 31:
                main_bucket = "1_month"
            elif date_diff <= 93:
                main_bucket = "3_month"
            elif date_diff <= 186:
                main_bucket = "6_month"
            elif date_diff <= 366:
                main_bucket = "1_year"
            elif date_diff <= 1826:
                main_bucket = "5_years"
            else:
                main_bucket = "max"

            all_data = {k: v for k, v in all_data.items() if k in (main_bucket, "custom_range")}

        meta_tenants = {}
        meta_providers = {}
        all_buckets = {label: all_data.get(label, []) 
                      for label in ["1_day", "5_day", "1_month", "3_month", "6_month", 
                                   "1_year", "5_years", "max", "custom_range"]}

        for bucket_name, providers in all_data.items():
            for provider in providers:
                pid = provider.get("provider_id", "")
                pname = provider.get("service_provider", "Unknown")
                if pid not in meta_providers:
                    meta_providers[pid] = pname
                if tenant_id == "All":
                    tid = str(provider.get("tenant_id", ""))
                    if tid not in meta_tenants:
                        meta_tenants[tid] = ""
                else:
                    tid = str(tenant_id)
                    if tid not in meta_tenants:
                        meta_tenants[tid] = ""

        if meta_tenants:
            try:
                ids = list(meta_tenants.keys())
                query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
                df_tenant = common_utils_database.execute_query(query, params=ids)
                if isinstance(df_tenant, pd.DataFrame):
                    for row in df_tenant.to_dict(orient="records"):
                        meta_tenants[str(row["tenant_id"])] = row["tenant_name"]
            except Exception as tenant_exc:
                logging.warning(f"Failed to resolve tenant names: {tenant_exc}")

        response = {
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "providers": meta_providers,
                "default_time_range": "1_month"
                
            },
            "data": {
                "title": "SIM Vs Service Provider",
                "chart_type": "line_chart",
                "xField": "time",
                "yField": "sim_count",
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            }
        }
        return response

    except Exception as exception:
        logging.error(f"[get_sim_count_by_service_provider] Unexpected error: {exception}")
        response["message"] = f"Error retrieving SIM counts: {exception}"
        try:
            error_data = {
                "service_name": "get_sim_count_by_service_provider",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": str(type(exception).__name__),
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.warning(f"Error logging failed: {log_exc}")
        return response

def get_sim_activations_by_service_provider(data):
    """
    Retrieves SIM activation counts grouped by service provider over multiple time ranges for chart display.

    Args:
        data (dict): {
            "tenant_name": str,
            "tenant_id": int or "All",
            "start_date": "YYYY-MM-DD" (Optional),
            "end_date": "YYYY-MM-DD" (Optional),
            "username": str,
            "sessionID": str,
            "request_received_at": str,
            "db_name": str (Optional),
            "service_provider": str (Optional, partial match),
            "billing_cycle_end_period": "YYYY-MM-DD" (Optional)
        }

        Filters (tenant_id, service_provider, start_date/end_date, billing_cycle_end_period)
        are applied on the cached (post-built) data — NOT while building the cache.
    """

    response = {"flag": False, "data": {}, "meta": {}, "message": ""}
    try:
        tenant_name = data.get("tenant_name", "")
        tenant_id = data.get("tenant_id", "All")
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        request_received_at = parse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.now().date()
        start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
        end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
        refresh = str(data.get("refresh", "False")).lower() == "true"
        service_provider = data.get("service_provider", "")
        billing_cycle_end_period = data.get("billing_cycle_end_period", None)

            

        function = "get_sim_activations_by_service_provider"
        cache_key = get_cache_key(tenant_database, function)
        
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **db_config)

        # Try to retrieve from cache
        cached_data = None
        if not refresh:
            try:
                cached_response = redis_client.get(cache_key)
                if cached_response:
                    cached_data = json.loads(cached_response)
                    logging.info(f"Cache hit for key: {cache_key}")
            except Exception as e:
                logging.warning(f"Redis cache retrieval failed: {e}")

        # ---------- helpers ----------
        def eom(ts: pd.Timestamp) -> pd.Timestamp:
            """Returns the end-of-month timestamp for the given date."""
            return (ts + pd.offsets.MonthEnd(0))

        def to_datestr(ts: pd.Timestamp, date_only=True, year_only=False) -> str:
            """Formats a timestamp into a date string, full ISO string, or year-only string."""
            if year_only:
                return str(ts.year)
            return ts.date().isoformat() if date_only else ts.isoformat()

        # Week ranges for a month (1-7, 8-14, 15-21, 22-end)
        def month_week_cutoffs_for_month(first_of_month: pd.Timestamp, end_cap: pd.Timestamp, include_today_partial: bool):
            """Generates weekly cutoff dates within a month, optionally including today if partial month."""
            ranges = []
            s1 = first_of_month
            s2 = first_of_month + pd.Timedelta(days=7)
            s3 = first_of_month + pd.Timedelta(days=14)
            s4 = first_of_month + pd.Timedelta(days=21)

            e1 = first_of_month + pd.Timedelta(days=6)
            e2 = first_of_month + pd.Timedelta(days=13)
            e3 = first_of_month + pd.Timedelta(days=20)
            e4 = eom(first_of_month)

            week_starts = [s1.normalize(), s2.normalize(), s3.normalize(), s4.normalize()]
            week_ends = [e1.normalize(), e2.normalize(), e3.normalize(), e4.normalize()]

            for s, e in zip(week_starts, week_ends):
                actual_end = e
                if include_today_partial and (first_of_month.year == end_cap.year and first_of_month.month == end_cap.month):
                    if actual_end > end_cap.normalize():
                        actual_end = end_cap.normalize()
                if s <= actual_end:
                    ranges.append((pd.to_datetime(s), pd.to_datetime(actual_end)))
            ranges = sorted(list(dict.fromkeys(ranges)), key=lambda x: x[0])
            return ranges

        # Weekly ranges across months
        def month_week_cutoffs_range(start_month_ts: pd.Timestamp, end_ts: pd.Timestamp, include_today_partial=True):
            """Generates all weekly cutoff dates across multiple months from start to end timestamp."""
            points = []
            cursor = pd.Timestamp(year=start_month_ts.year, month=start_month_ts.month, day=1)
            end_month_first = pd.Timestamp(year=end_ts.year, month=end_ts.month, day=1)
            while cursor <= end_month_first:
                include_today = include_today_partial and (cursor.year == end_ts.year and cursor.month == end_ts.month)
                points.extend(month_week_cutoffs_for_month(cursor, end_ts, include_today))
                cursor = (cursor + pd.offsets.MonthEnd(0)) + pd.Timedelta(days=1)
            points = sorted(list(dict.fromkeys(points)), key=lambda x: x[0])
            return points

        
        #  FIX: ensures exactly n years incl current year
        def yearly_points_last_n_years(n_years: int, end_ts: pd.Timestamp):
            """Returns yearly cutoff points for the last n years, using Dec 31 or today for the current year."""
           
            end_year = end_ts.year
            start_year = end_year - (n_years - 1)

            ranges = []
            for y in range(start_year, end_year + 1):
                start = pd.Timestamp(year=y, month=1, day=1)
                # for current year, end is today, else Dec 31
                end = end_ts if y == end_year else pd.Timestamp(year=y, month=12, day=31)
                ranges.append((start, end))
            return ranges

        # Accepts timestamps or (start,end) tuples; ALWAYS keeps BCE in records so we can filter post-cache.
        def non_cumulative_grouping(time_points, date_only=True, year_only=False):
            """
            Returns record list with fields:
            tenant_id, provider_id, service_provider, billing_cycle_end_date, sim_count, time
            """
            records = []
            #  FIX: Safe emptiness check for DatetimeIndex or list/tuple
            if time_points is None or (hasattr(time_points, "empty") and time_points.empty) or len(time_points) == 0:
                return records

            pts = list(time_points)
            df_sorted = df.sort_values('created_date')
            first_item = pts[0]
            is_range_mode = isinstance(first_item, (list, tuple)) and len(first_item) == 2

            if is_range_mode:
                for (start_ts, end_ts) in pts:
                    start_norm = pd.to_datetime(start_ts).normalize()
                    end_norm = pd.to_datetime(end_ts).normalize()
                    subset = df_sorted[
                        (df_sorted['created_date'].dt.normalize() >= start_norm) &
                        (df_sorted['created_date'].dt.normalize() <= end_norm)
                    ]
                    if subset.empty:
                        continue
                    grouped = subset.groupby(
                        ['tenant_id', 'service_provider_id', 'service_provider_display_name', 'billing_cycle_end_date'],
                        as_index=False
                    )['sim_count'].sum()
                    # ⬇ Pass year_only here
                    t_str = to_datestr(end_norm, date_only=date_only,year_only=year_only)
                    
                    for _, row in grouped.iterrows():
                        records.append({
                            "tenant_id": int(row['tenant_id']) if not pd.isna(row['tenant_id']) else None,
                            "provider_id": int(row['service_provider_id']) if not pd.isna(row['service_provider_id']) else None,
                            "service_provider": row['service_provider_display_name'],
                            "billing_cycle_end_date": str(row["billing_cycle_end_date"].date()) if pd.notnull(row["billing_cycle_end_date"]) else None,
                            "sim_count": int(row['sim_count']),
                            "time": t_str
                        })
            else:
                pts_ts = list(pd.to_datetime(pts))
                for t in pts_ts:
                    subset = df_sorted[df_sorted['created_date'].dt.normalize() == t.normalize()]
                    if subset.empty:
                        continue
                    grouped = subset.groupby(
                        ['tenant_id', 'service_provider_id', 'service_provider_display_name', 'billing_cycle_end_date'],
                        as_index=False
                    )['sim_count'].sum()
                    t_str = to_datestr(t, date_only=date_only,year_only=year_only)
                    for _, row in grouped.iterrows():
                        records.append({
                            "tenant_id": int(row['tenant_id']) if not pd.isna(row['tenant_id']) else None,
                            "provider_id": int(row['service_provider_id']) if not pd.isna(row['service_provider_id']) else None,
                            "service_provider": row['service_provider_display_name'],
                            "billing_cycle_end_date": str(row["billing_cycle_end_date"].date()) if pd.notnull(row["billing_cycle_end_date"]) else None,
                            "sim_count": int(row['sim_count']),
                            "time": t_str
                        })
            return records

        # ---------- build or load buckets ----------
        if refresh or cached_data is None:
            logging.info("Fetching fresh SIM count data from DB")

            query = """
                SELECT tenant_id, service_provider_id, service_provider_display_name, created_date,
                       billing_cycle_end_date
                FROM sim_management_inventory
                WHERE is_active = TRUE AND created_date IS NOT NULL
            """
            df = database.execute_query(query, True)

            # Normalize dataframe
            if not isinstance(df, pd.DataFrame):
                try:
                    df = pd.DataFrame(df)
                except Exception:
                    df = pd.DataFrame(columns=[
                        "tenant_id", "service_provider_id", "service_provider_display_name", "created_date", "billing_cycle_end_date"
                    ])

            df['created_date'] = pd.to_datetime(df['created_date'])
            df['billing_cycle_end_date'] = pd.to_datetime(df['billing_cycle_end_date'])
            df['sim_count'] = 1

            now = pd.Timestamp.now()
            today = now.normalize()
            five_days_ago = today - pd.Timedelta(days=4)
            month_start = now.replace(day=1)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1)
            year_start = pd.Timestamp(year=now.year, month=1, day=1)
            min_date = df['created_date'].min()
            min_year = int(min_date.year) if pd.notnull(min_date) else int(now.year)

            buckets = {}
            # 1_day: 4-hour points
            buckets['1_day']   = non_cumulative_grouping(pd.date_range(start=today,       end=now,   freq="4h"), date_only=False)
            # 5_day: daily points
            buckets['5_day']   = non_cumulative_grouping(pd.date_range(start=five_days_ago, end=today, freq="D"),  date_only=True)
            # Weekly ranges within months
            buckets['1_month'] = non_cumulative_grouping(month_week_cutoffs_range(month_start,        now, include_today_partial=True), date_only=True)
            buckets['3_month'] = non_cumulative_grouping(month_week_cutoffs_range(three_months_start, now, include_today_partial=True), date_only=True)
            buckets['6_month'] = non_cumulative_grouping(month_week_cutoffs_range(six_months_start,   now, include_today_partial=True), date_only=True)
            buckets['1_year']  = non_cumulative_grouping(month_week_cutoffs_range(year_start,         now, include_today_partial=True), date_only=True)
            # Yearly points
            buckets['5_years'] = non_cumulative_grouping(yearly_points_last_n_years(5, now), year_only=True)
            buckets['max'] = non_cumulative_grouping(
                yearly_points_last_n_years(now.year - min_year + 1, now), 
                year_only=True  #  forces year-only labels
            )

            # Cache results
            new_sync_time = datetime.utcnow()
            try:
                redis_client.setex(cache_key, 7200, json.dumps(buckets))
                redis_client.set(f"{cache_key}:timestamp", new_sync_time.strftime("%Y-%m-%d %H:%M:%S"))
                logging.info(f"Cache set for key: {cache_key}")
                try:
                    audit_data = {
                        "function_name": function,
                        "created_date": request_received_at,
                        "created_by": username,
                        "last_synced_by": username,
                        "last_sync_date": new_sync_time,
                    }
                    common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")
            except Exception as redis_exc:
                logging.warning(f"Redis set failed: {redis_exc}")

            cached_data = buckets

        # ------------------ post-cache filtering ------------------
        all_data = cached_data.copy() if cached_data else {}

        # Tenant filter
        if tenant_id != "All":
            try:
                tenant_id_int = int(tenant_id)
                for key in list(all_data.keys()):
                    all_data[key] = [rec for rec in all_data[key] if int(rec.get("tenant_id", -1)) == tenant_id_int]
            except Exception:
                for key in list(all_data.keys()):
                    all_data[key] = [rec for rec in all_data[key] if str(rec.get("tenant_id")) == str(tenant_id)]

        # Service provider filter
        if service_provider and service_provider != "":
            sp_norm = service_provider.strip().lower()
            for bucket_name in list(all_data.keys()):
                all_data[bucket_name] = [
                    rec for rec in all_data[bucket_name]
                    if sp_norm in (rec.get("service_provider") or "").strip().lower()
                ]

        # Billing cycle end period filter
        if billing_cycle_end_period and billing_cycle_end_period != "":
            try:
                target_date = pd.to_datetime(str(billing_cycle_end_period)).date()
            except Exception:
                target_date = str(billing_cycle_end_period)

            for bucket_name in list(all_data.keys()):
                filtered = []
                for rec in all_data[bucket_name]:
                    prov_val = rec.get("billing_cycle_end_date")
                    if prov_val:
                        try:
                            prov_val = pd.to_datetime(str(prov_val)).date()
                        except Exception:
                            prov_val = str(prov_val)
                    if prov_val == target_date:
                        filtered.append(rec)
                all_data[bucket_name] = filtered

        # Start & end date custom range logic
        main_bucket = None
        if start_date and end_date:
            start_ts = pd.to_datetime(start_date)
            end_ts = pd.to_datetime(end_date)
            date_diff = (end_ts - start_ts).days

            if date_diff <= 1:
                main_bucket = "1_day"
            elif date_diff <= 6:
                main_bucket = "5_day"
            elif date_diff <= 31:
                main_bucket = "1_month"
            elif date_diff <= 93:
                main_bucket = "3_month"
            elif date_diff <= 186:
                main_bucket = "6_month"
            elif date_diff <= 366:
                main_bucket = "1_year"
            elif date_diff <= 1826:
                main_bucket = "5_years"
            else:
                main_bucket = "max"

            for k in list(all_data.keys()):
                if k not in (main_bucket, "custom_range"):
                    del all_data[k]
            if "custom_range" not in all_data:
                all_data["custom_range"] = []
        #  ensure buckets don’t overlap
        if main_bucket == "5_years":
            all_buckets = {"5_years": all_data.get("5_years", [])}
        elif main_bucket == "max":
            all_buckets = {"max": all_data.get("max", [])}
        
        


        # ------------------ format output (merge duplicates) ------------------
        meta_tenants = {}
        meta_providers = {}
        all_buckets = {label: [] for label in ["1_day", "5_day", "1_month", "3_month", "6_month", "1_year", "5_years", "max", "custom_range"]}

        for bucket_name in all_buckets.keys():
            bucket_data = all_data.get(bucket_name, [])
            grouped_by_provider = defaultdict(list)

            for rec in bucket_data:
                pid = rec.get("provider_id", "")
                pname = rec.get("service_provider", "Unknown")
                grouped_by_provider[pid].append([rec.get("time", ""), int(rec.get("sim_count", 0))])

                if pid not in meta_providers:
                    meta_providers[pid] = pname
                if tenant_id == "All":
                    meta_tenants[str(rec.get("tenant_id", ""))] = ""
                else:
                    meta_tenants[str(tenant_id)] = ""

            formatted = []
            for pid, time_pairs in grouped_by_provider.items():
                merged = {}
                for time_label, cnt in time_pairs:
                    merged[time_label] = merged.get(time_label, 0) + int(cnt)
                merged_list = [[t, merged[t]] for t in sorted(merged.keys())]
                formatted.append({
                    "tenant_id": tenant_id if tenant_id != "All" else "",
                    "provider_id": pid,
                    "records": merged_list
                })
            all_buckets[bucket_name] = formatted

        # Resolve tenant names
        if meta_tenants:
            try:
                ids = list(meta_tenants.keys())
                query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
                df_tenant = common_utils_database.execute_query(query, params=ids)
                if isinstance(df_tenant, pd.DataFrame):
                    for row in df_tenant.to_dict(orient="records"):
                        meta_tenants[str(row["tenant_id"])] = row["tenant_name"]
            except Exception as tenant_exc:
                logging.warning(f"Failed to resolve tenant names: {tenant_exc}")

        response = {
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "providers": meta_providers,
                "default_time_range": main_bucket if main_bucket else "1_month"
                
            },
            "data": {
                "title": "SIMs Active",
                "chart_type": "line_chart",
                "xField": "time",
                "yField": "sim_count",
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            }
        }
        return response

    except Exception as exception:
        logging.exception(f"[get_sim_activations_by_service_provider] Unexpected error: {exception}")
        response["message"] = f"Unexpected error occurred during data preparation{exception}"
        try:
            error_data = {
                "service_name": "get_sim_activations_by_service_provider",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
            logging.info("[get_sim_activations_by_service_provider] Error log successfully recorded.")
        except Exception as log_exc:
            logging.warning(f"[get_sim_activations_by_service_provider] Error logging to DB failed: {log_exc}")
        return response

def get_service_provider_vs_status(data):
    """
    Retrieves SIM counts grouped by service provider and sim_status for a given tenant, formatted for stacked bar chart.

    Args:
        data (dict): Input dictionary with tenant_name, db_name, start_date, end_date, username, sessionID, request_received_at, tenant_id.

    Returns:
        dict: Response with counts grouped by service provider and status.
    """


    response = {"flag": False, "data": {}, "meta": {}, "message": ""}

    try:
        tenant_id = data.get("tenant_id", "All")
        tenant_database = data.get("db_name", "")
        start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
        end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
        sessionID = data.get("sessionID", "")
        username = data.get("username", "")
        tenant_name = data.get("tenant_name", "")
        request_received_at = parse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.utcnow().date()
        refresh = str(data.get("refresh", "False")).lower() == "true"
        service_provider = data.get("service_provider", "")
        billing_cycle_end_period = data.get("billing_cycle_end_period", None)

       

        # Cache / DB setup
        function = "get_service_provider_vs_status"
        cache_key = get_cache_key(tenant_database, function)
        

        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        cached_data = None

        # Try cache
        if not refresh:
            try:
                cached_response = redis_client.get(cache_key)
                if cached_response:
                    cached_parsed = json.loads(cached_response)
                    cached_data = cached_parsed.get("buckets", {})
                    logging.info(f"Cache hit for key: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Redis cache retrieval failed: {cache_exc}")

        # If refresh or no cache, fetch fresh data
        if refresh or cached_data is None:
            logging.info("Fetching fresh SIM count data from DB")

            query = """
                SELECT tenant_id, service_provider_id, service_provider_display_name, created_date, sim_status,
                billing_cycle_end_date
                FROM sim_management_inventory
                WHERE is_active = TRUE AND created_date IS NOT NULL
            """
            df_all = database.execute_query(query, True)

            df_all['created_date'] = pd.to_datetime(df_all['created_date'])
            df_all['billing_cycle_end_date'] = pd.to_datetime(df_all['billing_cycle_end_date'])
            df_all['sim_count'] = 1

            now = pd.Timestamp.now()
            today = now.normalize()
            five_days_ago = today - pd.Timedelta(days=4)
            month_start = now.replace(day=1)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1)
            year_start = pd.Timestamp(year=now.year, month=1, day=1)
            min_date = df_all['created_date'].min()
            min_year = int(min_date.year) if pd.notnull(min_date) else int(now.year)

            # ---------- helper functions ----------
            def eom(ts: pd.Timestamp) -> pd.Timestamp:
                """Returns the end-of-month timestamp for the given date."""
                return ts + pd.offsets.MonthEnd(0)

            def month_week_cutoffs_for_month(first_of_month: pd.Timestamp, end_cap: pd.Timestamp, include_today_partial: bool):
                """Generates weekly cutoff dates within a month, optionally including today if partial month."""
                pts = []
                for d in [6, 13, 20]:  # 7th, 14th, 21st
                    pt = first_of_month + pd.Timedelta(days=d)
                    if pt.normalize() <= end_cap.normalize():
                        pts.append(pt.normalize())
                dend = eom(first_of_month)
                if dend.normalize() <= end_cap.normalize():
                    pts.append(dend)
                if include_today_partial and first_of_month.year == end_cap.year and first_of_month.month == end_cap.month:
                    if end_cap.normalize() not in pts:
                        pts.append(end_cap.normalize())
                return sorted(pd.to_datetime(list(dict.fromkeys(pts))))

            def month_week_cutoffs_range(start_month_ts: pd.Timestamp, end_ts: pd.Timestamp, include_today_partial=True):
                """Generates all weekly cutoff dates across multiple months from start to end timestamp."""
                points = []
                cursor = pd.Timestamp(year=start_month_ts.year, month=start_month_ts.month, day=1)
                end_month_first = pd.Timestamp(year=end_ts.year, month=end_ts.month, day=1)
                while cursor <= end_month_first:
                    include_today = include_today_partial and (cursor.year == end_ts.year and cursor.month == end_ts.month)
                    points.extend(month_week_cutoffs_for_month(cursor, end_ts, include_today))
                    cursor = (cursor + pd.offsets.MonthEnd(0)) + pd.Timedelta(days=1)
                return sorted(pd.to_datetime(list(dict.fromkeys(points))))

            #  FIX: ensures exactly n years incl current year
            def yearly_points_last_n_years(n_years: int, end_ts: pd.Timestamp):
                """Returns yearly cutoff points for the last n years, using Dec 31 or today for the current year."""
    
                start_year = end_ts.year - (n_years - 1)
                pts = [pd.Timestamp(year=y, month=12, day=31) for y in range(start_year, end_ts.year)]
                pts.append(end_ts.normalize())  # current year cutoff
                return sorted(pd.to_datetime(list(dict.fromkeys(pts))))

            

            
            def to_datestr(ts: pd.Timestamp, date_only=True, year_only=False) -> str:
                """Formats a timestamp into a date string, full ISO string, or year-only string."""
                if year_only:
                    return str(ts.year)
                return ts.date().isoformat() if date_only else ts.isoformat()
            # ---------- cumulative grouping ----------
            def cumulative_grouping(time_points, date_only=True, year_only=False):
                """Aggregates cumulative SIM counts by status for each tenant and service provider up to each time point, 
                returning structured records with per-status counts and associated dates."""
                status_counts_map = {}
                if time_points is None:
                    return []
                pts = list(pd.to_datetime(time_points))
                if len(pts) == 0:
                    return []
                df_sorted = df_all.sort_values('created_date')
                for t in pts:
                    subset = df_sorted[df_sorted['created_date'] <= t]
                    if subset.empty:
                        continue
                    grouped = subset.groupby(
                        ['tenant_id', 'service_provider_id', 'service_provider_display_name', 'sim_status','billing_cycle_end_date'],
                        as_index=False
                    )['sim_count'].sum()

                    #  Pass year_only here
                    t_str = to_datestr(t, date_only=date_only, year_only=year_only)
                    for _, row in grouped.iterrows():
                        key = (row['tenant_id'], row['service_provider_id'])
                        if key not in status_counts_map:
                            status_counts_map[key] = {
                                "tenant_id": row['tenant_id'],
                                "provider_id": row['service_provider_id'],
                                "service_provider": row['service_provider_display_name'],
                                "billing_cycle_end_date": row['billing_cycle_end_date'].date().isoformat() if pd.notnull(row['billing_cycle_end_date']) else None,

                                "records": []
                            }
                        # find record for this time
                        record_found = next((r for r in status_counts_map[key]["records"] if r["date"] == t_str), None)
                        if record_found is None:
                            record_found = {
                                "date": t_str,
                                "status_counts": {
                                    "Activated": 0,
                                    "Active": 0,
                                    "Deactivated": 0,
                                    "Suspended": 0,
                                    "Retired": 0
                                }
                            }
                            status_counts_map[key]["records"].append(record_found)
                        # status = row['sim_status']
                        # if status in record_found["status_counts"]:
                        #     record_found["status_counts"][status] += int(row['sim_count'])
                        # else:
                        #     record_found["status_counts"][status] = int(row['sim_count'])
                        ALLOWED_STATUSES = {"Activated","Active", "Deactivated", "Suspended", "Retired"}
                        status = row['sim_status']

                        if status in ALLOWED_STATUSES:
                            record_found["status_counts"][status] += int(row['sim_count'])

                
                
                return list(status_counts_map.values())

            # ---------- build buckets ----------
            buckets = {}
            buckets['1_day'] = cumulative_grouping(pd.date_range(start=today, end=now, freq="4h"), date_only=False)
            buckets['5_day'] = cumulative_grouping(pd.date_range(start=five_days_ago, end=today, freq="D"), date_only=True)
            buckets['1_month'] = cumulative_grouping(month_week_cutoffs_range(month_start, now, include_today_partial=True), date_only=True)
            buckets['3_month'] = cumulative_grouping(month_week_cutoffs_range(three_months_start, now, include_today_partial=True), date_only=True)
            buckets['6_month'] = cumulative_grouping(month_week_cutoffs_range(six_months_start, now, include_today_partial=True), date_only=True)
            buckets['1_year'] = cumulative_grouping(month_week_cutoffs_range(year_start, now, include_today_partial=True), date_only=True)
            buckets['5_years'] = cumulative_grouping(yearly_points_last_n_years(5, now), year_only=True)
            buckets['max'] = cumulative_grouping(
                yearly_points_last_n_years(now.year - min_year + 1, now), 
                year_only=True  #  forces year-only labels
            )

            # Cache results
            try:
                redis_client.setex(cache_key, 7200, json.dumps({"buckets": buckets}))
                redis_client.set(f"{cache_key}:timestamp", datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
            except Exception as redis_exc:
                logging.warning(f"Redis set failed: {redis_exc}")
            cached_data = buckets

        # ------------------ post-cache filtering ------------------
        all_data = cached_data.copy() if cached_data else {}

        # Tenant filtering
        if tenant_id != "All":
            for bucket_name in list(all_data.keys()):
                all_data[bucket_name] = [
                    provider for provider in all_data[bucket_name]
                    if str(provider.get("tenant_id")) == str(tenant_id)
                ]
        if service_provider and service_provider != "":
            sp_norm = service_provider.strip().lower()
            logging.info(sp_norm, "data service provider ")
            for bucket_name in list(all_data.keys()):
                filtered = [
                    provider for provider in all_data[bucket_name]
                    if provider.get("service_provider", "").strip().lower() == sp_norm
                ]
                for p in filtered:
                    logging.info(p.get("service_provider", "").strip().lower(), "log service provider ")
                all_data[bucket_name] = filtered


        # Billing cycle end period filtering  now tolerant of both formats
        if billing_cycle_end_period and billing_cycle_end_period != "":
            try:
                # normalize to date only
                billing_cycle_end_period = pd.to_datetime(str(billing_cycle_end_period)).date().isoformat()
            except Exception:
                billing_cycle_end_period = str(billing_cycle_end_period)

            for bucket_name in list(all_data.keys()):
                logging.info("All provider billing_cycle_end_date values for bucket", bucket_name, 
                [p.get("billing_cycle_end_date") for p in all_data[bucket_name]])
                filtered = []
                for provider in all_data[bucket_name]:
                    prov_val = provider.get("billing_cycle_end_date")
                    if prov_val:
                        try:
                            prov_val = pd.to_datetime(str(prov_val)).date().isoformat()
                        except Exception:
                            prov_val = str(prov_val)
                    if prov_val == billing_cycle_end_period:
                        filtered.append(provider)
                all_data[bucket_name] = filtered

                logging.info(prov_val, "112345", billing_cycle_end_period)

        # Date range filtering
        main_bucket = None
        # Check if user provided a custom date range
        if start_date and end_date:
            start_ts = pd.to_datetime(start_date)
            end_ts = pd.to_datetime(end_date)
            date_diff = (end_ts - start_ts).days
            
            
            #all_data["custom_range"] = non_cumulative_grouping(pd.date_range(start=start_ts, end=end_ts, freq="D"), date_only=True)
            # Decide which main bucket this date range belongs to
            if date_diff <= 1:
                main_bucket = "1_day"
            elif date_diff <= 6:
                main_bucket = "5_day"
            elif date_diff <= 31:
                main_bucket = "1_month"
            elif date_diff <= 93:
                main_bucket = "3_month"
            elif date_diff <= 186:
                main_bucket = "6_month"
            elif date_diff <= 366:
                main_bucket = "1_year"
            elif date_diff <= 1826:
                main_bucket = "5_years"
            else:
                main_bucket = "max"
            
            # Keep only that bucket + custom_range
            all_data = {k: v for k, v in all_data.items() if k in (main_bucket, "custom_range")}
           
        # ensure buckets don’t overlap
        if main_bucket == "5_years":
            all_buckets = {"5_years": all_data.get("5_years", [])}
        elif main_bucket == "max":
            all_buckets = {"max": all_data.get("max", [])}
        else:
            all_buckets = {label: all_data.get(label, []) 
                          for label in ["1_day", "5_day", "1_month", "3_month", "6_month", 
                                        "1_year", "5_years", "max", "custom_range"]}
        
        # ------------------ format output ------------------
        meta_tenants = {}
        meta_providers = {}
        

        # Collect provider metadata
        for bucket_name, providers in all_data.items():
            for provider in providers:
                pid = provider.get("provider_id", "")
                pname = provider.get("service_provider", "Unknown")
                if pid not in meta_providers:
                    meta_providers[pid] = pname
                tid = str(provider.get("tenant_id", tenant_id))
                if tid not in meta_tenants:
                    meta_tenants[tid] = ""
                    

        # Resolve tenant names
        if meta_tenants:
            try:
                ids = list(meta_tenants.keys())
                query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
                df_tenant = common_utils_database.execute_query(query, params=ids)
                if isinstance(df_tenant, pd.DataFrame):
                    for row in df_tenant.to_dict(orient="records"):
                        meta_tenants[str(row["tenant_id"])] = row["tenant_name"]
            except Exception as tenant_exc:
                logging.warning(f"Failed to resolve tenant names: {tenant_exc}")

        response = {
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "providers": meta_providers,
                "default_time_range": "1_month"
            },
            "data": {
                "title": "Service Provider Vs SIM Status",
                "chart_type": "stacked_bar",
                "xField": "date",
                "yField": "status_counts",
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            }
        }
        return response

    except Exception as e:
        logging.exception(f"[get_service_provider_vs_status] Exception: {e}")
        response["message"] = f"Error retrieving SIM counts by provider and status{e}"
        try:
            error_data = {
                "service_name": "get_service_provider_vs_status",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(e),
                "module_name": "Dashboard",
                "request_received_at": data.get("request_received_at"),
                "session_id": sessionID,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_err:
            logging.warning(f"[get_service_provider_vs_status] Error logging failed: {log_err}")
        return response

####################################  sim Overview code ########################

##################### Usage Insights code  ############################ 

def get_usage_insights_cache_key(db_name):
    """Returns a cache key string for  usage insights for the specified database."""

    return f"sim_provider_count:{db_name}"

def sync_usage_insight(data):
    """
        Synchronizes usage insights for a tenant by updating the cache, 
        records success or failure in audit tables, and logs any errors.

        Args:
            data (dict): Contains keys like 'function_name', 'username', 'tenant_database','cache_key'.

        Returns:
            dict: {'flag': True/False, 'message': str} indicating success or failure of the sync operation.
    """

    tenant_database = data.get("db_name", "") 
    function_name = "sync_usage_insights"
    cache_key = get_usage_insights_cache_key(tenant_database)
    username = data.get("username", "")
    try:    
        # Use timezone-aware UTC datetime
        request_received_at = data.get("request_received_at", "")
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        database = DB(tenant_database, **db_config)

        #  Run update_usage_cache — if this fails, audits will be skipped
        update_usage_cache(
            database, cache_key, function_name, username, request_received_at, common_utils_database
        )

        # Only if update_usage_cache succeeds, do audits
        try:
            audit_data = {
                "function_name": "refresh_usage_insights_caches",
                "created_by": username,
                "last_synced_by": username,
            }
            common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
        except Exception as audit_exc:
            logging.warning(f"Dashboard cache audit insert failed for {function_name}: {audit_exc}")

        try:
            audit_data = {
                "service_name": function_name,
                "created_date": request_received_at,
                "created_by": username,
                "status": "Success",
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Synced usage insights for tenant {tenant_database}",
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": data.get("sessionID", ""),
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.warning(f"[sync_usage_insights] Audit logging failed: {audit_exc}")

        return {"flag": True, "message": "Synced usage insights successfully"}

    except Exception as exc:
        logging.error(f"[sync_usage_insights] Error: {exc}")
        try:
            error_data = {
                "service_name": function_name,
                "error_message": str(exc),
                "error_type": type(exc).__name__,
                "users": username,
                "tenant_name": data.get("tenant_name", ""),
                "comments": str(exc),
                "module_name": "Dashboard",
                "request_received_at": data.get("request_received_at", ""),
                "session_id": data.get("sessionID", ""),
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.warning(f"[sync_usage_insights] Error logging to DB: {log_exc}")
        return {"flag": False, "message": "Error syncing usage insights"}

def update_usage_cache(database, cache_key, function_name, username, request_received_at, common_utils_database):
    """
    Updates Redis cache by appending fresh data from 3 usage-related stored procedures
    and updating (replacing) data for 2 rate plan stored procedures:

    APPEND behavior:
    - fn_get_usage_summary_by_plan_by_customer
    - fn_get_usage_summary_by_plan_by_provider
    - fn_get_usage_summary_by_plan_by_provider_rate_plan

    UPDATE (REPLACE) behavior:
    - fn_get_rate_plan_name_by_customer
    - fn_get_rate_plan_name_by_provider

    Data is stored separately and appended/updated to existing cache without merging or deduplication.
    Cache does not expire.
    """
    
    # Initialize the base structure for cache data
    cache_data = {
        "rate_plan_name_customer": pd.DataFrame(),
        "usage_summary_customer": pd.DataFrame(),
        "rate_plan_name_provider": pd.DataFrame(),
        "usage_summary_provider": pd.DataFrame(),
        "usage_summary_by_plan_by_provider_rate_plan": pd.DataFrame(),
        "sync_time": datetime.utcnow()
    }

    # ------------------- Load existing cache -------------------
    try:
        cached_raw = redis_client.get(cache_key)
        old_data = {
            "rate_plan_name_customer": pd.DataFrame(),
            "usage_summary_customer": pd.DataFrame(),
            "rate_plan_name_provider": pd.DataFrame(),
            "usage_summary_provider": pd.DataFrame(),
            "usage_summary_by_plan_by_provider_rate_plan": pd.DataFrame()
        }

        if cached_raw:
            existing_cache = json.loads(cached_raw)
            for key in old_data.keys():
                old_data[key] = pd.DataFrame(existing_cache.get(key, []))

        # Copy old data into cache_data
        for key in old_data:
            cache_data[key] = old_data[key]

        # ------------------- Fetch new data from DB -------------------
        queries = {
            "rate_plan_name_customer": "SELECT * FROM fn_get_rate_plan_name_by_customer();",
            "usage_summary_customer": "SELECT * FROM fn_get_usage_summary_by_plan_by_customer();",
            "rate_plan_name_provider": "SELECT * FROM fn_get_rate_plan_name_by_provider();",
            "usage_summary_provider": "SELECT * FROM fn_get_usage_summary_by_plan_by_provider();",
            "usage_summary_by_plan_by_provider_rate_plan": "SELECT * FROM fn_get_usage_summary_by_plan_by_provider_rate_plan();"
        }

        # Define which keys should be updated (replaced) vs appended
        update_keys = ["rate_plan_name_customer", "rate_plan_name_provider"]
        append_keys = ["usage_summary_customer", "usage_summary_provider", "usage_summary_by_plan_by_provider_rate_plan"]

        for key, sql in queries.items():
            df = database.execute_query(sql, True)

            if isinstance(df, pd.DataFrame) and not df.empty:
                # Print column names and sample values for debugging
                logging.info(f"\n--- {key.upper()} ---")
                logging.info(f"Columns: {list(df.columns)}")
                logging.info(f"Sample values:")
                for col in df.columns:
                    sample_value = df[col].iloc[0] if len(df) > 0 else "N/A"
                    logging.info(f"  {col}: {sample_value}")
                logging.info(f"Total rows: {len(df)}")
                
                # Data type conversions
                df["device_count"] = pd.to_numeric(df.get("device_count", 0), errors="coerce").fillna(0)
                if "total_data_usage" in df.columns:
                    df["total_data_usage"] = pd.to_numeric(df.get("total_data_usage", 0), errors="coerce").fillna(0)
                if "usage_day" in df.columns:
                    df["usage_day"] = df["usage_day"].astype(str)
                if "usage_hour_group" in df.columns:
                    df["usage_hour_group"] = df["usage_hour_group"].astype(str)

                # Determine whether to update (replace) or append data
                if key in update_keys:
                    # UPDATE: Replace the entire dataset for rate plan functions
                    cache_data[key] = df
                    logging.info(f"UPDATED cache for {key} with {len(df)} rows (replaced existing data)")
                elif key in append_keys:
                    # APPEND: Add new data to existing data for usage summary functions
                    cache_data[key] = pd.concat([old_data[key], df], ignore_index=True)
                    logging.info(f"APPENDED to cache for {key}: {len(df)} new rows, {len(cache_data[key])} total rows")
            else:
                # No new data, retain old cache
                logging.info(f"\n--- {key.upper()} ---")
                logging.info("No new data retrieved from database")
                cache_data[key] = old_data[key]

        # Print final cache summary
        logging.info("\n=== FINAL CACHE SUMMARY ===")
        for key in cache_data:
            if key != "sync_time":
                total_rows = len(cache_data[key])
                behavior = "UPDATE" if key in update_keys else "APPEND"
                logging.info(f"{key} ({behavior}): {total_rows} total rows in cache")

        # ------------------- Prepare cache to save -------------------
        cache_response = {
            "rate_plan_name_customer": cache_data["rate_plan_name_customer"].to_dict(orient="records"),
            "usage_summary_customer": cache_data["usage_summary_customer"].to_dict(orient="records"),
            "rate_plan_name_provider": cache_data["rate_plan_name_provider"].to_dict(orient="records"),
            "usage_summary_provider": cache_data["usage_summary_provider"].to_dict(orient="records"),
            "usage_summary_by_plan_by_provider_rate_plan": cache_data["usage_summary_by_plan_by_provider_rate_plan"].to_dict(orient="records"),
            "sync_time": cache_data["sync_time"].strftime("%Y-%m-%d %H:%M:%S")
        }

        # ------------------- Store in Redis (no expiry) -------------------
        try:
            redis_client.set(cache_key, json.dumps(cache_response))  # persistent cache
            redis_client.set(f"{cache_key}:timestamp", cache_data["sync_time"].strftime("%Y-%m-%d %H:%M:%S"))
            logging.info(f"Redis set successful for all 5 views: {cache_key}")
        except Exception as redis_exc:
            logging.warning(f"Redis set failed: {redis_exc}")

        # ------------------- Audit Logging -------------------
        try:
            audit_data = {
                "function_name": function_name,
                "created_by": username,
                "last_synced_by": username,
                "last_sync_date": cache_data["sync_time"],
            }
            common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
        except Exception as audit_exc:
            logging.warning(f"Audit logging failed: {audit_exc}")

        return cache_data

    except Exception as e:
        logging.error(f"Error updating usage cache: {e}")
        raise e

def get_usage_data_from_cache(cache_key, use_carrier, return_rate_plan_name=False, return_usage_summary_by_plan=False):
    """
    Get usage data from Redis cache.
    
    If return_rate_plan_name is True, returns rate_plan_name_* data.
    Otherwise, returns usage_summary_* data.
    
    Returns tuple: (result_df, cache_miss)
    """
    try:
        cached_data = redis_client.get(cache_key)
        if not cached_data:
            return pd.DataFrame(), True

        cache_response = json.loads(cached_data)

        required_keys = {
            "rate_plan_name_customer",
            "usage_summary_customer",
            "rate_plan_name_provider",
            "usage_summary_provider",
            "usage_summary_by_plan_by_provider_rate_plan"
        }

        if not required_keys.issubset(cache_response.keys()):
            return pd.DataFrame(), True

        #  Choose the correct key based on context
        if return_rate_plan_name:
            data_key = "rate_plan_name_provider" if use_carrier else "rate_plan_name_customer"
        elif return_usage_summary_by_plan:
            data_key = "usage_summary_by_plan_by_provider_rate_plan"
        else:
            data_key = "usage_summary_provider" if use_carrier else "usage_summary_customer"

        selected_data = cache_response.get(data_key, [])
        result_df = pd.DataFrame(selected_data)

        return result_df, False

    except Exception as redis_exc:
        logging.warning(f"Redis fetch error: {redis_exc}")
        return pd.DataFrame(), True

def total_usage_card(data):
    """Calculates the total data usage (in GB) for a tenant, optionally filtered by date range, service provider, or billing cycle."""
    tenant_id = data.get("tenant_id", "")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    refresh = str(data.get("refresh", "False")).lower() == "true"
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    service_provider = str(data.get("service_provider", ""))
    billing_cycle_end_period = str(data.get("billing_cycle_end_period", ""))

    response = {
        "flag": False,
        "data": {
            "total_usage_gb": 0.0,
            "usage_type": "",
            "title": "Total Usage (GB)",
        },
        "message": "",
    }

    function = "total_usage_card"
    cache_key = get_usage_insights_cache_key(tenant_database)

   

    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exc:
        response["message"] = f"Database connection error: {db_exc}"
        try:
            if 'common_utils_database' in locals():
                error_data = {
                    "service_name": function,
                    "error_message": str(db_exc),
                    "error_type": type(db_exc).__name__,
                    "users": username,
                    "tenant_name": tenant_name,
                    "comments": str(db_exc),
                    "module_name": "Dashboard",
                    "request_received_at": request_received_at,
                    "session_id": sessionID,
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"[total_usage_card] Error logging DB connection error : {e}")

    try:
        opt_tenant_id = tenant_id
        if tenant_id == "All":
            if tenant_name in ["Altaworx Test", "Altaworx"]:
                opt_tenant_id = 1
            else:
                tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id"])
                opt_tenant_id = tenant_data["id"].to_list()[0]

        opt_setting = database.get_data(
            "optimization_setting",
            {"tenant_id": opt_tenant_id},
            ["optino_cross_providercustomer_optimization"],
        )

        use_carrier = False
        if not opt_setting.empty:
            use_carrier = bool(opt_setting.iloc[0, 0])

        if refresh:
            cache_data = update_usage_cache(
                database, cache_key, function, username, request_received_at, common_utils_database
            )
            result_df = cache_data["usage_summary_carrier"] if use_carrier else cache_data["usage_summary_customer"]

            total_usage_mb = result_df["total_data_usage"].sum() if not result_df.empty else 0
            total_usage_gb = float(total_usage_mb) / 1024
            response["flag"] = True
            response["data"]["total_usage_gb"] = f"{float(total_usage_gb):,.2f}"
           
        else:
            result_df, cache_miss = get_usage_data_from_cache(cache_key, use_carrier)

            if cache_miss:
                logging.info(f"Cache miss for {cache_key}, updating cache for both views")
                cache_data = update_usage_cache(
                    database, cache_key, function, username, request_received_at, common_utils_database
                )

                result_df = cache_data["usage_summary_carrier"] if use_carrier else cache_data["usage_summary_customer"]

            response["flag"] = True

            if tenant_id != "All" or (start_date and end_date)or service_provider or billing_cycle_end_period:
                try:
                    if not result_df.empty:
                        result_df["usage_day"] = pd.to_datetime(result_df["usage_day"]).dt.date
                        result_df["total_data_usage"] = pd.to_numeric(result_df["total_data_usage"], errors="coerce").fillna(0)

                        if tenant_id != "All":
                            result_df = result_df[result_df["tenant_id"] == int(tenant_id)]
                        if service_provider and service_provider != "All":
                            result_df = result_df[result_df['service_provider_display_name'] == service_provider]
                        if billing_cycle_end_period and billing_cycle_end_period != "All":
                            billing_end_date = pd.to_datetime(billing_cycle_end_period).date()
                            result_df = result_df[result_df['usage_day'] == billing_end_date]
                          

                        if start_date and end_date:
                            start_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
                            end_dt = datetime.strptime(end_date, "%Y-%m-%d").date()
                            result_df = result_df[(result_df["usage_day"] >= start_dt) & (result_df["usage_day"] <= end_dt)]

                    total_usage_gb = result_df["total_data_usage"].sum() / 1024
                    response["data"]["total_usage_gb"] = f"{float(total_usage_gb):,.2f}"
                except Exception as e:
                    logging.warning(f"Filtering on cached data failed: {e}")
                    response["data"]["total_usage_gb"] = 0.0
            else:
                if not result_df.empty:
                    result_df["total_data_usage"] = pd.to_numeric(result_df["total_data_usage"], errors="coerce").fillna(0)
                    total_usage_gb = result_df["total_data_usage"].sum() / 1024
                    response["data"]["total_usage_gb"] = f"{float(total_usage_gb):,.2f}"
                else:
                    response["data"]["total_usage_gb"] = 0.0

        try:
            audit_data = {
                "service_name": function,
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Retrieved total usage for tenant {tenant_name}",
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"[total_usage_card] Error logging audit : {e}")

    except Exception as exception:
        response["flag"] = False
        response["data"]["total_usage_gb"] = 0.0
        response["message"] = f"Error retrieving total usage: {exception}"
        try:
            error_data = {
                "service_name": function,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"[total_usage_card] Error logging to DB : {e}")

    return response

def total_usage_sims_count(data):
    """
    Returns the total number of SIMs that have usage (usage > 0) for the tenant.
    Uses either usage_summary_provider or usage_summary_customer based on the
    optino_cross_providercustomer_optimization setting.
    """
    tenant_id = data.get("tenant_id", "")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    refresh = str(data.get("refresh", "False")).lower() == "true"
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    service_provider = str(data.get("service_provider", ""))
    billing_cycle_end_period = str(data.get("billing_cycle_end_period", ""))

    response = {
        "flag": False,
        "data": {
            "usage_sims_count": 0,
            "usage_type": "",
            "title": "Total Usage SIMs Count"
            
        },
        "message": "",
    }

    function = "total_usage_sims_count"
    cache_key = get_usage_insights_cache_key(tenant_database)

    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exc:
        response["message"] = f"Database connection error: {db_exc}"
        try:
            if 'common_utils_database' in locals():
                error_data = {
                    "service_name": function,
                    "created_date": request_received_at,
                    "error_message": str(db_exc),
                    "error_type": type(db_exc).__name__,
                    "users": username,
                    "tenant_name": tenant_name,
                    "comments": str(db_exc),
                    "module_name": "Dashboard",
                    "request_received_at": request_received_at,
                    "session_id": sessionID,
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"[total_usage_sims_count] Error logging DB connection error : {e}")

    try:
        # Resolve tenant ID
        opt_tenant_id = tenant_id
        if tenant_id == "All":
            if tenant_name in ["Altaworx Test", "Altaworx"]:
                opt_tenant_id = 1
            else:
                tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id"])
                opt_tenant_id = tenant_data["id"].to_list()[0]

        # Determine usage type (provider/customer)
        opt_setting = database.get_data(
            "optimization_setting",
            {"tenant_id": opt_tenant_id},
            ["optino_cross_providercustomer_optimization"],
        )

        use_carrier = False
        if not opt_setting.empty:
            use_carrier = bool(opt_setting.iloc[0, 0])

        response["data"]["usage_type"] = (
            "carrier_cycle_usage_mb" if use_carrier else "customer_cycle_usage_mb"
        )

       

        # Refresh flow
        if refresh:
            cache_data = update_usage_cache(
                database, cache_key, function, username, request_received_at, common_utils_database
            )
            result_df = cache_data["usage_summary_provider"] if use_carrier else cache_data["usage_summary_customer"]
            
            total_count = 0
            if not result_df.empty and "device_count" in result_df.columns:
                total_count = result_df["device_count"].sum()

            response["flag"] = True
            response["data"]["usage_sims_count"] = f"{int(total_count):,}"
            response["message"] = ""

        else:
            result_df, cache_miss = get_usage_data_from_cache(cache_key, use_carrier)
            if cache_miss:
                logging.info(f"Cache miss for {cache_key}, updating cache for both views")
                cache_data = update_usage_cache(
                    database, cache_key, function, username, request_received_at, common_utils_database
                )
                result_df = cache_data["usage_summary_provider"] if use_carrier else cache_data["usage_summary_customer"]

        # Apply tenant/date filters
        if not result_df.empty:
            result_df["device_count"] = pd.to_numeric(result_df.get("device_count", 0), errors="coerce").fillna(0)

            if "usage_day" in result_df.columns:
                result_df["usage_day"] = pd.to_datetime(result_df["usage_day"], errors="coerce").dt.date

            if tenant_id != "All":
                result_df = result_df[result_df["tenant_id"] == int(tenant_id)]
            if service_provider and service_provider != "All":
                result_df = result_df[result_df['service_provider_display_name'] == service_provider]
            if billing_cycle_end_period and billing_cycle_end_period != "All":
                billing_end_date = pd.to_datetime(billing_cycle_end_period).date()
                result_df = result_df[result_df['usage_day'] == billing_end_date]

            if start_date and end_date:
                try:
                    start_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
                    end_dt = datetime.strptime(end_date, "%Y-%m-%d").date()
                    result_df = result_df[
                        (result_df["usage_day"] >= start_dt) & (result_df["usage_day"] <= end_dt)
                    ]
                except Exception as e:
                    logging.warning(f"Date filtering failed: {e}")

            total_count = result_df["device_count"].sum()
            response["data"]["usage_sims_count"] = f"{int(total_count):,}"

        response["flag"] = True

        # Audit Logging
        try:
            audit_data = {
                "service_name": function,
                "created_date": request_received_at,
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Retrieved total usage SIMs count for tenant {tenant_name}",
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"[total_usage_sims_count] Error logging audit : {e}")

    except Exception as exception:
        response["flag"] = False
        response["data"]["usage_sims_count"] = 0
        response["message"] = f"Error retrieving total usage SIMs count : {exception}"
        try:
            error_data = {
                "service_name": function,
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"[total_usage_sims_count] Error logging to DB : {e}")

    return response

def total_usage_cost(data):
    """
    Calculates the total usage cost for all SIMs by multiplying the number of SIMs per customer_rate_plan
    with the corresponding rate from the customerrateplan table.
    """
    tenant_id = data.get("tenant_id", "")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = parse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.now().date()
    tenant_name = data.get("tenant_name", "")
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
    refresh = str(data.get("refresh", "False")).lower() == "true"
    service_provider = str(data.get("service_provider", ""))
    billing_cycle_end_period = str(data.get("billing_cycle_end_period", ""))

    function = "total_usage_cost"
    cache_key = get_usage_insights_cache_key(tenant_database)

    response = {
        "flag": False,
        "data": {
            "total_usage_cost": 0.0,
            "breakdown": [],
            "title": "Total Usage Cost"
        },
        "message": "",
    }

    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exc:
        response["message"] = f"Database connection error: {db_exc}"
        try:
            if 'common_utils_database' in locals():
                error_data = {
                    "service_name": function,
                    "error_message": str(db_exc),
                    "error_type": type(db_exc).__name__,
                    "users": username,
                    "tenant_name": tenant_name,
                    "comments": str(db_exc),
                    "module_name": "Dashboard",
                    "request_received_at": request_received_at,
                    "session_id": sessionID,
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"[total_usage_cost] Error logging DB connection error : {e}")

    try:
        if refresh:
            cache_data = update_usage_cache(
                database, cache_key, function, username, request_received_at, common_utils_database
            )
            result_df = cache_data["rate_plan_name_provider"]
        else:
            result_df, cache_miss = get_usage_data_from_cache(cache_key, use_carrier=True, return_rate_plan_name=True)



            if cache_miss:
                logging.info(f"Cache miss for {cache_key}, updating cache for both views")
                cache_data = update_usage_cache(
                    database, cache_key, function, username, request_received_at, common_utils_database
                )
                result_df = cache_data["rate_plan_name_provider"]

        if not result_df.empty:
            logging.info(f"[total_usage_cost] result_df columns (from cache): {result_df.columns.tolist()}")
            required_columns = ['customer_rate_plan_name', 'tenant_id', 'usage_day', 'device_count']
            missing_cols = [col for col in required_columns if col not in result_df.columns]
            if missing_cols:
                logging.error(f"[total_usage_cost] Missing columns in result_df: {missing_cols}")
                query_df = pd.DataFrame()
            else:
                query_df = result_df.groupby(['customer_rate_plan_name', 'tenant_id', 'usage_day'])['device_count'].sum().reset_index()
                query_df.columns = ['customer_rate_plan_name', 'tenant_id', 'usage_day', 'sim_count']
        else:
            query_df = pd.DataFrame()

        if not query_df.empty:
            df = query_df.copy()
            if tenant_id != "All":
                tenant_id_int = int(tenant_id)
                df = df[df["tenant_id"] == tenant_id_int]
            if start_date and end_date:
                df["usage_day"] = pd.to_datetime(df["usage_day"]).dt.date
                df = df[(df["usage_day"] >= start_date) & (df["usage_day"] <= end_date)]
            if service_provider and service_provider != "All":
                df = df[result_df['service_provider_display_name'] == service_provider]
            if billing_cycle_end_period and billing_cycle_end_period != "All":
                billing_end_date = pd.to_datetime(billing_cycle_end_period).date()
                df = df[df['usage_day'] == billing_end_date]
            if df.empty:
                total_cost = 0
                breakdown = []
            else:
                df = df.dropna(subset=["customer_rate_plan_name"])
                rate_plan_names = df["customer_rate_plan_name"].dropna().unique().tolist()

                if rate_plan_names:
                    rate_query = """
                        SELECT rate_plan_name, display_rate
                        FROM customerrateplan
                        WHERE is_active = true AND tenant_id = %s AND rate_plan_name IN %s
                    """
                    rate_df = database.execute_query(rate_query, params=[tenant_id, tuple(rate_plan_names)])
                    rate_map = dict(zip(rate_df["rate_plan_name"], rate_df["display_rate"])) if isinstance(rate_df, pd.DataFrame) else {}

                    total_cost = 0
                    breakdown = []
                    grouped = df.groupby("customer_rate_plan_name")["sim_count"].sum().reset_index()
                    for _, row in grouped.iterrows():
                        plan = row["customer_rate_plan_name"]
                        count = row["sim_count"]
                        rate = float(rate_map.get(plan, 0))
                        cost = count * rate
                        total_cost += cost
                        breakdown.append({
                            "rate_plan_name": plan,
                            "sim_count": int(count),
                            "rate": rate,
                            "cost": cost
                        })
                else:
                    total_cost = 0
                    breakdown = []
        else:
            total_cost = 0
            breakdown = []

        response = {
            "flag": True,
            "data": {
                "total_usage_cost": f"{round(total_cost, 2):,}",
                "breakdown": breakdown,
                "title": "Total Usage Cost"
            }
        }

        try:
            audit_data = {
                "service_name": function,
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Retrieved total usage cost for tenant {tenant_name}",
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"[total_usage_cost] Error logging audit : {e}")

    except Exception as e:
        response = {
            "flag": False,
            "data": {
                "total_usage_cost": 0.0,
                "breakdown": [],
                "title": "Total Usage Cost"
            },
            "message": f"Error retrieving total usage cost: {e}",
        }
        try:
            error_data = {
                "service_name": function,
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(e),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"[total_usage_cost] Error logging to DB : {e}")

    return response

def average_usage_card(data):
    """
    Returns the average usage (GB) per SIM for the tenant, using either 
    usage_summary_provider or usage_summary_customer from Redis cache,
    depending on the optimization setting.
    """
    tenant_id = data.get("tenant_id", "")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    refresh = str(data.get("refresh", "False")).lower() == "true"
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    service_provider = str(data.get("service_provider", ""))
    billing_cycle_end_period = str(data.get("billing_cycle_end_period", ""))

    response = {
        "flag": False,
        "data": {
            "average_usage_gb": 0.0,
            "usage_type": "",
            "title": "Average Usage per SIM (GB)",
            
        },
        "message": "",
    }

    function = "average_usage_card"
    cache_key = get_usage_insights_cache_key(tenant_database)

    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exc:
        response["message"] = f"Database connection error: {db_exc}"
        try:
            if 'common_utils_database' in locals():
                error_data = {
                    "service_name": function,
                    "created_date": request_received_at,
                    "error_message": str(db_exc),
                    "error_type": type(db_exc).__name__,
                    "users": username,
                    "tenant_name": tenant_name,
                    "comments": str(db_exc),
                    "module_name": "Dashboard",
                    "request_received_at": request_received_at,
                    "session_id": sessionID,
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"[average_usage_card] Error logging DB connection error : {e}")
        return response

    try:
        # Resolve tenant ID for optimization
        opt_tenant_id = tenant_id
        if tenant_id == "All":
            if tenant_name in ["Altaworx Test", "Altaworx"]:
                opt_tenant_id = 1
            else:
                tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id"])
                opt_tenant_id = tenant_data["id"].to_list()[0]

        # Get optimization setting
        opt_setting = database.get_data(
            "optimization_setting",
            {"tenant_id": opt_tenant_id},
            ["optino_cross_providercustomer_optimization"],
        )

        use_carrier = False
        if not opt_setting.empty:
            use_carrier = bool(opt_setting.iloc[0, 0])

        response["data"]["usage_type"] = "carrier_cycle_usage" if use_carrier else "customer_cycle_usage"

        if refresh:
            cache_data = update_usage_cache(
                database, cache_key, function, username, request_received_at, common_utils_database
            )
            result_df = cache_data["usage_summary_provider"] if use_carrier else cache_data["usage_summary_customer"]
            
            if not result_df.empty:
                result_df["total_data_usage"] = pd.to_numeric(result_df["total_data_usage"], errors="coerce").fillna(0)
                result_df["device_count"] = pd.to_numeric(result_df["device_count"], errors="coerce").fillna(0)
                total_usage_mb = result_df["total_data_usage"].sum()
                total_device_count = result_df["device_count"].sum()
            else:
                total_usage_mb = 0
                total_device_count = 0

            average_usage_gb = (total_usage_mb / total_device_count / 1024) if total_device_count > 0 else 0

            response["flag"] = True
            response["data"]["average_usage_gb"] = f"{float(average_usage_gb):,.2f}"
            response["message"] = ""

        else:
            # Try to load from cache
            result_df, cache_miss = get_usage_data_from_cache(cache_key, use_carrier)

            if cache_miss:
                logging.info(f"Cache miss for {cache_key}, updating cache for both views")
                cache_data = update_usage_cache(
                    database, cache_key, function, username, request_received_at, common_utils_database
                )
                result_df = cache_data["usage_summary_provider"] if use_carrier else cache_data["usage_summary_customer"]

            response["flag"] = True

            if not result_df.empty:
                result_df["usage_day"] = pd.to_datetime(result_df["usage_day"], errors="coerce").dt.date
                result_df["total_data_usage"] = pd.to_numeric(result_df["total_data_usage"], errors="coerce").fillna(0)
                result_df["device_count"] = pd.to_numeric(result_df["device_count"], errors="coerce").fillna(0)

                if tenant_id != "All":
                    result_df = result_df[result_df["tenant_id"] == int(tenant_id)]
                if service_provider and service_provider != "All":
                    result_df = result_df[result_df['service_provider_display_name'] == service_provider]
                if billing_cycle_end_period and billing_cycle_end_period != "All":
                    billing_end_date = pd.to_datetime(billing_cycle_end_period).date()
                    result_df = result_df[result_df['usage_day'] == billing_end_date]

                if start_date and end_date:
                    start_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
                    end_dt = datetime.strptime(end_date, "%Y-%m-%d").date()
                    result_df = result_df[
                        (result_df["usage_day"] >= start_dt) &
                        (result_df["usage_day"] <= end_dt)
                    ]

                total_usage_mb = result_df["total_data_usage"].sum()
                total_device_count = result_df["device_count"].sum()
                average_usage_gb = (total_usage_mb / total_device_count / 1024) if total_device_count > 0 else 0
                response["data"]["average_usage_gb"] = f"{float(average_usage_gb):,.2f}"
            else:
                response["data"]["average_usage_gb"] = 0.0

        # Audit
        try:
            audit_data = {
                "service_name": function,
                "created_date": request_received_at,
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Retrieved average usage for tenant {tenant_name}",
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"[average_usage_card] Error logging audit : {e}")

    except Exception as exception:
        response["flag"] = False
        response["data"]["average_usage_gb"] = 0.0
        response["message"] = f"Error retrieving average usage : {exception}"
        try:
            error_data = {
                "service_name": function,
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"[average_usage_card] Error logging to DB : {e}")

    return response

def generate_bucket_ranges(df, date_column='modified_date', min_date=None):
    """Generates predefined date bucket ranges (daily, weekly, monthly, yearly) based on a DataFrame and  minimum date."""

    today = datetime.now().date()
    if min_date is None and not df.empty:
        min_date = df[date_column].min()
    if min_date is None:
        min_date = today
    if hasattr(min_date, 'date'):
        min_date = min_date.date()

    ranges = {
        '1_day': {'start': today, 'end': today, 'type': 'hourly'},
        '5_day': {'start': today - timedelta(days=4), 'end': today, 'type': 'daily'},
        '1_month': {'start': today.replace(day=1), 'end': today, 'type': 'weekly'},
        '3_month': {'start': (today.replace(day=1) - timedelta(days=60)).replace(day=1), 'end': today, 'type': 'weekly'},
        '6_month': {'start': (today.replace(day=1) - timedelta(days=150)).replace(day=1), 'end': today, 'type': 'weekly'},
        '1_year': {'start': today.replace(month=1, day=1), 'end': today, 'type': 'weekly'},
        '5_years': {'start': today.replace(year=today.year-4, month=1, day=1), 'end': today, 'type': 'yearly'},
        'max': {'start': min_date, 'end': today, 'type': 'yearly'},
        'custom_range': {'start': min_date, 'end': today, 'type': 'weekly'}
    }
    return ranges, '1_month'

def assign_week_label(day):
    """Return the week number in a month (1-4)"""
    d = day.day
    if d <= 7:
        return 1
    elif d <= 14:
        return 2
    elif d <= 21:
        return 3
    else:
        return 4

def process_grouped(df_filtered, bucket_type):
    """
    Group data based on bucket_type and return dict in original format:
    { "2025-07-25": 396849763.88 }
    All keys/values are converted to Python native types.
    """
    grouped = defaultdict(list)

    if bucket_type == 'hourly':
        cols = ['tenant_id','service_provider_id','service_provider_display_name','usage_hour_group']
        grouped_df = df_filtered.groupby(cols)['usage_gb'].sum().reset_index()
        for _, row in grouped_df.iterrows():
            tid = int(row['tenant_id'])
            pid = int(row['service_provider_id'])
            grouped[(tid, pid)].append({str(row['usage_hour_group']): float(row['usage_gb'])})

    elif bucket_type == 'daily':
        cols = ['tenant_id','service_provider_id','service_provider_display_name','usage_day']
        grouped_df = df_filtered.groupby(cols)['usage_gb'].sum().reset_index()
        for _, row in grouped_df.iterrows():
            tid = int(row['tenant_id'])
            pid = int(row['service_provider_id'])
            grouped[(tid, pid)].append({row['usage_day'].strftime('%Y-%m-%d'): float(row['usage_gb'])})

    elif bucket_type == 'weekly':
        df_filtered['week_of_month'] = df_filtered['usage_day'].apply(assign_week_label)
        for (tid, pid), group in df_filtered.groupby(['tenant_id','service_provider_id']):
            tid = int(tid)
            pid = int(pid)
            for (year, month, week), week_df in group.groupby([df_filtered['usage_day'].apply(lambda d: d.year),
                                                               df_filtered['usage_day'].apply(lambda d: d.month),
                                                               'week_of_month']):
                last_day = week_df['usage_day'].max()
                total_usage = float(week_df['usage_gb'].sum())
                grouped[(tid,pid)].append({last_day.strftime('%Y-%m-%d'): total_usage})

    elif bucket_type == 'yearly':
        df_filtered['year'] = pd.to_datetime(df_filtered['usage_day']).dt.year
        for (tid,pid), group in df_filtered.groupby(['tenant_id','service_provider_id']):
            tid = int(tid)
            pid = int(pid)
            for year, year_df in group.groupby('year'):
                last_day = datetime(int(year),12,31).date()
                total_usage = float(year_df['usage_gb'].sum())
                # Only use the year as label (works for both 5_years and max buckets)
                grouped[(tid, pid)].append({str(year): total_usage})
    # elif bucket_type == 'bi_yearly':
    #     df_filtered['year'] = pd.to_datetime(df_filtered['usage_day']).dt.year
    #     start_year = int(df_filtered['year'].min())
    #     end_year = int(df_filtered['year'].max())
    #     bins = list(range(start_year, end_year + 2, 2))
    #     for (tid,pid), group in df_filtered.groupby(['tenant_id','service_provider_id']):
    #         tid = int(tid)
    #         pid = int(pid)
    #         for i in range(len(bins)-1):
    #             start = bins[i]
    #             end = bins[i+1]-1
    #             period_df = group[(group['year']>=start) & (group['year']<=end)]
    #             if not period_df.empty:
    #                 last_day = datetime(int(end),12,31).date()
    #                 total_usage = float(period_df['usage_gb'].sum())
    #                 grouped[(tid,pid)].append({last_day.strftime('%Y-%m-%d'): total_usage})

    return grouped

def get_matching_bucket(bucket_ranges, start_date, end_date):
    """
    Decide which predefined bucket a given date range belongs to.
    """
    start_ts = pd.to_datetime(start_date)
    end_ts = pd.to_datetime(end_date)
    date_diff = (end_ts - start_ts).days

    if date_diff <= 1:
        return "1_day"
    elif date_diff <= 6:
        return "5_day"
    elif date_diff <= 31:
        return "1_month"
    elif date_diff <= 93:
        return "3_month"
    elif date_diff <= 186:
        return "6_month"
    elif date_diff <= 366:
        return "1_year"
    elif date_diff <= 1826:
        return "5_years"
    else:
        return "max"

def get_usage_trend_by_provider(data):
    """
        Retrieves usage trends by service provider for a tenant, optionally filtered by date, tenant, service provider, 
        or billing cycle. It handles caching, bucketed aggregation (daily/weekly/monthly/yearly), and audit/error logging.

        Args:
            data (dict): Contains keys such as:
                - 'db_name' (str): Tenant database name.
                - 'tenant_name' (str, optional): Tenant display name.
                - 'tenant_id' (str/int, optional): Tenant ID filter.
                - 'start_date', 'end_date' (str/datetime, optional): Date range for filtering.
                - 'service_provider' (str, optional): Filter for a specific provider.
                - 'billing_cycle_end_period' (str, optional): Filter by billing cycle end date.
                - 'refresh' (bool/str, optional): Force cache refresh.
                - 'username', 'sessionID', 'request_received_at' (str, optional): Audit info.

        Returns:
            dict: Response containing:
                - 'flag' (bool): True if successful, False on error.
                - 'data' (dict): Chart configuration and aggregated usage data.
                - 'meta' (dict): Tenant and provider metadata, default time range.
                - 'message' (str, optional): Error message if operation failed.
    """

    # Initialize response
    response = {
        "flag": False,
        "data": {
            "title": "Usage Trend",
            "chart_type": "stacked_bar",
            "data": [],
            "xField": "time",
            "yField": "usage_gb",
            "smooth": True,
            "height": 300,
            "width": 500,
        }
    }

    FUNCTION_NAME = "get_usage_trend_by_provider"
    logging.info(f"[{FUNCTION_NAME}] Start at {pd.Timestamp.now()}")
    
    try:
        # Extract parameters safely
        params = {
            'tenant_name': str(data.get("tenant_name", "")),
            'tenant_id': str(data.get("tenant_id", "")),
            'db_name': str(data.get("db_name", "")),
            'start_date': safe_date_parse(data.get("start_date")),
            'end_date': safe_date_parse(data.get("end_date")),
            'refresh': str(data.get("refresh", "False")).lower() == "true",
            'username': str(data.get("username", "")),
            'sessionID': str(data.get("sessionID", "")),
            'request_received_at': str(data.get("request_received_at", "")),
            'billing_cycle_end_period': str(data.get("billing_cycle_end_period", "")),
            'service_provider': str(data.get("service_provider", ""))
        }

        # Validate required parameters
        if not params['db_name']:
            response["message"] = "Database name is required"
            return response

        # Database connections
        database = DB(params['db_name'], **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        # Cache operations
        cache_key = get_usage_insights_cache_key(params['db_name'])
        use_customer = False  # placeholder

        # Get data from cache or refresh
        if params['refresh']:
            cache_data = update_usage_cache(
                database, cache_key, FUNCTION_NAME, 
                params['username'], params['request_received_at'], common_utils_database
            )
            result_df = cache_data.get("usage_summary_provider", pd.DataFrame())
        else:
            result_df, cache_miss = get_usage_data_from_cache(cache_key, use_customer)
            if cache_miss:
                cache_data = update_usage_cache(
                    database, cache_key, FUNCTION_NAME,
                    params['username'], params['request_received_at'], common_utils_database
                )
                result_df = cache_data.get("usage_summary_provider", pd.DataFrame())

        # Early exit if no data (using proper DataFrame empty check)
        if result_df.empty if isinstance(result_df, pd.DataFrame) else not result_df:
            response["flag"]=True
            response["message"] = "No data available"
            return response

        # Convert to DataFrame if not already
        if not isinstance(result_df, pd.DataFrame):
            try:
                df = pd.DataFrame(result_df)
            except Exception as e:
                response["message"] = f"Data conversion error: {str(e)}"
                return response
        else:
            df = result_df.copy()

        # Process DataFrame with proper type checking
        try:
            df['usage_day'] = pd.to_datetime(df['usage_day']).dt.date
            df['usage_gb'] = (df['total_data_usage'] / 1024).round(2)
        except KeyError as e:
            response["message"] = f"Missing required column: {str(e)}"
            return response
        except Exception as e:
            response["message"] = f"Data processing error: {str(e)}"
            return response
    
        # 🔎 Debug: logging.info last row info
        try:
            last_row = df.tail(1).to_dict(orient="records")[0]
            logging.info(
                f"[{FUNCTION_NAME}] Last row sample: usage_day={last_row.get('usage_day')}, "
                f"usage_hour_group={last_row.get('usage_hour_group')}, full_row={last_row}"
            )
        except Exception as dbg_err:
            logging.warning(f"[{FUNCTION_NAME}] Failed to log last row: {dbg_err}")

        # Filter by tenant if needed
        if params['tenant_id'] and params['tenant_id'] != "All":
            try:
                df = df[df['tenant_id'] == int(params['tenant_id'])]
                if df.empty:
                    response["message"] = "No data available for specified tenant"
                    return response
            except ValueError:
                response["message"] = "Invalid tenant ID format"
                return response
        
         # Filter by service provider if needed
        if params['service_provider'] and params['service_provider'] != "":
            if 'service_provider_display_name' in df.columns:
                try:
                    df = df[df['service_provider_display_name'].astype(str) == str(params['service_provider'])]
                    if df.empty:
                        response["message"] = "No data available for specified service provider"
                        response["flag"] = True
                        return response
                except Exception as e:
                    response["message"] = f"Service provider filtering error: {str(e)}"
                    return response
            else:
                response["message"] = "Column 'service_provider_display_name' not found in data"
                return response

        # Filter by billing cycle end date (usage_day) if provided
        if params['billing_cycle_end_period'] and params['billing_cycle_end_period'] != "All":
            if 'usage_day' in df.columns:
                try:
                    billing_end_date = pd.to_datetime(params['billing_cycle_end_period']).date()
                    df = df[df['usage_day'] == billing_end_date]
                    if df.empty:
                        response["message"] = f"No data available for billing cycle ending on {billing_end_date}"
                        response["flag"] = True
                        return response
                except Exception as e:
                    response["message"] = f"Billing cycle filtering error: {str(e)}"
                    return response
            else:
                response["message"] = "Column 'usage_day' not found in data"
                return response

        # Date filtering with proper checks
        if params['start_date'] and params['end_date']:
            try:
                df = df[
                    (df['usage_day'] >= params['start_date']) & 
                    (df['usage_day'] <= params['end_date'])
                ]
                if df.empty:
                    response["message"] = "No data available for specified date range"
                    return response
            except Exception as e:
                response["message"] = f"Date filtering error: {str(e)}"
                return response

        min_date = df['usage_day'].min() if not df.empty else None

        # Generate bucket ranges
        try:
            bucket_ranges, default_label = generate_bucket_ranges(df, 'usage_day', min_date)
            all_buckets = {label: [] for label in bucket_ranges.keys()}
        except Exception as e:
            response["message"] = f"Bucket generation error: {str(e)}"
            return response

        # Pre-compute provider names mapping
        try:
            provider_names = df.drop_duplicates('service_provider_id').set_index('service_provider_id')['service_provider_display_name'].to_dict()
            meta_providers = {int(k): str(v) for k, v in provider_names.items()}
            meta_tenants = {}
        except Exception as e:
            response["message"] = f"Provider mapping error: {str(e)}"
            return response

        # Process each bucket
        # Process each bucket
        if params['start_date'] and params['end_date']:
            # Determine which predefined bucket this date range corresponds to
            label = get_matching_bucket(bucket_ranges, params['start_date'], params['end_date'])
            cfg = bucket_ranges.get(label, {
                'start': params['start_date'],
                'end': params['end_date'],
                'type': 'daily'
            })

            df_filtered = df[
                (df['usage_day'] >= cfg['start']) & 
                (df['usage_day'] <= cfg['end'])
            ].copy()

            if not df_filtered.empty:
                grouped = process_grouped(df_filtered, cfg['type'])
                for (tid, pid), records in grouped.items():
                    all_buckets[label].append({
                        "tenant_id": int(tid),
                        "provider_id": int(pid),
                        "records": serialize_data(records)
                    })
                    meta_tenants[int(tid)] = ""
        else:
            for label, cfg in bucket_ranges.items():
                df_filtered = df[
                    (df['usage_day'] >= cfg['start']) & 
                    (df['usage_day'] <= cfg['end'])
                ].copy()

                if not df_filtered.empty:
                    grouped = process_grouped(df_filtered, cfg['type'])
                    for (tid, pid), records in grouped.items():
                        all_buckets[label].append({
                            "tenant_id": int(tid),
                            "provider_id": int(pid),
                            "records": serialize_data(records)
                        })
                        meta_tenants[int(tid)] = ""


        # Fetch tenant names in bulk
        if meta_tenants:
            try:
                tenant_ids = list(meta_tenants.keys())
                if tenant_ids:  # Check if there are any tenant IDs to query
                    query = """
                        SELECT id AS tenant_id, tenant_name 
                        FROM tenant 
                        WHERE id IN ({})
                    """.format(','.join(['%s'] * len(tenant_ids)))
                    
                    tenant_names = common_utils_database.execute_query(query, params=tenant_ids)
                    
                    if isinstance(tenant_names, pd.DataFrame) and not tenant_names.empty:
                        meta_tenants.update(
                            tenant_names.set_index('tenant_id')['tenant_name']
                                      .astype(str)
                                      .to_dict()
                        )
            except Exception as e:
                logging.warning(f"[{FUNCTION_NAME}] Failed to fetch tenant names: {str(e)}")

        # Build final response
        response.update({
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "providers": meta_providers,
                "default_time_range": default_label,
            },
            "data": {
                "title": "Usage Trend",
                "chart_type": "stacked_bar",
                "xField": "time",
                "yField": "usage_gb",
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            }
        })

        # Audit logging
        try:
            audit_data = {
                "service_name": FUNCTION_NAME,
                "created_by": params['username'],
                "status": "Success",
                "tenant_name": params['tenant_name'],
                "comments": f"Retrieved usage trend by provider for tenant {params['tenant_name']}",
                "module_name": "Dashboard",
                "request_received_at": params['request_received_at'],
                "session_id": params['sessionID'],
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"[{FUNCTION_NAME}] Error logging audit: {str(e)}")

        return response

    except Exception as e:
        error_msg = f"Unexpected error: {str(e)}"
        logging.error(f"[{FUNCTION_NAME}] {error_msg}", exc_info=True)
        response["message"] = f"Error retrieving usage trend by provider: {error_msg}"
        
        try:
            if 'common_utils_database' in locals():
                error_data = {
                    "service_name": FUNCTION_NAME,
                    "created_date": params.get('request_received_at', ''),
                    "error_message": str(e),
                    "error_type": type(e).__name__,
                    "users": params['username'],
                    "tenant_name": params['tenant_name'],
                    "comments": str(e),
                    "module_name": "Dashboard",
                    "request_received_at": params['request_received_at'],
                    "session_id": params['sessionID'],
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_err:
            logging.warning(f"[{FUNCTION_NAME}] Failed to log error: {str(log_err)}")
        
        return response

def safe_date_parse(date_str):
    """Helper function to safely parse dates"""
    if not date_str:
        return None
    try:
        return datetime.strptime(str(date_str), "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None
       
def get_service_type_usage_distribution(data):
    
    """
        Retrieves service type usage distribution for tenants and service providers, performs filtering by tenant, service provider, 
        billing cycle, and date range, computes bucketed aggregations (daily/weekly/monthly/yearly), calculates percentage usage per period, 
        and returns data in a JSON-serializable format suitable for charting.

        Args:
            data (dict): Input parameters including:
                - 'db_name' (str): Tenant database name.
                - 'tenant_name' (str, optional): Display name of the tenant.
                - 'tenant_id' (str/int, optional): Tenant ID filter.
                - 'start_date', 'end_date' (str, optional): Date range for filtering.
                - 'service_provider' (str, optional): Filter by provider name.
                - 'billing_cycle_end_period' (str, optional): Filter by billing cycle end date.
                - 'refresh' (bool/str, optional): Force cache refresh.
                - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.

        Returns:
            dict: JSON-serializable response containing:
                - 'flag' (bool): True if successful, False on error.
                - 'meta' (dict): Tenant and provider metadata, default time range.
                - 'data' (dict): Chart-ready data with bucketed usage percentages.
                - 'message' (str): Error message if applicable.
    """

    response = {
        "flag": False,
        "data": {
            "title": "Service Type Usage Distribution",
            "chart_type": "stacked_bar",
            "data": {},
            "xField": "date",
            "yField": "usage",
            "smooth": True,
            "height": 300,
            "width": 500,
        },
        "message": ""
    }
    try:
        # Initialization and input parsing
        tenant_name = data.get("tenant_name", "")
        tenant_id = data.get("tenant_id", "")
        tenant_database = data.get("db_name", "")
        start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
        end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        request_received_at = data.get("request_received_at", "")
        refresh = str(data.get("refresh", "False")).lower() == "true"
        service_provider = str(data.get("service_provider", ""))
        billing_cycle_end_period = str(data.get("billing_cycle_end_period", ""))
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        function = "get_service_type_usage_distribution"
        cache_key = get_usage_insights_cache_key(tenant_database)
        
        use_customer = False  # placeholder

        # Fetch data
        if refresh:
            cache_data = update_usage_cache(database, cache_key, function, username, request_received_at, common_utils_database)
            result_df = cache_data["usage_summary_customer"] if use_customer else cache_data["usage_summary_provider"]
        else:
            result_df, cache_miss = get_usage_data_from_cache(cache_key, use_customer)
            if cache_miss:
                cache_data = update_usage_cache(database, cache_key, function, username, request_received_at, common_utils_database)
                result_df = cache_data["usage_summary_customer"] if use_customer else cache_data["usage_summary_provider"]

        # Convert to DataFrame
        df_all = pd.DataFrame(result_df) if not result_df.empty else pd.DataFrame()
        
        if not df_all.empty:
            df_all['usage_day'] = pd.to_datetime(df_all['usage_day']).dt.date
            if tenant_id != "All":
                df_all = df_all[df_all['tenant_id'] == int(tenant_id)]
            if start_date and end_date:
                df_all = df_all[(df_all['usage_day'] >= start_date) & (df_all['usage_day'] <= end_date)]
            if service_provider and service_provider != "All":
                try:
                   
                    
                    df_all = df_all[df_all['service_provider_display_name'] == service_provider]
                    if df_all.empty:
                        response["message"] = "No data available for specified service provider"
                        response["flag"] = True
                        return response
                except Exception as e:
                    response["message"] = f"Service provider filtering error: {str(e)}"
                    return response

            # Filter by billing cycle end date if provided
            logging.info("billing_cycle_end_period:", billing_cycle_end_period)
            if billing_cycle_end_period and billing_cycle_end_period != "All":
                try:
                    # Convert timestamp string to date
                    billing_end_date = pd.to_datetime(billing_cycle_end_period).date()
                    logging.info("billing_end_date:", billing_end_date)
                    df_all = df_all[df_all['usage_day'] == billing_end_date]
                    logging.info("df_all345:", df_all)
                    
                    if df_all.empty:
                        response["message"] = f"No data available for billing cycle ending on {billing_end_date}"
                        response["flag"] = True
                        return response
                except Exception as e:
                    response["message"] = f"Billing cycle filtering error: {str(e)}"
                    return response
            # Service provider filtering
           

            
            # Rename column total_data_usage → usage_gb for shared functions
            if 'total_data_usage' in df_all.columns:
                df_all = df_all.rename(columns={'total_data_usage': 'usage_gb'})
            
           
            min_date = df_all['usage_day'].min()
            
            
        else:
            min_date = None
            

        logging.info("Filtered DataFrame:")
        logging.info(df_all)

        # Generate bucket ranges and initialize response structure
        bucket_ranges, default_label = generate_bucket_ranges(df_all, 'usage_day', min_date)
        logging.info("Bucket ranges:", bucket_ranges)
        all_buckets = {label: [] for label in bucket_ranges.keys()}
        meta_tenants = {}
        meta_providers = {}
        provider_id_to_name = {}

        # Build provider name mapping once
        if not df_all.empty:
            unique_providers = df_all['service_provider_id'].unique()
            for pid in unique_providers:
                provider_rows = df_all[df_all['service_provider_id'] == pid]
                if not provider_rows.empty:
                    provider_id_to_name[pid] = provider_rows.iloc[0]['service_provider_display_name']
        
        

        # Process each time bucket
        # Process each time bucket
        for label, cfg in bucket_ranges.items():
            bucket_data = []
            logging.info("==== Raw df_all head ====")
            logging.info(df_all.head(10))  # Show first 10 rows
            logging.info(f"Columns: {df_all.columns.tolist()}")
            logging.info(f"dtypes: {df_all.dtypes}")
            logging.info("==== After conversion usage_day ====")
            logging.info(df_all['usage_day'].head(10))
            if not df_all.empty:
                df_filtered = df_all[(df_all['usage_day'] >= cfg['start']) & (df_all['usage_day'] <= cfg['end'])]
                logging.info("df_filtered:",df_filtered)
                if not df_filtered.empty:
                    grouped = process_grouped(df_filtered, cfg['type'])
                    
                    for (tid, pid), records in grouped.items():
                        total_usage = sum(list(r.values())[0] for r in records)
                        if total_usage == 0:
                            continue
                            
                        formatted_records = []
                        for rec in records:
                            period = list(rec.keys())[0]
                            usage_val = list(rec.values())[0]
                            percentage = (usage_val / total_usage) * 100
                            formatted_records.append([period, f"{percentage:.2f}%"])
                        
                        bucket_data.append({
                            "tenant_id": tid,
                            "provider_id": pid,
                            "records": serialize_data(formatted_records)
                        })
                        
                        meta_tenants[tid] = ""
                        if pid in provider_id_to_name:
                            meta_providers[pid] = provider_id_to_name[pid]
            
            all_buckets[label] = bucket_data

        # --- New: Filter buckets based on start_date / end_date ---
        if start_date and end_date:
            # Determine the main bucket
            main_bucket = get_matching_bucket(bucket_ranges, start_date, end_date)
            
            # Create a custom_range bucket
            df_filtered = df_all[(df_all['usage_day'] >= start_date) & (df_all['usage_day'] <= end_date)]
            custom_bucket_data = []
            if not df_filtered.empty:
                grouped = process_grouped(df_filtered, 'daily')  # daily grouping for custom range
                for (tid, pid), records in grouped.items():
                    custom_bucket_data.append({
                        "tenant_id": tid,
                        "provider_id": pid,
                        "records": serialize_data(records)
                    })
            
            all_buckets["custom_range"] = custom_bucket_data
            
            
            # Keep only main_bucket + custom_range
            # Keep all bucket keys, empty those not main_bucket or custom_range
            # for k in all_buckets.keys():
            #     if k != main_bucket and k != "custom_range":
            #         all_buckets[k] = []
            for k in all_buckets.keys():
                if k != main_bucket:
                    all_buckets[k] = []



        # Populate tenant names
        if meta_tenants:
            tenant_ids = list(meta_tenants.keys())
            query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(tenant_ids))})"
            df_tenants = common_utils_database.execute_query(query, params=tenant_ids)
            if isinstance(df_tenants, pd.DataFrame):
                for _, row in df_tenants.iterrows():
                    meta_tenants[row["tenant_id"]] = row["tenant_name"]

        # Build final response
        response = {
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "providers": meta_providers,
                "default_time_range": default_label
            },
            "data": {
                "title": "Service Type Usage Distribution",
                "chart_type": "stacked_bar",
                "xField": "date",
                "yField": list(meta_providers.values()),
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            },
            "message": ""
        }
        return response

    except Exception as exception:
        # Error handling
        logging.error(f"[get_service_type_usage_distribution] Unexpected error: {exception}")
        response["message"] = f"Error retrieving service type usage distribution: {exception}"
        try:
            error_data = {
                "service_name": "get_service_type_usage_distribution",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_err:
            logging.warning(f"Failed to log error: {log_err}")
        return response

def get_usage_by_carrier_weekly_distribution(data):
    """
    Retrieves total data usage in GB grouped by service provider (on each day) for a given tenant with optional date filters.
    Implements Redis caching mechanism for improved performance.
    Ensures robust exception handling and always returns all expected keys in the response.
    Args:
        data (dict): Input parameters including:  
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'billing_cycle_end_period' (str, optional): Filter by billing cycle end date
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'data' (dict): Chart-ready data with usage by carrier/provider.
            - 'message' (str): Error message if applicable.
            
    
    """
    response = {
        "flag": False,
        "data": {
            "title": "Usage by Carrier / Provider",
            "chart_type": "bar",
            "data": [],
            "yField": [],
            "xField": "usage_gb",
            "smooth": True,
            "height": 300,
            "width": 500,
        },
        "message": "",
    }
    try:
        tenant_name = data.get("tenant_name", "")
        tenant_id = data.get("tenant_id", "")
        tenant_database = data.get("db_name", "")
        start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
        end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        request_received_at = data.get("request_received_at", "")
        refresh = str(data.get("refresh", "False")).lower() == "true"
        service_provider = str(data.get("service_provider", ""))
        billing_cycle_end_period = str(data.get("billing_cycle_end_period", ""))


        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        function = "get_service_type_usage_distribution"
        cache_key = get_usage_insights_cache_key(tenant_database)
        # Generate cache key and retrieve optimization
       
        use_customer = False  # placeholder for optimization logic
 
        # Fetch data
        if refresh:
            cache_data = update_usage_cache(database, cache_key, function, username, request_received_at, common_utils_database)
            result_df = cache_data["usage_summary_customer"] if use_customer else cache_data["usage_summary_provider"]
        else:
            result_df, cache_miss = get_usage_data_from_cache(cache_key, use_customer)
            if cache_miss:
                cache_data = update_usage_cache(database, cache_key, function, username, request_received_at, common_utils_database)
                result_df = cache_data["usage_summary_customer"] if use_customer else cache_data["usage_summary_provider"]

        df_all = pd.DataFrame(result_df) if not result_df.empty else pd.DataFrame()
        if not df_all.empty:
            df_all['usage_day'] = pd.to_datetime(df_all['usage_day']).dt.date
            df_all['usage_gb'] = (df_all['total_data_usage']/1024).round(2)
            df_all['tenant_id'] = df_all['tenant_id'].astype(int)
            df_all['service_provider_id'] = df_all['service_provider_id'].astype(int)
            if tenant_id != "All":
                df_all = df_all[df_all['tenant_id']==int(tenant_id)]
            if start_date and end_date:
                df_all = df_all[(df_all['usage_day']>=start_date) & (df_all['usage_day']<=end_date)]
            if service_provider and service_provider != "All":
                try:
                   
                    
                    df_all = df_all[df_all['service_provider_display_name'] == service_provider]
                    if df_all.empty:
                        response["message"] = "No data available for specified service provider"
                        response["flag"] = True
                        return response
                except Exception as e:
                    response["message"] = f"Service provider filtering error: {str(e)}"
                    return response

            # Filter by billing cycle end date if provided
            logging.info("billing_cycle_end_period:", billing_cycle_end_period)
            if billing_cycle_end_period and billing_cycle_end_period != "All":
                try:
                    # Convert timestamp string to date
                    billing_end_date = pd.to_datetime(billing_cycle_end_period).date()
                    df_all = df_all[df_all['usage_day'] == billing_end_date]
                    logging.info("df_all123:", df_all)
                    if df_all.empty:
                        response["message"] = f"No data available for billing cycle ending on {billing_end_date}"
                        response["flag"] = True
                        return response
                except Exception as e:
                    response["message"] = f"Billing cycle filtering error: {str(e)}"
                    return response
            min_date = df_all['usage_day'].min()
        else:
            min_date = None

        bucket_ranges, default_label = generate_bucket_ranges(df_all, 'usage_day', min_date)
       
        # Add custom_range bucket if start_date & end_date provided
        if start_date and end_date:
            bucket_ranges["custom_range"] = {
                "start": start_date,
                "end": end_date,
                "type": "custom"
            }

        # Decide which main bucket this custom range belongs to
        if start_date and end_date:
            main_bucket = get_matching_bucket(bucket_ranges, start_date, end_date)
            # Keep only main bucket + custom_range
            bucket_ranges = {k: v for k, v in bucket_ranges.items() if k in (main_bucket, "custom_range")}

        all_buckets = {label: [] for label in bucket_ranges.keys()}
        meta_tenants, meta_providers = {}, {}

        for label, cfg in bucket_ranges.items():
            # Filter df for this bucket
            df_filtered = df_all[(df_all['usage_day'] >= cfg['start']) & (df_all['usage_day'] <= cfg['end'])] if not df_all.empty else pd.DataFrame()

            # Process grouped data if any, else grouped is empty dict
            grouped = process_grouped(df_filtered, cfg['type']) if not df_filtered.empty else {}

            formatted = []
            if grouped:
                for (tid, pid), records in grouped.items():
                    formatted.append({
                        "tenant_id": tid,
                        "provider_id": pid,
                        "records": serialize_data(records)
                    })
                    meta_tenants[tid] = ""
                    meta_providers[pid] = df_filtered[df_filtered['service_provider_id']==pid]['service_provider_display_name'].iloc[0]

            # Assign formatted data (empty list if no data)
            all_buckets[label] = formatted

        if start_date and end_date:
            main_bucket = get_matching_bucket(bucket_ranges, start_date, end_date)
            for k in all_buckets.keys():
                if k != main_bucket:
                    all_buckets[k] = []



        # Populate tenant names from DB
        if meta_tenants:
            ids = list(meta_tenants.keys())
            q = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
            df = common_utils_database.execute_query(q, params=ids)
            if isinstance(df, pd.DataFrame):
                for row in df.to_dict(orient="records"):
                    meta_tenants[int(row["tenant_id"])] = str(row["tenant_name"])

        response = {
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "providers": meta_providers,
                "default_time_range": default_label
            },
            "data": {
                "title": "Usage by Carrier / Provider",
                "chart_type": "bar",
                "xField": "usage_gb",
                "yField": list(meta_providers.values()),
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            },
            "message": ""
        }
        return response

    except Exception as exception:
        logging.error(f"[get_usage_by_carrier_weekly_distribution] Unexpected error: {exception}")
        response["message"] = f"Error retrieving weekly usage distribution: {exception}"
        try:
            error_data = {
                "service_name": "get_usage_by_carrier_weekly_distribution",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_err:
            logging.warning(f"Failed to log error: {log_err}")
        return response
    
def get_plan_utilisation_summary(data):
    """
    Returns a bar chart showing total usage (in GB) for each customer_rate_plan across service providers.
    Uses process_grouped, generate_bucket_ranges, and assign_week_label for proper bucket formatting.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'billing_cycle_end_period' (str, optional): Filter by billing cycle end date.
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant, provider, and plan metadata, default time range.
            - 'data' (dict): Chart-ready data with usage by plan and provider.
            - 'message' (str): Error message if applicable.
            
    """

    response = {
        "flag": False,
        "meta": {"tenants": {}, "providers": {}, "plans": {}, "default_time_range": "custom_range"},
        "data": {
            "title": "Plan Usage by Service Provider",
            "chart_type": "bar",
            "xField": "usage_count",
            "yField": [],
            "data": {},
            "smooth": True,
            "height": 300,
            "width": 500,
        },
        "message": "",
    }

    try:
        tenant_id = data.get("tenant_id", "")
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        request_received_at = data.get("request_received_at", "")
        tenant_name = data.get("tenant_name", "")
        start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
        end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
        refresh = str(data.get("refresh", "False")).lower() == "true"
        service_provider = str(data.get("service_provider", ""))
        billing_cycle_end_period = str(data.get("billing_cycle_end_period", ""))

        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        function = "get_plan_utilisation_summary"
        cache_key = get_usage_insights_cache_key(tenant_database)

        use_customer = False
        if refresh:
            cache_data = update_usage_cache(
                database, cache_key, function, username, request_received_at, common_utils_database
            )
            result_df = cache_data["usage_summary_by_plan_by_provider_rate_plan"]
        else:
            result_df, cache_miss = get_usage_data_from_cache(cache_key, use_customer, return_usage_summary_by_plan=True)
            if cache_miss:
                cache_data = update_usage_cache(
                    database, cache_key, function, username, request_received_at, common_utils_database
                )
                result_df = cache_data["usage_summary_by_plan_by_provider_rate_plan"]

        df_all = pd.DataFrame(result_df) if not result_df.empty else pd.DataFrame()

        if not df_all.empty:
            df_all['usage_day'] = pd.to_datetime(df_all['usage_day']).dt.date
            df_all['customer_rate_plan_name'] = df_all['customer_rate_plan_name'].apply(lambda x: None if pd.isna(x) else str(x))
            df_all["usage_gb"] = df_all["total_data_usage"]
            df_all['tenant_id'] = df_all['tenant_id'].astype(int)
            df_all['service_provider_id'] = df_all['service_provider_id'].astype(int)

            if tenant_id != "All":
                df_all = df_all[df_all['tenant_id'] == int(tenant_id)]
            if start_date and end_date:
                df_all = df_all[(df_all['usage_day'] >= start_date) & (df_all['usage_day'] <= end_date)]
            if service_provider and service_provider != "All":
                try:
                   
                    
                    df_all = df_all[df_all['service_provider_display_name'] == service_provider]
                    if df_all.empty:
                        response["message"] = "No data available for specified service provider"
                        response["flag"] = True
                        return response
                except Exception as e:
                    response["message"] = f"Service provider filtering error: {str(e)}"
                    return response

            # Filter by billing cycle end date if provided
            logging.info("billing_cycle_end_period:", billing_cycle_end_period)
            if billing_cycle_end_period and billing_cycle_end_period != "All":
                try:
                    # Convert timestamp string to date
                    billing_end_date = pd.to_datetime(billing_cycle_end_period).date()
                    df_all = df_all[df_all['usage_day'] == billing_end_date]
                    logging.info("df_all123:", df_all)
                    if df_all.empty:
                        response["message"] = f"No data available for billing cycle ending on {billing_end_date}"
                        response["flag"] = True
                        return response
                except Exception as e:
                    response["message"] = f"Billing cycle filtering error: {str(e)}"
                    return response
            min_date = df_all['usage_day'].min()
        else:
            min_date = None

        # Generate bucket ranges
        bucket_ranges, default_label = generate_bucket_ranges(df_all, 'usage_day', min_date)
        all_buckets = {label: [] for label in bucket_ranges.keys()}
        meta_tenants, meta_providers, meta_plans = {}, {}, {}

        for label, cfg in bucket_ranges.items():
            if df_all.empty:
                continue
            df_filtered = df_all[(df_all['usage_day'] >= cfg['start']) & (df_all['usage_day'] <= cfg['end'])]
            if df_filtered.empty:
                continue

            grouped = process_grouped(df_filtered, cfg['type'])

            # Convert grouped format into final bucket structure
            for (tid, pid), records_list in grouped.items():
                for record in records_list:
                    for date_str, usage in record.items():
                        plan_name = None
                        row_plan = df_filtered[(df_filtered['tenant_id']==tid) & (df_filtered['service_provider_id']==pid)]
                        if not row_plan.empty:
                            plan_name = row_plan['customer_rate_plan_name'].iloc[0]

                        all_buckets[label].append({
                            "tenant_id": tid,
                            "provider_id": pid,
                            "plan": plan_name,
                            "records": serialize_data([[date_str, usage]])
                        })

                        # Update metadata
                        meta_tenants[tid] = ""
                        if pid not in meta_providers:
                            sp_name = row_plan['service_provider_display_name'].iloc[0] if not row_plan.empty else "Unknown"
                            meta_providers[pid] = sp_name
                        plan_key = plan_name if plan_name else "null"
                        if plan_key not in meta_plans:
                            meta_plans[plan_key] = plan_name

        # ---------------- NEW: Filter all_buckets to main bucket ----------------
        if start_date and end_date:
            main_bucket = get_matching_bucket(bucket_ranges, start_date, end_date)
            for k in all_buckets.keys():
                if k != main_bucket:
                    all_buckets[k] = []

        # Populate tenant names
        if meta_tenants:
            tenant_ids = list(meta_tenants.keys())
            query = f"SELECT id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(tenant_ids))})"
            df_tenants = common_utils_database.execute_query(query, params=tenant_ids)
            if isinstance(df_tenants, pd.DataFrame):
                for _, row in df_tenants.iterrows():
                    meta_tenants[int(row["id"])] = row["tenant_name"]

        # Prepare yField (unique plans)
        all_plans = df_all['customer_rate_plan_name'].unique().tolist() if not df_all.empty else []
        yField = [p if p else None for p in all_plans]

        # Build final response
        response = {
            "flag": True,
            "meta": {
                "tenants": {int(k): v for k, v in meta_tenants.items()},
                "providers": meta_providers,
                "plans": meta_plans,
                "default_time_range": default_label
            },
            "data": {
                "title": "Plan Usage by Service Provider",
                "chart_type": "bar",
                "xField": "usage_count",
                "yField": yField,
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            },
            "message": ""
        }

        return response

    except Exception as exception:
        logging.error(f"[get_plan_utilisation_summary] Unexpected error: {exception}")
        response["message"] = f"Error retrieving plan usage by service provider: {exception}"
        try:
            error_data = {
                "service_name": "get_plan_utilisation_summary",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_err:
            logging.warning(f"Failed to log error: {log_err}")

        return response

##################### Usage Insights code  ############################ 

######################### Revenue metrics  ############################

def get_revenue_metrics_cards(data):
    """
    Retrieves total revenue metrics: Total Charges, Total Payments, Total Billed Amount, Pending Payments.
    Returns formatted values with '$' prefix. Uses Redis caching.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'billing_cycle_end_date' (str, optional): Filter by billing cycle end date.
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'data' (dict): Revenue metrics data for dashboard cards.
            - 'message' (str): Error message if applicable.

    """

    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    tenant_database = data.get("db_name", "")
    tenant_id = data.get("tenant_id", "All")

    start_date = datetime.strptime(data['start_date'], "%Y-%m-%d").date() if data.get("start_date") else None
    end_date = datetime.strptime(data['end_date'], "%Y-%m-%d").date() if data.get("end_date") else None
    refresh = str(data.get("refresh", "False")).lower() == "true"
    service_provider = data.get("service_provider", "")
    billing_cycle_end_date = data.get("billing_cycle_end_date", "")

    response = {
        "flag": False,
        "data": {
            "title": "Revenue Metrics",
            "height": 300,
            "width": 500,
        },
        "message": "",
    }

    # Initialize DB connections (these assume a DB wrapper named `DB` exists)
    killbill_database = DB("billing_platform", **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        function = "get_revenue_metrics_cards"
        cache_key = get_cache_key(tenant_database, function)
        cached_data = None

        # Try to read from cache unless refresh requested
        if not refresh:
            try:
                cached_response = redis_client.get(cache_key)
                if cached_response:
                    cached_data = json.loads(cached_response)
                    logging.info(f"Cache hit: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Cache retrieval failed: {cache_exc}")

        # If refresh or cache miss -> fetch from DB and (re)populate cache
        if refresh or cached_data is None:
            logging.info("Fetching fresh data from billing DB")

            # Return numeric sums from DB; do formatting in Python.
            query = """
                SELECT
                    COALESCE(SUM(cb.charges), 0)          AS total_charges,
                    COALESCE(SUM(cb.payments), 0)         AS total_payments,
                    COALESCE(SUM(cb.total), 0)            AS total_billed_amount,
                    COALESCE(SUM(cb.remaining), 0)        AS overdue_payments,
                    cb.tenant_id,
                    MAX(cb.created_date)                  AS modified_date,
                    cs.service_provider_name              AS service_provider_name
                FROM public.customer_bills cb
                LEFT JOIN public.customer_services cs
                    ON cb.customer_profile_id = cs.customer_profile_id
                WHERE cb.is_active = TRUE
                GROUP BY cb.tenant_id, cs.service_provider_name
            """

            # Execute query (the DB wrapper is expected to return a pandas.DataFrame)
            result_df = killbill_database.execute_query(query, True)

            if isinstance(result_df, pd.DataFrame) and not result_df.empty:
                # Convert Timestamp -> ISO string for stable caching
                if "modified_date" in result_df.columns:
                    result_df["modified_date"] = result_df["modified_date"].astype(str)

                # Ensure service_provider_name exists to avoid downstream KeyErrors
                if "service_provider_name" not in result_df.columns:
                    result_df["service_provider_name"] = None

                cache_response = result_df.to_dict(orient="records")
                try:
                    # Cache for 2 hours (7200 seconds)
                    redis_client.setex(cache_key, 7200, json.dumps(cache_response, default=str))
                    logging.info(f"Cached fresh data under key: {cache_key}")
                except Exception as redis_exc:
                    logging.warning(f"Redis set failed: {redis_exc}")

                # Audit cache refresh
                new_sync_time = datetime.now()
                try:
                    audit_data = {
                        "function_name": function,
                        "created_date": request_received_at,
                        "created_by": username,
                        "last_synced_by": username,
                        "last_sync_date": new_sync_time,
                    }
                    common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")

                cached_data = cache_response
            else:
                # If query returns empty, set to empty list so cache processing continues gracefully
                cached_data = []

        # Build DataFrame from cached data for filtering/aggregation
        df_all = pd.DataFrame(cached_data)

        if not df_all.empty:
            # Normalize types
            if "modified_date" in df_all.columns:
                df_all['modified_date'] = pd.to_datetime(df_all['modified_date']).dt.date
            else:
                # If modified_date missing, create NaT-like column for safe comparisons
                df_all['modified_date'] = pd.NaT

            if 'tenant_id' in df_all.columns:
                # Some cached sources may have tenant_id as strings; coerce
                try:
                    df_all['tenant_id'] = df_all['tenant_id'].astype(int)
                except Exception:
                    df_all['tenant_id'] = pd.to_numeric(df_all['tenant_id'], errors='coerce').fillna(0).astype(int)

            # Filter by tenant
            if tenant_id != "All":
                try:
                    df_all = df_all[df_all["tenant_id"] == int(tenant_id)]
                except Exception as e:
                    logging.warning(f"Tenant filter conversion error: {e}")

            # Filter by service_provider (note column name: service_provider_name)
            if service_provider and service_provider != "":
                if "service_provider_name" in df_all.columns:
                    df_all = df_all[df_all["service_provider_name"] == service_provider]

            # Filter by billing_cycle_end_date if column exists
            # Filter by billing_cycle_end_date: when form provides a datetime (e.g. '2025-09-20 14:00:00'),
            # apply a 30-day window ending at that datetime: [billing_dt - 30 days, billing_dt]
            if billing_cycle_end_date and billing_cycle_end_date != "":
                try:
                    billing_dt = pd.to_datetime(billing_cycle_end_date)
                    start_dt = billing_dt - pd.Timedelta(days=30)
                    # Ensure modified_date is datetime and filter by the full datetime range
                    if "modified_date" in df_all.columns:
                        df_all = df_all[
                        (pd.to_datetime(df_all["modified_date"]) >= start_dt) &
                        (pd.to_datetime(df_all["modified_date"]) <= billing_dt)
                        ]
                    else:
                        logging.warning("billing_cycle_end_date provided but modified_date column missing; skipping billing window filter")
                except Exception as e:
                    logging.warning(f"Billing cycle end date filter error: {e}")

            # Filter by date range on modified_date
            if start_date and end_date:
                try:
                    df_all = df_all[
                        (df_all["modified_date"] >= start_date) &
                        (df_all["modified_date"] <= end_date)
                    ]
                except Exception as e:
                    logging.warning(f"Date range filter error: {e}")

        # If after filtering we have no data, return gracefully
        if df_all.empty:
            response["flag"] = True
            response["data"] = []
            response["message"] = "No data found for the specified criteria"
            return response

        # Ensure numeric dtype for aggregation; these columns were returned numeric from DB
        for col in ["total_charges", "total_payments", "total_billed_amount", "overdue_payments"]:
            if col in df_all.columns:
                df_all[col] = pd.to_numeric(df_all[col], errors="coerce").fillna(0.0)
            else:
                df_all[col] = 0.0

        # Aggregate across all matching rows (summing values)
        agg_row = {
            "total_charges": df_all["total_charges"].sum(),
            "total_payments": df_all["total_payments"].sum(),
            "total_billed_amount": df_all["total_billed_amount"].sum(),
            "overdue_payments": df_all["overdue_payments"].sum(),
            "tenant_id": int(tenant_id) if tenant_id != "All" else None,
        }

        # Tenant name mapping (only fetch if tenant filter is applied)
        tenant_mapping = {}
        if tenant_id != "All":
            tenant_query = "SELECT id, tenant_name FROM tenant WHERE id = %s"
            try:
                tenant_df = common_utils_database.execute_query(tenant_query, params=[tenant_id], dict_result=True)
                if isinstance(tenant_df, pd.DataFrame) and not tenant_df.empty:
                    tenant_mapping = {row["id"]: row["tenant_name"] for row in tenant_df.to_dict(orient="records")}
            except Exception as e:
                logging.warning(f"Tenant name lookup failed: {e}")

        # Prepare chart/card payload with formatted currency strings
        chart_data = {
            "total_charges": f"${agg_row['total_charges']:,.2f}",
            "total_payments": f"${agg_row['total_payments']:,.2f}",
            "total_billed_amount": f"${agg_row['total_billed_amount']:,.2f}",
            "overdue_payments": f"${agg_row['overdue_payments']:,.2f}",
            # raw numeric values for consumers that need numbers
            "raw_total_charges": agg_row['total_charges'],
            "raw_total_payments": agg_row['total_payments'],
            "raw_total_billed_amount": agg_row['total_billed_amount'],
            "raw_overdue_payments": agg_row['overdue_payments'],
            "tenant_id": agg_row["tenant_id"],
            "tenant_name": tenant_mapping.get(agg_row['tenant_id'], f"Tenant_{agg_row['tenant_id']}") if agg_row["tenant_id"] else "All Tenants",
        }


        response["flag"] = True
        response["data"] = serialize_data(chart_data)


    except Exception as exception:
        response["flag"] = False
        response["message"] = f"Error retrieving revenue metrics: {exception}"
        try:
            error_data = {
                "service_name": "get_revenue_metrics_cards",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.warning(f"Failed to log error: {log_exc}")

    return response


def get_revenue_by_carrier(data):
    """
    Returns a breakdown of revenue by carrier (service provider), including a sparkline (trend) for each.
    Bucketing logic mirrors get_sim_count_by_service_provider (week cutoffs, yearly cutoffs, 2-year cutoffs, 4-hour intervals).
    Bucketing happens BEFORE caching; cache hits only apply filters over the cached buckets.
    No cumulative grouping is used here.

    **Change (2025-08-22):**
    For multi-segment time ranges (5_day, 1_month, 3_month, 6_month, 1_year, 5_years, max, custom_range)
    the code now aggregates across the whole label period (combined start..end) instead of requiring
    each sub-segment to be populated. This ensures that if *any* record exists within the larger
    period (for example: only today's record), the larger buckets will include that provider/record.
    The 1_day bucket still preserves its 4-hour granularity.

    **Fix (2025-09-04):**
    - Removed billing_cycle_end_date from queries as it doesn't exist in the database
    - Modified billing_cycle_end_date filter to use modified_date with 30-day window
    - Fixed column references to match actual database schema

    **Fix (2025-09-08):**
    - Ensure "today's" partial segment ends at the actual current timestamp (hours preserved),
      so same-day rows (e.g. 2025-09-08T11:10:20Z) are included in non-1_day buckets.
    - Use `max` modified_date per group when choosing representative label so bucket labels reflect
      the latest record within the bucket.
    - Modified _segments_5_day to set seg_end to end of day (23:59:59.999999Z) for days prior to today,
      ensuring records with timestamps throughout the day (e.g., 2025-09-04T12:00:00Z) are included.

    **Fix applied here:**
    - Removed JSON serialization of `records` field in _aggregate_non_cumulative to prevent escaped backslashes
      in the output, storing the records list directly.

    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'billing_cycle_end_date' (str, optional): Filter by billing cycle end date (uses modified_date with 30-day window).
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): Chart-ready data with revenue by carrier and trend sparklines.
            - 'message' (str): Error message if applicable.
    """


    # -------- request fields --------
    tenant_id = data.get("tenant_id", "All")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    request_received_at = dtparse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.utcnow().date()
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
    refresh = str(data.get("refresh", "False")).lower() == "true"
    service_provider = data.get('service_provider', '')
    billing_cycle_end_date = data.get("billing_cycle_end_date", "")

    response = {
        "flag": False,
        "meta": {
            "tenants": {},
            "providers": {},
            "default_time_range": "1_month",
        },
        "data": {
            "title": "Revenue By Carrier",
            "columns": ["Carrier", "Revenue", "Statistic"],
            "rows": [],
            "height": 300,
            "width": 500,
        },
        "message": "",
    }

    # ---------- helpers ----------
    def _now_ts():
        """Returns the current timestamp (UTC-aware)."""
        return pd.Timestamp.now(tz="UTC")

    def _normalize_date(ts):
        """Normalizes a timestamp to midnight (start of day)."""
        try:
            t = pd.to_datetime(ts, utc=True)
            return t.normalize()
        except Exception:
            return pd.to_datetime(ts, utc=True).normalize()

    def _eom(ts):
        """Returns the end-of-month timestamp for the given date."""
        t = pd.to_datetime(ts, utc=True)
        return t + pd.offsets.MonthEnd(0)

    def _fmt_date(ts):
        """Formats a timestamp as 'YYYY-MM-DD'."""
        t = pd.to_datetime(ts, utc=True)
        return t.date().isoformat()

    def _fmt_dt(ts):
        """Formats a timestamp as ISO 8601 UTC string 'YYYY-MM-DDTHH:MM:SSZ'."""
        try:
            t = pd.to_datetime(ts, utc=True)
            return t.strftime('%Y-%m-%dT%H:%M:%SZ')
        except Exception:
            t = pd.to_datetime(ts, utc=True)
            return t.strftime('%Y-%m-%dT%H:%M:%SZ')

    def _month_week_segments_for_month(first_of_month, end_cap, include_today_partial):
        """
        Builds week segments for a given month.
        Ensures partial first/last buckets are included.
        """
        today_norm = _normalize_date(_now_ts())
        d7 = first_of_month + pd.Timedelta(days=6)
        d14 = first_of_month + pd.Timedelta(days=13)
        d21 = first_of_month + pd.Timedelta(days=20)
        dend = _eom(first_of_month)
        cutoffs = []

        for p in (d7, d14, d21, dend):
            if _normalize_date(p) <= _normalize_date(end_cap):
                cutoffs.append(_normalize_date(p))

        if include_today_partial and first_of_month.year == end_cap.year and first_of_month.month == end_cap.month:
            t = today_norm
            if t <= dend and t not in cutoffs:
                cutoffs.append(t)

        cutoffs = sorted(pd.to_datetime(list(dict.fromkeys(cutoffs))))

        segs = []
        seg_start = _normalize_date(first_of_month)
        now_ts = _now_ts()

        for c in cutoffs:
            if include_today_partial and c == _normalize_date(now_ts) and first_of_month.year == end_cap.year and first_of_month.month == end_cap.month:
                seg_end = now_ts
                label_ts = now_ts
            else:
                seg_end = _normalize_date(c)
                label_ts = _normalize_date(c)

            if seg_start <= seg_end:
                segs.append((seg_start, seg_end, label_ts))
            seg_start = seg_end + pd.Timedelta(days=1)

        return segs

    def _month_week_segments_range(start_month_ts, end_ts, include_today_partial=True):
        """Generates weekly segments across a range of months."""
        segments = []
        cursor = pd.Timestamp(year=start_month_ts.year, month=start_month_ts.month, day=1, tz="UTC")
        end_month_first = pd.Timestamp(year=end_ts.year, month=end_ts.month, day=1, tz="UTC")
        while cursor <= end_month_first:
            include_today = include_today_partial and (cursor.year == end_ts.year and cursor.month == end_ts.month)
            segments.extend(_month_week_segments_for_month(cursor, end_ts, include_today))
            cursor = (_eom(cursor)) + pd.Timedelta(days=1)
        return segments

    def _year_segments_last_n_years(n_years, end_ts):
        """Generates yearly segments for the last n years including the current year."""
        segs = []
        start_year = end_ts.year - n_years + 1
        for y in range(start_year, end_ts.year):
            segs.append((pd.Timestamp(year=y, month=1, day=1, tz="UTC"),
                         pd.Timestamp(year=y, month=12, day=31, tz="UTC"),
                         pd.Timestamp(year=y, month=12, day=31, tz="UTC")))
        cy_start = pd.Timestamp(year=end_ts.year, month=1, day=1, tz="UTC")
        cy_end = _normalize_date(end_ts)
        segs.append((cy_start, cy_end, cy_end))
        return segs

    def _segments_1_day(now_ts):
        """Splits a single day into 4-hour segments."""
        start = _normalize_date(now_ts)
        anchors = list(pd.date_range(start=start, end=now_ts, freq="4h", tz="UTC"))
        if len(anchors) == 0 or anchors[-1] < now_ts:
            anchors.append(now_ts)
        segs = []
        seg_start = anchors[0] if anchors else start
        for idx in range(1, len(anchors)):
            seg_end = anchors[idx]
            if seg_start <= seg_end:
                segs.append((seg_start, seg_end, seg_end))
            seg_start = seg_end
        return segs

    def _segments_5_day(now_ts):
        """Splits the last 5 days into daily segments, with the last segment ending at now_ts."""
        today = _normalize_date(now_ts)
        start_day = today - pd.Timedelta(days=4)
        days = list(pd.date_range(start=start_day, end=today, freq="D", tz="UTC"))
        segments = []
        for i, d in enumerate(days):
            if i == len(days) - 1:  # Last day (today)
                segments.append((d, now_ts, now_ts))  # Extend to current timestamp
            else:
                # End at 23:59:59.999999Z to include all records for the day
                seg_end = d + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                segments.append((d, seg_end, seg_end))
        print("5_day segments:", segments)  # Debug print
        return segments

    def _aggregate_non_cumulative(df, segments, time_with_hours, year_only=False):
        """
        Aggregates `df` for the provided `segments` list.
        Uses each group's representative modified_date (max) as the t_str so record labels
        reflect the latest data date/time rather than the bucket's start/min.
        Stores records list directly to avoid escaped backslashes in JSON output.
        """
        if df.empty:
            print("trend_df is empty in _aggregate_non_cumulative")  # Debug print
            return []
        records_by_key = defaultdict(list)

        for seg_start, seg_end, label_ts in segments:
            print(f"Processing segment: {seg_start} to {seg_end}, label: {label_ts}")  # Debug print
            mask = (df["modified_date"] >= seg_start) & (df["modified_date"] <= seg_end)
            sub = df.loc[mask]
            print(f"Records in segment: {len(sub)}")  # Debug print
            if sub.empty:
                continue

            grouped = (
                sub.groupby(["tenant_id", "service_provider_id", "service_provider_name"], as_index=False)
                .agg({"revenue": "sum", "modified_date": "max"})
                .rename(columns={"modified_date": "rep_modified_date"})
            )

            for _, r in grouped.iterrows():
                if year_only:
                    t_str = str(label_ts.year)
                else:
                    if time_with_hours:
                        t_str = _fmt_dt(label_ts)
                    else:
                        rep_dt = r.get("rep_modified_date")
                        try:
                            t_str = _fmt_date(rep_dt)
                        except Exception:
                            t_str = _fmt_date(label_ts)

                tid = int(r["tenant_id"])
                pid = int(r["service_provider_id"])
                pname = r["service_provider_name"] if pd.notnull(r["service_provider_name"]) and r["service_provider_name"] != "" else "Unknown provider"
                val = float(r["revenue"]) if pd.notnull(r["revenue"]) and np.isfinite(r["revenue"]) else 0.0
                records_by_key[(tid, pid, pname)].append([t_str, val])

        rows = []
        for (tid, pid, pname), recs in records_by_key.items():
            stat = [rv for _, rv in recs]
            rows.append({
                "tenant_id": tid,
                "provider_id": pid,
                "service_provider_name": pname,
                "Revenue": "$0.00",
                "Statistic": stat,
                "records": recs,  # Store list directly, no JSON serialization
            })
        return rows

    def _parse_record_date(s):
        """Safely parses a string into a date object, handling both ISO datetime and YYYY-MM-DD formats."""
        if s is None:
            return None
        try:
            if isinstance(s, (pd.Timestamp, datetime)):
                return pd.to_datetime(s, utc=True).date()
            dt = pd.to_datetime(s, utc=True)
            return dt.date()
        except Exception:
            try:
                dt = pd.to_datetime(s, utc=True, errors='coerce')
                if pd.isnull(dt):
                    return None
                return dt.date()
            except Exception:
                return None

    try:
        killbill_database = DB('billing_platform', **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as exception:
        response["message"] = f"Database connection error: {exception}"
        logging.exception("DB connection error in get_revenue_by_carrier")
        return response

    try:
        function = "get_revenue_by_carrier"
        cache_key = get_cache_key(tenant_database, function)
        cached_blob = None

        if not refresh:
            try:
                cached_response = redis_client.get(cache_key)
                if cached_response:
                    cached_blob = json.loads(cached_response)
                    logging.info(f"Cache hit: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Cache retrieval failed: {cache_exc}")

        if refresh or cached_blob is None:
            logging.info("Fetching fresh data for get_revenue_by_carrier")

            summary_query = """
                SELECT tenant_id, service_provider_name, service_provider_id, SUM(revenue) AS revenue
                FROM public.revenue_metrics_billing_dashboard
                GROUP BY tenant_id, service_provider_name, service_provider_id
            """
            trend_query = """
                SELECT service_provider_name, service_provider_id, tenant_id,
                       modified_date, SUM(revenue) AS revenue
                FROM public.revenue_metrics_billing_dashboard
                GROUP BY service_provider_name, service_provider_id, tenant_id, modified_date
            """

            summary_df = killbill_database.execute_query(summary_query, flag=True)
            trend_df = killbill_database.execute_query(trend_query, flag=True)

            if isinstance(summary_df, pd.DataFrame) and not summary_df.empty:
                summary_df["tenant_id"] = pd.to_numeric(summary_df["tenant_id"], errors="coerce").fillna(-1).astype(int)
                summary_df["service_provider_id"] = pd.to_numeric(summary_df["service_provider_id"], errors="coerce").fillna(-1).astype(int)
                summary_df["revenue"] = pd.to_numeric(summary_df["revenue"], errors="coerce").fillna(0.0)
            else:
                summary_df = pd.DataFrame(columns=["tenant_id", "service_provider_name", "service_provider_id", "revenue"])

            if isinstance(trend_df, pd.DataFrame) and not trend_df.empty:
                print("trend_df dates:", trend_df["modified_date"].unique())  # Debug print
                trend_df["tenant_id"] = pd.to_numeric(trend_df["tenant_id"], errors="coerce").fillna(-1).astype(int)
                trend_df["service_provider_id"] = pd.to_numeric(trend_df["service_provider_id"], errors="coerce").fillna(-1).astype(int)
                trend_df["modified_date"] = pd.to_datetime(trend_df["modified_date"], utc=True)
                trend_df["revenue"] = pd.to_numeric(trend_df["revenue"], errors="coerce").fillna(0.0)
            else:
                trend_df = pd.DataFrame(columns=["service_provider_name", "service_provider_id", "tenant_id", "modified_date", "revenue"])

            total_map = {}
            if not summary_df.empty:
                for _, r in summary_df.iterrows():
                    total_map[(int(r["tenant_id"]), int(r["service_provider_id"]))] = float(r["revenue"])

            now = _now_ts()
            month_start = now.replace(day=1)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1)
            year_start = pd.Timestamp(year=now.year, month=1, day=1, tz="UTC")
            five_years_start = (now - pd.DateOffset(years=5)).replace(day=1)
            min_ts = trend_df["modified_date"].min() if not trend_df.empty else now
            min_year = int(min_ts.year) if pd.notnull(min_ts) else int(now.year)

            segments_by_label = {
                "1_day": _segments_1_day(now),
                "5_day": _segments_5_day(now),
                "1_month": _month_week_segments_range(month_start, now, True),
                "3_month": _month_week_segments_range(three_months_start, now, True),
                "6_month": _month_week_segments_range(six_months_start, now, True),
                "1_year": _month_week_segments_range(year_start, now, True),
                "5_years": _year_segments_last_n_years(5, now),
                "max": _year_segments_last_n_years(now.year - min_year + 1, now),
                "custom_range": [],
            }

            tenant_map, provider_map, grouped_data = {}, {}, {}
            for label, segs in segments_by_label.items():
                if not segs:
                    grouped_data[label] = []
                    continue

                rows = _aggregate_non_cumulative(
                    trend_df,
                    segs,
                    (label == "1_day"),
                    year_only=(label == "max")
                )

                for row in rows:
                    tid = row["tenant_id"]
                    pid = row["provider_id"]
                    row["Revenue"] = f"${round(float(total_map.get((tid, pid), 0.0)), 2):.2f}"
                    tenant_map[tid] = ""

                if not trend_df.empty:
                    for _, r in trend_df[["service_provider_id", "service_provider_name"]].drop_duplicates().iterrows():
                        pid = int(r["service_provider_id"])
                        pname = r["service_provider_name"] if pd.notnull(r["service_provider_name"]) and r["service_provider_name"] != "" else "Unknown provider"
                        provider_map[pid] = pname
                elif not summary_df.empty:
                    for _, r in summary_df[["service_provider_id", "service_provider_name"]].drop_duplicates().iterrows():
                        pid = int(r["service_provider_id"])
                        pname = r["service_provider_name"] if pd.notnull(r["service_provider_name"]) and r["service_provider_name"] != "" else "Unknown provider"
                        provider_map[pid] = pname

                grouped_data[label] = rows

            if tenant_map:
                ids = list(tenant_map.keys())
                try:
                    q = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s'] * len(ids))})"
                    df_tn = common_utils_database.execute_query(q, params=ids)
                    if isinstance(df_tn, pd.DataFrame) and not df_tn.empty:
                        for row in df_tn.to_dict(orient="records"):
                            tenant_map[int(row["tenant_id"])] = row["tenant_name"]
                except Exception as tenant_exc:
                    logging.warning(f"Failed to resolve tenant names: {tenant_exc}")

            cache_payload = {"data": grouped_data, "meta": {"tenants": tenant_map, "providers": provider_map, "default_time_range": "1_month"}}
            try:
                redis_client.setex(cache_key, 7200, json.dumps(cache_payload, default=str))
            except Exception as redis_exc:
                logging.warning(f"Redis set failed: {redis_exc}")

            try:
                audit_data = {"function_name": function, "created_date": request_received_at, "created_by": username, "last_synced_by": username}
                common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
            except Exception as audit_exc:
                logging.warning(f"Audit logging failed: {audit_exc}")

            cached_blob = cache_payload

        grouped_data = cached_blob.get("data", {})
        meta_info = cached_blob.get("meta", {"tenants": {}, "providers": {}, "default_time_range": "1_month"})

        if tenant_id and tenant_id != "All":
            try:
                tid_int = int(tenant_id)
            except Exception:
                tid_int = None
            if tid_int is not None:
                for label in list(grouped_data.keys()):
                    grouped_data[label] = [row for row in grouped_data[label] if int(row.get("tenant_id", -1)) == tid_int]

        if service_provider and service_provider != "":
            try:
                provider_ids = [
                    pid for pid, pname in meta_info.get("providers", {}).items()
                    if pname == service_provider
                ]
            except Exception:
                provider_ids = []

            if provider_ids:
                for label in list(grouped_data.keys()):
                    grouped_data[label] = [
                        row for row in grouped_data[label]
                        if int(row.get("provider_id", -1)) in provider_ids
                    ]

        if billing_cycle_end_date and billing_cycle_end_date != "":
            try:
                end_dt = pd.to_datetime(billing_cycle_end_date, utc=True).date()
                start_dt = (pd.to_datetime(billing_cycle_end_date, utc=True) - pd.Timedelta(days=30)).date()

                for label in list(grouped_data.keys()):
                    filtered_rows = []
                    for row in grouped_data[label]:
                        recs = row.get("records", [])
                        parsed_recs = recs if isinstance(recs, list) else []
                        trimmed = []
                        for item in parsed_recs:
                            if not isinstance(item, (list, tuple)) or len(item) == 0:
                                continue
                            t_str = item[0]
                            d = _parse_record_date(t_str)
                            if d is None:
                                continue
                            if start_dt <= d <= end_dt:
                                if len(item) >= 2:
                                    trimmed.append([t_str, item[1]])
                                else:
                                    trimmed.append([t_str, 0.0])

                        if trimmed:
                            row["records"] = trimmed
                            row["Statistic"] = [v for _, v in trimmed]
                            filtered_rows.append(row)

                    grouped_data[label] = filtered_rows

            except Exception as e:
                logging.warning(f"Failed to apply billing_cycle_end_date filter: {e}")

        if start_date or end_date:
            for label in list(grouped_data.keys()):
                filtered_rows = []
                for row in grouped_data[label]:
                    recs = row.get("records", [])
                    parsed_recs = recs if isinstance(recs, list) else []
                    trimmed = []
                    for item in parsed_recs:
                        if not isinstance(item, (list, tuple)) or len(item) == 0:
                            continue
                        t_str = item[0]
                        d = _parse_record_date(t_str)
                        if d is None:
                            continue
                        if start_date and d < start_date:
                            continue
                        if end_date and d > end_date:
                            continue
                        if len(item) >= 2:
                            trimmed.append([t_str, item[1]])
                        else:
                            trimmed.append([t_str, 0.0])

                    if trimmed:
                        row["records"] = trimmed
                        row["Statistic"] = [v for _, v in trimmed]
                        filtered_rows.append(row)
                grouped_data[label] = filtered_rows

        response["flag"] = True
        response["data"]["data"] = grouped_data
        response["meta"] = meta_info
        response["message"] = ""

    except Exception as exception:
        response["flag"] = False
        response["message"] = f"Error retrieving revenue by carrier: {exception}"
        logging.exception("Error in get_revenue_by_carrier")

        try:
            error_data = {
                "service_name": "get_revenue_by_carrier",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                try:
                    common_utils_database.log_error_to_db(error_data, "error_log_table")
                except Exception as log_exc:
                    logging.warning(f"Error logging to DB: {log_exc}")
        except Exception as log_exc:
            logging.warning(f"Error logging failure: {log_exc}")

    return response

def get_revenue_by_rate_plan(data):
    """
    Returns a breakdown of revenue by rateplan based on service provider.
    Implements Redis cache: filters are applied only after cache retrieval.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): Chart-ready data with revenue by rate plan.
            - 'message' (str): Error message if applicable.
    """

    tenant_id = data.get("tenant_id", "")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = parse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.utcnow().date()
    tenant_name = data.get("tenant_name", "")
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
    refresh = str(data.get("refresh", "False")).lower() == "true"
    service_provider = data.get("service_provider", "")
    billing_cycle_end_date = data.get("billing_cycle_end_period", "")

    response = {
        "flag": False,
        "meta": {"tenants": {}, "providers": {}, "default_time_range": "custom_range"},
        "data": {
            "title": "Revenue By Rate Plan",
            "chart_type": "",
            "xField": "revenue",
            "yField": [],
            "data": {},
            "smooth": True,
            "height": 300,
            "width": 500,
        },
        "message": "",
    }

    try:
        killbill_database = DB("billing_platform", **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        # Redis cache logic
        function = "get_revenue_by_rate_plan"
        cache_key = get_cache_key(tenant_database, function)
        cached_data = None

        if not refresh:
            try:
                cached_response = redis_client.get(cache_key)
                if cached_response:
                    cached_data = json.loads(cached_response)
                    logging.info(f"Cache hit for key: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Cache retrieval failed: {cache_exc}")

        # ---------- helpers (always available) ----------
        def eom(ts: pd.Timestamp) -> pd.Timestamp:
            """Returns the end-of-month timestamp for the given date."""
            return (ts + pd.offsets.MonthEnd(0))

        def month_week_cutoffs_for_month(first_of_month: pd.Timestamp, end_cap: pd.Timestamp, include_today_partial: bool):
            """Generates weekly cutoff dates within a month, optionally including today if partial month."""
            pts = []
            # Weekly cutoffs: 7th, 14th, 21st, and end of month
            d7 = first_of_month + pd.Timedelta(days=6)
            d14 = first_of_month + pd.Timedelta(days=13)
            d21 = first_of_month + pd.Timedelta(days=20)
            dend = eom(first_of_month)
            
            for p in (d7, d14, d21, dend):
                if p.normalize() <= end_cap.normalize():
                    pts.append(p)
            
            # Add current date if it's a partial month and not already included
            if include_today_partial and (first_of_month.year == end_cap.year and first_of_month.month == end_cap.month):
                today_pt = end_cap.normalize()
                if today_pt not in pts and today_pt > dend.normalize():
                    pts.append(today_pt)
            
            return sorted(pd.to_datetime(list(dict.fromkeys(pts))))

        def month_week_cutoffs_range(start_month_ts: pd.Timestamp, end_ts: pd.Timestamp, include_today_partial=True):
            """Generates all weekly cutoff dates across multiple months from start to end timestamp."""
            points = []
            cursor = pd.Timestamp(year=start_month_ts.year, month=start_month_ts.month, day=1, tz="UTC")
            end_month_first = pd.Timestamp(year=end_ts.year, month=end_ts.month, day=1, tz="UTC")
            
            while cursor <= end_month_first:
                include_today = include_today_partial and (cursor.year == end_ts.year and cursor.month == end_ts.month)
                month_pts = month_week_cutoffs_for_month(cursor, end_ts, include_today)
                points.extend(month_pts)
                cursor = (cursor + pd.offsets.MonthEnd(0)) + pd.Timedelta(days=1)
            return sorted(pd.to_datetime(list(dict.fromkeys(points))))

        def yearly_points_last_n_years(n_years: int, end_ts: pd.Timestamp):
            """Returns yearly cutoff points for the last n years, using Dec 31 or today for the current year."""
            start_year = end_ts.year - n_years + 1
            pts = [pd.Timestamp(year=y, month=12, day=31, tz="UTC") for y in range(start_year, end_ts.year +1)]
            if pts[-1] > end_ts:
                pts[-1] = end_ts
            return sorted(pd.to_datetime(list(dict.fromkeys(pts))))

        def to_datestr(ts: pd.Timestamp, date_only=True, year_only=False) -> str:
            """Formats a timestamp into a date string, full ISO string with Z, or year-only string."""
            if year_only:
                return str(ts.year)
            if date_only:
                return ts.date().isoformat()
            if getattr(ts, "tzinfo", None) is None:
                ts = ts.tz_localize("UTC")
            else:
                ts = ts.tz_convert("UTC")
            return ts.strftime('%Y-%m-%dT%H:%M:%SZ')

        def get_non_cumulative_grouping(filtered, points, date_only=False, year_only=False):
            if filtered.empty:
                return [ {
                    "tenant_id": -1,
                    "provider_id": -1,
                    "service_provider": "Unknown provider",
                    "customer_rate_plan_name": "",
                    "revenue": 0.0,
                    "time": to_datestr(points[0] if points else pd.Timestamp.now(tz="UTC"), date_only=date_only, year_only=year_only) if points else ""
                } ] if points else []
            df_sorted = filtered.sort_values('modified_date')
            pts = list(pd.to_datetime(points))
            records = []
            for i, t in enumerate(pts):
                if getattr(t, "tzinfo", None) is None:
                    t = t.tz_localize("UTC")
                if not date_only and not year_only:
                    start_period = pts[i - 1] + pd.Timedelta(seconds=1) if i > 0 else filtered['modified_date'].min()
                    t_str = to_datestr(start_period, date_only=False)
                else:
                    t_str = to_datestr(t, date_only=date_only, year_only=year_only)
                prev_t = pts[i - 1] if i > 0 else df_sorted['modified_date'].min() - pd.Timedelta(seconds=1)
                if getattr(prev_t, "tzinfo", None) is None:
                    prev_t = prev_t.tz_localize("UTC")
                subset = df_sorted[(df_sorted['modified_date'] > prev_t) & (df_sorted['modified_date'] <= t)]
                if subset.empty:
                    continue
                grouped = subset.groupby(['tenant_id', 'service_provider_id', 'service_provider_name', 'customer_rate_plan_name'], as_index=False)['revenue'].sum()
                for _, row in grouped.iterrows():
                    records.append({
                        "tenant_id": row['tenant_id'],
                        "provider_id": row['service_provider_id'],
                        "service_provider": row['service_provider_name'],
                        "customer_rate_plan_name": row['customer_rate_plan_name'],
                        "revenue": float(row['revenue']),
                        "time": t_str
                    })
            return records

        # If refresh or no cache — compute and set cache
        if refresh or cached_data is None:
            logging.info("Fetching fresh revenue data from DB")

            query = """SELECT service_provider_id,tenant_id,
                        service_provider_name,
                        customer_rate_plan_name,
                        revenue as charges,
                        modified_date
                FROM public.revenue_metrics_billing_dashboard_by_plan
                WHERE modified_date IS NOT null
            """
            df = killbill_database.execute_query(query, flag=True)

            if isinstance(df, pd.DataFrame) and not df.empty:
                df["tenant_id"] = pd.to_numeric(df["tenant_id"], errors="coerce").fillna(-1).astype(int)
                df["service_provider_id"] = pd.to_numeric(df["service_provider_id"], errors="coerce").fillna(-1).astype(int)
                df['modified_date'] = pd.to_datetime(df['modified_date'], utc=True)
                df["revenue"] = pd.to_numeric(df.get("charges", 0), errors="coerce").fillna(0).astype(float)
                df["service_provider_name"] = df["service_provider_name"].fillna("Unknown provider")
                df["customer_rate_plan_name"] = df["customer_rate_plan_name"].fillna("Unknown plan")
            else:
                df = pd.DataFrame(columns=["service_provider_id", "tenant_id", "service_provider_name", "customer_rate_plan_name", "charges", "modified_date", "revenue"])

            now = pd.Timestamp.now(tz="UTC")
            today = now.normalize()

            min_date = df['modified_date'].min() if not df.empty else now
            min_year = min_date.year if pd.notnull(min_date) else now.year

            buckets = {}

            # 1_day
            start_ts = today
            end_ts = now
            hour_starts = pd.date_range(start=start_ts, end=end_ts, freq="H", tz="UTC")
            points = []
            for h in hour_starts:
                end_h = h + pd.Timedelta(hours=1) - pd.Timedelta(seconds=1)
                if end_h > end_ts:
                    end_h = end_ts
                points.append(end_h)
            filtered = df[(df['modified_date'] >= start_ts) & (df['modified_date'] <= end_ts)]
            buckets['1_day'] = get_non_cumulative_grouping(filtered, points, date_only=False)

            # 5_day
            start_ts = today - pd.Timedelta(days=4)
            end_ts = today + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
            day_starts = pd.date_range(start=start_ts, end=today, freq="D", tz="UTC")
            points = []
            for d in day_starts:
                end_d = d + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
                points.append(end_d)
            filtered = df[(df['modified_date'] >= start_ts) & (df['modified_date'] <= end_ts)]
            buckets['5_day'] = get_non_cumulative_grouping(filtered, points, date_only=True)

            # 1_month
            month_start = now.replace(day=1)
            start_ts = month_start
            end_ts = now
            points = month_week_cutoffs_range(start_ts, end_ts)
            points = [p.replace(hour=23, minute=59, second=59) for p in points]
            filtered = df[(df['modified_date'] >= start_ts) & (df['modified_date'] <= end_ts)]
            buckets['1_month'] = get_non_cumulative_grouping(filtered, points, date_only=True)

            # 3_month
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1)
            start_ts = three_months_start
            end_ts = now
            points = month_week_cutoffs_range(start_ts, end_ts)
            points = [p.replace(hour=23, minute=59, second=59) for p in points]
            filtered = df[(df['modified_date'] >= start_ts) & (df['modified_date'] <= end_ts)]
            buckets['3_month'] = get_non_cumulative_grouping(filtered, points, date_only=True)

            # 6_month
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1)
            start_ts = six_months_start
            end_ts = now
            points = month_week_cutoffs_range(start_ts, end_ts)
            points = [p.replace(hour=23, minute=59, second=59) for p in points]
            filtered = df[(df['modified_date'] >= start_ts) & (df['modified_date'] <= end_ts)]
            buckets['6_month'] = get_non_cumulative_grouping(filtered, points, date_only=True)

            # 1_year
            year_start = pd.Timestamp(year=now.year, month=1, day=1, tz="UTC")
            start_ts = year_start
            end_ts = now
            points = month_week_cutoffs_range(start_ts, end_ts)
            points = [p.replace(hour=23, minute=59, second=59) for p in points]
            filtered = df[(df['modified_date'] >= start_ts) & (df['modified_date'] <= end_ts)]
            buckets['1_year'] = get_non_cumulative_grouping(filtered, points, date_only=True)

            # 5_years
            start_year = now.year - 4
            start_ts = pd.Timestamp(year=start_year, month=1, day=1, tz="UTC")
            end_ts = now
            points = yearly_points_last_n_years(5, end_ts)
            points = [p.replace(month=12, day=31, hour=23, minute=59, second=59) if p.year < now.year else end_ts for p in points]
            filtered = df[(df['modified_date'] >= start_ts) & (df['modified_date'] <= end_ts)]
            buckets['5_years'] = get_non_cumulative_grouping(filtered, points, year_only=True)

            # max
            start_ts = pd.Timestamp(year=min_year, month=1, day=1, tz="UTC")
            end_ts = now
            points = yearly_points_last_n_years(now.year - min_year +1, now)
            points = [p.replace(month=12, day=31, hour=23, minute=59, second=59) if p.year < now.year else end_ts for p in points]
            filtered = df[(df['modified_date'] >= start_ts) & (df['modified_date'] <= end_ts)]
            buckets['max'] = get_non_cumulative_grouping(filtered, points, year_only=True)

            # Cache
            new_sync_time = datetime.utcnow()
            try:
                redis_client.setex(cache_key, 7200, json.dumps(buckets, default=str))
                redis_client.set(f"{cache_key}:timestamp", new_sync_time.strftime("%Y-%m-%d %H:%M:%S"))
                logging.info(f"Cache set for key: {cache_key}")
                audit_data = {
                    "function_name": function,
                    "created_by": username,
                    "last_synced_by": username,
                }
                common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
            except Exception as redis_exc:
                logging.warning(f"Redis set failed: {redis_exc}")
            except Exception as audit_exc:
                logging.warning(f"Audit logging failed: {audit_exc}")

            cached_data = buckets

        # Post-cache filtering
        all_data = cached_data.copy() if cached_data else {}

        if tenant_id != "All" and tenant_id != "":
            for key in all_data:
                all_data[key] = [rec for rec in all_data[key] if rec.get("tenant_id", -1) == int(tenant_id)]

        if service_provider and service_provider != "":
            for key in all_data:
                all_data[key] = [rec for rec in all_data[key] if str(rec.get("service_provider", "")).lower() == service_provider.lower()]


        main_bucket = "1_month"

        # ------------------ date range filtering ------------------
        if start_date and end_date:
            start_ts = pd.to_datetime(start_date).tz_localize("UTC")
            end_ts = pd.to_datetime(end_date).tz_localize("UTC")
            date_diff = (end_ts - start_ts).days
            if date_diff <= 1:
                main_bucket = "1_day"
            elif date_diff <= 5:
                main_bucket = "5_day"
            elif date_diff <= 31:
                main_bucket = "1_month"
            elif date_diff <= 93:
                main_bucket = "3_month"
            elif date_diff <= 186:
                main_bucket = "6_month"
            elif date_diff <= 366:
                main_bucket = "1_year"
            elif date_diff <= 1826:
                main_bucket = "5_years"
            else:
                main_bucket = "max"

            filtered_buckets = {}
            for bucket, records in cached_data.items():
                filtered_buckets[bucket] = []
                for rec in records:
                    try:
                        rec_time = pd.to_datetime(rec["time"])
                        if getattr(rec_time, "tzinfo", None) is None:
                            rec_time = rec_time.tz_localize("UTC")
                    except Exception:
                        continue
                    if start_ts <= rec_time <= end_ts:
                        filtered_buckets[bucket].append(rec)

            all_data = {bucket: [] for bucket in cached_data.keys()}
            all_data[main_bucket] = filtered_buckets.get(main_bucket, [])
            all_data["custom_range"] = filtered_buckets.get(main_bucket, [])

        # ------------------ billing_cycle_end_date filtering ------------------
        if billing_cycle_end_date and billing_cycle_end_date != "":
            try:
                end_ts = pd.to_datetime(billing_cycle_end_date, utc=True)
                start_ts = end_ts - pd.Timedelta(days=30)
                date_diff = (end_ts - start_ts).days
                if date_diff <= 1:
                    main_bucket = "1_day"
                elif date_diff <= 5:
                    main_bucket = "5_day"
                elif date_diff <= 31:
                    main_bucket = "1_month"
                elif date_diff <= 93:
                    main_bucket = "3_month"
                elif date_diff <= 186:
                    main_bucket = "6_month"
                elif date_diff <= 366:
                    main_bucket = "1_year"
                elif date_diff <= 1826:
                    main_bucket = "5_years"
                else:
                    main_bucket = "max"

                filtered_buckets = {}
                for bucket, records in cached_data.items():
                    filtered_buckets[bucket] = []
                    for rec in records:
                        try:
                            rec_time = pd.to_datetime(rec["time"])
                            if getattr(rec_time, "tzinfo", None) is None:
                                rec_time = rec_time.tz_localize("UTC")
                        except Exception:
                            continue
                        if start_ts <= rec_time <= end_ts:
                            filtered_buckets[bucket].append(rec)

                all_data = {bucket: [] for bucket in cached_data.keys()}
                all_data[main_bucket] = filtered_buckets.get(main_bucket, [])
                all_data["custom_range"] = filtered_buckets.get(main_bucket, [])

            except Exception as bc_exc:
                logging.warning(f"Failed to process billing_cycle_end_date: {bc_exc}")
                  
        # Format the data for response
        meta_tenants = {}
        meta_providers = {}
        formatted_buckets = {}
        for bucket_name, bucket_data in all_data.items():
            grouped = defaultdict(list)
            for record in bucket_data:
                pid = record["provider_id"]
                revenue = record["revenue"]
                plan_name = record["customer_rate_plan_name"]
                time = record["time"]
                grouped[pid].append([time, revenue, plan_name])
                if str(pid) not in meta_providers:
                    meta_providers[str(pid)] = record["service_provider"]
            formatted = []
            for pid, records in grouped.items():
                records_sorted = sorted(records, key=lambda x: x[1], reverse=True)[:5]
                tenant_ids = {rec["tenant_id"] for rec in bucket_data if rec.get("tenant_id") not in (None, -1)}
                tenant_for_bucket = next(iter(tenant_ids), int(data.get("tenant_id", -1)))
                formatted.append({
                    "tenant_id": tenant_for_bucket,
                    "provider_id": pid,
                    "plans": [r[2] for r in records_sorted],
                    "records": records_sorted
                })
                
                # Collect tenant IDs (do not query here)
                if tenant_for_bucket not in meta_tenants:
                    meta_tenants[tenant_for_bucket] = None  # placeholder
                    
            formatted_buckets[bucket_name] = formatted

        if meta_tenants:
            try:
                ids = list(meta_tenants.keys())
                query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
                df_tenant = common_utils_database.execute_query(query, params=ids)
                if isinstance(df_tenant, pd.DataFrame):
                    for row in df_tenant.to_dict(orient="records"):
                        meta_tenants[str(row["tenant_id"])] = row["tenant_name"]
            except Exception as tenant_exc:
                logging.warning(f"Failed to resolve tenant names: {tenant_exc}")

        response["flag"] = True
        response["meta"]["tenants"] = meta_tenants
        response["meta"]["providers"] = meta_providers if meta_providers else {'-1': 'Unknown provider'}
        response["meta"]["default_time_range"] = main_bucket
        response["data"]["data"] = formatted_buckets
        return response

    except Exception as exception:
        logging.exception(f"[get_revenue_by_rate_plan] Exception: {exception}")
        response["flag"] = False
        response["data"]["data"] = {}
        response["data"]["yField"] = []
        response["message"] = f"Error retrieving revenue by rate plan {exception}"
        try:
            error_data = {
                "service_name": "get_revenue_by_rate_plan",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"[get_revenue_by_rate_plan] Error logging to DB : {e}")

    return response


def get_profit_margin_trend(data):
    """
    Returns a profit margin trend over several months for the dashboard.
    Uses Redis cache with filters applied post-cache.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): return profit .
            - 'message' (str): Error message if applicable.
    """
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = parse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.utcnow().date()
    tenant_name = data.get("tenant_name", "")
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
    tenant_id = data.get("tenant_id", "All")
    refresh = str(data.get("refresh", "False")).lower() == "true"
    tenant_database = data.get("db_name", "")
    billing_cycle_end_date = data.get("billing_cycle_end_period", "")
    service_provider = data.get("service_provider", "")

    response = {
        "flag": False,
        "meta": {
            "tenants": {},
            "providers": {},
            "plans": {},
            "default_time_range": "custom_range"
        },
        "data": {
            "title": "Profit Margin Trend",
            "chart_type": "line",
            "xField": ["Jan", "Feb", "Mar"],
            "yField": "profit_margin",
            "data": {},
            "smooth": True,
            "height": 300,
            "width": 500,
        },
        "message": "",
    }

    try:
        killbill_database = DB('billing_platform', **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        # Redis caching setup
        function = "get_profit_margin_trend"
        cache_key = get_cache_key(tenant_database, function)
        cached_data = None

        if not refresh:
            try:
                cached_response = redis_client.get(cache_key)
                if cached_response:
                    cached_data = json.loads(cached_response)
                    logging.info(f"Cache hit: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Cache fetch failed: {cache_exc}")

        # If refresh or no cache — compute and set cache
        if refresh or cached_data is None:
            logging.info("Fetching fresh SIM count data from DB")

            query = """
                SELECT tenant_id, service_provider_name as service_provider_display_name, revenue as total, modified_date
                FROM public.revenue_metrics_billing_dashboard
                WHERE modified_date IS NOT null
            """
            df = killbill_database.execute_query(query, True)

            # --- normalize dataframe ---
            if isinstance(df, pd.DataFrame) and not df.empty:
                df["tenant_id"] = pd.to_numeric(df.get("tenant_id"), errors="coerce").fillna(-1).astype(int)
                if "service_provider_id" in df.columns:
                    df["service_provider_id"] = pd.to_numeric(df.get("service_provider_id"), errors="coerce").fillna(-1).astype(int)

                df['modified_date'] = pd.to_datetime(df['modified_date'], errors='coerce', utc=True)
                df['created_date'] = df['modified_date']
                df['total'] = pd.to_numeric(df.get("total", 0), errors="coerce").fillna(0.0)
                # keep row-level profit_margin if needed, but we'll compute aggregated margins per range below
                df['profit_margin'] = np.where(
                    df['total'] != 0,
                    ((df['total'] - (df['total'] * 0.6)) / df['total']) * 100,
                    0.0
                )
            else:
                df = pd.DataFrame(columns=["tenant_id", "service_provider_display_name", "total", "modified_date", "created_date", "profit_margin"])

            # compute time cutoffs (use UTC-aware 'now')
            now = pd.Timestamp.now(tz="UTC")
            today = now.normalize()
            five_days_ago = today - pd.Timedelta(days=4)
            month_start = now.replace(day=1)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1)
            year_start = pd.Timestamp(year=now.year, month=1, day=1, tz="UTC")
            min_date = df['modified_date'].min() if not df.empty else now
            min_year = int(min_date.year) if pd.notnull(min_date) else int(now.year)

            # ---------- helper functions for range-based aggregation ----------
            def safe_label_for_range(start_ts: pd.Timestamp, end_ts: pd.Timestamp, date_only=True, year_only=False):
                if year_only:
                    return str(end_ts.year)
                if date_only:
                    return end_ts.date().isoformat()
                return end_ts.isoformat()

            def aggregate_ranges(ranges, date_only=True, year_only=False):
                """
                ranges: list of (start_ts, end_exclusive_ts) pairs (both tz-aware)
                returns list of aggregated records per range: grouped by tenant_id and provider name
                each record: {tenant_id, service_provider_display_name, profit_margin, time}
                """
                records = []
                if df.empty or not ranges:
                    return records

                for start_ts, end_excl in ranges:
                    # filter half-open [start_ts, end_excl)
                    subset = df[(df['modified_date'] >= start_ts) & (df['modified_date'] < end_excl)]
                    if subset.empty:
                        continue

                    grouped = subset.groupby(['tenant_id', 'service_provider_display_name'], as_index=False).agg(
                        total_sum=('total', 'sum')
                    )

                    label = safe_label_for_range(start_ts, (end_excl - pd.Timedelta(microseconds=1)), date_only=date_only, year_only=year_only)

                    for _, row in grouped.iterrows():
                        total_sum = row['total_sum'] if pd.notnull(row['total_sum']) else 0.0
                        profit_margin = 0.0
                        if total_sum != 0:
                            # apply same aggregated formula used previously
                            profit_margin = round(((total_sum - (total_sum * 0.6)) / total_sum) * 100, 2)
                        tenant_val = int(row['tenant_id']) if pd.notnull(row['tenant_id']) else -1
                        provider_name = row.get('service_provider_display_name') if pd.notnull(row.get('service_provider_display_name')) else "Unknown provider"
                        records.append({
                            "tenant_id": tenant_val,
                            "service_provider_display_name": provider_name,
                            "profit_margin": profit_margin,
                            "time": label
                        })
                return records

            # ---------- build ranges per your bucket logic ----------

            buckets = {}

            # 1_day: every 4 hours today (half-open intervals). Keep time component (date_only=False)
            day_intervals = []
            t_cursor = today
            # iterate 4h windows from midnight up to 'now'
            while t_cursor < now:
                start_ts = t_cursor
                end_ts = min(t_cursor + pd.Timedelta(hours=4), now + pd.Timedelta(microseconds=1))
                day_intervals.append((start_ts, end_ts))
                t_cursor = t_cursor + pd.Timedelta(hours=4)
            buckets['1_day'] = aggregate_ranges(day_intervals, date_only=False, year_only=False)

            # 5_day: each calendar day summed (half-open [day, next_day))
            days = pd.date_range(start=five_days_ago, end=today, freq="D", tz="UTC")
            day_ranges = []
            for d in days:
                start_ts = d.normalize()
                next_day = start_ts + pd.Timedelta(days=1)
                day_ranges.append((start_ts, next_day))
            buckets['5_day'] = aggregate_ranges(day_ranges, date_only=True, year_only=False)

            # Helper to produce month-week ranges for a month (1..7,8..14,15..21,22..EOM)
            def month_week_ranges_for_month(first_of_month: pd.Timestamp, end_cap: pd.Timestamp, include_partial=True):
                """
                Returns list of (start_ts, end_exclusive_ts) for week1, week2, week3, month-rest (EOM).
                If include_partial True and this is current month, ranges will be capped at 'end_cap' (now).
                """
                ranges = []
                tz = getattr(first_of_month, "tzinfo", None) or "UTC"
                f = pd.Timestamp(year=first_of_month.year, month=first_of_month.month, day=1, tz=tz)
                d7 = f + pd.Timedelta(days=7)        # exclusive boundary for week1 (1-7 => end_excl = 8th at 00:00)
                d14 = f + pd.Timedelta(days=14)      # week2 end_excl
                d21 = f + pd.Timedelta(days=21)      # week3 end_excl
                dend = (f + pd.offsets.MonthEnd(0)) + pd.Timedelta(days=1)  # exclusive end (first of next month)

                # compute end caps (if current month and partial)
                boundaries = [
                    (f, d7),
                    (d7, d14),
                    (d14, d21),
                    (d21, dend)
                ]

                for start_ts, end_excl in boundaries:
                    # if include_partial and this is the current month, cap end_excl at end_cap + 1 microsecond
                    if include_partial and (first_of_month.year == end_cap.year and first_of_month.month == end_cap.month):
                        capped_end = min(end_excl, end_cap + pd.Timedelta(microseconds=1))
                        if start_ts >= capped_end:
                            continue
                        ranges.append((start_ts, capped_end))
                    else:
                        if start_ts >= end_excl:
                            continue
                        ranges.append((start_ts, end_excl))
                return ranges

            # 1_month: current month week-ranges (include partial up to now)
            base_1_month_ranges = month_week_ranges_for_month(month_start, now, include_partial=True)
            buckets['1_month'] = aggregate_ranges(base_1_month_ranges, date_only=True, year_only=False)

            # 3_month: month_week ranges across 3 months window (include current partial)
            def month_range_list(start_month_ts: pd.Timestamp, end_ts: pd.Timestamp):
                months = []
                cursor = pd.Timestamp(year=start_month_ts.year, month=start_month_ts.month, day=1, tz=getattr(start_month_ts, "tzinfo", None) or "UTC")
                end_month_first = pd.Timestamp(year=end_ts.year, month=end_ts.month, day=1, tz=getattr(end_ts, "tzinfo", None) or "UTC")
                while cursor <= end_month_first:
                    months.append(cursor)
                    cursor = (cursor + pd.offsets.MonthEnd(0)) + pd.Timedelta(days=1)
                return months

            months_3 = month_range_list(three_months_start, now)
            ranges_3m = []
            for m in months_3:
                include_partial = (m.year == now.year and m.month == now.month)
                ranges_3m.extend(month_week_ranges_for_month(m, now, include_partial=include_partial))
            buckets['3_month'] = aggregate_ranges(ranges_3m, date_only=True, year_only=False)

            # 6_month
            months_6 = month_range_list(six_months_start, now)
            ranges_6m = []
            for m in months_6:
                include_partial = (m.year == now.year and m.month == now.month)
                ranges_6m.extend(month_week_ranges_for_month(m, now, include_partial=include_partial))
            buckets['6_month'] = aggregate_ranges(ranges_6m, date_only=True, year_only=False)

            # 1_year: month-week ranges across year_start .. now
            months_1y = month_range_list(year_start, now)
            ranges_1y = []
            for m in months_1y:
                include_partial = (m.year == now.year and m.month == now.month)
                ranges_1y.extend(month_week_ranges_for_month(m, now, include_partial=include_partial))
            buckets['1_year'] = aggregate_ranges(ranges_1y, date_only=True, year_only=False)

            # 5_years: yearly ranges (Jan 1 .. Dec 31) for last 5 years (and current partial year up to now)
            def yearly_ranges_last_n_years(n_years: int, end_ts: pd.Timestamp):
                start_year = end_ts.year - n_years
                ranges = []
                for y in range(start_year, end_ts.year):
                    start_ts = pd.Timestamp(year=y, month=1, day=1, tz=getattr(end_ts, "tzinfo", None) or "UTC")
                    next_start = pd.Timestamp(year=y+1, month=1, day=1, tz=getattr(end_ts, "tzinfo", None) or "UTC")
                    ranges.append((start_ts, next_start))
                # current year partial
                start_curr = pd.Timestamp(year=end_ts.year, month=1, day=1, tz=getattr(end_ts, "tzinfo", None) or "UTC")
                ranges.append((start_curr, end_ts + pd.Timedelta(microseconds=1)))
                return ranges

            ranges_5y = yearly_ranges_last_n_years(5, now)
            buckets['5_years'] = aggregate_ranges(ranges_5y, date_only=True, year_only=True)

            # max: from min_year to current year
            def yearly_ranges_from_to(start_year: int, end_ts: pd.Timestamp):
                ranges = []
                for y in range(start_year, end_ts.year):
                    start_ts = pd.Timestamp(year=y, month=1, day=1, tz=getattr(end_ts, "tzinfo", None) or "UTC")
                    next_start = pd.Timestamp(year=y+1, month=1, day=1, tz=getattr(end_ts, "tzinfo", None) or "UTC")
                    ranges.append((start_ts, next_start))
                # current year partial
                start_curr = pd.Timestamp(year=end_ts.year, month=1, day=1, tz=getattr(end_ts, "tzinfo", None) or "UTC")
                ranges.append((start_curr, end_ts + pd.Timedelta(microseconds=1)))
                return ranges

            ranges_max = yearly_ranges_from_to(min_year, now)
            buckets['max'] = aggregate_ranges(ranges_max, date_only=True, year_only=True)

            # Cache results
            new_sync_time = datetime.utcnow()
            try:
                redis_client.setex(cache_key, 7200, json.dumps(buckets, default=str))
                redis_client.set(f"{cache_key}:timestamp", new_sync_time.strftime("%Y-%m-%d %H:%M:%S"))
                logging.info(f"Cache set for key: {cache_key}")
                # audit
                try:
                    audit_data = {
                        "function_name": function,
                        "created_date": request_received_at,
                        "created_by": username,
                        "last_synced_by": username,
                        "last_sync_date": new_sync_time,
                    }
                    common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")
            except Exception as redis_exc:
                logging.warning(f"Redis set failed: {redis_exc}")

            cached_data = buckets

        # ------------------ post-cache filtering ------------------
        all_data = cached_data.copy() if cached_data else {}

        # Tenant filter: apply only when tenant_id provided and not "All" and not empty
        if tenant_id != "All" and tenant_id != "":
            for key in list(all_data.keys()):
                try:
                    all_data[key] = [
                        rec for rec in all_data[key]
                        if int(rec.get("tenant_id", -1)) == int(tenant_id)
                    ]
                except Exception:
                    all_data[key] = [
                        rec for rec in all_data[key]
                        if rec.get("tenant_id", -1) == tenant_id
                    ]

        # Service provider filter
        if service_provider and service_provider != "":
            sp_norm = service_provider.strip().lower()
            for key in list(all_data.keys()):
                all_data[key] = [
                    rec for rec in all_data[key]
                    if str(rec.get("service_provider_display_name", "")).strip().lower() == sp_norm
                ]

        # Billing cycle end period filtering ✅ using 'time' within past 30 days
        if billing_cycle_end_date and billing_cycle_end_date != "":
            try:
                end_dt = pd.to_datetime(str(billing_cycle_end_date), utc=True, errors="coerce")
                if pd.notnull(end_dt):
                    start_dt = end_dt - pd.Timedelta(days=30)

                    for bucket_name in list(all_data.keys()):
                        filtered = []
                        for rec in all_data[bucket_name]:
                            try:
                                # some 'time' labels are dates, some are ISO datetimes, handle both
                                rec_dt = pd.to_datetime(str(rec.get("time")), utc=True, errors="coerce")
                            except Exception:
                                rec_dt = None
                            if rec_dt is not None and start_dt <= rec_dt <= end_dt:
                                filtered.append(rec)
                        all_data[bucket_name] = filtered
            except Exception as bc_exc:
                logging.warning(f"Billing cycle filtering failed: {bc_exc}")

        # respect requested custom start/end to choose main_bucket
        if start_date and end_date:
            start_ts = pd.to_datetime(start_date).tz_localize("UTC")
            end_ts = pd.to_datetime(end_date).tz_localize("UTC")
            date_diff = (end_ts - start_ts).days

            if date_diff <= 1:
                main_bucket = "1_day"
            elif date_diff <= 5:
                main_bucket = "5_day"
            elif date_diff <= 31:
                main_bucket = "1_month"
            elif date_diff <= 93:
                main_bucket = "3_month"
            elif date_diff <= 186:
                main_bucket = "6_month"
            elif date_diff <= 366:
                main_bucket = "1_year"
            elif date_diff <= 1826:
                main_bucket = "5_years"
            else:
                main_bucket = "max"

            # Keep only that bucket + custom_range (if exists)
            all_data = {k: v for k, v in all_data.items() if k in (main_bucket, "custom_range")}

        # ------------------ format output ------------------
        meta_tenants = {}
        meta_providers = {}
        all_buckets = {label: [] for label in ["1_day", "5_day", "1_month", "3_month", "6_month", "1_year", "5_years", "max", "custom_range"]}

        for bucket_name in all_buckets.keys():
            bucket_data = all_data.get(bucket_name, [])
            grouped = defaultdict(list)
            for record in bucket_data:
                tenant_key = int(record.get("tenant_id", -1))  # use -1 sentinel fallback
                key = str(tenant_key)
                grouped[key].append([record.get("time", ""), record.get("profit_margin", 0)])

                if tenant_id == "All":
                    meta_tenants[key] = ""
                else:
                    # keep requested tenant in meta
                    if tenant_id != "All" and tenant_id != "":
                        meta_tenants[str(int(tenant_id))] = ""

            formatted = []
            for tenant_key_str, records in grouped.items():
                tenant_for_bucket = int(bucket_data[0].get("tenant_id", -1)) if bucket_data else -1
                formatted.append({
                    "tenant_id": tenant_for_bucket,
                    "records": records
                })
            all_buckets[bucket_name] = formatted

        # Resolve tenant name if specific tenant requested
        if meta_tenants:
            try:
                ids = list(meta_tenants.keys())
                query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
                df_tenant = common_utils_database.execute_query(query, params=ids)
                if isinstance(df_tenant, pd.DataFrame):
                    for row in df_tenant.to_dict(orient="records"):
                        meta_tenants[str(row["tenant_id"])] = row["tenant_name"]
            except Exception as tenant_exc:
                logging.warning(f"Failed to resolve tenant names: {tenant_exc}")

        # Prepare final response
        response = {
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "default_time_range": main_bucket if 'main_bucket' in locals() else "1_month",
            },
            "data": {
                "title": "Profit Margin Trend",
                "chart_type": "line",
                "xField": ["Jan", "Feb", "Mar"],
                "yField": "profit_margin",
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            }
        }
        return response

    except Exception as exception:
        logging.exception(f"[get_profit_margin_trend] Exception: {exception}")
        response["message"] = f"Error retrieving profit margin trend{exception}"
        try:
            error_data = {
                "service_name": "get_profit_margin_trend",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"[get_profit_margin_trend] Error logging to DB : {e}")

    return response


def get_revenue_by_usage_trend(data):
    """
    Returns a bar chart showing total revenue for each usage_type across service providers.
    Caches full unfiltered DB result in Redis and applies filters only on cached data.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): return revenue based on usage type .
            - 'message' (str): Error message if applicable.
    """

    tenant_id = data.get("tenant_id", "")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = parse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.utcnow().date()
    tenant_name = data.get("tenant_name", "")
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
    refresh = str(data.get("refresh", "False")).lower() == "true"
    service_provider = data.get("service_provider", "")
    # NOTE: billing_cycle_end_period accepted in input but intentionally not used (removed per request)
    billing_cycle_end_period = data.get("billing_cycle_end_period", None)

    response = {
        "flag": False,
        "meta": {
            "tenants": {},
            "providers": {},
            "plans": {},
            "default_time_range": "custom_range"
        },
        "data": {
            "title": "Revenue by Usage Type",
            "chart_type": "bar",
            "xField": ["Data", "Voice", "Sms", "Roaming"],
            "yField": "",
            "data": {},
            "smooth": True,
            "height": 300,
            "width": 500,
        },
        "message": "",
    }

    try:
        killbill_database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        function = "get_revenue_by_usage_trend"
        cache_key = get_cache_key(tenant_database, function)

        cached_data = None
        
        try:
            cached_response = redis_client.get(cache_key)
            if cached_response:
                cached_data = json.loads(cached_response)
                logging.info(f"Cache hit for key: {cache_key}")
        except Exception as cache_exc:
            logging.warning(f"Cache retrieval failed: {cache_exc}")

        # ---------- helpers ----------
        def eom(ts: pd.Timestamp) -> pd.Timestamp:
            """Returns the end-of-month timestamp for the given date."""
            return (ts + pd.offsets.MonthEnd(0))

        def month_week_cutoffs_for_month(first_of_month: pd.Timestamp, end_cap: pd.Timestamp, include_today_partial: bool):
            """
            Return cutoffs for a single month:
            - day 7, 14, 21, EOM that are <= end_cap
            - if this is the current month and include_today_partial=True -> also include today (end_cap.normalize())
            """
            pts = []
            d7 = first_of_month + pd.Timedelta(days=6)    # 7th
            d14 = first_of_month + pd.Timedelta(days=13)  # 14th
            d21 = first_of_month + pd.Timedelta(days=20)  # 21st
            dend = eom(first_of_month)                    # EOM

            for p in (d7, d14, d21, dend):
                # compare normalized dates to avoid time-of-day differences
                if p.normalize() <= end_cap.normalize():
                    pts.append(p.normalize())

            if include_today_partial and (first_of_month.year == end_cap.year and first_of_month.month == end_cap.month):
                today_pt = end_cap.normalize()
                if today_pt not in pts:
                    pts.append(today_pt)

            # unique and sorted
            pts_sorted = sorted(pd.to_datetime(list(dict.fromkeys(pts))))
            return pts_sorted

        def month_week_cutoffs_range(start_month_ts: pd.Timestamp, end_ts: pd.Timestamp, include_today_partial=True):
            """
            For each month in the range [start_month_ts .. end_ts], accumulate week cutoffs.
            start_month_ts expected to be first day of that month.
            """
            points = []
            cursor = pd.Timestamp(year=start_month_ts.year, month=start_month_ts.month, day=1, tz=getattr(start_month_ts, "tzinfo", None) or "UTC")
            end_month_first = pd.Timestamp(year=end_ts.year, month=end_ts.month, day=1, tz=getattr(end_ts, "tzinfo", None) or "UTC")

            while cursor <= end_month_first:
                include_today = include_today_partial and (cursor.year == end_ts.year and cursor.month == end_ts.month)
                month_pts = month_week_cutoffs_for_month(cursor, end_ts, include_today)
                points.extend(month_pts)
                # move to next month first day
                cursor = (cursor + pd.offsets.MonthEnd(0)) + pd.Timedelta(days=1)

            # ensure unique & sorted
            points_unique_sorted = sorted(pd.to_datetime(list(dict.fromkeys(points))))
            return points_unique_sorted

        def yearly_points_last_n_years(n_years: int, end_ts: pd.Timestamp):
            """
            Return Dec-31 for each past year in the window and 'today' for the current year.
            e.g. for last 5 years: years end points + today
            """
            start_year = end_ts.year - n_years
            pts = [pd.Timestamp(year=y, month=12, day=31, tz=getattr(end_ts, "tzinfo", None) or "UTC") for y in range(start_year, end_ts.year)]
            pts.append(end_ts.normalize())
            return sorted(pd.to_datetime(list(dict.fromkeys(pts))))

        def to_datestr(ts: pd.Timestamp, date_only=True, year_only=False) -> str:
            """Formats a timestamp into a date string, full ISO string, or year-only string."""
            if year_only:
                return str(ts.year)
            return ts.date().isoformat() if date_only else ts.isoformat()

        def non_cumulative_grouping(time_points, date_only=True, year_only=False):
            """Aggregates usage (data, voice, SMS, roaming) for each tenant and service provider at exact time points without accumulation,
               returning a list of records with normalized time and provider.

               CHANGES:
               - Accepts time_points derived from actual DB timestamps (floored to the appropriate granularity)
               - If time_points are Period objects (e.g. months), compares using .dt.to_period
               - For date_only=True -> compares normalized date equality
               - For year_only=True -> compares by year
               - For time-level buckets (date_only=False) -> compares by hour (floor to hour) to avoid matching every record via normalize()
            """
            records = []
            if time_points is None:
                return records

            # Convert PeriodIndex / Periods into a list format but preserve Period objects
            pts = list(time_points) if not isinstance(time_points, (pd.PeriodIndex, pd.Series)) else list(time_points)

            if len(pts) == 0:
                return records

            df_sorted = df.sort_values('modified_date')

            for t in pts:
                try:
                    # Handle pandas Period (months/years)
                    if isinstance(t, pd.Period):
                        # match by the period frequency
                        mask = df_sorted['modified_date'].dt.to_period(t.freq) == t
                        # for formatting, use start_time of the period converted to timestamp
                        # Period.start_time is timezone-naive; ensure UTC tz
                        t_for_fmt = pd.to_datetime(t.start_time).tz_localize("UTC") if pd.notnull(t.start_time) else pd.Timestamp(t.asfreq('D').start_time, tz="UTC")
                    else:
                        # normalize t into tz-aware Timestamp
                        t_ts = pd.to_datetime(t)
                        if getattr(t_ts, "tzinfo", None) is None:
                            try:
                                t_ts = t_ts.tz_localize("UTC")
                            except Exception:
                                t_ts = pd.to_datetime(t_ts, utc=True)

                        if year_only:
                            mask = df_sorted['modified_date'].dt.year == t_ts.year
                        elif date_only:
                            # compare only date component
                            mask = df_sorted['modified_date'].dt.normalize() == t_ts.normalize()
                        else:
                            # compare at hour precision (floor to hour). This ensures we only match rows that fall in that hour.
                            mask = df_sorted['modified_date'].dt.floor('H') == t_ts.floor('H')
                        t_for_fmt = t_ts

                    subset = df_sorted[mask]
                except Exception as inner_exc:
                    logging.debug(f"non_cumulative_grouping: skipping time point {t} due to {inner_exc}")
                    continue

                if subset.empty:
                    continue

                # Group by keys and sum — billing_cycle_end_date removed
                grouped = subset.groupby(
                    ['tenant_id', 'service_provider_id', 'service_provider_display_name'],
                    as_index=False
                ).agg({
                    'data_usage': 'sum',
                    'voice_usage': 'sum',
                    'sms_usage': 'sum',
                    'roaming_usage': 'sum'
                })

                # Format time string according to flags
                t_str = to_datestr(t_for_fmt, date_only=date_only, year_only=year_only)

                for _, row in grouped.iterrows():
                    rec = {
                        "tenant_id": int(row['tenant_id']) if pd.notnull(row['tenant_id']) else -1,
                        "provider_id": int(row['service_provider_id']) if pd.notnull(row['service_provider_id']) else -1,
                        "service_provider": row.get('service_provider_display_name') if pd.notnull(row.get('service_provider_display_name')) else "Unknown",
                        "data_usage": int(row['data_usage']) if pd.notnull(row['data_usage']) else 0,
                        "voice_usage": int(row['voice_usage']) if pd.notnull(row['voice_usage']) else 0,
                        "sms_usage": int(row['sms_usage']) if pd.notnull(row['sms_usage']) else 0,
                        "roaming_usage": int(row['roaming_usage']) if pd.notnull(row['roaming_usage']) else 0,
                        "time": t_str
                    }
                    records.append(rec)

            # Remove duplicates here by (tenant, provider, time)
            deduped = list({(r["tenant_id"], r["provider_id"], r["time"]): r for r in records}.values())
            return deduped

        # ---------- compute fresh data if needed ----------
        if refresh or cached_data is None:
            logging.info("Fetching fresh SIM count data from DB")

            query = """
                select tenant_id, service_provider_id, service_provider_display_name,
                       delta_ctd_data_usage, ctd_voice_usage, ctd_sms_usage, customer_cycle_usage_mb, created_date as modified_date
                from fn_get_sim_inventory_altaworx_test()
            """

            df = killbill_database.execute_query(query, True)

            # Normalize dataframe
            # ensure modified_date parsed and made UTC-aware
            df['modified_date'] = pd.to_datetime(df['modified_date'], errors='coerce', utc=True)

            # Use actual usage columns from DB
            df["data_usage"] = df.get("delta_ctd_data_usage", pd.Series(dtype=float)).fillna(0)
            df["voice_usage"] = df.get("ctd_voice_usage", pd.Series(dtype=float)).fillna(0)
            df["sms_usage"] = df.get("ctd_sms_usage", pd.Series(dtype=float)).fillna(0)
            df["roaming_usage"] = df.get("customer_cycle_usage_mb", pd.Series(dtype=float)).fillna(0)

            # --- CHANGES: preserve null IDs using sentinel -1 ---
            df["tenant_id"] = pd.to_numeric(df.get("tenant_id"), errors="coerce").fillna(-1).astype(int)
            # service_provider_id may exist — ensure sentinel -1 if missing
            if "service_provider_id" in df.columns:
                df["service_provider_id"] = pd.to_numeric(df.get("service_provider_id"), errors="coerce").fillna(-1).astype(int)
            else:
                df["service_provider_id"] = -1

            now = pd.Timestamp.now(tz="UTC")
            today = now.normalize()  # midnight today (tz-aware)
            five_days_ago = today - pd.Timedelta(days=4)
            month_start = now.replace(day=1)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1)
            year_start = pd.Timestamp(year=now.year, month=1, day=1, tz="UTC")
            min_date = df['modified_date'].min() if not df.empty else now
            min_year = int(min_date.year) if pd.notnull(min_date) else int(now.year)

            # ---------- build buckets ----------
            buckets = {}

            # --- NEW: build buckets from actual DB timestamps (no artificial slots) ---

            # ensure modified_date is tz-aware UTC already (done above), but guard if not
            try:
                df['modified_date'] = pd.to_datetime(df['modified_date'], utc=True)
            except Exception:
                df['modified_date'] = pd.to_datetime(df['modified_date'], errors='coerce', utc=True)

            # 1_day: use actual hours present in dataframe within today's window (floor to hour)
            try:
                pts_1_day = df.loc[(df['modified_date'] >= today) & (df['modified_date'] <= now), 'modified_date'] \
                              .dt.floor('H') \
                              .drop_duplicates() \
                              .sort_values()
                buckets['1_day'] = non_cumulative_grouping(pts_1_day, date_only=False)
            except Exception:
                # fallback to previous behavior if something unexpected happens
                buckets['1_day'] = non_cumulative_grouping(pd.date_range(start=today, end=now, freq="4h", tz="UTC"), date_only=False)

            # 5_day: unique dates present in last 5 days
            try:
                pts_5_day = df.loc[(df['modified_date'] >= five_days_ago) & (df['modified_date'] <= now), 'modified_date'] \
                             .dt.normalize() \
                             .drop_duplicates() \
                             .sort_values()
                buckets['5_day'] = non_cumulative_grouping(pts_5_day, date_only=True)
            except Exception:
                buckets['5_day'] = non_cumulative_grouping(pd.date_range(start=five_days_ago, end=today, freq="D", tz="UTC"), date_only=True)

            # 1_month: actual dates present in current month
            try:
                pts_1_month = df.loc[(df['modified_date'] >= month_start) & (df['modified_date'] <= now), 'modified_date'] \
                               .dt.normalize() \
                               .drop_duplicates() \
                               .sort_values()
                buckets['1_month'] = non_cumulative_grouping(pts_1_month, date_only=True)
            except Exception:
                buckets['1_month'] = non_cumulative_grouping(
                    month_week_cutoffs_range(month_start, now, include_today_partial=True),
                    date_only=True
                )

            # 3_month: actual dates present within 3-month window
            try:
                pts_3_month = df.loc[(df['modified_date'] >= three_months_start) & (df['modified_date'] <= now), 'modified_date'] \
                                .dt.normalize() \
                                .drop_duplicates() \
                                .sort_values()
                buckets['3_month'] = non_cumulative_grouping(pts_3_month, date_only=True)
            except Exception:
                buckets['3_month'] = non_cumulative_grouping(
                    month_week_cutoffs_range(three_months_start, now, include_today_partial=True),
                    date_only=True
                )

            # 6_month: actual dates present within 6-month window
            try:
                pts_6_month = df.loc[(df['modified_date'] >= six_months_start) & (df['modified_date'] <= now), 'modified_date'] \
                                .dt.normalize() \
                                .drop_duplicates() \
                                .sort_values()
                buckets['6_month'] = non_cumulative_grouping(pts_6_month, date_only=True)
            except Exception:
                buckets['6_month'] = non_cumulative_grouping(
                    month_week_cutoffs_range(six_months_start, now, include_today_partial=True),
                    date_only=True
                )

            # 1_year: use month periods actually present in this year (to reduce points)
            try:
                pts_1_year = df.loc[(df['modified_date'] >= year_start) & (df['modified_date'] <= now), 'modified_date'] \
                              .dt.to_period('M') \
                              .drop_duplicates() \
                              .sort_values()
                buckets['1_year'] = non_cumulative_grouping(pts_1_year, date_only=True)
            except Exception:
                buckets['1_year'] = non_cumulative_grouping(
                    month_week_cutoffs_range(year_start, now, include_today_partial=True),
                    date_only=True
                )

            # 5_years: use unique years present in the data but limit to last 5 years (if available)
            try:
                unique_years = sorted(df['modified_date'].dt.year.drop_duplicates())
                if unique_years:
                    max_year = unique_years[-1]
                    start_cut = max_year - 4  # last 5 years window
                    years_to_use = [y for y in unique_years if y >= start_cut]
                    pts_5_years = [pd.Timestamp(year=y, month=12, day=31, tz="UTC") for y in years_to_use]
                else:
                    pts_5_years = yearly_points_last_n_years(5, now)
                buckets['5_years'] = non_cumulative_grouping(pts_5_years, year_only=True)
            except Exception:
                buckets['5_years'] = non_cumulative_grouping(yearly_points_last_n_years(5, now), year_only=True)

            # max: use all distinct years present in the data (from min_year to current year)
            try:
                unique_years_all = sorted(df['modified_date'].dt.year.drop_duplicates())
                if unique_years_all:
                    pts_max = [pd.Timestamp(year=y, month=12, day=31, tz="UTC") for y in unique_years_all]
                else:
                    pts_max = yearly_points_last_n_years(now.year - min_year + 1, now)
                buckets['max'] = non_cumulative_grouping(pts_max, year_only=True)
            except Exception:
                buckets['max'] = non_cumulative_grouping(yearly_points_last_n_years(now.year - min_year + 1, now), year_only=True)

            # Cache results: append to existing cache (no expiry) and deduplicate
            try:
                existing_cache_raw = redis_client.get(cache_key)
                if existing_cache_raw:
                    try:
                        existing_cache = json.loads(existing_cache_raw)
                    except Exception:
                        existing_cache = {}
                else:
                    existing_cache = {}

                merged = existing_cache.copy() if isinstance(existing_cache, dict) else {}

                for bname, new_recs in buckets.items():
                    if bname not in merged or merged.get(bname) is None:
                        merged[bname] = []

                    # build a set of existing keys for deduplication
                    existing_keys = set()
                    for r in merged[bname]:
                        try:
                            existing_keys.add((int(r.get("tenant_id", -1)), int(r.get("provider_id", -1)), r.get("time")))
                        except Exception:
                            existing_keys.add((r.get("tenant_id", -1), r.get("provider_id", -1), r.get("time")))

                    for rec in new_recs:
                        try:
                            key = (int(rec.get("tenant_id", -1)), int(rec.get("provider_id", -1)), rec.get("time"))
                        except Exception:
                            key = (rec.get("tenant_id", -1), rec.get("provider_id", -1), rec.get("time"))
                        if key not in existing_keys:
                            merged[bname].append(rec)
                            existing_keys.add(key)

                # Save merged cache without expiry
                redis_client.set(cache_key, json.dumps(merged, default=str))
                # update timestamp key (no expiry)
                try:
                    redis_client.set(f"{cache_key}:timestamp", datetime.utcnow().isoformat())
                except Exception:
                    redis_client.set(f"{cache_key}:timestamp", str(datetime.utcnow()))

                logging.info(f"Cache updated (append mode, no expiry) for key: {cache_key}")
                # audit
                try:
                    audit_data = {
                        "function_name": function,
                        "created_date": request_received_at,
                        "created_by": username,
                        "last_synced_by": username,
                    }
                    common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")
            except Exception as redis_exc:
                logging.warning(f"Redis set failed: {redis_exc}")

            cached_data = buckets if not merged else merged

        # ------------------ post-cache filtering ------------------
        all_data = cached_data.copy() if cached_data else {}

        # Tenant filter: apply only when tenant_id provided and not "All" and not empty
        if tenant_id != "All" and tenant_id != "":
            for key in list(all_data.keys()):
                try:
                    all_data[key] = [
                        rec for rec in all_data[key]
                        if int(rec.get("tenant_id", -1)) == int(tenant_id)
                    ]
                except Exception:
                    all_data[key] = [
                        rec for rec in all_data[key]
                        if rec.get("tenant_id", -1) == tenant_id
                    ]

        # Service provider filtering (case-insensitive by display name)
        if service_provider and service_provider != "":
            sp_norm = service_provider.strip().lower()
            logging.info(sp_norm, "sp_normsp_normsp_norm")
            for bucket_name in list(all_data.keys()):
                filtered = [
                    provider for provider in all_data[bucket_name]
                    if str(provider.get("service_provider", "")).strip().lower() == sp_norm
                ]
                all_data[bucket_name] = filtered


        # Billing cycle end period filtering ✅ using modified_date within past 30 days
        if billing_cycle_end_period and billing_cycle_end_period != "":
            try:
                end_dt = pd.to_datetime(str(billing_cycle_end_period), utc=True, errors="coerce")
                if pd.notnull(end_dt):
                    start_dt = end_dt - pd.Timedelta(days=30)

                    for bucket_name in list(all_data.keys()):
                        filtered = []
                        for rec in all_data[bucket_name]:
                            try:
                                rec_dt = pd.to_datetime(str(rec.get("time")), utc=True, errors="coerce")
                            except Exception:
                                rec_dt = None
                            if rec_dt is not None and start_dt <= rec_dt <= end_dt:
                                filtered.append(rec)
                        all_data[bucket_name] = filtered
            except Exception as bc_exc:
                logging.warning(f"Billing cycle filtering failed: {bc_exc}")

        if start_date and end_date:
            start_ts = pd.to_datetime(start_date)
            end_ts = pd.to_datetime(end_date)
            date_diff = (end_ts - start_ts).days

            # Decide which main bucket this date range belongs to
            if date_diff <= 1:
                main_bucket = "1_day"
            elif date_diff <= 5:
                main_bucket = "5_day"
            elif date_diff <= 31:
                main_bucket = "1_month"
            elif date_diff <= 93:
                main_bucket = "3_month"
            elif date_diff <= 186:
                main_bucket = "6_month"
            elif date_diff <= 366:
                main_bucket = "1_year"
            elif date_diff <= 1826:
                main_bucket = "5_years"
            else:
                main_bucket = "max"

            # Keep only that bucket + custom_range (if any)
            all_data = {k: v for k, v in all_data.items() if k in (main_bucket, "custom_range")}

        # ------------------ format output ------------------
        meta_tenants = {}
        meta_providers = {}
        all_buckets = {label: [] for label in ["1_day", "5_day", "1_month", "3_month", "6_month", "1_year", "5_years", "max", "custom_range"]}

        for bucket_name in all_buckets.keys():
            bucket_data = all_data.get(bucket_name, [])
            grouped = defaultdict(list)
            for record in bucket_data:
                tenant_key = int(record.get("tenant_id", -1))
                key = str(tenant_key)
                pid = record.get("provider_id", -1)
                pname = record.get("service_provider", "Unknown")
                data_usage = int(record.get("data_usage", 0))
                voice_usage = int(record.get("voice_usage", 0))
                sms_usage = int(record.get("sms_usage", 0))
                roaming_usage = int(record.get("roaming_usage", 0))

                grouped[(pid)].append(
                    [record.get("time", ""), data_usage, voice_usage, sms_usage, roaming_usage]
                )

                # keep provider display name in meta (string keys)
                if pid not in meta_providers:
                    meta_providers[pid] = pname
                if tenant_id == "All":
                    meta_tenants[key] = ""
                else:
                    # ensure requested tenant is present in meta if provided
                    if tenant_id != "All" and tenant_id != "":
                        meta_tenants[str(int(tenant_id))] = ""

            formatted = []
            for pid, records in grouped.items():
                # remove duplicates by (time, provider_id)
                unique_records = list({(r[0], pid): r for r in records}.values())
                formatted.append({
                    "tenant_id": int(bucket_data[0]["tenant_id"]) if bucket_data else -1,
                    "provider_id": pid,
                    "records": unique_records
                })
            all_buckets[bucket_name] = formatted

        # Resolve tenant name if specific tenant requested
        if meta_tenants:
            try:
                ids = list(meta_tenants.keys())
                query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
                df_tenant = common_utils_database.execute_query(query, params=ids)
                if isinstance(df_tenant, pd.DataFrame):
                    for row in df_tenant.to_dict(orient="records"):
                        meta_tenants[str(row["tenant_id"])] = row["tenant_name"]
            except Exception as tenant_exc:
                logging.warning(f"Failed to resolve tenant names: {tenant_exc}")

        # Prepare final response
        response = {
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "providers": meta_providers,
                "default_time_range": main_bucket if 'main_bucket' in locals() else "1_month",
            },
            "data": {
               "title": "Revenue by Usage Type",
                "chart_type": "bar",
                "xField": ["Data", "Voice", "Sms", "Roaming"],
                "yField": "",
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            }
        }
        return response

    except Exception as exception:
        logging.exception(f"[get_revenue_by_usage_trend] Exception: {exception}")
        response["flag"] = False
        response["data"]["data"] = {}
        response["data"]["yField"] = []
        response["message"] = f"Error retrieving plan usage by service provider{exception}"
        try:
            error_data = {
                "service_name": "get_revenue_by_usage_trend",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception:
            logging.exception("[get_revenue_by_usage_trend] Error logging to DB")

    return response


######################### Revenue metrics  ############################

########################## zendesk Tab ####################

ZENDESK_SUBDOMAIN = os.getenv('ZENDESK_SUBDOMAIN')

BASE_URL = f'https://{ZENDESK_SUBDOMAIN}.zendesk.com/api/v2'
ZENDESK_EMAIL = os.getenv('ZENDESK_EMAIL')
ZENDESK_API_TOKEN = os.getenv('ZENDESK_API_TOKEN')

def normalize(tag):
    """
    Converts tag to lowercase and removes all non-alphanumeric characters.
    Example: "Bulk Change" → "bulkchange"
    """
    return re.sub(r'[^a-z0-9]', '', tag.lower())

def generate_intervals_for_label(label, start, end):
    """Generate start points for intervals based on label rules."""
    intervals = []

    if label == "1_day":
        # Every 4 hours
        current = datetime.combine(start, datetime.min.time())
        while current <= datetime.combine(end, datetime.max.time()):
            intervals.append(current)
            current += timedelta(hours=4)

    elif label == "5_day":
        # Every 1 day
        current = start
        while current <= end:
            intervals.append(datetime.combine(current, datetime.min.time()))
            current += timedelta(days=1)

    elif label in ["1_month", "3_month", "6_month", "1_year"]:
        # Weekly grouping 1–7, 8–14, 15–21, 22–end_of_month
        today = date.today()
        current = start
        while current <= end:
            y, m = current.year, current.month
            days_in_month = monthrange(y, m)[1]

            # If this is the current month, only go up to today
            if y == today.year and m == today.month:
                days_in_month = today.day

            cutoffs = [1, 8, 15, 22, days_in_month + 1]

            for i in range(len(cutoffs) - 1):
                week_start = date(y, m, cutoffs[i])
                if week_start < start or week_start > end:
                    continue
                intervals.append(datetime.combine(week_start, datetime.min.time()))

            # Go to next month
            if m == 12:
                current = date(y + 1, 1, 1)
            else:
                current = date(y, m + 1, 1)

    elif label == "5_years":
        # Fixed 5-year window: current year and past 4 years
        today = date.today()
        start_year = today.year - 4
        for year in range(start_year, today.year + 1):
            intervals.append(datetime.combine(date(year, 1, 1), datetime.min.time()))

    elif label == "max":
        # Every 2 years
        start_year = (start.year // 2) * 2
        current = date(start_year, 1, 1)
        while current <= end:
            intervals.append(datetime.combine(current, datetime.min.time()))
            current = date(current.year + 2, 1, 1)

    return intervals

def get_status_count_of_tickets(data):
    """
    Returns count of tickets based on status. Uses Redis caching and filters data only on cached results.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
           
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): return ticket countbased on status .
            - 'message' (str): Error message if applicable.
    """

    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    organization_id = data.get("tenant_id", "")
    refresh = str(data.get("refresh", "False")).lower() == "true"

    response_data = {
        "flag": False,
        "data": {
            "title": "Ticket Status Volume",
            "columns": ["Status", "Count"],
            "organization_id": organization_id,
            "rows": [],
            "height": 100,
            "width": 300,
        },
        "message": "",
    }

    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as exception:
        response_data["message"] = f"Database connection error : {exception}"
        try:
            error_data = {
                "service_name": "get_status_count_of_tickets",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            common_utils_database.log_error_to_db(error_data, "error_table")
        except Exception:
            pass
        return response_data

    try:
        # Cache logic
        function = "get_status_count_of_tickets"
        cache_key = get_cache_key("zendesk_tickets_tracking", function)
        cached_data = None

        if not refresh:
            try:
                cached = redis_client.get(cache_key)
                if cached:
                    cached_data = json.loads(cached)
                    logging.info(f"Cache hit: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Redis cache retrieval failed: {cache_exc}")

        if refresh or cached_data is None:
            logging.info("Fetching fresh data for ticket status count")

            query = """
                SELECT 
                    ticket_status,
                    created_date,
                    organization_id
                FROM public.zendesk_tickets_tracking
                WHERE ticket_status IN ('open', 'new', 'hold', 'pending', 'solved', 'closed')
            """

            result_df = common_utils_database.execute_query(query, flag=True)
            if isinstance(result_df, pd.DataFrame) and not result_df.empty:
                result_df["created_date"] = pd.to_datetime(result_df["created_date"]).dt.date
                cached_data = result_df.to_dict(orient="records")

                try:
                    redis_client.setex(cache_key, 7200, json.dumps(cached_data,default=str))  # 2 hours TTL
                    redis_client.set(f"{cache_key}:timestamp", datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
                    logging.info(f"Redis set successful: {cache_key}")
                except Exception as redis_exc:
                    logging.warning(f"Redis set failed: {redis_exc}")
                new_sync_time = datetime.now()
                #  Audit refresh after setting cache
                try:
                        audit_data = {
                            "function_name": function,
                            "created_date": request_received_at,
                            "created_by": username,
                            "last_synced_by": username,
                            "last_sync_date": new_sync_time,
                        }
                        common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                        logging.warning(f"Audit logging failed: {audit_exc}")
            else:
                cached_data = []

        # Convert cached data to DataFrame
        df_all = pd.DataFrame(cached_data)
        if not df_all.empty:
            df_all["created_date"] = pd.to_datetime(df_all["created_date"]).dt.date

            if organization_id != "All":
                df_all = df_all[df_all["organization_id"] == str(organization_id)]

            if start_date and end_date:
                start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
                end_date = datetime.strptime(end_date, "%Y-%m-%d").date()
                df_all = df_all[
                    (df_all["created_date"] >= start_date) &
                    (df_all["created_date"] <= end_date)
                ]

            # Define status mapping
            status_map = {
                "open": "Active",
                "new": "Active",
                "hold": "Active",
                "pending": "Inprogress",
                "solved": "Closed",
                "closed": "Closed"
            }

            df_all["status_category"] = df_all["ticket_status"].map(status_map)

            grouped = df_all.groupby("status_category").size().to_dict()

            label_display = {
                "Active": "Active Tickets",
                "Inprogress": "In progress Tickets",
                "Closed": "Closed Tickets"
            }

            status_defaults = {key: 0 for key in label_display}
            for key in grouped:
                if key in status_defaults:
                    status_defaults[key] = grouped[key]

            rows = [{
                "Status": label_display[key],
                "Count": f"{status_defaults[key]:,}"
            } for key in ["Active", "Inprogress", "Closed"]]

            total = sum(status_defaults.values())
            rows.append({"Status": "Total Tickets", "Count": f"{total:,}"})

            response_data["flag"] = True
            response_data["data"]["rows"] = serialize_data(rows)
            response_data["message"] = ""

    except Exception as exception:
        response_data["flag"] = False
        response_data["message"] = f"Error fetching status of tickets: {exception}"
        try:
            error_data = {
                "service_name": "get_status_count_of_tickets",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_table")
        except Exception:
            pass

    return response_data

def fetch_zendesk(endpoint, params=None):
    """Fetches data (typically tickets) from the Zendesk API,  
    while handling authentication, pagination, and optional date filtering."""
    all_results = []
    auth = (f"{ZENDESK_EMAIL}/token", ZENDESK_API_TOKEN)
    is_incremental = "/incremental/tickets.json" in endpoint

    # Handle incremental parameters
    start_time = 0
    end_timestamp = None
    if is_incremental and params:
        start_date_str = params.get("start_date", "")
        end_date_str = params.get("end_date", "")

        if start_date_str:
            try:
                start_time = int(time.mktime(datetime.strptime(start_date_str, "%Y-%m-%d").timetuple()))
            except Exception as e:
                logging.warning(f"Invalid start_date format: {start_date_str}. Error: {e}")

        if end_date_str:
            try:
                end_timestamp = int(time.mktime(datetime.strptime(end_date_str, "%Y-%m-%d").timetuple()))
            except Exception as e:
                logging.warning(f"Invalid end_date format: {end_date_str}. Error: {e}")

    # Construct URL
    if is_incremental:
        url = f"{BASE_URL}/incremental/tickets.json?start_time={start_time}"
    else:
        url = f"{BASE_URL}{endpoint}"

 

    prev_url = None
    while url:
        if url == prev_url:
            logging.info("Detected stuck pagination loop. Exiting.")
            break
        prev_url = url
        response = requests.get(url, auth=auth, params=None if is_incremental else params)

        if response.status_code != 200:
            raise Exception(f"API Error {response.status_code}: {response.text}")

        data = response.json()
        results = data.get('tickets', data.get('results', []))
        all_results.extend(results)

        # Stop if end_timestamp is reached
        if is_incremental and end_timestamp is not None:
            latest_ticket_time = data.get('end_time', 0)
            if latest_ticket_time >= end_timestamp:
                break

        url = data.get('next_page')
        if not is_incremental:
            params = None  # Clear params after first request

    return all_results


def get_bulk_organization_names(org_ids):
    """
    Fetches organization names in bulk from Zendesk endpoint.
    Returns a dictionary mapping organization_id -> name.
    """
    if not org_ids:
        return {}
 
    org_ids = list(org_ids)  # ✅ Fix: Ensure list for slicing
    auth = (f"{ZENDESK_EMAIL}/token", ZENDESK_API_TOKEN)
    org_name_map = {}
    chunk_size = 100  # Zendesk limit per request
 
    for i in range(0, len(org_ids), chunk_size):
        chunk = org_ids[i:i + chunk_size]
        ids_param = ",".join(chunk)
        url = f"{BASE_URL}/organizations/show_many.json?ids={ids_param}"
 
        try:
            response = requests.get(url, auth=auth)
            if response.status_code == 200:
                orgs = response.json().get("organizations", [])
                for org in orgs:
                    org_id = str(org.get("id"))
                    org_name = org.get("name")
                    org_name_map[org_id] = org_name
 
            elif response.status_code == 429:
                retry_after = int(response.headers.get("Retry-After", 10))
                logging.warning(f"Rate limited. Retrying after {retry_after} seconds.")
                time.sleep(retry_after)
                continue
 
            else:
                raise Exception(f"Failed to fetch organizations: {response.status_code} - {response.text}")
        except Exception as exception:
            logging.error(f"Error fetching organization names: {exception}")
 
        time.sleep(0.2)  # Prevent rate limiting
 
    return org_name_map
 
 
def get_ticket_audits(ticket_id, auth):
    """Fetch audit history for a single ticket"""
    audit_url = f"{BASE_URL}/tickets/{ticket_id}/audits.json"
    try:
        response = requests.get(audit_url, auth=auth)
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", 10))
            logging.warning(f"Rate limited while fetching audits. Retrying after {retry_after} seconds.")
            time.sleep(retry_after)
            return get_ticket_audits(ticket_id, auth)  # Retry the request
        else:
            logging.warning(f"Failed to fetch audits for ticket {ticket_id}: {response.status_code}")
            return None
    except Exception as e:
        logging.error(f"Error fetching audits for ticket {ticket_id}: {e}")
        return None
 


def insert_new_zendesk_tickets_batch(data):
    """Fetch tickets from Zendesk, insert new tickets into DB, and log audit"""
    response = {
        "flag": False,
        "inserted_count": 0,
        "message": "",
    }
    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        batch_size = 100
        auth = (f"{ZENDESK_EMAIL}/token", ZENDESK_API_TOKEN)
        url = f"{BASE_URL}/tickets.json?per_page={batch_size}"

        all_tickets = {}
        while url:
            response_api = requests.get(url, auth=auth)
            if response_api.status_code != 200:
                logging.error(f"Failed to fetch tickets: {response_api.status_code} - {response_api.text}")
                response["message"] = f"Failed to fetch tickets: {response_api.status_code}"
                break

            data_api = response_api.json()
            tickets = data_api.get("tickets", data_api.get("results", []))
            if not tickets:
                break

            for t in tickets:
                ticket_id = str(t["id"])
                all_tickets[ticket_id] = t

            url = data_api.get("next_page")
            time.sleep(0.2)

        if not all_tickets:
            response["message"] = "No tickets found to insert."
            return response

        ticket_ids = list(all_tickets.keys())
        if not ticket_ids:
            response["message"] = "No ticket IDs found."
            return response

        placeholders = ','.join(['%s'] * len(ticket_ids))
        check_query = f"SELECT ticket_id FROM zendesk_tickets_tracking WHERE ticket_id IN ({placeholders})"
        existing_rows = database.execute_query(check_query, return_df=True, params=ticket_ids)
        existing_ids = set(existing_rows["ticket_id"].astype(str)) if existing_rows is not None else set()

        insert_data_in_table = []

        # Collect org_ids for NEW tickets
        org_ids = {
            str(t.get("organization_id"))
            for tid, t in all_tickets.items()
            if tid not in existing_ids and t.get("organization_id")
        }
        org_name_cache = get_bulk_organization_names(org_ids)

        # Insert new tickets
        for ticket_id in ticket_ids:
            if ticket_id in existing_ids:
                continue

            ticket = all_tickets[ticket_id]
            org_id = str(ticket.get("organization_id")) if ticket.get("organization_id") else None
            org_name = org_name_cache.get(org_id) if org_id else None

            tags_list = ticket.get("tags") or []
            tags_pg_array = '{' + ','.join(f'"{t}"' for t in tags_list) + '}'

            created_at = ticket.get("created_at")
            created_date = None
            if created_at:
                try:
                    dt = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%SZ")
                    created_date = dt.strftime("%Y-%m-%d %H:%M:%S+00")
                except Exception:
                    created_date = created_at

            

            insert_data_in_table.append({
                "ticket_id": ticket_id,
                "organization_id": org_id,
                "organization_name": org_name,
                "ticket_status": ticket.get("status"),
                "created_date": created_date,
                "tag": tags_pg_array,
                "priority": ticket.get("priority"),
                "subcategory": ticket.get("type"),
                "updated_date": ticket.get("updated_at"),
                "due_at": ticket.get("due_at")
                # "interaction_history": interaction_history
            })

        inserted_count = 0
        if insert_data_in_table:
            # ✅ Batch insert in chunks of 500
            batch_size = 500
            for i in range(0, len(insert_data_in_table), batch_size):
                batch = insert_data_in_table[i:i + batch_size]
                database.insert_data(batch, "zendesk_tickets_tracking")
                inserted_count += len(batch)

            response["flag"] = True
            response["inserted_count"] = inserted_count
            response["message"] = f"Inserted {inserted_count} new tickets (in batches of {batch_size})."
        else:
            response["flag"] = True
            response["inserted_count"] = 0
            response["message"] = "No new tickets to insert."

        # Audit log
        try:
            audit_data = {
                "service_name": "insert_new_zendesk_tickets_batch",
                "created_by": "Lambda Sync",
                "status": "Success" if inserted_count > 0 else "No Insert",
                "comments": f"Inserted {inserted_count} new Zendesk tickets.",
                "module_name": "Dashboard",
            }
            database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.warning(f"[insert_new_zendesk_tickets_batch] Audit logging failed: {audit_exc}")

    except Exception as exception:
        response["flag"] = False
        response["message"] = f"Error inserting Zendesk tickets: {exception}"
        try:
            error_data = {
                "service_name": "insert_new_zendesk_tickets_batch",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": "Lambda Sync",
                "comments": str(exception),
                "module_name": "Dashboard",
            }
            if 'database' in locals():
                database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.warning(f"[insert_new_zendesk_tickets_batch] Error logging to DB: {log_exc}")

    return response


def get_ticket_status_distribution(data):
    """
    Returns ticket status distribution for an organization in multiple time buckets.
    Uses Redis caching to fetch unfiltered data, filters applied in-memory.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
           
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): return ticket status distribution .
            - 'message' (str): Error message if applicable.
    """
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    start_date_str = data.get("start_date", "")
    end_date_str = data.get("end_date", "")
    organization_id = data.get("tenant_id", "")
    refresh = str(data.get("refresh", "False")).lower() == "true"

    response = {
        "flag": False,
        "meta": {
            "organization_names": {},
            "default_time_range": ""
        },
        "data": {
            "title": "Ticket Status Distribution",
            "chart_type": "Pie chart",
            "xField": "",
            "yField": "",
            "smooth": False,
            "height": 300,
            "width": 500,
            "data": {
                "1_day": [],
                "5_day": [],
                "1_month": [],
                "3_month": [],
                "6_month": [],
                "1_year": [],
                "5_years": [],
                "max": [],
                "custom_range": []
            }
        },
        "message": ""
    }

    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date() if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date() if end_date_str else None

        # Redis cache key
        function = "get_ticket_status_distribution"
        cache_key = get_cache_key("zendesk_tickets_tracking", function)
        cached_data = None

        if not refresh:
            try:
                cached = redis_client.get(cache_key)
                if cached:
                    cached_data = json.loads(cached)
                    logging.info(f"Cache hit: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Redis cache retrieval failed: {cache_exc}")

        if refresh or cached_data is None:
            logging.info("Fetching fresh data for ticket status distribution")

            raw_query = """
                SELECT 
                    organization_id,
                    organization_name,
                    created_date,
                    ticket_status
                FROM zendesk_tickets_tracking
                WHERE created_date IS NOT NULL
            """

            df = database.execute_query(raw_query, flag=True)
            df = df if isinstance(df, pd.DataFrame) else pd.DataFrame()
            if not df.empty:
                # Keep both tz-aware timestamp and date-only for downstream buckets
                df["created_datetime"] = pd.to_datetime(df["created_date"], errors="coerce", utc=True)
                df["created_date"] = df["created_datetime"].dt.date

                cached_data = df.to_dict(orient="records")

                try:
                    redis_client.setex(cache_key, 7200, json.dumps(cached_data, default=str))
                    redis_client.set(f"{cache_key}:timestamp", datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
                except Exception as redis_exc:
                    logging.warning(f"Redis set failed: {redis_exc}")
                new_sync_time = datetime.now()
                #  Audit refresh after setting cache
                try:
                    audit_data = {
                        "function_name": function,
                        "created_date": request_received_at,
                        "created_by": username,
                        "last_synced_by": username,
                        "last_sync_date": new_sync_time,
                    }
                    database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")
            else:
                cached_data = []

        df_all = pd.DataFrame(cached_data)
        if df_all.empty:
            return response

        # Ensure tz-aware created_datetime and date-only created_date (handles cached records too)
        if "created_datetime" in df_all.columns:
            try:
                df_all["created_datetime"] = pd.to_datetime(df_all["created_datetime"], utc=True)
            except Exception:
                df_all["created_datetime"] = pd.to_datetime(df_all["created_datetime"], errors="coerce", utc=True)
        else:
            df_all["created_datetime"] = pd.to_datetime(df_all["created_date"], errors="coerce", utc=True)

        df_all["created_date"] = df_all["created_datetime"].dt.date

        logging.info("df_all['created_date'] -> %s", df_all["created_date"].head())

        # Apply filters
        if organization_id and organization_id != "All":
            before = len(df_all)
            df_all = df_all[df_all["organization_id"] == str(organization_id)]
            after = len(df_all)
            logging.info(f"[Filter] Org filter applied: {before} -> {after} rows for org_id={organization_id}")
        logging.info("start_date %s", start_date)
        logging.info("end_date %s", end_date)
        if start_date and end_date:
            before = len(df_all)
            logging.info(f"[Filter] Date filter requested: start_date={start_date}, end_date={end_date}")

            df_all = df_all[
                (df_all["created_date"] >= start_date) & 
                (df_all["created_date"] <= end_date)
            ]
            after = len(df_all)
            logging.info(f"[Filter] After date filtering: {before} -> {after} rows")
            if df_all.empty:
                response["message"] = "No data available for the selected date range."
                response["flag"] = True   # mark as success
                return response
        logging.info("df_all-> %s", df_all.shape)

        # Determine min_date if not provided
        min_date = df_all["created_date"].min() if not (start_date and end_date) else None
        logging.info(f"[Bucket] min_date={min_date}, start_date={start_date}, end_date={end_date}")
        time_buckets, default_label = execute_all_time_buckets(start_date, end_date, min_date, column="created_date")
        logging.info("time_buckets %s", time_buckets)
        logging.info("default_label %s", default_label)
        response["meta"]["default_time_range"] = default_label

        status_map = {
            'open': 'Open',
            'new': 'To do',
            'pending': 'Inprogress',
            'hold': 'To do',
            'solved': 'Closed',
            'closed': 'Closed'
        }

        org_id_to_name = {}
        collected_org_ids = set()

        # ---------- INLINE 1_day handling using explicit pd.date_range 4-hour edges ----------
        if any(b["label"] == "1_day" for b in time_buckets):
            bucket = next(b for b in time_buckets if b["label"] == "1_day")
            b_start = bucket["start"]
            b_end = bucket["end"]

            # Build timezone-aware timestamps in UTC (to match created_datetime)
            bucket_start_dt = datetime.combine(b_start, datetime.min.time())
            bucket_end_dt = datetime.combine(b_end, datetime.max.time())

            bucket_start_ts = pd.Timestamp(bucket_start_dt).tz_localize("UTC")
            bucket_end_ts = pd.Timestamp(bucket_end_dt).tz_localize("UTC")

            floored_start = bucket_start_ts.floor("4H")
            ceiled_end = bucket_end_ts.ceil("4H")

            edges = pd.date_range(start=floored_start, end=ceiled_end, freq="4h", tz="UTC")

            for i in range(len(edges) - 1):
                interval_start_ts = edges[i]
                interval_end_ts = edges[i + 1] - pd.Timedelta(seconds=1)

                # Filter rows for this 4-hour window using tz-aware created_datetime
                df_filtered = df_all[
                    (df_all["created_datetime"] >= interval_start_ts) &
                    (df_all["created_datetime"] <= interval_end_ts)
                ].copy()

                if df_filtered.empty:
                    continue

                # label for this window uses interval end timestamp
                date_label = interval_end_ts.strftime("%Y-%m-%d %H:%M:%S")

                df_filtered["status_category"] = df_filtered["ticket_status"].fillna("").str.lower().map(status_map).fillna("To do")

                org_records = defaultdict(lambda: defaultdict(lambda: {"Open": 0, "To do": 0, "Inprogress": 0, "Closed": 0}))
                for _, row in df_filtered.iterrows():
                    org_id = row.get("organization_id")
                    org_name = row.get("organization_name", "Unknown Organization")
                    status = row.get("status_category", "To do")

                    if not org_id:
                        continue

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name
                    org_records[org_id][date_label][status] += 1

                for org_id, date_dict in org_records.items():
                    formatted_records = [{"date": date_key, "status_counts": counts} for date_key, counts in date_dict.items()]
                    response["data"]["data"]["1_day"].append({
                        "organization_id": org_id,
                        "records": serialize_data(formatted_records)
                    })

            # Remove 1_day bucket from further processing
            time_buckets = [b for b in time_buckets if b["label"] != "1_day"]
        # ---------- END INLINE 1_day handling ----------

        # --- Updated interval/sub-bucket logic starts here (remaining labels) ---
        for bucket in time_buckets:
            start, end, label = bucket["start"], bucket["end"], bucket["label"]
            intervals = generate_intervals_for_label(label, start, end)

            for interval_start in intervals:
                # Determine interval_end based on label
                if label == "5_day":
                    interval_end = interval_start + timedelta(days=1) - timedelta(seconds=1)
                elif label in ["1_month", "3_month", "6_month", "1_year"]:
                    y, m = interval_start.year, interval_start.month
                    days_in_month = monthrange(y, m)[1]
                    cutoffs = [1, 8, 15, 22, days_in_month + 1]
                    start_day = interval_start.day
                    idx = cutoffs.index(start_day)
                    end_day = cutoffs[idx + 1] - 1
                    interval_end = date(y, m, end_day)
                elif label == "5_years":
                    interval_end = date(interval_start.year + 1, 1, 1) - timedelta(seconds=1)

                elif label == "max":
                    # Get the first and last year from the filtered data
                    start_year = df_all["created_date"].min().year
                    end_year = df_all["created_date"].max().year

                    for year in range(start_year, end_year + 1):
                        year_start = date(year, 1, 1)
                        year_end = date(year, 12, 31)

                        # Clip by actual start/end dates if outside selected range
                        if start_date and year_start < start_date:
                            year_start = start_date
                        if end_date and year_end > end_date:
                            year_end = end_date

                        df_filtered = df_all[
                            (df_all["created_date"] >= year_start) & 
                            (df_all["created_date"] <= year_end)
                        ].copy()

                        if df_filtered.empty:
                            continue

                        # df_filtered["date"] = year_end.strftime("%Y-%m-%d")
                        if label in ["5_years", "max"]:
                            df_filtered["date"] = df_filtered["created_date"].apply(lambda x: str(x.year))
                        elif label == "1_day":
                            # Use datetime with hours for 4-hour buckets
                            df_filtered["date"] = interval_end.strftime("%Y-%m-%d %H:%M:%S")
                        else:
                            df_filtered["date"] = interval_end.strftime("%Y-%m-%d")


                        df_filtered["status_category"] = df_filtered["ticket_status"].str.lower().map(status_map).fillna("To do")

                        org_records = defaultdict(lambda: defaultdict(lambda: {"Open": 0, "To do": 0, "Inprogress": 0, "Closed": 0}))
                        for _, row in df_filtered.iterrows():
                            org_id = row["organization_id"]
                            # logging.info("###org_id:%s", org_id)
                            org_name = row.get("organization_name", "Unknown Organization")
                            date_val = row["date"]
                            status = row["status_category"]

                            if not org_id:
                                continue

                            collected_org_ids.add(org_id)
                            org_id_to_name[org_id] = org_name
                            org_records[org_id][date_val][status] += 1

                        for org_id, date_dict in org_records.items():
                            formatted_records = [{"date": date_key, "status_counts": counts} for date_key, counts in date_dict.items()]
                            response["data"]["data"][label].append({
                                "organization_id": org_id,
                                "records": serialize_data(formatted_records)
                            })

                else:
                    interval_end = end

                start_dt = interval_start.date() if isinstance(interval_start, datetime) else interval_start
                end_dt = interval_end.date() if isinstance(interval_end, datetime) else interval_end

                df_filtered = df_all[
                    (df_all["created_date"] >= start_dt) & 
                    (df_all["created_date"] <= end_dt)
                ].copy()

                if df_filtered.empty:
                    continue

                if label in ["5_years", "max"]:
                    # Ensure created_date is datetime first
                    df_filtered["date"] = df_filtered["created_date"].apply(lambda x: str(x.year))
                else:
                    df_filtered["date"] = interval_end.strftime("%Y-%m-%d")  # assign all to interval end
                df_filtered["status_category"] = df_filtered["ticket_status"].str.lower().map(status_map).fillna("To do")

                org_records = defaultdict(lambda: defaultdict(lambda: {"Open": 0, "To do": 0, "Inprogress": 0, "Closed": 0}))
                for _, row in df_filtered.iterrows():
                    org_id = row["organization_id"]
                    org_name = row.get("organization_name", "Unknown Organization")
                    date_val = row["date"]
                    status = row["status_category"]

                    if not org_id:
                        continue

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name
                    org_records[org_id][date_val][status] += 1

                for org_id, date_dict in org_records.items():
                    formatted_records = [{"date": date_key, "status_counts": counts} for date_key, counts in date_dict.items()]
                    response["data"]["data"][label].append({
                        "organization_id": org_id,
                        "records": serialize_data(formatted_records)
                    })
        # --- End of updated interval/sub-bucket logic ---
        # After all loops
        if collected_org_ids:
            response["meta"]["organization_names"] = {
                str(org_id): org_id_to_name.get(org_id, "Unknown Organization") for org_id in collected_org_ids
            }
            response["flag"] = True

    except Exception as exception:
        logging.exception(f"[get_ticket_status_distribution] Error: {exception}")
        response["message"] = f"Unexpected error occurred during data preparation: {exception}"
        response["flag"] = False
        try:
            error_data = {
                "service_name": "get_ticket_status_distribution",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'database' in locals():
                database.log_error_to_db(error_data, "error_log_table")
        except Exception:
            pass

    return response


def get_ticket_resolution_time(data):
    
    """
    Calculates the average resolution time for tickets, grouped by organization,
    and provides this data across multiple time buckets.
    """
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    start_date_str = data.get("start_date", "")
    end_date_str = data.get("end_date", "")
    organization_id = data.get("tenant_id", "")

    response = {
        "flag": False,
        "meta": {
            "organization_names": {},
            "default_time_range": ""
        },
        "data": {
            "title": "Ticket Resolution Time",
            "chart_type": "line",
            "xField": "date",
            "yField": "avg_resolution_hours",
            "smooth": True,
            "height": 300,
            "width": 500,
            "data": {
                "1_day": [],
                "5_day": [],
                "1_month": [],
                "3_month":[],
                "6_month":[],
                "1_year": [],
                "5_years": [],
                "max": [],
                "custom_range": []
            }
        },
        "message": ""
    }

    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date() if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date() if end_date_str else None

        if not (start_date and end_date):
            min_date_query = "SELECT MIN(created_date) FROM zendesk_tickets_tracking"
            min_date_result = database.execute_query(min_date_query, flag=True)
            min_date_str = min_date_result.iloc[0]["min"] if not min_date_result.empty else None
            min_date = datetime.fromisoformat(min_date_str.replace("Z", "")).date() if min_date_str else None
        else:
            min_date = None

        time_buckets, default_label = execute_all_time_buckets(start_date, end_date, min_date)
        response["meta"]["default_time_range"] = default_label

        collected_org_ids = set()
        org_id_to_name = {}

        for bucket in time_buckets:
            start = bucket["start"]
            end = bucket["end"]
            label = bucket["label"]
            time_format = bucket["format"]
            formatted_time = time_format.replace("created_date", "created_date::timestamp")

            base_query = f"""
                SELECT
                    organization_id,
                    organization_name,
                    {formatted_time} AS date,
                    AVG(EXTRACT(EPOCH FROM (updated_date - created_date))) / 3600 AS avg_resolution_hours
                FROM zendesk_tickets_tracking
                WHERE ticket_status IN ('solved', 'closed') AND updated_date IS NOT NULL
            """
            query_params = []

            if start and end:
                base_query += " AND created_date::timestamp BETWEEN %s AND %s"
                query_params.append(start.strftime("%Y-%m-%d 00:00:00"))
                query_params.append(end.strftime("%Y-%m-%d 23:59:59"))

            if organization_id and str(organization_id).lower() != "all":
                org_id_str = str(organization_id).strip()
                base_query += " AND organization_id = %s"
                query_params.append(org_id_str)

            base_query += " GROUP BY organization_id, organization_name, date ORDER BY date"

            results_df = database.execute_query(base_query, params=query_params)
            results = results_df.to_dict(orient="records") if results_df is not None else []

            for row in results:
                org_id = row.get("organization_id")
                org_name = row.get("organization_name") or "Unknown Organization"
                collected_org_ids.add(org_id)
                org_id_to_name[org_id] = org_name

                response["data"]["data"][label].append({
                    "organization_id": org_id,
                    "organization_name": org_name,
                    "date": str(row.get("date", "")).replace("'", ""),
                    "avg_resolution_hours": round(row.get("avg_resolution_hours", 0), 2)
                })

        if collected_org_ids:
            response["meta"]["organization_names"] = {
                str(org_id): org_id_to_name.get(org_id, "Unknown Organization") for org_id in collected_org_ids
            }
            response["flag"] = True

    except Exception as exception:
        response["message"] = f"Error fetching ticket resolution time : {exception}"
        response["flag"] = False
        try:
            error_data = {
                "service_name": "get_ticket_resolution_time",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            database.log_error_to_db(error_data, "error_log_table")
            logging.error(f"[get_ticket_resolution_time]: {exception}")
        except Exception as e:
            logging.exception(f"[get_ticket_resolution_time] Error logging to DB : {e}")

    return response

def get_ticket_severity_overview(data):
    """
    Returns ticket severity distribution (Low, Medium, High) for an organization across time buckets,
    with interval logic and week cutoff grouping for month-based labels.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): return ticket count based on severity(low,high,medium) .
            - 'message' (str): Error message if applicable.
    """
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    start_date_str = data.get("start_date", "")
    end_date_str = data.get("end_date", "")
    organization_id = data.get("tenant_id", "")
    refresh = str(data.get("refresh", "False")).lower() == "true"

    response = {
        "flag": False,
        "meta": {
            "organization_names": {},
            "default_time_range": ""
        },
        "data": {
            "title": "Ticket Severity Overview",
            "chart_type": "Heatmap",
            "xField": "",
            "yField": "",
            "smooth": False,
            "height": 300,
            "width": 500,
            "data": {
                "1_day": [], "5_day": [], "1_month": [], "3_month": [], "6_month": [],
                "1_year": [], "5_years": [], "max": [], "custom_range": []
            }
        },
        "message": ""
    }

    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date() if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date() if end_date_str else None

        # Redis cache
        function = "get_ticket_severity_overview"
        cache_key = get_cache_key("zendesk_tickets_tracking", function)
        cached_data = None

        if not refresh:
            try:
                cached = redis_client.get(cache_key)
                if cached:
                    cached_data = json.loads(cached)
                    logging.info(f"[Cache Hit] {cache_key}")
            except Exception as e:
                logging.warning(f"[Redis Get Error] {e}")

        if refresh or cached_data is None:
            raw_query = """
                SELECT 
                    organization_id,
                    organization_name,
                    created_date,
                    priority
                FROM zendesk_tickets_tracking
                WHERE created_date IS NOT NULL
            """
            df = database.execute_query(raw_query, flag=True)
            df = df if isinstance(df, pd.DataFrame) else pd.DataFrame()

            if not df.empty:
                # Keep full timestamp (tz-aware) and date-only
                df["created_datetime"] = pd.to_datetime(df["created_date"], errors="coerce", utc=True)
                df["created_date"] = df["created_datetime"].dt.date

                cached_data = df.to_dict(orient="records")
                try:
                    redis_client.setex(cache_key, 7200, json.dumps(cached_data, default=str))
                    redis_client.set(f"{cache_key}:timestamp", datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
                except Exception as e:
                    logging.warning(f"[Redis Set Error] {e}")

                try:
                    audit_data = {
                        "function_name": function,
                        "created_by": username,
                        "last_synced_by": username,
                    }
                    database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")
            else:
                cached_data = []

        df_all = pd.DataFrame(cached_data)
        if df_all.empty:
            return response

        # Ensure tz-aware created_datetime and date-only created_date for downstream logic
        if "created_datetime" in df_all.columns:
            try:
                df_all["created_datetime"] = pd.to_datetime(df_all["created_datetime"], utc=True)
            except Exception:
                df_all["created_datetime"] = pd.to_datetime(df_all["created_datetime"], errors="coerce", utc=True)
        else:
            df_all["created_datetime"] = pd.to_datetime(df_all.get("created_date", None), errors="coerce", utc=True)

        df_all["created_date"] = df_all["created_datetime"].dt.date

        logging.info("Requested range: %s to %s", start_date, end_date)
        logging.info("Available range: %s to %s", df_all["created_date"].min(), df_all["created_date"].max())

        # Filters
        if organization_id and organization_id != "All":
            df_all = df_all[df_all["organization_id"] == str(organization_id)]

        if start_date and end_date:
            df_all = df_all[
                (df_all["created_date"] >= start_date) &
                (df_all["created_date"] <= end_date)
            ]
            if df_all.empty:
                response["message"] = "No data available for the selected date range."
                response["flag"] = True   # mark as success
                return response

        min_date = df_all["created_date"].min() if not (start_date and end_date) else None
        time_buckets, default_label = execute_all_time_buckets(start_date, end_date, min_date, column="created_date")
        response["meta"]["default_time_range"] = default_label

        severity_map = {
            'low': 'Low',
            'normal': 'Medium',
            'high': 'High',
            'urgent': 'High'
        }

        collected_org_ids = set()
        org_id_to_name = {}

        # ---------- INLINE 1_day handling using explicit pd.date_range 4-hour edges ----------
        if any(b["label"] == "1_day" for b in time_buckets):
            bucket = next(b for b in time_buckets if b["label"] == "1_day")
            b_start = bucket["start"]
            b_end = bucket["end"]

            # Build timezone-aware timestamps in UTC (to match created_datetime)
            bucket_start_dt = datetime.combine(b_start, datetime.min.time())
            bucket_end_dt = datetime.combine(b_end, datetime.max.time())

            bucket_start_ts = pd.Timestamp(bucket_start_dt).tz_localize("UTC")
            bucket_end_ts = pd.Timestamp(bucket_end_dt).tz_localize("UTC")

            floored_start = bucket_start_ts.floor("4H")
            ceiled_end = bucket_end_ts.ceil("4H")

            edges = pd.date_range(start=floored_start, end=ceiled_end, freq="4h", tz="UTC")

            for i in range(len(edges) - 1):
                interval_start_ts = edges[i]
                interval_end_ts = edges[i + 1] - pd.Timedelta(seconds=1)

                # Filter rows for this 4-hour window using tz-aware created_datetime
                df_filtered = df_all[
                    (df_all["created_datetime"] >= interval_start_ts) &
                    (df_all["created_datetime"] <= interval_end_ts)
                ].copy()

                if df_filtered.empty:
                    continue

                # Map priority -> severity and aggregate counts
                df_filtered["priority"] = df_filtered["priority"].fillna("").astype(str).str.lower()
                df_filtered["severity"] = df_filtered["priority"].map(severity_map).fillna("Medium")
                date_label = interval_end_ts.strftime("%Y-%m-%d %H:%M:%S")

                org_records = defaultdict(lambda: defaultdict(lambda: {"Low": 0, "Medium": 0, "High": 0}))
                for _, row in df_filtered.iterrows():
                    org_id = row.get("organization_id")
                    org_name = row.get("organization_name", "Unknown Organization")
                    severity = row.get("severity", "Medium")

                    if not org_id:
                        continue

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name
                    org_records[org_id][date_label][severity] += 1

                for org_id, date_dict in org_records.items():
                    formatted_records = [
                        {"date": date_key, "severity_counts": counts}
                        for date_key, counts in date_dict.items()
                    ]
                    response["data"]["data"]["1_day"].append({
                        "organization_id": org_id,
                        "records": serialize_data(formatted_records)
                    })

            # Remove 1_day bucket from further processing
            time_buckets = [b for b in time_buckets if b["label"] != "1_day"]
        # ---------- END INLINE 1_day handling ----------

        # Main loop for remaining buckets
        for bucket in time_buckets:
            start, end, label = bucket["start"], bucket["end"], bucket["label"]
            intervals = generate_intervals_for_label(label, start, end)

            for interval_start in intervals:
                # Determine interval_end
                if label == "5_day":
                    interval_end = interval_start + timedelta(days=1) - timedelta(seconds=1)
                elif label in ["1_month", "3_month", "6_month", "1_year"]:
                    y, m = interval_start.year, interval_start.month
                    days_in_month = monthrange(y, m)[1]
                    cutoffs = [1, 8, 15, 22, days_in_month + 1]
                    start_day = interval_start.day
                    if start_day in cutoffs:
                        idx = cutoffs.index(start_day)
                        end_day = cutoffs[idx + 1] - 1
                        interval_end = date(y, m, end_day)
                    else:
                        interval_end = interval_start + timedelta(days=6)
                elif label == "5_years":
                    interval_end = date(interval_start.year + 1, 1, 1) - timedelta(seconds=1)
                elif label == "max":
                    start_year = df_all["created_date"].min().year
                    end_year = df_all["created_date"].max().year

                    for year in range(start_year, end_year + 1):
                        year_start = date(year, 1, 1)
                        year_end = date(year, 12, 31)

                        if start_date and year_start < start_date:
                            year_start = start_date
                        if end_date and year_end > end_date:
                            year_end = end_date

                        df_filtered = df_all[
                            (df_all["created_date"] >= year_start) &
                            (df_all["created_date"] <= year_end)
                        ].copy()

                        if df_filtered.empty:
                            continue

                        if label in ["5_years", "max"]:
                            df_filtered["date"] = df_filtered["created_date"].apply(lambda x: str(x.year))
                        elif label == "1_day":
                            df_filtered["date"] = interval_end.strftime("%Y-%m-%d %H:%M:%S")
                        else:
                            df_filtered["date"] = interval_end.strftime("%Y-%m-%d")
                        df_filtered["priority"] = df_filtered["priority"].fillna("").astype(str).str.lower()
                        df_filtered["severity"] = df_filtered["priority"].map(severity_map).fillna("Medium")

                        org_records = defaultdict(lambda: defaultdict(lambda: {"Low": 0, "Medium": 0, "High": 0}))
                        for _, row in df_filtered.iterrows():
                            org_id = row["organization_id"]
                            org_name = row.get("organization_name", "Unknown Organization")
                            date_val = row["date"]
                            severity = row["severity"]

                            collected_org_ids.add(org_id)
                            org_id_to_name[org_id] = org_name
                            org_records[org_id][date_val][severity] += 1

                        for org_id, date_dict in org_records.items():
                            formatted_records = [
                                {"date": date_key, "severity_counts": counts}
                                for date_key, counts in date_dict.items()
                            ]
                            response["data"]["data"][label].append({
                                "organization_id": org_id,
                                "records": serialize_data(formatted_records)
                            })

                else:
                    interval_end = end

                start_dt = interval_start.date() if isinstance(interval_start, datetime) else interval_start
                end_dt = interval_end.date() if isinstance(interval_end, datetime) else interval_end

                df_filtered = df_all[
                    (df_all["created_date"] >= start_dt) &
                    (df_all["created_date"] <= end_dt)
                ].copy()

                if df_filtered.empty:
                    continue

                df_filtered["priority"] = df_filtered["priority"].fillna("").astype(str).str.lower()
                df_filtered["severity"] = df_filtered["priority"].map(severity_map).fillna("Medium")

                # ✅ For month-based labels, set the date to the week cutoff date
                if label in ["1_month", "3_month", "6_month", "1_year"]:
                    y, m = interval_start.year, interval_start.month
                    days_in_month = monthrange(y, m)[1]
                    cutoffs = [7, 14, 21, days_in_month]
                    start_day = interval_start.day
                    end_day = next((c for c in cutoffs if start_day <= c), days_in_month)
                    df_filtered["date"] = date(y, m, end_day).strftime("%Y-%m-%d")
                elif label in ["5_years", "max"]:
                    df_filtered["date"] = df_filtered["created_date"].apply(lambda x: str(x.year))
                elif label == "1_day":
                    # this branch won't run because we handled 1_day above
                    df_filtered["date"] = interval_end.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    df_filtered["date"] = interval_end.strftime("%Y-%m-%d")

                org_records = defaultdict(lambda: defaultdict(lambda: {"Low": 0, "Medium": 0, "High": 0}))
                for _, row in df_filtered.iterrows():
                    org_id = row["organization_id"]
                    org_name = row.get("organization_name", "Unknown Organization")
                    date_val = row["date"]
                    severity = row["severity"]

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name
                    org_records[org_id][date_val][severity] += 1

                for org_id, date_dict in org_records.items():
                    formatted_records = [
                        {"date": date_key, "severity_counts": counts}
                        for date_key, counts in date_dict.items()
                    ]
                    response["data"]["data"][label].append({
                        "organization_id": org_id,
                        "records": serialize_data(formatted_records)
                    })

        if collected_org_ids:
            response["meta"]["organization_names"] = {
                str(org_id): org_id_to_name.get(org_id, "Unknown Organization") for org_id in collected_org_ids
            }
            response["flag"] = True

    except Exception as exception:
        logging.exception("[get_ticket_severity_overview]")
        response["message"] = f"Error fetching ticket severity overview: {exception}"
        response["flag"] = False
        try:
            error_data = {
                "service_name": "get_ticket_severity_overview",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'database' in locals():
                database.log_error_to_db(error_data, "error_log_table")
        except Exception:
            pass

    return response


def get_ticket_category_distribution(data):
    """
    Returns ticket category distribution for an organization across multiple time buckets
    using mapped Zendesk tags, with Redis caching.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.      
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): return ticket count based on category .
            - 'message' (str): Error message if applicable.
    """
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    start_date_str = data.get("start_date", "")
    end_date_str = data.get("end_date", "")
    organization_id = data.get("tenant_id", "")
    refresh = str(data.get("refresh", "false")).lower() == "true"

    response = {
        "flag": False,
        "meta": {
            "organization_names": {},
            "default_time_range": ""
        },
        "data": {
            "title": "Ticket Category Distribution",
            "chart_type": "Heatmap",
            "xField": "",
            "yField": "",
            "smooth": False,
            "height": 300,
            "width": 500,
            "data": {
                "1_day": [], "5_day": [], "1_month": [], "3_month": [], "6_month": [],
                "1_year": [], "5_years": [], "max": [],
                "custom_range": []
            }
        },
        "message": ""
    }

    CATEGORY_MAPPING = {
        "Inventory": ["inventory"],
        "Bulk Change": ["bulkchange"],
        "Customer Rate Plans": ["customerrateplan", "customerrateplans"],
        "Optimisation": ["optimisation", "optimization"],
        "Reports": ["report", "reports"],
        "Revenue Assurance": ["revenueassurance"],
        "Billing Platform" : ["billingplatform"]
    }
    NORMALIZED_TAG_TO_CATEGORY = {
        normalize(tag): cat
        for cat, tag_list in CATEGORY_MAPPING.items()
        for tag in tag_list
    }

    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date() if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date() if end_date_str else None

        function = "get_ticket_category_distribution"
        cache_key = get_cache_key("zendesk_tickets_tracking", function)
        cached_data = None

        if not refresh:
            try:
                cached = redis_client.get(cache_key)
                if cached:
                    cached_data = json.loads(cached)
                    logging.info(f"[Cache Hit] {cache_key}")
            except Exception as e:
                logging.warning(f"[Redis Get Error] {e}")

        if refresh or cached_data is None:
            raw_query = """
                SELECT 
                    organization_id,
                    organization_name,
                    created_date,
                    tag
                FROM zendesk_tickets_tracking
                WHERE created_date IS NOT NULL
            """
            df = database.execute_query(raw_query, flag=True)
            df = df if isinstance(df, pd.DataFrame) else pd.DataFrame()

            if not df.empty:
                cached_data = df.to_dict(orient="records")
                try:
                    redis_client.setex(cache_key, 7200, json.dumps(cached_data, default=str))
                    redis_client.set(f"{cache_key}:timestamp", datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
                except Exception as e:
                    logging.warning(f"[Redis Set Error] {e}")

                new_sync_time = datetime.now()
                try:
                    audit_data = {
                        "function_name": function,
                        "created_by": username,
                        "last_synced_by": username,
                    }
                    database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")
            else:
                cached_data = []

        df_all = pd.DataFrame(cached_data)
        if df_all.empty:
            return response

        # Keep both timestamp and date so 1_day can use full timestamp
        df_all["created_datetime"] = pd.to_datetime(df_all["created_date"], utc=True)
        df_all["created_date"] = df_all["created_datetime"].dt.date

        logging.info("Requested range: %s to %s", start_date, end_date)
        logging.info("Available range: %s to %s", df_all["created_date"].min(), df_all["created_date"].max())

        if organization_id and organization_id != "All":
            df_all = df_all[df_all["organization_id"] == str(organization_id)]

        if start_date and end_date:
            df_all = df_all[
                (df_all["created_date"] >= start_date) &
                (df_all["created_date"] <= end_date)
            ]
            if df_all.empty:
                response["message"] = "No data available for the selected date range."
                response["flag"] = True   # mark as success
                return response

        min_date = df_all["created_date"].min() if not (start_date and end_date) else None
        time_buckets, default_label = execute_all_time_buckets(start_date, end_date, min_date, column="created_date")
        response["meta"]["default_time_range"] = default_label

        collected_org_ids = set()
        org_id_to_name = {}

        for bucket in time_buckets:
            start, end, label = bucket["start"], bucket["end"], bucket["label"]
            # generate_intervals_for_label is still used for non-1_day labels
            if label == "1_day":
                # ---------------------------
                # Option 2 logic: explicit 4-hour bucket edges using pd.date_range
                # ---------------------------
                # Build timezone-aware interval range for this bucket.
                # Start at start date 00:00:00 and end at end date 23:59:59 to cover full day(s)
                bucket_start_dt = datetime.combine(start, datetime.min.time())
                bucket_end_dt = datetime.combine(end, datetime.max.time())

                # Make tz-aware to match created_datetime (which we set with utc=True)
                # created_datetime is tz-aware (UTC)
                bucket_start_ts = pd.Timestamp(bucket_start_dt).tz_localize("UTC")
                bucket_end_ts = pd.Timestamp(bucket_end_dt).tz_localize("UTC")

                # Floor the start to nearest 4H boundary and ceil the end to nearest 4H boundary
                # We compute a starting edge aligned with 4-hour boundaries
                floored_start = pd.Timestamp(bucket_start_ts).floor("4H")
                ceiled_end = pd.Timestamp(bucket_end_ts).ceil("4H")

                # Generate edges every 4 hours
                edges = pd.date_range(start=floored_start, end=ceiled_end, freq="4h", tz="UTC")

                # Iterate over consecutive pairs of edges to form intervals
                # edges: e0, e1, e2,...; intervals are [e0, e1-1s], [e1, e2-1s], ...
                for i in range(len(edges) - 1):
                    interval_start_ts = edges[i]
                    interval_end_ts = edges[i + 1] - pd.Timedelta(seconds=1)

                    # Filter rows for this 4-hour window using created_datetime (tz-aware)
                    df_filtered = df_all[
                        (df_all["created_datetime"] >= interval_start_ts) &
                        (df_all["created_datetime"] <= interval_end_ts)
                    ].copy()

                    if df_filtered.empty:
                        continue

                    # Build counts per org for this interval
                    org_records = defaultdict(lambda: defaultdict(lambda: {
                        "Inventory": 0,
                        "Bulk Change": 0,
                        "Customer Rate Plans": 0,
                        "Optimisation": 0,
                        "Reports": 0,
                        "Revenue Assurance": 0,
                        "Uncategorized": 0,
                        "Billing Platform": 0
                    }))

                    for _, row in df_filtered.iterrows():
                        org_id = row["organization_id"]
                        org_name = row.get("organization_name", "Unknown Organization")
                        tag_string = row.get("tag", "")

                        if not org_id:
                            continue

                        collected_org_ids.add(org_id)
                        org_id_to_name[org_id] = org_name

                        tags = [t.strip() for t in (tag_string or "").split(',') if t]
                        normalized_tags = [normalize(t) for t in tags]

                        matched = False
                        for norm_tag in normalized_tags:
                            if norm_tag in NORMALIZED_TAG_TO_CATEGORY:
                                cat = NORMALIZED_TAG_TO_CATEGORY[norm_tag]
                                org_records[org_id][str(interval_end_ts)][cat] += 1
                                matched = True
                                break

                        if not matched:
                            org_records[org_id][str(interval_end_ts)]["Uncategorized"] += 1

                    # Append results for each org for this interval
                    for org_id, date_dict in org_records.items():
                        formatted_records = [
                            {"date": date_key, "category_counts": counts}
                            for date_key, counts in date_dict.items()
                        ]
                        response["data"]["data"][label].append({
                            "organization_id": org_id,
                            "records": serialize_data(formatted_records)
                        })

                # Done with 1_day; continue to next bucket
                continue

            # For non-1_day labels use original interval generation
            intervals = generate_intervals_for_label(label, start, end)

            for interval_start in intervals:
                # Determine interval_end
                if label == "5_day":
                    interval_end = interval_start + timedelta(days=1) - timedelta(seconds=1)
                elif label in ["1_month", "3_month", "6_month", "1_year"]:
                    y, m = interval_start.year, interval_start.month
                    days_in_month = monthrange(y, m)[1]
                    cutoffs = [1, 8, 15, 22, days_in_month + 1]
                    start_day = interval_start.day
                    if start_day in cutoffs:
                        idx = cutoffs.index(start_day)
                        end_day = cutoffs[idx + 1] - 1
                        interval_end = date(y, m, end_day)
                    else:
                        interval_end = interval_start + timedelta(days=6)
                elif label == "5_years":
                    interval_end = date(interval_start.year + 1, 1, 1) - timedelta(seconds=1)
                elif label == "max":
                    # Year-wise intervals from min to max date
                    start_year = df_all["created_date"].min().year
                    end_year = df_all["created_date"].max().year

                    for year in range(start_year, end_year + 1):
                        year_start = date(year, 1, 1)
                        year_end = date(year, 12, 31)

                        # Clip by actual start/end dates if outside selected range
                        if start_date and year_start < start_date:
                            year_start = start_date
                        if end_date and year_end > end_date:
                            year_end = end_date

                        df_filtered = df_all[
                            (df_all["created_date"] >= year_start) &
                            (df_all["created_date"] <= year_end)
                        ].copy()

                        if df_filtered.empty:
                            continue

                        # Assign interval end as date for all rows
                        if label in ["5_years", "max"]:
                            df_filtered["date"] = df_filtered["created_date"].apply(lambda x: str(x.year))
                        elif label == "1_day":
                            df_filtered["date"] = interval_end.strftime("%Y-%m-%d %H:%M:%S")
                        else:
                            df_filtered["date"] = interval_end.strftime("%Y-%m-%d")

                        org_records = defaultdict(lambda: defaultdict(lambda: {
                            "Inventory": 0,
                            "Bulk Change": 0,
                            "Customer Rate Plans": 0,
                            "Optimisation": 0,
                            "Reports": 0,
                            "Revenue Assurance": 0,
                            "Uncategorized": 0,
                            "Billing Platform": 0
                        }))

                        for _, row in df_filtered.iterrows():
                            org_id = row["organization_id"]
                            org_name = row.get("organization_name", "Unknown Organization")
                            tag_string = row.get("tag", "")
                            date_val = row["date"]

                            if not org_id:
                                continue

                            collected_org_ids.add(org_id)
                            org_id_to_name[org_id] = org_name

                            tags = [t.strip() for t in tag_string.split(',') if t]
                            normalized_tags = [normalize(t) for t in tags]

                            matched = False
                            for norm_tag in normalized_tags:
                                if norm_tag in NORMALIZED_TAG_TO_CATEGORY:
                                    cat = NORMALIZED_TAG_TO_CATEGORY[norm_tag]
                                    org_records[org_id][date_val][cat] += 1
                                    matched = True
                                    break

                            if not matched:
                                org_records[org_id][date_val]["Uncategorized"] += 1

                        for org_id, date_dict in org_records.items():
                            formatted_records = [
                                {"date": date_key, "category_counts": counts}
                                for date_key, counts in date_dict.items()
                            ]
                            response["data"]["data"][label].append({
                                "organization_id": org_id,
                                "records": serialize_data(formatted_records)
                            })

                    # Skip general interval processing for "max"
                    continue  # ensures "max" is processed only in this block

                else:
                    interval_end = end

                start_dt = interval_start.date() if isinstance(interval_start, datetime) else interval_start
                end_dt = interval_end.date() if isinstance(interval_end, datetime) else interval_end

                df_filtered = df_all[
                    (df_all["created_date"] >= start_dt) &
                    (df_all["created_date"] <= end_dt)
                ].copy()

                if df_filtered.empty:
                    continue

                if label in ["5_years", "max"]:
                    df_filtered["date"] = df_filtered["created_date"].apply(lambda x: str(x.year))
                elif label == "1_day":
                    # this branch won't run because we handled 1_day above
                    df_filtered["date"] = interval_end.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    df_filtered["date"] = interval_end.strftime("%Y-%m-%d")

                org_records = defaultdict(lambda: defaultdict(lambda: {
                    "Inventory": 0,
                    "Bulk Change": 0,
                    "Customer Rate Plans": 0,
                    "Optimisation": 0,
                    "Reports": 0,
                    "Revenue Assurance": 0,
                    "Uncategorized": 0,
                    "Billing Platform": 0
                }))

                for _, row in df_filtered.iterrows():
                    org_id = row["organization_id"]
                    org_name = row.get("organization_name", "Unknown Organization")
                    tag_string = row.get("tag", "")
                    date_val = row.get("date", "")

                    if not org_id:
                        continue

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name

                    tags = [t.strip() for t in tag_string.split(',') if t]
                    normalized_tags = [normalize(t) for t in tags]

                    matched = False
                    for norm_tag in normalized_tags:
                        if norm_tag in NORMALIZED_TAG_TO_CATEGORY:
                            cat = NORMALIZED_TAG_TO_CATEGORY[norm_tag]
                            org_records[org_id][date_val][cat] += 1
                            matched = True
                            break

                    if not matched:
                        org_records[org_id][date_val]["Uncategorized"] += 1

                for org_id, date_dict in org_records.items():
                    formatted_records = [
                        {"date": date_key, "category_counts": counts}
                        for date_key, counts in date_dict.items()
                    ]
                    response["data"]["data"][label].append({
                        "organization_id": org_id,
                        "records": serialize_data(formatted_records)
                    })

        if collected_org_ids:
            response["meta"]["organization_names"] = {
                str(org_id): org_id_to_name.get(org_id, "Unknown Organization") for org_id in collected_org_ids
            }
            response["flag"] = True

    except Exception as exception:
        logging.exception(f"[get_ticket_category_distribution] : {exception}")
        response["message"] = f"Error fetching ticket category distribution: {exception}"
        response["flag"] = False
        try:
            error_data = {
                "service_name": "get_ticket_category_distribution",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'database' in locals():
                database.log_error_to_db(error_data, "error_log_table")
        except Exception:
            pass

    return response


def get_ticket_compilance_by_module(data):
    """
    Ticket Compliance by Module

    - Category comes from mapped Zendesk tags (only tags in CATEGORY_MAPPING).
    - If no tag matches CATEGORY_MAPPING, bucket into **Uncategorized** and still count status & ETA.
    - For every Category -> Subcategory -> updated_date, count ticket_status in (open, close, progress).
      "progress" aggregates synonymous statuses like "inprogress".
    - ETA buckets for active statuses only (open, inprogress, new) comparing due_at vs current date:
        * before_eta : due_at < today
        * eta        : due_at = today
        * after_eta  : due_at > today
    - Remaining logic mirrors the example function (cache, buckets, org meta, error logging).
    """

    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    start_date_str = data.get("start_date", "")
    end_date_str = data.get("end_date", "")
    organization_id = data.get("tenant_id", "")
    refresh = str(data.get("refresh", "false")).lower() == "true"

    response = {
        "flag": False,
        "meta": {
            "organization_names": {},
            "default_time_range": "",
            "last_sync_time": ""
        },
        "data": {
            "title": "Ticket Compliance by Module",
            "chart_type": "",
            "xField": "",
            "yField": [],
            "smooth": True,
            "height": 300,
            "width": 500,
            "data": {
                "1_day": [], "5_day": [], "1_month": [], "3_month": [], "6_month": [],
                "1_year": [], "5_years": [], "max": [], "custom_range": []
            }
        },
        "message": ""
    }

    CATEGORY_MAPPING = {
        "Inventory": ["inventory"],
        "Bulk Change": ["bulkchange"],
        "Customer Rate Plans": ["customerrateplan", "customerrateplans"],
        "Optimisation": ["optimisation", "optimization"],
        "Reports": ["report", "reports"],
        "Revenue Assurance": ["revenueassurance"],
    }
    NORMALIZED_TAG_TO_CATEGORY = {
        normalize(tag): cat
        for cat, tag_list in CATEGORY_MAPPING.items()
        for tag in tag_list
    }

    def make_counts():
        return {"open": 0, "close": 0, "progress": 0,
                "before_eta": 0, "eta": 0, "after_eta": 0}

    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date() if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date() if end_date_str else None

        function = "get_ticket_compilance_by_module"
        cache_key = get_cache_key("zendesk_tickets_tracking", function)
        cached_data = None

        # Read from cache
        if not refresh:
            try:
                cached = redis_client.get(cache_key)
                if cached:
                    cached_data = json.loads(cached)
                    ts = redis_client.get(f"{cache_key}:timestamp")
                    if ts:
                        response["meta"]["last_sync_time"] = ts.decode() if hasattr(ts, "decode") else str(ts)
                    logging.info(f"[Cache Hit] {cache_key}")
            except Exception as e:
                logging.warning(f"[Redis Get Error] {e}")

        # Fetch from DB if no cache or refresh requested
        if refresh or cached_data is None:
            raw_query = """
                SELECT 
                    organization_id,
                    organization_name,
                    updated_date,
                    tag,
                    subcategory,
                    ticket_status,
                    due_at
                FROM zendesk_tickets_tracking
                WHERE updated_date IS NOT NULL
            """
            df = database.execute_query(raw_query, flag=True)
            df = df if isinstance(df, pd.DataFrame) else pd.DataFrame()

            if not df.empty:
                # ✅ Keep full datetime (tz-aware) & also store date-only for other buckets
                df["updated_datetime"] = pd.to_datetime(df["updated_date"], errors="coerce", utc=True)
                df["updated_date"] = df["updated_datetime"].dt.date

                if "due_at" in df.columns:
                    # due_at comparisons are date-based, so keep as date
                    df["due_at"] = pd.to_datetime(df["due_at"], errors="coerce").dt.date
                else:
                    df["due_at"] = pd.NaT

                cached_data = df.to_dict(orient="records")
                try:
                    redis_client.setex(cache_key, 7200, json.dumps(cached_data, default=str))
                    ts_now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
                    redis_client.set(f"{cache_key}:timestamp", ts_now)
                    response["meta"]["last_sync_time"] = ts_now
                except Exception as e:
                    logging.warning(f"[Redis Set Error] {e}")

                # Audit cache refresh
                try:
                    audit_data = {
                        "function_name": function,
                        "created_by": username,
                        "last_synced_by": username,
                    }
                    database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")
            else:
                cached_data = []

        # Build DF from cache/DB
        df_all = pd.DataFrame(cached_data)
        if df_all.empty:
            return response

        # Ensure we have a tz-aware datetime column and a date-only column
        if "updated_datetime" in df_all.columns:
            # If stored as strings, convert to tz-aware Timestamps
            try:
                df_all["updated_datetime"] = pd.to_datetime(df_all["updated_datetime"], utc=True)
            except Exception:
                df_all["updated_datetime"] = pd.to_datetime(df_all["updated_datetime"], errors="coerce", utc=True)
        else:
            df_all["updated_datetime"] = pd.to_datetime(df_all.get("updated_date", None), errors="coerce", utc=True)

        # Date-only column for other buckets (safe even if updated_datetime missing time)
        df_all["updated_date"] = df_all["updated_datetime"].dt.date

        # Ensure due_at is date-like
        if "due_at" in df_all.columns:
            try:
                df_all["due_at"] = pd.to_datetime(df_all["due_at"], errors="coerce").dt.date
            except Exception:
                pass
        else:
            df_all["due_at"] = pd.NaT

        logging.info("Requested range:", start_date, "to", end_date)
        logging.info("Available range:", df_all["updated_date"].min(), "to", df_all["updated_date"].max())

        # Organization filter
        if organization_id and organization_id != "All":
            df_all = df_all[df_all["organization_id"] == str(organization_id)]

        # Date filter (date-only)
        if start_date and end_date:
            df_all = df_all[
                (df_all["updated_date"] >= start_date) &
                (df_all["updated_date"] <= end_date)
            ]
            if df_all.empty:
                response["message"] = "No data available for the selected date range."
                response["flag"] = True
                return response

        # Compute buckets
        min_date = df_all["updated_date"].min() if not (start_date and end_date) else None
        time_buckets, default_label = execute_all_time_buckets(start_date, end_date, min_date, column="updated_date")
        response["meta"]["default_time_range"] = default_label

        collected_org_ids = set()
        org_id_to_name = {}
        today = datetime.utcnow().date()

        # Helper: normalize status labels to our buckets
        def normalize_status(s: str) -> str:
            s = (s or "").strip().lower()
            if s in {"closed", "close", "solved", "resolved"}:
                return "close"
            if s in {"inprogress", "in_progress", "in progress", "pending"}:
                return "progress"  # aggregate progress-like states
            if s in {"open", "new"}:
                return "open"
            return s

        # ---------- INLINE 1_day handling using explicit pd.date_range 4-hour edges ----------
        if any(b["label"] == "1_day" for b in time_buckets):
            bucket = next(b for b in time_buckets if b["label"] == "1_day")
            b_start = bucket["start"]
            b_end = bucket["end"]

            # Build timezone-aware timestamps in UTC (to match updated_datetime)
            bucket_start_dt = datetime.combine(b_start, datetime.min.time())
            bucket_end_dt = datetime.combine(b_end, datetime.max.time())

            bucket_start_ts = pd.Timestamp(bucket_start_dt).tz_localize("UTC")
            bucket_end_ts = pd.Timestamp(bucket_end_dt).tz_localize("UTC")

            floored_start = bucket_start_ts.floor("4H")
            ceiled_end = bucket_end_ts.ceil("4H")

            edges = pd.date_range(start=floored_start, end=ceiled_end, freq="4h", tz="UTC")

            for i in range(len(edges) - 1):
                interval_start_ts = edges[i]
                interval_end_ts = edges[i + 1] - pd.Timedelta(seconds=1)

                # Filter rows for this 4-hour window using tz-aware updated_datetime
                df_filtered = df_all[
                    (df_all["updated_datetime"] >= interval_start_ts) &
                    (df_all["updated_datetime"] <= interval_end_ts)
                ].copy()

                if df_filtered.empty:
                    continue

                org_records = defaultdict(
                    lambda: defaultdict(
                        lambda: defaultdict(
                            lambda: defaultdict(make_counts)
                        )
                    )
                )

                for _, row in df_filtered.iterrows():
                    org_id = row.get("organization_id")
                    if not org_id:
                        continue

                    org_name = row.get("organization_name", "Unknown Organization")
                    tag_string = row.get("tag", "")
                    subcategory = row.get("subcategory", "Unknown Subcategory") or "Unknown Subcategory"
                    status_raw = str(row.get("ticket_status", ""))
                    due_date = row.get("due_at", None)
                    # Use the interval_end as date_key (string), consistent with your other 1_day presentation
                    date_key = str(interval_end_ts)

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name

                    # Category mapping
                    cat = None
                    tags = [t.strip() for t in str(tag_string).split(',') if t]
                    for t in tags:
                        nt = normalize(t)
                        if nt in NORMALIZED_TAG_TO_CATEGORY:
                            cat = NORMALIZED_TAG_TO_CATEGORY[nt]
                            break
                    if not cat:
                        cat = "Uncategorized"

                    status = normalize_status(status_raw)
                    counts = org_records[org_id][cat][subcategory][date_key]

                    if status in {"open", "close", "progress"}:
                        counts[status] += 1

                    # ETA logic for active statuses
                    if status_raw.strip().lower() in {"open", "inprogress", "in_progress", "in progress", "new"} and pd.notna(due_date):
                        try:
                            # due_date is already a date (we parsed earlier)
                            due = due_date if isinstance(due_date, date) else (due_date.date() if isinstance(due_date, pd.Timestamp) else None)
                            if due and isinstance(due, date):
                                if due < today:
                                    counts["before_eta"] += 1
                                elif due == today:
                                    counts["eta"] += 1
                                else:
                                    counts["after_eta"] += 1
                        except Exception:
                            pass

                # Append per-org records for this interval
                for org_id, rec in org_records.items():
                    response["data"]["data"]["1_day"].append({
                        "organization_id": org_id,
                        "records": rec
                    })

            # Remove 1_day bucket from further processing
            time_buckets = [b for b in time_buckets if b["label"] != "1_day"]
        # ---------- END INLINE 1_day handling ----------

        # Core processing per bucket (remaining labels)
        for bucket in time_buckets:
            start, end, label = bucket["start"], bucket["end"], bucket["label"]

            # Special processing for MAX -> per-year rollups
            if label == "max":
                start_year = df_all["updated_date"].min().year
                end_year = df_all["updated_date"].max().year

                for year in range(start_year, end_year + 1):
                    year_start = date(year, 1, 1)
                    year_end = date(year, 12, 31)

                    if start_date and year_start < start_date:
                        year_start = start_date
                    if end_date and year_end > end_date:
                        year_end = end_date

                    df_filtered = df_all[
                        (df_all["updated_date"] >= year_start) &
                        (df_all["updated_date"] <= year_end)
                    ].copy()

                    if df_filtered.empty:
                        continue

                    df_filtered["date"] = str(year_end.year)

                    org_records = defaultdict(
                        lambda: defaultdict(
                            lambda: defaultdict(
                                lambda: defaultdict(make_counts)
                            )
                        )
                    )

                    for _, row in df_filtered.iterrows():
                        org_id = row.get("organization_id")
                        if not org_id:
                            continue

                        org_name = row.get("organization_name", "Unknown Organization")
                        tag_string = row.get("tag", "")
                        subcategory = row.get("subcategory", "Unknown Subcategory") or "Unknown Subcategory"
                        status_raw = str(row.get("ticket_status", ""))
                        due_date = row.get("due_at", None)
                        date_key = row.get("date", "")

                        collected_org_ids.add(org_id)
                        org_id_to_name[org_id] = org_name

                        # Category mapping
                        cat = None
                        tags = [t.strip() for t in str(tag_string).split(',') if t]
                        for t in tags:
                            nt = normalize(t)
                            if nt in NORMALIZED_TAG_TO_CATEGORY:
                                cat = NORMALIZED_TAG_TO_CATEGORY[nt]
                                break
                        if not cat:
                            cat = "Uncategorized"

                        status = normalize_status(status_raw)
                        counts = org_records[org_id][cat][subcategory][date_key]

                        if status in {"open", "close", "progress"}:
                            counts[status] += 1

                        if status_raw.strip().lower() in {"open", "inprogress", "in_progress", "in progress", "new"} and pd.notna(due_date):
                            try:
                                due = due_date if isinstance(due_date, date) else (due_date.date() if isinstance(due_date, pd.Timestamp) else None)
                                if due and isinstance(due, date):
                                    if due < today:
                                        counts["before_eta"] += 1
                                    elif due == today:
                                        counts["eta"] += 1
                                    else:
                                        counts["after_eta"] += 1
                            except Exception:
                                pass

                    for org_id, rec in org_records.items():
                        response["data"]["data"][label].append({
                            "organization_id": org_id,
                            "records": rec
                        })
                continue

            # Build intervals for non-MAX
            intervals = generate_intervals_for_label(label, start, end)

            for interval_start in intervals:
                if label == "5_day":
                    interval_end = interval_start + timedelta(days=1) - timedelta(seconds=1)
                elif label in ["1_month", "3_month", "6_month", "1_year"]:
                    y, m = interval_start.year, interval_start.month
                    days_in_month = monthrange(y, m)[1]
                    cutoffs = [1, 8, 15, 22, days_in_month + 1]
                    start_day = interval_start.day
                    if start_day in cutoffs:
                        idx = cutoffs.index(start_day)
                        end_day = cutoffs[idx + 1] - 1
                        interval_end = date(y, m, end_day)
                    else:
                        interval_end = interval_start + timedelta(days=6)
                elif label == "5_years":
                    interval_end = date(interval_start.year + 1, 1, 1) - timedelta(seconds=1)
                else:
                    interval_end = end

                start_dt = interval_start.date() if isinstance(interval_start, datetime) else interval_start
                end_dt = interval_end.date() if isinstance(interval_end, datetime) else interval_end

                df_filtered = df_all[
                    (df_all["updated_date"] >= start_dt) &
                    (df_all["updated_date"] <= end_dt)
                ].copy()

                if df_filtered.empty:
                    continue

                if label == "5_years":
                    df_filtered["date"] = str(end_dt.year)
                else:
                    df_filtered["date"] = df_filtered["updated_date"].astype(str)

                org_records = defaultdict(
                    lambda: defaultdict(
                        lambda: defaultdict(
                            lambda: defaultdict(make_counts)
                        )
                    )
                )

                for _, row in df_filtered.iterrows():
                    org_id = row.get("organization_id")
                    if not org_id:
                        continue

                    org_name = row.get("organization_name", "Unknown Organization")
                    tag_string = row.get("tag", "")
                    subcategory = row.get("subcategory", "Unknown Subcategory") or "Unknown Subcategory"
                    status_raw = str(row.get("ticket_status", ""))
                    due_date = row.get("due_at", None)
                    date_key = row.get("date", "")

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name

                    cat = None
                    tags = [t.strip() for t in str(tag_string).split(',') if t]
                    for t in tags:
                        nt = normalize(t)
                        if nt in NORMALIZED_TAG_TO_CATEGORY:
                            cat = NORMALIZED_TAG_TO_CATEGORY[nt]
                            break
                    if not cat:
                        cat = "Uncategorized"

                    status = normalize_status(status_raw)
                    counts = org_records[org_id][cat][subcategory][date_key]

                    if status in {"open", "close", "progress"}:
                        counts[status] += 1

                    if status_raw.strip().lower() in {"open", "inprogress", "in_progress", "in progress", "new"} and pd.notna(due_date):
                        try:
                            due = due_date if isinstance(due_date, date) else (due_date.date() if isinstance(due_date, pd.Timestamp) else None)
                            if due and isinstance(due, date):
                                if due < today:
                                    counts["before_eta"] += 1
                                elif due == today:
                                    counts["eta"] += 1
                                else:
                                    counts["after_eta"] += 1
                        except Exception:
                            pass

                for org_id, rec in org_records.items():
                    response["data"]["data"][label].append({
                        "organization_id": org_id,
                        "records": rec
                    })

        if collected_org_ids:
            response["meta"]["organization_names"] = {
                str(org_id): org_id_to_name.get(org_id, "Unknown Organization") for org_id in collected_org_ids
            }
            response["flag"] = True

    except Exception as exception:
        logging.exception("[get_ticket_compilance_by_module]")
        response["message"] = f"Error fetching ticket compliance by module: {exception}"
        response["flag"] = False
        try:
            error_data = {
                "service_name": "get_ticket_compilance_by_module",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'database' in locals():
                database.log_error_to_db(error_data, "error_log_table")
        except Exception:
            pass

    return response



########################## zendesk Tab ####################

############ Cache Ui Refresh #############
 
def refresh_dashboard_all_caches(data):
    """
    Triggers cache refresh for different sets of functions based on tab_name:
    - sim_overiew
    - revenue_metrics
    - zendesk
    """

    tenant_name = data.get("tenant_name", "")
    tenant_id = data.get("tenant_id", "All")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    tab_name = data.get("tab_name", "").lower().strip()
    request_received_at = data.get("request_received_at", "")
    response = {
        "flag": True,
        "message": f"Cache refresh initiated for {tab_name or 'all'} functions",
        "results": {},
        "meta": {
            "tenant_name": tenant_name,
            "tenant_id": tenant_id,
            "tab_name": tab_name,
            "request_received_at": str(request_received_at)
        }
    }

    # Mapping of tab_name to its respective functions
    tab_functions_map = {
        "sim_overiew": [
            ("get_service_provider_vs_status", get_service_provider_vs_status),
            ("get_sim_activations_by_service_provider", get_sim_activations_by_service_provider),
            ("get_sim_count_by_service_provider", get_sim_count_by_service_provider),
            ("count_of_sim_overview", count_of_sim_overview)
        ],
        "revenue_metrics": [
            ("get_revenue_metrics_cards", get_revenue_metrics_cards),
            ("get_revenue_by_carrier", get_revenue_by_carrier),
            ("get_revenue_by_rate_plan", get_revenue_by_rate_plan),
            ("get_profit_margin_trend", get_profit_margin_trend),
            ("get_revenue_by_usage_trend", get_revenue_by_usage_trend)
        ],
        "zendesk": [
            ("get_status_count_of_tickets", get_status_count_of_tickets),
            ("get_ticket_status_distribution", get_ticket_status_distribution),
            ("get_ticket_category_distribution", get_ticket_category_distribution),
            ("get_ticket_severity_overview", get_ticket_severity_overview),
            ("get_ticket_compilance_by_module", get_ticket_compilance_by_module)
        ]
    }

    if tab_name not in tab_functions_map:
        response["flag"] = False
        response["message"] = f"Invalid tab_name: {tab_name}"
        return response

    functions_to_refresh = tab_functions_map[tab_name]

    try:
        common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **db_config)
    except Exception as db_exc:
        logging.exception(f"Failed to connect to common_utils_database in refresh_all_caches : {db_exc}")
        response["flag"] = False
        response["message"] = f"Database connection error: {db_exc}"
        return response

    for function_name, function in functions_to_refresh:
        try:
            data_with_refresh = data.copy()
            data_with_refresh["refresh"] = "True"

            result = function(data_with_refresh)

            # always use refresh_{tab_name}_caches for dashboard_cache_audit
            cache_func_name = f"refresh_{tab_name}_caches"

            if result.get("flag", False):
                last_sync_time = datetime.utcnow()
                response["results"][function_name] = {
                    "status": "Success",
                    "last_sync_date": last_sync_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "message": f"Cache refreshed successfully for {function_name}"
                }

                
                try:
                    audit_data = {
                        "function_name": cache_func_name,
                        "created_by": username,
                        "last_synced_by": username,
                    }
                    common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Dashboard cache audit insert failed for {function_name}: {audit_exc}")

            else:
                response["results"][function_name] = {
                    "status": "Failed",
                    "last_sync_date": None,
                    "message": result.get("message", f"Failed to refresh cache for {function_name}")
                }
                response["flag"] = False
                response["message"] = "One or more cache refreshes failed"

                
                    

            # Audit logging — user actions (separate table)
            try:
                audit_data = {
                    "service_name": f"refresh_{tab_name}_caches",
                    "function_name": function_name,
                    "created_by": username,
                    "status": response["results"][function_name]["status"],
                    "tenant_name": tenant_name,
                    "comments": f"Cache refresh attempt for {function_name} in tab {tab_name} with {data_with_refresh}",
                    "module_name": tab_name.capitalize(),
                    "request_received_at": str(request_received_at),
                    "session_id": sessionID,
                }
                common_utils_database.update_audit(audit_data, "audit_user_actions")
            except Exception as audit_exc:
                logging.warning(f"Audit logging failed for {function_name}: {audit_exc}")

        except Exception as func_exc:
            logging.exception(f"Error refreshing cache for {function_name}: {func_exc}")
            response["results"][function_name] = {
                "status": "Failed",
                "last_sync_date": None,
                "message": f"Error refreshing cache for {function_name}: {func_exc}"
            }
            response["flag"] = False
            response["message"] = "One or more cache refreshes failed"


            # Log error into error_log_table
            try:
                error_data = {
                    "service_name": f"refresh_{tab_name}_caches",
                    "error_message": str(func_exc),
                    "error_type": type(func_exc).__name__,
                    "users": username,
                    "tenant_name": tenant_name,
                    "comments": f"Error during cache refresh for {function_name} in tab {tab_name}",
                    "module_name": tab_name.capitalize(),
                    "request_received_at": str(request_received_at),
                    "session_id": sessionID,
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
            except Exception as log_exc:
                logging.warning(f"Error logging failed for {function_name}: {log_exc}")

    return response

def get_dashboard_last_sync_time(data):

    max_diff_seconds=60
    """
    Retrieves the latest last_sync_date for the functions in a given tab_name 
    from dashboard_cache_audit, converts it to tenant's local timezone, 
    and returns:
        {
            "last_sync_date": <most recent timestamp in tenant time>,
            "recent_sync_date": <same value if within 1 min, else None>
        }
    """

    tab_name = data.get("tab_name", "").lower().strip()
    tab_name = f"refresh_{tab_name}_caches"

    try:
        common_utils_database = DB("common_utils", **db_config)

        #  Fetch tenant timezone
        tenant_timezone = fetch_tenant_timezone(common_utils_database, data)

        #  Query for the latest sync date
        query = """
            SELECT function_name, last_sync_date
            FROM dashboard_cache_audit
            WHERE function_name = %s and last_sync_date is not null
            ORDER BY last_sync_date DESC 
            LIMIT 1
        """
        df = common_utils_database.execute_query(query, params=[tab_name])

        if not isinstance(df, pd.DataFrame) or df.empty:
            return {"last_sync_date": None, "recent_sync_date": None}

        #  Convert timestamps from UTC to tenant's timezone
        converted_records = convert_timestamp_data(
            df.to_dict(orient="records"), tenant_timezone, timestamp_columns=["last_sync_date"]
        )

        last_sync_date_str = converted_records[0]["last_sync_date"]

        # check if within allowed threshold
        now_local = datetime.now(timezone(tenant_timezone))
        try:
            record_dt = datetime.strptime(last_sync_date_str, "%m-%d-%Y %I:%M:%S %p")
            time_diff = abs((now_local.replace(tzinfo=None) - record_dt).total_seconds())
            recent_sync_date = last_sync_date_str if time_diff <= max_diff_seconds else None
        except Exception as e:
            logging.warning(f"Error parsing last_sync_date {last_sync_date_str}: {e}")
            recent_sync_date = None

        return {"flag": True, "message": "Success",
            "last_sync_date": last_sync_date_str,
            "recent_sync_date": recent_sync_date
        }

    except Exception as e:
        logging.exception(f"Error while fetching last sync time for tab '{tab_name}': {e}")
        
        return {"flag": False, "message": "Error fetching last sync time",
                "last_sync_date": None, "recent_sync_date": None
        }

############ Cache Ui Refresh #############

############ User Role ###########

def escape_sql(value):
    """Escape single quotes for safe f-string SQL usage"""
    if value is None:
        return ""
    return str(value).replace("'", "''")

def get_update_module_features(data):
    """
    Get or update module features for a user based on username, role, or default module features.
    """

    username = escape_sql(data.get("username", ""))
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    role_name = escape_sql(data.get("role_name", ""))
    action = data.get("action")
    selected_features = data.get("selected_features", [])

    response = {
        "flag": True,
        "message": "Success",
        "module_features": [],
        "selected_features": []
    }

    try:
        common_utils_database = DB("common_utils", **db_config)
    except Exception as db_exc:
        logging.info(f"Failed to connect to common_utils_database in get_update_module_features : {db_exc}")
        response["flag"] = False
        response["message"] = f"Database connection error: {db_exc}"
        return response

    try:
        
        # Step 1: Get current tenant's ID and parent_tenant_id
        query = f"""SELECT id, parent_tenant_id FROM tenant WHERE tenant_name = '{tenant_name}' and is_active = true"""
        tenant_data = common_utils_database.execute_query(query, True)

        if tenant_data.empty:
            return {}

        tenant_id = tenant_data["id"].iloc[0]

        # Override ID for Altaworx Test
        if tenant_name == "Altaworx Test":
            tenant_id = 1  # Override with specific ID

        # If action is update and selected_features is provided, update the user's dashboard_dynamic_cols
        if action == "update" and selected_features:
            try:
                selected_features_json = json.dumps(selected_features) if isinstance(
                    selected_features, (list, dict)) else str(selected_features)
                selected_features_json = escape_sql(selected_features_json)

                # Prepare the data
                update_query = {
                    "dashboard_dynamic_cols": json.dumps(selected_features)
                }

                # Example: if you want to update by username instead of id
                common_utils_database.update_dict(
                    "users",
                    update_query,
                    {"username": username}
                )
                response["message"] = "Selected features updated successfully"

            except Exception as update_exc:
                logging.info(f"Error updating selected features for user {username}: {update_exc}")
                response["flag"] = False
                response["message"] = f"Error updating selected features: {update_exc}"
                return response

        # Step 1: Try to get module_features from user_module_tenant_mapping table
        user_module_query = f"""
            SELECT module_features 
            FROM user_module_tenant_mapping 
            WHERE user_name = '{username}'
            and tenant_id = '{tenant_id}'
            
        """
        user_module_result = common_utils_database.execute_query(
            user_module_query, True
        )["module_features"].to_list() if not common_utils_database.execute_query(user_module_query, True).empty else []

        module_features_data = None

        if user_module_result:
            module_features_data = user_module_result[0]
        else:
            # Step 2: If empty, try role_module table
            role_module_query = f"""
                SELECT module_features 
                FROM role_module 
                WHERE role = '{role_name}'
            """
            role_module_result = common_utils_database.execute_query(
                role_module_query, True
            )["module_features"].to_list() if not common_utils_database.execute_query(role_module_query, True).empty else []

            if role_module_result:
                module_features_data = role_module_result[0]
            else:
                # Step 3: If still empty, get from module_features table
                default_features_query = """
                    SELECT features 
                    FROM module_features 
                    WHERE module = 'Dashboard' AND parent_module_name = 'Dashboard'
                """
                default_features_result = common_utils_database.execute_query(
                    default_features_query, True
                )["features"].to_list() if not common_utils_database.execute_query(default_features_query, True).empty else []

                if default_features_result:
                    default_features = default_features_result[0]
                    module_features_data = {"Dashboard": {"Dashboard": default_features}}

        # Parse module_features_data and extract Dashboard features
        if module_features_data:
            if isinstance(module_features_data, str):
                try:
                    module_features_data = json.loads(module_features_data)
                except Exception:
                    pass  # not JSON, leave as-is

            dashboard_features = []
            if (
                isinstance(module_features_data, dict)
                and "Dashboard" in module_features_data
                and "Dashboard" in module_features_data["Dashboard"]
            ):
                dashboard_features = module_features_data["Dashboard"]["Dashboard"]

            processed_features = []
            for feature in dashboard_features:
                if "-" in feature:
                    feature_name, tab_name = feature.rsplit("-", 1)
                    processed_features.append({"name": feature_name, "tab": tab_name})

            response["module_features"] = processed_features

        # Get selected_features from users table
        selected_features_query = f"""
            SELECT dashboard_dynamic_cols 
            FROM users 
            WHERE username = '{username}'
        """
        selected_result = common_utils_database.execute_query(
            selected_features_query, True
        )["dashboard_dynamic_cols"].to_list() if not common_utils_database.execute_query(selected_features_query, True).empty else []

        if selected_result:
            selected_data = selected_result[0]
            if isinstance(selected_data, str):
                try:
                    selected_data = json.loads(selected_data)
                except Exception:
                    pass  # leave as-is if not JSON

            processed_selected = []
            if isinstance(selected_data, list):
                for feature in selected_data:
                    if isinstance(feature, str) and "-" in feature:
                        feature_name, tab_name = feature.rsplit("-", 1)
                        processed_selected.append({"name": feature_name, "tab": tab_name})
                    elif isinstance(feature, dict):
                        processed_selected.append(feature)

            response["selected_features"] = processed_selected

        # Audit logging
        try:
            audit_data = {
                "service_name": "get_update_module_features",
                "created_by": username,
                "status": "True",
                "tenant_name": tenant_name,
                "comments": f"Action: {action}",
                "module_name": "Dashboard",
                "request_received_at": str(request_received_at),
                "session_id": sessionID,
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.info(f"Audit logging failed: {audit_exc}")

    except Exception as func_exc:
        logging.info(f"Error in get_update_module_features: {func_exc}")
        response["flag"] = False
        response["message"] = f"Error processing request: {func_exc}"

        try:
            error_data = {
                "service_name": "get_update_module_features",
                "error_message": str(func_exc),
                "error_type": type(func_exc).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error in get_update_module_features function",
                "module_name": "Dashboard",
                "request_received_at": str(request_received_at),
                "session_id": sessionID,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"Error logging failed: {log_exc}")

    finally:
        try:
            common_utils_database.close()
        except:
            pass

    return response

############ User Role ###########



################# billing sync ######################



def run_populate_revenue_metrics(data):
    """
    Executes populate_revenue_metrics() and audits the count into audit_user_actions.
    Explicitly reads the 'populate_revenue_metrics' column if present and uses that value as count.
    Returns a response dict.
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    
    try:
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")

        killbill_database = DB('billing_platform', **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        # Query (adjust qualification if you prefer public.<fn>() or tenant-qualified)
        query = "SELECT * FROM populate_revenue_metrics()"
        result = killbill_database.execute_query(query, True)
        logging.info("raw result repr:", repr(result))

        # --- Extract the numeric count reliably ---
        count = 0
        try:
            

            if pd is not None and isinstance(result, pd.DataFrame):
                # If DataFrame has the expected column, use it
                col_name = "populate_revenue_metrics"
                if col_name in result.columns and not result.empty:
                    try:
                        # take first row value from that column
                        count = int(result[col_name].iat[0])
                    except Exception as e_col:
                        logging.info(f"[populate_revenue_metrics] failed to parse column '{col_name}': {e_col}")
                        # fallback to first cell
                        try:
                            count = int(result.iat[0, 0])
                        except Exception as e_fallback:
                            logging.info("[populate_revenue_metrics] fallback parse failed:", e_fallback)
                            count = 0
                else:
                    # column not present — fallback to first column or first cell if available
                    if not result.empty:
                        try:
                            count = int(result.iat[0, 0])
                        except Exception as e:
                            logging.info("[populate_revenue_metrics] unable to parse DataFrame first cell:", e)
                            count = 0
                    else:
                        count = 0

            elif isinstance(result, (list, tuple)):
                # e.g. result might be [(67,)] or [[67]] or [67]
                if len(result) == 0:
                    count = 0
                else:
                    first = result[0]
                    if isinstance(first, (list, tuple)) and len(first) > 0:
                        try:
                            count = int(first[0])
                        except Exception as e:
                            logging.info("[populate_revenue_metrics] parse list-of-rows failed:", e)
                            count = 0
                    else:
                        try:
                            count = int(first)
                        except Exception as e:
                            logging.info("[populate_revenue_metrics] parse scalar in list failed:", e)
                            count = 0

            elif result is None:
                count = 0

            else:
                # Scalar-like fallback
                try:
                    count = int(result)
                except Exception:
                    logging.info("[populate_revenue_metrics] unknown result shape, can't parse to int. repr:", repr(result))
                    count = 0

        except Exception as parse_exc:
            logging.info("[populate_revenue_metrics] parse error:", parse_exc)
            count = 0

        
        # Step 2: Audit log
        try:
            audit_data = {
                "service_name": "populate_revenue_metrics",
                "created_by": username,
                "status": "Success" if count > 0 else "No Rows",
                "comments": f"populate_revenue_metrics inserted/updated {count} rows.",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            # keep running even if audit fails
            logging.info(f"[populate_revenue_metrics] Audit logging failed: {audit_exc}")

        # Build response
        response["flag"] = True
        response["inserted_count"] = count
        response["message"] = f"populate_revenue_metrics executed successfully, rows={count}"

    except Exception as exception:
        response["flag"] = False
        response["message"] = f"Error executing populate_revenue_metrics: {exception}"

        # Step 3: Error log
        try:
            error_data = {
                "service_name": "populate_revenue_metrics",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "comments": str(exception),
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if "common_utils_database" in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"[populate_revenue_metrics] Error logging to DB: {log_exc}")

    return response



def run_populate_revenue_metrics_diff(data):
    """
    Executes populate_revenue_metrics_diff() and audits the count into audit_user_actions.
    Robustly extracts the numeric count from various shapes returned by execute_query.
    Returns a response dict.
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    try:
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")

        killbill_database = DB('billing_platform', **db_config)
        # you used env var in your snippet — keep that
        common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE", "common_utils"), **db_config)

        # Step 1: Call the SQL function (keep same call style you used)
        query = "SELECT * from  populate_revenue_metrics_diff();"
        # some DB helpers use fetch=True / True; try both by using keyword if present
        try:
            result = killbill_database.execute_query(query, fetch=True)
        except TypeError:
            # fallback if execute_query signature is (query, True)
            result = killbill_database.execute_query(query, True)

        # debug logging.info (remove or replace with logger if desired)
        logging.info("populate_revenue_metrics_diff raw result repr:", repr(result))

        # --- Extract the numeric count reliably ---
        count = 0
        try:
            

            # Prefer named column matching the function name
            expected_col = "populate_revenue_metrics_diff"
            alt_col = "populate_revenue_metrics"

            if pd is not None and isinstance(result, pd.DataFrame):
                if not result.empty:
                    # try expected column first
                    if expected_col in result.columns:
                        try:
                            count = int(result[expected_col].iat[0])
                        except Exception as e:
                            logging.info(f"[populate_revenue_metrics_diff] failed parse '{expected_col}': {e}")
                            # fallback to first cell
                            try:
                                count = int(result.iat[0, 0])
                            except Exception as e2:
                                logging.info("[populate_revenue_metrics_diff] fallback parse failed:", e2)
                                count = 0
                    elif alt_col in result.columns:
                        try:
                            count = int(result[alt_col].iat[0])
                        except Exception as e:
                            logging.info(f"[populate_revenue_metrics_diff] failed parse '{alt_col}': {e}")
                            try:
                                count = int(result.iat[0, 0])
                            except Exception:
                                count = 0
                    else:
                        # neither expected column present — use first cell
                        try:
                            count = int(result.iat[0, 0])
                        except Exception as e:
                            logging.info("[populate_revenue_metrics_diff] unable to parse DataFrame first cell:", e)
                            count = 0
                else:
                    count = 0

            elif isinstance(result, (list, tuple)):
                # e.g. [(67,)], [[67]] or [67]
                if len(result) == 0:
                    count = 0
                else:
                    first = result[0]
                    if isinstance(first, (list, tuple)) and len(first) > 0:
                        try:
                            count = int(first[0])
                        except Exception as e:
                            logging.info("[populate_revenue_metrics_diff] parse list-of-rows failed:", e)
                            count = 0
                    else:
                        try:
                            count = int(first)
                        except Exception as e:
                            logging.info("[populate_revenue_metrics_diff] parse scalar in list failed:", e)
                            count = 0

            elif result is None:
                count = 0

            else:
                # attempt to coerce scalar-like results to int
                try:
                    count = int(result)
                except Exception:
                    logging.info("[populate_revenue_metrics_diff] unknown result shape, can't parse to int. repr:", repr(result))
                    count = 0

        except Exception as parse_exc:
            logging.info("[populate_revenue_metrics_diff] parse error:", parse_exc)
            count = 0

        # Step 2: Audit log
        try:
            audit_data = {
                "service_name": "populate_revenue_metrics_diff",
                "created_by": username,
                "status": "Success" if count > 0 else "No Rows",
                "comments": f"populate_revenue_metrics_diff inserted/updated {count} rows.",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            # keep running even if audit fails
            logging.warning(f"[populate_revenue_metrics_diff] Audit logging failed: {audit_exc}")

        # Build response
        response["flag"] = True
        response["inserted_count"] = count
        response["message"] = f"populate_revenue_metrics_diff executed successfully, rows={count}"

    except Exception as exception:
        response["flag"] = False
        response["message"] = f"Error executing populate_revenue_metrics_diff: {exception}"

        # Step 3: Error log
        try:
            error_data = {
                "service_name": "populate_revenue_metrics_diff",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "comments": str(exception),
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if "common_utils_database" in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.warning(f"[populate_revenue_metrics_diff] Error logging to DB: {log_exc}")

    return response

################# billing sync ######################
