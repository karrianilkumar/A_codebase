"""
@Author1 : Phaneendra.Y
Created Date: 01-11-24
"""

# Importing the necessary Libraries
import os
import pandas as pd
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from datetime import datetime, timedelta
from io import BytesIO
import base64
import zipfile
import io
import pandas as pd
import logging
from itertools import groupby
import re
from zoneinfo import ZoneInfo
import io
from openpyxl import Workbook
import json


logging = Logging(name="dashboard")

def clean_tuple(tpl):
    """ Cleans and formats a tuple, returning a string representation or an empty tuple if invalid."""
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
       logging.exception(f"###Exception while converting tuple: {e}")
       return ()

def db_config_maker(user, db_config_making, tenant_database,tenant_name,role_name):
    """
    customer and provider info to the DB settings based on user role and tenant.
    """

    if role_name in ('Super Admin','Partner Admin'):
        return db_config_making
    common_utils_database = DB('common_utils', **db_config_making)
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )

    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    if tenant_id:
        tenant_id=int(tenant_id)
    query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"
    filters = common_utils_database.execute_query(query, True)

    database = DB(tenant_database, **db_config)
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except:
        customer_group = None

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception(f"###Error extracting rate_plan_name :{e}")
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception(f"###Error extracting rate_plan_name: {e}")
                customer_names=None

            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None


            except Exception as e:
                logging.exception(f"###Error extracting billing_account_number:{e}")
                billing_account_number=None

            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception(f"###Error extracting feature_codes :{e}")
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except:
            customer = None
    else:
        customer=customer_names
    customer=clean_tuple(customer)
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            formatted_values = "', '".join(service_provider)
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except:
        service_provider = None
        service_provider_id = None
    logging.info(f"###customerscustomerscustomerscustomers:{customer}")
    try:
        customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customers_df=database.execute_query(customers_query,True)
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                if isinstance(customer, str):
                    customer = customer.strip("()'")  # Clean customer from extra parentheses and quotes
                    customer = (customer,)  # Convert it into a tupl


                # Now convert tuple to list
                customer_list = list(customer)
                # Clean and fix the list by splitting the elements and ensuring they are correctly quoted
                fixed_customer_list = []

                # Split the string into items and strip any unwanted characters
                for item in customer_list[0].split("', '"):
                    fixed_customer_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info(f'###customer_list before extend:{fixed_customer_list}')

                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info(f'###customer_list after extend:{fixed_customer_list}')

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info(f'###final customer tuple:{customer}')
                customer=clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(f"Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    try:
        customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_name = customer_rate_plan_name.strip("()'")  # Remove ( and ) and ' from start and end
                    customer_rate_plan_name = (customer_rate_plan_name,)  # Now correctly convert it to tuple

                # Now convert tuple to list
                customer_rate_plan_list = list(customer_rate_plan_name)
                fixed_customer_rate_plan_list = []

                # Split the string into items and strip any unwanted characters
                for item in customer_rate_plan_list[0].split("', '"):
                    fixed_customer_rate_plan_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info(f'###customer_list before extend:{customer_rate_plan_list}')

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info(f'###customer_list after extend:{fixed_customer_rate_plan_list}')

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info(f'###final customer tuple:{customer_rate_plan_name}')

    except Exception as e:
        logging.exception(f"###Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")

    logging.info(f'###customer at the end of customer:{customer}')
    db_config_making["customers"] = customer
    db_config_making["service_providers"] = service_provider
    db_config_making["service_provider_id"] = service_provider_id
    return db_config_making



def funtion_caller(data,path):
    """
        Main dispatcher function that builds DB config for the user .
    """
    global db_config

    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

    user=data.get('username')
    if not user:
        user=data.get('user_name')
    tenant_database = data.get("db_name")
    role_name = data.get("role_name", "") or data.get('role', "") or data.get('role',"") or 'Super Admin'
    tenant_name = data.get("tenant_name", "") or data.get('tenant', "") or data.get('Partner',"")
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name)
    db_config=db_config_making
    logging.info(f"####db_config created is : {db_config}")

    if path == "/get_service_providers":
        result = get_service_providers(data)
    elif path == "/count_of_service_provider":
        result = count_of_service_provider(data)
    elif path == "/count_of_active_sims":
        result = count_of_active_sims(data)
    elif path == "/count_of_pending_sim_activations":
        result = count_of_pending_sim_activations(data)
    elif path == "/device_status_chart":
        result = device_status_chart(data)
    elif path == "/activated_vs_deactivated_pie_chart":
        result = activated_vs_deactivated_pie_chart(data)
    elif path == "/service_provider_change_request_stack_bar":
        result = service_provider_change_request_stack_bar(data)
    elif path == "/count_of_active_customers":
        result = count_of_active_customers(data)
    elif path == "/rev_assurance_record_discrepancy_card":
        result = rev_assurance_record_discrepancy_card(data)
    elif path == "/daily_sync_card":
        result = daily_sync_card(data)
    elif path == "/live_sessions_table":
        result = live_sessions_table(data)
    elif path == "/get_usage_details_card":
        result = get_usage_details_card(data)
    elif path == "/getm2m_high_usage_chart_data":
        result = getm2m_high_usage_chart_data(data)
    elif path == "/get_device_status_card":
        result = get_device_status_card(data)
    elif path == "/generate_empty_excel":
        result = generate_empty_excel()
    elif path == "/mobility_usage_per_group_pool":
        result = mobility_usage_per_group_pool(data)
    elif path == "/mobility_usage_per_customer_pool":
        result = mobility_usage_per_customer_pool(data)
    elif path == "/mobility_high_usage_chart":
        result = mobility_high_usage_chart(data)
    elif path == "/get_carrier_rate_plan_data":
        result = get_carrier_rate_plan_data(data)
    elif path == "/get_customer_rate_plan_data":
        result = get_customer_rate_plan_data(data)
    elif path == "/get_rate_plan_data":
        result = get_rate_plan_data(data)
    elif path == "/get_compare_cards":
        result = get_compare_cards(data)
    elif path == "/get_high_usage_chart_data":
        result = get_high_usage_chart_data(data)
    else:
        result = {"error": "Invalid path or method"}
        logging.warning(f"###Invalid path or method requested:{path}")

    return result


#######Dashboard code
def call_funtion(path, data):
    """
    calls the appropriate dashboard function based on the API path.

    """

    if path == "/get_service_providers":
        result = get_service_providers(data)
    elif path == "/count_of_service_provider":
        result = count_of_service_provider(data)
    elif path == "/count_of_active_sims":
        result = count_of_active_sims(data)
    elif path == "/count_of_pending_sim_activations":
        result = count_of_pending_sim_activations(data)
    elif path == "/device_status_chart":
        result = device_status_chart(data)
    elif path == "/activated_vs_deactivated_pie_chart":
        result = activated_vs_deactivated_pie_chart(data)
    elif path == "/service_provider_change_request_stack_bar":
        result = service_provider_change_request_stack_bar(data)
    elif path == "/count_of_active_customers":
        result = count_of_active_customers(data)
    elif path == "/rev_assurance_record_discrepancy_card":
        result = rev_assurance_record_discrepancy_card(data)
    elif path == "/daily_sync_card":
        result = daily_sync_card(data)
    elif path == "/live_sessions_table":
        result = live_sessions_table(data)
    elif path == "/get_compare_cards":
        result = get_compare_cards(data)
    elif path == "/get_high_usage_chart_data":
        result = get_high_usage_chart_data(data)
    else:
        result = {"error": "Invalid path or method"}
        logging.warning(f"###Invalid path or method requested: {path}")

    return result


def get_compare_cards(data):
    """
    Given a year and a list of months, returns a dictionary with month names (or numbers) as keys
    and a dictionary with 'start_date' and 'end_date' for each month.

    Parameters:
    year (int): The year for which the start and end dates are required.
    months (list): A list of month names (e.g., ['January', 'March', 'November']) or month numbers (e.g., [1, 3, 11]).

    Returns:
    dict: A dictionary where each key is a month and the value is a dictionary with 'start_date' and 'end_date'.
    """
    year = int(data["year"])  # Convert year to integer
    months = data["months"]
    path = data["chart_path"]

    month_dates = {}
    try:
        for month in months:
            acc_month = month
            # Convert month name to number if it is a string (e.g., 'January' -> 1)
            if isinstance(month, str):
                month = datetime.strptime(month, "%B").month

            # Construct the start date for the month (first day of the month)
            start_date = f"{year}-{month:02d}-01"
            # Get the last day of the month (end date)
            next_month = month % 12 + 1  # Next month
            next_month_year = (
                year if next_month > 1 else year + 1
            )  # Adjust year if next month is January

            end_date = f"{next_month_year}-{next_month:02d}-01"

            # Subtract one day from the next month's first day to get the last day of the current month
            end_date_obj = datetime.strptime(end_date, "%Y-%m-%d") - timedelta(days=1)
            end_date = end_date_obj.strftime("%Y-%m-%d")
            data.update({"start_date": start_date, "end_date": end_date})

            # You can add your function to process the data here (if needed)
            result = call_funtion(path, data)
            result.pop("flag")
            # Store both start and end dates
            month_dates[acc_month] = result

        return {"flag": True, "month_dates": month_dates}
    except Exception as e:
        logging.warning(f"###error here: {e}")

        return {"flag": False, "month_dates": month_dates}


def get_service_providers(data):
    """
    Retrieves a list of active service providers from the specified tenant database.
    Args:
        data (dict): A dictionary containing request parameters, including "db_name".

    Returns:
        dict: A response dictionary with a success flag and the list of active service
              providers. If an error occurs, it returns a flag of False and an empty list.
    """

    logging.info(f"###Request Recieved for path get_service_providers:{data}")
    ## database connection
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    try:
        service_providers = database.get_data(
            "serviceprovider", {"is_active": True}, ["service_provider_name"]
        )["service_provider_name"].to_list()
        logging.info(f"###Query defined to fetch active service provider:{service_providers}")
        service_providers.append("All Service Providers")
        # Create and return the response
        response = {"flag": True, "service_providers": service_providers}
        logging.info(f"###Response prepared successfully: {response}")

        return response
    except Exception as e:
        logging.exception(f"###An error occurred: {e}")
        return {"flag": False, "service_providers": []}


def count_of_service_provider(data):
    """
    Fetches the total number of service_provider's that got triggered from the AMOP application.
    Args:
        data (dict): A dictionary containing the following keys:
            - service_provider (str): The service_provider for filtering service provider's.
            - start_date (str): The start date for filtering service provider's (format: YYYY-MM-DD).
            - end_date (str): The end date for filtering service provider's (format: YYYY-MM-DD).
    Returns:
        dict: containing the status of total_emails_count and the data card information.
    """
    logging.info(f"###Request Recieved for path count_of_service_provider:{data}")
    # service_provider = data.get('service_provider')
    # start_date = data.get('start_date')
    # end_date = data.get('end_date')
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test" or tenant_database=="altaworx_test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id']
        )
    parent_tenant_id = tenant_details['parent_tenant_id'].values[0]
    if parent_tenant_id:
        tenant_id = parent_tenant_id
    else:
        tenant_id = tenant_details['id'].values[0]
    query = f"""
        SELECT COUNT(*)
        FROM serviceprovider where is_active=True AND tenant_id={tenant_id}
    """
    try:
        # Execute query with parameters
        res = database.execute_query(query, True)
        # Fetch the count and ensure it's a standard Python int
        if isinstance(res, pd.DataFrame) and not res.empty:
            total_service_providers = int(
                res.iloc[0, 0]
            )  # Convert to standard Python int
        else:
            total_service_providers = 0
        # Prepare the response
        response = {
            "flag": True,
            "data": {
                "title": "No: of Service Providers",
                "chart_type": "data",
                "data": total_service_providers,
                "icon": "useroutlined",
                "height": 100,
                "width": 300,
            },
        }
    except Exception as e:
        logging.exception(f"###Exception occurred:{e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching total_service_providers",
        }
    return response



def count_of_active_sims(data):
    """
    Fetches the total number of service_provider's that got triggered from the AMOP application.
    Args:
        data (dict): A dictionary containing the following keys:
            - service_provider (str): The service_provider for filtering service provider's.
            - start_date (str): The start date for filtering service provider's (format: YYYY-MM-DD).
            - end_date (str): The end date for filtering service provider's (format: YYYY-MM-DD).
    Returns:
        dict: containing the status of total_emails_count and the data card information.
    """
    logging.info(f"###Request Recieved for path count_of_active_sims:{data}")
    service_provider = data.get("service_provider")
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    logging.info(f"###count_of_active_sims_tenant_name is :{tenant_name}")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id']
        )
    logging.info(f'###count_of_service_provider tenant_details are: {tenant_details}')
    parent_tenant_id = tenant_details['parent_tenant_id'].values[0]

    if service_provider == "All":
        tenant_id = tenant_details['id'].values[0]
        tenant_id  = int(tenant_id)
        query = """
            SELECT COUNT(*)
            FROM sim_management_inventory
            WHERE sim_status IN ('Activated', 'Active')
            AND tenant_id = %s
            AND is_active = True
        """
        params = [
            tenant_id,
        ]

    else:
        tenant_id = tenant_details['id'].values[0]
        tenant_id  = int(tenant_id)
        query = """
            SELECT COUNT(*)
            FROM sim_management_inventory
            WHERE service_provider = %s
            AND sim_status IN ('Activated', 'Active')
            AND tenant_id = %s
            AND is_active = True
        """
        params = [
            service_provider,
            tenant_id,
        ]
    # Database connection
    # database = DB('common_utils', **db_config)
    logging.info(f"###count_of_active_sims query : {query}")
    try:
        # Execute query with parameters
        res = database.execute_query(query, params=params)
        # Fetch the count and ensure it's a standard Python int
        if isinstance(res, pd.DataFrame) and not res.empty:
            active_sims_count = int(res.iloc[0, 0])  # Convert to standard Python int
        else:
            active_sims_count = 0
        # Prepare the response
        response = {
            "flag": True,
            "data": {
                "title": "No: of Active SIMs",
                "chart_type": "data",
                "data": active_sims_count,
                "icon": "useroutlined",
                "height": 100,
                "width": 300,
            },
        }
    except Exception as e:
        logging.exception(f"###Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching total emails",
        }
    return response



def count_of_pending_sim_activations(data):
    """
    Fetches the total number of sim activations's that got triggered from the AMOP application.
    Args:
        data (dict): A dictionary containing the following keys:
            - service_provider (str): The service_provider for filtering service provider's.
            - start_date (str): The start date for filtering service provider's (format: YYYY-MM-DD).
            - end_date (str): The end date for filtering service provider's (format: YYYY-MM-DD).
    Returns:
        dict: containing the status of total_emails_count and the data card information.
    """
    logging.info(f"###Request Recieved for path count_of_pending_sim_activations:{data}")
    service_provider = data.get("service_provider")
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id']
        )
    logging.info(f'###count_of_service_provider tenant_details are: {tenant_details}')
    parent_tenant_id = tenant_details['parent_tenant_id'].values[0]
    if service_provider == "All":
        tenant_id = tenant_details['id'].values[0]
        tenant_id  = int(tenant_id)
        query = """
            SELECT COUNT(*)
            FROM sim_management_inventory
            WHERE sim_status='Pending Activation'
            AND tenant_id = %s
            AND is_active=True
        """
        params = [
            tenant_id
        ]

    else:
        tenant_id = tenant_details['id'].values[0]
        tenant_id  = int(tenant_id)
        query = """
            SELECT COUNT(*)
            FROM sim_management_inventory
            WHERE service_provider = %s
            AND tenant_id = %s
            AND sim_status='Pending Activation'
            AND is_active = True
        """
        params = [
            service_provider,
            tenant_id
        ]
    try:
        # Execute query with parameters
        res = database.execute_query(query, params=params)
        # Fetch the count and ensure it's a standard Python int
        if isinstance(res, pd.DataFrame) and not res.empty:
            pending_sim_activations_count = int(
                res.iloc[0, 0]
            )  # Convert to standard Python int
        else:
            pending_sim_activations_count = 0
        # Prepare the response
        response = {
            "flag": True,
            "data": {
                "title": "Pending SIM Activations",
                "chart_type": "data",
                "data": pending_sim_activations_count,
                "icon": "useroutlined",
                "height": 100,
                "width": 300,
            },
        }
    except Exception as e:
        logging.exception(f"###Exception occurred:{e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching total emails",
        }
    return response


def device_status_chart(data):
    """
    Fetches the count of device statuses over a custom date range.

    Args:
        data (dict): A dictionary containing:
            - partner_name (str): Partner name for filtering data.
            - start_date (str): Start date for filtering data (format: YYYY-MM-DD).
            - end_date (str): End date for filtering data (format: YYYY-MM-DD).
            - service_provider (str): Optional, filter by service provider.

    Returns:
        dict: A dictionary with the status of the data fetch and bar chart data.
    """
    logging.info(f"###Request Recieved for path device_status_chart:{data}")
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date()
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date()
    # Parse the custom date range from the input
    service_provider = data.get("service_provider")
    date_filter = data.get("filter", "")
    # try:
    #     today = datetime.now().date()
    #     if date_filter == "Today":
    #         start_date = today
    #         end_date = today
    #     elif date_filter == "Current Week":
    #         start_date = today - timedelta(days=today.weekday())  # Monday
    #         end_date = start_date + timedelta(days=6)
    #     elif date_filter == "Current Month":
    #         start_date = today.replace(day=1)
    #         # Calculate the last day of the month
    #         if start_date.month == 12:
    #             end_date = start_date.replace(year=start_date.year + 1, month=1, day=1) - timedelta(days=1)
    #         else:
    #             end_date = start_date.replace(month=start_date.month + 1, day=1) - timedelta(days=1)
    #     else:
    #         start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date()
    #         end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date()
    #     logging.info(f"start-end-date : {start_date} - {end_date}")
    # except Exception as e:
    #     logging.info(f"device_status_chart_time : {str(e)}")
    #     start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date()
    #     end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date()

    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id','time_zone']
        )
    logging.info(f'###device_status_chart tenant_details are: {tenant_details}')
    parent_tenant_id = tenant_details['parent_tenant_id'].values[0]
    if service_provider.lower() == "all":
        tenant_id = tenant_details['id'].values[0]
        tenant_id = int(tenant_id)
        query = """
        SELECT
            CASE
                WHEN Upper(sim_status) IN ('ACTIVATED', 'ACTIVE') THEN 'ACTIVE'
                ELSE Upper(sim_status) -- Keep the original status if no mapping is specified
            END AS sim_status,
            COUNT(*) AS status_count
        FROM sim_management_inventory
        WHERE
            tenant_id = %s
            AND modified_date BETWEEN
            CAST(CONCAT(%s, ' 00:00:00') AS timestamp) AND
            CAST(CONCAT(%s, ' 23:59:59') AS timestamp)
        GROUP BY
            CASE
                WHEN Upper(sim_status) IN ('ACTIVATED', 'ACTIVE') THEN 'ACTIVE'
                ELSE Upper(sim_status)
            END;
        """
        params = [tenant_id,start_date, end_date]

    else:
        tenant_id = tenant_details['id'].values[0]
        tenant_id = int(tenant_id)
        query = """
        SELECT
        CASE
        WHEN Upper(sim_status) IN ('ACTIVATED', 'ACTIVE') THEN 'ACTIVE'
        ELSE Upper(sim_status) -- Keep the original status if no mapping is specified
        END AS sim_status,
        COUNT(*) AS status_count
        FROM sim_management_inventory
        WHERE
            service_provider_display_name = %s
            AND tenant_id = %s
            AND modified_date BETWEEN
            CAST(CONCAT(%s, ' 00:00:00') AS timestamp) AND
            CAST(CONCAT(%s, ' 23:59:59') AS timestamp)
        GROUP BY
            CASE
            WHEN Upper(sim_status) IN ('ACTIVATED', 'ACTIVE') THEN 'ACTIVE'
            ELSE Upper(sim_status)
        END;
        """
        params = [service_provider,tenant_id, start_date, end_date]
    try:
        # Database connection
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)

        # Execute the main query and retrieve the result
        res = database.execute_query(query, params=params)

        # Function to convert text to title case (with spaces)
        def to_title_case(text):
            if text:  # Check if the text is not None or empty
                return " ".join([word.capitalize() for word in text.split()])
            return text  # Return the original text if it's None or empty

        # Apply the function to the 'sim_status' column
        res["sim_status"] = res["sim_status"].apply(to_title_case)
        # Convert query result into a dictionary, handling any empty results
        status_counts = (
            {row["sim_status"]: row["status_count"] for row in res.to_dict("records")}
            if not res.empty
            else {}
        )

        # Extract all statuses dynamically from the query result
        statuses = list(status_counts.keys())

        # Prepare the response data
        data_card = []
        for status in statuses:  # Use dynamically fetched statuses
            count = status_counts.get(status, 0)  # Default to 0 if no data for status
            data_card.append({"status": status, "count": count})

        # Response formatted for bar chart data
        response = {
            "flag": True,
            "data": {
                "title": "Device Status",
                "chart_type": "bar",
                "data": data_card,
                "xField": "status",
                "yField": "count",
                "smooth": True,
                "height": 300,
                "width": 500,
            },
        }

    except Exception as e:
        logging.exception(f"###Exception occurred: {e}")
        response = {
            "flag": True,
            "data": {
                "title": "Device Status",
                "chart_type": "bar",
                "data": [],
                "xField": "status",
                "yField": "count",
                "smooth": True,
                "height": 300,
                "width": 500,
            },
        }

    return response


def activated_vs_deactivated_pie_chart(data):
    """
    Fetches the count of 'Activated' vs 'Deactivated' devices over a custom date range for a pie chart.

    Args:
        data (dict): A dictionary containing:
            - partner_name (str): Partner name for filtering data.
            - start_date (str): Start date for filtering data (format: YYYY-MM-DD).
            - end_date (str): End date for filtering data (format: YYYY-MM-DD).
            - service_provider (str): Optional, filter by service provider.

    Returns:
        dict: A dictionary with the status of the data fetch and pie chart data.
    """
    logging.info(f"###Request Recieved for path activated_vs_deactivated_pie_chart:{data}")

    # Parse the custom date range from the input
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d")
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d")
    service_provider = data.get("service_provider")

    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id','time_zone']
        )
    logging.info(f'###activated_vs_deactivated_pie_chart tenant_details are: {tenant_details}')
    parent_tenant_id = tenant_details['parent_tenant_id'].values[0]

    try:
        time_zone = tenant_details['time_zone'].values[0]
        # Get the timezone from tenant details
        logging.info(f"###activated_vs_deactivated_pie_chart_time_zone is: {time_zone}")
        logging.info(f'###before start - {start_date} - {end_date}')
        start_date = start_date.replace(tzinfo=ZoneInfo(time_zone))
        end_date = end_date.replace(tzinfo=ZoneInfo(time_zone))
        logging.info(f'###start date : {start_date} - {end_date}')
        start_date = start_date.strftime("%Y-%m-%d")
        end_date = end_date.strftime("%Y-%m-%d")
    except Exception as e:
        logging.info(f"###activated_vs_deactivated_pie_chart time_zone error: {e}")
        start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date()
        end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date()

    # Adjust query to focus on 'Activated' and 'Deactivated' statuses
    if service_provider.lower() == "all":
        tenant_id = tenant_details['id'].values[0]
        tenant_id = int(tenant_id)
        query = """

        SELECT
            sim_status,
            COUNT(*) AS status_count
        FROM (
            SELECT
                CASE
                    WHEN sim_status IN ('Activated', 'Active') THEN 'Activated'
                    ELSE sim_status
                END AS sim_status
            FROM sim_management_inventory
            WHERE sim_status IN ('Activated', 'Deactivated', 'Active')
            AND tenant_id = %s
            AND modified_date BETWEEN
            CAST(CONCAT(%s, ' 00:00:00') AS timestamp) AND
            CAST(CONCAT(%s, ' 23:59:59') AS timestamp)
        ) AS grouped_status
        GROUP BY sim_status
        """
        params = [tenant_id,start_date, end_date]
    else:
        tenant_id = tenant_details['id'].values[0]
        tenant_id = int(tenant_id)
        query = """
        SELECT
            sim_status,
            COUNT(*) AS status_count
        FROM (
            SELECT
                CASE
                    WHEN sim_status IN ('Activated', 'Active') THEN 'Activated'
                    ELSE sim_status
                END AS sim_status
            FROM sim_management_inventory
            WHERE sim_status IN ('Activated', 'Deactivated', 'Active')
            AND service_provider_display_name = %s AND tenant_id = %s AND modified_date BETWEEN
            CAST(CONCAT(%s, ' 00:00:00') AS timestamp) AND
            CAST(CONCAT(%s, ' 23:59:59') AS timestamp)
        ) AS grouped_status
        GROUP BY sim_status
        """
        params = [service_provider,tenant_id ,start_date, end_date]

    try:
        # Database connection
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)

        # Execute the query and retrieve the result
        res = database.execute_query(query, params=params)

        # Convert query result into a dictionary, handling any empty results
        status_counts = (
            {row["sim_status"]: row["status_count"] for row in res.to_dict("records")}
            if not res.empty
            else {}
        )

        # Prepare data for pie chart
        pie_data = [
            {"status": "Activated", "count": status_counts.get("Activated", 0)},
            {"status": "Deactivated", "count": status_counts.get("Deactivated", 0)},
        ]

        # Response formatted for pie chart data
        response = {
            "flag": True,
            "data": {
                "title": "Activated vs Deactivated",
                "chart_type": "pie",
                "data": pie_data,
                "angleField": "count",
                "colorField": "status",
                "height": 300,
                "width": 300,
            },
        }

    except Exception as e:
        logging.exception(f"###Exception occurred: {e}")
        response = {
            "flag": True,
            "data": {
                "title": "Activated vs Deactivated",
                "chart_type": "pie",
                "data": [],
                "angleField": "count",
                "colorField": "status",
                "height": 300,
                "width": 300,
            },
        }

    return response


def service_provider_change_request_stack_bar(data):
    """
    Fetches data for a stacked bar chart of change request types per service provider.

    Args:
        data (dict): A dictionary containing:
            - start_date (str): Start date for filtering data (format: YYYY-MM-DD).
            - end_date (str): End date for filtering data (format: YYYY-MM-DD).
            - db_name (str): The database name to connect to.

    Returns:
        dict: A dictionary with the status of the data fetch and stacked bar chart data.
    """
    logging.info(f"###Request Recieved for path service_provider_change_request_stack_bar:{data}")
    # Parse date range from input
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date()
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date()
    tenant_database = data.get("db_name", "")
    service_provider = data.get("service_provider")

    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id']
        )
    logging.info(f'###device_status_chart tenant_details are: {tenant_details}')
    parent_tenant_id = tenant_details['parent_tenant_id'].values[0]

    # Adjust query to focus on 'Activated' and 'Deactivated' statuses
    if service_provider.lower() == "all":
        tenant_id = tenant_details['id'].values[0]
        tenant_id = int(tenant_id)
        query = """
                SELECT
                    service_provider,
                    change_request_type,
                    COUNT(*) AS request_count
                FROM
                    sim_management_bulk_change
                WHERE
                    tenant_id = %s
                    AND modified_date BETWEEN
            CAST(CONCAT(%s, ' 00:00:00') AS timestamp) AND
            CAST(CONCAT(%s, ' 23:59:59') AS timestamp)
                GROUP BY
                    service_provider, change_request_type;
                """
        params = [tenant_id,start_date, end_date]
    else:
        tenant_id = tenant_details['id'].values[0]
        tenant_id = int(tenant_id)
        query = """
                SELECT
                    service_provider,
                    change_request_type,
                    COUNT(*) AS request_count
                FROM
                    sim_management_bulk_change
                WHERE service_provider = %s
                    AND tenant_id = %s
                    AND modified_date BETWEEN
            CAST(CONCAT(%s, ' 00:00:00') AS timestamp) AND
            CAST(CONCAT(%s, ' 23:59:59') AS timestamp)
                GROUP BY
                    service_provider, change_request_type;
                """
        params = [service_provider, tenant_id, start_date, end_date]
    try:
        # Database connection
        database = DB(tenant_database, **db_config)

        # Execute the query and retrieve the result
        res = database.execute_query(query, params=params)

        # Convert query result into structured data for stacked bar chart
        if not res.empty:
            chart_data = []
            for row in res.to_dict("records"):
                chart_data.append(
                    {
                        "service_provider": row["service_provider"],
                        "change_request_type": row["change_request_type"],
                        "count": row["request_count"],
                    }
                )

            # Response formatted for stacked bar chart
            response = {
                "flag": True,
                "data": {
                    "title": "Change Request Types Per Service Provider",
                    "chart_type": "stackedBar",
                    "data": chart_data,
                    "xField": "service_provider",
                    "yField": "count",
                    "seriesField": "change_request_type",
                    "height": 300,
                    "width": 500,
                },
            }
        else:
            # Empty result set
            response = {
                "flag": True,
                "data": {
                    "title": "Change Request Types Per Service Provider",
                    "chart_type": "stackedBar",
                    "data": [],
                    "xField": "service_provider",
                    "yField": "count",
                    "seriesField": "change_request_type",
                    "height": 300,
                    "width": 500,
                },
            }

    except Exception as e:
        logging.exception(f"###Exception occurred: {e}")
        response = {
            "flag": True,
            "data": {
                "title": "Change Request Types Per Service Provider",
                "chart_type": "stackedBar",
                "data": [],
                "xField": "service_provider",
                "yField": "count",
                "seriesField": "change_request_type",
                "height": 300,
                "width": 500,
            },
        }

    return response


def count_of_active_customers(data):
    """
    Fetches the total number of active customer's that got triggered from the AMOP application.
    Args:
        data (dict): A dictionary containing the following keys:
            - service_provider (str): The service_provider for filtering service provider's.
            - start_date (str): The start date for filtering service provider's (format: YYYY-MM-DD).
            - end_date (str): The end date for filtering service provider's (format: YYYY-MM-DD).
    Returns:
        dict: containing the status of total_emails_count and the data card information.
    """
    logging.info(f"###Request Recieved for path count_of_active_customers:{data}")
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    logging.info(f'###count_of_active_customers tenant_name is: {tenant_name}')
    # Database connection
    try:
        tenant_details=common_utils_database.get_data(
            "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id']
            )
        logging.info(f'###count_of_active_customers tenant_details are: {tenant_details}')
        parent_tenant_id = tenant_details['parent_tenant_id'].values[0]
        tenant_id = tenant_details['id'].values[0]
        query = f"""
                SELECT count(*) FROM public.RevCustomer
                where integration_authentication_id = 4 and is_active = True and Status IN ('OPEN', 'Active')
                and tenant_id={tenant_id}
            """
        logging.info(f'###count_of_service_provider query is :{query}')
        # Execute query with parameters
        res = database.execute_query(query, True)
        # Fetch the count and ensure it's a standard Python int
        if isinstance(res, pd.DataFrame) and not res.empty:
            active_customer_count = int(
                res.iloc[0, 0]
            )  # Convert to standard Python int
        else:
            active_customer_count = 0
        # Prepare the response
        response = {
            "flag": True,
            "data": {
                "title": "No: of Active Customers",
                "chart_type": "data",
                "data": active_customer_count,
                "icon": "useroutlined",
                "height": 100,
                "width": 300,
            },
        }
    except Exception as e:
        logging.exception(f"###Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching total emails",
        }
    return response


def rev_assurance_record_discrepancy_card(data):
    """
    Fetches the total number of service_provider's that got triggered from the AMOP application.
    Args:
        data (dict): A dictionary containing the following keys:
            - service_provider (str): The service_provider for filtering service provider's.
            - start_date (str): The start date for filtering service provider's (format: YYYY-MM-DD).
            - end_date (str): The end date for filtering service provider's (format: YYYY-MM-DD).
    Returns:
        dict: containing the status of total_emails_count and the data card information.
    """
    logging.info(f"###Request Recieved for path rev_assurance_record_discrepancy_card:{data}")
    service_provider = data.get("service_provider")
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)

    # Check if the end_date is provided and valid
    if end_date is None:
        response = {
            "flag": False,
            "message": "End date is required and cannot be None.",
        }
        return response

    # If end_date is not None, try to parse it
    try:
        # Handle cases where end_date includes time (e.g., 'YYYY-MM-DD HH:MM:SS')
        end_date_stripped = end_date.split()[0]  # Keep only the date part
        end_date_parsed = datetime.strptime(end_date_stripped, "%Y-%m-%d")
        end_date_parsed = end_date_parsed + timedelta(days=1)
    except ValueError as e:
        response = {"flag": False, "message": f"Invalid end date format: {str(e)}"}
        return response

    # Base query depending on whether 'service_provider' is 'All' or specific
    if service_provider == "All":
        query = """
            SELECT
                service_provider,
                CASE
                    WHEN LOWER(device_status) = '' THEN CONCAT('Device not in Rev.IO, but ', 'activated', ' in carrier.')
                    WHEN LOWER(rev_io_status) = 'deactivated' THEN CONCAT('Device is Deactivated in Rev.IO, but ', device_status, ' in carrier.')
                    WHEN LOWER(device_status) = 'deactivated' THEN CONCAT('Device is Deactivated in carrier, but ', 'activated', ' in Rev.IO.')
                    ELSE CONCAT('Device is ', device_status, ' in both Rev.IO and carrier.')
                END AS message,
                COUNT(*) AS message_count
            FROM
                vw_rev_assurance_list_view_with_count
            WHERE
              carrier_last_status_date BETWEEN %s AND %s
            GROUP BY
                service_provider, message
            ORDER BY
                service_provider, message_count DESC;
        """
        params = [start_date, end_date_parsed.strftime("%Y-%m-%d")]
    else:
        query = """
            SELECT
                service_provider,
                CASE
                    WHEN LOWER(device_status) = '' THEN CONCAT('Device not in Rev.IO, but ', 'activated', ' in carrier.')
                    WHEN LOWER(rev_io_status) = 'deactivated' THEN CONCAT('Device is Deactivated in Rev.IO, but ', device_status, ' in carrier.')
                    WHEN LOWER(device_status) = 'deactivated' THEN CONCAT('Device is Deactivated in carrier, but ', 'activated', ' in Rev.IO.')
                    ELSE CONCAT('Device is ', device_status, ' in both Rev.IO and carrier.')
                END AS message,
                COUNT(*) AS message_count
            FROM
                vw_rev_assurance_list_view_with_count
            WHERE
                service_provider = %s AND carrier_last_status_date BETWEEN %s AND %s
            GROUP BY
                service_provider, message
            ORDER BY
                service_provider, message_count DESC;
        """
        params = [service_provider, start_date, end_date_parsed.strftime("%Y-%m-%d")]

    try:
        # Execute the query
        res = database.execute_query(query, params=params)

        # If the result is not empty
        if isinstance(res, pd.DataFrame) and not res.empty:
            # Initialize a dictionary to hold the data
            grouped_data = {}

            # Group the data by service provider
            for row in res.to_dict("records"):
                provider = row["service_provider"]
                message = row["message"]
                message_count = row["message_count"]

                # If the provider is not in the dictionary, initialize it
                if provider not in grouped_data:
                    grouped_data[provider] = {"provider": provider, "messages": {}}

                # Add the message count under the provider
                grouped_data[provider]["messages"][message] = message_count

            # Prepare the final response
            response = {
                "title": "Rev Assurance-Record Discrepancies",
                "chart_type": "bar_two",
                "flag": True,
                "data": list(grouped_data.values()),
                "xField": "Service Provider",
                "yField": "No.of records",
                "height": 400,
                "width": 800,
            }
        else:
            # Handle case where no data is found
            response = {
                "flag": True,  # Flag is True to indicate the request was successful
                "title": "Rev Assurance-Record Discrepancies",
                "chart_type": "bar_two",
                "data": [],  # Empty data array
                "xField": "Service Provider",  # Column name for x-axis
                "yField": "No.of records",  # Column name for y-axis
                "height": 400,
                "width": 800,
            }
    except Exception as e:
        logging.exception(f"###Exception occurred:{e}")
        response = {
            "flag": True,  # Flag is True to indicate the request was successful
            "title": "Rev Assurance-Record Discrepancies",
            "chart_type": "bar_two",
            "data": [],  # Empty data array
            "xField": "Service Provider",  # Column name for x-axis
            "yField": "No.of records",  # Column name for y-axis
            "height": 400,
            "width": 800,
        }

    return response



def daily_sync_card(data):
    """
    Fetches the sync status details for migrations from the database and formats the result.

    Args:
        data (dict): A dictionary containing the following keys:
            - service_provider (str): The service_provider for filtering service provider's.
            - start_date (str): The start date for filtering records (format: YYYY-MM-DD).
            - end_date (str): The end date for filtering records (format: YYYY-MM-DD).

    Returns:
        dict: Contains the formatted data for display in the desired structure.
    """
    logging.info(f"###Request Recieved for path daily_sync_card:{data}")
    columns = [
        {"title": "S. No", "dataIndex": "no", "key": "no", "width": "10%"},
        {
            "title": "Sync Name",
            "dataIndex": "syncName",
            "key": "syncName",
            "width": "25%",
        },
        {
            "title": "Sync Type",
            "dataIndex": "syncType",
            "key": "syncType",
            "width": "20%",
        },
        {"title": "Status", "dataIndex": "status", "key": "status", "width": "20%"},
        {
            "title": "Date and Time",
            "dataIndex": "dateTime",
            "key": "dateTime",
            "width": "25%",
        },
    ]
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    mg_database = DB("Migration_Test", **db_config)

    # Log the received input data for debugging
    logging.info(f"###Received data: {data}")

    # Ensure the end date includes the whole day by adding 1 day
    end_date_adjusted = (
        datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
    ).strftime("%Y-%m-%d")

    # Log the adjusted end date
    logging.info(f"###Adjusted end date: {end_date_adjusted}")

    # Base query with conditions, using placeholders for date range
    query = """
        SELECT
            migration_name AS "sync_status",
            CASE
                WHEN schedule_flag = TRUE AND reverse_sync = TRUE THEN 'Reverse Sync'
                WHEN schedule_flag = TRUE THEN 'Daily Sync'
                ELSE 'No Sync'
            END AS "sync_type",
            CASE
                WHEN status = 'true' THEN 'Success'
                WHEN status = 'false' THEN 'Failure'
                ELSE 'No Sync upto now'
            END AS "status",
            last_migrated_time AS "date_and_time"
        FROM public.migrations_altaworx_test
        WHERE to_database = 'altaworx_test' and last_migrated_time BETWEEN %s AND %s order by last_migrated_time desc;
    """

    # Log the query for debugging purposes
    logging.info(f"###Executing query: {query}")
    logging.info(f"###Using params: {start_date}, {end_date_adjusted}")

    params = [start_date, end_date_adjusted]

    try:
        # Execute the query with the parameters
        res = mg_database.execute_query(query, params=params)

        # Log the columns of the DataFrame to check their names
        logging.info(f"###Columns in the DataFrame: {res.columns}")

        # Strip any leading/trailing spaces in column names
        res.columns = res.columns.str.strip()

        # Log columns again after stripping spaces
        logging.info(f"###Columns after stripping spaces: {res.columns}")

        # If the result is not empty
        if isinstance(res, pd.DataFrame) and not res.empty:
            # Initialize a list to hold the formatted data
            formatted_data = []

            # Define columns dynamically
            columns = [
                {"title": "S. No", "dataIndex": "no", "key": "no", "width": "10%"},
                {
                    "title": "Sync Name",
                    "dataIndex": "syncName",
                    "key": "syncName",
                    "width": "25%",
                },
                {
                    "title": "Sync Type",
                    "dataIndex": "syncType",
                    "key": "syncType",
                    "width": "20%",
                },
                {
                    "title": "Status",
                    "dataIndex": "status",
                    "key": "status",
                    "width": "20%",
                },
                {
                    "title": "Date and Time",
                    "dataIndex": "dateTime",
                    "key": "dateTime",
                    "width": "25%",
                },
            ]

            # Iterate over the rows of the result and format dynamically
            for idx, row in res.iterrows():
                formatted_row = {
                    "key": str(idx + 1),  # Use index as key for each row
                    "no": idx + 1,
                    "syncName": row["sync_status"].replace("_", " ").title(),
                    "syncType": row["sync_type"],  # Match the column name exactly
                    "status": row["status"],  # Match the column name exactly
                    "dateTime": row["date_and_time"].strftime(
                        "%d/%m/%y %I:%M:%S %p"
                    ),  # Use strftime() directly
                }
                formatted_data.append(formatted_row)

            # Prepare the final response
            response = {
                "flag": True,
                "data": formatted_data,
                "columns": columns,
                "height": 400,
                "width": 800,
            }
        else:
            # Handle case where no data is found
            logging.warning(f"###No data found for the given criteria: {params}")
            response = {
                "flag": True,  # Flag is True to indicate the request was successful
                "data": [],  # Empty data array
                "columns": columns,  # Keep the column structure the same
                "height": 400,
                "width": 800,
            }
    except Exception as e:
        logging.exception(f"###Exception occurred: {e}")
        response = {
            "flag": True,  # Flag is True to indicate the request was successful
            "data": [],  # Empty data array
            "columns": columns,  # Keep the column structure the same
            "height": 400,
            "width": 800,
        }

    # Log the response for debugging
    # logging.info(f"Response: {response}")

    return response



def live_sessions_table(data):
    """
    Fetches the live session details from the database and formats the result.

    Args:
        data (dict): A dictionary containing the following keys:
            - service_provider (str): The service_provider for filtering service provider's.
            - start_date (str): The start date for filtering records (format: YYYY-MM-DD).
            - end_date (str): The end date for filtering records (format: YYYY-MM-DD).

    Returns:
        dict: Contains the formatted data for display in the desired structure.
    """
    logging.info(f"###Request Recieved for path live_sessions_table:{data}")
    columns = [
        {"title": "S. No", "dataIndex": "no", "key": "no", "width": "10%"},
        {
            "title": "Username",
            "dataIndex": "username",
            "key": "username",
            "width": "25%",
        },
        {"title": "Login", "dataIndex": "login", "key": "login", "width": "25%"},
        {"title": "Logout", "dataIndex": "logout", "key": "logout", "width": "20%"},
        {
            "title": "Last Request",
            "dataIndex": "lastRequest",
            "key": "lastRequest",
            "width": "20%",
        },
    ]
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    common_utils_database = DB("common_utils", **db_config)

    # Log the received input data for debugging
    #logging.info(f"###Received data: {data}")

    # Ensure the end date includes the whole day by adding 1 day
    end_date_adjusted = (
        datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
    ).strftime("%Y-%m-%d")

    # Log the adjusted end date
    logging.info(f"###Adjusted end date: {end_date_adjusted}")

    # Base query with conditions, using placeholders for date range
    query = """
                   WITH LatestSessions AS (
            SELECT username,
                   TO_CHAR(login::date, 'YYYY-MM-DD HH:SS') AS login,
                   TO_CHAR(logout::date, 'YYYY-MM-DD HH:SS') AS logout,
                   TO_CHAR(last_request::date, 'YYYY-MM-DD HH:SS') AS last_request,
                   ROW_NUMBER() OVER (PARTITION BY username ORDER BY last_request DESC) AS rn
            FROM public.live_sessions
            WHERE last_request BETWEEN %s AND %s
        )
        SELECT username, login, logout, last_request
        FROM LatestSessions
        WHERE rn = 1
        ORDER BY last_request DESC;
    """

    # Log the query for debugging purposes
    logging.info(f"###Executing query: {query}")
    logging.info(f"###Using params: {start_date}, {end_date_adjusted}")

    try:
        # Execute the query with the parameters
        res = common_utils_database.execute_query(
            query, params=[start_date, end_date_adjusted]
        )

        # Log the columns of the DataFrame to check their names
        logging.info(f"###Columns in the DataFrame: {res.columns}")

        # Strip any leading/trailing spaces in column names
        res.columns = res.columns.str.strip()

        # Log columns again after stripping spaces
        logging.info(f"###Columns after stripping spaces: {res.columns}")

        # If the result is not empty
        if isinstance(res, pd.DataFrame) and not res.empty:
            # Initialize a list to hold the formatted data
            formatted_data = []

            # Define columns dynamically
            columns = [
                {"title": "S. No", "dataIndex": "no", "key": "no", "width": "10%"},
                {
                    "title": "Username",
                    "dataIndex": "username",
                    "key": "username",
                    "width": "25%",
                },
                {
                    "title": "Login",
                    "dataIndex": "login",
                    "key": "login",
                    "width": "25%",
                },
                {
                    "title": "Logout",
                    "dataIndex": "logout",
                    "key": "logout",
                    "width": "20%",
                },
                {
                    "title": "Last Request",
                    "dataIndex": "lastRequest",
                    "key": "lastRequest",
                    "width": "20%",
                },
            ]

            # Iterate over the rows of the result and format dynamically
            for idx, row in res.iterrows():
                formatted_row = {
                    "key": str(idx + 1),  # Use index as key for each row
                    "no": idx + 1,
                    "username": row[
                        "username"
                    ],  # Column names should match the query result
                    "login": row["login"],
                    "logout": row["logout"],
                    "lastRequest": (
                        str(row["last_request"])
                        if isinstance(row["last_request"], pd.Timestamp)
                        else row["last_request"]
                    ),
                }
                formatted_data.append(formatted_row)

            # Prepare the final response
            response = {
                "flag": True,
                "data": formatted_data,
                "columns": columns,
                "height": 400,
                "width": 800,
            }
        else:
            # Handle case where no data is found
            logging.warning(
                f"###No data found for the given criteria: {start_date}, {end_date_adjusted}"
            )
            response = {
                "flag": True,  # Flag is True, since the structure is valid
                "data": [],  # Empty data array
                "columns": columns,  # Keep the column structure the same
                "height": 400,
                "width": 800,
            }
    except Exception as e:
        logging.exception(f"###Exception occurred: {e}")
        response = {
            "flag": True,  # Flag is True, since the structure is valid
            "data": [],  # Empty data array
            "columns": columns,  # Keep the column structure the same
            "height": 400,
            "width": 800,
        }

    # Log the response for debugging
    logging.info(f"###Response: {response}")

    return response


##one point o stat cards

##Helper Function
# Format large numbers in specific columns
def format_large_numbers(val):
    """ 
    Formats large numeric values with commas and appropriate decimal precision.
    """
    try:
        # Attempt to convert to float
        num = float(val)

        # Check if the number is an integer
        if num.is_integer():
            return "{:,.0f}".format(num)  # No decimal places for integers
        else:
            return "{:,.2f}".format(num)  # Two decimal places for floats
    except ValueError:
        # If conversion fails, return the value as is
        return val

# Custom function to format column names
def format_column_names(col_name):
    """
     Formats and humanizes a raw column name for better readability.
    """
    # Define replacements for specific substrings
    replacements = {
        'avgusagepertnmb': 'Avg Usage Per TN MB',
        'mb': 'MB',
        'tn': 'TN',
        'iccid': 'ICCID',
        'msisdn': 'MSISDN',
        # Add more replacements as needed
    }

    # Apply replacements to column name
    for old, new in replacements.items():
        col_name = col_name.replace(old, new)

    # Convert camelCase to "Test Ready" style (with spaces)
    col_name = re.sub(r'([a-z])([A-Z])', r'\1 \2', col_name)

    # Return the formatted column name with title case
    return col_name.title()

##helper function to download blob
def dataframe_to_blob(data_frame):
    '''
    Description:The Function is used to convert the dataframe to blob
    '''
    # Create a BytesIO buffer
    bio = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(bio, engine='openpyxl') as writer:
        data_frame.to_excel(writer, index=False)

    # Get the value from the buffer
    bio.seek(0)
    blob_data = base64.b64encode(bio.read())
    return blob_data

##1st card
def get_usage_details_card(data):
    """
    Fetches and returns usage data for the usage details card.

    Depending on the input, it:
    - Retrieves usage trends from monthly views for a tenant and service provider.
    - Combines and processes the data to return either JSON for charts or a downloadable Excel blob.
    - Supports both 'All Service Providers' and specific providers.

    Args:
        data (dict): Input data with keys like 'db_name', 'partner', 'service_providers', and 'action'.

    Returns:
        dict: A response with:
            - 'flag': True if data is found or download is successful, otherwise False.
            - 'usage_details_card': A list of monthly usage info (if not downloading).
            - 'blob': A base64 string of Excel data (only if action is 'download').
    """
    logging.info(f"###Request Recieved for path get_usage_details_card:{data}")
    service_provider = data.get('service_providers', '')
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id']
        )
    tenant_id = tenant_details['id'].values[0]
    tenant_id  = int(tenant_id)
    action = data.get('action', '')
    if service_provider=='All':
        query = f'''
        SELECT
            portal_type_id,
            bill_year,
            bill_month,
            service_provider_id,
            total_cards,
            total_usage_bytes,
            total_usage_mb
        FROM
            public.vw_device_usage_trend_by_month
            WHERE tenant_id = {tenant_id}
        UNION ALL
        SELECT
            portal_type_id,
            bill_year,
            bill_month,
            service_provider_id,
            total_cards,
            total_usage_bytes,
            total_usage_mb
        FROM
            public.vw_mobility_device_usage_trend_by_month
            WHERE tenant_id = {tenant_id}
        '''
    else:
        query = f'''
                SELECT *
            FROM (
                SELECT
                    portal_type_id,
                    bill_year,
                    bill_month,
                    service_provider_id,
                    service_provider,
                    total_cards,
                    total_usage_bytes,
                    total_usage_mb
                FROM
                    public.vw_device_usage_trend_by_month
                UNION ALL
                SELECT
                    portal_type_id,
                    bill_year,
                    bill_month,
                    service_provider_id,
                    NULL AS service_provider,
                    total_cards,
                    total_usage_bytes,
                    total_usage_mb
                FROM
                    public.vw_mobility_device_usage_trend_by_month
            ) AS combined_data
            WHERE service_provider = '{service_provider}' AND tenant_id = {tenant_id};

        '''
    try:
        df = database.execute_query(query, True)

        if df.empty:
            logging.info("###No usage details data found for the query{df}")
            return {"flag": False, "usage_details_card": []}

        if action == 'download':
            if service_provider=='All':
                export_query=f'''WITH CombinedData AS (
                    SELECT
                        bill_year,
                        bill_month,
                        service_provider_id,
                        total_cards,
                        total_usage_mb,
                        total_usage_mb / NULLIF(total_cards, 0) AS avg_usage_per_tn_mb
                    FROM
                        (
                            SELECT
                                bill_year,
                                bill_month,
                                service_provider_id,
                                total_cards,
                                total_usage_mb
                            FROM
                                public.vw_device_usage_trend_by_month
                            UNION ALL
                            SELECT
                                bill_year,
                                bill_month,
                                service_provider_id,
                                total_cards,
                                total_usage_mb
                            FROM
                                public.vw_mobility_device_usage_trend_by_month
                        ) AS Combined
                    WHERE
                        (bill_year, bill_month) >= (
                            SELECT EXTRACT(YEAR FROM CURRENT_DATE - INTERVAL '12 months'),
                                EXTRACT(MONTH FROM CURRENT_DATE - INTERVAL '12 months')
                        )
                ),
                AggregatedData AS (
                    SELECT
                        TO_CHAR(TO_DATE(bill_year::text || '-' || bill_month::text, 'YYYY-MM'), 'Mon YYYY') AS month,
                        SUM(total_usage_mb) AS total_usage_mb,
                        SUM(total_usage_mb) / NULLIF(SUM(total_cards), 0) AS avg_usage_per_tn_mb
                    FROM
                        CombinedData
                    GROUP BY
                        bill_year, bill_month
                )
                SELECT
                    month,
                    ROUND(avg_usage_per_tn_mb, 2) AS AvgUsagePerTNMB,
                    ROUND(total_usage_mb, 2) AS TotalUsageMB,
                    'All Service Providers' AS ServiceProvider
                FROM
                    AggregatedData
                ORDER BY
                    TO_DATE(month, 'Mon YYYY') DESC
                LIMIT 12;

                '''
            else:
                export_query=f'''
                        WITH CombinedData AS (
                            SELECT
                                bill_year,
                                bill_month,
                                service_provider_id,
                                total_cards,
                                total_usage_mb,
                                total_usage_mb / NULLIF(total_cards, 0) AS avg_usage_per_tn_mb,
                                service_provider  -- Assuming this column exists in the first view
                            FROM
                                public.vw_device_usage_trend_by_month
                            WHERE
                                (bill_year, bill_month) >= (
                                    SELECT EXTRACT(YEAR FROM CURRENT_DATE - INTERVAL '12 months'),
                                        EXTRACT(MONTH FROM CURRENT_DATE - INTERVAL '12 months')
                                )
                            UNION ALL
                            SELECT
                                bill_year,
                                bill_month,
                                service_provider_id,
                                total_cards,
                                total_usage_mb,
                                total_usage_mb / NULLIF(total_cards, 0) AS avg_usage_per_tn_mb,
                                NULL AS service_provider  -- Adding NULL for service_provider in the second query
                            FROM
                                public.vw_mobility_device_usage_trend_by_month
                            WHERE
                                (bill_year, bill_month) >= (
                                    SELECT EXTRACT(YEAR FROM CURRENT_DATE - INTERVAL '12 months'),
                                        EXTRACT(MONTH FROM CURRENT_DATE - INTERVAL '12 months')
                                )
                        ),
                        FilteredData AS (
                            SELECT
                                bill_year,
                                bill_month,
                                service_provider_id,
                                total_cards,
                                total_usage_mb,
                                avg_usage_per_tn_mb,
                                service_provider
                            FROM
                                CombinedData
                            WHERE
                                service_provider = '{service_provider}'  -- Filter by service provider name
                        ),
                        AggregatedData AS (
                            SELECT
                                TO_CHAR(TO_DATE(bill_year::text || '-' || bill_month::text, 'YYYY-MM'), 'Mon YYYY') AS month,
                                SUM(total_usage_mb) AS total_usage_mb,
                                SUM(total_usage_mb) / NULLIF(SUM(total_cards), 0) AS avg_usage_per_tn_mb
                            FROM
                                FilteredData
                            GROUP BY
                                bill_year, bill_month
                        )
                        SELECT
                            month,
                            ROUND(avg_usage_per_tn_mb, 2) AS AvgUsagePerTNMB,
                            ROUND(total_usage_mb, 2) AS TotalUsageMB,
                            '{service_provider}' AS ServiceProvider
                        FROM
                            AggregatedData
                        ORDER BY
                            TO_DATE(month, 'Mon YYYY') DESC
                        LIMIT 12;

                '''
            expot_df=database.execute_query(export_query,True)
            if expot_df.empty:
                blob_data = generate_empty_excel()
                # Return JSON response for empty Excel
                response = {
                    'flag': True,
                    'blob': blob_data.decode('utf-8'),  # If you need a decoded version
                    'message': 'No data available. Empty Excel generated.'
                }
                return response
            logging.info(f"###Download action requested{export_df}")
            expot_df.columns = [format_column_names(col) for col in expot_df.columns]
            #expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]
            expot_df.replace(to_replace='None', value='', inplace=True)
            expot_df = expot_df.astype(str)
            columns_to_format = [col for col in expot_df.columns if col.lower() != "iccid"]
            expot_df[columns_to_format] = expot_df[columns_to_format].applymap(format_large_numbers)

            # Format column names (remove underscores and make them readable)
            expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]

            blob_data = dataframe_to_blob(expot_df)
            logging.info(f"###Blob data prepared for download:{blob_data}")
            return {"flag": True, "blob": blob_data.decode('utf-8')}

        usage_data = df.to_dict(orient='records')

        # Filter valid records
        usage_data = [
            record for record in usage_data
            if record.get('bill_year') is not None and record.get('bill_month') is not None
        ]

        # Sort and group by (BillYear * 100) + BillMonth
        usage_data_by_month = sorted(
            usage_data,
            key=lambda x: (int(x['bill_year']) * 100) + int(x['bill_month']),
            reverse=True
        )

        grouped_data = groupby(
            usage_data_by_month,
            key=lambda x: (int(x['bill_year']) * 100) + int(x['bill_month'])
        )

        data_point_limit = 12
        limited_data = []

        for key, group in grouped_data:
            group_list = list(group)
            total_cards = sum(item['total_cards'] for item in group_list)
            total_usage_bytes = sum(item['total_usage_bytes'] for item in group_list)
            total_usage_mb = sum(item['total_usage_mb'] for item in group_list)

            avg_usage_per_card_bytes = total_usage_bytes / total_cards if total_cards != 0 else 0
            avg_usage_per_card_mb = total_usage_mb / total_cards if total_cards != 0 else 0

            limited_data.append({
                "Id": key,
                "BillYear": int(group_list[0]['bill_year']),
                "BillMonth": int(group_list[0]['bill_month']),
                "TotalCards": total_cards,
                "TotalUsageBytes": total_usage_bytes,
                "TotalUsageMB": total_usage_mb,
                "AvgUsagePerCardBytes": avg_usage_per_card_bytes,
                "AvgUsagePerCardMB": avg_usage_per_card_mb,
                "ServiceProvider": group_list[0]['service_provider_id']
            })

            if len(limited_data) >= data_point_limit:
                break

        # Sort the last 12 months' data in ascending order
        limited_data = sorted(
            limited_data,
            key=lambda x: (x['BillYear'], x['BillMonth'])
        )

        # Prepare final result
        result = [
            {
                "name": pd.Timestamp(year=int(item['BillYear']), month=int(item['BillMonth']), day=1).strftime("%b %Y"),
                "usagePerTN": item['AvgUsagePerCardMB'],
                "dataUsageByMonth": item['TotalUsageMB']
            }
            for item in limited_data
        ]

        response = {"flag": True, "usage_details_card": result}
        logging.info(f"###Response prepared successfully for last 12 months in ascending order: {response}")
        return response

    except Exception as e:
        logging.error(f"###Error processing usage data: {str(e)}")
        return {"flag": False, "usage_details_card": []}




##2nd card
def get_device_status_card(data):
    """
    Fetches and formats device status data for the device status card.

    This function queries device status trends by month for a tenant, either across all service providers
    or a specific one. It supports both normal chart data retrieval and downloadable Excel blob generation.

    Args:
        data (dict): Input containing:
            - 'db_name' (str): The tenant database name.
            - 'service_providers' (str): Specific service provider name or 'All'.
            - 'action' (str): 'download' to trigger Excel blob generation.

    Returns:
        dict: A response with:
            - 'flag': Always True if the operation (data fetch or download) is successful.
            - 'device_status_card_data': A list of monthly device status info (only if action is not 'download').
            - 'blob': A base64-encoded Excel string (only if action is 'download').
            - 'message': An optional message if no data is available for download.
            
        Returns an empty list if an exception occurs.

    """
    logging.info(f"###Request Recieved for path get_device_status_card:{data}")
 
    service_provider = data.get('service_providers', '')
    action = data.get('action', '')
    ##Database connection
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    # Dynamically adjust query based on service_provider presence
    if service_provider=='All':
        query = '''
        SELECT
            SUM(activated_count) AS activated_count,
            SUM(activation_ready_count) AS activation_ready_count,
            SUM(deactivated_count) AS deactivated_count,
            SUM(inventory_count) AS inventory_count,
            SUM(test_ready_count) AS test_ready_count,
            (SUM(activated_count) + SUM(activation_ready_count) + SUM(deactivated_count) +
             SUM(inventory_count) + SUM(test_ready_count)) AS total_count,
            bill_year,
            bill_month
        FROM
            public.vw_device_status_trend_by_month
        GROUP BY
            bill_year, bill_month
        ORDER BY
            bill_year DESC, bill_month DESC
        '''
    else:
        query = f'''
        SELECT
            SUM(activated_count) AS activated_count,
            SUM(activation_ready_count) AS activation_ready_count,
            SUM(deactivated_count) AS deactivated_count,
            SUM(inventory_count) AS inventory_count,
            SUM(test_ready_count) AS test_ready_count,
            (SUM(activated_count) + SUM(activation_ready_count) + SUM(deactivated_count) +
             SUM(inventory_count) + SUM(test_ready_count)) AS total_count,
            bill_year,
            bill_month
        FROM
            public.vw_device_status_trend_by_month
        WHERE
            service_provider = '{service_provider}'
        GROUP BY
            bill_year, bill_month
        ORDER BY
            bill_year DESC, bill_month DESC
        '''


    try:
        # Execute the query and fetch the data
        df = database.execute_query(query, True)
        # Handle the case where no data is returned by sending default zeroes
        if df.empty:
            return [{'month': f'{pd.Timestamp(year=year, month=month, day=1).strftime("%b %Y")}',
                     'Active': 0, 'ActivationReady': 0, 'Inventory': 0,
                     'TestReady': 0, 'Deactivated': 0, 'TotalTNs': 0}
                    for year, month in [(2024, m) for m in range(1, 13)]]
        if action=='download':
            if service_provider=='All':
                export_query=f'''
                    SELECT
                    TO_CHAR(TO_DATE(bill_year::text || '-' || bill_month::text, 'YYYY-MM'), 'Mon YYYY') AS Month,  -- Format Month as Jan 2025
                    COALESCE(SUM(activated_count), 0) AS Active,
                    COALESCE(SUM(activation_ready_count), 0) AS ActivationReady,
                    COALESCE(SUM(inventory_count), 0) AS InventoryStatus,
                    COALESCE(SUM(test_ready_count), 0) AS TestReady,
                    COALESCE(SUM(deactivated_count), 0) AS Deactivated,
                    COALESCE(SUM(activated_count) + SUM(activation_ready_count) + SUM(deactivated_count) +
                            SUM(inventory_count) + SUM(test_ready_count), 0) AS TotalTNs,
                    'All Service Providers' AS ServiceProvider  -- This will be displayed for all service providers
                FROM
                    public.vw_device_status_trend_by_month
                WHERE
                    bill_year IS NOT NULL AND bill_month IS NOT NULL  -- Ensure valid year-month combinations
                GROUP BY
                    bill_year, bill_month
                ORDER BY
                    bill_year DESC, bill_month DESC limit 12;

                '''
            else:
                export_query=f'''
                        SELECT
                            TO_CHAR(TO_DATE(bill_year::text || '-' || bill_month::text, 'YYYY-MM'), 'Mon YYYY') AS Month,  -- Format Month as Jan 2025
                            COALESCE(SUM(activated_count), 0) AS Active,
                            COALESCE(SUM(activation_ready_count), 0) AS ActivationReady,
                            COALESCE(SUM(inventory_count), 0) AS InventoryStatus,
                            COALESCE(SUM(test_ready_count), 0) AS TestReady,
                            COALESCE(SUM(deactivated_count), 0) AS Deactivated,
                            COALESCE(SUM(activated_count) + SUM(activation_ready_count) + SUM(deactivated_count) +
                                    SUM(inventory_count) + SUM(test_ready_count), 0) AS TotalTNs,
                            '{service_provider}' AS ServiceProvider  -- Dynamically replace with the provided service provider
                        FROM
                            public.vw_device_status_trend_by_month
                        WHERE
                            bill_year IS NOT NULL
                            AND bill_month IS NOT NULL  -- Ensure valid year-month combinations
                            AND service_provider = '{service_provider}'  -- Filter by the service provider (replace placeholder with actual value)
                        GROUP BY
                            bill_year, bill_month
                        ORDER BY
                            bill_year DESC, bill_month DESC
                        LIMIT 12;

                '''

            expot_df=database.execute_query(export_query,True)
            if expot_df.empty:
                blob_data = generate_empty_excel()
                # Return JSON response for empty Excel
                response = {
                    'flag': True,
                    'blob': blob_data.decode('utf-8'),  # If you need a decoded version
                    'message': 'No data available. Empty Excel generated.'
                }
                return response
            logging.info(f"###Download action requested:{export_df}")
            expot_df.columns = [format_column_names(col) for col in expot_df.columns]
            #expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]
            expot_df.replace(to_replace='None', value='', inplace=True)
            expot_df = expot_df.astype(str)
            # Apply formatting to all cells
            # Apply formatting to all cells
            columns_to_format = [col for col in expot_df.columns if col.lower() != "iccid"]
            expot_df[columns_to_format] = expot_df[columns_to_format].applymap(format_large_numbers)

            # Format column names (remove underscores and make them readable)
            expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]

            blob_data = dataframe_to_blob(expot_df)
            logging.info(f"###Blob data prepared for download:{blob_data}")
            return {"flag": True, "blob": blob_data.decode('utf-8')}
        # Drop rows with None in bill_year or bill_month
        df_cleaned = df.dropna(subset=['bill_year', 'bill_month'])
        # Sort values by bill_year and bill_month if not done in SQL
        monthly_sum = df_cleaned.sort_values(by=['bill_year', 'bill_month'], ascending=[True, True])

        # Get the most recent 12 months of data
        if len(monthly_sum) > 12:
            monthly_sum = monthly_sum.tail(12)

        # Prepare the result list in the required format
        result = [
            {
                'month': f'{pd.Timestamp(year=int(row.bill_year), month=int(row.bill_month), day=1).strftime("%b %Y")}',
                'Active': int(row['activated_count']),
                'ActivationReady': int(row['activation_ready_count']),
                'Inventory': int(row['inventory_count']),
                'TestReady': int(row['test_ready_count']),
                'Deactivated': int(row['deactivated_count']),
                'TotalTNs': int(row['total_count']),
            }
            for _, row in monthly_sum.iterrows()
        ]
        # Return the formatted result
        response={"flag":True,"device_status_card_data":result}
        return response
    except Exception as e:
        logging.exception(f"###Exception is {e}")
        return []

##combined high usage chart

def get_high_usage_chart_data(data):
    """
    Fetches high-usage device data for a tenant, returning either chart data or an Excel blob for download.

    Queries the device usage views (`vw_device_high_usage_scatter_chart` and `vw_mobility_device_high_usage_scatter_charts`)
    to retrieve the top 10 devices by data usage, optionally filtered by service provider.

    Args:
        data (dict): Includes:
            - 'db_name': Tenant database name.
            - 'service_providers': Specific provider name or 'All'.
            - 'partner': Tenant (partner) name.
            - 'action': Optional; if 'download', returns Excel-formatted data.

    Returns:
        dict:on success:
         High usage data for chart display or Excel download blob.
        On failure or no data:
            {'flag': False, 'rate_plan_data': []}
    """
    logging.info(f"###Request Recieved for path get_high_usage_chart_data:{data}")
    service_provider = data.get('service_providers', '')
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id']
        )
    tenant_id = tenant_details['id'].values[0]
    tenant_id  = int(tenant_id)
    action = data.get('action', '')
    try:
        # Dynamically adjust query based on service_provider presence
        if service_provider=='All':
            query=f'''SELECT
                        iccid,
                        ctd_data_usage_mb,
                        ctd_session_count
                    FROM (
                        SELECT DISTINCT ON (iccid)
                            iccid,
                            ctd_data_usage_mb,
                            ctd_session_count
                        FROM
                            public.vw_device_high_usage_scatter_chart
                        WHERE tenant_id={tenant_id}

                        UNION ALL

                        SELECT DISTINCT ON (iccid)
                            iccid,
                            ctd_data_usage_mb,
                            ctd_session_count
                        FROM
                            public.vw_mobility_device_high_usage_scatter_charts
                        WHERE tenant_id={tenant_id}
                    ) AS combined_results
                    ORDER BY
                        ctd_data_usage_mb DESC
                    LIMIT 10;
            '''
        else:
            query = f'''
                    SELECT
                        iccid,
                        ctd_data_usage_mb,
                        ctd_session_count
                    FROM (
                        SELECT DISTINCT ON (iccid)
                            iccid,
                            ctd_data_usage_mb,
                            ctd_session_count
                        FROM
                            public.vw_device_high_usage_scatter_chart WHERE service_provider_name = '{service_provider}'
                            AND tenant_id={tenant_id}

                        UNION ALL

                        SELECT DISTINCT ON (iccid)
                            iccid,
                            ctd_data_usage_mb,
                            ctd_session_count
                        FROM
                            public.vw_mobility_device_high_usage_scatter_charts  WHERE service_provider_name = '{service_provider}'
                            AND tenant_id={tenant_id}
                    ) AS combined_results
                    ORDER BY
                        ctd_data_usage_mb DESC
                    LIMIT 10;
                '''


        if action == 'download':
            if service_provider=='All':
                export_query=f'''SELECT
                        iccid,
                        ctd_data_usage_mb,
                        ctd_session_count,service_provider_name
                    FROM (
                        SELECT DISTINCT ON (iccid)
                            iccid,
                            ctd_data_usage_mb,
                            ctd_session_count,service_provider_name
                        FROM
                            public.vw_device_high_usage_scatter_chart
                        WHERE tenant_id={tenant_id}

                        UNION ALL

                        SELECT DISTINCT ON (iccid)
                            iccid,
                            ctd_data_usage_mb,
                            ctd_session_count,service_provider_name
                        FROM
                            public.vw_mobility_device_high_usage_scatter_charts
                        WHERE tenant_id={tenant_id}
                    ) AS combined_results
                    ORDER BY
                        ctd_data_usage_mb DESC
                    LIMIT 10;
                '''
            else:
                export_query=f'''SELECT
                            iccid,
                            ctd_data_usage_mb,
                            ctd_session_count,service_provider_name
                        FROM (
                            SELECT DISTINCT ON (iccid)
                                iccid,
                                ctd_data_usage_mb,
                                ctd_session_count,service_provider_name
                            FROM
                                public.vw_device_high_usage_scatter_chart WHERE service_provider_name = '{service_provider}'
                                AND tenant_id={tenant_id}

                            UNION ALL

                            SELECT DISTINCT ON (iccid)
                                iccid,
                                ctd_data_usage_mb,
                                ctd_session_count,service_provider_name
                            FROM
                                public.vw_mobility_device_high_usage_scatter_charts  WHERE service_provider_name = '{service_provider}'
                                AND tenant_id={tenant_id}
                        ) AS combined_results
                        ORDER BY
                            ctd_data_usage_mb DESC
                        LIMIT 10;
                '''
            expot_df=database.execute_query(export_query,True)
            if expot_df.empty:
                blob_data = generate_empty_excel()
                # Return JSON response for empty Excel
                response = {
                    'flag': True,
                    'blob': blob_data.decode('utf-8'),  # If you need a decoded version
                    'message': 'No data available. Empty Excel generated.'
                }
                return response
            #logging.info(f"###Download action requested:{export_df}")
            expot_df.columns = [format_column_names(col) for col in expot_df.columns]
            #expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]
            expot_df.replace(to_replace='None', value='', inplace=True)
            expot_df = expot_df.astype(str)
            # Apply formatting to all cells
            columns_to_format = [col for col in expot_df.columns if col.lower() != "iccid"]
            expot_df[columns_to_format] = expot_df[columns_to_format].applymap(format_large_numbers)

            # Format column names (remove underscores and make them readable)
            expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]

            blob_data = dataframe_to_blob(expot_df)
            #logging.info(f"###Blob data prepared for download:{blob_data}")
            return {"flag": True, "blob": blob_data.decode('utf-8')}
        data=database.execute_query(query,True)
        if data.empty:
            response={"flag":True,"high_usage_chart_card_data":[]}
            return response

        data=data.to_dict(orient='records')
        # Sample transformation logic in Python
        unique_data = {}



        # Loop through the database result
        for item in data:
            usage = item['ctd_data_usage_mb']
            session = item['ctd_session_count']
            iccid = item['iccid']

            # Only store the first occurrence of each data usage, adjusting session and iccid if needed
            if usage not in unique_data:
                unique_data[usage] = {'session': session, 'iccid': iccid}

        # Convert back to a list of dictionaries
        transformed_data = [{'usage': k, 'session': v['session'], 'iccid': v['iccid']} for k, v in unique_data.items()]
        response = {"flag": True, "high_usage_chart_card_data": transformed_data}
        return response
    except Exception as e:
        logging.exception(f"###Exception is {e}")
        message=f'Error processing high usage chart data: {str(e)}'
        return {"flag":True,"high_usage_chart_card_data":[],"message":message}


##3rd chart card
def getm2m_high_usage_chart_data(data):
    """
    Retrieves M2M high usage chart data for a tenant and optionally generates a downloadable Excel report.

    This function fetches data from a high-usage scatter chart view for a given tenant,
    optionally filtered by service provider. If `action` is set to `'download'`, an Excel
    blob of the dataset is returned. For chart rendering, it returns a simplified list of 
    unique usage-session pairs, deduplicated by usage value.

    Args:
        data (dict): Input containing:
            - 'db_name' (str): Name of the tenant's database.
            - 'partner' (str): Tenant (partner) name.
            - 'service_providers' (str): Specific service provider or 'All'.
            - 'action' (str, optional): 'download' to trigger Excel blob generation.

   
    Returns:
        dict: Contains either:
        on success:
            - 'm2m_high_usage_chart_data' for chart display, or
            - 'blob' for Excel download.
        On failure or no data:
            {'flag': False, 'rate_plan_data': []}
    """
    logging.info(f"###Request Recieved for path getm2m_high_usage_chart_data:{data}")
    service_provider = data.get('service_providers', '')
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id']
        )
    tenant_id = tenant_details['id'].values[0]
    tenant_id  = int(tenant_id)
    action = data.get('action', '')
    # Dynamically adjust query based on service_provider presence
    if service_provider=='All':
        query=f'''SELECT DISTINCT ON (iccid)
            iccid,
            ctd_data_usage_mb,
            ctd_session_count
        FROM
            public.vw_device_high_usage_scatter_chart
        WHERE tenant_id={tenant_id}
        ORDER BY
            iccid,
            ctd_data_usage_mb DESC,
            ctd_session_count ASC;
        '''
    else:
        query = f'''
            SELECT DISTINCT ON (iccid)
            iccid,
            ctd_data_usage_mb,
            ctd_session_count
        FROM
            public.vw_device_high_usage_scatter_chart
            WHERE service_provider_name = '{service_provider}'
            AND tenant_id={tenant_id}
            ORDER BY ctd_data_usage_mb DESC, ctd_session_count ASC;
            '''


    if action == 'download':
        if service_provider=='All':
            export_query=f'''SELECT DISTINCT ON (iccid)
                iccid,
                ctd_data_usage_mb,
                ctd_session_count,
                service_provider_name
            FROM
                public.vw_device_high_usage_scatter_chart
            WHERE tenant_id={tenant_id}
            ORDER BY
                iccid,
                ctd_data_usage_mb DESC,
                ctd_session_count ASC;
            '''
        else:
            export_query=f'''SELECT DISTINCT ON (iccid)
                iccid,
                ctd_data_usage_mb,
                ctd_session_count,
                service_provider_name
            FROM
                public.vw_device_high_usage_scatter_chart where service_provider_name='{service_provider}' AND tenant_id={tenant_id}

            ORDER BY
                iccid,
                ctd_data_usage_mb DESC,
                ctd_session_count ASC;
            '''
        expot_df=database.execute_query(export_query,True)
        if expot_df.empty:
            blob_data = generate_empty_excel()
            # Return JSON response for empty Excel
            response = {
                'flag': True,
                'blob': blob_data.decode('utf-8'),  # If you need a decoded version
                'message': 'No data available. Empty Excel generated.'
            }
            return response
        #logging.info(f"###Download action requested:{export_df}")
        expot_df.columns = [format_column_names(col) for col in expot_df.columns]
        #expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]
        expot_df.replace(to_replace='None', value='', inplace=True)
        expot_df = expot_df.astype(str)
        # Apply formatting to all cells
        columns_to_format = [col for col in expot_df.columns if col.lower() != "iccid"]
        expot_df[columns_to_format] = expot_df[columns_to_format].applymap(format_large_numbers)

        # Format column names (remove underscores and make them readable)
        expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]

        blob_data = dataframe_to_blob(expot_df)
        #logging.info(f"###Blob data prepared for download:{blob_data}")
        return {"flag": True, "blob": blob_data.decode('utf-8')}
    data=database.execute_query(query,True)
    if data.empty:
        response={"flag":True,"m2m_high_usage_chart_data":[]}
        return response

    data=data.to_dict(orient='records')
    # Sample transformation logic in Python
    unique_data = {}



    # Loop through the database result
    for item in data:
        usage = item['ctd_data_usage_mb']
        session = item['ctd_session_count']

        # Only store the first occurrence of each data usage, adjusting session if needed
        if usage not in unique_data:
            unique_data[usage] = session

    # Convert back to a list of dictionaries
    transformed_data = [{'usage': k, 'session': v} for k, v in unique_data.items()]
    response={"flag":True,"m2m_high_usage_chart_data":transformed_data}
    return response

#4th card
def get_customer_rate_plan_data(data):
    """
    Fetches rate plan usage data for a tenant with optional Excel export.

    Aggregates SIM counts by data plan size (`plan_mb`) from both mobility and M2M views.
    If `action` is 'download', returns an Excel blob of summarized data grouped by service provider.

    Args:
        data (dict): Contains 'db_name', 'partner', 'service_providers', optional 'plan_type', and optional 'action'.

    Returns:
        dict: Contains either:
        on success:
            - 'rate_plan_data' for chart display, or
            - 'blob' for Excel download.
        On failure or no data:
            {'flag': False, 'rate_plan_data': []}
    """
    logging.info(f"###Request Recieved for path get_customer_rate_plan_data:{data}")
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id']
        )
    tenant_id = tenant_details['id'].values[0]
    tenant_id  = int(tenant_id)
    """
    Fetch rate plan data for carrier_rate_plan or customer_rate_plan based on plan_type.

    Params:
        data: dict containing 'service_provider' (optional)
        plan_type: str, either 'carrier' or 'customer' to specify the query source
    """
    service_provider = data.get('service_providers', '')
    plan_type = data.get('plan_type', 'customer')
    # Select the correct table/view based on plan_type
    action=data.get('action','')
    mobility_view_name = 'public.vw_mobility_sim_cards_by_customer_rate_plan_limit_report'
    m2m_view_name = 'public.vw_smi_sim_cards_by_customer_rate_plan_limit_report'
    if service_provider=='All':
        # SQL query to fetch SIM card details with optional service provider filter
        query = f'''
                    SELECT
                    plan_mb,
                    SUM(total_sim_count) AS total_sim_count, -- Summing total_sim_count from both subqueries
                    SUM(sim_count) AS sim_count,
                    SUM(ctd_session_count) AS ctd_session_count
                FROM (
                    -- First subquery
                    SELECT
                        plan_mb,
                        COUNT(*) AS total_sim_count, -- Count of total SIMs in this group
                        SUM(sim_count) AS sim_count,
                        SUM(ctd_session_count) AS ctd_session_count
                    FROM
                        {mobility_view_name}
                    WHERE
                        portal_type_id = 2
                        AND tenant_id = {tenant_id}
                    GROUP BY
                        plan_mb

                    UNION ALL

                    -- Second subquery
                    SELECT
                        plan_mb,
                        COUNT(*) AS total_sim_count, -- Count of total SIMs in this group
                        SUM(sim_count) AS sim_count,
                        SUM(ctd_session_count) AS ctd_session_count
                    FROM
                        {m2m_view_name}
                    WHERE
                        portal_type_id = 0
                        AND tenant_id = {tenant_id}
                    GROUP BY
                        plan_mb
                ) AS combined_results
                GROUP BY
                    plan_mb
                ORDER BY
                    plan_mb;
        '''
    else:
        query=f'''
                    SELECT
                    plan_mb,
                    SUM(total_sim_count) AS total_sim_count, -- Summing total_sim_count from both subqueries
                    SUM(sim_count) AS sim_count,
                    SUM(ctd_session_count) AS ctd_session_count
                FROM (
                    -- First subquery
                    SELECT
                        plan_mb,
                        COUNT(*) AS total_sim_count, -- Count of total SIMs in this group
                        SUM(sim_count) AS sim_count,
                        SUM(ctd_session_count) AS ctd_session_count
                    FROM
                        {mobility_view_name}
                    WHERE
                        portal_type_id = 2 AND service_provider_name = '{service_provider}'
                        AND tenant_id = {tenant_id}
                    GROUP BY
                        plan_mb

                    UNION ALL

                    -- Second subquery
                    SELECT
                        plan_mb,
                        COUNT(*) AS total_sim_count, -- Count of total SIMs in this group
                        SUM(sim_count) AS sim_count,
                        SUM(ctd_session_count) AS ctd_session_count
                    FROM
                        {m2m_view_name}
                    WHERE
                        portal_type_id = 0 AND service_provider_name = '{service_provider}'
                        AND tenant_id = {tenant_id}
                    GROUP BY
                        plan_mb
                ) AS combined_results
                GROUP BY
                    plan_mb
                ORDER BY
                    plan_mb;
        '''

    try:
        # Execute the query and fetch the data
        df = database.execute_query(query, True)
        # Handle case where no data is returned
        if df.empty:
            response={"flag":False,"rate_plan_data":[]}
            return response
        if action == 'download':
            if service_provider=='All':
                export_query=f'''SELECT
                                plan_mb,
                                SUM(sim_count) AS total_tns, -- Summing sim_count as total_tns
                                STRING_AGG(DISTINCT service_provider_name, ', ') AS service_provider_names -- Combine distinct service provider names
                                FROM (
                                -- First subquery
                                SELECT
                                    plan_mb,
                                    SUM(sim_count) AS sim_count, -- Summing sim_count
                                    service_provider_name
                                FROM
                                     {mobility_view_name}
                                WHERE
                                    portal_type_id = 2
                                    AND tenant_id = {tenant_id}
                                GROUP BY
                                    plan_mb, service_provider_name
                                UNION ALL
                                -- Second subquery
                                SELECT
                                    plan_mb,
                                    SUM(sim_count) AS sim_count, -- Summing sim_count
                                    service_provider_name
                                FROM
                                    {m2m_view_name}
                                WHERE
                                    portal_type_id = 0
                                    AND tenant_id = {tenant_id}
                                GROUP BY
                                    plan_mb, service_provider_name
                                ) AS combined_results
                                GROUP BY
                                plan_mb
                                ORDER BY
                                plan_mb;
                            '''
            else:
                export_query=f'''SELECT
                                plan_mb,
                                SUM(sim_count) AS total_tns, -- Summing sim_count as total_tns
                                STRING_AGG(DISTINCT service_provider_name, ', ') AS service_provider_names -- Combine distinct service provider names
                                FROM (
                                -- First subquery
                                SELECT
                                    plan_mb,
                                    SUM(sim_count) AS sim_count, -- Summing sim_count
                                    service_provider_name
                                FROM
                                     {mobility_view_name}
                                WHERE
                                    portal_type_id = 2
                                    AND tenant_id = {tenant_id}
                                GROUP BY
                                    plan_mb, service_provider_name
                                UNION ALL
                                -- Second subquery
                                SELECT
                                    plan_mb,
                                    SUM(sim_count) AS sim_count, -- Summing sim_count
                                    service_provider_name
                                FROM
                                    {m2m_view_name}
                                WHERE
                                    portal_type_id = 0 AND service_provider_name = '{service_provider}'
                                    AND tenant_id = {tenant_id}
                                GROUP BY
                                    plan_mb, service_provider_name
                                ) AS combined_results
                                GROUP BY
                                plan_mb
                                ORDER BY
                                plan_mb;
                            '''
            expot_df=database.execute_query(export_query,True)
            if expot_df.empty:
                blob_data = generate_empty_excel()
                # Return JSON response for empty Excel
                response = {
                    'flag': True,
                    'blob': blob_data.decode('utf-8'),  # If you need a decoded version
                    'message': 'No data available. Empty Excel generated.'
                }
                return response
            #logging.info(f"###Download action requested:{export_df}")
            expot_df.columns = [format_column_names(col) for col in expot_df.columns]
            #expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]
            expot_df.replace(to_replace='None', value='', inplace=True)
            expot_df = expot_df.astype(str)
            # Apply formatting to all cells
            # Apply formatting to all cells
            columns_to_format = [col for col in expot_df.columns if col.lower() != "iccid"]
            expot_df[columns_to_format] = expot_df[columns_to_format].applymap(format_large_numbers)

            # Format column names (remove underscores and make them readable)
            expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]

            blob_data = dataframe_to_blob(expot_df)
            #logging.info(f"###Blob data prepared for download:{blob_data}")
            return {"flag": True, "blob": blob_data.decode('utf-8')}
        # Prepare the result in the desired format
        result = [
            {
                "dataLimit": str(row['plan_mb']),
                "tnCount": row['sim_count']
            }
            for _, row in df.iterrows()
        ]

        # Display the results
        response={"flag":True,"rate_plan_data":result}
        return response
    except Exception as e:
        response={"flag":False,"rate_plan_data":[]}
        return response

##5th card
def get_carrier_rate_plan_data(data):
    """
    Fetches SIM count by data limit from carrier/customer rate plans, with optional Excel export.

    Combines data from mobility and M2M views for a tenant and service provider. If `action` is 
    'download', returns an Excel blob; otherwise, returns data limits and SIM counts.

    Args:
        data (dict): Includes 'db_name', 'partner', 'service_providers', 'plan_type', and optional 'action'.

    Returns:
        dict: On success:
            - 'rate_plan_data' for chart display, or
            - 'blob' for Excel download.
        On failure or no data:
            {'flag': False, 'rate_plan_data': []}

           
    """
    logging.info(f"###Request Recieved for path get_carrier_rate_plan_data:{data}")
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    action=data.get('action','')
    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id']
        )
    tenant_id = tenant_details['id'].values[0]
    tenant_id  = int(tenant_id)
    """
    Fetch rate plan data for carrier_rate_plan or customer_rate_plan based on plan_type.

    Params:
        data: dict containing 'service_provider' (optional)
        plan_type: str, either 'carrier' or 'customer' to specify the query source
    """
    service_provider = data.get('service_providers', '')
    plan_type = data.get('plan_type', 'customer')
    # Select the correct table/view based on plan_type
    mobility_view_name = 'public.vw_mobility_sim_cards_by_carrier_rate_plan_limit_report'
    m2m_view_name = 'public.vw_smi_sim_cards_by_carrier_rate_plan_limit_report'

    if service_provider=='All':
        # SQL query to fetch SIM card details with optional service provider filter
        query = f'''
                    SELECT
                    plan_mb,
                    SUM(total_sim_count) AS total_sim_count, -- Summing total_sim_count from both subqueries
                    SUM(sim_count) AS sim_count,
                    SUM(ctd_session_count) AS ctd_session_count
                FROM (
                    -- First subquery
                    SELECT
                        plan_mb,
                        COUNT(*) AS total_sim_count, -- Count of total SIMs in this group
                        SUM(sim_count) AS sim_count,
                        SUM(ctd_session_count) AS ctd_session_count
                    FROM
                        {mobility_view_name}
                    WHERE
                        portal_type_id = 2
                        AND tenant_id = {tenant_id}
                    GROUP BY
                        plan_mb

                    UNION ALL

                    -- Second subquery
                    SELECT
                        plan_mb,
                        COUNT(*) AS total_sim_count, -- Count of total SIMs in this group
                        SUM(sim_count) AS sim_count,
                        SUM(ctd_session_count) AS ctd_session_count
                    FROM
                        {m2m_view_name}
                    WHERE
                        portal_type_id = 0
                        AND tenant_id = {tenant_id}
                    GROUP BY
                        plan_mb
                ) AS combined_results
                GROUP BY
                    plan_mb
                ORDER BY
                    plan_mb;
        '''
    else:
        # SQL query to fetch SIM card details with optional service provider filter
        query = f'''
                    SELECT
                    plan_mb,
                    SUM(total_sim_count) AS total_sim_count, -- Summing total_sim_count from both subqueries
                    SUM(sim_count) AS sim_count,
                    SUM(ctd_session_count) AS ctd_session_count
                FROM (
                    -- First subquery
                    SELECT
                        plan_mb,
                        COUNT(*) AS total_sim_count, -- Count of total SIMs in this group
                        SUM(sim_count) AS sim_count,
                        SUM(ctd_session_count) AS ctd_session_count
                    FROM
                        {mobility_view_name}
                    WHERE
                        portal_type_id = 2 AND service_provider_name = '{service_provider}'
                        AND tenant_id = {tenant_id}
                    GROUP BY
                        plan_mb

                    UNION ALL

                    -- Second subquery
                    SELECT
                        plan_mb,
                        COUNT(*) AS total_sim_count, -- Count of total SIMs in this group
                        SUM(sim_count) AS sim_count,
                        SUM(ctd_session_count) AS ctd_session_count
                    FROM
                        {m2m_view_name}
                    WHERE
                        portal_type_id = 0 AND service_provider_name = '{service_provider}'
                        AND tenant_id = {tenant_id}
                    GROUP BY
                        plan_mb
                ) AS combined_results
                GROUP BY
                    plan_mb
                ORDER BY
                    plan_mb;
        '''
    try:
        # Execute the query and fetch the data
        df = database.execute_query(query, True)
        # Handle case where no data is returned
        if df.empty:
            response={"flag":False,"rate_plan_data":[]}
            return response
        if action == 'download':
            if service_provider=='All':
                export_query=f'''SELECT
                                plan_mb,
                                SUM(sim_count) AS total_tns, -- Summing sim_count as total_tns
                                STRING_AGG(DISTINCT service_provider_name, ', ') AS service_provider_names -- Combine distinct service provider names
                                FROM (
                                -- First subquery
                                SELECT
                                    plan_mb,
                                    SUM(sim_count) AS sim_count, -- Summing sim_count
                                    service_provider_name
                                FROM
                                     {mobility_view_name}
                                WHERE
                                    portal_type_id = 2
                                    AND tenant_id = {tenant_id}
                                GROUP BY
                                    plan_mb, service_provider_name
                                UNION ALL
                                -- Second subquery
                                SELECT
                                    plan_mb,
                                    SUM(sim_count) AS sim_count, -- Summing sim_count
                                    service_provider_name
                                FROM
                                    {m2m_view_name}
                                WHERE
                                    portal_type_id = 0
                                    AND tenant_id = {tenant_id}
                                GROUP BY
                                    plan_mb, service_provider_name
                                ) AS combined_results
                                GROUP BY
                                plan_mb
                                ORDER BY
                                plan_mb;
                            '''
            else:
                export_query=f'''SELECT
                                plan_mb,
                                SUM(sim_count) AS total_tns, -- Summing sim_count as total_tns
                                STRING_AGG(DISTINCT service_provider_name, ', ') AS service_provider_names -- Combine distinct service provider names
                                FROM (
                                -- First subquery
                                SELECT
                                    plan_mb,
                                    SUM(sim_count) AS sim_count, -- Summing sim_count
                                    service_provider_name
                                FROM
                                     {mobility_view_name}
                                WHERE
                                    portal_type_id = 2
                                    AND tenant_id = {tenant_id}
                                GROUP BY
                                    plan_mb, service_provider_name
                                UNION ALL
                                -- Second subquery
                                SELECT
                                    plan_mb,
                                    SUM(sim_count) AS sim_count, -- Summing sim_count
                                    service_provider_name
                                FROM
                                    {m2m_view_name}
                                WHERE
                                    portal_type_id = 0 AND service_provider_name = '{service_provider}'
                                    AND tenant_id = {tenant_id}
                                GROUP BY
                                    plan_mb, service_provider_name
                                ) AS combined_results
                                GROUP BY
                                plan_mb
                                ORDER BY
                                plan_mb;
                            '''
            expot_df=database.execute_query(export_query,True)
            if expot_df.empty:
                blob_data = generate_empty_excel()
                # Return JSON response for empty Excel
                response = {
                    'flag': True,
                    'blob': blob_data.decode('utf-8'),  # If you need a decoded version
                    'message': 'No data available. Empty Excel generated.'
                }
                return response
            #logging.info(f"###Download action requested:{export_df}")
            expot_df.columns = [format_column_names(col) for col in expot_df.columns]
            #expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]
            expot_df.replace(to_replace='None', value='', inplace=True)
            expot_df = expot_df.astype(str)
            # Apply formatting to all cells
            columns_to_format = [col for col in expot_df.columns if col.lower() != "iccid"]
            expot_df[columns_to_format] = expot_df[columns_to_format].applymap(format_large_numbers)

            # Format column names (remove underscores and make them readable)
            expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]

            blob_data = dataframe_to_blob(expot_df)
            #logging.info(f"###Blob data prepared for download:{blob_data}")
            return {"flag": True, "blob": blob_data.decode('utf-8')}
        # Prepare the result in the desired format
        result = [
            {
                "dataLimit": str(row['plan_mb']),
                "tnCount": row['sim_count']
            }
            for _, row in df.iterrows()
        ]

        # Display the results
        response={"flag":True,"rate_plan_data":result}
        return response
    except Exception as e:
        response={"flag":False,"rate_plan_data":[]}
        return response


##8th card

def mobility_high_usage_chart(data):
    """
    Generates a high-usage scatter chart or downloadable Excel for mobility SIM data usage.

    Identifies SIMs exceeding 50% of their plan usage. If `action` is 'download', returns a formatted 
    Excel blob of high-usage SIMs; otherwise, returns distinct usage vs. percent-used data points 
    for plotting.

    Args:
        data (dict): Input with keys:
            - db_name (str): Tenant database name.
            - partner (str): Tenant name.
            - service_providers (str): Specific provider name or 'All'.
            - action (str): 'download' to trigger Excel blob response.

    Returns:
        dict:
            - On succcess:
                - 'flag': True, 'mobility_high_usage_chart': list of usage data or 'blob' for Excel.
            - On failure or no data:
                {'flag': False, 'mobility_high_usage_chart': []}
  
    """
    logging.info(f"###Request Recieved for path mobility_high_usage_chart:{data}")

    tenant_database = data.get('db_name', '')
    database = DB(tenant_database, **db_config)
    service_provider = data.get('service_providers', '')
    action = data.get('action', '')
    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id']
        )
    tenant_id = tenant_details['id'].values[0]
    tenant_id  = int(tenant_id)

    # Determine the query based on service provider
    if service_provider:
        query = f'''
            SELECT *
                FROM (
                SELECT
                ctd_data_usage_mb,msisdn,ctd_session_count,
                (CASE
                    WHEN plan_limit_mb > 0 THEN (ctd_data_usage_mb / plan_limit_mb * 100)
                    ELSE 0
                END) AS percentage
                FROM
                public.vw_mobility_device_high_usage_scatter_charts
                ) subquery
                WHERE percentage > 50
                AND tenant_id = {tenant_id}
                ORDER BY
                ctd_data_usage_mb ASC,
                ctd_session_count DESC;
        '''
        logging.info(f"###Query defined with service provider filter:{service_provider}")
    else:
        query = f'''
            SELECT *
                FROM (
                SELECT
                ctd_data_usage_mb,msisdn,ctd_session_count,
                (CASE
                    WHEN plan_limit_mb > 0 THEN (ctd_data_usage_mb / plan_limit_mb * 100)
                    ELSE 0
                END) AS percentage
                FROM
                public.vw_mobility_device_high_usage_scatter_charts
                ) subquery
                WHERE percentage > 50
                AND tenant_id = {tenant_id}
                ORDER BY
                ctd_data_usage_mb ASC,
                ctd_session_count DESC;
        '''
        logging.info(f"###Query defined without service provider filter:{service_provider}")

    try:
        logging.info(f"###Executing query to fetch high usage data:{query}")
        # Execute the query and fetch the data (assuming DataFrame is returned)
        if action=='download':
            if service_provider=='All':
                export_query=f'''
                    SELECT *
                    FROM (
                        SELECT
                        msisdn as servicenumber,
                            ctd_data_usage_mb as datausagemb,


                            (CASE
                                WHEN plan_limit_mb > 0 THEN (ctd_data_usage_mb / plan_limit_mb * 100)
                                ELSE 0
                            END) AS percentage,service_provider_name as serviceprovider
                        FROM
                            public.vw_mobility_device_high_usage_scatter_charts
                    ) subquery
                    WHERE percentage > 50
                    AND tenant_id = {tenant_id}
                    ORDER BY
                        datausagemb ASC,
                        percentage DESC;  -- Sorted by data usage and percentage

                '''
            else:
                export_query=f'''
                    SELECT *
                    FROM (
                        SELECT
                        msisdn as servicenumber,
                            ctd_data_usage_mb as datausagemb,


                            (CASE
                                WHEN plan_limit_mb > 0 THEN (ctd_data_usage_mb / plan_limit_mb * 100)
                                ELSE 0
                            END) AS percentage,service_provider_name as serviceprovider
                        FROM
                            public.vw_mobility_device_high_usage_scatter_charts WHERE
                service_provider_name = '{service_provider}'
                    ) subquery
                    WHERE percentage > 50
                    AND tenant_id = {tenant_id}
                    ORDER BY
                        datausagemb ASC,
                        percentage DESC;  -- Sorted by data usage and percentage
                    '''

            logging.info(f"###Download action requested:{export_query}")
            expot_df=database.execute_query(export_query,True)
            if expot_df.empty:
                blob_data = generate_empty_excel()
                # Return JSON response for empty Excel
                response = {
                    'flag': True,
                    'blob': blob_data.decode('utf-8'),  # If you need a decoded version
                    'message': 'No data available. Empty Excel generated.'
                }
                return response
            #logging.info(f"###Download action requested:{export_df}")
            expot_df.replace(to_replace='None', value='', inplace=True)
            expot_df = expot_df.astype(str)
            # Apply formatting to all cells
            columns_to_format = [col for col in expot_df.columns if col.lower() not in ["iccid", "servicenumber"]]
            expot_df[columns_to_format] = expot_df[columns_to_format].applymap(format_large_numbers)

            # Format column names (remove underscores and make them readable)
            expot_df.columns = [col.replace('_', ' ').title() for col in expot_df.columns]

            blob_data = dataframe_to_blob(expot_df)
            #logging.info(f"###Blob data prepared for download:{blob_data}")
            return {"flag": True, "blob": blob_data.decode('utf-8')}

        data = database.execute_query(query, True)

        # If data is empty, return empty response
        if data.empty:
            logging.info(f"###No data found for the query:{data}")
            return {"flag": True, "mobility_high_usage_chart": []}
        # Convert DataFrame to dictionary records
        data = data.to_dict(orient='records')

        # Create a dictionary to store unique usage and session data
        unique_data = {}

        # Loop through each item in the data
        for item in data:
            usage = item['ctd_data_usage_mb']
            session = item['percentage']

            # Only store the first occurrence of each data usage, adjusting session if needed
            if usage not in unique_data:
                unique_data[usage] = session
            logging.info(f"###Unique data filtered and stored:{usage} with session {session}")

        # Convert the unique data dictionary back to a list of dictionaries
        transformed_data = [{'usage': k, 'percentUsed': v} for k, v in unique_data.items()]
        logging.info(f"###Data transformed successfully for response:{transformed_data}")

        # Create and return the response
        response = {"flag": True, "mobility_high_usage_chart": transformed_data}
        logging.info(f"###Response prepared successfully: {response}")
        return response

    except Exception as e:
        logging.exception(f"###An error occurred: {e}")
        return {"flag": False, "mobility_high_usage_chart": []}



def mobility_usage_per_customer_pool(data):
    """
    Fetches and returns the top 12 customer rate pools with the highest data usage percentage 
    for a given tenant, optionally filtered by service provider.

    If `action` is 'download', returns a base64-encoded Excel blob for the data; otherwise, 
    returns a formatted list of pool names and their usage percentages for chart rendering.

    Args:
        data (dict): Input dictionary with keys:
            - db_name (str): Name of the tenant's database.
            - partner (str): Tenant name (e.g., 'Altaworx Test' normalized to 'Altaworx').
            - service_providers (str): Service provider name or 'All'.
            - action (str): If 'download', returns Excel blob instead of chart data.

    Returns:
        dict:
            - On success:
                - 'flag': True, 'mobility_usage_per_customer_pool': list of pool data or 'blob' for Excel.
            - On failure or no data:
                {'flag': False, 'message': str(e), 'mobility_usage_per_customer_pool': []}
    """
    logging.info(f"###Request Recieved for path mobility_usage_per_customer_pool:{data}")
    tenant_database = data.get('db_name', '')
    database = DB(tenant_database, **db_config)
    service_provider = data.get('service_providers', '')
    action = data.get('action', '')
    tenant_name = data.get("partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_details=common_utils_database.get_data(
        "tenant",{"tenant_name":tenant_name},['id','parent_tenant_id']
        )
    tenant_id = tenant_details['id'].values[0]
    tenant_id  = int(tenant_id)

    # Determine the query based on service provider
    if service_provider=='All':
        query = f'''
            SELECT
                customer_rate_pool_id,
                customer_rate_pool_name,
                service_provider_name,
                MAX(customer_rate_pool_data_usage_percentage) AS customer_rate_pool_data_usage_percentage
            FROM
                public.vw_mobility_usage_by_customer_pools
                WHERE tenant_id = {tenant_id}
            GROUP BY
                customer_rate_pool_id,
                customer_rate_pool_name,
                service_provider_name
            ORDER BY
                customer_rate_pool_data_usage_percentage DESC
            LIMIT 12;
        '''

    else:
        query = f'''
           SELECT
                customer_rate_pool_id,
                customer_rate_pool_name,
                service_provider_name,
                MAX(customer_rate_pool_data_usage_percentage) AS customer_rate_pool_data_usage_percentage
            FROM
                public.vw_mobility_usage_by_customer_pools
            WHERE
                service_provider_name = '{service_provider}'
                AND tenant_id = {tenant_id}
            GROUP BY
                customer_rate_pool_id,
                customer_rate_pool_name,
                service_provider_name
            ORDER BY
                customer_rate_pool_data_usage_percentage DESC
            LIMIT 12;
        '''
    try:
        # Execute the query and fetch the data (assuming DataFrame is returned)
        data = database.execute_query(query, True)
        if action=='download':
            if data.empty:
                blob_data = generate_empty_excel()
                # Return JSON response for empty Excel
                response = {
                    'flag': True,
                    'blob': base64.b64encode(blob_data).decode('utf-8'),
                    'message': 'No data available. Empty Excel generated.'
                }
                return response
            data.columns = [
                col.replace('_', ' ').title() for col in data.columns
            ]
                # Proceed with the export if row count is within the allowed limit
            data = data.astype(str)
            data.replace(to_replace='None', value='', inplace=True)

            blob_data = dataframe_to_blob(data)
            # Return JSON response
            response = {
                'flag': True,
                'blob': blob_data.decode('utf-8')
            }
            return response
        # If data is empty, return empty response
        if data.empty:
            return {"flag": True, "mobility_usage_per_customer_pool": []}
        # Convert DataFrame to dictionary records
        data = data.to_dict(orient='records')

        # Create a list to store the formatted data
        formatted_data = []

        # Loop through each item in the data and format it as required
        for item in data:
            pool_name = item['customer_rate_pool_name']
            usage_percentage = item['customer_rate_pool_data_usage_percentage']

            # Append the formatted data as a dictionary
            formatted_data.append({
                'name': pool_name,
                'value': usage_percentage
            })

        # Create and return the response
        response = {"flag": True, "mobility_usage_per_customer_pool": formatted_data}
        return response

    except Exception as e:
        logging.exception(f"###An error occurred: {e}")
        message=f"Exception is {e}"
        return {"flag": False,"message":message, "mobility_usage_per_customer_pool": []}

def mobility_usage_per_group_pool(data):
    """
    Retrieves top 12 group/pool entries with the highest data usage percentages 
    for a given service provider from the mobility usage group pool view.

    If `action` is 'download', the function returns an Excel blob of the data.
    Otherwise, it formats the top entries into a name/value pair structure 
    for chart consumption.

    Args:
        data (dict): Dictionary with keys:
            - db_name (str): Name of the tenant database.
            - service_providers (str): Specific service provider name or 'All'.
            - action (str): If set to 'download', exports results as Excel blob.

    Returns:
        dict:
            - On success:
                - 'flag': True, 'mobility_usage_per_group_pool': list of formatted data or 'blob' for Excel.
            - On failure or no data:
                {'flag': False, 'mobility_usage_per_group_pool': []}
    """
    logging.info(f"###Request Recieved for path mobility_usage_per_group_pool:{data}")
    tenant_database = data.get('db_name', '')
    database = DB(tenant_database, **db_config)
    service_provider = data.get('service_providers', '')
    action = data.get('action', '')

    # Determine the query based on service provider
    if service_provider=='All':
        query = '''
            SELECT
                foundation_account_number,
                data_group_id,
                pool_id,
                Billing_account_number,
                MAX(data_usage_percentage) AS data_usage_percentage,
                MAX(data_group_device_count) AS data_group_device_count,
                MAX(pool_device_count) AS pool_device_count
            FROM
                public.vw_mobility_usage_by_group_pools
            WHERE service_provider_name = 'AT&T - Telegence - UAT ONLY'  and
                data_usage_percentage IS NOT NULL
                AND (data_group_device_count > 0 OR pool_device_count > 0)
            GROUP BY
                foundation_account_number, data_group_id, pool_id, Billing_account_number
            LIMIT 12;
        '''

        logging.info(f"###Query defined with service provider filter: {service_provider}")
    else:
        query = f'''
            SELECT
                foundation_account_number,
                data_group_id,
                pool_id,
                Billing_account_number,
                MAX(data_usage_percentage) AS data_usage_percentage,
                MAX(data_group_device_count) AS data_group_device_count,
                MAX(pool_device_count) AS pool_device_count
            FROM
                public.vw_mobility_usage_by_group_pools
            WHERE
                service_provider_name = '{service_provider}'  -- Filter by customer_name when service_provider is provided
                AND data_usage_percentage IS NOT NULL
                AND (data_group_device_count > 0 OR pool_device_count > 0)
            GROUP BY
                foundation_account_number, data_group_id, pool_id, Billing_account_number
            LIMIT 12;
        '''

        logging.info(f"###Query defined without service provider filter:{service_provider}")

    try:
        # Execute the query and fetch the data (assuming DataFrame is returned)
        data = database.execute_query(query, True)
        if action=='download':
            logging.info(f"###Download action requested:{data}")
            if data.empty:
                logging.info(f"###No data available for download; generating empty Excel:{data}")

                blob_data = generate_empty_excel()
                # Return JSON response for empty Excel
                response = {
                    'flag': True,
                    'blob': blob_data.decode('utf-8'),  # If you need a decoded version
                    'message': 'No data available. Empty Excel generated.'
                }
                return response
            data.columns = [
                col.replace('_', ' ').title() for col in data.columns
            ]
            logging.info(f"###Data columns formatted for export:{data}")
                # Proceed with the export if row count is within the allowed limit
            data = data.astype(str)
            data.replace(to_replace='None', value='', inplace=True)

            blob_data = dataframe_to_blob(data)
            logging.info(f"###Blob data prepared for download:{blob_data}")
            # Return JSON response
            response = {
                'flag': True,
                'blob': blob_data.decode('utf-8')
            }
            return response
        logging.info(f"###Executing query to fetch mobility usage data:{data}")


        # If data is empty, return empty response
        if data.empty:
            logging.info(f"###No data found for the query:{data}")
            return {"flag": True, "mobility_usage_per_group_pool": []}
        # Convert DataFrame to dictionary records
        data = data.to_dict(orient='records')

        # Create a list to store the formatted data
        formatted_data = []

        # Loop through each item in the data and format it as required
        for item in data:
            # Use 'data_group_id' if present, otherwise use 'pool_id'
            pool_name = item['data_group_id'] if item['data_group_id'] else item['pool_id']
            usage_percentage = item['data_usage_percentage']

            # Append the formatted data as a dictionary in the required format
            formatted_data.append({
                'name': pool_name,
                'value': usage_percentage
            })
        #logging.info(f"###Data formatted successfully for response:{formatted_data}")

        # Create and return the response
        response = {"flag": True, "mobility_usage_per_group_pool": formatted_data}
        #logging.info(f"###Response prepared successfully: {response}")
        return response

    except Exception as e:
        logging.exception(f"###An error occurred: {e}")
        return {"flag": True, "mobility_usage_per_group_pool": []}




def generate_empty_excel():
    """
    Generates an empty Excel file with a placeholder sheet using openpyxl.
    """
    # Create a workbook and an empty worksheet
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Sheet1"  # Set the sheet name

    # Save the workbook to a BytesIO bufferr
    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()







def get_rate_plan_data(data):
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    """
    Fetch rate plan data for carrier_rate_plan or customer_rate_plan based on plan_type.

    Params:
        data: dict containing 'service_provider' (optional)
        plan_type: str, either 'carrier' or 'customer' to specify the query source
    """
    logging.info(f"###Request Recieved for path get_rate_plan_data:{data}")
    service_provider = data.get('service_provider', '')
    plan_type = data.get('plan_type', 'customer')
    # Select the correct table/view based on plan_type
    if plan_type == 'carrier':
        mobility_view_name = 'public.vw_mobility_sim_cards_by_carrier_rate_plan_limit_report'
        m2m_view_name = 'public.vw_smi_sim_cards_by_carrier_rate_plan_limit_report'

    elif plan_type == 'customer':
        mobility_view_name = 'public.vw_mobility_sim_cards_by_customer_rate_plan_limit_report'
        m2m_view_name = 'public.vw_smi_sim_cards_by_customer_rate_plan_limit_report'
    else:
        raise ValueError("Invalid plan_type. Must be either 'carrier' or 'customer'.")

    # SQL query to fetch SIM card details with optional service provider filter
    query = f'''
                SELECT
                plan_mb,
                SUM(total_sim_count) AS total_sim_count, -- Summing total_sim_count from both subqueries
                SUM(sim_count) AS sim_count,
                SUM(ctd_session_count) AS ctd_session_count
            FROM (
                -- First subquery
                SELECT
                    plan_mb,
                    COUNT(*) AS total_sim_count, -- Count of total SIMs in this group
                    SUM(sim_count) AS sim_count,
                    SUM(ctd_session_count) AS ctd_session_count
                FROM
                    {mobility_view_name}
                WHERE
                    portal_type_id = 2
                GROUP BY
                    plan_mb

                UNION ALL

                -- Second subquery
                SELECT
                    plan_mb,
                    COUNT(*) AS total_sim_count, -- Count of total SIMs in this group
                    SUM(sim_count) AS sim_count,
                    SUM(ctd_session_count) AS ctd_session_count
                FROM
                    {m2m_view_name}
                WHERE
                    portal_type_id = 0
                GROUP BY
                    plan_mb
            ) AS combined_results
            GROUP BY
                plan_mb
            ORDER BY
                plan_mb;
    '''

    # Add service_provider filter if provided
    if service_provider:
        query += f" WHERE service_provider_name = '{service_provider}'"
    try:
        # Execute the query and fetch the data
        df = database.execute_query(query, True)
        # Handle case where no data is returned
        if df.empty:
            response={"flag":False,"rate_plan_data":[]}
            return response

        # Prepare the result in the desired format
        result = [
            {
                "dataLimit": str(row['plan_mb']),
                "tnCount": row['sim_count']
            }
            for _, row in df.iterrows()
        ]

        # Display the results
        response={"flag":True,"rate_plan_data":result}
        return response
    except Exception as e:
        response={"flag":False,"rate_plan_data":[]}
        return response


