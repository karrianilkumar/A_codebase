"""
main.py

Module for handling API requests and routing them to the appropriate function.

Functions:
- lambda_handler(event,context=None)

Author: Srikanth R
Date: December 26, 2024
"""

import json
import time
import os
import boto3
import pytz
import datetime
from datetime import datetime, timedelta
from common_utils.email_trigger import get_memory_usage, memory_sns
from dashboards import (
       total_payments, ar_aging_pie, outstanding_table, total_bill_line_graph, total_bill_by_ledger_bar,bp_dashboards, collections_summary
)
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging
from common_utils.authentication_check import validate_token, Validate_Ui_token
from common_utils.permission_manager import PermissionManager
from common_utils.authentication_check import get_client_id


# Dictionary to store database configuration settings retrieved from environment variables.
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema":False
}
logging = Logging(name="main")

# Initialize the SNS client
sns = boto3.client("sns")
cloudwatch = boto3.client("cloudwatch")


def lambda_handler(event, context):
    """
    Handles incoming API requests and routes them to the appropriate function.

    Args:
        event (dict): The incoming API request event.

    Returns:
        dict: A dictionary containing the response status code and body.

    Example:
        >>> event = {'data': {'path': '/get_modules'}}
        >>> lambda_handler(event)
        {'statusCode': 200, 'body': '{"flag": True, "modules": [...]}'}
    """
    function_name = context.function_name if context else "sim_management"
    logging.info("Lambda function started: %s", function_name)

    # Record the start time of the function
    performance_matrix = {}
    start_time = time.time()
    performance_matrix["start_time"] = (
        f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time))}."
        f"{int((start_time % 1) * 1000):03d}"
    )

    # Extract the HTTP method, path and query string parameters from the event
    data = event.get("data")
    print('####data',data)
    if not data:
        return {"message": "No details provided or Invalid details", "status_code": 400}

    if data:
        try:
            data = data
        except json.JSONDecodeError:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid JSON in body"}),
            }
    else:
        data = {}

    if "data" in data:
        print('###entred into if')
        data = data.get("data")

    service_path = event.get("path")
    if service_path:
        data["path"] = service_path

    path = data.get("path")
    print('###path',path)

    result = {}
    # token validation
    verified_request = True
    access_token = data.get("z_access_token", "")
    ui_token = data.get("access_token", "")

    if not access_token and not ui_token:
        result = {"message": "MISSING TOKEN"}
        result["status_code"] = 401
        verified_request = False

    if access_token:
        client_id = get_client_id(access_token)
        data["client_id"] = client_id
    if access_token and not validate_token(access_token):
        client_id = get_client_id(access_token)
        data["client_id"] = client_id
        result = {"message": "INVALID TOKEN"}
        result["status_code"] = 401
        verified_request = False

    # username = data.get('username')
    # elif ui_token and not Validate_Ui_token(username,access_token) and verified_request:
    #     result = {"message": "INVALID TOKEN"}
    #     result["status_code"] = 401
    #     verified_request=False

    # Capture the hit time when the request is received (same as before)
    hit_time = time.time()
    hit_time_formatted = datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
        "%Y-%m-%d %H:%M:%S"
    )
    logging.info(
        f"Hit Time: {hit_time_formatted}, Request Received at: {hit_time_formatted}"
    )

    request_received_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info("Routing request for path: %s", path)
    # Route based on the path and method
    if path=='/total_payments':
        result=total_payments(data)
    elif path=='/ar_aging_pie':
        result=ar_aging_pie(data)
    elif path == "/outstanding_table":
        result = outstanding_table(data)
    elif path == "/total_bill_line_graph":
        result = total_bill_line_graph(data)
    elif path == "/total_bill_by_ledger_bar":
        result = total_bill_by_ledger_bar(data)
    elif path == "/bp_dashboards":
        result = bp_dashboards(data)    
    elif path == "/collections_summary":
        result = collections_summary(data)
    else:
        result = {"error": "Invalid path or method"}
        logging.warning("Invalid path or method requested: %s", path)

    # database Connection
    if result.get("flag") == False:
        common_utils_database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
        status_code = 400  # You can change this to an appropriate error code
        logging.error("Error in result: %s", result)
        # Sending email
        result_response = send_email("Exception Mail")
        if isinstance(result, dict) and result.get("flag") is False:
            logging.info(result)
        else:
            to_emails, cc_emails, subject, body, from_email, partner_name = (
                result_response
            )
            common_utils_database.update_dict(
                "email_templates",
                {"last_email_triggered_at": request_received_at},
                {"template_name": "Exception Mail"},
            )
            query = """
                SELECT parents_module_name, sub_module_name, child_module_name, partner_name
                FROM email_templates
                WHERE template_name = 'Exception Mail'
            """
            # Execute the query and fetch the result
            email_template_data = common_utils_database.execute_query(query, True)
            if not email_template_data.empty:
                # Unpack the results
                (
                    parents_module_name,
                    sub_module_name,
                    child_module_name,
                    partner_name,
                ) = email_template_data.iloc[0]
            else:
                # If no data is found, assign default values or log an error
                parents_module_name = ""
                sub_module_name = ""
                child_module_name = ""
                partner_name = ""

            # Email audit logging
            error_message = result.get(
                "error", "Unknown error occurred"
            )  # Extracting the error message
            email_audit_data = {
                "template_name": "Exception Mail",
                "email_type": "Application",
                "partner_name": partner_name,
                "email_status": "success",
                "from_email": from_email,
                "to_email": to_emails,
                "cc_email": cc_emails,
                "comments": f"{path} - Error: {error_message}",  # Adding error message to comments
                "subject": subject,
                "body": body,
                "action": "Email triggered",
                "parents_module_name": parents_module_name,
                "sub_module_name": sub_module_name,
                "child_module_name": child_module_name,
            }
            common_utils_database.update_audit(email_audit_data, "email_audit")

    else:
        status_code = 200

    # Capture the request completion time in IST
    request_completed_time = time.time()
    request_completed_time_formatted = datetime.now(
        pytz.timezone("Asia/Kolkata")
    ).strftime("%Y-%m-%d %H:%M:%S")

    # Calculate the time difference between hit time and request completed time
    time_taken = round(
        request_completed_time - hit_time, 4
    )  # Round to 4 decimal places
    logging.info(
        f"Request Completed: {request_completed_time_formatted}, Time Taken: {time_taken} seconds"
    )

    # Record the end time of the function
    end_time = time.time()
    performance_matrix["end_time"] = (
        f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
    )
    performance_matrix["execution_time"] = f"{end_time - start_time:.4f}"
    logging.info(
        f"Request processed at {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
    )

    performance_matrix["execution_time"] = f"{end_time - start_time:.4f} seconds"
    logging.info(f"Function performance_matrix: {performance_matrix} seconds")
    logging.info(
        "Lambda function execution completed in %.4f seconds", end_time - start_time
    )

    memory_limit = int(context.memory_limit_in_mb)
    memory_used = int(get_memory_usage()) + 100
    final_memory_used = get_memory_usage()
    logging.info(
        f"$$$$$$$$$$$$$$$$$$$$$$$Final Memory Used: {final_memory_used:.2f} MB"
    )
    memory_sns(memory_limit, memory_used, context)

    if access_token or (not access_token and not ui_token):
        if "status_code" in result:
            return result
        else:
            return result
    else:
        return {
            "statusCode": status_code,
            "body": json.dumps(result),
            "performance_matrix": json.dumps(performance_matrix),
            "started": hit_time_formatted,
            "time_taken": time_taken,
            "request_completed_time_formatted": request_completed_time_formatted,
        }
