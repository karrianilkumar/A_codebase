"""
@Author1 : Ratna B
Created Date: 27-12-2024
"""

# Importing the necessary Libraries
import ast
import boto3
import requests
import os
import io
# from bp_email_trigger import send_email_without_template
import pandas as pd
from common_utils.email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import datetime
from datetime import time
from datetime import datetime, timedelta,date
from dateutil.relativedelta import relativedelta
import time
from io import BytesIO
from common_utils.data_transfer_main import DataTransfer
import json
import base64
import re
import pytds
from pytz import timezone
import numpy as np
from collections import defaultdict
#download template dependencies
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from datetime import datetime, timedelta
import pandas as pd
from io import BytesIO
import base64
from io import StringIO
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
import csv
from openpyxl import load_workbook
from openpyxl import Workbook
from pytz import UnknownTimeZoneError, timezone
import pandas as pd
import psycopg2
import random
import string

# Dictionary to store database configuration settings retrieved from environment variables.
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema": False
}
logging = Logging(name="sim_management")


def get_headers_mapping(tenant_database, module_list, role, user, tenant_id, sub_parent_module, parent_module, data,):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.

    This function:
    - Connects to the database.
    - Fetches field mappings and categorizes them into pop-ups, general fields, and table fields.
    - Retrieves and processes module features based on user roles.
    - Returns a structured dictionary containing headers and features for each module.

    Parameters:
        tenant_database (str): The database name of the tenant.
        module_list (list): List of module names to fetch field mappings for.
        role (str): The role of the user (e.g., 'Super Admin').
        user (str): The username of the user.
        tenant_id (int): The ID of the tenant.
        sub_parent_module (str): The name of the sub-parent module.
        parent_module (str): The name of the parent module.
        data (dict): Additional input data, which may contain:
            - feature_module_name (str): The feature module name.
            - username/user_name/user (str): The username.
            - tenant_name/tenant (str): The tenant name.

    Returns:
        dict: A dictionary where each module name maps to its corresponding headers and features.
    """
    # Establish database connections
    database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    billing_platform_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    
    # Extract relevant details from the input data dictionary
    main_module_name=data.get("main_module_name", "Customer Profiles")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")
    parent_module_name = data.get("parent_module", "Billing Platform")
    print(f'tenant_name-----{tenant_name}')

    tenant_id_query = database.get_data(
        "tenant", {"tenant_name": tenant_name},["id"]
    )
    tenant_id = tenant_id_query["id"].to_list()[0]
    
    ret_out = {}
    
    # Iterate over each module name in the provided module list
    for module_name in module_list:
        out = billing_platform_database.get_data(
            "field_column_mapping", {"module_name": module_name}
        ).to_dict(orient="records")
        pop_up = []
        general_fields = []
        table_fileds = {}
        # Categorize the fetched data based on field types
        for data in out:
            if data["pop_col"]:
                pop_up.append(data)
            elif data["table_col"]:
                table_fileds.update(
                    {
                        data["db_column_name"]: [
                            data["display_name"],
                            data["table_header_order"],
                        ]
                    }
                )
            else:
                general_fields.append(data)
        # Create a dictionary to store categorized fields
        headers = {}
        headers["general_fields"] = general_fields
        pop_up = sorted(pop_up, key=lambda x: x['id'])
        headers["pop_up"] = pop_up
        headers["header_map"] = table_fileds
        try:
            final_features = []

            # Fetch all features for the 'super admin' role
            if role.lower() == "super admin":
                all_features = database.get_data(
                    "module_features", {"module": main_module_name, "parent_module_name":parent_module_name}, ["features"]
                )["features"].to_list()
                if all_features:
                    final_features = json.loads(all_features[0])
            else:
                final_features = get_features_by_feature_name(
                    user_name, tenant_id, main_module_name, database,parent_module_name,role
                )

        except Exception as e:
            logging.exception(f"there is some error {e}")
            pass
        # Add the final features to the headers dictionary
        headers["module_features"] = final_features
        if module_name in ["Customer Services Carrier","Customer Services Customer"]:
            module_name = "Customer Services"
        ret_out[module_name] = headers

    return ret_out



def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name, role
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        logging.debug("Raw user features fetched: %s", user_features_raw)

        if not user_features_raw or user_features_raw[0] is None:
            query=f'''select module_features from role_module where role='{role}'
            '''
            user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
        
        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  
        
        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        print(
            "Retrieved features: %s", features_list
        )  

    except Exception as e:
        # Catch any exceptions and log a warning
        logging.warning("There was an error while fetching features: %s", e)

    return features_list  # Return the list of retrieved features

def data_update_db(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        logging.info(f'INchanged_data---------{changed_data}---{unique_id}------{table_name}')

        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            logging.info("***update_data",update_data)
            # Perform the update operation
            db.update_dict(table_name, update_data, {"id": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def convert_timestamp(df_dict, tenant_time_zone):
    """
    Convert timestamp columns in the provided dictionary list to the tenant's timezone.

    Parameters:
        df_dict (list of dict): A list of dictionaries where each dictionary represents a record
                                containing timestamp fields.
        tenant_time_zone (str): The timezone to which the timestamps should be converted.

    Returns:
        list of dict: The updated list of dictionaries with timestamps converted to the tenant's timezone.
    """
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y %H:%M:%S')  # Ensure it's a string
    return df_dict

def serialize_data(data):
    """Recursively convert pandas and datetime objects to JSON serializable types."""
    
    # Ensure the type check is valid
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    
    # Handle both pandas and native Python timestamps
    elif isinstance(data, (pd.Timestamp, datetime)):  
        return data.strftime('%m-%d-%Y %H:%M:%S')  
    
    elif isinstance(data,date):  
        return data.strftime('%m-%d-%Y %H:%M:%S')  

    # Return other types as they are
    else:
        return data

def get_export_status(data):
    """
    The get_export_status function retrieves the export status of a specific module from a database.
    It queries the export_status table based on the given module name and returns the corresponding status data.
    """
    try:
        common_utils_database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
        database = DB(os.environ['BILLING_PLATFORM'], **db_config)
        report_id=data.get("report_id","")
        request_received_at = data.get("request_received_at", None)
        module_name=data.get("module_name","")    
        export_status_query = (
            f"select * from export_status where module_name='{module_name}'"
        )
        export_status_data = common_utils_database.execute_query(
            export_status_query, True
        ).to_dict(orient="records")
        # updating the report status
        try:
            if report_id:
                reports_data={
                    "generated_date":request_received_at,
                    "status":"Generated"
                }
                update_report=database.update_dict("reports",reports_data, {"id": report_id})
        except Exception:
            pass
        return {"flag": True, "export_status_data": export_status_data[0]}
    except Exception as e:
        logging.exception(f"Exception is {e}")
        return {"flag": False, "export_status_data": []}


def export_to_s3_bucket_(data):
    """
    Export combined query results for all billing periods into a single Excel file
    and upload it to an Amazon S3 bucket.

    Args:
        data (dict): Input data with necessary details.

    Returns:
        dict: Operation result containing flag, message, and optionally download_url.
    """
    S3_BUCKET_NAME = "searchexceluat"

    # Extract input parameters
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    logging.info(f'module_name---------{module_name}')
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    user_name = data.get("user_name", "")
    session_id = data.get("session_id", "")
    service_provider = data.get("service_provider", "")
    billing_cycle_period = data.get("billing_cycle_period", "")
    end_date = data.get('end_date', '')
    start_date = data.get('start_date', '')
    tenant_database = data.get("db_name", "")
    data_frames = data.get("dfs", {})  # Expecting a dict {"Sheet1": df1, "Sheet2": df2}
    logging.info(f'data_frames---------{data_frames}')
    report_name=data.get("report_name","")
    username=data.get("username","")
    database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    start_time = time.time()


    # insert into reports table
    reports_dict={
        "report_name":report_name,
        "requested_by":username,
        "requested_date":request_received_at,
        "status":"Pending"
    }
    try:
        inserted_id=database.insert_data(reports_dict,"reports")
        if inserted_id:
            response = {
                    "flag": True,
                    "message": "Successfully Generated Report"
                }
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": module_name,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f'Successfully Generated {report_name}',
                "module_name": module_name,
                "request_received_at": request_received_at
            }
            db.update_audit(audit_data_user_actions, "audit_user_actions")
        else:
            response = {
                    "flag": False,
                    "message": "Error Inserting Report data to Reports table"
                }
            return response
    except Exception:
        inserted_id=''

    if module_name == 'SimManagement Inventory':
        file_name = f"exports/uat/{module_name_snake_case}/SimManagement/Inventory.xlsx"
    else:
        file_name = f"exports/uat/{module_name_snake_case}/{module_name}.xlsx"

    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"


    # Update export status to 'Waiting'
    db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name},
    )

    try:
        if not data_frames :
            db.update_dict(
                "export_status",
                {"status_flag": "No Data Found for export", "url": ""},
                {"module_name": module_name},
            )
            return {"flag": False, "message": "No data found for export."}

        excel_buffer = BytesIO()
        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
            for sheet_name, df in data_frames.items():
                if df.empty:
                    df = pd.DataFrame(columns=df.columns)

                # Format column names
                acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "SIM"}
                special_replacements = {"Att": "AT&T", "And": "and"}

                df.columns = [
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in str(col).split("_")
                    )
                    for col in df.columns
                ]
                df.columns = [
                    " ".join([special_replacements.get(word, word) for word in col.split(" ")]) for col in df.columns
                ]

                df.to_excel(writer, index=False, sheet_name=sheet_name)

                # Apply styles
                workbook = writer.book
                sheet = workbook[sheet_name]

                header_font = Font(bold=True)
                for cell in sheet[1]:
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                    cell.font = header_font

                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        excel_buffer.seek(0)

        s3_client = boto3.client("s3")
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=excel_buffer.getvalue(),
            ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

        db.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": module_name},
        )
        return {"flag": True, "download_url": download_url,"report_id":inserted_id}

    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name}
        )
        db.log_error_to_db(
            {
                "service_name": module_name,
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": str(e),
                "module_name": module_name,
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error: {str(e)}"}
    
def generate_empty_excel():
    """
    Generates an empty Excel file with a placeholder sheet using openpyxl.
    """
    # Create a workbook and an empty worksheet
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Sheet1"  # Set the sheet name

    # Save the workbook to a BytesIO bufferr
    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()

def dataframe_to_blob(data_frame):
    """
    Description:The Function is used to convert the dataframe to blob
    """
    # Create a BytesIO buffer
    bio = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        data_frame.to_excel(writer, index=False)

    # Get the value from the buffer
    bio.seek(0)
    blob_data = base64.b64encode(bio.read())
    return blob_data

def total_payments(data):
    """
    Fetches the total payment amount per day, month, or year in the specified date range.

    Args:
        data (dict): A dictionary containing the following keys:
            - start_date (str): The start date for filtering payments (format: YYYY-MM-DD).
            - end_date (str): The end date for filtering payments (format: YYYY-MM-DD).

    Returns:
        dict: A dictionary containing the status and the bar chart data of daily, monthly, or yearly payment totals.
    """
    start_time = time.time()
    modified_date=data.get('request_received_at','')
    Partner = data.get("partner", "")
    username = data.get("username", "")
    session_id = data.get("session_id", "")
    flag = data.get('flag', 'today')
    action = data.get('action', '')
    today = datetime.now().date()
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("partner", "")
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1
    
    # Default range for weekly and daily
    start_of_week = today - timedelta(days=today.weekday())
    end_of_week = start_of_week + timedelta(days=6)
    
    # Set default date range based on the flag
    if flag.lower() in ['weekly']:
        data["start_date"] = data.get("start_date", start_of_week.strftime("%Y-%m-%d"))
        data["end_date"] = data.get("end_date", end_of_week.strftime("%Y-%m-%d"))
    elif flag.lower() == 'today':
        # For today, set the range to today only
        data["start_date"] = today.strftime("%Y-%m-%d")
        data["end_date"] = (today + timedelta(days=1)).strftime("%Y-%m-%d")
    elif flag.lower() in ['monthly', 'yearly']:
        # For monthly or yearly, get the range from 12 months ago to today
        start_date = today.replace(day=1)  # Set to the first of the current month
        start_date = start_date - timedelta(days=365)  # Go back one year
        data["start_date"] = start_date.strftime("%Y-%m-%d")
        data["end_date"] = today.strftime("%Y-%m-%d")
    
    try:
        query = """
            SELECT DATE(date) AS date, SUM(amount) AS total_amount
            FROM payment_history
            WHERE tenant_id %s and date BETWEEN %s AND %s
            GROUP BY DATE(date)
            ORDER BY DATE(date)
        """
        params = [tenant_id, data["start_date"], data["end_date"]]
        print("Executing query:", query % tuple(params))  # Debug: log the query with params
        
        # Database connection
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)

        # Execute query
        res = killbill_database.execute_query(query, params=params)
        print(f'results: {res}')
        
        # Process result
        if isinstance(res, pd.DataFrame):
            daily_amounts = res.set_index("date")["total_amount"].to_dict()
        else:
            daily_amounts = dict(res.fetchall()) if res else {}
        
        # Format result dates
        daily_amounts = {
        date.strftime("%Y-%m-%d"): round(float(amount), 2) for date, amount in daily_amounts.items()
        }
        print(f'formatted daily_amounts: {daily_amounts}')

        data_card = []

        if flag.lower() in ['today', 'weekly']:
            # Weekly or Daily Processing
            days_of_week = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            for i in range(7):
                day = start_of_week + timedelta(days=i)
                date_str = day.strftime("%Y-%m-%d")
                amount = round(daily_amounts.get(date_str, 0.0), 2)
                data_card.append({"day": days_of_week[i], "value": amount})

        elif flag.lower() in ['monthly', 'yearly']:
            # Monthly or Yearly Processing (over the past 12 months)
            months_of_year = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
            month_totals = {month: 0.0 for month in months_of_year}

            year_totals = {}

            for date_str, amount in daily_amounts.items():
                # Get the month and year from the date
                date_obj = datetime.strptime(date_str, "%Y-%m-%d")
                month_name = date_obj.strftime("%b")
                year = date_obj.year

                # Update month totals
                if month_name in months_of_year:
                    month_totals[month_name] += round(amount, 2)
                
                # Update year totals
                if year not in year_totals:
                    year_totals[year] = 0.0
                year_totals[year] += round(amount, 2)

            # Preparing the data_card for monthly or yearly payments
            for month in months_of_year:
                data_card.append({"day": month, "value": round(month_totals[month], 2)})

            if flag.lower() == 'yearly':
                # Preparing the data_card for yearly payments (sorted by year)
                for year, total in sorted(year_totals.items()):
                    data_card.append({"day": str(year), "value": round(total, 2)})

        if action == "download":
            df_output = pd.DataFrame(data_card)
            df_output.replace(to_replace="None", value="", inplace=True)
            df_output = df_output.astype(str)
            df_output.columns = [col.replace("_", " ").title() for col in df_output.columns]
            blob_data = dataframe_to_blob(df_output)

            return {
                "flag": True,
                "blob": blob_data.decode("utf-8"),
                "filename": "Total_Payments.xlsx"
            }

        response = {
            "flag": True,
            "data": {
                "title": f"Total Payment Amount ({flag.capitalize()})",
                "chart_type": "bar",
                "data": data_card,
                "xField": "day",
                "yField": "value",
                "smooth": True,
                "height": 300,
                "width": 500,
            },
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "total_payments",
            "created_by": username,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": 'Successfully fetched payment data',
            "module_name": "BP Dashboards",
            "request_received_at": modified_date
            }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        print(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching payment data",
        }
        message = str(e)
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "total_payments",
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "BP Dashboards",
                "request_received_at": modified_date,
            }
            database.log_error_to_db(error_data, "error_log_table")
        except:
            pass

    return response

def ar_aging_pie(data):
    """
    Fetches the aging summary including total and current A/R values.
    Args:
        data (dict): Should contain 'partner', 'start_date', and 'end_date'.
    Returns:
        dict: Status flag and chart data for aging buckets.
    """
    start_time = time.time()
    modified_date=data.get('request_received_at','')
    Partner = data.get("partner", "")
    username = data.get("username", "")
    session_id = data.get("session_id", "")
    partner_name = data.get("partner")
    action = data.get("action", "")
    start_date = data.get("start_date")
    end_date = (datetime.strptime(data.get("end_date"), "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("partner", "")
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1

    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    
    try:
        query = """
            SELECT * FROM ar_aging_view
            WHERE tenant_id = %s and modified_date >= %s AND modified_date < %s;
        """

        params = [tenant_id,start_date, end_date]
        res = killbill_database.execute_query(query, params=params)
        columns = res.columns.tolist()
        # Assigning the values of each column to separate variables
        # Extracting values as lists for all rows
        current = res['current'].tolist()
        column_0_30 = res['0-30'].tolist()
        column_31_60 = res['31-60'].tolist()
        column_61_90 = res['61-90'].tolist()
        column_91_120 = res['91-120'].tolist()
        column_120_plus = res['120+'].tolist()

        total_0_30 = round(sum(column_0_30), 2)
        total_31_60 = round(sum(column_31_60), 2)
        total_61_90 = round(sum(column_61_90), 2)
        total_91_120 = round(sum(column_91_120), 2)
        total_120_plus = round(sum(column_120_plus), 2)
                               
        total_current = round(sum(current), 2)

        total_value = 0
        for i in range(len(res)):
            total_value += res['0-30'][i] + res['31-60'][i] + res['61-90'][i] + res['91-120'][i] + res['120+'][i]
        
        total_value_ = round(total_value + total_current, 2)
        print(f'total_value------{total_value}')
        labels = ["0-30", "31-60", "61-90", "91-120", "120+"]

        data_card = [
            {"status": "0-30", "count": total_0_30},
            {"status": "31-60", "count": total_31_60},
            {"status": "61-90", "count": total_61_90},
            {"status": "91-120", "count": total_91_120},
            {"status": "120+", "count": total_120_plus},
        ]
        if action == "download":
            data_card.append({"status": "current", "count": total_current})  # Example for adding current value
            data_card.append({"status": "total", "count": total_value_})
            df = pd.DataFrame(data_card)
            if df.empty:
                blob_data = generate_empty_excel()
                # Return JSON response for empty Excel
                response = {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),  # If you need a decoded version
                    "message": "No data available. Empty Excel generated.",
                }
            logging.info("Download action requested.")
            df.replace(to_replace="None", value="", inplace=True)
            df = df.astype(str)
            df.columns = [
                col.replace("_", " ").title() for col in df.columns
            ]

            blob_data = dataframe_to_blob(df)
            logging.info("Blob data prepared for download.")
            response = {"flag": True, "blob": blob_data.decode("utf-8"), "filename": "A_R_Aging_Pie.xlsx"}
            #return response
    
        if action == 'view':
            response = {
                "flag": True,
                "data": {
                    "title": f"Total A/ R: ${total_value_:,.0f}    Current A/ R: ${total_current:,.0f}",
                    "chart_type": "pie",
                    "data": data_card,
                    "angleField": "count",
                    "colorField": "status",
                    "color": ["#1890FF", "#13C2C2", "#2FC25B", "#FACC14", "#F04864"],
                    "radius": 0.8,
                    "innerRadius": 0.6,
                    "height": 300,
                    "width": 500,
                },
            }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "ar_aging_pie",
            "created_by": username,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": 'Successfully fetched A/R aging data',
            "module_name": "BP Dashboards",
            "request_received_at": modified_date
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        print("Error occurred while fetching A/R aging data: %s", e)
        response = {
            "flag": False,
            "message": "Error occurred while fetching A/R aging data."
        }
        message = str(e)
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "ar_aging_pie",
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "BP Dashboards",
                "request_received_at": modified_date,
            }
            database.log_error_to_db(error_data, "error_log_table")
        except:
            pass

    return response

def outstanding_table(data):
    action = data.get("action", "")
    start_time = time.time()
    tenant_name = data.get("tenant_name", "")
    tenant_id = data.get("tenant_id", "")
    mode=os.getenv('ENV','UAT')
    role_name = data.get("role_name", "")
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1
    columns = [
        {"title": "S. No", "dataIndex": "no", "key": "no", "width": "10%"},
        {
            "title": "Customer ID",
            "dataIndex": "account_number",
            "key": "account_number",
            "width": "10%"
        },
        {
            "title": "Name",
            "dataIndex": "customer_name",
            "key": "customer_name",
            "width": "25%"
        },
        {
            "title": "Email",
            "dataIndex": "email",
            "key": "email",
            "width": "25%"
        },
        {
            "title": "Outstanding",
            "dataIndex": "amount_due",
            "key": "amount_due",
            "width": "20%"
        },
        {
            "title": "Contact",
            "dataIndex": "telephone_number",
            "key": "telephone_number",
            "width": "20%"
        },
        {
            "title": "Agent",
            "dataIndex": "sales_person",
            "key": "sales_person",
            "width": "20%"
        },
        {
            "title": "Account Type",
            "dataIndex": "account_type",
            "key": "account_type",
            "width": "20%"
        }
        ]
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    try:
        query = f"""SELECT account_number,customer_name,email,amount_due,telephone_number,sales_person,account_type FROM customer_profiles where tenant_id = {tenant_id} and amount_due is not null order by amount_due desc limit 5"""
        customer_profiles = killbill_database.execute_query(query, True)
        print(f'customer_profiles------{customer_profiles}')
        customer_profiles.columns = customer_profiles.columns.str.strip()
        
        if action == "download":
            if customer_profiles.empty:
                blob_data = generate_empty_excel()
                # Return JSON response for empty Excel
                response = {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),  # If you need a decoded version
                    "message": "No data available. Empty Excel generated.",
                }
            logging.info("Download action requested.")
            if "amount_due" in customer_profiles.columns:
                customer_profiles["amount_due"] = customer_profiles["amount_due"].astype(float).round(2)

            customer_profiles.replace(to_replace="None", value="", inplace=True)
            customer_profiles = customer_profiles.astype(str)
            customer_profiles.columns = [
                col.replace("_", " ").title() for col in customer_profiles.columns
            ]

            blob_data = dataframe_to_blob(customer_profiles)
            logging.info("Blob data prepared for download.")
            response = {"flag": True, "blob": blob_data.decode("utf-8")}


        if action == 'view':
            formatted_data = []
            i = 0
            for idx, row in customer_profiles.iterrows():
                print(f'idx------{idx}')
                print(f'row------{row}')
                formatted_row = {
                    "no": str(i + 1),  # Add index as serial number
                    "key": str(i + 1),  # Use index as key for each row
                    "account_number": row["account_number"],
                    "customer_name": row["customer_name"],  # Column names should match the query result
                    "email": row["email"],
                    "amount_due": round(float(row["amount_due"]), 2) if row["amount_due"] is not None else 0.00,
                    "telephone_number": row["telephone_number"],
                    "sales_person": row["sales_person"], 
                    "account_type": row["account_type"]
                }
                formatted_data.append(formatted_row)
                i += 1
            response = {
                "flag": True,
                "data": formatted_data,
                "columns": columns,
                "height": 400,
                "width": 800,
            }
       
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "outstanding_table",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully fetched outstanding data',
            "module_name": "BP Dashboards",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        print(f"Error occurred while fetching outstanding data: {e}")
        response = {
            "flag": False,
            "message": "Error occurred while fetching outstanding data."
        }
        message = str(e)
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "outstanding_table",
                "error_message": message,
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message,
                "module_name": "BP Dashboards",
                "request_received_at": data.get("request_received_at", None),
            }
            database.log_error_to_db(error_data, "error_log_table")
        except:
            pass
    return response

def total_bill_line_graph(data):
    start_time = time.time()
    action = data.get("action", "")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("partner", "")
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1

    # Generate list of last 12 months (e.g., Apr 2024 to Mar 2025)
    today = date.today()
    months_list = [
        (today.replace(day=1) - relativedelta(months=i)) for i in reversed(range(12))
    ]
    month_labels = [month.strftime("%b %Y") for month in months_list]
    
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)

    # Fetch all bill records
    try:
        query = f"""
            SELECT mrc, nrc, taxes, applied_services, created_date AS created_at
            FROM customer_bills
            where tenant_id = {tenant_id}
        """
        df = killbill_database.execute_query(query, True)

        if df.empty:
            if action == "download":
                blob_data = generate_empty_excel()
                response = {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),
                    "filename": "Total_Bill_Line_Graph.xlsx"
                }
            final_output={
                "title":"Total Bill Line Graph",
                "chart_type":"line",
                "total_bill_line_graph":[]
            }
            response = {"flag": True, "data": final_output}

        # Ensure created_at is datetime
        df["created_at"] = pd.to_datetime(df["created_at"])

        # Pre-fill result structure
        result_data = {
            label: {"month": label,"MRC": 0, "NRC": 0, "Taxes": 0, "NA": 0, "CR": 0, "Total": 0}
            for label in month_labels
        }

        for _, row in df.iterrows():
            created_at = row["created_at"]
            month_label = created_at.strftime("%b %Y")

            if month_label not in result_data:
                continue  # Ignore records outside 12-month range

            result_data[month_label]["MRC"] += row.get("mrc", 0)
            result_data[month_label]["NRC"] += row.get("nrc", 0)
            result_data[month_label]["Taxes"] += row.get("taxes", 0)

            applied_services = row.get("applied_services")
            if applied_services:
                try:
                    applied_services_ids = tuple(ast.literal_eval(applied_services))
                    for service_id in applied_services_ids:
                        service_data = killbill_database.get_data(
                            "customer_services",
                            {"id": service_id},
                            ["netwrok_access_fee", "recovery_fee"]
                        )
                        if not service_data.empty:
                            result_data[month_label]["NA"] += service_data["netwrok_access_fee"].iloc[0]
                            result_data[month_label]["CR"] += service_data["recovery_fee"].iloc[0]
                except Exception as e:
                    print(f"Error parsing applied_services: {e}")

        # Calculate Total
        for item in result_data.values():
            for key in ["MRC", "NRC", "Taxes", "NA", "CR"]:
                item[key] = round(float(item[key]), 2)
            item["Total"] = item["MRC"] + item["NRC"] + item["Taxes"] + item["NA"] + item["CR"]

        # Return results sorted by the generated month list
        output = [result_data[label] for label in month_labels]

        if action == "download":
            df_output = pd.DataFrame(output)
            df_output.replace(to_replace="None", value="", inplace=True)
            for col in ["MRC", "NRC", "Taxes", "NA", "CR", "Total"]:
                if col in df_output.columns:
                    df_output[col] = df_output[col].astype(float).round(2)

            df_output = df_output.astype(str)
            df_output.columns = [col.replace("_", " ").title() for col in df_output.columns]
            blob_data = dataframe_to_blob(df_output)
            response = {
                "flag": True,
                "blob": blob_data.decode("utf-8"),
                "filename": "Total_Bill_Line_Graph.xlsx"
            }
        
        elif action == "view":
            final_output={
                "title":"Total Bill Line Graph",
                "chart_type":"line",
                "total_bill_line_graph":output
            }
            response = {
                "flag": True,
                "data": final_output
            }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "total_bill_line_graph",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("partner", ""),
            "comments": 'Successfully fetched bill data',
            "module_name": "BP Dashboards",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
    except Exception as e:
        logging.info(f'Error occurred while fetching bill data: {e}')
        response = {
            "flag": False,
            "message": "Error occurred while fetching bill data."
        }
        message = str(e)
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "total_bill_line_graph",
                "error_message": message,
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message,
                "module_name": "BP Dashboards",
                "request_received_at": data.get("request_received_at", None),
            }
            database.log_error_to_db(error_data, "error_log_table")
        except:
            pass
    return response

def total_bill_by_ledger_bar(data):
    pass

def bp_dashboards(data):
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
    table_name = data.get('table_name','customer_profiles')
    role_name = data.get('role_name', '')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    tenant_id=data.get('tenant_id',None)
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1

    db_name=data.get('db_name', "altaworx_test")
    if not db_name or db_name=="null":
        db_name="altaworx_test"
    try:
        # Fetch user-specific header mappings for UI display
        header_map = get_headers_mapping(killbill_database,["Billing Customer Profiles"],role_name, '', '', '', '',data)

        # Serialize customer data for API response
        data_dict_all = {}
        # print(f'###data_dict_all {data_dict_all}')

        # Construct and return the success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map
        }
        return response

    except Exception as e:
        # Log the exception and return a failure response
        logging.exception(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching email list",
            "data": {}
        }
        return response

def collections_summary(data):
    start_time = time.time()
    action = data.get("action", "")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    mode=os.getenv('ENV', 'UAT')
    col_sort = data.get("col_sort", "")
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1

    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    limit = end - start
    offset = start

    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)

    try:
        #fetch total_count
        total_count_query = f"""
        select count(*) as total_count
        from vw_collection_history where tenant_id = {tenant_id}"""
        total_count_df = killbill_database.execute_query(total_count_query, True)
        total_count = total_count_df['total_count'].iloc[0]

        pages_data = {
                "start": start,
                "end": end,
                "total": int(total_count)
            }

        # Fetch all customer profiles
        collection_history_query = f"""
            select customer_name, account_number, due_date_of_this_bill, amount_due,
                template_description, day, step_description, days_left, collection_status
            from vw_collection_history
            where tenant_id = {tenant_id}"""

        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]          # Extract column name
            order_direction = order[order_by]         # Already lowercase
            collection_history_query += f" ORDER BY {order_by} {order_direction}"

        collection_history_query += f" LIMIT {limit} OFFSET {offset}"
        collection_history_df = killbill_database.execute_query(collection_history_query, True)
        logging.info(f'collection_history_df----------{collection_history_df}')

        if action == "download":
            if collection_history_df.empty:
                blob_data = generate_empty_excel()
                response = {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),
                    "message": "No data available. Empty Excel generated."
                }
                end_time = time.time()
                time_consumed = f"{end_time - start_time:.4f}"
                time_consumed = int(float(time_consumed))
                audit_data_user_actions = {
                    "service_name": "collections_summary",
                    "created_by": data.get("username", ""),
                    "status": str(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "session_id": data.get("session_id", ""),
                    "tenant_name": data.get("Partner", ""),
                    "comments": 'No data available. Empty Excel generated.',
                    "module_name": "BP Dashboards",
                    "request_received_at": data.get("request_received_at", None)
                }
                database.update_audit(audit_data_user_actions, "audit_user_actions")
                return response
            collection_history_df.replace(to_replace="None", value="", inplace=True)
            collection_history_df["day"] = collection_history_df["day"].fillna(0).astype(int)
            collection_history_df["days_left"] = collection_history_df["days_left"].fillna(0).astype(int)
            column_mapping = {
                "customer_name": "Customer Name",
                "account_number": "Account Number",
                "due_date_of_this_bill": "Bill Due Date",
                "amount_due": "Amount Due",
                "template_description": "Collection Name",
                "day": "Current Step",
                "step_description":"Step Details",
                "days_left": "Days Left",
                "collection_status": "Collection Status"
            }
            collection_history_df.rename(columns=column_mapping, inplace=True)

            collection_history_df = collection_history_df.astype(str)

            blob_data = dataframe_to_blob(collection_history_df)
            logging.info("Blob data prepared for download.")
            response = {"flag": True, "blob": blob_data.decode("utf-8")}
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "collections_summary",
                "created_by": data.get("username", ""),
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": 'Successfully downloaded Collections History data',
                "module_name": "BP Dashboards",
                "request_received_at": data.get("request_received_at", None)
            }
            database.update_audit(audit_data_user_actions, "audit_user_actions")
            return response
        
        formatted_data = []
        for i, row in collection_history_df.iterrows():
            formatted_row = {
                "key": str(i + 1),
                "customer_name": row["customer_name"],
                "account_number": row["account_number"],
                "due_date_of_this_bill": row["due_date_of_this_bill"].strftime("%Y-%m-%d") if row["due_date_of_this_bill"] else None,
                "amount_due": row["amount_due"],
                "template_description": row["template_description"],
                "day": row["day"],
                "step_description": row["step_description"],
                "collection_status": row["collection_status"],
                "days_left": row["days_left"]
            }
            formatted_data.append(formatted_row)

        # response = {
        #     "flag": True,
        #     "data": formatted_data,
        #     "columns": columns,
        #     "height": 400,
        #     "width": 800,
        # }
        header_map = get_headers_mapping(killbill_database,["Collections Summary"], role_name, '', '', '', '', data)
        data_dict_all = {"collections_summary": serialize_data(formatted_data)}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "collections_summary",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully fetched Collections History data',
            "module_name": "BP Dashboards",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
    except Exception as e:
        logging.info(f'Error occurred while fetching collection summary data: {e}')
        response = {
            "flag": False,
            "message": "Error occurred while fetching collection summary data."
        }
        message = str(e)
        error_type = str(type(e).__name__)
        # Log error to database
        error_data = {
            "service_name": "collections_summary",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(response["message"]),
            "module_name": "BP Dashboards",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response