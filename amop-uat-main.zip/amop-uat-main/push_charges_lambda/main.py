"""
main.py
Module for handling API requests and routing them to the appropriate function.
Functions:
- lambda_handler(event,context=None)
Author: Nikhil N, Phaneendra Y
Date: July 22, 2024
"""

import boto3
import json
import time
from datetime import datetime
import pytz
from common_utils.db_utils import DB
import os

# from common_utils.daily_migration_management.migration_api import MigrationScheduler
from common_utils.email_trigger import (
    send_sns_email,
    get_memory_usage,
    memory_sns,
    insert_email_audit,
)

# from migration_management.migration_api import MigrationScheduler

from migration_api_opt import MigrationScheduler

from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging

logging = Logging(name="main")
##database configuration
# db_config = {
#     'host': "amoppostgres.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
#     'port': "5432",
#     'user': "root",
#     'password': "AmopTeam123"}

db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}

# Initialize the SNS client
sns = boto3.client("sns")
cloudwatch = boto3.client("cloudwatch")


def lambda_handler(event, context):
    """
    Handles incoming API requests and routes them to the appropriate function.

    Args:
        event (dict): The incoming API request event.

    Returns:
        dict: A dictionary containing the response status code and body.

    Example:
        >>> event = {'data': {'path': '/get_modules'}}
        >>> lambda_handler(event)
        {'statusCode': 200, 'body': '{"flag": True, "modules": [...]}'}
    """

    # Extract the HTTP method, path, and query string parameters from the event
    data = event.get("data")
    if not data:
        data = {}

    data = data.get("data", {})
    path = data.get("path", "")
    user = (
        data.get("username")
        or data.get("user_name")
        or data.get("user")
        or "superadmin"
    )

    # Route based on the path and method
    if path == "/push_charges_sync":
        scheduler = MigrationScheduler()
        result = scheduler.push_charges_sync(data)
    else:
        result = {"flag": False, "error": "Invalid path or method"}

    memory_limit = int(context.memory_limit_in_mb)
    memory_used = int(get_memory_usage()) + 100
    final_memory_used = get_memory_usage()
    logging.info(
        f"$$$$$$$$$$$$$$$$$$$$$$$Final Memory Used: {final_memory_used:.2f} MB"
    )
    memory_sns(memory_limit, memory_used, context)

    return {"statusCode": 200, "body": json.dumps(result)}
