"""
@Author1 : Phaneendra.Y
Created Date: 10-10-24
"""

# Standard Library Imports
from datetime import datetime
import time
import json
import re
import os

# Third-Party Imports
import pandas as pd
from sqlalchemy import create_engine, text , bindparam
from sqlalchemy.orm import sessionmaker

# Local Application Imports
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import fetch_tenant_timezone, convert_timestamp_data, serialize_data

##to fetch the service providers ids for each tenants separately used to get the serviceprovider ids in generic way
def load_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_serviceproviders.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"### Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs

db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}
logging = Logging(name="sim_management")


##Helper function to get the db config
def db_config_maker(user, db_config_making, tenant_database):
    """
    Builds and returns an extended database configuration dictionary by fetching 
    customer and service provider information for the given user.

    Args:
        user (str): Username used to fetch customer/service provider details.
        db_config_making (dict): Basic database configuration dictionary with keys like host, port, user, password.
        tenant_database (str): The name of the tenant-specific database to connect to.

    Returns:
        dict: The updated database configuration dictionary with additional keys:
            - "customers": tuple of customer names or None
            - "service_providers": tuple of service provider names or None
            - "service_provider_id": tuple of service provider IDs or None
    """
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_making)

    # query = f"select customers,service_provider from users where username ='{user}'"
    # filters = common_utils_database.execute_query(query, True)
    query = "select customers,service_provider from users where username = %s"
    filters = common_utils_database.execute_query(query, flag=True , params=[user])

    database = DB(tenant_database, **db_config)

    try:
        customer = tuple(json.loads(filters["customers"].to_list()[0]))

    except Exception as e:
      logging.error(f"Exception occurred while getting customer: {str(e)}")
      customer = None    
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        # if len(service_provider) == 1:
        #     query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        # else:
        #     query = f"select id from serviceprovider where service_provider_name in '{service_provider[0]}'"
        # service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())

        if len(service_provider) == 1:
            query = "SELECT id FROM serviceprovider WHERE service_provider_name = %s"
            params = [service_provider[0]]
        else:
            query = "SELECT id FROM serviceprovider WHERE service_provider_name IN %s"
            params = [service_provider]

        service_provider_id = tuple(database.execute_query(query, True, params=params)["id"].to_list())

    except Exception as e:
      logging.error(f"Exception occurred while getting service_provider , service_provider_id : {str(e)}")
      service_provider = None
      service_provider_id = None   

    db_config_making["customers"] = customer
    db_config_making["service_providers"] = service_provider
    db_config_making["service_provider_id"] = service_provider_id

    return db_config_making



### Main function to call the respective function based on the path
def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes automation-related requests.

    This function:
    1. Initializes database configuration from environment variables
    2. Determines the user and tenant-specific configuration
    3. Routes the request to the appropriate automation-related handler function based on the path

    Args:
        data (dict): Request data containing user/tenant information (e.g., username, db_name)
        path (str): API endpoint path being invoked
        access_token (str): Optional access token (currently unused, can be used for authentication)

    Returns:
        dict: Result of the invoked handler function or an error message for an invalid path
    """
    # Access global db_config variable
    global db_config

    # Initialize base database configuration from environment variables
    db_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
    }

    # Extract username from data (fallback handling)
    user = data.get("username") or data.get("user_name")
    tenant_database = data.get("db_name")

    # Build tenant-specific DB config
    db_config = db_config_maker(user, db_config, tenant_database)
    logging.info(f"### db_config created is : {db_config}")

    # Map API paths to corresponding handler functions
    path_function_map = {
        "/get_automation_rule_create_pop_up_data": get_automation_rule_create_pop_up_data,
        "/get_automation_rule_data": get_automation_rule_data,
        "/delete_automation_rule": delete_automation_rule,
        "/insert_automation_data": insert_automation_data,
        "/get_automation_rule_details_data": get_automation_rule_details_data,
        "/update_automation_actions_data": update_automation_actions_data,
    }

    # Route to the correct function based on the path
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result


# helper function to get the header mappings
def get_headers_mappings(
    tenant_database,
    module_list,
    role,
    user,
    tenant_id,
    sub_parent_module,
    parent_module,
    data,
):
    """
    Fetches and organizes header mappings and module features based on module names and user role.

    Args:
        tenant_database (str): Name of the tenant-specific database.
        module_list (list): List of module names to fetch header mappings for.
        tenant_id (int): The ID of the tenant for which data is being fetched.
        sub_parent_module (str): Sub-parent module name, used for hierarchical grouping.
        parent_module (str): Top-level module name like "Sim Management".
        data (dict): Additional information such as tenant_name, username, feature_module_name, etc.

    Returns:
        dict: A dictionary where each key is a module name and the value is another dictionary with:
            - 'general_fields': List of general form/display fields.
            - 'pop_up': List of fields to be shown in pop-ups.
            - 'header_map': Dict mapping DB columns to display names and order for tables.
            - 'module_features': List of features accessible by the user for that module.
    """
    ##Database connection
    ret_out = {}
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        logging.info(f"### Module name is :{module_list} and role is:{role}")
        # common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        feature_module_name = data.get("feature_module_name", "")
        user_name = data.get("username") or data.get("user_name") or data.get("user")
        tenant_name = data.get("tenant_name") or data.get("tenant")
        parent_module_name = data.get("parent_module_name") or data.get("parent_module")
        if parent_module_name == "Sim Management":
            parent_module_name = "Sim Management"
        try:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            logging.debug(f"### tenant_id  is :{tenant_id}")
        except Exception as e:
            logging.exception(f"### Getting exception at fetching tenant id {e}")
        # Iterate over each module name in the provided module list
        for module_name in module_list:
            out = common_utils_database.get_data(
                "field_column_mapping", {"module_name": module_name}
            ).to_dict(orient="records")
            pop_up = []
            general_fields = []
            table_fileds = {}
            # Categorize the fetched data based on field types
            for data in out:
                if data["pop_col"]:
                    pop_up.append(data)
                elif data["table_col"]:
                    table_fileds.update(
                        {
                            data["db_column_name"]: [
                                data["display_name"],
                                data["table_header_order"],
                            ]
                        }
                    )
                else:
                    general_fields.append(data)
            # Create a dictionary to store categorized fields
            headers = {}
            headers["general_fields"] = general_fields
            headers["pop_up"] = pop_up
            headers["header_map"] = table_fileds
            logging.info("### Got the header map here")
            try:
                final_features = []

                # Fetch all features for the 'super admin' role
                if role.lower() == "super admin":
                    all_features = common_utils_database.get_data(
                        "module_features",
                        {"module": feature_module_name},
                        ["features"],
                    )["features"].to_list()
                    if all_features:
                        final_features = json.loads(all_features[0])
                else:
                    final_features = get_features_by_feature_name(
                        user_name,
                        tenant_id,
                        feature_module_name,
                        common_utils_database,
                        parent_module_name,role
                    )

            except Exception as e:
                logging.warning(f"### there is some error {e}")
                pass
            # Add the final features to the headers dictionary
            headers["module_features"] = final_features
            ret_out[module_name] = headers
    except Exception as e:
        logging.warning(f"### there is some error : {e}")

    return ret_out


##Helper function to get the features by feature name
def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name,role
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        logging.debug(f"### Raw user features fetched:{user_features_raw}")
        # if not user_features_raw or user_features_raw[0] is None:
        #     query=f'''select module_features from role_module where role='{role}'
        #     '''
        #     user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()
        if not user_features_raw or user_features_raw[0] is None:
            query = '''
                SELECT module_features 
                FROM role_module 
                WHERE role = %s
            '''
            user_features_raw = common_utils_database.execute_query(query, flag=True, params=[role])["module_features"].to_list()
        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  # Assuming the result is a list with one JSON string

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  # Add features if found under parent module

        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        logging.info(f"### Retrieved features: {features_list}")  # Log the retrieved features

    except Exception as e:
        # Catch any exceptions and log a warning
        logging.warning(f"### There was an error while fetching features: {e}")

    return features_list  # Return the list of retrieved features


# Function to format dates
def format_date(date):
    """Function to format dates"""
    if isinstance(date, pd.Timestamp):  # Check if it's a Pandas Timestamp
        return date.strftime("%m-%d-%Y %H:%M:%S")
    return date  # Return as-is if not a Timestamp

##helper function to remove the hardcodes using the
def get_provider_ids(json_data, tenant_name, provider_names):
    """Fetches only the IDs of specified providers for a given tenant."""
    return [
        details["id"]
        for provider_name, details in json_data.get(tenant_name, {}).items()
        if provider_name in provider_names
    ]

def get_main_name_by_unique_name(json_data, tenant_name, unique_name):
    """Fetches 'main_name' of a provider based on its unique name."""
    return json_data.get(tenant_name, {}).get(unique_name, {}).get("main_name", None)


##get automation rule create pop up data
def get_automation_rule_create_pop_up_data(data):
    """
    Fetches data required to populate the automation rule creation or edit popup.

    Args:
        data (dict): A dictionary containing the following keys:
            - tenant_name (str): Name of the tenant
            - db_name (str): Tenant database name
            - username (str): Name of the user making the request
            - action (str): "create" or other (for edit)
            - automation_rule_id (int): ID of the rule to fetch (used when action is edit)

    Returns:
        dict: A dictionary with flag status (True/False) and:
            - On success: multiple dictionaries containing condition/action/status/etc. data
            - On failure: error message with flag set to False
    """

    logging.info("### Request Recieved for get_automation_rule_create_pop_up_data")
    # module_name = data.get("module_name", "Automation rule")
    start_time = time.time()
    # logging.info(f"Request Data: {data}")
    # Partner = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", " ")
    # table = data.get("table", "automation_rule")
    # Initialize the database connection
    tenant_database = data.get("db_name", "altaworx_test")
    tenant_name = data.get("tenant_name", "Altaworx")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    parent_tenant_query = '''SELECT parent_tenant_id FROM tenant WHERE tenant_name = %s '''
    parent_tenant_id_df = common_utils_database.execute_query(parent_tenant_query,True,params=[tenant_name])
    if not parent_tenant_id_df.empty:
        parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

        if parent_tenant_id is not None:
            parent_tenant_id = int(parent_tenant_id)
            parent_tenant_name_query = '''
                SELECT tenant_name 
                FROM tenant 
                WHERE id = %s
            '''
            parent_tenant_name = common_utils_database.execute_query(parent_tenant_name_query, True, params=[parent_tenant_id])["tenant_name"].to_list()[0]
            tenant_name = parent_tenant_name
    try:
        json_data = load_json()
        telegence_ids = get_provider_ids(json_data, tenant_name, ["Telegence"])
    except Exception as e:
        logging.error(f"### Error loading JSON: {e}")
        json_data = {}  # Fallback to empty dict if JSON fails
        telegence_ids = []  # Default to empty list
    # Convert the comma-separated string into a list

    service_provider_name = get_main_name_by_unique_name(json_data, tenant_name, "Telegence")
    # Fetch service provider ID safely
    service_provider_id = telegence_ids[0] if telegence_ids else None
    # tenant_names = tenant_names_str.split(",")
    # if tenant_name not in tenant_names:
    #     service_provider_name = "AT&T - Telegence"
    #     service_provider_id = 6
    # else:
    #     service_provider_name = "AT&T - Telegence - UAT ONLY"
    #     service_provider_id = 20
    # database Connection
    database = DB(tenant_database, **db_config)

    action = data.get("action", "")
    logging.debug(f"### action is {action}")
    try:
        if action == "create":
            automation_rule_condition_dict = database.get_data(
                "automation_rule_condition",
                {"is_active": True},
                ["id", "automation_rule_condition_name"],
            ).to_dict(orient="records")
            automation_rule_action_dict = database.get_data(
                "automation_rule_action",
                {"is_active": True},
                ["id", "automation_rule_action_name"],
            ).to_dict(orient="records")
            automation_rule_followup_effective_date_type_dict = database.get_data(
                "automation_rule_followup_effective_date_type",
                {"is_active": True},
                ["id", "description"],
            ).to_dict(orient="records")
            # Get integration_id
            integration_id = database.get_data(
                "serviceprovider",
                {"service_provider_name": service_provider_name},
                ["integration_id"],
            )["integration_id"].to_list()[0]
            # Fetch data from 'device_status' table
            device_status_data = database.get_data(
                "device_status",
                {"integration_id": integration_id, "allows_api_update": True},
                ["id", "display_name"],
            )
            # Convert the result to a list of dictionaries and remove duplicates based on 'id'
            Has_Current_status_values = [
                d for d in {
                    d["id"]: d for d in device_status_data.to_dict(orient="records")
                }.values()
                if d["display_name"] != "Change Phone Number"
            ]
            service_provider_name_dict = database.get_data(
                "serviceprovider",
                {"service_provider_name": service_provider_name},
                ["id", "service_provider_name"],
            ).to_dict(orient="records")
            features_data = database.get_data(
                "mobility_feature",
                {"service_provider_id": service_provider_id},
                ["soc_code", "friendly_name"],
            ).to_dict(orient="records")

            message = "Data Fetched Successfully"
            # Prepare the response
            response = {
                "flag": True,
                "automation_rule_condition_dict": automation_rule_condition_dict,
                "automation_rule_action_dict": automation_rule_action_dict,
                "automation_rule_followup_effective_date_type_dict": automation_rule_followup_effective_date_type_dict,
                "Has_Current_status_values": Has_Current_status_values,
                "service_provider_name_dict": service_provider_name_dict,
                "features_data": features_data,
                "message": message,
            }
        else:
            automation_rule_condition_dict = database.get_data(
                "automation_rule_condition",
                {"is_active": True},
                ["id", "automation_rule_condition_name"],
            ).to_dict(orient="records")
            automation_rule_action_dict = database.get_data(
                "automation_rule_action",
                {"is_active": True},
                ["id", "automation_rule_action_name"],
            ).to_dict(orient="records")
            automation_rule_followup_effective_date_type_dict = database.get_data(
                "automation_rule_followup_effective_date_type",
                {"is_active": True},
                ["id", "description"],
            ).to_dict(orient="records")
            # Get integration_id
            integration_id = database.get_data(
                "serviceprovider",
                {"service_provider_name": service_provider_name},
                ["integration_id"],
            )["integration_id"].to_list()[0]
            # Fetch data from 'device_status' table
            device_status_data = database.get_data(
                "device_status",
                {"integration_id": integration_id, "allows_api_update": True},
                ["id", "display_name"],
            )
            # Convert the result to a list of dictionaries and remove duplicates based on 'id'
            Has_Current_status_values = [
                d for d in {
                    d["id"]: d for d in device_status_data.to_dict(orient="records")
                }.values()
                if d["display_name"] != "Change Phone Number"
            ]
            service_provider_name_dict = database.get_data(
                "serviceprovider",
                {"service_provider_name": service_provider_name},
                ["id", "service_provider_name"],
            ).to_dict(orient="records")
            features_data = database.get_data(
                "mobility_feature",
                {"service_provider_id": service_provider_id},
                ["soc_code", "friendly_name"],
            ).to_dict(orient="records")
            automation_rule_id = data.get("automation_rule_id", "")
            automation_rule_detail_data = database.get_data(
                "automation_rule_detail",
                {"automation_rule_id": automation_rule_id, "is_active": True},
            ).to_dict(orient="records")
            # Step 2: Format dates within automation_rule_detail_data
            for record in automation_rule_detail_data:
                record["created_date"] = format_date(record.get("created_date"))
                record["modified_date"] = format_date(record.get("modified_date"))
                record["deleted_date"] = format_date(record.get("deleted_date"))

            # Step 3: Extract rule_followup_id values from automation_rule_detail_data
            rule_followup_ids = [
                item["rule_followup_id"] for item in automation_rule_detail_data
            ]
            # Step 4: Query automation_rule_followup_detail for each rule_followup_id
            automation_rule_followup_data = []
            automation_rule_followup_details = []
            for rule_followup_id in rule_followup_ids:
                followup_detail = database.get_data(
                    "automation_rule_followup_detail",
                    {"rule_followup_id": rule_followup_id, "is_active": True},
                ).to_dict(orient="records")
                # Step 5: Format dates within each followup_detail
                for record in followup_detail:
                    record["created_date"] = format_date(record.get("created_date"))
                    record["modified_date"] = format_date(record.get("modified_date"))
                    record["deleted_date"] = format_date(record.get("deleted_date"))
                followup_data = database.get_data(
                    "automation_rule_followup_effective_date_type",
                    {"id": rule_followup_id, "is_active": True},
                ).to_dict(orient="records")
                automation_rule_followup_data.extend(followup_data)
                automation_rule_followup_details.extend(
                    followup_detail
                )  # Use extend to flatten the list
            message = "Data Fetched Successfully"
            # Prepare the response
            response = {
                "flag": True,
                "automation_rule_detail_data": automation_rule_detail_data,
                "automation_rule_followup_details": automation_rule_followup_details,
                "automation_rule_condition_dict": automation_rule_condition_dict,
                "automation_rule_action_dict": automation_rule_action_dict,
                "automation_rule_followup_effective_date_type_dict": automation_rule_followup_effective_date_type_dict,
                "Has_Current_status_values": Has_Current_status_values,
                "service_provider_name_dict": service_provider_name_dict,
                "features_data": features_data,
                "message": message,
            }
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = round(end_time - start_time, 4)

            audit_data_user_actions = {
                "service_name": "get_automation_rule_create_pop_up_data",
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "comments": "fetching the Automation Rule pop up data",
                "module_name": "Automation rule",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        return response
    except Exception as e:
        # Handle exceptions and provide feedback
        logging.exception(f"### Exception occurred: {e}")
        message = "Something went wrong while getting automation rule pop up data"
        # Error Management
        error_data = {
            "service_name": "get_automation_rule_create_pop_up_data",  
            "error_message": str(e),
            "error_type":  type(e).__name__,
            "users": username,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Automation rule",
            "request_received_at": start_time,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        response = {"flag": False, "error": str(e)}
        return response


##get automation rule data
def get_automation_rule_data(data):
    """
    Fetches automation rule records for display in a paginated, sortable table view.

    Args:
        data (dict): Dictionary containing input data such as:
            - tenant_name (str): Tenant for which data is requested
            - db_name (str): Database name for the tenant
            - username (str): Username of the requester
            - table (str): Table name for count query (default: "automation_rule")
            - mod_pages (dict): Contains "start" and "end" for pagination
            - limit (int): Number of rows per page
            - col_sort (dict): Sorting configuration as {column: direction}

    Returns:
        dict: Response with the following keys:
            - flag (bool): True if successful, False if error occurred
            - automation_rule_data (list): List of records in dictionary form
            - header_map (dict): Header configuration based on role and module
            - pages (dict): Pagination metadata including total records
    """
    logging.info("### Request data Recieved")
    module_name = data.get("module_name", "Automation rule")
    start_time = time.time()
    # logging.info(f"Request Data: {data}")
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", " ")
    table = data.get("table", "automation_rule")
    # Initialize the database connection
    tenant_database = data.get("db_name", "altaworx_test")
    role_name = data.get("role_name", "")
    col_sort = data.get("col_sort", "")
    # database Connection
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    # # Get tenant's timezone
    tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
    try:
        automation_rule_data = []
        pages = {}
        if "mod_pages" in data:
            start = data["mod_pages"].get("start") or 0  # Default to 0 if no value
            end = data["mod_pages"].get("end") or 100  # Default to 100 if no value
            # limit = data.get("limit", 100)
            # Calculate pages
            pages["start"] = start
            pages["end"] = end
            count_params = [table]
            if module_name == "Automation rule":
                count_query = "SELECT COUNT(*) FROM %s where is_active=True" % table
            else:
                count_query = "SELECT COUNT(*) FROM %s" % table
            count_result = database.execute_query(count_query, count_params).iloc[0, 0]
            pages["total"] = int(count_result)
        # Fetch the query from the database based on the module name
        module_query_df = common_utils_database.get_data(
            "export_queries", {"module_name": module_name}
        )
        ##checking the dataframe is empty or not
        if module_query_df.empty:
            return {
                "flag": False,
                "message": f"No query found for module name: {module_name}",
            }
        # Extract the query string from the DataFrame
        query = module_query_df.iloc[0]["module_query"]
        if not query:
            return {"flag": False, "message": f"Unknown module name: {module_name}"}
        params = [start, end]

        # if col_sort:
        #     # Extract the single key-value pair for sorting
        #     key, value = list(col_sort.items())[0]
        #     if key in (
        #         "created_date",
        #         "modified_date",
        #         "last_usage_date",
        #         "date_added",
        #     ):
        #         # Construct the ORDER BY clause
        #         custom_order_by = f"{key}::TIMESTAMP {value.upper()}"
        #     else:
        #         custom_order_by = f"{key} {value.upper()}"

        #     # Remove any existing ORDER BY clause
        #     order_by_pattern = (
        #         r"\sORDER\s+BY\s+[^\s]+(\sASC|\sDESC)?(?=\s+(OFFSET|LIMIT))"
        #     )
        #     query = re.sub(order_by_pattern, "", query, flags=re.IGNORECASE)

        #     # Insert the new ORDER BY clause before OFFSET and LIMIT
        #     limit_offset_pattern = (
        #         r"(OFFSET\s+%s\s+LIMIT\s+%s;)"  # Captures OFFSET and LIMIT
        #     )
        #     query = re.sub(
        #         limit_offset_pattern,
        #         f"ORDER BY {custom_order_by} \\1",
        #         query,
        #         flags=re.IGNORECASE,
        #     )

        # automation_rule_data = database.execute_query(query, params=params).to_dict(
        #     orient="records"
        # )



        # Whitelist of allowed columns and directions
        allowed_columns = {
            "created_date",
            "modified_date",
            "last_usage_date",
            "date_added",
            "some_other_column",  # Add if needed
        }
        allowed_directions = {"ASC", "DESC"}

        if col_sort:
            # Extract the single key-value pair for sorting
            key, value = list(col_sort.items())[0]

            # Validate column and direction
            if key in allowed_columns and value.upper() in allowed_directions:
                # Construct ORDER BY clause safely
                if key in {"created_date", "modified_date", "last_usage_date", "date_added"}:
                    custom_order_by = f"{key}::TIMESTAMP {value.upper()}"
                else:
                    custom_order_by = f"{key} {value.upper()}"

                # Remove any existing ORDER BY clause
                order_by_pattern = (
                    r"\sORDER\s+BY\s+[^\s]+(\sASC|\sDESC)?(?=\s+(OFFSET|LIMIT))"
                )
                query = re.sub(order_by_pattern, "", query, flags=re.IGNORECASE)

                # Insert the new ORDER BY clause before OFFSET and LIMIT
                limit_offset_pattern = r"(OFFSET\s+%s\s+LIMIT\s+%s;)"
                query = re.sub(
                    limit_offset_pattern,
                    f"ORDER BY {custom_order_by} \\1",
                    query,
                    flags=re.IGNORECASE,
                )
            else:
                raise ValueError("Invalid column or sort direction in col_sort.")

        # Now safe to execute
        automation_rule_data = database.execute_query(query, params=params).to_dict(
            orient="records"
        )

        automation_rule_data = convert_timestamp_data(
            automation_rule_data, tenant_time_zone
        )
        # Generate the headers mapping
        headers_map = get_headers_mappings(
            tenant_database,
            [module_name],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
        )
        # Prepare the response
        response = {
            "flag": True,
            "automation_rule_data": serialize_data(automation_rule_data),
            "header_map": headers_map,
            "pages": pages,
        }
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = round(end_time - start_time, 4)

            audit_data_user_actions = {
                "service_name": "get_automation_rule_data",  
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "comments": "fetching the automation rule data",
                "module_name": "Automation rule",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        return response
    except Exception as e:
        # Handle exceptions and provide feedback
        logging.exception(f"### Exception occurred: {e}")
        message = "Something went wrong while fetching automation rule data"
        try:
            # Error Management
            error_data = {
                "service_name": "get_automation_rule_data",   
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Automation Rule",
                "request_received_at": start_time,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.warning("### Exception occured at updating the error table")
        # Generate the headers mapping
        headers_map = get_headers_mappings(
            tenant_database,
            [module_name],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
        )
        # Prepare the response
        response = {
            "flag": True,
            "automation_rule_data": {},
            "header_map": headers_map,
            "pages": {},
        }
        return response


# ##delete automation rules
# def delete_automation_rule(data, automation_rule_id, database):
#     # automation_rule_id = data.get('automation_rule_id', '')
#     logging.debug(automation_rule_id, "automation_rule_id")
#     # database = data.get("db_name", "altaworx_test")

#     # Create the database URL for SQLAlchemy
#     db_url = f"postgresql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{database}"
#     # Create a new engine instance
#     engine = create_engine(db_url)

#     # Create a configured "Session" class
#     Session = sessionmaker(bind=engine)

#     # Create a session
#     session = Session()
#     try:
#         # Get the automation_rule_detail followup IDs
#         automation_rule_details_data = session.execute(
#             text(
#                 """SELECT rule_followup_id FROM
#                   automation_rule_detail WHERE automation_rule_id = :automation_rule_id
#                   """
#             ),
#             {"automation_rule_id": automation_rule_id},
#         ).fetchall()

#         # Extract the followup IDs
#         rule_followup_ids = [
#             row[0] for row in automation_rule_details_data if row[0] is not None
#         ]
#         logging.debug(rule_followup_ids, "rule_followup_ids")

#         # Delete from automation_rule_detail
#         session.execute(
#             text(
#                 "DELETE FROM automation_rule_detail WHERE automation_rule_id = :automation_rule_id"
#             ),
#             {"automation_rule_id": automation_rule_id},
#         )

#         # Delete from automation_rule
#         session.execute(
#             text("DELETE FROM automation_rule WHERE id = :automation_rule_id"),
#             {"automation_rule_id": automation_rule_id},
#         )

#         # If there are followup IDs, delete from the related tables
#         if rule_followup_ids:
#             formatted_followup_ids = ", ".join(map(str, rule_followup_ids))
#             session.execute(
#                 text(
#                     f"""DELETE FROM automation_rule_followup_detail
#                     WHERE rule_followup_id IN ({formatted_followup_ids})
#                     """
#                 )
#             )
#             session.execute(
#                 text(
#                     f"DELETE FROM automation_rule_followup WHERE id IN ({formatted_followup_ids})"
#                 )
#             )
#         else:
#             logging.info("### No valid followup IDs to delete.")

#         # Commit the transaction
#         session.commit()
#         logging.info("### Deletion successful in the database")
#         response = {"flag": True, "message": "Deleted Successfully"}
#         return response

#     except Exception as e:
#         # Rollback in case of any errors
#         session.rollback()
#         logging.exception(f"Error: {e}")
#         return {"flag": False, "message": str(e)}

#     finally:
#         # Close the session
#         session.close()




##delete automation rules
def delete_automation_rule(data, automation_rule_id, database):
    """
    Deletes an automation rule and all related records from the database.

    Args:
        data (dict): Dictionary containing request metadata like:
            - tenant_name (str): Name of the tenant (used for audit logging).
            - request_received_at (str): Timestamp of the request.
            - username (str): Name of the user who triggered the request.
        automation_rule_id (int): The ID of the automation rule to be deleted.
        database (str): Name of the tenant-specific database to connect and execute deletions.

    Returns:
        dict: A dictionary with:
            - flag (bool): Indicates success or failure of the deletion process.
            - message (str): Success or error message.
            - error (str, optional): Error details in case of failure.
    """
    logging.info(f"### delete_automation_rule called with request data:\n{json.dumps(data, indent=2, default=str)}")
    request_received_at = data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    tenant_name = data.get("tenant_name", "")
    start_time = time.time()
    username = data.get("username") or data.get("user_name") or data.get("user") or ""
    logging.debug(f"### automation_rule_id: {automation_rule_id}")
    # start_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Create the database URL for SQLAlchemy
    db_url = f"postgresql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{database}"
    # Create a new engine instance
    engine = create_engine(db_url)
    # Create a configured "Session" class
    Session = sessionmaker(bind=engine)

    # Create a session
    session = Session()

    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as exception:
        logging.error(f"### Connection failed to common_utils_database: {exception}")
        return {"flag": False, "error": "common_utils_database connection failed"}

             
    try:
        
        # Get the automation_rule_detail followup IDs
        automation_rule_details_data = session.execute(
            text(
                """SELECT rule_followup_id FROM
                  automation_rule_detail WHERE automation_rule_id = :automation_rule_id
                  """
            ),
            {"automation_rule_id": automation_rule_id},
        ).fetchall()

        # Extract the followup IDs
        rule_followup_ids = [
            row[0] for row in automation_rule_details_data if row[0] is not None
        ]
        logging.debug(f"### rule_followup_ids: {rule_followup_ids}")


        # Delete from automation_rule_detail
        session.execute(
            text(
                "DELETE FROM automation_rule_detail WHERE automation_rule_id = :automation_rule_id"
            ),
            {"automation_rule_id": automation_rule_id},
        )

        # Fetch the automation_rule data before deletion
        automation_rule_data = session.execute(
            text("SELECT * FROM automation_rule WHERE id = :id"),
            {"id": automation_rule_id}
        ).fetchone()

        # Convert to dictionary
        automation_rule_dict = dict(automation_rule_data._mapping) if automation_rule_data else {}
        automation_rule_name = automation_rule_dict.get("automation_rule_name", "")

        # Delete from automation_rule
        session.execute(
            text("DELETE FROM automation_rule WHERE id = :automation_rule_id"),
            {"automation_rule_id": automation_rule_id},
        )



        # If there are followup IDs, delete from the related tables
        # if rule_followup_ids:
        #     formatted_followup_ids = ", ".join(map(str, rule_followup_ids))
        #     session.execute(
        #         text(
        #             f"""DELETE FROM automation_rule_followup_detail
        #             WHERE rule_followup_id IN ({formatted_followup_ids})
        #             """
        #         )
        #     )

        if rule_followup_ids:
            session.execute(
                text(
                    """DELETE FROM automation_rule_followup_detail
                    WHERE rule_followup_id IN :followup_ids"""
                ).bindparams(
                    bindparam("followup_ids", expanding=True)
                ),
                {"followup_ids": rule_followup_ids}
            )
            # session.execute(
            #     text(
            #         f"DELETE FROM automation_rule_followup WHERE id IN ({formatted_followup_ids})"
            #     )
            # )
            
            session.execute(
                text("DELETE FROM automation_rule_followup WHERE id IN :ids")
                .bindparams(bindparam("ids", expanding=True)),
                {"ids": rule_followup_ids}
            )
        else:
            logging.info("### No valid followup IDs to delete.")

        # Commit the transaction
        session.commit()
        logging.info("### Deletion successful in the database")
        response = {"flag": True, "message": "Deleted Successfully"}

        try :
            end_time = time.time()
            time_consumed = round(end_time - start_time, 4)

            audit_data_user_actions = {
                "service_name": "delete_automation_rule",
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "comments": f"Deleted automation rule: ID={automation_rule_id}, Name='{automation_rule_name}', Data={json.dumps(automation_rule_dict, default=str)}",
                "module_name": "Automation rule",  
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        return response

    except Exception as e:
        # Rollback in case of any errors
        session.rollback()
        logging.exception(f"### Exception occurred: {e}")
        message = f"Something went wrong while deleting rule. Rule ID={automation_rule_id}, Name='{automation_rule_name}', Data={json.dumps(automation_rule_dict)}"
        error_data = {
            "service_name": "delete_automation_rule",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Automation rule",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        response = {"flag": False, "error": str(e)}
        return response 

    finally:
        # Close the session
        session.close() 

# insert automation data into the database
# def insert_automation_data(data):
#     """
#     Inserts or updates automation rule data into the database.

#     This function handles both creation and editing of automation rules:
#     - If action is 'edit', it deletes the existing rule before re-inserting.

#     Args:
#         data (dict): A dictionary containing:
#             - action (str): Either "create" or "edit".
#             - automation_rule_id (int): ID of the rule to be edited (for edit action).
#             - tenant_name (str): Name of the tenant.
#             - username (str): Name of the user performing the action.
#             - db_name (str): Target tenant database name.
#             - data (dict): Nested dictionary containing automation_rule, block_details,
#                            follow-up rules, and step details.

#     Returns:
#         dict: A dictionary with:
#             - flag (bool): True if insertion is successful, False otherwise.
#             - message (str): Status message of the operation.
#             - error (str, optional): Error message if the operation failed.
#     """
#     logging.info("### Request data Recieved")
#     automation_rule_id = data.get("automation_rule_id", "")
#     action = data.get("action", "")
#     # module_name = data.get("module_name", "Automation rule")
#     start_time = time.time()
#     # logging.info(f"Request Data: {data}")
#     tenant_name = data.get("tenant_name", "")
#     request_received_at = data.get("request_received_at", "")
#     username = data.get("username", " ")
#     # Initialize the database connection
#     tenant_database = data.get("db_name", "altaworx_test")
#     data = data.get("data")
#     # database Connection
#     db = DB(tenant_database, **db_config)
#     common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

#     logging.debug(f"### action is {action}")
#     if action == "edit":
#         delete_automation_rule(data, automation_rule_id, tenant_database)
#     try:
#         # Insert into automation_rule and retrieve the ID
#         automation_rule_data = data["automation_data"]["automation_rule"]
#         automation_rule_name = automation_rule_data.get("automation_rule_name")
#         if action != "edit":
#             try:
#                 automation_rule_dataframe = db.get_data(
#                     "automation_rule",
#                     {"automation_rule_name": automation_rule_name, "is_active": True},
#                 )

#                 # Check if the DataFrame contains any rows
#                 if not automation_rule_dataframe.empty:
#                     return {
#                         "flag": False,
#                         "error_type": "Warning",
#                         "message": f"Cannot create duplicate automation rule: '{automation_rule_name}' already exists.",
#                     }
#             except Exception as e:
#                 logging.error(f"### Error while checking for duplicate automation rule: {e}")
#         automation_rule_id = db.insert_data(automation_rule_data, "automation_rule")

#         # Iterate over block_details
#         for block in data["automation_data"]["block_details"]:
#             automation_followup_id = None
#             # Check if automation_followup exists and insert it
#             if block.get("automation_rule_followup"):
#                 followup_data = block["automation_rule_followup"]
#                 automation_followup_id = db.insert_data(
#                     followup_data, "automation_rule_followup"
#                 )

#                 # Insert into automation_followup_detail
#                 for followup_detail in block["automation_rule_followup_detail"]:
#                     followup_detail["rule_followup_id"] = (
#                         automation_followup_id  # Link to followup ID
#                     )
#                     db.insert_data(followup_detail, "automation_rule_followup_detail")

#             # Insert into automation_rule_detail or step_details depending on the block
#             if "automation_rule_detail" in block:
#                 rule_detail_data = block["automation_rule_detail"]
#             else:
#                 rule_detail_data = block["step_details"]

#             rule_detail_data["automation_rule_id"] = (
#                 automation_rule_id  # Link to automation_rule_id
#             )
#             rule_detail_data["rule_followup_id"] = (
#                 automation_followup_id  # Link to followup ID
#             )
#             db.insert_data(
#                 rule_detail_data, "automation_rule_detail"
#             )  # Insert into rule detail
#             # Prepare the response
#         response = {
#             "flag": True,
#             "message": "Data Inserted Successfully",
#         }
#         try:
#             # End time calculation
#             end_time = time.time()
#             time_consumed = round(end_time - start_time, 4)

#             audit_data_user_actions = {
#                 "service_name": "insert_automation_data",
#                 "created_by": username,
#                 "status": str(response["flag"]),
#                 "time_consumed_secs": time_consumed,
#                 "tenant_name": tenant_name,
#                 "comments": "Inserted the automation rule data",
#                 "module_name": "Automation rule",  
#                 "request_received_at": request_received_at,
#             }
#             common_utils_database.update_audit(
#                 audit_data_user_actions, "audit_user_actions"
#             )
#         except Exception as e:
#             logging.warning(f"### Exception is {e}")
#         return response
#     except Exception as e:
#         # Handle exceptions and provide feedback
#         logging.exception(f"### Exception occurred: {e}")
#         message = "Something went wrong while the automation rule data is inserting"
#         # Error Management
#         error_data = {
#             "service_name": "insert_automation_data",
#             "error_message": str,
#             "error_type": type(e).__name__,
#             "users": username,
#             "tenant_name": tenant_name,
#             "comments": message,
#             "module_name":"Automation rule",
#             "request_received_at": start_time,
#         }
#         common_utils_database.log_error_to_db(error_data, "error_log_table")
#         response = {"flag": False, "error": str(e)}
#         return response

def insert_automation_data(data):
    """
    Inserts or updates automation rule data into the database.

    This function handles both creation and editing of automation rules:
    - If action is 'edit', it deletes the existing rule before re-inserting.

    Args:
        data (dict): A dictionary containing:
            - action (str): Either "create" or "edit".
            - automation_rule_id (int): ID of the rule to be edited (for edit action).
            - tenant_name (str): Name of the tenant.
            - username (str): Name of the user performing the action.
            - db_name (str): Target tenant database name.
            - data (dict): Nested dictionary containing automation_rule, block_details,
                           follow-up rules, and step details.

    Returns:
        dict: A dictionary with:
            - flag (bool): True if insertion is successful, False otherwise.
            - message (str): Status message of the operation.
            - error (str, optional): Error message if the operation failed.
    """
    logging.info(f"### insert_automation_data called with request data:\n{json.dumps(data, indent=2, default=str)}")

    automation_rule_id = data.get("automation_rule_id", "")
    action = data.get("action", "")
    # module_name = data.get("module_name", "Automation rule")
    start_time = time.time()
    # logging.info(f"Request Data: {data}")
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", " ")
    # Initialize the database connection
    tenant_database = data.get("db_name", "altaworx_test")
    data = data.get("data")
    # database Connection
    db = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    logging.debug(f"### action is {action}")
    if action == "edit":
        delete_automation_rule(data, automation_rule_id, tenant_database)
    try:
        # Insert into automation_rule and retrieve the ID
        automation_rule_data = data["automation_data"]["automation_rule"]
        automation_rule_name = automation_rule_data.get("automation_rule_name")
        if action != "edit":
            try:
                automation_rule_dataframe = db.get_data(
                    "automation_rule",
                    {"automation_rule_name": automation_rule_name, "is_active": True},
                )

                # Check if the DataFrame contains any rows
                if not automation_rule_dataframe.empty:
                    return {
                        "flag": False,
                        "error_type": "Warning",
                        "message": f"Cannot create duplicate automation rule: '{automation_rule_name}' already exists.",
                    }
            except Exception as e:
                logging.error(f"### Error while checking for duplicate automation rule: {e}")
        automation_rule_id = db.insert_data(automation_rule_data, "automation_rule")

        # Iterate over block_details
        for block in data["automation_data"]["block_details"]:
            automation_followup_id = None
            # Check if automation_followup exists and insert it
            if block.get("automation_rule_followup"):
                followup_data = block["automation_rule_followup"]
                automation_followup_id = db.insert_data(
                    followup_data, "automation_rule_followup"
                )

                # Insert into automation_followup_detail
                for followup_detail in block["automation_rule_followup_detail"]:
                    followup_detail["rule_followup_id"] = (
                        automation_followup_id  # Link to followup ID
                    )
                    db.insert_data(followup_detail, "automation_rule_followup_detail")

            # Insert into automation_rule_detail or step_details depending on the block
            if "automation_rule_detail" in block:
                rule_detail_data = block["automation_rule_detail"]
            else:
                rule_detail_data = block["step_details"]

            rule_detail_data["automation_rule_id"] = (
                automation_rule_id  # Link to automation_rule_id
            )
            rule_detail_data["rule_followup_id"] = (
                automation_followup_id  # Link to followup ID
            )
            db.insert_data(
                rule_detail_data, "automation_rule_detail"
            )  # Insert into rule detail
            # Prepare the response
        response = {
            "flag": True,
            "message": "Data Inserted Successfully",
        }
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = round(end_time - start_time, 4)

            audit_data_user_actions = {
                "service_name": "insert_automation_data",
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "comments": f"Inserted automation rule: '{automation_rule_name}' with data: {automation_rule_data}",
                "module_name": "Automation rule",  
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        return response
    except Exception as e:
        # Handle exceptions and provide feedback
        logging.exception(f"### Exception occurred: {e}")
        message = "Something went wrong while Inserting automation rule: '{automation_rule_name}' with data: {automation_rule_data}"
        # Error Management
        error_data = {
            "service_name": "insert_automation_data",
            "error_message": str,
            "error_type": type(e).__name__,
            "users": username,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name":"Automation rule",
            "request_received_at": start_time,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        response = {"flag": False, "error": str(e)}
        return response
##get automation rule details data for the automation rule
def get_automation_rule_details_data(data):
    """
    Retrieves detailed information about an automation rule for a given tenant and rule name.

    Args:
        data (dict): Dictionary containing required input parameters, including:
            - db_name (str): Tenant-specific database name.
            - tenant_name (str): Name of the tenant.
            - automation_rule_name (str): Name of the automation rule to fetch.
            - service_provider_name (str): (Optional) Name of the service provider (default: "AT&T - Telegence").

    Returns:
        dict: A dictionary with keys:
            - flag (bool): Indicates success or failure of the operation.
            - automation_rule_detail_data (list): List of rule details.
            - automation_rule_condition_dict (list): List of available rule conditions.
            - automation_rule_action_dict (list): List of available rule actions.
            - automation_rule_followup_effective_date_type_dict (list): List of follow-up types.
            - Has_Current_status_values (list): Filtered device status options.
            - features_data (list): List of mobility feature data.
            - message (str): Success or error message.
    """
    logging.info("### Function has started to get rule details")
    # Start time  and date calculation
    start_time = time.time()
    tenant_database = data.get("db_name", "")
    request_received_at = data.get("request_received_at", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_name = data.get("tenant_name", "Altaworx")
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    # # Convert the comma-separated string into a list
    # parent_tenant_query=f'''select parent_tenant_id from tenant where tenant_name='{tenant_name}'
    # '''
    # parent_tenant_id_df=common_utils_database.execute_query(parent_tenant_query,True)

    parent_tenant_query = '''SELECT parent_tenant_id FROM tenant WHERE tenant_name = %s'''
    parent_tenant_id_df = common_utils_database.execute_query(parent_tenant_query,flag=True,params=[tenant_name])

    if not parent_tenant_id_df.empty:
        parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

        if parent_tenant_id is not None:
            parent_tenant_id = int(parent_tenant_id)
            # parent_tenant_name_query = f'''
            #     SELECT tenant_name
            #     FROM tenant
            #     WHERE id = {parent_tenant_id}
            # '''
            # parent_tenant_name = common_utils_database.execute_query(parent_tenant_name_query, True)['tenant_name'].to_list()[0]

            parent_tenant_name_query = '''SELECT tenant_name FROM tenant WHERE id = %s'''

            parent_tenant_name_df = common_utils_database.execute_query(parent_tenant_name_query, flag=True, params=[parent_tenant_id]  )
            # Safely extract the tenant_name if the query returns results
            parent_tenant_name = ( parent_tenant_name_df['tenant_name'].to_list()[0] if not parent_tenant_name_df.empty else None)
            tenant_name = parent_tenant_name
    try:
        json_data = load_json()
        telegence_ids = get_provider_ids(json_data, tenant_name, ["Telegence"])
    except Exception as e:
        logging.error(f"### Error loading JSON: {e}")
        json_data = {}  # Fallback to empty dict if JSON fails
        telegence_ids = []  # Default to empty list
    # Convert the comma-separated string into a list
    service_provider_name = get_main_name_by_unique_name(json_data, tenant_name, "Telegence")
    # Fetch service provider ID safely
    service_provider_id = telegence_ids[0] if telegence_ids else None
    username = data.get("username", "")
    session_id = data.get("sessionID", "")
    try:
        database = DB(tenant_database, **db_config)

    except Exception as db_exception:
        logging.error(f"### Failed to connect to the database:{str(db_exception)}")
        return {"error": "Database connection failed.", "details": str(db_exception)}
    automation_rule_name = data.get("automation_rule_name", "")
    service_provider_name = data.get("service_provider_name", "AT&T - Telegence")
    try:
        logging.info(f"### Fetching automation rule ID for rule name: {automation_rule_name}")
        automation_rule_id = database.get_data(
            "automation_rule", {"automation_rule_name": automation_rule_name}, ["id"]
        )["id"].to_list()[0]
        logging.info(f"### Automation rule ID fetched:{automation_rule_id}")
        automation_rule_detail_data = database.get_data(
            "automation_rule_detail",
            {"automation_rule_id": automation_rule_id},
            [
                "rule_followup_id",
                "automation_rule_id",
                "rule_condition_id",
                "rule_condition_value",
                "rule_action_id",
                "rule_action_value",
                "condition_step",
            ],
        ).to_dict(orient="records")
        # Get integration_id
        integration_id = database.get_data(
            "serviceprovider",
            {"service_provider_name": service_provider_name},
            ["integration_id"],
        )["integration_id"].to_list()[0]
        # Fetch data from 'device_status' table
        device_status_data = database.get_data(
            "device_status",
            {"integration_id": integration_id, "allows_api_update": True},
            ["id", "display_name"],
        )
        # Convert the result to a list of dictionaries and remove duplicates based on 'id'
        Has_Current_status_values = [
                d for d in {
                    d["id"]: d for d in device_status_data.to_dict(orient="records")
                }.values()
                if d["display_name"] != "Change Phone Number"
            ]
        features_data = database.get_data(
            "mobility_feature",
            {"service_provider_id": service_provider_id},
            ["soc_code", "friendly_name"],
        ).to_dict(orient="records")
        automation_rule_condition_dict = database.get_data(
            "automation_rule_condition",
            {"is_active": True},
            ["id", "automation_rule_condition_name"],
        ).to_dict(orient="records")
        automation_rule_action_dict = database.get_data(
            "automation_rule_action",
            {"is_active": True},
            ["id", "automation_rule_action_name"],
        ).to_dict(orient="records")
        automation_rule_followup_effective_date_type_dict = database.get_data(
            "automation_rule_followup_effective_date_type",
            {"is_active": True},
            ["id", "description"],
        ).to_dict(orient="records")
        logging.info("### Data Fetched Successfully")
        # Prepare the response
        response = {
            "flag": True,
            "automation_rule_detail_data": automation_rule_detail_data,
            "automation_rule_condition_dict": automation_rule_condition_dict,
            "automation_rule_action_dict": automation_rule_action_dict,
            "automation_rule_followup_effective_date_type_dict": automation_rule_followup_effective_date_type_dict,
            "Has_Current_status_values": Has_Current_status_values,
            "features_data": features_data,
            "message": "Data Fetched Successfully",
        }
        # End time calculation
        end_time = time.time()
        time_consumed = round(end_time - start_time, 4)

        try:
            audit_data_user_actions = {
                "service_name": "get_automation_rule_details_data",
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": "Fetching the Automation Rule Details",
                "module_name": "Automation Rule",   
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception while updating audit exception is {e}")

        return response
    except Exception as e:
        logging.exception(f"### Exception is {e}")
        message = "Unable to fetch the automation rule details"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_automation_rule_details_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Automation Rule",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error("### Failed to update error details table")
        response = {
            "flag": True,  # In case of any error, we return flag as True to indicate request was processed
            "automation_rule_detail_data": [],
            "automation_rule_condition_dict": [],
            "automation_rule_action_dict": [],
            "automation_rule_followup_effective_date_type_dict": [],
            "Has_Current_status_values": [],
            "features_data": [],
            "message": message,
        }
        return response


##update automation rule data for the automation rule
def update_automation_actions_data(data):
    """
    Deactivates an automation rule by setting its 'is_active' field to False in the 'automation_rule' table.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): The tenant's database name.
            - request_received_at (str): Timestamp when the request was received.
            - tenant_name (str): Name of the tenant.
            - username (str): Name of the user making the request.
            - sessionID (str): Session ID for tracking.
            - changed_data (dict): Must include the 'id' of the record to be updated.

    Returns:
        dict: 
            - If successful: {"flag": True, "message": "..."}
            - If failure: {"flag": False, "message": "..."} with error details.
    """
    logging.info("### Request data Recieved for path update_automation_actions_data")
    # Start time  and date calculation
    start_time = time.time()
    # Extract database name and establish connection
    tenant_database = data.get("db_name", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    session_id = data.get("sessionID", "")
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error(f"### Failed to connect to the database : {str(db_exception)}")
        return {"error": "Database connection failed.", "details": str(db_exception)}
    changed_data = data.get("changed_data", {})
    # Extract data from input
    record_id = changed_data.get("id")  # Get the record ID to update
    # Validate that the record ID is provided
    if not record_id:
        return {"flag": False, "message": "Record ID is required and cannot be empty."}

    # Prepare update data
    updated_data = {"is_active": False}  # Data to update

    try:
        # Perform the update
        database.update_dict("automation_rule", updated_data, {"id": record_id})
        response = {
            "flag": True,
            "message": f"Record with ID {record_id} successfully updated to is_active=False.",
        }
        # End time calculation
        end_time = time.time()
        time_consumed = round(end_time - start_time, 4)
        try:
            audit_data_user_actions = {
                "service_name": "update_automation_actions_data",  
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"Updated Automation Rule record_id {record_id} to {updated_data}",
                "module_name": "Automation Rule",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception while updating audit exception is {e}")
        return response
    except Exception as e:
        # Log the exception and return failure response
        logging.exception(f"### Exception occurred during update: {e}")
        message = "Unable to update the automation rule"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "update_automation_actions_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Automation rule",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit exception is {e}")
        return {
            "flag": False,
            "message": "Failed to update the record in automation_rule.",
        }
