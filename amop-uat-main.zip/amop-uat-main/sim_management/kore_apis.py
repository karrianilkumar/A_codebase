"""
@Author1 : Phaneendra.Y
@Author2 : Burhan
@Author3 : Gopi Teja B
@Created Date: 2025-02-03
"""

# Importing the necessary Libraries
import os
import requests
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import base64
# from common_utils.timezone_conversion import *
from common_utils.kore import db_config

logging = Logging(name="kore_apis")

def get_access_token(client_id, client_secret):
    """
    Fetches and returns an OAuth2 access token from the Kore Wireless API 
    using the client credentials grant type.

    Args:
        client_id (str): The client ID issued by Kore Wireless for authentication.
        client_secret (str): The client secret associated with the client ID.

    Returns:
        str or None: The access token string if successfully retrieved, else None.
    """
    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret
    }
    token_url = 'https://api.korewireless.com/Api/api/token'
    try:
        response = requests.post(token_url, data=payload)
        response.raise_for_status()
        token_data = response.json()
        access_token = token_data.get("access_token")
        if access_token:
            logging.info("### Access Token Generated Successfully:")
            logging.info(f"### Access Token: {access_token}") 
            return access_token
        else:
            logging.info("### Error: Access token not found in response.")
            logging.info(f"### token_data : {token_data}")
            return None
        
    except requests.exceptions.RequestException as e:
        logging.error(f"### Error fetching access token: {e}")
        return None


def get_account_id_(data,tenant_id,kore_id,kore_integration_id,api_key=None):
    """
    Fetches the Kore account ID and access token for a given tenant and service provider 
    by calling the Kore Wireless API using OAuth2 authentication.

    Args:
        data (dict): Not used within this function, but passed from caller context.
        tenant_id (str or int): The tenant's unique ID in the system.
        kore_id (str or int): The service provider ID associated with Kore.
        kore_integration_id (str or int): The integration ID configured for Kore.
        api_key (str, optional): Optional API key used to authorize the request, if required.

    Returns:
        tuple or None:
            - (str, str): A tuple containing:
                - account_id (str): The Kore account ID fetched via API.
                - access_token (str): The OAuth2 bearer token used for API requests.
            - None: If any error occurs or no account ID is returned.
    """
    #email = os.environ['KORE_EMAIL']
    email = "czambrano@spectrotel.com"
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    base_url = database.get_data("integration", {"name": "Kore"})["website"].to_list()[
        0
    ]
    url = f"{base_url}v1/accounts?email={email}"

    # tenant_name = os.getenv("KORE_TENANT_NAME", "Spectrotel")
    # try:
    #     tenant_id = database.get_data("tenant", {"tenant_name": tenant_name}, ["id"])[
    #         "id"
    #     ].to_list()[0]
    # except Exception as e:
    #     logging.exception(f"An error occurred: {e}")
    details = database.get_data(
        "integration_authentication",
        {"integration_id": kore_integration_id, "tenant_id": tenant_id, "service_provider_id": kore_id},
        ["oauth2_client_id", "oauth2_client_secret", "token_value"],
    )
    client_id = details["oauth2_client_id"].to_list()[0]
    client_secret = details["oauth2_client_secret"].to_list()[0]
    api_key = details["token_value"].to_list()[0]
    access_token = get_access_token(client_id, client_secret)
    headers = {"Accept": "application/json", "Authorization": f"Bearer {access_token}"}
    if api_key:
        headers["x-api-key"] = api_key  # Include API Key if required
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        account_data = response.json()

        # Extract account-id from the list inside 'account'
        accounts = account_data.get("account", [])
        if accounts and isinstance(accounts, list):
            account_id = accounts[0].get(
                "account-id"
            )  # Get the first account's account-id
            logging.info(f"### account_data : {account_data}")
            return account_id, access_token
        else:
            logging.info("### Error: No accounts found or invalid response structure.")
            return None
    except requests.exceptions.RequestException as e:
        logging.info(f"### Error fetching account ID: {e}")
        logging.info(f"### Response: {response.text}")  # Debugging: Log the raw response
        return None


def get_account_id_old(api_key=None):
    """
    Fetches the Kore account ID and access token for a specific email and integration setup.

    Args:
        api_key (str, optional): Optional x-api-key for API access. If not provided, it is fetched from the database.

    Returns:
        tuple or None: 
            - (str) account_id: The account-id of the first account returned by Kore API.
            - (str) access_token: The generated OAuth2 access token.
            - Returns None if the request fails or if account details are not found.
    """
    # email = os.environ['EMAIL']
    email = 'czambrano@spectrotel.com'
    database = DB("common_utils", **db_config)
    base_url = database.get_data("integration", {"name": "Kore"})['website'].to_list()[0]
    url = f"{base_url}v1/accounts?email={email}"
    details = database.get_data(
            "integration_authentication", {"integration_id": "19", "tenant_id": "1", "service_provider_id":"126"}, ["oauth2_client_id", "oauth2_client_secret", "token_value"]
        )
    client_id = details["oauth2_client_id"].to_list()[0]
    client_secret = details["oauth2_client_secret"].to_list()[0]
    api_key = details["token_value"].to_list()[0]
    access_token = get_access_token(client_id, client_secret)
    logging.info("### Access Token of Kore got Generated")
    headers = {
        'Accept': 'application/json',
        'Authorization': f"Bearer {access_token}"
    }
    if api_key:
        headers['x-api-key'] = api_key  # Include API Key if required
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        account_data = response.json()

        # Extract account-id from the list inside 'account'
        accounts = account_data.get('account', [])
        if accounts and isinstance(accounts, list):
            account_id = accounts[0].get('account-id')  # Get the first account's account-id
            logging.info(f"### account_data : {account_data}")
            return account_id, access_token
        else:
            logging.info("### Error: No accounts found or invalid response structure.")
            return None
    except requests.exceptions.RequestException as e:
        logging.error(f"### Error fetching account ID: {e}")
        logging.error(f"### Response: {response.text}")  # Debugging: Log the raw response
        return None

def send_core_request(cost_center_pk, subscription_id, account_id, access_token):
    """
    Sends a POST request to the Kore Wireless API to associate a cost center with a subscription.

    Args:
        cost_center_pk (str or int): The primary key of the cost center to be associated.
        subscription_id (str): The Kore subscription ID for which the cost center needs to be set.
        account_id (str): The Kore account ID used in the API URL.
        access_token (str): The bearer token used for authorization in the API request.

    Returns:
        dict: A dictionary containing the API response and operation status:
            - "flag" (bool): True if the request was successful (status code 200 or 201), False otherwise.
            - "response" (dict): The JSON response returned by the API, or an error message in case of failure.
    """
    try:
        url = f"https://api.korewireless.com/connectivity/v1/accounts/{account_id}/subscription-requests/cost-center"

        payload = [{"cost-center-pk": cost_center_pk, "subscription-id": subscription_id}]
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "x-api-key": "FwEO4B4Fqq28VPsaetYh59xZ75wsUpow98XCbUFC",
            "Authorization": f"Bearer {access_token}",
        }
        logging.info(f"### Access Token of Kore got Generated, payload: {payload}, headers: {headers}, url is {url}")

        response = requests.request("POST", url, headers=headers, json=payload)
        if response.status_code in (200, 201):
            return {"flag": True, "response": response.json()}
        else:
            return {"flag": False, "response": response.json()}
    except Exception as e:
        logging.error(f"### Exception is : {e}")
        message = (
            "Something went wrong while processing the request in send_core_request"
        )
        response = {"flag": False, "message": message}
        return response


def send_provisioning_request(base_url, account_id, action, iccid, subscription_id, mail_to,access_token,api_key):
    """
    Function to send provisioning requests (terminate, suspend, reactivate, deactivate) to the API.
    Parameters:
        base_url (str): The base URL for the API.
        account_id (str): The account ID.
        action (str): The action to be performed (terminate, suspend, reactivate, deactivate).
        iccid (str): The ICCID of the subscription.
        subscription_id (str): The subscription ID.
        mail_to (str): The email address to send notifications to.
        force_enabled_esim (bool, optional): If the action is "terminate", whether to force terminate eSIM profiles.
    Returns:
        dict: The response JSON from the API.
    """

    try:
        url = f"{base_url}/v1/accounts/{account_id}/provisioning-requests/{action}"
        # Construct the subscription object from iccid and subscription_id
        subscriptions = [{
            "subscription-id": subscription_id,
            "iccid": iccid
        }]
        # Construct the payload
        payload = {
            action: {
                "subscriptions": subscriptions
                # "mail-to": mail_to
            }
        }
        # Convert payload to JSON
        # payload = json.dumps(payload_data)
        # Set headers
        final_headers = {
            "Authorization": f"Bearer {access_token}",
            'Accept': 'application/json',
            'x-api-key': api_key
        }
        logging.info(f"### final_headers: {final_headers}, payload: {payload}, url: {url}")
        # Send the request
        response = requests.post(url, headers=final_headers, json=payload)
        logging.info(f"### Response of send_provisioning_request: {response.text}")
        # Return the response text (or you could return the JSON response)
        if response.status_code in (200, 201):
            response_data = {
                "flag": True,
                "response": response.text,
                "status_code": response.status_code,
                "response_json": response.json(),
            }
        else:
            response_data = {
                "flag": False,
                "response": response.text,
                "status_code": response.status_code,
                "response_json": response.json(),
            }
        return response_data
    except Exception as e:
        logging.error(f"### Exception is : {e}")
        message = (
            f"Something went wrong updating the device status in korewireless{e}"
        )
        response = {"flag": False, "message": message}
        return response

def activate_provisioning_request(base_url, account_id, subscription_id, iccid, imei, activation_profile_id, mail_to, access_token, api_key):
    """
    Sends a provisioning activation request to the Kore Wireless API for a given subscription/device.

    Args:
        base_url (str): Base URL of the Kore Wireless API (currently unused in the request URL).
        account_id (str): Kore account ID used in the API endpoint.
        subscription_id (str): Unique ID for the subscription to be activated.
        iccid (str): Integrated Circuit Card Identifier for the SIM to activate.
        imei (str): International Mobile Equipment Identity of the device.
        activation_profile_id (str): Activation profile ID to apply during activation.
        mail_to (str): Email address to notify (currently commented out).
        api_key (str): API key required for Kore API authentication.

    Returns:
        dict: A dictionary containing the result of the request:
            - "flag" (bool): Indicates success (True) or failure (False).
            - "response" (str): Raw text response from the API.
            - "status_code" (int): HTTP status code of the response.
            - "response_json" (dict): Parsed JSON response body, if available.
    """
    url = f"https://api.korewireless.com/connectivity/v1/accounts/{account_id}/provisioning-requests/activate"

    # Construct the payload
    payload = {
        "activate": {
            "activation-state": "active",
            "subscriptions": [
                {
                    "subscription-id": subscription_id,
                    "iccid": iccid,
                    "imei": imei
                }
            ],
            #"mail-to": mail_to,  # Uncomment if this field is necessary
            "activation-profile-id": activation_profile_id
        }
    }

    final_headers = {
        "Authorization": f"Bearer {access_token}",
        'Accept': 'application/json',
        'x-api-key': api_key
    }

    try:
        # Make the POST request, ensure we're sending JSON
        logging.info(f"### final_headers: {final_headers}, payload: {payload}, url: {url}")
        response = requests.post(url, headers=final_headers, json=payload)  # Using 'json=payload'
        logging.info(f"### Kore Device Status-Activation, Carrier request response status code: {response.status_code}")
        logging.info(f"### Kore Device Status-Activation, Carrier request response body: {response.json()}")

        if response.status_code in (200, 201):
            # Return the JSON response
            response_data = {"flag": True, "response": response.text, "status_code": response.status_code, "response_json": response.json()}
            return response_data
        else:
            response_data = {"flag": False, "response": response.text, "status_code": response.status_code, "response_json": response.json()}
            return response_data
    except requests.exceptions.RequestException as e:
        logging.error(f"### Kore Device Status-Activation, Carrier request encountered an error: {e}")
        response_data = {"flag": False, "response": str(e)}
        return response_data


def base64_encode(plain_text):
    """Encodes a given plain text string into a Base64-encoded string."""
    # Convert the plain text to bytes, then encode it in Base64
    plain_text_bytes = plain_text.encode("utf-8")
    base64_encoded = base64.b64encode(plain_text_bytes).decode("utf-8")
    return base64_encoded

def base64_decode(base64_encoded_data):
    """Decodes a Base64-encoded string back into its original UTF-8 plain text."""
    # Decode the Base64 string to bytes
    base64_encoded_bytes = base64.b64decode(base64_encoded_data)
    # Convert the bytes back to a UTF-8 string
    decoded_string = base64_encoded_bytes.decode("utf-8")
    return decoded_string

def send_revio_request(service_id, username, password, token, main_url, cost_center):
    """
    Sends a GET request to the Revio API for a specific service ID and updates the CostCenter1 if present.
    Args:
        service_id (str): The service ID for which the request is being made.
        username (str): The username for authentication.
        password (str): The password for authentication (base64 encoded).
        token (str): The subscription key token (base64 encoded).
        main_url (str): The main URL of the Revio API.
        cost_center (str): The cost center value to update if CostCenter1 is present in the response.
    Returns:
        dict: A dictionary containing the result of the operation. The dictionary has a 'flag' key indicating success (True) or failure (False), and a 'message' key with additional information in case of failure.
    """
    # Prepare authentication and headers
    auth_token = base64_encode(f"{username}:{base64_decode(password)}")
    subscription_key = base64_decode(token)
    logging.info(auth_token, subscription_key)

    url = f"{main_url}/{service_id}"
    headers = {
        "Authorization": f"Basic {auth_token}",
        "Ocp-Apim-Subscription-Key": subscription_key,
        "Accept": "application/json",
    }

    # Send the request and handle the response
    try:
        response = requests.get(url, headers=headers)

        if response.status_code == 200:

            logging.info(f"### Request successful: {response.json()}")

            if "CostCenter1" in response.json():
                # Define the request payload
                data = {"CostCenter1": cost_center}

                # Send the request and handle the response
                response = requests.put(url, headers=headers, json=data)

                if response.status_code in [200, 202]:  # Success responses
                    logging.info(
                        f"### CostCenter1 for ICCID {service_id} updated successfully."
                    )
                    return {"flag": True}
                else:
                    logging.info(
                        f"### Failed to update CostCenter1 for ICCID {service_id}: {response.status_code} - {response.text}"
                    )
                    return {
                        "flag": False,
                        "message": f"Failed to update CostCenter1 for ICCID {service_id}: {response.status_code} - {response.text} ",
                    }

        else:
            logging.info(
                f"### Failed with status code {response.status_code}: {response.text}"
            )
            return {
                "flag": False,
                "message": f"Failed with status code {response.status_code}: {response.text}",
            }
    except Exception as e:
        logging.info(f"### Error during request: {str(e)}")
        return {"flag": False, "message": f" Failed to send message due to: {str(e)}"}
