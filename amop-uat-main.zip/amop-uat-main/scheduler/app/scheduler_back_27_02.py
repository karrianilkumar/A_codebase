"""
@author: Gopi Teja,Phaneendra
Created Date: 2022-11-23
"""

import json
import logging
import schedule
#import requests
import time
import requests
import datetime
import pytz

import os
import multiprocessing

# Define the 'clean_daily_sync' function
def clean_daily_sync(tenant_id):
    print(f"#### Cleaning up for {tenant_id}")
    try:
        # Call the clean_daily_sync endpoint before kore_daily_sync
        response = requests.post(f'http://kore_spectrocel:5000/kore_daily_sync',json={"tenant_id": tenant_id,"path":"/clean_daily_sync"})
        print(f"Response from Clean daily sync: {response.json()}")
    except Exception as e:
        print(f"Error calling clean_daily_sync: {e}")

def start_kore_dialy_sync(tenant_id):
    print(f"#### Started FM of {tenant_id}")

    # Call kore_daily_sync function (assuming Kore container exposes an endpoint to call this)
    try:
        response = requests.post(f'http://kore_spectrocel:5000/kore_daily_sync', json={"tenant_id": tenant_id,"path":"/kore_dialy_sync"})
        print(f"Response from Kore container: {response.json()}")
    except Exception as e:
        print(f"Error calling Kore container: {e}")


def run_schedule(job_func, at_time, *args):
    """
    Runs a scheduled job at the given UTC time daily.

    Parameters:
        job_func (function): The function to execute.
        at_time (str): Time in UTC format ('HH:MM').
        *args: Additional arguments to pass to the job function.
    """
    utc = pytz.utc

    def utc_job_wrapper():
        now_utc = datetime.datetime.now(utc).strftime("%H:%M")
        if now_utc == at_time:
            print(f"Running scheduled job at {now_utc} UTC")
            job_func(*args)
    print(f"Scheduled job at {at_time} UTC. starting...")
    # Check every minute to ensure execution at the correct UTC time
    schedule.every(1).minutes.do(utc_job_wrapper)

    print(f"Scheduled job at {at_time} UTC. rn...")

    while True:
        schedule.run_pending()
        time.sleep(1)

# def run_schedule(job_func, interval=None, at_time=None, *args):
#     if at_time:
#         print(f"Scheduling job at {at_time} UTC daily...")
#         schedule.every().day.at(at_time).do(job_func, *args)
#     elif interval:
#         print(f"Scheduling job every {interval} seconds...")
#         schedule.every(interval).seconds.do(job_func, *args)
#     else:
#         raise ValueError("You must specify either an interval or at_time.")

#     while True:
#         schedule.run_pending()
#         time.sleep(1)

# # def run_schedule(job_func, interval=None, at_time=None, *args):
# #     utc = pytz.utc
# #     if at_time:
# #         print(f"Scheduling job at {at_time} UTC daily...")

# #         def utc_job_wrapper():
# #             now_utc = datetime.datetime.now(utc).strftime("%H:%M")
# #             if now_utc == at_time:
# #                 job_func(*args)

# #         schedule.every(1).minutes.do(utc_job_wrapper)  # Check every minute
# #     elif interval:
# #         print(f"Scheduling job every {interval} seconds...")
# #         schedule.every(interval).seconds.do(job_func, *args)
# #     else:
# #         raise ValueError("You must specify either an interval or at_time.")

# #     while True:
# #         schedule.run_pending()
# #         time.sleep(1)

if __name__ == '__main__':
    # Email monitor process (or other task that needs scheduling)
    def scheduled_task(tenant_id):
        # First clean the data
        clean_daily_sync(tenant_id)
        # Then trigger the main kore_daily_sync
        start_kore_dialy_sync(tenant_id)
    # Define processes for each task
    ##scheduling the time to run dialy
    email_monitor_process = multiprocessing.Process(target=run_schedule, args=(scheduled_task, None,"15:50", 'altaworx_test'))

    # Start each process
    email_monitor_process.start()

    # Join each process to wait for them to finishjjoikjh
    email_monitor_process.join()

