"""
@author: Gopi Teja,Phaneendra
Created Date: 2022-11-23
"""

import json
import logging
import schedule
#import requests
import time
import requests
import datetime
import pytz

import os
import multiprocessing


##Kore daily sync function

# Define the 'clean_daily_sync' function
def clean_daily_sync(tenant_id):
    print(f"#### Cleaning up for {tenant_id}")
    try:
        # Call the clean_daily_sync endpoint before kore_daily_sync
        response = requests.post(f'http://carrier_data_sync_container:5000/kore_daily_sync',json={"tenant_id": tenant_id,"path":"/clean_daily_sync"})
        print(f"Response from Clean daily sync: {response.json()}")
    except Exception as e:
        print(f"Error calling clean_daily_sync: {e}")

def start_kore_daily_sync(tenant_id):
    print(f"#### Started start_kore_daily_sync of {tenant_id}")

    # Call kore_daily_sync function (assuming Kore container exposes an endpoint to call this)
    try:
        response = requests.post(f'http://carrier_data_sync_container:5000/run_scheduled_sync_tasks', json={"tenant_id": tenant_id,"path":"/kore_dialy_sync"})
        print(f"Response from Kore container: {response.json()}")
    except Exception as e:
        print(f"Error calling Kore container: {e}")

## Schedule the task to run at a specific time for kore_daily_sync
def scheduled_task(tenant_id):
    clean_daily_sync(tenant_id)
    start_kore_daily_sync(tenant_id)


## Schedule the task to run at a specific time for kore_daily_sync
def run_schedule():

    at_time =  "10:35"   # 4:55 PM IST converted to UTC (11:15 AM UTC)
    utc = pytz.utc

    now_utc = datetime.datetime.now(utc).strftime("%H:%M")
    print(f"monitoring..kore sync.{now_utc}")
    if now_utc == at_time:
        print(f"Running scheduled job at {now_utc} UTC")
        scheduled_task('altaworx_test')



'''
Webbing daily sync function
'''
## Define the 'start_webbing_daily_sync' function
def start_webbing_daily_sync(tenant_id):
    print(f"#### Started start_webbing_daily_sync of {tenant_id}")
    try:
        response = requests.post(f'http://carrier_data_sync_container:5000/run_scheduled_sync_tasks', json={"tenant_id": tenant_id, "path": "/webbing_dialy_syncs"})
        print(f"Response from Webbing container: {response.json()}")
    except Exception as e:
        print(f"Error calling Webbing container: {e}")



# Function to schedule Webbing sync
def run_schedule_webbing():
    print("Checking if it's time for Webbing sync...")
    at_time = "12:35"   # 5:35 PM IST converted to UTC (11:15 AM UTC)
    utc = pytz.utc

    now_utc = datetime.datetime.now(utc).strftime("%H:%M")
    print(f"monitoring.Webbing Sync..{now_utc}")
    if now_utc == at_time:
        print(f"Running Webbing scheduled job at {now_utc} UTC")
        start_webbing_daily_sync('altaworx_test')

##schedule the tasks for dialy Telgo Calls
# Function to trigger the Telgo caller
def start_telgo_caller(tenant_id):
    print(f"#### Started start_telgo_caller of {tenant_id}")
    try:
        response = requests.post(
            'http://carrier_data_sync_container:5000/run_scheduled_sync_tasks',
            json={"tenant_id": tenant_id, "path": "/initiate_telgoo5_sim_deactivation_sync"}
        )
        print(f"Response from Webbing container: {response.json()}")
    except Exception as e:
        print(f"Error calling Webbing container: {e}")

# Schedule to run every minute
def run_telgo():
    start_telgo_caller('altaworx_test')

schedule.every(1).minutes.do(run_telgo)


schedule.every(1).minutes.do(run_schedule)
schedule.every(1).minutes.do(run_schedule_webbing)

if __name__ == '__main__':
    while True:
        schedule.run_pending()
        time.sleep(1)

