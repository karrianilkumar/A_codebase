"""
main.py
Module for handling API requests and routing them to the appropriate function.
Functions:
- lambda_handler(event,context=None)
Author: Nikhil N, Phaneendra Y
Date: July 22, 2024
"""

import boto3
import json
import time
from datetime import datetime
import pytz
from common_utils.db_utils import DB
import os

# from common_utils.daily_migration_management.migration_api import MigrationScheduler
from migration_api import MigrationScheduler
from common_utils.email_trigger import (
    send_sns_email,
    get_memory_usage,
    memory_sns,
    insert_email_audit,
)
from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging
import requests
import random

logging = Logging(name="main")
##database configuration
# db_config = {
#     'host': "amoppostgres.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
#     'port': "5432",
#     'user': "root",
#     'password': "AmopTeam123"}

db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}

# Initialize the SNS client
sns = boto3.client("sns")
cloudwatch = boto3.client("cloudwatch")


def fetch_message_bodies(event):
    message_bodies = [record["body"] for record in event.get("Records", [])]
    return message_bodies

def post_with_retries(url, json, retries=1):
    '''
    main container caller function
    Args:
        url (str): The URL to send the POST request to.
        json (dict): The JSON data to include in the POST request.
        retries (int): Number of retry attempts in case of failure.
    '''
    delay = 1
    for attempt in range(1, retries + 1):
        try:
            resp = requests.post(url, json=json, timeout=60)
            if resp.status_code < 400:
                return resp.json()
        except requests.RequestException:
            pass  # ignore and retry

        logging.warning("Attempt %d failed; retrying in %ds", attempt, delay)
        time.sleep(delay + random.uniform(0, 0.5))
        delay *= 2
    logging.error("All %d attempts failed", retries)
    return None  # After all retries fail

def lambda_handler(event, context):
    """
    Handles incoming API requests and routes them to the appropriate function.

    Args:
        event (dict): The incoming API request event.

    Returns:
        dict: A dictionary containing the response status code and body.

    Example:
        >>> event = {'data': {'path': '/get_modules'}}
        >>> lambda_handler(event)
        {'statusCode': 200, 'body': '{"flag": True, "modules": [...]}'}
    """

    function_name = context.function_name if context else "user_authentication"

    # Set the timezone to India Standard Time
    india_timezone = pytz.timezone("Asia/Kolkata")
    performance_matrix = {}
    # Record the start time of the function
    start_time = time.time()
    utc_time_start_time = datetime.utcfromtimestamp(start_time)
    start_time_ = utc_time_start_time.replace(tzinfo=pytz.utc).astimezone(
        india_timezone
    )
    performance_matrix["start_time"] = (
        f"{start_time_.strftime('%Y-%m-%d %H:%M:%S')}.{int((start_time % 1) * 1000):03d}"
    )
    logging.info(f"Request received at {start_time}")

    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    # Extract the HTTP method, path, and query string parameters from the event
    logging.info("########event", event)
    if isinstance(event, dict):
        logging.info(f"after lambda sync event is {event}")
        data = event
        logging.info(f"request data is {data}")
        path = data.get("path", "")
        container_flag=data.get("container_flag",False)
        logging.info(f"Container flag 1 is {container_flag}")

        first_key = next(iter(event))
        if first_key == "data":
            path = data.get("path", "")
            if path:
                if path == "/lambda_sync_jobs":
                    scheduler = MigrationScheduler()
                    result = scheduler.lambda_sync_jobs_(data)
                elif path == "/main_migration_func":
                    migration_job = MigrationScheduler()
                    job_name = data["job_name"]
                    result = migration_job.main_migration_func(job_name)

            elif data.get("data",None):
                data_=data.get('data',None)
                logging.info(f"Data in event is {data_}")
                path = data_.get("path", "")
                logging.info(f"Path got is {path}")
                if path == "/lambda_sync_jobs":
                    scheduler = MigrationScheduler()
                    result = scheduler.lambda_sync_jobs_(data_)
                    if result:
                        state = f"JOB -- {data} success"
                    else:
                        state = f"JOB -- {data} failed"
                    return {"statusCode": 200, "body": json.dumps(state)}
                elif path == "/main_migration_func":
                    migration_job = MigrationScheduler()
                    job_name = data_["job_name"]
                    logging.info(f"Heree job name {job_name}")
                    result = migration_job.main_migration_func(job_name)
                    if result:
                        state = f"JOB -- {job_name} success"
                    else:
                        state = f"JOB -- {job_name} failed"
                    return {"statusCode": 200, "body": json.dumps(state)}
                else:
                    job_name = data["data"]["key_name"]
                    container_flag=data_["data"]["key_name"]
                    logging.info(f"Container flag is hereee {container_flag}")
                    if container_flag:
                        logging.info(f"Call the container here 1111  ")
                        url = f"http://54.152.69.196:5000/migration"
                        logging.info(f"Calling container with data: {data}")
                        try:
                            result=post_with_retries(url, data, retries=1)
                            response={"flag": True, "message": "Request forwarded to EC2 successfully"}
                            logging.info(f"Request forwarded to EC2 successfully")
                        except Exception as e:
                            logging.info(f"Error in calling container {e}")
                            response={"flag": False, "message": "Error in forwarding request to EC2"}
                        return response
                    logging.info(f"job name is {job_name}")
                    migration_job = MigrationScheduler()
                    key_data = data.get("data", None)
                    logging.info(f"input key data here 1 {key_data}")
                    result = migration_job.lambda_sync_jobs_(key_data)
                    if result:
                            state = f"JOB -- {key_data} success"
                    else:
                        state = f"JOB -- {key_data} failed"
                    return {"statusCode": 200, "body": json.dumps(state)}

            else:
                job_name = data["data"]["key_name"]
                container_flag=data["data"]["container_flag"]
                logging.info(f"Container flag is hereee {container_flag}")
                if container_flag:
                    logging.info(f"Call the container here 222 ")
                    url = f"http://54.152.69.196:5000/migration"
                    logging.info(f"Calling container with data: {data}")
                    try:
                        result=post_with_retries(url, data, retries=1)
                        response={"flag": True, "message": "Request forwarded to EC2 successfully"}
                        logging.info(f"Request forwarded to EC2 successfully")
                    except Exception as e:
                        logging.info(f"Error in calling container {e}")
                        response={"flag": False, "message": "Error in forwarding request to EC2"}
                    return response

                logging.info(f"job name is {job_name}")
                migration_job = MigrationScheduler()
                key_data = data.get("data", None)
                logging.info(f"input key data here 2 {key_data}")
                result = migration_job.lambda_sync_jobs_(key_data)

        elif path == "/lambda_sync_jobs":
            scheduler = MigrationScheduler()
            result = scheduler.lambda_sync_jobs_(data)
        elif path == "/main_migration_func":
            migration_job = MigrationScheduler()
            job_name = data["job_name"]
            result = migration_job.main_migration_func(data, job_name)
        else:

            # Fetch the bodies
            message_bodies = fetch_message_bodies(event)

            logging.info("=====================", message_bodies)
            logging.info(f"type {type(message_bodies)}")

            job_name = message_bodies[0]

            migration_job = MigrationScheduler()
            result = migration_job.main_migration_func(job_name)

    if result:
        state = f"JOB -- {job_name} success"
    else:
        state = f"JOB -- {job_name} failed"

    # data = event.get('data')
    # if not data:
    #     data = {}

    # data = data.get('data', {})
    # path = data.get('path', '')
    # user = data.get('username') or data.get('user_name') or data.get('user') or 'superadmin'
    # result="Done"

    # if path == 'migration_api':
    #     # return  {"Return_dict": {"Tax_precent": "10"}}

    # else:
    #     result = {'flag': False, 'error': 'Invalid path or method'}

    memory_limit = int(context.memory_limit_in_mb)
    memory_used = int(get_memory_usage()) + 100
    final_memory_used = get_memory_usage()
    logging.info(
        f"$$$$$$$$$$$$$$$$$$$$$$$Final Memory Used: {final_memory_used:.2f} MB"
    )
    memory_sns(memory_limit, memory_used, context)

    return {"statusCode": 200, "body": json.dumps(state)}
