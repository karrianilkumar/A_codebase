"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24
"""
# Importing the necessary Libraries
from decimal import Decimal
import json
import logging
import os
import ast
import requests
import os
import pandas as pd
from common_utils.db_utils import DB
import psycopg2
from pandas import Timestamp
from datetime import datetime
from dotenv import load_dotenv
from dateutil.relativedelta import relativedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import concurrent.futures
import time
from io import BytesIO
from sqlalchemy import create_engine, text
import base64
import re
import pytds
import uuid
import threading
from pytz import timezone
import numpy as np
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import uuid
import time, random

# Database configuration
db_config = {
     "host": os.environ["HOST"],
     "port": os.environ["PORT"],
     "user": os.environ["USER"],
     "password": os.environ["PASSWORD"],

 }





##function caller where the functions begins
def funtion_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler
    if path == "/verizon_bc_archive_devices":
        result = verizon_bc_archive_devices(data)
    elif path == "/verizon_bc_change_customer_rate_plan":
        result = verizon_bc_change_customer_rate_plan(data)
    elif path == "/verizon_bc_change_carrier_rate_plan":
        result = verizon_bc_change_carrier_rate_plan(data)
    elif path== "/verizon_bc_update_device_status":
        result = verizon_bc_update_device_status(data)
    elif path== "/verizon_bc_change_iccid_imei":
        result = verizon_bc_change_iccid_imei(data)
    elif path== "/verizon_bc_assign_customer":
        result = verizon_bc_assign_customer(data)
    elif path== "/verizon_bc_line_sync":
        result = verizon_bc_line_sync(data)
    ##else condition to handle the invalid path method
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result


## Function to get Carrier API details
def get_carrier_api_details(service_provider,change_type,common_utils_database):
    '''
    Function to get the Carrier API URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The Carreir API URL,app_id,app_secret if found, otherwise None.'''
    # Initialize variables
    carrier_api_url=None
    app_id=None
    app_secret=None
    carrier_limit=None
    alternative_api_url=None
    ##carrier api query and their limits query
    carrier_details= common_utils_database.get_data(
    "bulk_change_carrier_limits", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["carrier_api_url","app_id","app_secret","carrier_limit","alternative_api_url"]
    )
    logging.info(f"carrier_details: {carrier_details}")
    if not carrier_details.empty:
        ##fetching the carrier API limits
        carrier_api_url=carrier_details.iloc[0]['carrier_api_url']
        app_id=carrier_details.iloc[0]['app_id']
        app_secret=carrier_details.iloc[0]['app_secret']
        carrier_limit=carrier_details.iloc[0]['carrier_limit']
        alternative_api_url=carrier_details.iloc[0].get('alternative_api_url', None)
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url
    else:
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url

##Archive devices function 
def verizon_bc_archive_devices(data):
    """
    Archives devices from the system based on the provided ICCIDs.

    This function is typically triggered during a bulk change operation, where a list of SIM cards
    (identified by their ICCIDs) needs to be marked as archived in the system. Archiving a device
    means it is no longer considered active or in use, and its status is updated accordingly
    in relevant tables (e.g., inventory, assignment logs, usage tracking).

    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs to be archived.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
            - other metadata as needed for auditing or tracking.

    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
    """
    logging.info(f"Received data for archiving devices: %s", data)
    start_time = time.time()
    # Validate required fields
    iccids = data.get("iccids", [])
    invalid_iccids = data.get("invalid_iccids", [])
    tenant_id = data.get("tenant_id", [])
    bulk_change_id = data.get("bulk_change_id", "")
    created_by=data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    service_provider = data.get("service_provider", "")
    role_name= data.get("role", "")
    service_provider_id = data.get("service_provider_id", "")
    username= data.get("username", "")
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###verizon_bc_archiving devices and {tenant_name} time is {now}")
    #database connection
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### verizon_bc_archive_devices and {tenant_name} DB connection error: %s", e)
        return {"flag":False,"message": "DB connection failed", "details": str(e)}
    # Audit - start
    bulk_change_audit_action(data, common_utils_database,
                 action=f"Bulk Change Process Initiated"
                )
    live_progress_percentage_tracker(database, bulk_change_id,25)
    try:
        bulk_change_requests = database.get_data(
                'sim_management_bulk_change_request',
                {"bulk_change_id": bulk_change_id},
                ['id', 'iccid']
        )
        if bulk_change_requests.empty:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_archive_devices",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###verizon_bc_archive_devices rate plan and {tenant_name} Audit logging failed: {e}")
                return response
        ##main login to archive the devices
        # Map ICCID to request ID for fast access
        live_progress_percentage_tracker(database, bulk_change_id,40)
        iccid_to_request_id = dict(zip(bulk_change_requests["iccid"], bulk_change_requests["id"]))
        # Step 2: Archive valid ICCIDs in inventory
        database.update_dict(
            "sim_management_inventory",
            {"is_active": False,"is_deleted": True},
            and_conditions={"tenant_id": tenant_id},
            in_conditions={"iccid": iccids},
        )
        logging.info(f"### verizon_bc_archive_devices and {tenant_name} archived {len(iccids)} devices in inventory")

        # Prepare logs
        log_entries = []
        invalid_log_entries = []


        # Valid ICCIDs
        for iccid in iccids:
            request_id = iccid_to_request_id.get(iccid)
            if request_id:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Archive Device: {iccid}",
                    "request_text": "Update AMOP",
                    "has_errors": False,
                    "response_status": "PROCESSED",
                    "response_text": "Device archived successfully",
                    "error_text": "",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### verizon_bc_archive_devices and {tenant_name} inserted {len(log_entries)} log entries for bulk change request")
        #updating bulk change request tables     
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len(iccids),"is_processed":True,"has_errors":False,
                    "processed_date": now,"status_details":"Device archived successfully"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": iccids},
        )
        # preparing the payload for history table update
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": iccids,
                                    "msisdns":[],
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        # Call the history table update API  
        try:
            logging.info(f"### verizon_bc_archive_devices and {tenant_name} sync call has started for history table")
            threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### verizon_bc_archive_devices and {tenant_name} Exception in thread: {e}")  
        
        # Invalid SIMs
        live_progress_percentage_tracker(database, bulk_change_id,70)

        invalid_iccids = data.get("invalid_iccids", [])
        for iccid in invalid_iccids:
            request_id = iccid_to_request_id.get(iccid)
            invalid_log_entries.append({
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Archive Device Failed: {iccid}",
                "request_text": "Update AMOP",
                "has_errors": True,
                "response_status": "ERROR",
                "response_text": "Invalid SIM - could not be processed",
                "error_text": "Invalid ICCID",
                "processed_date": now,
                "processed_by": created_by,
                "created_by": created_by,
                "created_date": now,
                "is_deleted": False,
                "is_active": True
            })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        #  Step 3: Bulk insert all logs
        if invalid_log_entries:
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_log")
        logging.info(f"### verizon_bc_archive_devices and {tenant_name} archived {len(iccids)} devices successfully")


        # Update the status of the bulk change request to PROCESSED
        database.update_dict(
                'sim_management_bulk_change',
                {
                    "status": "PROCESSED",
                    "success": len(iccids),
                    "processed_date": now
                },
                {'id': bulk_change_id}
            )
        ##Future Upudates will be done here 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #below sync url and payload used to sync the inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(data, common_utils_database,
                 action=f"Sync To 1.0 Tables"
                )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        try:
            logging.info(f"### verizon_bc_archive_devices and {tenant_name} sync call has started")

            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### verizon_bc_archive_devices and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### verizon_bc_archive_devices and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### verizon_bc_archive_devices and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### verizon_bc_archive_devices and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # Attempt to audit the actionn
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_archive_devices",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for archive devices.{bulk_change_id}",
                "request_received_at": now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database,
                 action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### verizon_bc_archive_devices and {tenant_name} Audit logging failed: {e}")
        # Attempt to audit the actionn
        bulk_change_audit_action(data, common_utils_database,
                 action=f"Bulk Change Process Completed"
                )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### verizon_bc_archive_devices and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )

        return response
    except Exception as e:
        logging.exception(f"verizon_bc_archive_devices and {tenant_name} Error during bulk change processing for archive status verizon_bc_archive_devices: {str(e)}")
        # Update the status of the bulk change request to ERROR
        # Log the error
        error_message = f"Error during bulk change processing for archive status verizon_bc_archive_devices: {str(e)}"
        # response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        logging.error(f"### verizon_bc_archive_devices and {tenant_name} Error during bulk change processing for archive status verizon_bc_archive_devices: {str(e)}")
        # Prepare error response
        response = {
            "flag": False,
            "message": "Bulk change request processing failed for verizon_bc_archive_devices.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(iccids),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log error to database
            error_data = {
                "service_name": "verizon_bc_archive_devices",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for verizon_bc_archive_devices:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### verizon_bc_archive_devices and {tenant_name} Exception in logging error data to DB: {e}")
        return response

## Change customer rate plan function
def verizon_bc_change_customer_rate_plan(data):
    """
    Change the customer rate plan for the given devices as part of a bulk change operation.
   
    this function is typically triggered during a bulk change operation where a list of SIM cards needs to have their customer rate plans updated.
    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs used to identify devices.
            -changed_data (dict): Dictionary containing the rate plan changes.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
            - other metadata as needed for auditing or tracking.
 
    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
 
    Returns:
        dict: Result of the operation with flags, messages, and details.
    """
    logging.info(f"### Received data for changing customer rate plan: %s", data)
    # Start timing the function execution
    start_time = time.time()
    # Extract all required fields from input data
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id", "")
    created_by = data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    tenant_id= data.get("tenant_id", "")
    service_provider = data.get("service_provider", "")
    service_provider_id = data.get("service_provider_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    invalid_iccids = data.get("invalid_iccids", [])
    invalid_ids=data.get('invalid_ids','')
    # Validate required fields
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###verizon_bc_change_customer_rate_plan and {tenant_name} time is {now}")
    try:
        # Connect to main and audit databases
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### DB connection error: %s", e)
        return {"flag": False, "message": "DB connection failed", "details": str(e)}
    try:
        # Audit - Start
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Bulk Change Process Initiated"
        )
        live_progress_percentage_tracker(database, bulk_change_id,25)
        
        # Fetch bulk change request entries for valid ICCIDs
        bulk_change_requests = database.get_data(
            'sim_management_bulk_change_request',
            {"bulk_change_id": bulk_change_id},
            ['id', 'iccid','change_request']
        )
        if not bulk_change_requests.empty:
            change_request_json = bulk_change_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_change_customer_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###verizon_bc_change_customer_rate_plan and {tenant_name} Audit logging failed: {e}")
                return response
            
        # Map iccids to request IDs
        live_progress_percentage_tracker(database, bulk_change_id,40)
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        customer_rate_plan_update=change_request_json.get("CustomerRatePlanUpdate","")
        customer_rate_plan_id=customer_rate_plan_update.get("CustomerRatePlanId","")
        customer_rate_pool_id=customer_rate_plan_update.get("CustomerPoolId","")
        effective_date=customer_rate_plan_update.get("EffectiveDate","")
        rate_plan_db_name=None
        rate_pool_db_name=None
        plan_mb=None
        # Validate input data
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_name","plan_mb"]   
            )
            if not rate_plan_data.empty:
                rate_plan_db_name = rate_plan_data["rate_plan_name"].to_list()[0]
                plan_mb = rate_plan_data["plan_mb"].to_list()[0]

        if customer_rate_pool_id:
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                rate_pool_db_name = rate_pool_data["name"].to_list()[0]
        
        update_fields={}
        # Extract valid ICCIDs
        # Prepare an update dict dynamically
        if customer_rate_plan_id is None:
            update_fields["customer_rate_plan_id"] = None
            update_fields["customer_rate_plan_name"] = None
        elif str(customer_rate_plan_id).strip() != "-1":
            update_fields["customer_rate_plan_id"] = customer_rate_plan_id
            update_fields["customer_rate_plan_name"] = rate_plan_db_name
        if customer_rate_pool_id is None:
            update_fields["customer_rate_pool_id"] = None
            update_fields["customer_rate_pool_name"] = None
        elif str(customer_rate_pool_id) != "-1":
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id	
            update_fields["customer_rate_pool_name"] = rate_pool_db_name

        if effective_date:
            update_fields["effective_date"] = effective_date
        if plan_mb:
            update_fields["customer_data_allocation_mb"] = plan_mb
        else:
            update_fields["customer_data_allocation_mb"] = None




        # Update the SIM management inventory with the new rate plan
        if update_fields.items():
            logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Updating SIM management inventory with updated fields: {update_fields}")
            database.update_dict(
            "sim_management_inventory",update_fields,
            and_conditions={"tenant_id":tenant_id,"is_active": True},
            in_conditions={"iccid": iccids},
            
            )
 
        # Map ICCID to request ID for logging
        iccid_to_request_id = dict(zip(bulk_change_requests["iccid"], bulk_change_requests["id"]))
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entries = []
        invalid_log_entries = []
 
        # Log valid ICCIDs
        for iccid in iccids:
            request_id = iccid_to_request_id.get(iccid)
            if not customer_rate_plan_id and not customer_rate_pool_id:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Change Customer Rate Plan",
                    "request_text": "Update AMOP",
                    "has_errors": not customer_rate_plan_id,
                    "response_status": "PROCESSED" if customer_rate_plan_id else "ERROR",
                    "response_text": "Changed customer rate plan successfully" if customer_rate_plan_id else "Rate plan not updated",
                    "error_text": "" if customer_rate_plan_id else "Rate plan not found or inactive",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
            else:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Change Customer Rate Plan",
                    "request_text": "Update AMOP",
                    "has_errors": not customer_rate_plan_id,
                    "response_status": "PROCESSED",
                    "response_text": "Changed customer rate plan successfully",
                    "error_text": "",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} inserted {len(log_entries)} log entries for bulk change request")
        #update       
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len(iccids),"is_processed":True,"has_errors":False,
                    "processed_date": now,"status_details":"Changed customer rate plan successfully"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": iccids},
        )
        # Prepare payload for history table update
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": iccids,
                                    "msisdns":[],
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        if effective_date:
            payload_history_table["data"]["effective_date"] = effective_date
        # Call the history table update API  
        try:
            logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} sync call has started for history table")
            threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")  
        
        live_progress_percentage_tracker(database, bulk_change_id,70)
        if invalid_iccids:
            logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                invalid_log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Change Customer Rate Plan Failed",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if invalid_log_entries:
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_log")
        logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} inserted {len(invalid_log_entries)} log entries for bulk change request")
        # Update bulk change status to PROCESSED
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "success": len(iccids),
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Below sync url and payload used to sync the inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Sync To 1.0 Tables"
        )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        try:
            logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} sync call has started")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        # Prepare success response
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "msisdns": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # audit the auditing log
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_change_customer_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing customer rate plan for devices.{bulk_change_id}",
                "request_received_at":now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database, action=f"Auditing")

        except Exception as e:
            logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Audit logging failed: {e}")
        # audit the auditing log
        bulk_change_audit_action(data, common_utils_database, action=f"Bulk Change Process Completed")
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        return response
 
    except Exception as e:
        # Main exception block
        logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processingg: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(iccids),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "verizon_bc_change_customer_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
 



##Update Device Status function
def verizon_bc_update_device_status(data):
    """
   Update the device status using the Verizon API.

    This function processes a list of MSISDNs and updates their device status in the Verizon system.
    It performs the following steps:
        - Retrieves API credentials and configuration limits based on the service provider and change type.
        - Fetches bulk change requests and maps MSISDNs to their respective request payloads.
        - Iteratively calls the Verizon API for each MSISDN with retry logic.
        - Updates status in the request and inventory tables based on API responses.
        - Logs both success and failure results into the bulk change log table.
        - Handles any invalid MSISDNs or request IDs by logging them appropriately.
        - Marks the bulk change as processed.
        - Records an audit entry and error logs in case of exceptions.

    Args:
        data (dict): Input dictionary containing the following keys:
            - msisdns (list): List of MSISDNs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains the payload structure to send to the Verizon API.
            - created_by (str): Username of the user initiating the request.
            - service_provider (str): Name of the carrier or service provider.
            - change_type (str): Type of update being performed (e.g., SIM status or device status).
            - tenant_id (str): ID of the tenant initiating the request.
            - tenant_name (str): Name of the tenant for logging/auditing purposes.
            - db_name (str): Database name associated with the tenant.
            - username (str): Username to use in audit logs.
            - invalid_msisdns (list): MSISDNs that failed validation before processing.
            - invalid_ids (list): Request IDs associated with invalid rows.
            - request_received_at (str): Timestamp when the request was received (optional).

    Returns:
        dict: A response object indicating the result of the operation, containing:
            - flag (bool): True if processing completed without unhandled exceptions.
            - message (str): Summary message indicating the result.
            - processed (int): Number of MSISDNs processed.
            - msisdns (list): List of MSISDNs attempted.
            - invalid_msisdns (list): List of MSISDNs skipped due to invalid state.
            - bulk_change_id (str): ID of the bulk change request.
            - error (str, optional): Error message in case of failure.
    """
    logging.info(f"### Received data for updating device status: {data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    invalid_iccids = data.get("invalid_iccids", [])
    invalid_ids = data.get("invalid_ids", [])
    status_update = data.get("changed_data", {}).get("UpdateStatus", {})
    integration_id=data.get("integration_id", "")
    service_provider_id = data.get("service_provider_id", "")
    device_status_id = data.get("device_status_id","")
    ip_address=data.get("changed_data", {}).get("Request", {}).get("ipAddress") 

    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###verizon_bc_update_device_status and {tenant_name} time is {now}")

    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### verizon_bc_update_device_status and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### verizon_bc_update_device_status and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    
    try:
        # Get carrier API credentials and configuration
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        remaining = list(iccids)
        if not bulk_requests_df.empty:
            change_request_json=bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_update_device_status",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### verizon_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
                return response
        requests_map = dict(zip(bulk_requests_df["iccid"], bulk_requests_df["change_request"]))
        if isinstance(change_request_json, str):
            change_request_json = json.loads(change_request_json)
        update_status=change_request_json.get("UpdateStatus","")
        sim_status=update_status
        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Update status: {update_status}")
        request_json=change_request_json.get("Request","")
        #new_iccid=request_json.get("ICCID","")
        #new_imei=request_json.get("IMEI","")
        rateplancode=request_json.get("RatePlanCode","")
        reasoncode=request_json.get("ReasonCode","")
        mdnzipcode=request_json.get("MdnZipCode","")
        ppu_data = request_json.get("thingSpacePPU", {})
        first_name = ppu_data.get("FirstName", "")
        last_name = ppu_data.get("LastName", "")
        address_line = ppu_data.get("AddressLine", "")
        city = ppu_data.get("City", "")
        state = ppu_data.get("State", "")
        zip_code = ppu_data.get("ZipCode", "")
        country = ppu_data.get("Country", "")
        thing_space_ppu = request_json.get("thingSpacePPU", {})

        updated_data= {}
        updated_data = {
            "user_address": json.dumps(thing_space_ppu)
        }
        inventory_update={}
        rate_plan_id = None
        rate_plan_code = None
        rate_plan_data = pd.DataFrame()
        update_fields = {}
        if rateplancode:
            rate_plan_data = database.get_data(
            "carrier_rate_plan",
            {"rate_plan_code": rateplancode, "is_active": True},
            ["id","rate_plan_code"]
            )
        if not rate_plan_data.empty:
            rate_plan_id = rate_plan_data["id"].to_list()[0]
            rate_plan_code=rate_plan_data["rate_plan_code"].to_list()[0]#friendly_name
        if rate_plan_id:
            update_fields["carrier_rate_plan_id"] = rate_plan_id
        if rate_plan_code:
            update_fields["carrier_rate_plan_name"] = rate_plan_code
        else:
            update_fields["carrier_rate_plan_name"] = rateplancode
        
        # Validate required fields            
        account_data= database.get_data(
            "integration_authentication",
            {"integration_id": integration_id, "service_provider_id": service_provider_id,},
            ["oauth2_custom1"]
        )
        if not account_data.empty:
            accountname = account_data.iloc[0]["oauth2_custom1"]
        else:
            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Account name not found for integration ID: {integration_id}")
            accountname = None
        device_status_data = pd.DataFrame()
        if device_status_id:
            device_status_data = database.get_data(
                "device_status",
                {"id": device_status_id, "is_active": True},
                ["id", "display_name"]
            )    
        if not device_status_data.empty:
            device_status = device_status_data["display_name"].iloc[0]
        else:
            # if status not found
            device_status = None
        if device_status_id:
            inventory_update["device_status_id"]= int(device_status_id)
            inventory_update["sim_status"]= device_status
        else:
            inventory_update["sim_status"]=status_update
        
        ##fetching the requests ids
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        succesfull_iccids=[]
        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Fetching access token and session ID")
        access_id,session_id=get_verizon_token_details(app_id,app_secret)
        if not access_id or not session_id:
            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Failed to fetch access token or session ID")
            return {"flag": False, "message": "Failed to fetch access token or session ID"}
        #constracting header 
        headers = {
            "Authorization": f"Bearer {access_id}",
            "VZ-M2M-Token": session_id,
            "Content-Type": "application/json",
        }
        url=None
        payload=None
        if update_status.lower() == "inventory":
            if not iccids:
              iccids=invalid_iccids
              remaining=list(invalid_iccids)
        if update_status.lower()=="deactive":
            update_status="deactivate"
        # elif update_status.lower() == "pending activation": 
        #     update_status = "preactive"   
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")

        # Execute API calls in parallel using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}
                for iccid in batch:
                    json_request=requests_map.get(iccid)
                    logging.info(f"### verizon_bc_update_device_status and {tenant_name} Processing ICCID: {iccid} with request: {json_request}")
                    if isinstance(json_request, str):
                       json_request = json.loads(json_request)
                    req = json_request.get("Request", {})
                    new_iccid=req.get("ICCID","")
                    new_imei=req.get("IMEI","")
                    update_status = update_status.strip().lower()
                    if update_status in ("restore","suspend"):
                        url = f"{carrier_api_url}/{update_status}"
                        payload ={   
                            "devices": [
                                {
                                "deviceIds": [
                                    {
                                    "id": new_iccid,
                                    "kind": "iccid"
                                    }
                                ]
                                }
                            ]
                        }
                    elif update_status == "deactivate":
                        url = f"{carrier_api_url}/{update_status}"
                        # if update_status.lower() == "preactive":
                        #     url = f"{carrier_api_url}/add"
                        payload = {
                                    "devices": [
                                    {
                                        "deviceIds": [
                                        {
                                            "id": new_iccid,
                                            "kind": "iccid"
                                        }
                                        ]
                                    }
                                    ],
                                    "reasonCode": reasoncode,
                                }
                    else:
                        if update_status.lower() == "active" and update_status.lower() != "inventory":
                            update_status = "activate"
                            url = f"{carrier_api_url}/{update_status}"
                            payload={
                                "devices": [
                                        {
                                        "deviceIds": [
                                            {
                                            "kind": "iccid",
                                            "id": new_iccid
                                            },
                                            {
                                            "kind": "imei",
                                            "id": new_imei
                                            }
                                        ],
                                        "ipAddress": ip_address
                                        }
                                    ],
                                    "accountName": accountname,
                                    "servicePlan": rateplancode,
                                    "publicIpRestriction": "Restricted",
                                    "mdnZipCode": mdnzipcode,
                                    "primaryPlaceOfUse": {
                                        "customerName": {
                                        "firstName": first_name,
                                        "lastName": last_name
                                        },
                                        "address": {
                                        "addressLine1": address_line,
                                        "city": city,
                                        "state": state,
                                        "zip": zip_code,
                                        "country":country
                                        }
                                    }
                                }

                    def task(iccid=iccid, url=url, payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        api_success = False
                        # Retry logic
                        if update_status.lower() != "inventory":
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### verizon_bc_update_device_status and {tenant_name} Attempting {attempt} for iccid: {iccid} with URL: {url}")
                                    resp = requests.post(url, json=payload, headers=headers, timeout=60)
                                    logging.info(f"### verizon_bc_update_device_status and {tenant_name} Response Code: {resp.status_code} for iccid: {iccid}")
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    status = "INPROGRESS" if success else "API_FAILED"
                                    if success:
                                        succesfull_iccids.append(iccid)
                                        break
                                except Exception as e:
                                    result = str(e)
                                    logging.warning(f"### verizon_bc_update_device_status and {tenant_name} Attempt {attempt} failed for iccid: {iccid}: {result}")
                                    time.sleep(RETRY_DELAY)

                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {"status": status, "has_errors": not success, "is_processed": True,
                            "processed_date": now,"status_details":result},
                                and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                            )
                            # Prepare log entry
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                "log_entry_description": "Update Verizon Subscriber: Verizon API",
                                "request_text": json.dumps(payload),
                                "has_errors": not success,
                                "response_status":"PROCESSED" if success else "API_Failed",
                                "response_text": result,
                                "error_text": "" if success else result,
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")

                            # Update request status in DB
                            # Update inventory if successful
                            if success:
                                payload={
                                        "deviceId": {
                                        "id": iccid,
                                        "kind": "iccid"
                                         }
                                        } 
                                # second API call to fetch device details
                                api_success = False
                                response_data = {}
                                new_msisdn = None
                                new_state = None
                                for attempt in range(1, MAX_RETRIES + 1):
                                    try:
                                        if attempt == 1:
                                            time.sleep(180)  # 3 minutes before first retry
                                        else:
                                            time.sleep(120)
                                        url = f"{carrier_api_url}/list"
                                        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Attempting {attempt} for iccid: {iccid} with URL: {url}")
                                        resp = requests.post(url, json=payload, headers=headers, timeout=60)
                                        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Response Code: {resp.status_code} for iccid: {iccid}")
                                        api_success = 200 <= resp.status_code < 300
                                        result = resp.text
                                        if api_success:
                                            response_data = resp.json()
                                    except Exception as e:
                                        result = str(e)
                                        logging.warning(f"### verizon_bc_update_device_status and {tenant_name} Attempt {attempt} failed for iccid: {iccid}: {result}")
                                        time.sleep(RETRY_DELAY)
                                    if api_success:
                                        if not response_data.get("devices"): 
                                            status = "API_FAILED"
                                        else:
                                            new_msisdn = next(
                                                        (d["id"] for d in response_data["devices"][0]["deviceIds"] if d["kind"] == "msisdn"),
                                                        None
                                                    )
                                            new_state = next(
                                                        (c.get("state") for c in response_data["devices"][0].get("carrierInformations", []) if "state" in c),
                                                        None
                                                    )
                                            
                                            if new_state==sim_status:
                                                status = "PROCESSED"
                                                logging.info(f"### verizon_bc_update_device_status and {tenant_name} Updating SIM status to active for iccid: {iccid}")
                                                if update_status.lower() in ("restore","suspend","deactivate"):
                                                    logging.info(f"### verizon_bc_update_device_status and {tenant_name} Updating SIM status for iccid: {update_status}")
                                                    database.update_dict(
                                                        "sim_management_inventory",
                                                        inventory_update,
                                                        and_conditions={"tenant_id": tenant_id, "is_active": True,"service_provider_display_name":service_provider},
                                                        in_conditions={"iccid": [iccid]}
                                                    )
                                                else:
                                                    updated_data["sim_status"] = status_update
                                                    updated_data["ip_address"] = ip_address
                                                    updated_data["imei"] = new_imei
                                                    updated_data["username"]=f"{first_name} {last_name}"
                                                    if new_msisdn:
                                                        updated_data["msisdn"] = new_msisdn
                                                    database.update_dict(
                                                        "sim_management_inventory",updated_data,
                                                        and_conditions={"tenant_id": tenant_id, "is_active": True,"service_provider_display_name":service_provider},
                                                        in_conditions={"iccid": [iccid]}
                                                    )
                                            else:
                                                status = "API_FAILED"
                                                api_success=False
                                        if status == "PROCESSED":
                                            logging.info(f"PROCESSED for iccid: {iccid}, stopping retries")
                                            break   # only stop on success
                                        else:
                                            logging.warning(f"Attempt {attempt}: API call succeeded but status={status}, will retry...") 
                                                
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {"status": status, "has_errors": not api_success, "is_processed": True,"subscriber_number":new_msisdn if new_msisdn else None,
                            "processed_date": now,"status_details":f"sim status {new_state if new_state else 'not activated'} {result}"},
                                and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                            )
                            # Prepare log entry
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                "log_entry_description": "Update Verizon Subscriber: Verizon API",
                                "request_text": json.dumps(payload),
                                "has_errors": not api_success,
                                "response_status": status,
                                "response_text": result if new_msisdn else f"MSISDN not found in response {result}",
                                "error_text": "" if api_success else result,
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")
                        # Handle inventory update without API call
                        else:
                            logging.info(f"### verizon_bc_update_device_status and {tenant_name}  inventory update for iccid: {iccid} as update_status is 'inventory'")
                            update_fields.update({
                                        "iccid": iccid,
                                        "tenant_id": tenant_id,
                                        "is_active": True,
                                        "is_deleted":False,
                                        "tenant_is_active":True,
                                        "tenant_is_deleted":False,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "service_provider_display_name": service_provider,                               
                                        "service_provider_id":service_provider_id,
                                        "service_provider_is_active":True,
                                        "device_status_id":device_status_id,
                                        "sim_status":status_update                                    
                                    })
                            database.insert_data(update_fields, "sim_management_inventory")
                            logging.info(f"### verizon_bc_update_device_status and {tenant_name} Inventory updated for iccid: {iccid} with data: {update_fields}")
                            database.update_dict(
                                        "sim_management_bulk_change_request",
                                        {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"Inventory updated successfully"},
                                        and_conditions={"bulk_change_id": bulk_change_id},
                                        in_conditions={"iccid": [iccid]},
                                    )
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                "log_entry_description": "Update Verizon Subscriber: Inventory Update",
                                "request_text": "Update AMOP",
                                "has_errors": False,
                                "response_status": "PROCESSED",
                                "response_text": "Inventory updated successfully",
                                "error_text": "",
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")
                        return iccid

                    futures[executor.submit(task)] = iccid                    

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### verizon_bc_update_device_status and {tenant_name} Error processing MSISDN: {e}")

        if INTERVAL and i + BATCH_SIZE < len(iccids):
            time.sleep(INTERVAL)
        # Handle and log invalid MSISDNs
        if update_status.lower() != "inventory":
            if invalid_iccids:
                for iccid in invalid_iccids:
                    request_id = iccid_to_request_id.get(iccid)
                    logs.append({
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": request_id,
                        "log_entry_description": "Update Verizon Subscriber: Invalid MSISDN",
                        "request_text": "N/A",
                        "has_errors": True,
                        "response_status": "ERROR",
                        "response_text": "Invalid SIM - could not be processed",
                        "error_text": "Invalid ICCID",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                    })

            if logs:
                database.insert_data(logs,"sim_management_bulk_change_log")

            # Mark invalid request IDs as processed
            if invalid_iccids:
                database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR", "is_processed": True, "has_errors": True,
                        "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                    and_conditions={"bulk_change_id": bulk_change_id},
                    in_conditions={"iccid": invalid_iccids}
                )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )
        # preparing the payload for history table update
        if succesfull_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": succesfull_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the history table update API  
            try:
                logging.info(f"### verizon_bc_archive_devices and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_archive_devices and {tenant_name} Exception in thread: {e}")  
        
        #  sync API trigger 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Below sync url and payload used to sync the inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            logging.info(f"### verizon_bc_update_device_status and {tenant_name} sync call has started")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f"### verizon_bc_update_device_status and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### verizon_bc_update_device_status and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        # Prepare response
        response={
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "msisdns": iccids,
            "invalid_msisdns": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # audit the final bulk change log
        ##auditing the auditing log
        
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_update_device_status",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk change",
                "comments": f"Successfully processed bulk change request for updating device status for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### verizon_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### verizon_bc_update_device_status and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "verizon_bc_update_device_status",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for: {iccids}",
                "module_name": "Bulk change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Exception in logging error data to DB: {log_e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": iccids,
            "invalid_msisdns": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response

## Change Carrier Rate Plan function
def verizon_bc_change_carrier_rate_plan(data):
    """Change the carrier rate plan for the given devices.
    This function processes a list of iccids and updates their carrier rate plan in the Verizon system.
    It handles bulk requests, updates the database, and logs the results.   
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDS to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Verizon API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Recevied data for change carrier rate plan :{data}")
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    changed_data = data.get("changed_data")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Initialize for log entries
    log_entries = []
    succesful_iccids=[]
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_change_carrier_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###verizon_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
                return response
            live_progress_percentage_tracker(database, bulk_change_id,20)
                
        # Map iccids to request IDs
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        carrier_rate_plan_update=change_request_json.get("CarrierRatePlanUpdate","")
        carrie_rate_plan=carrier_rate_plan_update.get("CarrierRatePlan","")
        effective_date=carrier_rate_plan_update.get("EffectiveDate","")

        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        ## Prepare headers for API call
        rate_plan_id=None
        rate_plan_code=None
        # Validate input data for rateplan and optimization
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Validating input data for rate plan and optimization group")
        if carrie_rate_plan:
           rate_plan_data = database.get_data(
            "carrier_rate_plan",
            {"rate_plan_code": carrie_rate_plan, "is_active": True},
            ["id","rate_plan_code"]
            )
        if not rate_plan_data.empty:
            rate_plan_id = rate_plan_data["id"].to_list()[0]
            rate_plan_code=rate_plan_data["rate_plan_code"].to_list()[0]
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Rate plan ID: {rate_plan_id} Rate Plan Code: {rate_plan_code}")
        # Prepare an update dict 
        if carrie_rate_plan:
           update_fields = {"carrier_rate_plan_id": rate_plan_id,"carrier_rate_plan_name": carrie_rate_plan}       
        if effective_date:
           update_fields["effective_date"] = effective_date
        # Validate iccids
        remaining = iccids.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###verizon_bc_change_carrier_rate_plan and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        remaining = list(iccids) 
        # Get access token and session ID
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Fetching access token and session ID")
        access_id,session_id=get_verizon_token_details(app_id,app_secret)
        if not access_id or not session_id:
            logging.error(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Failed to fetch access token or session ID")
            return {"flag": False, "message": "Failed to fetch access token or session ID"}
        #constracting header 
        headers = {
            "Authorization": f"Bearer {access_id}",
            "VZ-M2M-Token": session_id,
            "Content-Type": "application/json",
        }
        live_progress_percentage_tracker(database, bulk_change_id,40)
        # Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each iccid in the batch
                logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} iccids")
                for iccid in batch:
                    # Prepare the URL and payload for the API call
                    url = f"{carrier_api_url}"
                    payload = {
                        "devices": [
                            {
                                "deviceIds": [
                                    {"kind": "iccid", "id": iccid},
                                ]
                            }
                        ],
                    "servicePlan" :carrie_rate_plan
                    }
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    def task(iccid=iccid, url=url, payload=payload):  
                        success = False
                        result = ""
                        status = "API_FAILED"
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Attempting {attempt} for iccid: {iccid} with URL: {url}")
                                resp = requests.put(
                                    url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Response Code: {resp.status_code} for iccid: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "INPROGRESS" if success else "API_FAILED"
                                if success:
                                    succesful_iccids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Attempt {attempt} failed for iccids: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)
                        if success:
                            update_data = {
                                "status": status,
                                "has_errors": False,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details":result   
                            }
                        else:
                            update_data = {
                                "status": status,
                                "has_errors": True,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details":result
                            }
                        #update the request status
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id},
                            )
                        # Only update inventory if API succeeded
                        if success:
                            database.update_dict(
                                "sim_management_inventory",update_fields,
                                and_conditions={"tenant_id":tenant_id,"is_active": True},
                                in_conditions={"iccid": [iccid]}
                                )
                        # Constructing the log entry
                        log = {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                        "log_entry_description": "Update Verizon Subscriber: Verizon API",
                        "request_text": json.dumps(payload),
                        "has_errors": status == "API_FAILED",
                        "response_status": "PROCESSED" if success else "API_Failed",
                        "response_text": result,
                        "error_text": "" if status == "PROCESSED" else result,
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                        }
            
                        if log:
                            database.insert_data(log,"sim_management_bulk_change_log") 
                        if success:
                            payload={
                                    "deviceId": {
                                    "id": iccid,
                                    "kind": "iccid"
                                }
                                } 
                            # second API call to fetch device details
                            api_success = False
                            response_data = {}
                            rate_plan_status = False
                            service_plan=None
                            new_msisdn=None
                            status="API_FAILED"
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    if attempt == 1:
                                        time.sleep(180)  # 3 minutes before first retry
                                    else:
                                        time.sleep(120)  # 2 minutes for subsequent retries
                                    url = f"{alternative_api_url}/list"
                                    logging.info(f"### verizon_bc_update_device_status and {tenant_name} Attempting {attempt} for iccid: {iccid} with URL: {url}")
                                    resp = requests.post(url, json=payload, headers=headers, timeout=60)
                                    logging.info(f"### verizon_bc_update_device_status and {tenant_name} Response Code: {resp.status_code} for iccid: {iccid}")
                                    api_success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    if api_success:
                                        response_data = resp.json()

                                except Exception as e:
                                    result = str(e)
                                    logging.warning(f"### verizon_bc_update_device_status and {tenant_name} Attempt {attempt} failed for iccid: {iccid}: {result}")
                                    time.sleep(RETRY_DELAY)
                                if api_success:
                                    if not response_data.get("devices"): 
                                        status = "API_FAILED"
                                    else:
                                        service_plan = next(
                                                    (c.get("servicePlan") for c in response_data["devices"][0].get("carrierInformations", []) if "servicePlan" in c),
                                                    None
                                                )
                                        new_msisdn = next(
                                                    (d["id"] for d in response_data["devices"][0]["deviceIds"] if d["kind"] == "msisdn"),
                                                    None
                                                        )
                                        if service_plan==carrie_rate_plan:
                                            rate_plan_status = True
                                            status="PROCESSED"
                                        else:
                                            status="API_FAILED" 
                                    if status == "PROCESSED":
                                        logging.info(f"PROCESSED for iccid: {iccid}, stopping retries")
                                        break   # only stop on success
                                    else:
                                        logging.warning(f"Attempt {attempt}: API call succeeded but status={status}, will retry...")
                                                                
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {"status": status, "has_errors": not api_success, "is_processed": True,"subscriber_number":new_msisdn if new_msisdn else None,
                            "processed_date": now,"status_details":f"sim status {result if rate_plan_status else 'service plan not updated from carrier'} {result}"},
                                and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                            )
                            # Prepare log entry
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                "log_entry_description": "Update Verizon Subscriber: Verizon API",
                                "request_text": json.dumps(payload),
                                "has_errors": not api_success,
                                "response_status": status,
                                "response_text": result if rate_plan_status else f"service plan not updated from carrier {result}",
                                "error_text": "" if api_success else result,
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")

                                            
                        return iccid
                    
                    # Submit the task to the executor
                    logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Submitting task for ICCID: {iccid}")
                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Error processing ICCIDS: {e}")

              
        if interval and i + batch_size < len(iccids):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # preparing the payload for history table update
        if succesful_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": succesful_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            # Call the history table update API  
            try:
                logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")  
            
        # Update the bulk change request status   
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Processed {len(iccids) - len(remaining)} iccids, {len(remaining)} remaining")
        ## Handle invalid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_iccids:
            logging.info(f"### Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"verizon_bc_change_carrier_rate_plan and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API URL and payload are used to sync inventory tables 
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info('### verizon_bc_change_carrier_rate_plan and {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info('### verizon_bc_change_carrier_rate_plan and {tenant_name} sync call has ended') 
        except Exception as e:
            logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        ##auditing the sync completion
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_change_carrier_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "verizon_bc_change_carrier_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response



def verizon_bc_change_iccid_imei(data):
    """
     Update ICCID or IMEI for multiple subscribers using Verizon API.

    This function performs the following steps:
        - Validates required input values.
        - Establishes DB connections.
        - Fetches API credentials and carrier limits.
        - Builds and sends PATCH requests per MSISDN in parallel with retry logic.
        - Updates status in DB and logs results.
        - Handles invalid MSISDNs and triggers sync API.

    Args:
        data (dict): Input dictionary containing:
            - new_iccid (str): New ICCID to assign (if applicable).
            - new_imei (str): New IMEI to assign (if applicable).
            - bulk_change_id (str): Unique ID of the bulk change job.
            - service_provider (str): Carrier/service provider name.
            - change_type (str): Type of operation.
            - created_by (str): User initiating the request.
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant.
            - db_name (str): Database name for the tenant.
            - username (str): Username for error/audit tracking.
            - changed_data (dict): Contains serviceCharacteristic array.
            - invalid_msisdns (list): Optional invalid MSISDNs before processing.
            - request_received_at (str): Optional timestamp.

    Returns:
        dict: Result object with success flag, count, and error info
    """
    logging.info(f"Received data for ICCID/IMEI change: {data}")
    start_time = time.time()
    
    # Extract input data
    msisdns = list(data.get("msisdns", []))
    bulk_change_id = data.get("bulk_change_id")
    tenant_id = data.get("tenant_id", "")
    invalid_ids = data.get("invalid_ids", "")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name")
    db_name = data.get("db_name", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    request_received_at = data.get("request_received_at")
    tenant_database = db_name
    access_token = data.get("access_token", "")
    role_name = data.get("role", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logs = []
    successful_msisdns=[]
    processed = 0

    # DB Connections
    try:
        database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### verizon_bc_change_iccid_imei and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
       

    # Audit log - start processing
    try:
        bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id, 20)
    except Exception as e:
        logging.error(f"### verizon_bc_change_iccid_imei and {tenant_name} Audit logging failed while inserting logs: {e}")

    try:
        # Get carrier config
        carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
            service_provider, change_type, common_utils_database
        )
        
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        ##fetching carrier url  
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}

        # Fetch request rows
        request_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number","change_request"]
        )
        logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Fetched {len(request_df)} records from bulk change request table")
        
        updated_data = {}
        
        # Validate input data
        if not request_df.empty:
            change_request_json = request_df.iloc[0]["change_request"]
            if not change_request_json:
                message = "Bulk Change Request data is empty"
                response = {"flag": False, "message": message}
                error_update_data = {"errors": len(msisdns), "status": "ERROR"}
                database.update_dict(
                    "sim_management_bulk_change",
                    error_update_data,
                    and_conditions={"bulk_change_id": bulk_change_id},
                )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_change_iccid_imei",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###verizon_bc_change_iccid_imei and {tenant_name} Audit logging failed: {e}")
                return response
                
            if isinstance(change_request_json, str):
                change_request_json = json.loads(change_request_json)
            # Handle Verizon-specific fields
            service_chars = change_request_json.get("Request", {})
            if service_chars:
                ##fetching the customer rate plan and customer rate pool details
                customer_rate_plan_id = service_chars.get("CustomerRatePlan", "")
                customer_rate_pool_id = service_chars.get("CustomerRatePool", "")
                
                if customer_rate_plan_id:
                    rate_plan_data = database.get_data(
                        "customerrateplan",
                        {"id": customer_rate_plan_id, "is_active": True},
                        ["rate_plan_name"]
                    )
                    if not rate_plan_data.empty:
                        customer_rate_plan_name = rate_plan_data["rate_plan_name"].to_list()[0]
                        updated_data['customer_rate_plan_name'] = customer_rate_plan_name
                        updated_data['customer_rate_plan_id'] = customer_rate_plan_id
                        
                if customer_rate_pool_id:
                    rate_plan_data = database.get_data(
                        "customer_rate_pool",
                        {"id": customer_rate_pool_id, "is_active": True},
                        ["name"]
                    )
                    if not rate_plan_data.empty:
                        customer_rate_pool_name = rate_plan_data["name"].to_list()[0]
                        updated_data['customer_rate_pool_name'] = customer_rate_pool_name
                        updated_data['customer_rate_pool_id'] = customer_rate_pool_id

        # Create mappings
        request_df = request_df.rename(columns={"subscriber_number": "msisdn"})
        id_map = dict(zip(request_df["msisdn"], request_df["id"]))
        msisdns_to_change_request = dict(zip(request_df["msisdn"], request_df["change_request"]))
        logging.info(f"Mapped {len(msisdns_to_change_request)} ICCIDs to change requests")

        # Carrier limits defaults
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        BATCH_SIZE = carrier_limits.get("batch_size", 50)
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests", 10)
        if PARALLEL_REQUESTS>10:
            logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        remaining = list(msisdns)

        # Get Verizon access token and session ID
        logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Fetching access token and session ID")
        access_id, session_id = get_verizon_token_details(app_id, app_secret)
        if not access_id or not session_id:
            logging.error(f"### verizon_bc_change_iccid_imei and {tenant_name} Failed to fetch access token or session ID")
            return {"flag": False, "message": "Failed to fetch access token or session ID"}
        #constracting header
        headers = {
            "Authorization": f"Bearer {access_id}",
            "VZ-M2M-Token": session_id,
            "Content-Type": "application/json",
        }

        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id, 40)
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(msisdns), BATCH_SIZE):
                batch = msisdns[i:i + BATCH_SIZE]
                logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Processing batch {i // BATCH_SIZE + 1} with {len(batch)} MSISDNs")
                futures = {}

                for msisdn in batch:
                    payload_str = msisdns_to_change_request.get(msisdn)

                    if not payload_str:
                        logging.warning(f"### verizon_bc_change_iccid_imei and {tenant_name} Skipping MSISDN {msisdn}: missing change_request payload")
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": id_map.get(msisdn),
                            "log_entry_description": f"Missing change_request payload for {msisdn}",
                            "request_text": "N/A",
                            "has_errors": True,
                            "response_status": "ERROR",
                            "response_text": "Missing payload",
                            "error_text": "No change_request found",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        logs.append(log)
                        continue

                    request_payload = json.loads(payload_str)
                    payload = request_payload.get("Request")
                    # Extract Verizon-specific fields
                    new_id = payload.get("NewIMEI", "")
                    old_id = payload.get("OldIMEI", "")
                    iccid_old = payload.get("OldICCID")

                    # Construct Verizon payload
                    verizon_payload = None
                    change_description = ""
                    if old_id and new_id:
                        kind = "imei"
                        change_option = "changeIMEI"
                    else:
                        kind = "iccid"
                        change_option = "changeICCID"
                        old_id = payload.get("OldICCID")
                        new_id = payload.get("NewICCID")
                        iccid_old = payload.get("OldICCID")

                    verizon_payload = {
                        "deviceIds": [{"kind": kind, "id": old_id}],
                        "deviceIdsTo": [{"kind": kind, "id": new_id}],
                        "change4gOption": change_option
                    }
                    updated_data[kind]=new_id
                    logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Processing MSISDN: {msisdn} with payload: {verizon_payload}")
                    url = carrier_api_url
                    bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")

                    def task(msisdn=msisdn, url=url, payload=verizon_payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        request_id = id_map.get(msisdn)

                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Attempt {attempt} - URL: {url}")
                                resp = requests.put(url, json=payload, headers=headers, timeout=30)
                                logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                
                                if 200 <= resp.status_code < 300:
                                    success = True
                                    #status = "PROCESSED"
                                    status = "INPROGRESS"
                                    result = resp.text
                                    break
                                else:
                                    result = resp.text
                                    time.sleep(RETRY_DELAY)
                            except Exception as e:
                                result = str(e)
                                logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Attempt {attempt} failed for {msisdn}: {e}")
                                time.sleep(RETRY_DELAY)

                        # DB update
                        database.update_dict(
                                        "sim_management_bulk_change_request",
                                        {"status": status,"is_processed":True,"has_errors":False,"processed_date": now,"status_details":result},
                                        and_conditions={"bulk_change_id": bulk_change_id},
                                        in_conditions={"subscriber_number": [msisdn]},
                                    )


                        # Update inventory if successful
                        if success:
                            logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} updated_data: {updated_data} for MSISDN: {msisdn} before updating inventory")
                            database.update_dict(
                                "sim_management_inventory",
                                  updated_data,
                                {"is_active": True, "msisdn": msisdn ,"tenant_id": tenant_id}
                            )

                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": request_id,
                            "log_entry_description": f"Change {change_description} via Verizon API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                        if success:
                            payload={
                                    "deviceId": {
                                    "id": iccid_old,
                                    "kind": "iccid"
                                }
                                } 
                            # second API call to fetch device details
                            api_success = False
                            response_data = {}
                            rate_plan_status = False
                            imei=None
                            new_msisdn=None
                            condition=None
                            status="API_FAILED"
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    if attempt == 1:
                                        time.sleep(180)  # 3 minutes before first retry
                                    else:
                                        time.sleep(120)
                                    url = f"{alternative_api_url}/list"
                                    logging.info(f"### verizon_bc_update_device_status and {tenant_name} Attempting {attempt} for msisdn: {msisdn} with URL: {url}")
                                    resp = requests.post(url, json=payload, headers=headers, timeout=60)
                                    logging.info(f"### verizon_bc_update_device_status and {tenant_name} Response Code: {resp.status_code} for msisdn: {msisdn}")
                                    api_success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    if api_success:
                                        response_data = resp.json()
                                except Exception as e:
                                    result = str(e)
                                    logging.warning(f"### verizon_bc_update_device_status and {tenant_name} Attempt {attempt} failed for msisdn: {msisdn}: {result}")
                                    time.sleep(RETRY_DELAY)
                                if api_success:
                                    if not response_data.get("devices"): 
                                        status = "API_FAILED"
                                    else:
                                        imei = next(
                                                    (d["id"] for d in response_data["devices"][0]["deviceIds"] if d["kind"] == "imei"),
                                                    None
                                                        )
                                        iccid_id = next(
                                                    (d["id"] for d in response_data["devices"][0]["deviceIds"] if d["kind"] == "iccid"),
                                                    None
                                                        )
                                        new_msisdn = next(
                                                    (d["id"] for d in response_data["devices"][0]["deviceIds"] if d["kind"] == "msisdn"),
                                                    None
                                                        )
                                        condition = iccid_id if change_option == "changeICCID" else imei
                                        if condition==new_id:
                                            rate_plan_status = True
                                            status="PROCESSED"
                                            successful_msisdns.append(msisdn)

                                        else:
                                            status="API_FAILED" 
                                    if status == "PROCESSED":
                                        logging.info(f"PROCESSED for iccid: {iccid_old}, stopping retries")
                                        break   # only stop on success
                                    else:
                                        logging.warning(f"Attempt {attempt}: API call succeeded but status={status}, will retry...") 
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {"status": status, "has_errors": not api_success, "is_processed": True,"subscriber_number":new_msisdn if new_msisdn else None,
                            "processed_date": now,"status_details":f"sim status {result if rate_plan_status else 'imei not updated from carrier'} {result}"},
                                and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id}
                            )
                            # Prepare log entry
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": request_id,
                                "log_entry_description": "Update Verizon Subscriber: Verizon API",
                                "request_text": json.dumps(payload),
                                "has_errors": not api_success,
                                "response_status": status,
                                "response_text": result if rate_plan_status else f"imei not updated from carrier {result}",
                                "error_text": "" if api_success else result,
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")
                            
                        return msisdn

                    futures[executor.submit(task)] = msisdns

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                        processed += 1
                    except Exception as e:
                        logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Error processing msisdn in thread: {e}")
        if INTERVAL and i + BATCH_SIZE < len(msisdns):
            time.sleep(INTERVAL)
        # preparing the payload for history table update
        if successful_msisdns:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": [],
                                        "msisdns":successful_msisdns,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the history table update API  
            try:
                logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Exception in thread: {e}")  
        

        # Handle invalid MSISDNs
        if invalid_msisdns:
           for msisdn in invalid_msisdns:
                request_id = msisdns_to_change_request.get(msisdn)
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Invalid MSISDN during ICCID/IMEI change",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid msisdn - could not be processed",
                    "error_text": "Invalid identifier",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if invalid_msisdns:
            database.update_dict(
                "sim_management_bulk_change_request",
                {
                    "status": "ERROR",
                    "errors": len(invalid_msisdns),
                    "is_processed": True,
                    "has_errors": True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"
                },
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"subscriber_number": invalid_msisdns},
            )

        if logs:
            database.insert_data(logs, "sim_management_bulk_change_log")

        # Update bulk change summary
        database.update_dict(
            "sim_management_bulk_change",
            {
                "status": "PROCESSED",
                "success": processed,
                "processed_date": now
            },
            {"id": bulk_change_id}
        )

        # Trigger sync APIs to 1.0 for bulk change  tables
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
            "data": {
                "access_token": access_token,
                "data": {"bulk_change_id": bulk_change_id},
                "db_name": tenant_database,
                "is_update": True,
                "module_name": "Bulk Change",
                "Partner": tenant_name,
                "path": "/update_bulk_change_tables_10",
                "request_received_at": now,
                "role_name": role_name,
                "tenant_name": tenant_name,
                "username": username
            }
        }
        # calling sync API to update inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
            "data": {
                "access_token": access_token,
                "key_name": "verizon_bulkchange_sync",
                "path": "/bulk_change_sync_10_updated",
                "tenant_name": tenant_name,
                "bulk_change_id": bulk_change_id
            }
        }

        try:
            live_progress_percentage_tracker(database, bulk_change_id, 80) 
            logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} sync call has started")
            bulk_change_audit_action(data, common_utils_database, action="Sync To 1.0 Tables")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
        except Exception as e:
           logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Exception in thread: {e}")

        # Final audit logging
        live_progress_percentage_tracker(database, bulk_change_id, 95)
        
        logging.info(f"###verizon_bc_change_iccid_imei bulk change completed in {time.time() - start_time:.2f} seconds | Processed: {processed}")
        
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "iccids": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }

        try:
            end_time = time.time()
            time_consumed = end_time - start_time 
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_change_iccid_imei",
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change for {len(msisdns)} devices with bulk_change_id: {bulk_change_id}",
                "request_received_at": now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database, action="Auditing")

        except Exception as e:
            logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Completed")
        live_progress_percentage_tracker(database, bulk_change_id, 100)
        
        logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Processed {len(msisdns)} ICCIDs, {len(remaining)} remaining")
        return response

    except Exception as e:
        logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Error during bulk change processing: {str(e)}")
        error_type = str(type(e).__name__)
        error_message = f"Error during bulk change processing: {str(e)}"
        
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        
        error_update_data = {"errors": len(msisdns), "status": "ERROR"}
        database.update_dict(
            "sim_management_bulk_change",
            error_update_data,
            and_conditions={"bulk_change_id": bulk_change_id},
        )
        
        try:
            error_data = {
                "service_name": "verizon_bulk_change_iccid_imei",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk ICCID/IMEI change with bulk_change_id: {bulk_change_id}",
                "module_name": "Bulk Change",
                "request_received_at": request_received_at or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
           logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Exception in logging error data to DB: {log_e}")
            
        return response  

 
    

## Assign customer function
def verizon_bc_assign_customer(data):
    """Assign a customer to the selected devices or services.
    This function processes a list of iccids and assign a customer account with the iccids in the Verizon system.
    It handles bulk requests, updates the database, and logs the results.
    Args:
        data (dict): Input data containing the following keys:
            - ICCIDs (list): List of ICCIDs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Verizon API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
        context (dict): Lambda context object containing execution details.
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    
    """
    logging.info(f"### Received data for assign customer: %s", data)
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Initialize for log entries
    log_entries = []
    successfull_iccids=[]
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###verizon_bc_assign_customer and {tenant_name} time is {now}")

    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### verizon_bc_assign_customer and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,20)
    except Exception as e:
        logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
            logging.info(f"### verizon_bc_assign_customer and {tenant_name} Carrier API details fetched successfully")

        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}


        # Fetch bulk change rows
       
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},#iccid
            ["id", "iccid", "change_request"]
        )
        # Validate input data 
       
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_assign_customer",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###verizon_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
                return response
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        #Extract relevant fields from the change request 
        customer_rate_plan_id=change_request_json.get("CustomerRatePlan","")
        customer_rate_pool_id=change_request_json.get("CustomerRatePool","")
        rev_customer_id=change_request_json.get("RevCustomerId","")
        service_type_id=change_request_json.get("ServiceTypeId","")
        effective_date=change_request_json.get("EffectiveDate","")
        activated_date=change_request_json.get("ActivatedDate","")
        usageplangroupid=change_request_json.get("UsagePlanGroupId","")
        revproductidlist=change_request_json.get("RevProductIdList",[0])
        product_id = revproductidlist[0] if revproductidlist else None
        provider_id=change_request_json.get("ProviderId","")
        number=change_request_json.get("Number","")
        integration_authentication_id=change_request_json.get("IntegrationAuthenticationId","")
        device_id=change_request_json.get("DeviceId")
        description=change_request_json.get("Description","")
        rate= change_request_json.get("RateList", [0])
        revpackageid=change_request_json.get("RevPackageId", None)
        # Initialize variables for customer and rate plan details
        rate_plan_id = None
        customer_rate_plan = None
        customer_rate_pool = None
        rev_customer = None
        provider_data=pd.DataFrame()
        rev_customer_uuid = None
        customer_id=None
        customer_name=None
       # Fetch customer and rate plan details from the database
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name"]
            )
            if not rate_plan_data.empty:
                rate_plan_id = rate_plan_data["rate_plan_code"].to_list()[0]
                customer_rate_plan=rate_plan_data["rate_plan_name"].to_list()[0]
        if customer_rate_pool_id:
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool = rate_pool_data["name"].to_list()[0]
        if rev_customer_id:
            rev_data = database.get_data(
                "revcustomer",
                {"rev_customer_id": rev_customer_id, "is_active": True},
                ["customer_name", "id"]
            )
            if not rev_data.empty:
                rev_customer = rev_data["customer_name"].to_list()[0]
                rev_customer_uuid = rev_data["id"].to_list()[0]
        # Initialize as empty DataFrame       
        customer_data = pd.DataFrame()  
        if rev_customer:
               customer_data = database.get_data(
        "customers", 
        {"customer_name": rev_customer, "is_active": True},
        ["id", "customer_name"]
    )

        if not customer_data.empty:
                customer_id = customer_data["id"].to_list()[0]
                customer_name = customer_data["customer_name"].to_list()[0]
        else:
            customer_id = None
            customer_name = None
        if provider_id:
            provider_data = database.get_data(
                "rev_provider",
                {"provider_id": provider_id, "is_active": True,"integration_authentication_id": integration_authentication_id},
                ["id"]
            )
            if not provider_data.empty:
                rev_provider_id = provider_data["id"].to_list()[0] 
       # Prepare update fields for the database
        update_fields = {"customer_rate_plan_id": customer_rate_plan_id,"customer_rate_plan_name": customer_rate_plan}
        if customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id
            update_fields["customer_rate_pool_name"] = customer_rate_pool
        if rev_customer_id:
            update_fields["rev_customer_id"] = rev_customer_id
            update_fields["rev_customer_name"] = rev_customer
        if effective_date:
            update_fields["effective_date"] = effective_date
        if integration_authentication_id:
            update_fields["account_number_integration_authentication_id"] = integration_authentication_id
        if device_id:
            update_fields["device_id"] = device_id
        update_fields["customer_id"] = customer_id if customer_id is not None else None
        update_fields["customer_name"] = customer_name if customer_name is not None else None
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        iccid_to_request_id = dict(zip(bulk_requests.iccid, bulk_requests.id))
        iccid_to_changerequest = dict(zip(bulk_requests.iccid, bulk_requests.change_request))
        ## Prepare headers for API call
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
        }
        # Prepare data for database insertion
        product_data={}
        if revpackageid:
            product_data["package_id"] = revpackageid
        if rate:
           product_data["rate"] = Decimal(str(rate[0]))
        if product_id:
            product_data["product_id"] = product_id
        # Validate iccids
        remaining = iccids.copy()
        logs = []
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"###verizon_bc_assign_customer and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###verizon_bc_assign_customer and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        remaining = list(iccids)
        ## Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process each batch of ICCIDs
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # craete a dictionary to hold futures
                futures = {}
                logging.info(f"###verizon_bc_assign_customer and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")
                for iccid in batch:
                    url = f"{carrier_api_url}"
                    logging.info(f"###verizon_bc_assign_customer and {tenant_name} Processing ICCID: {iccid}")
                    payload_str = iccid_to_changerequest.get(iccid)
                    logging.info(f"###verizon_bc_assign_customer and {tenant_name} Payload for ICCID {iccid}: {payload_str}")
                    request_payload = json.loads(payload_str)
                    #extract the create rev service flag
                    rev_service = request_payload.get("CreateRevService", False)
                    # Build payloads for all APIs
                    rev_api_payload = {
                        "customer_id": rev_customer_id,
                        "provider_id": provider_id,
                        "service_type_id": service_type_id,
                        "number": number,
                        "activated_date": activated_date,
                    }
                    product_api_payload={
                        "CustomerId": rev_customer_id,
                        "service_type_id": service_type_id,
                        "number": number,
                        "effective_date": effective_date,
                        "activated_date": activated_date,
                        "product_id": product_id,
                        }
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    #task function
                    def task(iccid=iccid, rev_service=rev_service):
                        """ 1. If CreateRevService is True:
                            - Step 1: Call API to create RevService (POST with retries)
                            - Step 2: On success, extract RevService ID from response
                            - Step 3: Use RevService ID to create Service Product (POST)
                        
                           2. If CreateRevService is False:
                            - Skip RevService creation and directly insert into DB"""
                        success = False
                        result = ""
                        status = "API_FAILED"
                        id = None
                        productid = None
                        try:
                            if rev_service:
                                # Step 1:  First API Call to create the revservice
                                for attempt in range(1, MAX_RETRIES + 1):
                                    try:
                                        logging.info(f"###verizon_bc_assign_customer and {tenant_name} Attempt {attempt} - URL: {url}, Payload: {rev_api_payload}")
                                        
                                        resp = requests.post(url, json=rev_api_payload, headers=headers, timeout=60)
                                        success = 200 <= resp.status_code < 300
                                        result = resp.text
                                        logging.info(f"###verizon_bc_assign_customer and {tenant_name} Response Code: {resp.status_code}")
                                        logging.info(f"###verizon_bc_assign_customer and {tenant_name} Response Text: {result}")
                                        status = "PROCESSED" if success else "API_Failed"
                                        if success:
                                            try:
                                                response_data = resp.json()
                                                id = response_data.get("id")
                                                successfull_iccids.append(iccid)
                                            except Exception:
                                                id = None
                                            break
                                    except Exception as e:
                                        result = str(e)
                                        status = "API_EXCEPTION"
                                        logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Exception in API call: {e}")
                                        time.sleep(RETRY_DELAY) 
                                if success:
                                    update_data = {
                                        "status": status,
                                        "has_errors": False,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result   
                                    }
                                else:
                                    update_data = {
                                        "status": status,
                                        "has_errors": True,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result
                                    }  
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    update_data,
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"iccid": iccids},
                                    )             
                                if success:  
                                    #inserting values in rev service 
                                    rev_data={
                                    "rev_customer_id":rev_customer_uuid,
                                    "number":number,
                                    "rev_service_id":id,
                                    "activated_date":activated_date,
                                    "is_active":True,
                                    "integration_authentication_id":integration_authentication_id,
                                    "rev_provider_id":rev_provider_id,
                                    "rev_service_type_id":service_type_id
                                    }
                                    rev_insert_id=database.insert_data(rev_data,"rev_service")
                                    if rev_insert_id:
                                        update_fields["rev_service_id"]=rev_insert_id

                                    #updating inventory table
                                    rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                # Inserting logs based on api result
                                rev_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Rev.io API",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": status == "PROCESSED",
                                        "response_status": "PROCESSED" if success else "API_Failed",
                                        "response_text": result,
                                        "error_text": "" if status == "PROCESSED" else result,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                database.insert_data(rev_log,"sim_management_bulk_change_log") 
                                logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserting log for rev service creation: {rev_log}")
                                #inserting logs after updating inventory table
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors":False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK" ,
                                        "error_text": "",
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                                # Step 2:  Second API Call
                                logging.info(f"### verizon_bc_assign_customer and {tenant_name} Creating Rev.io Service Product for ICCID: {iccid} with ID: {id}")
                                if id:
                                    second_url = f"{alternative_api_url}"
                                    #constracting payload 
                                    product_api_payload["service_id"]=id
                                    logging.info(f"### verizon_bc_assign_customer and {tenant_name} Product API Payload: {product_api_payload}, URL: {second_url}")

                                    for attempt in range(1, MAX_RETRIES + 1):
                                        try:
                                            get_resp = requests.post(second_url,json=product_api_payload, headers=headers, timeout=60)
                                            api_success = 200 <= get_resp.status_code < 300
                                            api_result = get_resp.text
                                            logging.info(f"### verizon_bc_assign_customer and {tenant_name} Response Code: {get_resp.status_code}")
                                            logging.info(f"### verizon_bc_assign_customer and {tenant_name} Response Text: {api_result}")
                                            status = "PROCESSED" if api_success else "API_FAILED"
                                            if api_success:
                                                response_data = get_resp.json()
                                                productid = response_data.get("id")
                                                break
                                        except Exception as e:
                                            result = str(e)
                                            status = "API_EXCEPTION"
                                            time.sleep(RETRY_DELAY)
                                    if api_success:
                                        product_data.update({
                                               "service_product_id": productid,  
                                                "customer_id":rev_customer_id,  
                                                "service_id": id,  
                                                "description":description,  
                                                "activated_date": activated_date,     
                                                "status": "ACTIVE",  
                                                "created_by": created_by,  
                                                "created_date": now,  
                                                "is_active": True,  
                                                "is_deleted": False,  
                                                "integration_authentication_id": integration_authentication_id,
                                        })
                                        #inserting values into revservice product table 
                                        database.insert_data(product_data,"rev_service_product")
                                        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserting log for rev service product creation: {product_data}")
                                        rev_service_log=database.update_dict(
                                            "sim_management_inventory",update_fields,
                                            and_conditions={"tenant_id":tenant_id,"is_active": True},
                                            in_conditions={"iccid": [iccid]}
                                        )
                                    #constracting logs 
                                    log = {
                                            "bulk_change_id": bulk_change_id,
                                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                            "log_entry_description": "Create Rev.io Service Product: Rev.io API",
                                            "request_text": json.dumps(product_api_payload),
                                            "has_errors": status == "API_FAILED",
                                            "response_status": "PROCESSED" if api_success else "API_Failed",
                                            "response_text": api_result,
                                            "error_text": "" if status == "PROCESSED" else result,
                                            "processed_date": now,
                                            "processed_by": created_by,
                                            "created_by": created_by,
                                            "created_date": now,
                                            "is_deleted": False,
                                            "is_active": True
                                        }
                    
                                    if log:
                                        database.insert_data(log,"sim_management_bulk_change_log")
                                    logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserting log for product creation: {log}") 
                                    if rev_service_log:
                                        data_log = {
                                            "bulk_change_id": bulk_change_id,
                                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                            "log_entry_description": "Create Rev.io Service: Update AMOP",
                                            "request_text": json.dumps(product_api_payload),
                                            "has_errors":False,
                                            "response_status": "PROCESSED",
                                            "response_text": "OK" ,
                                            "error_text": "",
                                            "processed_date": now,
                                            "processed_by": created_by,
                                            "created_by": created_by,
                                            "created_date": now,
                                            "is_deleted": False,
                                            "is_active": True
                                        }
                                        database.insert_data(data_log,"sim_management_bulk_change_log")
                                        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                            else:
                                #if createrevservice flag false then directly updating values into table
                                rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                
                                database.update_dict(
                                        "sim_management_bulk_change_request",
                                        {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK"},
                                        and_conditions={"bulk_change_id": bulk_change_id},
                                        in_conditions={"iccid": iccids},
                                    )

                                #constracting logs
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK",
                                        "error_text": "" ,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")

                        except Exception as e:
                            logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Unexpected error for ICCID {iccid}: {str(e)}")
                        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Completed processing ICCID: {iccid}, Success: {success}, ID: {id}, Product ID: {productid}")
                        return iccid
                    futures[executor.submit(task)] = iccid
                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.error(f"### verizon_bc_assign_customer and {tenant_name} Error processing iccid: {e}")
        if interval and i + batch_size < len(iccids):
            time.sleep(interval)
       
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        #logging.info("Processed %d iccids, %d remaining", len(iccids) - len(remaining), len(remaining))
        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Processed %d iccids, %d remaining", len(iccids) - len(remaining), len(remaining))
        # preparing the payload for history table update
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": successfull_iccids,
                                    "msisdns":[],
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        if effective_date:
            payload_history_table["data"]["effective_date"] = effective_date
        # Call the history table update API  
        try:
            logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} sync call has started for history table")
            threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")  
        
        # Check for any invalid ICCIDs
        if invalid_iccids:
            logging.info(f"### verizon_bc_assign_customer and {tenant_name} Invalid iccids found: {invalid_iccids}")
            # Log invalid IDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Assign customer ",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserted %d log entries for bulk change request", len(log_entries))
        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Bulk Change Completed in %.1fs", time.time() - start_time)
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API call for 1.0 tables to update the inventory
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### verizon_bc_assign_customer and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### verizon_bc_assign_customer and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        live_progress_percentage_tracker(database, bulk_change_id,95)
       
        # Attempt to audit the action
        try:
            audit_data_user_actions = {
                "service_name": "verizon_bc_assign_customer",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for Assign customer for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### verizon_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Error during bulk change processing: {e}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": iccids,
            "invalid_msisdns": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(iccids),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "verizon_bc_assign_customer",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Logging error to DB failed: {e}")
 
        return response
    
    
##Update Line Sync function
def verizon_bc_line_sync(data):
    """
    Sync SIM inventory and bulk change requests with the verizon API.

    This function processes a list of ICCIDs for a given bulk change operation
    and updates their details by calling the carrier's verizon API. It includes
    retry logic, database updates, inventory synchronization, error handling,
    and audit logging.

    Args:
        data (dict): Input dictionary containing the following keys:
            - iccids (list): List of ICCIDs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains request payload and UpdateStatus information.
            - service_provider (str): Name of the carrier/service provider.
            - change_type (str): Type of update (e.g., SIM/device status).
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant (for logs/audit).
            - db_name (str): Tenant-specific database name.
            - service_provider_id (str): Identifier for the service provider.
            - invalid_iccids (list): ICCIDs that failed validation before processing.

    Returns:
        dict: Response object summarizing the processing result:
            - flag (bool): True if operation completed without unhandled errors.
            - message (str): Summary of result (success or failure).
            - processed (int): Number of ICCIDs successfully processed.
            - remaining (int): Number of ICCIDs not processed.
            - iccids (list): List of ICCIDs attempted.
            - invalid_iccids (list): ICCIDs skipped due to invalid input.
            - bulk_change_id (str): Bulk change request ID.
            - error (str, optional): Error message if processing failed.
    """
    logging.info(f"### Received data for updating device status: {data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    service_provider_id = data.get("service_provider_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
   
    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###verizon_bc_line_sync and {tenant_name} time is {now}")
    successfull_ids = []
    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### verizon_bc_line_sync and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### verizon_bc_line_sync and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    
    try:
        # Get carrier API credentials and configuration
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### verizon_bc_line_sync and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### verizon_bc_line_sync and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid"]
        ).rename(columns={"iccid": "iccid"})
        if  bulk_requests_df.empty:
            
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_line_sync",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### verizon_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
                return response

        ##fetching the requests ids
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        
        if PARALLEL_REQUESTS>10:
           logging.info(f"###pondiot_bc_update_device_status and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
        PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        remaining = list(iccids)
        
        access_id,session_id=get_verizon_token_details(app_id,app_secret)
        if not access_id or not session_id:
            logging.error(f"### verizon_bc_line_sync and {tenant_name} Failed to fetch access token or session ID")
            return {"flag": False, "message": "Failed to fetch access token or session ID"}
        #constracting header 
        headers = {
            "Authorization": f"Bearer {access_id}",
            "VZ-M2M-Token": session_id,
            "Content-Type": "application/json",
        }
        
        # Execute API calls in parallel using ThreadPoolExecutor
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}

                for iccid in batch:
                    url = f"{carrier_api_url}"      
                    payload = {
                            "deviceId": {
                                "id": iccid,   # Example ICCID
                                "kind": "iccid"
                            }
                        }
          

                    def task(iccid=iccid, url=url,payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        updated = None
                        inserted = None
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### verizon_bc_line_sync and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                
                                resp = requests.post(url, json=payload,headers=headers, timeout=60)
                                logging.info(f"### verizon_bc_line_sync and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successfull_ids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### verizon_bc_line_sync and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                           "processed_date": now,"status_details":resp.text},
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory if successful
                        if success:
                            api_data = resp.json()

                            # Extract required fields from API response
                            device = api_data.get("devices", [])[0] if api_data.get("devices") else {}

                            billing_cycle_end_date = device.get("billingCycleEndDate")
                            sim_status = None
                            imei = None

                            # Extract sim_status from carrierInformations
                            carrier_info = device.get("carrierInformations", [])
                            if carrier_info:
                                sim_status = carrier_info[0].get("state")

                            # Extract imei & iccid from deviceIds
                            for dev_id in device.get("deviceIds", []):
                                if dev_id.get("kind") == "imei":
                                    imei = dev_id.get("id")
                                elif dev_id.get("kind") == "iccId":
                                    iccid_val = dev_id.get("id")

                            # Prepare update values
                            to_update = {
                                "billing_cycle_end_date": billing_cycle_end_date,
                                "sim_status": sim_status,
                                "imei": imei,
                                "iccid": iccid_val,
                            }

                            # First try update 
                            updated = database.update_dict(
                                "sim_management_inventory",
                                values=to_update,
                                and_conditions={
                                    "iccid": iccid,
                                    "tenant_id": tenant_id,
                                    "service_provider_id": service_provider_id,
                                    "is_active": True,
                                },
                            )

                            # If no update happened → insert
                            if not updated:
                                to_insert = {
                                    "billing_cycle_end_date": billing_cycle_end_date,
                                    "sim_status": sim_status,
                                    "imei": imei,
                                    "iccid": iccid_val,
                                    "tenant_id": tenant_id,
                                    "service_provider_id": service_provider_id,
                                    "is_active": True,
                                    "created_date": now,
                                }
                                inserted = database.insert_dict(to_insert, "sim_management_inventory")

                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update verizon Subscriber: verizon API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            
                        # Prepare log entry
                        # Determine inventory update success
                        inventory_success = inserted or updated  # True if either insert or update happened

                        # Prepare inventory log entry
                        inventory_log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update AMOP",
                            "request_text": None,
                            "has_errors": not inventory_success,
                            "response_status": "PROCESSED" if inventory_success else "ERROR",
                            "response_text": "inventory updated successfully" if inventory_success else "inventory update failed",
                            "error_text": "" if inventory_success else "Inventory update failed",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }

                        if inventory_log:
                            database.insert_data(inventory_log, "sim_management_bulk_change_log")   
                            
                         
                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### verizon_bc_line_sync and {tenant_name} Error processing ICCID: {e}")

            if INTERVAL and i + BATCH_SIZE < len(iccids):
                time.sleep(INTERVAL)
        # Handle and log invalid ICCIDs
        #prepare the payload for history table
        if successfull_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": successfull_ids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### verizon_bc_line_sync and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_line_sync and {tenant_name} Exception in thread: {e}")
        # Handle and log invalid ICCIDs
        if invalid_iccids:
            for iccid in invalid_iccids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": "Update verizon Subscriber: Invalid ICCID",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")

        # Mark invalid request IDs as processed
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        #  sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api to update the inventry tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### verizon_bc_line_sync and {tenant_name} sync call has started")
            
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### verizon_bc_line_sync and {tenant_name} sync call has ended")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### verizon_bc_line_sync and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### verizon_bc_line_sync and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### verizon_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        # Prepare response
        response={
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
       
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_line_sync",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for update device status for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
             ##auditing the auditing log
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### verizon_bc_line_sync and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### verizon_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### verizon_bc_line_sync and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR","status_details":"Processing Invalid Sim"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "verizon_bc_line_sync",
                "created_date": data.get("request_received_at") or now,
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for: {iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### verizon_bc_line_sync and {tenant_name} Exception in logging error data to DB: {log_e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response
        

##SYNC API call function
def call_sync_api(api_url, api_payload):
    '''
    Call the sync API with the provided URL and payload.
    This function is designed to be run in a separate thread after a delay.
    '''
    try:
        # Make the API call
        logging.info(f"### Calling sync API: {api_url} with payload: {api_payload}")
        response = requests.post(api_url, json=api_payload)
        if response.status_code == 200:
            logging.info("Bulk Change API call successful. Data sync call successfully done.")
        else:
            logging.error(f"API call failed with status code: {response.status_code}")
    except Exception as e:
        logging.error(f"Error making API call: {e}")

## Function to audit user actions in bulk change processing
def bulk_change_audit_action(data, common_utils_database,action):
    """
    Audits user actions by logging them into the bulk change auditing table.
 
    Args:
        data (dict): Data containing user action details.
        common_utils_database (DB): Database connection object.
 
    Returns:
        None
    """
    service_provider = data.get("service_provider", "")
    change_event_type = data.get("change_type", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
   
    request_received_at = data.get("request_received_at", "") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bulk_change_id = data.get("bulk_change_id", "")
    try:
        audit_data_user_actions = {
                "tenant_name": tenant_name,
                "bulk_change_id":bulk_change_id,
                "serviceprovider": service_provider,
                "change_event_type": change_event_type,
                "action": action,
                "created_date": request_received_at,
                "created_by": username,
               
        }
        common_utils_database.update_audit(audit_data_user_actions, "bulk_change_auditing")
        logging.info("User action audited successfully.")
    except Exception as e:
        logging.exception(f"### Error logging user actions: {e}")


def live_progress_percentage_tracker(database, bulk_change_id,progress_percent):
    """
    Updates the live_progress_percentage column in sim_management_bulk_change_request table.
    """
    try:
        update_fields={}
        #updating sync status when progress percentage reached 100
        if progress_percent==100:
            update_fields["live_progress_percentage"]=progress_percent
            update_fields["progress"]="Sync Completed"
        else:
            update_fields["live_progress_percentage"]=progress_percent

        database.update_dict(
            "sim_management_bulk_change",
            update_fields,
            and_conditions={"id": bulk_change_id}
        )
        return True
    except Exception as e:
        logging.error(f"Error updating live progress: {e}")
        return False

def get_verizon_token_details(app_id,app_secret):
    """
    Obtain an OAuth access token and session token from Verizon  API.

    Args:
        app_id (str): The client ID (application ID) for Verizon API.
        app_secret (str): The client secret associated with the app_id.

    Returns:
        tuple[str, str]: A tuple containing the access token and the session token.

    Raises:
        requests.exceptions.HTTPError: If any of the HTTP requests fail.
        Exception: For unexpected decoding or response format issues.
    """
    main_url = "https://thingspace.verizon.com"
    client_id = app_id
    client_secret = app_secret
    username = "ldaniel80"
    password_encoded = "OG81a1dnOFhNMDh6SkN0biQq"

    # Decode password from base64
    password = base64.b64decode(password_encoded).decode('utf-8')

    token_url = f"{main_url}/api/ts/v1/oauth2/token"
    session_url = f"{main_url}/api/m2m/v1/session/login"

    # Prepare Basic Auth header
    auth_header = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()

    # Get OAuth access token
    token_response = requests.post(
        token_url,
        headers={
            "Authorization": f"Basic {auth_header}",
            "Accept": "application/json",
        },
        data={"grant_type": "client_credentials"},
    )
    token_response.raise_for_status()
    access_token_id = token_response.json().get("access_token")
    logging.info(f"### get_verizon_token_details Access token: {access_token_id}")

    # Get session token
    session_response = requests.post(
        session_url,
        headers={
            "Authorization": f"Bearer {access_token_id}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        },
        json={"username": username, "password": password},
    )
    session_response.raise_for_status()
    session_token = session_response.json().get("sessionToken")
    logging.info(f"## get_verizon_token_details Session token: {session_token}")
    return access_token_id,session_token
