"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil .N
Created Date: 24-12-24
"""

# Importing the necessary Libraries
import ast
import boto3
import requests
import os
import pandas as pd
from common_utils.email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import datetime
from datetime import time
from datetime import datetime, timedelta
import time
from io import BytesIO
from common_utils.data_transfer_main import DataTransfer
import json
import base64
import re
import pytds
from pytz import timezone
import numpy as np

def get_logging_instance(session_id):
    global logging
    logging=Logging(name="Kore", session_id=session_id)
    return True

# Dictionary to store database configuration settings retrieved from environment variables.
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}
logging = Logging(name="kore")



# def path_func(data,path):

#     session_id=data.get("sessionID","Common_id")
#     get_logging_instance(session_id)

#     if path == "/Kore_daily_sync":
#         result = Kore_daily_sync(data)
#     else:
#         result = {"error": "Invalid path or method"}
#         logging.warning("Invalid path or method requested: %s", path)

#     return result


def get_access_token(client_id,client_secret,token_url):
    # Prepare the request payload
    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret
    }

    # Send the POST request
    try:
        response = requests.post(token_url, data=payload)
        response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)

        # Parse the JSON response
        token_data = response.json()
        access_token = token_data.get("access_token")
        if access_token:
            print("Access Token Generated Successfully:")
            # print(access_token)
            return access_token
        else:
            print("Error: Access token not found in response.")
            print(token_data)
            return None
    except requests.exceptions.RequestException as e:
        print(f"Error fetching access token: {e}")
        return None


def get_account_id(base_url, headers, email, api_key, access_token):
    """
    Fetch the account ID using the email address.

    :param base_url: The base URL of the API
    :param email: The email address to query
    :return: The account ID or an error message
    """
    url = f"{base_url}/v1/accounts?email={email}"

    try:
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            # Parse and return account ID from the response
            data = response.json()
            account_id = data.get('accountId', 'Account ID not found in response')
            return account_id
        else:
            print(f"Error: {response.status_code} - {response.text}")
            return ''

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return ''


def get_all_subscriptions_usage_data(base_url, headers, account_id, page_index, start_date, end_date, max_page_item=10):
    """
    Get all ICCIDs for a given account by paginating through subscriptions.

    :param base_url: The base URL of the API
    :param account_id: The account ID to fetch subscriptions for
    :param max_page_item: Maximum number of items per page
    :return: A list of all ICCIDs for the account
    """
    all_iccids = {}
    iccid_usage_data={}
    subscription_plans_data={}
    while True:
        # Fetch the subscriptions for the current page
        subscriptions_data = get_all_subscriptions(base_url, headers, account_id, page_index=page_index, max_page_item=max_page_item)

        if isinstance(subscriptions_data, dict) and 'subscriptions' in subscriptions_data:
            subscriptions = subscriptions_data['subscriptions']
            if not subscriptions:
                break  # No more subscriptions, exit the loop
            for subscription in subscriptions:

                subscription_id = subscription.get('subscription-id')
                subscription_id_usage=get_subscription_usage(base_url, headers, account_id, subscription_id, start_date, end_date)
                if subscription_id_usage:
                    iccid_usage_data[subscription_id]=subscription_id_usage

                profile_id = subscription['profiles'][0]['profile-id']
                plan_data=get_subscription_plan(base_url, headers, account_id, profile_id)
                if plan_data:
                    subscription_plans_data[subscription_id]=plan_data

                if subscription_id:
                    all_iccids[subscription_id]=subscription
            page_index += 1  # Move to the next page
        else:
            print(f"Error fetching subscriptions: {subscriptions_data}")
            break  # Exit the loop if there's an error

    return all_iccids,iccid_usage_data,subscription_plans_data,page_index


def get_all_subscriptions(base_url, headers, account_id, page_index=1, max_page_item=10,
                          sort_field="subscriptionId", sort_direction="Desc",
                          imsi=None, imei=None, iccid=None, eid=None,
                          sim_state=None, msisdn=None, last_modified_from=None,
                          last_modified_to=None):
    """
    Fetch all subscriptions for a given account ID with optional filters.

    :param base_url: The base URL of the API
    :param account_id: The account ID to fetch subscriptions for
    :param page_index: Page index for pagination
    :param max_page_item: Maximum number of items per page
    :param sort_field: Field to sort by
    :param sort_direction: Sorting direction ('Asc' or 'Desc')
    :param imsi: Optional filter by IMSI
    :param imei: Optional filter by IMEI
    :param iccid: Optional filter by ICCID
    :param eid: Optional filter by EID
    :param sim_state: Optional filter by SIM state
    :param msisdn: Optional filter by MSISDN
    :param last_modified_from: Optional filter by last modified date (start)
    :param last_modified_to: Optional filter by last modified date (end)
    :return: JSON response or an error message
    """
    url = f"{base_url}/v1/accounts/{account_id}/subscriptions"
    params = {
        "page-index": page_index,
        "max-page-item": max_page_item,
        "sort-field": sort_field,
        "sort-direction": sort_direction,
        "imsi": imsi,
        "imei": imei,
        "iccid": iccid,
        "eid": eid,
        "sim-state": sim_state,
        "msisdn": msisdn,
        "show-state-history": "false",
        "last-modified-from": last_modified_from,
        "last-modified-to": last_modified_to
    }

    # Filter out None values from params
    params = {key: value for key, value in params.items() if value is not None}

    try:
        response = requests.get(url, headers=headers, params=params)

        if response.status_code == 200:
            # Return the JSON response
            return response.json()
        else:
            return f"Error: {response.status_code} - {response.text}"

    except requests.exceptions.RequestException as e:
        return f"An error occurred: {e}"


def get_subscription_plan(base_url, headers, account_id, profile_id):
    """
    Fetch the details of a SIM's plans using the profile ID.

    :param base_url: The base URL of the API
    :param account_id: The account ID
    :param profile_id: The profile ID of the SIM
    :param api_token: The API token for authentication
    :return: JSON response containing SIM plan details or an error message
    """
    # Construct the URL
    url = f"{base_url}/v1/accounts/{account_id}/profiles/{profile_id}"

    try:
        # Make the GET request
        response = requests.get(url, headers=headers)

        # Check if the request was successful
        if response.status_code == 200:
            return response.json()  # Return the response as JSON
        else:
            print(f"Error: {response.status_code} - {response.text}")
            return {}

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return {}


def get_subscription_usage(base_url, headers, account_id, subscription_id, start_date, end_date):
    """
    Fetch subscription usage records for a given subscription and account.

    :param base_url: The base URL of the API
    :param account_id: The account ID to fetch subscriptions for
    :param subscription_id: The subscription ID to fetch usage records for
    :param start_date: The start date for the usage records (format: YYYY-MM-DD)
    :param end_date: The end date for the usage records (format: YYYY-MM-DD)
    :param source: Optional source filter (e.g., 'API', 'ROAMING', etc.)
    :return: JSON response or an error message
    """
    url = f"{base_url}/v1/accounts/{account_id}/subscriptions/{subscription_id}/usage-records"
    params = {
        "start-date": start_date,
        "end-date": end_date,
        "source": "cdr"  # Optional parameter
    }

    # Filter out None values from params
    params = {key: value for key, value in params.items() if value is not None}

    try:
        response = requests.get(url, headers=headers, params=params)

        if response.status_code == 200:
            # Return the JSON response
            return response.json()
        else:
            print(f"Error: {response.status_code} - {response.text}")
            return {}

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return {}


def get_all_plans(base_url, headers, account_id):
    """
    Fetch all plans for a given account.

    :param base_url: The base URL of the API
    :param account_id: The account ID to fetch plans for
    :param api_token: The API token for authentication
    :return: JSON response containing all plans or an error message
    """
    # Construct the URL for the API request
    url = f"{base_url}/v1/accounts/{account_id}/plans"

    try:
        # Send the GET request to the API
        response = requests.get(url, headers=headers)

        # Check if the request was successful
        if response.status_code == 200:
            all_plan_data=response.json()  # Return the JSON response containing plans
            return all_plan_data['plans']
        else:
            print(f"Error: {response.status_code} - {response.text}")
            return []

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return []


def get_plan_usage(base_url, headers, account_id, plan_id, start_date, end_date):
    """
    Fetch usage records for a specific plan.

    :param base_url: The base URL of the API
    :param account_id: The account ID
    :param plan_id: The plan ID for which usage records are fetched
    :param start_date: Start date for the usage records (YYYY-MM-DD)
    :param end_date: End date for the usage records (YYYY-MM-DD)
    :param source: Source for the usage records (e.g., 'source')
    :param api_token: The API token for authentication
    :return: JSON response containing usage records or an error message
    """
    # Construct the URL for the API request
    url = f"{base_url}/v1/accounts/{account_id}/plans/{plan_id}/usage-records"

    # Parameters for the query
    params = {
        'start-date': start_date,
        'end-date': end_date,
        'source': "cdr"
    }

    try:
        # Send the GET request to the API with parameters and headers
        response = requests.get(url, headers=headers, params=params)

        # Check if the request was successful
        if response.status_code == 200:
            return response.json()  # Return the JSON response containing usage records
        else:
            print(f"Error: {response.status_code} - {response.text}")
            return {}

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return {}


def fetch_customer_details(base_url, headers, account_id):
    """
    Fetch all customer details (activation profiles) for a given account ID.

    :param base_url: The base URL of the API
    :param headers: The headers for the request (including authorization)
    :param account_id: The account ID
    :return: A dictionary with customer IDs and their details
    """
    # Construct the URL to fetch all activation profiles
    url = f"{base_url}/v1/accounts/{account_id}/activation-profiles"

    try:
        # Make the GET request to fetch all activation profiles
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            # Parse the response JSON to get activation profiles
            profiles = response.json()

            # Initialize a dictionary to store customer data
            customer_data = {}

            # Loop through each profile to fetch detailed information
            for profile in profiles.get("data", []):  # Assuming the profiles are in "data"
                profile_id = profile.get("id")  # Replace "id" with the actual key for profile ID
                if profile_id:
                    # Fetch details for the individual profile
                    details = fetch_customer_profile_details(base_url, headers, account_id, profile_id)
                    customer_data[profile_id] = details

            return customer_data
        else:
            print(f"Error fetching profiles: {response.status_code} - {response.text}")
            return {}

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return {}


def fetch_customer_profile_details(base_url, headers, account_id, profile_id):
    """
    Fetch detailed information for a specific activation profile.

    :param base_url: The base URL of the API
    :param headers: The headers for the request (including authorization)
    :param account_id: The account ID
    :param profile_id: The profile ID to fetch details for
    :return: JSON response containing profile details or an error message
    """
    # Construct the URL for the specific activation profile
    url = f"{base_url}/v1/accounts/{account_id}/activation-profiles/{profile_id}"

    try:
        # Make the GET request to fetch profile details
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            return response.json()  # Return the profile details as JSON
        else:
            print(f"Error fetching profile {profile_id}: {response.status_code} - {response.text}")
            return {}

    except requests.exceptions.RequestException as e:
        print(f"An error occurred while fetching profile {profile_id}: {e}")
        return {}


def Kore_daily_syncs(data):

    logging.info("Starting with Kore Features implementation")
    tenant_database = data.get("db_name", "spectrotel")

    database = DB(tenant_database, **db_config)
    email=data.get("email", "")
    mode=os.environ["MODE"]

    if mode=='sandbox':
        base_url=os.environ['KORE_URL_SANDBOX']
        client_id=os.environ['KORE_CLIENT_ID_SB']
        client_secret=os.environ['KORE_CLIENT_SECRET_KEY_SB']
        token_url=os.environ['KORE_TOKEN_URL_SB']
        api_key=os.environ['KORE_API_KEY_SB']
    elif mode=='Prod':
        base_url=os.environ['KORE_URL_PROD']
        client_id=os.environ['KORE_CLIENT_ID_PROD']
        client_secret=os.environ['KORE_CLIENT_SECRET_KEY_PROD']
        token_url=os.environ['KORE_TOKEN_URL_PROD']
        api_key=os.environ['KORE_API_KEY_PROD']

    access_token = get_access_token(client_id, client_secret, token_url)

    final_headers = {
        "Authorization": f"Bearer {access_token}",
        'Accept': 'application/json',
        'x-api-key': api_key
    }

    account_id=get_account_id(base_url ,final_headers ,email ,api_key ,access_token)
    if not account_id:
        return {"flag":False,'Message':'No acccount Id found for this email'}


    #need to check these dates
    start_date=''
    end_date = datetime.today().strftime('%Y-%m-%d')

    #need to used this index for futher lambda exceptions
    page_index=0

    #fetching all sims and their usage details and plan details
    all_iccids_data,iccid_usage_data,subscription_plans_data,page_index=get_all_subscriptions_usage_data(base_url, final_headers, account_id, page_index, start_date, end_date, max_page_item=10)

    #fetching all plans and their usage details
    plans=get_all_plans(base_url, final_headers, account_id)
    all_plans_usage={}
    if plans:
        for plan in plans:
            plan_id=plan['plan']['plan-id']
            if plan_id:
                plan_usage=get_plan_usage(base_url, final_headers, account_id, plan_id, start_date, end_date)
                if plan_usage:
                    all_plans_usage[plan_id]=plan_usage

    #fetching all Cutsomer details
    customer_details=fetch_customer_details(base_url, final_headers, account_id)

    #stagging to stagging tables


