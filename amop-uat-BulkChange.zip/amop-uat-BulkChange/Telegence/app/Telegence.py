"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24
"""
# Importing the necessary Libraries
from decimal import Decimal
import json
import logging
import os
import ast
import requests
import os
import pandas as pd
from common_utils.db_utils import DB
import psycopg2
from pandas import Timestamp
from datetime import datetime
from dotenv import load_dotenv
from dateutil.relativedelta import relativedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import concurrent.futures
import time
from io import BytesIO
from sqlalchemy import create_engine, text
import base64
import re
import pytds
import uuid
import threading
from pytz import timezone
import numpy as np
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import uuid
import time, random

# Database configuration
db_config = {
     "host": os.environ["HOST"],
     "port": os.environ["PORT"],
     "user": os.environ["USER"],
     "password": os.environ["PASSWORD"],

 }


'''
Change types Developed for POD19 are:
1. Archive Devices
2. Change Customer Rate Plan    
3. Change Carrier Rate Plan
4. Update Device Status
5. Assign Customer
6. Edit Username and Cost Center
7. Change Phone Number
8. Update PPU Address
9. Change ICCID/IMEI
10. Activate New Service
11. Create Revenue Service
12. Refresh a Line
'''


##function caller where the functions begins
def funtion_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler
    if path == "/telegence_bc_archive_devices":
        result = telegence_bc_archive_devices(data)
    elif path == "/telegence_bc_change_customer_rate_plan":
        result = telegence_bc_change_customer_rate_plan(data)
    elif path == "/telegence_bc_change_carrier_rate_plan":
        result = telegence_bc_change_carrier_rate_plan(data)
    elif path== "/telegence_bc_update_device_status":
        result = telegence_bc_update_device_status(data)
    elif path== "/telegence_bc_change_phone_number":
        result = telegence_bc_change_phone_number(data)
    elif path== "/telegence_bc_update_ppu_address":
        result = telegence_bc_update_ppu_address(data)
    elif path== "/telegence_bc_change_iccid_imei":
        result = telegence_bc_change_iccid_imei(data)
    elif path== "/telegence_bc_activate_new_service":
        result = telegence_bc_activate_new_service(data)
    elif path== "/telegence_bc_assign_customer":
        result = telegence_bc_assign_customer(data)
    elif path== "/telegence_bc_update_feature":
        result = telegence_bc_update_feature(data)
    elif path== "/telegence_bc_create_rev_service":
        result = telegence_bc_create_rev_service(data)
    elif path== "/telegence_bc_edit_username_cost_center":
        result = telegence_bc_edit_username_cost_center(data)
    elif path== '/telegence_refresh_a_line':
        result = telegence_refresh_a_line(data)
    elif path== '/telegence_bc_line_sync':
        result = telegence_bc_line_sync(data)
    ##else condition to handle the invalid path method
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result


## Function to get Carrier API details
def get_carrier_api_details(service_provider,change_type,common_utils_database):
    '''
    Function to get the Carrier API URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The Carreir API URL,app_id,app_secret if found, otherwise None.'''
    # Initialize variables
    carrier_api_url=None
    app_id=None
    app_secret=None
    carrier_limit=None
    alternative_api_url=None
    ##carrier api query and their limits query
    carrier_details= common_utils_database.get_data(
    "bulk_change_carrier_limits", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["carrier_api_url","app_id","app_secret","carrier_limit","alternative_api_url"]
    )
    logging.info(f"carrier_details: {carrier_details}")
    if not carrier_details.empty:
        ##fetching the carrier API limits
        carrier_api_url=carrier_details.iloc[0]['carrier_api_url']
        app_id=carrier_details.iloc[0]['app_id']
        app_secret=carrier_details.iloc[0]['app_secret']
        carrier_limit=carrier_details.iloc[0]['carrier_limit']
        alternative_api_url=carrier_details.iloc[0].get('alternative_api_url', None)
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url
    else:
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url

##Archive devices function 
def telegence_bc_archive_devices(data):
    """
    Archives devices from the system based on the provided ICCIDs.

    This function is typically triggered during a bulk change operation, where a list of SIM cards
    (identified by their ICCIDs) needs to be marked as archived in the system. Archiving a device
    means it is no longer considered active or in use, and its status is updated accordingly
    in relevant tables (e.g., inventory, assignment logs, usage tracking).

    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs to be archived.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
            - other metadata as needed for auditing or tracking.

    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
    """
    logging.info(f"Received data for archiving devices: %s", data)
    start_time = time.time()
    # Validate required fields
    iccids = data.get("iccids", [])
    invalid_iccids = data.get("invalid_iccids", [])
    tenant_id = data.get("tenant_id", [])
    bulk_change_id = data.get("bulk_change_id", "")
    created_by=data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    service_provider = data.get("service_provider", "")
    role_name= data.get("role", "")
    service_provider_id = data.get("service_provider_id", "")
    username= data.get("username", "")
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_archiving devices and {tenant_name} time is {now}")
    #database connection
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### telegence_bc_archive_devices and {tenant_name} DB connection error: %s", e)
        return {"flag":False,"message": "DB connection failed", "details": str(e)}
    # Audit - start
    bulk_change_audit_action(data, common_utils_database,
                 action=f"Bulk Change Process Initiated"
                )
    live_progress_percentage_tracker(database, bulk_change_id,25)
    try:
        bulk_change_requests = database.get_data(
                'sim_management_bulk_change_request',
                {"bulk_change_id": bulk_change_id},
                ['id', 'iccid']
        )
        ##main login to archive the devices
        # Map ICCID to request ID for fast access
        live_progress_percentage_tracker(database, bulk_change_id,40)
        iccid_to_request_id = dict(zip(bulk_change_requests["iccid"], bulk_change_requests["id"]))
        # Step 2: Archive valid ICCIDs in inventory
        database.update_dict(
            "sim_management_inventory",
            {"is_active": False,"is_deleted": True},
            and_conditions={"tenant_id": tenant_id},
            in_conditions={"iccid": iccids},
        )
        logging.info(f"### telegence_bc_archive_devices and {tenant_name} archived {len(iccids)} devices in inventory")

        # Prepare logs
        log_entries = []

        # Valid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,70)
        for iccid in iccids:
            request_id = iccid_to_request_id.get(iccid)
            if request_id:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Archive Device: {iccid}",
                    "request_text": "Update AMOP",
                    "has_errors": False,
                    "response_status": "PROCESSED",
                    "response_text": "Device archived successfully",
                    "error_text": "",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
                
        #updating bulk change request tables     
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len(iccids),"is_processed":True,"has_errors":False,
                    "processed_date": now,"status_details":"Device archived successfully"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": iccids},
        )
        # Prepare payload for history table update
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids":iccids,
                                    "msisdns":[],
                                    "service_provider":service_provider,
                                    "Partner":tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        #api call to update the history table
        try:
            if iccids:
                logging.info(f"### telegence_bc_archive_devices and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_archive_devices and {tenant_name} Exception in thread: {e}") 
        # Invalid SIMs
        invalid_iccids = data.get("invalid_iccids", [])
        for iccid in invalid_iccids:
            request_id = iccid_to_request_id.get(iccid)
            log_entries.append({
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Archive Device Failed: {iccid}",
                "request_text": "Update AMOP",
                "has_errors": True,
                "response_status": "ERROR",
                "response_text": "Invalid SIM - could not be processed",
                "error_text": "Invalid ICCID",
                "processed_date": now,
                "processed_by": created_by,
                "created_by": created_by,
                "created_date": now,
                "is_deleted": False,
                "is_active": True
            })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        #  Step 3: Bulk insert all logs
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### telegence_bc_archive_devices and {tenant_name} archived {len(iccids)} devices successfully")


        # Update the status of the bulk change request to PROCESSED
        database.update_dict(
                'sim_management_bulk_change',
                {
                    "status": "PROCESSED",
                    "success": len(iccids),
                    "processed_date": now
                },
                {'id': bulk_change_id}
            )
        ##Future Upudates will be done here 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(data, common_utils_database,
                 action=f"Sync To 1.0 Tables"
                )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        try:
            logging.info(f"### telegence_bc_archive_devices and {tenant_name} sync call has started")

            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f"### telegence_bc_archive_devices and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_bc_archive_devices and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_archive_devices and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_archive_devices and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # Attempt to audit the actionn
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_archive_devices",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for archive devices.{bulk_change_id}",
                "request_received_at": now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database,
                 action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### telegence_bc_archive_devices and {tenant_name} Audit logging failed: {e}")
        # Attempt to audit the actionn
        bulk_change_audit_action(data, common_utils_database,
                 action=f"Bulk Change Process Completed"
                )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### telegence_bc_archive_devices and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )

        return response
    except Exception as e:
        logging.exception(f"telegence_bc_archive_devices and {tenant_name} Error during bulk change processing for archive status telegence_bc_archive_devices: {str(e)}")
        # Update the status of the bulk change request to ERROR
        # Log the error
        error_message = f"Error during bulk change processing for archive status telegence_bc_archive_devices: {str(e)}"
        # response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        logging.error(f"### telegence_bc_archive_devices and {tenant_name} Error during bulk change processing for archive status telegence_bc_archive_devices: {str(e)}")
        # Prepare error response
        response = {
            "flag": False,
            "message": "Bulk change request processing failed for telegence_bc_archive_devices.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(iccids),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log error to database
            error_data = {
                "service_name": "telegence_bc_archive_devices",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for telegence_bc_archive_devices:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_archive_devices and {tenant_name} Exception in logging error data to DB: {e}")
        return response

## Change customer rate plan function
def telegence_bc_change_customer_rate_plan(data):
    """
    Change the customer rate plan for the given devices as part of a bulk change operation.
   
    this function is typically triggered during a bulk change operation where a list of SIM cards needs to have their customer rate plans updated.
    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs used to identify devices.
            -changed_data (dict): Dictionary containing the rate plan changes.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
            - other metadata as needed for auditing or tracking.
 
    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
 
    Returns:
        dict: Result of the operation with flags, messages, and details.
    """
    logging.info(f"### Received data for changing customer rate plan: %s", data)
    # Start timing the function execution
    start_time = time.time()
    # Extract all required fields from input data
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id", "")
    created_by = data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    tenant_id= data.get("tenant_id", "")
    service_provider = data.get("service_provider", "")
    service_provider_id = data.get("service_provider_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    invalid_msisdns = data.get("invalid_msisdns", [])
    invalid_ids=data.get('invalid_ids','')
    # Validate required fields
    customer_rate_plan_name = changed_data.get("customer_rate_plan_name", "")
    customer_rate_pool_name= changed_data.get("customer_rate_pool_name", "")
    effective_date = changed_data.get("effective_date", "")
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_change_customer_rate_plan and {tenant_name} time is {now}")
    try:
        # Connect to main and audit databases
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### DB connection error: %s", e)
        return {"flag": False, "message": "DB connection failed", "details": str(e)}
    try:
        # Audit - Start
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Bulk Change Process Initiated"
        )
        live_progress_percentage_tracker(database, bulk_change_id,25)
        rate_plan_db_id=None
        rate_pool_db_id=None
        plan_mb=None
        # Validate input data
        if customer_rate_plan_name:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"rate_plan_name": customer_rate_plan_name, "is_active": True},
                ["id","plan_mb"]
            )
            if not rate_plan_data.empty:
                rate_plan_db_id = rate_plan_data["id"].to_list()[0]
                plan_mb = rate_plan_data["plan_mb"].to_list()[0]

        if customer_rate_pool_name:
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"name": customer_rate_pool_name, "is_active": True},
                ["id"]
            )
            if not rate_pool_data.empty:
                rate_pool_db_id = rate_pool_data["id"].to_list()[0]
 
        # Fetch bulk change request entries for valid ICCIDs
        bulk_change_requests = database.get_data(
            'sim_management_bulk_change_request',
            {"bulk_change_id": bulk_change_id},
            ['id', 'subscriber_number']
        )
        if bulk_change_requests.empty:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_change_customer_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_change_customer rate plan and {tenant_name} Audit logging failed: {e}")
                return response
        bulk_change_requests = bulk_change_requests.rename(columns={'subscriber_number': 'msisdn'})
        update_fields={}
        # Extract valid MSISDNs
        # Prepare an update dict dynamically
        if rate_pool_db_id is None:
            update_fields["customer_rate_plan_id"] = None
            update_fields["customer_rate_plan_name"] = None
        elif str(rate_pool_db_id).strip() != "-1":
            update_fields["customer_rate_plan_id"] = rate_pool_db_id
            update_fields["customer_rate_plan_name"] = customer_rate_plan_name
        if rate_pool_db_id is None:
            update_fields["customer_rate_pool_id"] = None
            update_fields["customer_rate_pool_name"] = None
        elif str(rate_pool_db_id) != "-1":
            update_fields["customer_rate_pool_id"] = rate_pool_db_id	
            update_fields["customer_rate_pool_name"] = customer_rate_pool_name

        if effective_date:
            update_fields["effective_date"] = effective_date
        if plan_mb:
            update_fields["customer_data_allocation_mb"] = plan_mb
        else:
            update_fields["customer_data_allocation_mb"] = None
        # Update the SIM management inventory with the new rate plan
        live_progress_percentage_tracker(database, bulk_change_id,40)
        if update_fields.items():
            logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Updating SIM management inventory with updated fields: {update_fields}")
            database.update_dict(
            "sim_management_inventory",update_fields,
            and_conditions={"tenant_id":tenant_id,"is_active": True},
            in_conditions={"msisdn": msisdns},
            
            )
 
        # Map ICCID to request ID for logging
        msisdn_to_request_id = dict(zip(bulk_change_requests["msisdn"], bulk_change_requests["id"]))
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entries = []
 
        # Log valid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,70)
        for msisdn in msisdns:
            request_id = msisdn_to_request_id.get(msisdn)
            if not rate_plan_db_id and not rate_pool_db_id:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Change Customer Rate Plan",
                    "request_text": "Update AMOP",
                    "has_errors": not rate_plan_db_id,
                    "response_status": "PROCESSED" if rate_plan_db_id else "ERROR",
                    "response_text": "Changed customer rate plan successfully" if rate_plan_db_id else "Rate plan not updated",
                    "error_text": "" if rate_plan_db_id else "Rate plan not found or inactive",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
            else:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Change Customer Rate Plan",
                    "request_text": "Update AMOP",
                    "has_errors": not rate_plan_db_id,
                    "response_status": "PROCESSED",
                    "response_text": "Changed customer rate plan successfully",
                    "error_text": "",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        #update       
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len(msisdns),"is_processed":True,"has_errors":False,
                    "processed_date": now,"status_details":"Changed customer rate plan successfully"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"subscriber_number": msisdns},
        )
        # Prepare payload for history table update
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": [],
                                    "msisdns":msisdns,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        if effective_date:
            payload_history_table["data"]["effective_date"] = effective_date
        #api call to update the history table
        try:
            if msisdns:
                logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}") 
        if invalid_ids:
            logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Invalid MSISDNs found: {invalid_ids}")
            # Log invalid ICCIDs
            for request_id in invalid_ids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Change Customer Rate Plan Failed",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_ids),"is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"id": invalid_ids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} inserted {len(log_entries)} log entries for bulk change request")
        # Update bulk change status to PROCESSED
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "success": len(msisdns),
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Call sync API in separate thread after delay
        # below sync url is used to sync the bulk change table  data with 1.0
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #below sync url used to sync the inventory table data with 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Sync To 1.0 Tables"
        )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        try:
            logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} sync call has started")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        # Prepare success response
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        # audit the auditing log
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_change_customer_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing customer rate plan for devices.{bulk_change_id}",
                "request_received_at":now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database, action=f"Auditing")

        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Audit logging failed: {e}")
        # audit the auditing log
        bulk_change_audit_action(data, common_utils_database, action=f"Bulk Change Process Completed")
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        return response
 
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processingg: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(msisdns),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "telegence_bc_change_customer_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
 

##Update Device Status function
def telegence_bc_update_device_status(data):
    """
   Update the device status using the Telegence API.

    This function processes a list of MSISDNs and updates their device status in the Telegence system.
    It performs the following steps:
        - Retrieves API credentials and configuration limits based on the service provider and change type.
        - Fetches bulk change requests and maps MSISDNs to their respective request payloads.
        - Iteratively calls the Telegence API for each MSISDN with retry logic.
        - Updates status in the request and inventory tables based on API responses.
        - Logs both success and failure results into the bulk change log table.
        - Handles any invalid MSISDNs or request IDs by logging them appropriately.
        - Marks the bulk change as processed.
        - Records an audit entry and error logs in case of exceptions.

    Args:
        data (dict): Input dictionary containing the following keys:
            - msisdns (list): List of MSISDNs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains the payload structure to send to the Telegence API.
            - created_by (str): Username of the user initiating the request.
            - service_provider (str): Name of the carrier or service provider.
            - change_type (str): Type of update being performed (e.g., SIM status or device status).
            - tenant_id (str): ID of the tenant initiating the request.
            - tenant_name (str): Name of the tenant for logging/auditing purposes.
            - db_name (str): Database name associated with the tenant.
            - username (str): Username to use in audit logs.
            - invalid_msisdns (list): MSISDNs that failed validation before processing.
            - invalid_ids (list): Request IDs associated with invalid rows.
            - request_received_at (str): Timestamp when the request was received (optional).

    Returns:
        dict: A response object indicating the result of the operation, containing:
            - flag (bool): True if processing completed without unhandled exceptions.
            - message (str): Summary message indicating the result.
            - processed (int): Number of MSISDNs processed.
            - msisdns (list): List of MSISDNs attempted.
            - invalid_msisdns (list): List of MSISDNs skipped due to invalid state.
            - bulk_change_id (str): ID of the bulk change request.
            - error (str, optional): Error message in case of failure.
    """
    logging.info(f"### Received data for updating device status: {data}")
    start_time = time.time()
    # Extract required fields
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    invalid_ids = data.get("invalid_ids", [])
    request = data.get("changed_data", {}).get("Request", {})
    mode = request.get("mode")
    reason_code = request.get("reasonCode")
    # Extract status values from changed_data
    device_status_id = data.get("device_status_id","")
    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_update_device_status and {tenant_name} time is {now}")
    # Validate bulk_change_id
    successfull_ids = []
    if not bulk_change_id:
        logging.error(f"### telegence_bc_update_device_status and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### telegence_bc_update_device_status and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    live_progress_percentage_tracker(database, bulk_change_id,10)

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    try:
        # Get carrier API credentials and configuration
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### telegence_bc_update_device_status and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### telegence_bc_update_device_status and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        ).rename(columns={"subscriber_number": "msisdn"})
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_update_device_status",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
                return response
        device_status_data=pd.DataFrame()
        device_status = None
        ##fetching the status of the device to get updated using id
        if device_status_id:
            device_status_data = database.get_data(
                "device_status",
                {"id": device_status_id, "is_active": True},
                ["id", "display_name"]
            )
        if not device_status_data.empty:
           device_status = device_status_data["display_name"].iloc[0]
        live_progress_percentage_tracker(database, bulk_change_id,20)
        ##fetching the requests ids
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        if PARALLEL_REQUESTS>10:
            logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        remaining = list(msisdns)
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        # Execute API calls in parallel using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(msisdns), BATCH_SIZE):
                batch = msisdns[i:i + BATCH_SIZE]
                futures = {}

                for msisdn in batch:
                    url = f"{carrier_api_url}/{msisdn}"
                    payload = {"mode": mode, "reasonCode": reason_code}
                    def task(msisdn=msisdn, url=url, payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_update_device_status and {tenant_name} Attempting {attempt} for MSISDN: {msisdn} with URL: {url}")
                                resp = requests.patch(url, json=payload, 
                        headers={
                                    "app-id": app_id,
                                    "app-secret": app_secret,
                                    "Content-Type": "application/json"
                                }, timeout=60)
                                logging.info(f"### telegence_bc_update_device_status and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successfull_ids.append(msisdn)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### telegence_bc_update_device_status and {tenant_name} Attempt {attempt} failed for MSISDN: {msisdn}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                           "processed_date": now,"status_details":result},
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory if successful
                        if success:
                            database.update_dict(
                                "sim_management_inventory",
                                {"sim_status": device_status, "device_status_id": device_status_id},
                                and_conditions={"tenant_id": tenant_id, "is_active": True},
                                in_conditions={"msisdn": [msisdn]}
                            )

                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                            "log_entry_description": "Update Telegence Subscriber: Telegence API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                        return msisdn

                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_update_device_status and {tenant_name} Error processing MSISDN: {e}")

            if INTERVAL and i + BATCH_SIZE < len(msisdns):
                time.sleep(INTERVAL)
        live_progress_percentage_tracker(database, bulk_change_id,75)
        # Handle and log invalid MSISDNs
        #prepare the payload for history table
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": [],
                                    "msisdns":successfull_ids,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        #api call to update the history table
        try:
            if successfull_ids:
                logging.info(f"### telegence_bc_update_device_status and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_update_device_status and {tenant_name} Exception in thread: {e}") 
        if invalid_ids:
            for request_id in invalid_ids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Update Telegence Subscriber: Invalid MSISDN",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")

        # Mark invalid request IDs as processed
        if invalid_ids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"id": invalid_ids}
            )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        #  sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # api call to sync the bulk change inventory table data with 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### telegence_bc_update_device_status and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### telegence_bc_update_device_status and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_bc_update_device_status and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_update_device_status and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        # Prepare response
        response={
            "flag": True,
            "processed": len(msisdns) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        # audit the final bulk change log
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_update_device_status",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for updating device status for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the auditing log
            bulk_change_audit_action(
                    data, common_utils_database,
                    action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### telegence_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### telegence_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### telegence_bc_update_device_status and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "telegence_bc_update_device_status",
                "created_date": data.get("request_received_at") or now,
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for: {msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### telegence_bc_update_device_status and {tenant_name} Exception in logging error data to DB: {log_e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        return response

## Change Carrier Rate Plan function
def telegence_bc_change_carrier_rate_plan(data):
    """Change the carrier rate plan for the given devices.
    This function processes a list of MSISDNs and updates their carrier rate plan in the Telegence system.
    It handles bulk requests, updates the database, and logs the results.   
    Args:
        data (dict): Input data containing the following keys:
            - msisdns (list): List of MSISDNs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Telegence API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Recevied data for change carrier rate plan :{data}")
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Validate required fields
    # Initialize for log entries
    log_entries = []
    success_ids = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_change_carrier_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,20)
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        carrie_rate_plan=change_request_json.get("RatePlanName","")
        effective_date=change_request_json.get("EffectiveDate","")
        optimization_group=change_request_json.get("OptimizationGroup","")
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        ## Prepare headers for API call
        headers = {
            "app-id": app_id,
            "app-secret": app_secret,
            "Content-Type": "application/json"
        }
        rate_plan_id=None
        optimization_group_id=None
        rate_plan_code=None
        optimization_group_data = pd.DataFrame()
        rate_plan_data=pd.DataFrame()
        # Validate input data for rateplan and optimization
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Validating input data for rate plan and optimization group")
        if carrie_rate_plan:
           rate_plan_data = database.get_data(
            "carrier_rate_plan",
            {"rate_plan_code": carrie_rate_plan, "is_active": True},
            ["id","friendly_name"]
            )
        if not rate_plan_data.empty:
            rate_plan_id = rate_plan_data["id"].to_list()[0]
            rate_plan_code=rate_plan_data["friendly_name"].to_list()[0]
        if optimization_group and str(optimization_group) != "-1":
           optimization_group_data = database.get_data(
            "optimization_group",
            {"optimization_group_name": optimization_group, "is_active": True},
            ["id"]
            )
        if not optimization_group_data.empty:
            optimization_group_id = optimization_group_data["id"].to_list()[0]
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Rate plan ID: {rate_plan_id}, Optimization Group ID: {optimization_group_id}, Rate Plan Code: {rate_plan_code}")
        # Prepare an update dict 
        update_fields = {"carrier_rate_plan_id": rate_plan_id,"carrier_rate_plan_name": rate_plan_code}       
        if optimization_group_id is not None:
            update_fields["optimization_group_id"] = optimization_group_id
        if effective_date:
           update_fields["effective_date"] = effective_date
        # Validate MSISDNs
        remaining = msisdns.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###telegence_bc_change_carrier_rate_plan and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        # if effective_date:
        #    payload["effectiveDate"] = effective_date
        live_progress_percentage_tracker(database, bulk_change_id,40)
        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of MSISDNs
                batch = msisdns[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each MSISDN in the batch
                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for msisdn in batch:
                    # Prepare the URL and payload for the API call
                    url = f"{carrier_api_url}/{msisdn}"
                    payload={
                        "serviceCharacteristic": [
                            {
                                "name": "singleUserCode",#"carrierRatePlanId",
                                "value": carrie_rate_plan
                            }
                        ]
                    }
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    def task(msisdn=msisdn, url=url, payload=payload):  
                        success = False
                        result = ""
                        status = "API_FAILED"
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Attempting {attempt} for MSISDN: {msisdn} with URL: {url}")
                                resp = requests.patch(
                                    url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    success_ids.append(msisdn)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Attempt {attempt} failed for MSISDN: {msisdn}: {result}")
                                time.sleep(RETRY_DELAY)
                        if success:
                            update_data = {
                                "status": status,
                                "has_errors": False,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details":result   
                            }
                        else:
                            update_data = {
                                "status": status,
                                "has_errors": True,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details":result
                            }
                        #update the request status
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id},
                            )
                        # Only update inventory if API succeeded
                        if success:
                            database.update_dict(
                                "sim_management_inventory",update_fields,
                                and_conditions={"tenant_id":tenant_id,"is_active": True},
                                in_conditions={"msisdn": [msisdn]}
                                )
                        # Constructing the log entry
                        log = {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                        "log_entry_description": "Update Telegence Subscriber: Telegence API",
                        "request_text": json.dumps(payload),
                        "has_errors": status == "API_FAILED",
                        "response_status": "PROCESSED" if success else "API_Failed",
                        "response_text": result,
                        "error_text": "" if status == "PROCESSED" else result,
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                        }
            
                        if log:
                            database.insert_data(log,"sim_management_bulk_change_log") 
                        return msisdn
                    
                    # Submit the task to the executor
                    logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Submitting task for MSISDN: {msisdn}")
                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Error processing MSISDN: {e}")

              
        if interval and i + batch_size < len(msisdns):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        #preare the payload for history table
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": [],
                                    "msisdns":success_ids,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        if effective_date:
            payload_history_table["data"]["effective_date"] = effective_date
        # Call the history table API
        try:
            if success_ids:
                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}") 
        # Update the bulk change request status   
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Processed {len(msisdns) - len(remaining)} MSISDNs, {len(remaining)} remaining")
        ## Handle invalid MSISDNs
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_ids:
            logging.info(f"### Invalid MSISDNs found: {invalid_ids}")
            # Log invalid ICCIDs
            for request_id in invalid_ids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"id": invalid_ids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"telegence_bc_change_carrier_rate_palan and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread 
        live_progress_percentage_tracker(database, bulk_change_id,80)
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API for 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'### telegence_bc_change_carrier_rate_plan and {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f'### telegence_bc_change_carrier_rate_plan and {tenant_name} sync call has ended') 
        except Exception as e:
            logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        ##auditing the sync completion
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_change_carrier_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response

## Change Phone Number function  
def telegence_bc_change_phone_number(data):
    """
    Change phone number using the Telegence API.
    This function processes a bulk change request to update phone numbers in the Telegence system.
    Args:
        data (dict): Input data containing the following keys:
            - tenant_name (str): Name of the tenant.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            - changed_data (dict): Data to be sent to the Telegence API.
            - old_msisdn (list): List of old MSISDNs to process.
            - new_msisdn (list): New MSISDNs to set.
            - effective_date (str): Effective date for the change.
            - bulk_change_id (str): ID of the bulk change request.
            - tenant_id (str): ID of the tenant.
            - created_by (str): User who initiated the request.
            - username (str): Username of the user making the request.
            - invalid_msisdns (list): List of invalid MSISDNs, if any.
            - invalid_ids (list): List of invalid IDs, if any.
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    
    """
    logging.info(f"### Received data for changing phone number {data}")
    start_time=time.time()
    tenant_name=data.get("tenant_name","")
    service_provider=data.get("service_provider","")
    change_type=data.get("change_type","")
    changed_data=data.get("changed_data",{})
    msisdns=data.get("msisdns",[])
    bulk_change_id=data.get("bulk_change_id","")
    tenant_id=data.get("tenant_id")
    created_by = data.get("created_by", "")
    username = data.get("username", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    invalid_ids=data.get('invalid_ids','')
    role_name = data.get("role_name", "")
    access_token = data.get("access_token", "")
    tenant_database = data.get("db_name", "")
    #frequency_setting=data.get("frequency_setting",4)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### telegence_bc_change_phone_number and {tenant_name} time is {now}")
    logging.info(f"### telegence_bc_change_phone_number are {msisdns}")
    # Validate required fields
    if not bulk_change_id:
        logging.error(f"### telegence_bc_change_phone_number and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    #connect to the database
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} DB connection failed: {e}")
        return {"flag":False,"message": "DB connection failed", "details": str(e)}
    live_progress_percentage_tracker(database, bulk_change_id,10)
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
    except Exception as e:
        logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Audit logging failed: {e}")
    # Initialize for log entries
    log_entries = []
    successful_msisdns = []
    ## current time
    frequency_setting=None
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    tenant_details = common_utils_database.get_data(
      "tenant", {"tenant_name": tenant_name}, ["id","change_phone_number_frequency_setting"]
    )
    if not tenant_details.empty:
        frequency_setting = tenant_details.iloc[0].get("change_phone_number_frequency_setting")

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        #  Fetching carrier API configuration details
        try:
            logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            # Fetch carrier API details
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}

        # Fetch bulk change rows       
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_change_phone_number",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_change_phone_number and {tenant_name} Audit logging failed: {e}")
                return response
        # Rename columns for consistency 
        logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Fetched {len(bulk_requests_df)} bulk change requests from the database")
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        # Feching details from inventory table 
        inventory_df = database.get_data(
            "sim_management_inventory",
            {"msisdn": msisdns, "is_active": True, "tenant_id": tenant_id,"service_provider_display_name":service_provider},
            ["msisdn", "billing_account_number", "service_zip_code"]
        )  
        if not inventory_df.empty:
            inventory_records = inventory_df.to_dict(orient='records')
            logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Fetched inventory records for MSISDNs from the database")

        else:
            logging.error(f"### telegence_bc_change_phone_number and {tenant_name} No inventory records found for MSISDNs: {msisdns}")
            inventory_records = []
        live_progress_percentage_tracker(database, bulk_change_id,20)
        msisdn_to_details = {
             record["msisdn"]: {
             "billingAccountNumber": record["billing_account_number"],
             "serviceZipCode": record["service_zip_code"]
           }
             for record in inventory_records
           }

        ## Prepare headers for API call
        headers = {
            "app-id": app_id,
            "app-secret": app_secret,
            "Content-Type": "application/json"
        }
        
        # Validate MSISDNs
        remaining = msisdns.copy()
        updated_msisdns = {}
        logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Validating input data for phone number change")
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {e}"}
        
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###telegence_bc_change_phone_number and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        valid_msisdns=[]
        blocked_msisdns=[]
        response_data = None
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action=f"Processing With Carrier APIs")
        # Query to get counts per msisdn
        if msisdns:
            placeholders = ",".join(["%s"] * len(msisdns))

            query = f"""
                SELECT req.subscriber_number, COUNT(*) AS processed_count
                FROM public.sim_management_bulk_change_request req
                JOIN public.sim_management_bulk_change bc
                ON req.bulk_change_id = bc.id
                WHERE req.subscriber_number IN ({placeholders})
                AND req.status = %s
                AND req.created_date >= NOW() - INTERVAL '30 days'
                AND bc.change_request_type = %s
                GROUP BY req.subscriber_number
            """

            # Params: expand msisdns list + extra params
            params = msisdns + ["PROCESSED", change_type]

            df = database.execute_query(query, params=params)
            if df is None or df.empty:
                valid_msisdns = []  
                blocked_msisdns = []
            else:
                # Valid where processed_count <= frequency_setting
                valid_msisdns = df.loc[df["processed_count"] <= frequency_setting, "subscriber_number"].tolist()

                # Blocked where processed_count > frequency_setting
                blocked_msisdns = df.loc[df["processed_count"] > frequency_setting, "subscriber_number"].tolist()
        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        if valid_msisdns:
            msisdns = valid_msisdns
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of MSISDNs
                batch = msisdns[i:i + batch_size]
                futures = {}
                
                # Process each MSISDN in the batch
                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for msisdn in batch:
                    url = f"{carrier_api_url}"
                    details = msisdn_to_details.get(msisdn)   
                    payload = {
                        "billingAccountNumber": details["billingAccountNumber"],
                        "subscriberNumber": msisdn,
                        "serviceZipCode": details["serviceZipCode"]
                    }
                    # Define the task function to be executed in parallel
                    def task(msisdn=msisdn, payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        response_data = {}

                        # Retry loop
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Attempting {attempt} for MSISDN: {msisdn} with URL: {url}")
                            
                                response = requests.post(url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Response Code: {response.status_code} for MSISDN: {msisdn}")
                                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Response Body: {response.text}")

                                success = 200 <= response.status_code < 300
                                result = response.text
                                status = "PROCESSED" if success else "API_FAILED"

                                if success:
                                    response_data = response.json()
                                    successful_msisdns.append(msisdn)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Attempt {attempt} failed for MSISDN: {msisdn}: {result}")
                                time.sleep(RETRY_DELAY)
                        # If the API call was successful, check the response
                        # Check and extract new MSISDN from response
                        new_msisdn_number = None
                        if response_data:
                            number_change_info = response_data.get("numberChangeInfo", {})
                            if number_change_info.get("status") == "FAILED":
                                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Phone number change failed for {msisdn}: {number_change_info.get('statusMessage', 'Unknown error')}")
                                success = False
                                status = "API_FAILED"
                            else:
                                new_msisdn_number = number_change_info.get("newSubscriberNumber")
                                if new_msisdn_number:
                                    updated_msisdns[msisdn] = new_msisdn_number
                                    success = True
                                    status = "PROCESSED"
                                    logging.info(f"### telegence_bc_change_phone_number and {tenant_name} MSISDN changed from {msisdn} to {new_msisdn_number} ")

                        # Update request status
                        update_data = {
                            "status": status,
                            "has_errors": not success,
                            "is_processed": True,
                            "processed_date": now,
                            "status_details":result
                        }
                        # Update the request status in the database
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id},
                        )

                        # Update inventory if success
                        if success and new_msisdn_number:
                            update_fields = {"msisdn": new_msisdn_number}
                            database.update_dict(
                                "sim_management_inventory",
                                update_fields,
                                and_conditions={"is_active": True},
                                in_conditions={"msisdn": [msisdn]},
                            )

                        # Construct and insert log
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                            "log_entry_description": "Update Telegence Change Phone Number: Telegence API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        # Insert log into the database
                        database.insert_data(log, "sim_management_bulk_change_log")
                        return msisdn  # for tracking

                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Error processing MSISDN: {e}")

        if interval and i + batch_size < len(msisdns):
            time.sleep(interval)  
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Prepare URL and payload for history table update
        if successful_msisdns:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": [],
                                        "msisdns":successful_msisdns,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update history table
            try:
                 logging.info(f"### telegence_bc_change_phone_number and {tenant_name} sync call has started for history table")
                 threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Exception in thread: {e}") 
            logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Processed {len(msisdns) - len(remaining)} MSISDNs, {len(remaining)} remaining")
        live_progress_percentage_tracker(database, bulk_change_id,75)
        #handling blocked msisdns
        if blocked_msisdns:
            logging.info(f"### blocked MSISDNs found: {blocked_msisdns}")
            # Log invalid IDs
            for msisdn in blocked_msisdns:
                request_id = msisdn_to_request_id.get(msisdn)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Chang Phone number",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": f"Change Phone Number can be done only{frequency_setting} times in last 30 days for the same MSISDN",
                    "error_text": "blocked MSISDN",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_msisdns:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","is_processed":True,"has_errors":True,"processed_date": now,"status_details":f"Change Phone Number can be done only{frequency_setting} times in last 30 days for the same MSISDN"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"subscriber_number": blocked_msisdns},)
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        #handling invalid msisdns
        if invalid_msisdns:
            logging.info(f"### Invalid MSISDNs found: {invalid_msisdns}")
            # Log invalid IDs
            for msisdn in invalid_msisdns:
                request_id = msisdn_to_request_id.get(msisdn)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Chang Phone number",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_msisdns:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","is_processed":True,"has_errors":True,"processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"subscriber_number": invalid_msisdns},)
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"telegence_bc_change_phone_number and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
       
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
                ##Future Upudates will be done here 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API for 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'### telegence_bc_change_phone_number and {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f"### telegence_bc_change_phone_number and {tenant_name} sync call has ended") 
        except Exception as e:
            logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
       ##auditing the sync completion
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_change_phone_number",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing phone number for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
 
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "telegence_bc_change_phone_number",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Exception in logging error data to DB: {e}")
        return response

##PPU address update function
def telegence_bc_update_ppu_address(data):
    """
    Bulk update of PPU address using AMLC Telegence API using MSISDN to change_request mapping.

    This function performs the following steps:
        - Extracts necessary metadata and initializes DB connections.
        - Fetches carrier API credentials and limits.
        - Fetches and maps MSISDNs to their payloads and request IDs.
        - Sends PATCH requests to update PPU address using ThreadPoolExecutor with retry logic.
        - Logs responses, updates DB entries, and handles invalid MSISDNs/IDs.
        - Logs audit events before and after processing.

    Args:
        data (dict): Contains keys such as msisdns, bulk_change_id, created_by, service_provider, etc.

    Returns:
        dict: Summary response including processed count and any remaining MSISDNs.
    """
    logging.info(f"### Received data for PPU address update: %s",data)
    start_time = time.time()
    # Extract input metadata
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    invalid_ids = data.get("invalid_ids", [])
    now_dt = datetime.now()
    username= data.get("username", "")
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###def telegence_bc_update_ppu_address and {tenant_name} time is {now}")
    if not bulk_change_id:
        logging.error("### telegence_bc_update_ppu_address and {tenant_name} Missing required fields") 
        return {"flag": False, "message": "bulk_change_id is required"}

    # DB Connections
    try:
        database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### telegence_bc_update_ppu_address and{tenant_name} DB connection error:{e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,10)
    try:
        # Fetch carrier API details
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### telegence_bc_update_ppu_address and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}
        
    except Exception as e:
        logging.exception(f"### telegence_bc_update_ppu_address and{tenant_name} Audit logging failed after config fetch: {e}")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    ## Carrier limits
    successful_msisdns = []
    BATCH_SIZE = carrier_limits.get("batch_size")
    PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
    INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
    MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
    RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
    try:
        # Fetch change requests from DB
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        ).rename(columns={"subscriber_number": "msisdn"})
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_update_ppu_address",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_update_ppu_address and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,30)
        try:
            change_request = json.loads(change_request_json)
        except (TypeError, json.JSONDecodeError):
            # handle parsing error
            change_request = {}
        logging.info(f"### telegence_bc_update_ppu_address and{tenant_name} change_request: {change_request}")
        useraddress = change_request.get("UserAddress", {})
        updated_data = {"user_address": json.dumps(useraddress)}
        ##fetching the change requests
        msisdn_to_changerequest = dict(zip(bulk_requests.msisdn, bulk_requests.change_request))
        msisdn_to_request_id = dict(zip(bulk_requests.msisdn, bulk_requests.id))

        logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Fetched {len(bulk_requests)} bulk change requests from the database")
        logs = []
        remaining = list(msisdns)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        ##batch processing
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            ## Process each batch of MSISDNs
            for i in range(0, len(msisdns), BATCH_SIZE):
                # Create a batch of MSISDNs
                logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Processing batch {i // BATCH_SIZE + 1} with {min(BATCH_SIZE, len(msisdns) - i)} MSISDNs")
                batch = msisdns[i:i + BATCH_SIZE]
                futures = {}
                # Prepare payloads and URLs for each MSISDN in the batch
                logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Batch size is {len(batch)}")
                for msisdn in batch:
                    url = f"{carrier_api_url}/{msisdn}"
                    try:
                        # Parse the change request JSON for the MSISDN
                        payload_str=msisdn_to_changerequest.get(msisdn)
                        request_payload = json.loads(payload_str)
                        payload = request_payload.get("UserAddress")
                    except Exception as e:
                        logging.warning(f"### telegence_bc_update_ppu_address and {tenant_name} Invalid JSON for MSISDN {msisdn}: {e}")
                        payload = {}
                    ## Validate payload
                    request_id = msisdn_to_request_id.get(msisdn)
                    def task(msisdn=msisdn, url=url, payload=payload, request_id=request_id):
                        success = False
                        result = ""
                        status = "API_FAILED"

                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Attempt {attempt} - URL: {url}")
                                resp = requests.patch(
                                    url,
                                    json=payload,
                                    headers={"app-id": app_id, "app-secret": app_secret, "Content-Type": "application/json"},
                                    timeout=60
                                )
                                ## Prepare request payloads
                                logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Response Code: {resp.status_code} for PPU address update")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successful_msisdns.append(msisdn)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Attempt {attempt} failed for {msisdn}:{e}")
                                time.sleep(RETRY_DELAY)

                        # Update DB request row
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                              "processed_date": now,"status_details":result},
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory
                        if success:
                            logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Updating inventory for MSISDN: {msisdn}")
                            database.update_dict("sim_management_inventory", updated_data, {
                                "is_active": True,
                                "msisdn": msisdn
                                })

                        # Prepare and insert log
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": request_id,
                            "log_entry_description": "Update PPU Address via Telegence API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now_dt,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now_dt,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log,"sim_management_bulk_change_log")
                        return msisdn

                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Error processing MSISDN in thread: {e}")

                if INTERVAL and i + BATCH_SIZE < len(msisdns):
                    time.sleep(INTERVAL)
        logging.info(f"carrier requests are processed successfully")
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": [],
                                    "msisdns":successful_msisdns,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        #api call to update device history tables
        try:
            if successful_msisdns:
                logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Exception in thread: {e}") 
        live_progress_percentage_tracker(database, bulk_change_id,80)
                    
        # Handle invalid MSISDNs
        if invalid_ids:
            logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Invalid MSISDNs found: {invalid_ids}")
            # Log invalid IDS
            for request_id in invalid_ids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Invalid MSISDN during PPU address update",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid MSISDN - could not be processed",
                    "error_text": "Invalid MSISDN",
                    "processed_date": now_dt,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now_dt,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")

        if invalid_ids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now,"status_details":"Invalid MSISDN - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"id": invalid_ids}
            )

        database.update_dict(
            "sim_management_bulk_change",
            {"status": "PROCESSED", "processed_date": now_dt},
            {"id": bulk_change_id}
        )
        ##Future Upudates will be done here 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                    "data": {
                        "access_token": access_token,
                        "data": {
                            "bulk_change_id": bulk_change_id
                        },
                        "db_name": tenant_database,
                        "is_update": True,
                        "module_name": "Bulk Change",
                        "Partner": tenant_name,
                        "path": "/update_bulk_change_tables_10",
                        "request_received_at": now,
                        "role_name": role_name,
                        "tenant_name": tenant_name,
                        "username": username
                    }
                }
        # Sync API for 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        ##prepare response
        response = {
            "flag": True,
            "processed": len(msisdns) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk PPU address update request processed successfully.",
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        # End time calculation
        try:
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_update_ppu_address",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk PPU address update request for devices: {bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
             logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        logging.exception(f"### telegence_bc_change_update_ppu_address and {tenant_name} Audit logging failed: {e}")
        error_message = f"Error during bulk PPU address update processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "telegence_bc_update_ppu_address",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
             logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
    
## create rev service update function
def telegence_bc_create_rev_service(data):
    """
    Create Rev Serivice in Rev.IO for the provided MSISDNs, update inventory,
    and update device_tenant and rev_service_product tables accordingly.
    
    This function handles bulk requests with batching and parallelism, 
    updates the database, logs the results, and performs retries on API failures.

    Args:
        data (dict): Input data containing the following keys:
            - msisdns (list): List of msisdns to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to Rev.IO API.
            - created_by (str): User who initiated the request.
            - tenant_id (str): Tenant ID for DB operations.
            - db_name (str): DB name for tenant.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            - invalid_msisdns (list): msisdns to mark as invalid if required.
            - username (str): Username of the user initiating the request
            - tenant_name (str): Name of the tenant
            - role_name (str): Role of the user
            - access_token (str): Access token for sync API

    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Received data for Create Rev Serivice {data} ")
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Initialize for log entries
    log_entries = []
    successful_msisdns = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_create_rev_service and {tenant_name} time is {now}")

    # Check for missing required fields
    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### telegence_bc_create_rev_service and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### telegence_bc_create_rev_service and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
            logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Carrier API details fetched successfully")

        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}

        # Fetch bulk change rows
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        # Validate input data 
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_create_rev_service",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_create_rev_service and {tenant_name} Audit logging failed: {e}")
                return response
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        #Extract relevant fields from the change request 
        customer_rate_plan_id=change_request_json.get("CustomerRatePlan","")
        customer_rate_pool_id=change_request_json.get("CustomerRatePool","")
        rev_customer_id=change_request_json.get("RevCustomerId","")
        service_type_id=change_request_json.get("ServiceTypeId","")
        effective_date=change_request_json.get("EffectiveDate","")
        activated_date=change_request_json.get("ActivatedDate","")
        usageplangroupid=change_request_json.get("UsagePlanGroupId","")
        revproductidlist=change_request_json.get("RevProductIdList",[])
        product_id = revproductidlist[0] if revproductidlist else None
        provider_id=change_request_json.get("ProviderId","")
        number=change_request_json.get("Number","")
        integration_authentication_id=change_request_json.get("IntegrationAuthenticationId","")
        device_id=change_request_json.get("DeviceId")
        description=change_request_json.get("Description","")
        rate= change_request_json.get("RateList", [])
        revpackageid=change_request_json.get("RevPackageId", None)
        # Initialize variables for customer and rate plan details
        rate_plan_id = None
        customer_rate_plan = None
        customer_rate_pool = None
        rev_customer = None
        provider_data=pd.DataFrame()
        rev_customer_uuid = None
        customer_id=None
        customer_name=None
       # Fetch customer and rate plan details from the database
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name"]
            )
            if not rate_plan_data.empty:
                rate_plan_id = rate_plan_data["rate_plan_code"].to_list()[0]
                customer_rate_plan=rate_plan_data["rate_plan_name"].to_list()[0]
        if customer_rate_pool_id:
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool = rate_pool_data["name"].to_list()[0]
        if rev_customer_id:
            rev_data = database.get_data(
                "revcustomer",
                {"rev_customer_id": rev_customer_id, "is_active": True},
                ["customer_name", "id"]
            )
            if not rev_data.empty:
                rev_customer = rev_data["customer_name"].to_list()[0]
                rev_customer_uuid = rev_data["id"].to_list()[0]
        if rev_customer:
            customer_data=database.get_data(
                "customers",
                {"customer_name":rev_customer,"is_active": True},
                ["id","customer_name"]
            )
        if not customer_data.empty:
            customer_id=customer_data["id"].to_list()[0]
            customer_name=customer_data["customer_name"].to_list()[0]
        if provider_id:
            provider_data = database.get_data(
                "rev_provider",
                {"provider_id": provider_id, "is_active": True,"integration_authentication_id": integration_authentication_id},
                ["id"]
            )
            if not provider_data.empty:
                rev_provider_id = provider_data["id"].to_list()[0] 
       # Prepare update fields for the database
        update_fields = {"customer_rate_plan_id": customer_rate_plan_id,"customer_rate_plan_name": customer_rate_plan}
        if customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id
            update_fields["customer_rate_pool_name"] = customer_rate_pool
        if rev_customer_id:
            update_fields["rev_customer_id"] = rev_customer_id
            update_fields["rev_customer_name"] = rev_customer
        if effective_date:
            update_fields["effective_date"] = effective_date
        if integration_authentication_id:
            update_fields["account_number_integration_authentication_id"] = integration_authentication_id
        if device_id:
            update_fields["device_id"] = device_id
        update_fields["customer_id"] = customer_id if customer_id is not None else None
        update_fields["customer_name"] = customer_name if customer_name is not None else None
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        bulk_requests = bulk_requests.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests.msisdn, bulk_requests.id))
        msisdn_to_changerequest = dict(zip(bulk_requests.msisdn, bulk_requests.change_request))
        ## Prepare headers for API call
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
        }
        # Prepare data for database insertion
        product_data={}
        if revpackageid:
            product_data["package_id"] = revpackageid
        if rate:
            product_data["rate"] = rate
        if product_id:
            product_data["product_id"] = product_id
        # Validate msisdns
        remaining = msisdns.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###telegence_bc_create_rev_service and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        ## Chunking msisdns and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process each batch of msisdns
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of msisdns
                batch = msisdns[i:i + batch_size]
                # create a dictionary to hold futures
                futures = {}
                logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for msisdn in batch:
                    url = f"{carrier_api_url}"
                    logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Processing msisdn: {msisdn}")
                    payload_str = msisdn_to_changerequest.get(msisdn)
                    logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Payload for MSISDN {msisdn}: {payload_str}")
                    #request_payload = json.loads(payload_str)
                    #extract the create rev service flag
                    #rev_service = request_payload.get("CreateRevService", False)
                    # Build payloads for all APIs
                    rev_api_payload = {
                        "customer_id": rev_customer_id,
                        "provider_id": provider_id,
                        "service_type_id": service_type_id,
                        "number": number,
                        "activated_date": activated_date,
                    }
                   
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    #task function
                    def task(msisdn=msisdn):
                        """
                            - Step 1: Call RevService API with retries
                            - Step 2: Extract RevService ID from API response
                            - Step 3: Insert into rev_service table & update inventory"""
                        success = False
                        result = ""
                        status = "API_FAILED"
                        id = None
                       
                        try:                           
                            #  API Call to create the revservice
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Attempt {attempt} - URL: {url}")
                                    
                                    resp = requests.post(url, json=rev_api_payload, headers=headers, timeout=60)
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Response Code: {resp.status_code} for Create Rev Service")
                                    logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Response Text: {result}")
                                    status = "PROCESSED" if success else "API_Failed"
                                    if success:
                                        try:
                                            response_data = resp.json()
                                            id = response_data.get("id")
                                            successful_msisdns.append(msisdn)
                                        except Exception:
                                            id = None
                                        break
                                except Exception as e:
                                    result = str(e)
                                    status = "API_EXCEPTION"
                                    logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Attempt {attempt} failed for {msisdn}: {e}")
                                    time.sleep(RETRY_DELAY)                
                            if success:
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":result},
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"subscriber_number": msisdns},
                                )
                                #inserting values in rev service 
                                rev_data={
                                "rev_customer_id":rev_customer_uuid,
                                "number":msisdn,
                                "rev_service_id":id,
                                "activated_date":activated_date,
                                "is_active":True,
                                "integration_authentication_id":integration_authentication_id,
                                "rev_provider_id":rev_provider_id,
                                "rev_service_type_id":service_type_id,
                                "rev_service_line_status":"PROCESSED",
                                "bulk_change_id":bulk_change_id,
                                }
                                database.insert_data(rev_data,"rev_service")
                                #updating inventory table
                                rev_service_log=database.update_dict(
                                    "sim_management_inventory",update_fields,
                                    and_conditions={"tenant_id":tenant_id,"is_active": True},
                                    in_conditions={"msisdn": [msisdn]}
                                )
                            # Inserting logs based on api result
                            rev_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Create Rev.io Service: Rev.io API",
                                    "request_text": json.dumps(rev_api_payload),
                                    "has_errors": status == "PROCESSED",
                                    "response_status": "PROCESSED" if success else "API_Failed",
                                    "response_text": result,
                                    "error_text": "" if status == "PROCESSED" else result,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                            database.insert_data(rev_log,"sim_management_bulk_change_log") 
                            logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Rev Service created successfully for MSISDN: {msisdn}")
                            #inserting logs after updating inventory table
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Create Rev.io Service: Update AMOP",
                                    "request_text": json.dumps(rev_api_payload),
                                    "has_errors":False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK" ,
                                    "error_text": "",
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Inventory updated successfully for MSISDN: {msisdn}")       
                        except Exception as e:
                            logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Unexpected error for msisdn {msisdn}: {str(e)}")
                        logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Completed processing for MSISDN: {msisdn}")
                        return msisdn
                    futures[executor.submit(task)] = msisdn
                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Error processing MSISDN in thread: {e}")
        if interval and i + batch_size < len(msisdns):
            time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Processed %d msisdns, %d remaining", len(msisdns) - len(remaining), len(remaining))
        # Check for any invalid ICCIDs
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": [],
                                    "msisdns":successful_msisdns,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        if effective_date:
            payload_history_table["data"]["effective_date"] = effective_date
        # Call sync API for history table
        try:
            if successful_msisdns:
             logging.info(f"### telegence_bc_create_rev_service and {tenant_name} sync call has started for history table")
             threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Exception in thread: {e}") 
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_ids:
            logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Invalid msisdns found: %s", invalid_ids)
            # Log invalid IDs
            for request_id in invalid_ids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Create Rev Serivice ",
                    "request_text": "Update AMOP",
                    "has_errors": True, 
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_ids:
            database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR","is_processed":True,"has_errors":True,"status_details":"Invalid SIM - could not be processed"},
                    and_conditions={"bulk_change_id": bulk_change_id},
                    in_conditions={"id": invalid_ids},
                )
        # Insert log entries into DB
        if log_entries: 
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Bulk Change ID: {bulk_change_id}")
        logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Processed %d msisdns, %d remaining", len(msisdns) - len(remaining), len(remaining))
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token, 
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api call for inventory table
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### telegence_bc_create_rev_service and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### telegence_bc_create_rev_service and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_bc_create_rev_service  and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            audit_data_user_actions = {
                "service_name": "telegence_bc_create_rev_service",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for Create Rev Serivice for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response



    
   
##Change ICCID/IMEI function
def telegence_bc_change_iccid_imei(data):
    """
     Update ICCID or IMEI for multiple subscribers using Telegence API.

    This function performs the following steps:
        - Validates required input values.
        - Establishes DB connections.
        - Fetches API credentials and carrier limits.
        - Builds and sends PATCH requests per MSISDN in parallel with retry logic.
        - Updates status in DB and logs results.
        - Handles invalid MSISDNs and triggers sync API.

    Args:
        data (dict): Input dictionary containing:
            - msisdns (list): List of MSISDNs to process.
            - new_iccid (str): New ICCID to assign (if applicable).
            - new_imei (str): New IMEI to assign (if applicable).
            - bulk_change_id (str): Unique ID of the bulk change job.
            - service_provider (str): Carrier/service provider name.
            - change_type (str): Type of operation.
            - created_by (str): User initiating the request.
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant.
            - db_name (str): Database name for the tenant.
            - username (str): Username for error/audit tracking.
            - changed_data (dict): Contains serviceCharacteristic array.
            - invalid_msisdns (list): Optional invalid MSISDNs before processing.
            - request_received_at (str): Optional timestamp.

    Returns:
        dict: Result object with success flag, count, and error info
    """
    logging.info(f"Received data for ICCID/IMEI change{data}")
    start_time = time.time()
    # Extract input data
    msisdns = list(data.get("msisdns", []))
    bulk_change_id = data.get("bulk_change_id")
    tenant_id = data.get("tenant_id","")
    invalid_ids=data.get("invalid_ids","")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name")
    db_name = data.get("db_name", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    request_received_at = data.get("request_received_at")
    tenant_database = db_name
    access_token = data.get("access_token", "")
    role_name = data.get("role", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_change_iccid_imei and {tenant_name} time is {now}")
    logs = []
    processed = 0
    # DB Connections
    try:
        database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### telegence_bc_change_iccid_imei and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    # Audit log - start processing
    try:
        bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,20)
    except Exception as e:
        #logging.exception("### Audit logging failed before PATCH requests")
        logging.error(f"### telegence_bc_change_iccid_imei and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Get carrier config
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
            service_provider, change_type, common_utils_database
        )
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        ##fetching carrier url
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}

        # Fetch request rows
        request_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "subscriber_number", "change_request"]
        )
        logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Fetched {len(request_df)} records from bulk change request table")
        updated_data={}
        successful_msisdns = []
        # Validate input data
        if not request_df.empty:
            change_request_json = request_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_change_iccid_imei",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_change_iccid_imei and {tenant_name} Audit logging failed: {e}")
                return response
            if isinstance(change_request_json, str):
                change_request_json = json.loads(change_request_json)
            ##fetching the required details
            request_df = request_df.rename(columns={'subscriber_number': 'msisdn'})
            service_chars = change_request_json.get("RevService", {})
            if service_chars:
                ##fetching the customer rate plan and customer rate pool details
                customer_rate_plan_id = service_chars.get("CustomerRatePlan","")
                customer_rate_pool_id = service_chars.get("CustomerRatePool","")
                if customer_rate_plan_id:
                    rate_plan_data = database.get_data(
                        "customerrateplan",
                        {"id": customer_rate_plan_id, "is_active": True},
                        ["rate_plan_name"]
                    )
                    if not rate_plan_data.empty:
                        customer_rate_plan_name = rate_plan_data["rate_plan_name"].to_list()[0]
                        updated_data['customer_rate_plan_name']=customer_rate_plan_name
                        updated_data['customer_rate_plan_id']=customer_rate_plan_id
                if customer_rate_pool_id:
                    rate_plan_data = database.get_data(
                        "customer_rate_pool",
                        {"id": customer_rate_pool_id, "is_active": True},
                        ["name"]
                    )
                    if not rate_plan_data.empty:
                        customer_rate_pool_name = rate_plan_data["name"].to_list()[0]
                        updated_data['customer_rate_pool_name']=customer_rate_pool_name
                        updated_data['customer_rate_pool_id']=customer_rate_pool_id
        # Create mappings
        id_map = dict(zip(request_df["msisdn"], request_df["id"]))
        msisdns_to_change_request = dict(zip(request_df["msisdn"], request_df["change_request"]))
        logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Mapped {len(msisdns_to_change_request)} MSISDNs to change requests")

        # Carrier limits
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        BATCH_SIZE = carrier_limits.get("batch_size", 50)
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests", 10)
        if PARALLEL_REQUESTS>10:
            logging.info(f"###telegence_bc_change_iccid_imei and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        remaining = list(msisdns)

        headers = {
            "app-id": app_id,
            "app-secret": app_secret,
            "Content-Type": "application/json"
        }
        live_progress_percentage_tracker(database, bulk_change_id,40)
        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(msisdns), BATCH_SIZE):
                batch = msisdns[i:i + BATCH_SIZE]
                logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Processing batch {i // BATCH_SIZE + 1} with {len(batch)} MSISDNs")
                futures = {}

                for msisdn in batch:
                    payload_str = msisdns_to_change_request.get(msisdn)

                    if not payload_str:
                        logging.warning(f"### telegence_bc_change_iccid_imei and {tenant_name} Skipping MSISDN {msisdn}: missing change_request payload")
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": id_map.get(msisdn),
                            "log_entry_description": f"Missing change_request payload for {msisdn}",
                            "request_text": "N/A",
                            "has_errors": True,
                            "response_status": "ERROR",
                            "response_text": "Missing payload",
                            "error_text": "No change_request found",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        logs.append(log)
                        continue
                    request_payload = json.loads(payload_str)
                    payload = request_payload.get("Request")
                    service_chars = payload.get("serviceCharacteristic", [])
                    characteristics_dict = {item["name"]: item["value"] for item in service_chars}
                    iccid = characteristics_dict.get("sim","")
                    imei = characteristics_dict.get("IMEI","")
                    updated_data['imei']=imei
                    updated_data['iccid']=iccid
                    #logging.info(f"updated_data is {updated_data}")
                    logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Processing MSISDN: {msisdn} with payload: {payload}")
                    url = f"{carrier_api_url}/{msisdn}"
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    def task(msisdn=msisdn, url=url, payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        request_id = id_map.get(msisdn)

                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Attempt {attempt} - URL: {url}")
                                resp = requests.patch(url, json=payload, headers=headers, timeout=30)
                                logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                if 200 <= resp.status_code < 300:
                                    success = True
                                    status = "PROCESSED"
                                    result = resp.text
                                    successful_msisdns.append(msisdn)
                                    break
                                else:
                                    result = resp.text
                                    time.sleep(RETRY_DELAY)
                            except Exception as e:
                                result = str(e)
                                logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Attempt {attempt} failed for {msisdn}: {e}")
                                time.sleep(RETRY_DELAY)
                        # DB update
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                              "processed_date": now,"status_details":result},
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id}
                        )
                        # Update inventory
                        if success:
                            database.update_dict("sim_management_inventory", updated_data, {
                                "is_active": True,
                                "msisdn": msisdn
                            })
                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": request_id,
                            "log_entry_description": f"Change {'ICCID' if 'sim' in characteristics_dict else 'IMEI'} via Telegence API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                        return msisdn

                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                        processed += 1
                    except Exception as e:
                        logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Error processing MSISDN in thread: {e}")

                if INTERVAL and i + BATCH_SIZE < len(msisdns):

                    time.sleep(INTERVAL)
        live_progress_percentage_tracker(database, bulk_change_id,60)
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": [],
                                    "msisdns":successful_msisdns,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        # api call to update device history table
        try:
            if successful_msisdns:
             logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} sync call has started for history table")
             threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Exception in thread: {e}") 
        # Handle invalid MSISDNs
        if invalid_ids:
            for request_id in invalid_ids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Invalid MSISD during ICCID/IMEI change",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid input",
                    "error_text": "Invalid identifier",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if invalid_ids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","errors":len(invalid_ids),"is_processed":True,"has_errors":False,
                    "processed_date": now,"status_details":"Invalid input"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"id": invalid_ids},
            )

        if logs:
            database.insert_data(logs, "sim_management_bulk_change_log")

        # Update bulk change summary
        database.update_dict("sim_management_bulk_change", {
            "status": "PROCESSED",
            "success": processed,
            "processed_date": now
        }, {"id": bulk_change_id})

        # Trigger sync API
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
            "data": {
                "access_token": access_token,
                "data": {
                    "bulk_change_id": bulk_change_id
                },
                "db_name": tenant_database,
                "is_update": True,
                "module_name": "Bulk Change",
                "Partner": tenant_name,
                "path": "/update_bulk_change_tables_10",
                "request_received_at": now,
                "role_name": role_name,
                "tenant_name": tenant_name,
                "username": username
            }
        }
        # Sync API call for inventory table
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }

        try:
            logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

        except Exception as e:
            logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        live_progress_percentage_tracker(database, bulk_change_id,95)
        logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Bulk ICCID/IMEI change completed in {time.time() - start_time:.2f} seconds | Processed: {processed}")
        total_time = time.time() - start_time
        
        response= {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_change_iccid_imei",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing iccid/imei for devices.{bulk_change_id}",
                "request_received_at":now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Processed {len(msisdns)} MSISDNs, {len(remaining)} remaining")
        return response
    except Exception as e:
        logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Error during bulk change processing: {str(e)}")
        error_type = str(type(e).__name__)
        error_message = f"Error during bulk change processing for change ICCID?IMEI: {str(e)}"
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns, 
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            error_data = {
                "service_name": "Bulk ICCID/IMEI Processor",
                "created_date": request_received_at or now,
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk ICCID/IMEI change for: {msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": request_received_at or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Exception in logging error data to DB: {e}")
        return response
  

##Edit username or cost center function
def telegence_bc_edit_username_cost_center(data):
    """Edit the username or cost center associated with the device."""

    logging.info(f"### Recevied data for telegence_bc_edit_usename_cost_center :{data}")
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    #username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Validate required fields
    # Initialize for log entries
    log_entries = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_edit_usename_cost_center",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_edit_usename_cost_center and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,20)
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
           username=change_request_json.get("ContactName", "")
           cost_center=change_request_json.get("CostCenter1", "") 
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        ## Prepare headers for API call
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
            "Content-Type": "application/json-patch+json"
        }
        
        # Prepare an update dict 
        rev_data=pd.DataFrame()
        revid=None
        update_fields = {}
        successfull_ids = []
        if username:
           update_fields["username"] = username
        if cost_center:
            update_fields["cost_center"]=cost_center
        # Validate MSISDNs
        remaining = msisdns.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###telegence_bc_edit_usename_cost_center and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        costcenter_labels = ["CostCenter1", "CostCenter2", "CostCenter3"]
        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of MSISDNs
                batch = msisdns[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each MSISDN in the batch
                logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for msisdn in batch:
                    # Prepare the URL and payload for the API call
                    rev_data = database.get_data(
                            "rev_service",
                            {"number": msisdn, "is_active": True},
                            ["rev_service_id",]
                          )
                    if not rev_data.empty:
                        revid = rev_data["rev_service_id"].to_list()[0]
                    else:
                       logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} No active RevService found for MSISDN: {msisdn}") 
                    url = f"{carrier_api_url}/{revid}"
                    payload = []
                    def task(msisdn=msisdn, url=url, payload=payload):  
                        success = False
                        result = ""
                        status = "API_FAILED"
                        username_index = None
                        costcenter_index = None
                        if revid:
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Attempting {attempt} for MSISDN: {msisdn} with URL: {url}")
                                    resp = requests.get(
                                        url, headers=headers, timeout=60)
                                    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Response Text: {result}")
                                    status = "PROCESSED" if success else "API_FAILED"
                                    if success:
                                        response_data = resp.json()
                                        break
                                except Exception as e:
                                    result = str(e)
                                    logging.warning(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Attempt {attempt} failed for MSISDN: {msisdn}: {result}")
                                    time.sleep(RETRY_DELAY)
                            if success:
                                label_to_index = {f["label"]: i for i, f in enumerate(response_data["fields"])}
                                username_index = label_to_index.get("User Name")
                                #costcenter_index = next((label_to_index[label] for label in costcenter_labels if label in label_to_index), None)
                                costcenter_index = [
                                        index for label, index in label_to_index.items() if label.startswith("CostCenter")
                                    ]
                                logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Username index: {username_index}, Cost Center index: {costcenter_index} for MSISDN: {msisdn}")
                                    
                            #update the request status
                            if username_index  or costcenter_index:
                                if username_index:
                                    payload.append({
                                        "op": "replace",
                                        "path": f"/fields/{username_index}/value",
                                        "value": username
                                    })

                                if costcenter_index:
                                    payload.append({
                                        "op": "replace",
                                        "path": f"/fields/{costcenter_index}/value",
                                        "value": cost_center
                                    })

                                logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} API Payload: {payload}, URL: {url}")

                                for attempt in range(1, MAX_RETRIES + 1):
                                    try:
                                        get_resp = requests.patch(url,json=payload, headers=headers, timeout=60)
                                        api_success = 200 <= get_resp.status_code < 300
                                        api_result = get_resp.text
                                        logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} Response Code: {get_resp.status_code}")
                                        logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} Response Text: {api_result}")
                                        status = "PROCESSED" if api_success else "API_FAILED"
                                        if api_success:
                                            response_data = get_resp.json()
                                            successfull_ids.append(msisdn)
                                            break
                                    except Exception as e:
                                        result = str(e)
                                        status = "API_EXCEPTION"
                                        time.sleep(RETRY_DELAY)
                                if api_success:
                                    update_data = {
                                        "status": status,
                                        "has_errors": False,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result 

                                    }
                                else:
                                    update_data = {
                                        "status": status,
                                        "has_errors": True,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result 
                                    }  
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    update_data,
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"subscriber_number":[msisdn]},
                                    )             
                                    #inserting values into revservice product table 
                                rev_service_log=database.update_dict(
                                    "sim_management_inventory",update_fields,
                                    and_conditions={"tenant_id":tenant_id,"is_active": True},
                                    in_conditions={"msisdn": [msisdn]}
                                )
                                #constracting logs 
                                log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                        "log_entry_description": "Edit Username/Cost Center via Telegence API",
                                        "request_text": json.dumps(payload),
                                        "has_errors": status == "API_FAILED",
                                        "response_status": "PROCESSED" if api_success else "API_Failed",
                                        "response_text": api_result,
                                        "error_text": "" if status == "PROCESSED" else result,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                
                                if log:
                                    database.insert_data(log,"sim_management_bulk_change_log")
                                logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Inserting log for Edit Username/Cost Center: {log}") 
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                        "log_entry_description": "Update AMOP",
                                        "request_text": json.dumps(payload),
                                        "has_errors":False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK" ,
                                        "error_text": "",
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                            else:
                                rev_service_log=database.update_dict(
                                            "sim_management_inventory",update_fields,
                                            and_conditions={"tenant_id":tenant_id,"is_active": True},
                                            in_conditions={"msisdn": [msisdn]}
                                        )
                                successfull_ids.append(msisdn)

                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK"},
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"subscriber_number":[msisdn]},
                                    )

                                    #constracting logs
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                        "log_entry_description": "Edit Username/Cost Center via Telegence API",
                                        "request_text": "Upadte AMOP",
                                        "has_errors": False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK",
                                        "error_text": "" ,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                        else:
                            rev_service_log=database.update_dict(
                                    "sim_management_inventory",update_fields,
                                    and_conditions={"tenant_id":tenant_id,"is_active": True},
                                    in_conditions={"msisdn": [msisdn]}
                                )
                            successfull_ids.append(msisdn)

                            database.update_dict(
                                    "sim_management_bulk_change_request",
                                    {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK"},
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"subscriber_number": [msisdn]},
                                    )

                            #constracting logs
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Update AMOP",
                                    "request_text": "Edit Username/Cost Center processed",
                                    "has_errors": False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK",
                                    "error_text": "" ,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                        return msisdn


                    # Submit the task to the executor
                    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Submitting task for MSISDN: {msisdn}")
                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Error processing MSISDN: {e}")

              
        if interval and i + batch_size < len(msisdns):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Update the bulk change request status   
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Processed {len(msisdns) - len(remaining)} MSISDNs, {len(remaining)} remaining")
        ## Handle invalid MSISDNs
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": [],
                                    "msisdns":successfull_ids,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        # Call the API to update device history tables
        try:
            if successfull_ids:
                logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Exception in thread: {e}") 
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_ids:
            logging.info(f"### Invalid MSISDNs found: {invalid_ids}")
            # Log invalid ICCIDs
            for request_id in invalid_ids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"id": invalid_ids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"telegence_bc_edit_usename_cost_center and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread 
        live_progress_percentage_tracker(database, bulk_change_id,80)
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync call for inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'### telegence_bc_edit_usename_cost_center and {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f'### telegence_bc_edit_usename_cost_center and {tenant_name} sync call has ended') 
        except Exception as e:
            logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_edit_usename_cost_center",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the sync completion
            bulk_change_audit_action(
                    data, common_utils_database,
                    action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response

## Activate new service function
def telegence_bc_activate_new_service(data):
    """Activate a new service for the given devices.
       this function performs the following steps:
         - Validates required input values.
            - Establishes DB connections.
            - Fetches API credentials and carrier limits.
            - Builds and sends POST requests per ICCID in parallel with retry logic.
            - Updates status in DB and logs results.
            - Handles invalid ICCIDs and triggers sync API.
    Args:
        data (dict): Input dictionary containing:
            - iccids (list): List of ICCIDs to process.
            - bulk_change_id (str): Unique ID of the bulk change job.
            - changed_data (dict): Contains serviceCharacteristic array.
            - service_provider (str): Carrier/service provider name.
            - change_type (str): Type of operation.
            - created_by (str): User initiating the request.
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant.
            - db_name (str): Database name for the tenant.
            - username (str): Username for error/audit tracking.
            - customer_name (str): Name of the customer.
            - customer_id (str): ID of the customer.
            - role_name (str): Role name for auditing purposes.
            - invalid_iccids (list): Optional invalid ICCIDs before processing.

    Returns:    
        dict: Result object with success flag, count, and error info
    """
    logging.info(f"### Received data for Activate New Service: {data}")
    iccids = data.get("iccids", [])
    #imei=data.get("imei")
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    role = data.get("role_name", "")
    invalid_ids= data.get("invalid_ids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    access_token=data.get("access_token", "")
    customer_name = data.get("customer_name", "")
    customer_id = data.get("customer_id", "")
    service_provider_id=data.get("service_provider_id",None)
    ##start time for processing
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_activate_new_service and {tenant_name} time is {now}")
    start_time=time.time()
    log_entries=[]
    logging.info("Activate new service function called")
    #validating inputs
    required_fields = [ "bulk_change_id", "service_provider", "change_type","iccids"]
    missing = [field for field in required_fields if not data.get(field)]

    if missing:
       return {
        "flag": False,
        "message": f"Missing required fields: {', '.join(missing)}"
    }
    tenant_database = data.get("db_name", "")
    # DB setup
    try: 
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    live_progress_percentage_tracker(database, bulk_change_id,10)
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
    except Exception as e:
        logging.exception(f"###telegence_bc_activate_new_service and {tenant_name} Audit logging failed while inserting logs: {e}")

    try:
        # Carrier API details
        try:
            # Get carrier API URL and limits
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
       
        # Fetch bulk change rows
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},#iccid
            ["id", "iccid", "change_request"]
        )
        rate_plan_name=None
        rate_plan_data=pd.DataFrame()
        carrier_rate_plan_data=pd.DataFrame()
        live_progress_percentage_tracker(database, bulk_change_id,20)        # Validate input data
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_activate_new_service",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_activate_new_service and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,25)
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        #Extract relevant fields from the change request
        characteristics = change_request_json.get("TelegenceActivationRequest", {}).get("service", {}).get("serviceCharacteristic", [])
        characteristics_dict = {item["name"]: item["value"] for item in characteristics}
        carrier_rate_code = characteristics_dict.get("singleUserCode")
        servicezipcode=characteristics_dict.get("serviceZipCode")
        customer_rate_plan_id = change_request_json.get("CustomerRatePlan")
        billing_account = change_request_json.get("TelegenceActivationRequest", {}).get("billingAccount")
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} and customer_rate_plan_id is {customer_rate_plan_id} and billing_account is {billing_account}")
        if billing_account and "id" in billing_account:
            billing_account_id = billing_account["id"]
        else:
            billing_account_id = None
        ##fetching the foundation account number details
        foundation_account_number=None
        try:
            foundation_account_number=database.execute_query('telegence_device',{"billing_account_number":billing_account_id},["foundation_account_number"])["foundation_account_number"].to_list()[0]
        except Exception as e:
            logging.info(f"Exception while fetching the account number{e}")
            foundation_account_number=None
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} foundation_account_number is {foundation_account_number} and billing_account_id is {billing_account_id}")
        # Validate tenant name and get parent tenant ID
        parent_tenant_id = None
        try:
            parent_tenant_id=common_utils_database.get_data('tenant',{"id":tenant_id},["parent_tenant_id"])["parent_tenant_id"].to_list()[0]
        except Exception as e:
            logging.exception(f"Exception while fetching parent_tenant_id{e}")
            parent_tenant_id = None
        # Fetch customer rate plan details
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name"]
            )
        if not rate_plan_data.empty:
            rate_plan_code = rate_plan_data["rate_plan_code"].to_list()[0]
            rate_plan_name = rate_plan_data["rate_plan_name"].to_list()[0]
        carrier_rate_plan_name=None
        carrier_rate_plan_id=None
        if carrier_rate_code:
           carrier_rate_plan_data = database.get_data(
            "carrier_rate_plan",
            {"rate_plan_code": carrier_rate_code, "is_active": True},
            ["id","friendly_name"]
            )
        if not carrier_rate_plan_data.empty:
            carrier_rate_plan_id = carrier_rate_plan_data["id"].to_list()[0]
            carrier_rate_plan_name=carrier_rate_plan_data["friendly_name"].to_list()[0]
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        iccid_to_requestid=dict(zip(bulk_requests.iccid,bulk_requests.id))
        iccid_to_changerequest=dict(zip(bulk_requests.iccid,bulk_requests.change_request))
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Fetched {iccid_to_changerequest} bulk change requests from the database for activate new service")
        live_progress_percentage_tracker(database, bulk_change_id,30)
        successful_iccids=[]

        # Prepare headers for API request
        headers = {
            "app-id": app_id,
            "app-secret": app_secret,
            "Content-Type": "application/json"
        }
        remaing_iccids=iccids.copy()
        logs=[]
        # Prepare data for insert
        inventory_data = {}
        if carrier_rate_plan_id:
            inventory_data["carrier_rate_plan_id"] = carrier_rate_plan_id
        if carrier_rate_plan_name :
            inventory_data["carrier_rate_plan_name"] = carrier_rate_plan_name
        if customer_rate_plan_id :
            inventory_data["customer_rate_plan_id"] = customer_rate_plan_id
        if rate_plan_name :
            inventory_data["customer_rate_plan_name"] = rate_plan_name
        if servicezipcode:
            inventory_data["service_zip_code"]=servicezipcode
       # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f" ###telegence_bc_activate_new_service and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        ## Retry settings
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} max retires{MAX_RETRIES}")
        logs = []
        remaining = list(iccids)
        subscriber_number=None
        sim_status=None
        device_status_id=None
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        integration_id=data.get('integration_id',None)
        device_status_data=database.get_data("device_status",{"integration_id":integration_id},["id","display_name"])
        ## Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process ICCIDs in batches and in parallel
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # craete a dictionary to hold futures
                futures = {}
                logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for iccid in batch:
                    current_iccid = iccid
                    logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} current_iccid is {current_iccid}")
                    # Step 1: Prepare the API URL and payload
                    url = f"{carrier_api_url}"
                    logging.info(f" ###telegence_bc_activate_new_service and {tenant_name}Processing iccid_to_changerequest for iccid {iccid} and {iccid_to_changerequest}")
                    payload_str=iccid_to_changerequest.get(iccid)
                    logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} Processing ICCID: {iccid} with payload: {payload_str}")
                    # Step 2: Parse the payload string into a dictionary
                    request_payload = json.loads(payload_str)
                    logging.info(f"request_payload is {request_payload} ")
                    #Step 3: Extract the 'Request' part
                    payload_data = request_payload.get("TelegenceActivationRequest")
                    logging.info(f"Payload is {payload_data} ")
                    telegence_payload=[payload_data]
                    ##task for activate new service
                    def task(iccid=current_iccid, url=url, telegence_payload=telegence_payload):
                        """
                        Task to Activate New Service:
                        1. POST activation request with retries
                        2. Poll GET for final status/data with retries
                        3. Update DB, log, inventory
                        """ 
                        logging.info(f"task started for iccid{iccid}")
                        success = False
                        api_success=False
                        result = ""
                        status = "API_FAILED"
                        id=None
                        data_json={}
                        subscriber_number = None
                        sim_status = None
                        billing_account_id = None
                        imei_api = None
                        sim = None
                        GET_API_RETRIES=10
                        ##Activation API 
                        for attempt in range(1, GET_API_RETRIES + 1):
                            try:
                                logging.info(f"Attempt {attempt} - URL: {url}")
                                logging.info(
                                    f"url={url}, telegence_payload={telegence_payload!r}, headers={headers}"
                                )
                                resp = requests.post(
                                    url, json=telegence_payload, headers=headers, timeout=60)
                                if resp.status_code == 200:
                                    # Success—no need to retry
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(
                                    f"Attempt {attempt} failed: {result}")
                                time.sleep(RETRY_DELAY)
                        logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} Response Code: {resp.status_code}")
                        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Response TEXT: {resp.text}")
                        success = 200 <= resp.status_code < 300
                        result = resp.text
                        pending_log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_requestid.get(iccid),
                            "log_entry_description": "Update Telegence Subscriber: Telegence API",
                            "request_text": json.dumps(telegence_payload),
                            "has_errors": status == "PENDING",
                            "response_status": "PENDING" if success else "API_Failed",
                            "response_text": json.dumps(result),
                            "error_text": "" if status == "PROCESSED" else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
        
                        if pending_log:
                            database.insert_data(pending_log,"sim_management_bulk_change_log") 
                        status = "PROCESSED" if success else "API_FAILED"
                        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} status is {status}")
                        if success:
                            response_data = resp.json()
                            if isinstance(response_data, list) and response_data:
                                id = response_data[0].get("id")  
                        #connecting carrier Api again to get the subscriber number and sim status
                        if success and id:
                            try:
                                logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Waiting 2 seconds before second API for {iccid}")
                                time.sleep(20)
                                api_url = f"{url}/{id}"
                                api_success = False
                                ##attempting here when status is not found
                                for attempt in range(1, MAX_RETRIES + 1):
                                    logging.info(f"[{iccid}] Poll attempt #{attempt}")
                                    try:
                                        resp = requests.get(api_url, headers=headers, timeout=60)
                                        data_json = resp.json()
                                        logging.info(f"[{iccid}] ###telegence_bc_activate_new_service and {tenant_name} GET response data: {data_json}")

                                        if isinstance(data_json, list) and data_json:
                                            svc = data_json[0].get("service", {})
                                            sim_status = svc.get("status", "")
                                            logging.info(f"[{iccid}] sim_status is {sim_status} ")

                                            ##Based on the sim status will be triggerd
                                            if sim_status == "Rejected":
                                                ##Rejected sim will be automatically stopped
                                                api_success=False
                                                logging.error(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} Service rejected; stopping polling")
                                                break

                                            elif not sim_status:
                                                ##sim is in progress API will be trigged after 2 mins
                                                api_success=False
                                                logging.info(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} Empty status, retry in 2 mins")
                                                time.sleep(60)
                                                continue

                                            elif sim_status == "Active":
                                                ##sim got Activated 
                                                subscriber_number = svc.get("subscriberNumber")
                                                billing_account_id = data_json[0].get("billingAccount", {}).get("id")
                                                char_map = {c["name"]: c["value"] for c in svc.get("serviceCharacteristic", [])}
                                                imei_api = char_map.get("IMEI")
                                                if subscriber_number and billing_account_id and imei_api:
                                                    api_success = True
                                                    if "display_name" in device_status_data.columns and "id" in device_status_data.columns:
                                                        matches = device_status_data.loc[
                                                            device_status_data["display_name"] == sim_status,
                                                            "id"
                                                        ]
                                                        if not matches.empty:
                                                            device_status_id = matches.iloc[0]
                                                            device_status_id=int(device_status_id)
                                                    logging.info(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} All required data found; stopping polling and device_status_id {device_status_id}")
                                                    break
                                                else:
                                                    logging.info(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} Active but missing fields, retry in 2 mins")
                                                    time.sleep(60)
                                                    continue
                                            else:
                                                logging.info(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} Active but missing fields, retry in 2 mins")
                                                time.sleep(60)
                                                continue
                                        else:
                                            logging.info(f"[{iccid}] ###telegence_bc_activate_new_service and {tenant_name} Unexpected GET response; retry in 2 mins")
                                            time.sleep(60)

                                    except Exception as e:
                                        logging.warning(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} GET attempt {attempt} failed: {e}")
                                        time.sleep(60)
                                ##based on the api_success or failure the API will be triggered
                                if api_success:
                                    status = "PROCESSED"
                                    success = True
                                else:
                                    status = "API_FAILED"
                                    success = False
                            except Exception as e:
                                success = False
                                status = "API_EXCEPTION"
                                logging.error(f"###telegence_bc_activate_new_service and {tenant_name} Second API failed for {iccid}: {e}")

                        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} api_result for {iccid}: {data_json}")
                        
                        if success and subscriber_number:
                            update_data = {
                            "status": status,
                            "has_errors": False,
                            "is_processed": True,
                            "processed_date": now,
                            "subscriber_number":subscriber_number,
                            "status_details":json.dumps(data_json) 
                            }
                        else:
                            update_data = {
                            "status": status,
                            "has_errors": True,
                            "is_processed": True,
                            "processed_date": now,
                            "status_details":json.dumps(data_json) 
                            }
                        try:
                            if success and subscriber_number:
                                update_data['status_details']=json.dumps(data_json)
                            else:
                                error_msg = data_json[0].get("service", {}).get("error", "")
                                update_data['status_details'] = f"Telegence: Device Activation rejected for SIM: {iccid} — {error_msg}"
                        except Exception as e:
                            logging.exception(f"###telegence_bc_activate_new_service and {tenant_name} Exception occured while storing status details{e}")
                        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} update_data is {update_data}")
                    #update the request status
                        database.update_dict(
                        "sim_management_bulk_change_request",
                        update_data,
                        and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id},
                        )
                       
                        logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} success in activation {success} and  subscribernumber {subscriber_number}")
                        # Only update inventory if API succeeded
                        if success and subscriber_number:
                            try:
                                successful_iccids.append(iccid)
                            except Exception as e:
                                logging.exception(f"Failed to append the iccid")
                            inventory_data['date_activated']=now
                            inventory_data['modified_by']=created_by
                            if tenant_id and parent_tenant_id:
                                # Insert for parent tenant
                                parent_inventory = inventory_data.copy()
                                parent_inventory.update({
                                    "iccid": iccid,
                                    "msisdn": subscriber_number,
                                    "imei": imei_api,
                                    "billing_account_number": billing_account_id,
                                    "tenant_id": parent_tenant_id,
                                    "is_active": True,
                                    "is_deleted":False,
                                    "tenant_is_active":True,
                                    "tenant_is_deleted":False,
                                    "service_provider_is_active":True,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "service_provider_display_name": service_provider,
                                    "sim_status": sim_status,
                                    "service_provider_id":service_provider_id,
                                    "device_status_id":device_status_id,
                                    "foundation_account_number":foundation_account_number
                                })
                                database.insert_data(parent_inventory, "sim_management_inventory")
                            ###insert for actual tenanta
                            inventory_data.update({
                                    "iccid": iccid,
                                        "msisdn": subscriber_number,
                                        "imei": imei_api,
                                        "billing_account_number": billing_account_id,
                                        "tenant_id": tenant_id,
                                        "is_active": True,
                                        "is_deleted":False,
                                        "tenant_is_active":True,
                                        "tenant_is_deleted":False,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "service_provider_display_name": service_provider,                               
                                        "sim_status": sim_status,
                                        "service_provider_id":service_provider_id,
                                        "device_status_id":device_status_id,
                                        "foundation_account_number":foundation_account_number,
                                        "service_provider_is_active":True
                                    
                                    })
                            database.insert_data(inventory_data,"sim_management_inventory")
                        # Constructing the log entry for GET API
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_requestid.get(iccid),
                            "log_entry_description": "Update Telegence Subscriber: Telegence API",
                            "request_text": json.dumps(telegence_payload),
                            "has_errors": status == "API_FAILED",
                            "response_status": "PROCESSED" if success else "API_Failed",
                            "response_text":json.dumps(data_json) if data_json else "Unable to Process the Activation",
                            "error_text": "" ,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
            
                        if log:
                            database.insert_data(log,"sim_management_bulk_change_log") 
                        logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} current iccid processing is : {iccid}")
                        return iccid
                    futures[executor.submit(task)] = current_iccid
                # Then process results as they complete
                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} removing the iccid {iccid}")
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"###telegence_bc_activate_new_service and {tenant_name} Error processing ICCID")


        # After processing a batch, pause before the next batch if more ICCIDs remain 
        if interval and i + batch_size < len(iccids):
            time.sleep(interval)
        live_progress_percentage_tracker(database, bulk_change_id,80)
        #preare the payload for history table
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": successful_iccids,
                                    "msisdns":[],
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        # Call the history table API
        try:
            if successful_iccids:
             logging.info(f"### telegence_bc_activate_new_service and {tenant_name} sync call has started for history table")
             threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_activate_new_service and {tenant_name} Exception in thread: {e}") 
      
        #  Update the status of the bulk change request
        logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} bulk_change_id{bulk_change_id} and time is now{now}")
        database.update_dict(
                'sim_management_bulk_change',
                {
                    "status": "PROCESSED",
                    "processed_date": now
                },
                {'id': bulk_change_id}
            )
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} proccessed %d iccids,%d remaining",len(iccids) - len(remaing_iccids), len(remaing_iccids))
        
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Inserted %d log entries for bulk change request", len(log_entries))
        logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} Bulk Change Completed in %.1fs", time.time() - start_time)
        response={"flag": True, "processed": len(iccids)-len(remaing_iccids), "remaining": len(remaing_iccids),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_ids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        '''
        SYNC CALL for Activate New Service
        '''
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API for 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'###telegence_bc_activate_new_service and {tenant_name} sync call has started for telegence_bc_activate_new_service')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f'###telegence_bc_activate_new_service and {tenant_name} sync call has ended')
        except Exception as e:
            logging.exception(f"Exception in thread is {e}")
        # Return success
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Total time taken for processing: %s seconds", time.time() - start_time)
        ##auditing the sync completion
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        live_progress_percentage_tracker(database, bulk_change_id,95)
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_ids,
            "bulk_change_id": bulk_change_id
        }

        # Attempt to audit the action
        try:
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_activate_new_service",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for  devices.{bulk_change_id}",
                "request_received_at": now,
            }
        
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        '''
        Assign Customer logic to assign the customers when activation is happened
        '''
        ##function to call the assign customer logic
        try:
           logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Successfull iccids are {successful_iccids}")
           # Check if customer_id and customer_name are present
           if customer_id and customer_name and successful_iccids:
                logging.info(f"### Calling assign customer logic for bulk change request: {bulk_change_id} and successful iccids {successful_iccids}")
                telegence_bulk_change_assign_customer_wrapper(data,database,common_utils_database,now,successful_iccids)
                logging.info(f"### Assign customer logic completed for bulk change request: {bulk_change_id}")
        except Exception as e:
            logging.exception(f" ###telegence_bc_activate_new_service and {tenant_name} Exception while doing the assign customer logic")
        ##return the response
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"###telegence_bc_activate_new_service and {tenant_name} Error during bulk change processing: %s", str(e))
        error_message = f"###telegence_bc_activate_new_service and {tenant_name} during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": iccids,
            "invalid_msisdns": invalid_ids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
 
        return response
    
def telegence_bulk_change_assign_customer_wrapper(data, database, common_utils_database, now,successful_iccids):
    
    """
    Handles the 'Assign Customer' bulk change operation by preparing request data 
    and invoking the SIM management API to sync changes.

    Args:
        data (dict): Input data for the operation (may include context or parameters).
        database (object): Database connection or handler object.
        common_utils_database (module/object): Common utilities for database operations.
        bulk_change_id_activate_new (str/int): Identifier for the bulk change operation context.
        access_token (str): Access token used for authentication with the API.
        iccids (list): List of ICCIDs to process in the bulk change.
        role_name (str): Role of the user initiating the request.
        tenant_name (str): Name of the tenant performing the operation.

    Process:
        - Constructs a request payload including change data and metadata.
        - Logs each step and relevant values for observability.
        - Makes a POST request to the SIM management API for bulk update.
        - Parses the response and handles any errors gracefully.
        - Extracts and logs the `bulk_change_id` from the API response.

    Returns:
        None. (Side-effects include API calls and logs; `bulk_change_id` is printed and logged.)
    """
    logging.info(f"Request Data for wrapper function is {data}")
    iccids = data.get("iccids", [])
    bulk_change_id_new = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    username= data.get("username", "")
    role_name = data.get("role_name", "")
    tenant_name = data.get("tenant_name", "")
    access_token=data.get("access_token", "")
    customer_id= data.get("customer_id", "")
    customer_name= data.get("customer_name", "")
    effective_date = data.get("effective_date", None)
    request_received_at = data.get("request_received_at","")
    request_data={}
    changed_data={}
    tenant_database=data.get('db_name','')
    logging.info(f"API call flag is false {bulk_change_id_new}")
    request_data['tenant_name']=tenant_name
    request_data["path"]="/update_bulk_change_data"
    request_data["switch_user_2_0"]=True
    request_data["role_name"] = role_name
    request_data["request_received_at"]=request_received_at
    request_data["access_token"] = access_token
    request_data["bulk_change_20"] = True
    request_data["db_name"]=tenant_database
    request_data["sessionID"]=None
    logging.info(f"adding service provider {service_provider}")
    request_data["service_provider"]=service_provider

    request_data["change_type"]="Assign Customer"
    request_data["created_by"]=created_by
    request_data["iccids"]=successful_iccids
    changed_data["Number"]=""
    changed_data["ICCID"]=""
    changed_data["CreateRevService"]=False
    changed_data["IntegrationAuthenticationId"]=""
    changed_data["AddCarrierRatePlan"]=False
    changed_data["CarrierRatePlan"]=None
    changed_data["CommPlan"]=""
    changed_data["UseAgentAccount"]=False
    changed_data["JasperDeviceID"]=""
    changed_data["SiteId"]=None
    changed_data["AddCustomerRatePlan"]=False
    changed_data["CustomerRatePlan"]=None
    changed_data["CustomerRatePool"]=None
    changed_data["DeviceId"]=None
    changed_data["RevCustomerId"]=f'{customer_name} -- {customer_id}'
    changed_data["ProviderId"]=""
    changed_data["ServiceTypeId"]=""
    changed_data["RevProductId"]=[]
    changed_data["RevPackageId"]=""
    changed_data["RateList"]=[]
    changed_data["Prorate"]=False
    changed_data["useCarrierActivation"]=False
    changed_data["Description"]=""
    changed_data["EffectiveDate"]=effective_date
    changed_data["ActivatedDate"]=None
    changed_data["UsagePlanGroupId"]=None
    request_data["changed_data"]=changed_data
    # request_data=json.dumps(request_data)
    logging.info(f"final request data got is {bulk_change_id_new} {request_data}")

    try:
        try:
            '''
            This code is used to call the run db script using API Call so that the sync will be called
            '''
            fn_call=False
            # Prepare the API URL and payload
            api_url=os.environ["SIMMANAGEMENTREQUESTURL"]
            api_payload = {"data": request_data}
            logging.info(f"### request data here is {request_data}")
            logging.info(f"### BULK Change  API Payload is :{api_payload}")

            response = requests.post(api_url, json=api_payload)
            response_json = response.json()
            # Parse the inner body string (if needed)
            body = response_json.get("body")
            if isinstance(body, str):
                response_json = json.loads(body)
            else:
                response_json = body  # if it's already a dict

            logging.info(f"### BULK Change  API response: {response_json}")

            if response.status_code in (200, 504):
                current_timestamp = now
                logging.info(f" Update bulk Change data API call successful. Data sync completed at {current_timestamp}")
            else:
                logging.error(f"Update bulk Change data API sync call failed with status code: {response.status_code} and sync message is: {response.text}")

            # Extract bulk_change_id
            bulk_change_id = response_json.get("bulkchange_id", {}).get("id")
            request_data=response_json.get('data')
        except Exception as exception:
            logging.error(f"###run_db_script Error occurred while calling the sync API: {exception}")
            bulk_change_id = None
            request_data={}
        # Check if bulk_change_id is found in the response
        if bulk_change_id is None:
            fn_call=False
            logging.info(f"bulk_change_id not found in response.This is some issue in the update bulk change data")
        else:
            fn_call=True
            logging.info(f"bulk_change_id: {bulk_change_id}")
        logging.info(f"update_bulk_change_data response is {bulk_change_id} and bulk change if for assign customer is {bulk_change_id}")
        logging.info(f"return dict is {bulk_change_id}")
        # If bulk_change_id is found, proceed with the API call
        if fn_call:
            try:
                # Prepare the API URL and payload for the bulk change processor for assign customer
                api_url = os.environ["BULKCHANGEREQUESTURL"]
                
                api_payload = {
                            "data": {
                            "bulk_change_id": bulk_change_id,
                            "db_name": tenant_database,
                            "path": "/bulk_change_processor",
                            "request_received_at": now,
                            "role_name": role_name,
                            "tenant_name": tenant_name,
                            "service_provider": service_provider,
                            "iccids": successful_iccids,
                            "change_type": "Assign Customer",
                            "access_token": access_token,

                            }
                        }
                #call the API to process the bulk change request
                response = requests.post(api_url, json=api_payload)
                response_json = response.json()
                logging.info(f"bulk Change processor API response: {response_json}")
                if response.status_code in (200, 504):
                    current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    logging.info(f" bulk Change proccessor data API call successful with response{response.text}. Data proccess completed at {current_timestamp}")
                else:
                    logging.error(f"bulk Change proccessor data API  call failed with status code: {response.status_code} and  message is: {response.text}")

            except Exception as e:
                logging.error(f"Error in telegence_bc_assign_customer_wrapper: {e}")
            response = {
                "flag": True,
                "message": response.text,
                "iccids": iccids,
                "bulk_change_id": bulk_change_id
            }
        try:
            end_time = time.time()
            time_consumed = end_time - now 
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_assign_customer_wrapper",
                "created_by": username,
                "status": response,
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for  devices.{bulk_change_id}",
                "request_received_at": now,
            }
        
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging failed: {e}")
             
    except Exception as e:
        logging.error(f"Error in update_bulk_change_data: {e}")
        logging.exception(f"### Error during bulk change processing: %s", str(e))
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": iccids,
            "bulk_change_id": bulk_change_id
        }
       
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
        return response
    
    

## Assign customer function
def telegence_bc_assign_customer(data):
    """Assign a customer to the selected devices or services.
    This function processes a list of iccids and assign a customer account with the iccids in the Telegence system.
    It handles bulk requests, updates the database, and logs the results.
    Args:
        data (dict): Input data containing the following keys:
            - ICCIDs (list): List of ICCIDs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Telegence API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
        context (dict): Lambda context object containing execution details.
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    
    """
    logging.info(f"### Received data for assign customer: %s", data)
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Initialize for log entries
    log_entries = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_assign_customer and {tenant_name} time is {now}")

    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### telegence_bc_assign_customer and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,20)
    except Exception as e:
        logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
            logging.info(f"### telegence_bc_assign_customer and {tenant_name} Carrier API details fetched successfully")

        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}


        # Fetch bulk change rows
       
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},#iccid
            ["id", "iccid", "change_request"]
        )
        # Validate input data 
       
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_assign_customer",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
                return response
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        #Extract relevant fields from the change request 
        customer_rate_plan_id=change_request_json.get("CustomerRatePlan","")
        customer_rate_pool_id=change_request_json.get("CustomerRatePool","")
        rev_customer_id=change_request_json.get("RevCustomerId","")
        service_type_id=change_request_json.get("ServiceTypeId","")
        effective_date=change_request_json.get("EffectiveDate","")
        activated_date=change_request_json.get("ActivatedDate","")
        usageplangroupid=change_request_json.get("UsagePlanGroupId","")
        revproductidlist=change_request_json.get("RevProductIdList",[0])
        product_id = revproductidlist[0] if revproductidlist else None
        provider_id=change_request_json.get("ProviderId","")
        number=change_request_json.get("Number","")
        integration_authentication_id=change_request_json.get("IntegrationAuthenticationId","")
        device_id=change_request_json.get("DeviceId")
        description=change_request_json.get("Description","")
        rate= change_request_json.get("RateList", [0])
        revpackageid=change_request_json.get("RevPackageId", None)
        # Initialize variables for customer and rate plan details
        rate_plan_id = None
        customer_rate_plan = None
        customer_rate_pool = None
        rev_customer = None
        provider_data=pd.DataFrame()
        rev_customer_uuid = None
        customer_id=None
        customer_name=None
        customer_data=pd.DataFrame()
       # Fetch customer and rate plan details from the database
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name"]
            )
            if not rate_plan_data.empty:
                rate_plan_id = rate_plan_data["rate_plan_code"].to_list()[0]
                customer_rate_plan=rate_plan_data["rate_plan_name"].to_list()[0]
        if customer_rate_pool_id:
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool = rate_pool_data["name"].to_list()[0]
        if rev_customer_id:
            rev_data = database.get_data(
                "revcustomer",
                {"rev_customer_id": rev_customer_id, "is_active": True},
                ["customer_name", "id"]
            )
            if not rev_data.empty:
                rev_customer = rev_data["customer_name"].to_list()[0]
                rev_customer_uuid = rev_data["id"].to_list()[0]
        if rev_customer:
            customer_data=database.get_data(
                "customers",
                {"customer_name":rev_customer,"is_active": True},
                ["id","customer_name"]
            )
        if not customer_data.empty:
            customer_id=customer_data["id"].to_list()[0]
            customer_name=customer_data["customer_name"].to_list()[0]
        if provider_id:
            provider_data = database.get_data(
                "rev_provider",
                {"provider_id": provider_id, "is_active": True,"integration_authentication_id": integration_authentication_id},
                ["id"]
            )
            if not provider_data.empty:
                rev_provider_id = provider_data["id"].to_list()[0] 
       # Prepare update fields for the database
        update_fields = {"customer_rate_plan_id": customer_rate_plan_id,"customer_rate_plan_name": customer_rate_plan}
        if customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id
            update_fields["customer_rate_pool_name"] = customer_rate_pool
        if rev_customer_id:
            update_fields["rev_customer_id"] = rev_customer_id
            update_fields["rev_customer_name"] = rev_customer
        if effective_date:
            update_fields["effective_date"] = effective_date
        if integration_authentication_id:
            update_fields["account_number_integration_authentication_id"] = integration_authentication_id
        # if device_id:
        #     update_fields["device_id"] = device_id
        update_fields["customer_id"] = customer_id if customer_id is not None else None
        update_fields["customer_name"] = customer_name if customer_name is not None else None
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        iccid_to_request_id = dict(zip(bulk_requests.iccid, bulk_requests.id))
        iccid_to_changerequest = dict(zip(bulk_requests.iccid, bulk_requests.change_request))
        ## Prepare headers for API call
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
        }
        # Prepare data for database insertion
        product_data={}
        if revpackageid:
            product_data["package_id"] = revpackageid
        if rate:
           product_data["rate"] = Decimal(str(rate[0]))
        if product_id:
            product_data["product_id"] = product_id
        # Validate iccids
        remaining = iccids.copy()
        logs = []
        successful_iccids = []
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"###telegence_bc_assign_customer and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        ## Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process each batch of ICCIDs
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # craete a dictionary to hold futures
                futures = {}
                logging.info(f"###telegence_bc_assign_customer and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")
                for iccid in batch:
                    url = f"{carrier_api_url}"
                    logging.info(f"###telegence_bc_assign_customer and {tenant_name} Processing ICCID: {iccid}")
                    payload_str = iccid_to_changerequest.get(iccid)
                    logging.info(f"###telegence_bc_assign_customer and {tenant_name} Payload for ICCID {iccid}: {payload_str}")
                    request_payload = json.loads(payload_str)
                    #extract the create rev service flag
                    rev_service = request_payload.get("CreateRevService", False)
                    # Build payloads for all APIs
                    rev_api_payload = {
                        "customer_id": rev_customer_id,
                        "provider_id": provider_id,
                        "service_type_id": service_type_id,
                        "number": number,
                        "activated_date": activated_date,
                    }
                    product_api_payload={
                        "CustomerId": rev_customer_id,
                        "service_type_id": service_type_id,
                        "number": number,
                        "effective_date": effective_date,
                        "activated_date": activated_date,
                        "product_id": product_id,
                        }
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    #task function
                    def task(iccid=iccid, rev_service=rev_service):
                        """ 1. If CreateRevService is True:
                            - Step 1: Call API to create RevService (POST with retries)
                            - Step 2: On success, extract RevService ID from response
                            - Step 3: Use RevService ID to create Service Product (POST)
                        
                           2. If CreateRevService is False:
                            - Skip RevService creation and directly insert into DB"""
                        success = False
                        result = ""
                        status = "API_FAILED"
                        id = None
                        productid = None
                        try:
                            if rev_service:
                                # Step 1:  First API Call to create the revservice
                                for attempt in range(1, MAX_RETRIES + 1):
                                    try:
                                        logging.info(f"###telegence_bc_assign_customer and {tenant_name} Attempt {attempt} - URL: {url}, Payload: {rev_api_payload}")
                                        
                                        resp = requests.post(url, json=rev_api_payload, headers=headers, timeout=60)
                                        success = 200 <= resp.status_code < 300
                                        result = resp.text
                                        logging.info(f"###telegence_bc_assign_customer and {tenant_name} Response Code: {resp.status_code}")
                                        logging.info(f"###telegence_bc_assign_customer and {tenant_name} Response Text: {result}")
                                        status = "PROCESSED" if success else "API_Failed"
                                        if success:
                                            try:
                                                response_data = resp.json()
                                                id = response_data.get("id")
                                                successful_iccids.append(iccid)
                                            except Exception:
                                                id = None
                                            break
                                    except Exception as e:
                                        result = str(e)
                                        status = "API_EXCEPTION"
                                        logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Exception in API call: {e}")
                                        time.sleep(RETRY_DELAY) 
                                if success:
                                    update_data = {
                                        "status": status,
                                        "has_errors": False,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result    
                                    }
                                else:
                                    update_data = {
                                        "status": status,
                                        "has_errors": True,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result
                                    }  
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    update_data,
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"iccid": iccids},
                                    )             
                                if success:  
                                    #inserting values in rev service 
                                    rev_data={
                                    "rev_customer_id":rev_customer_uuid,
                                    "number":number,
                                    "rev_service_id":id,
                                    "activated_date":activated_date,
                                    "is_active":True,
                                    "integration_authentication_id":integration_authentication_id,
                                    "rev_provider_id":rev_provider_id,
                                    "rev_service_type_id":service_type_id
                                    }
                                    rev_insert_id=database.insert_data(rev_data,"rev_service")
                                    if rev_insert_id:
                                        update_fields["rev_service_id"]=rev_insert_id
                                    #updating inventory table
                                    rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                # Inserting logs based on api result
                                rev_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Rev.io API",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": status == "PROCESSED",
                                        "response_status": "PROCESSED" if success else "API_Failed",
                                        "response_text": result,
                                        "error_text": "" if status == "PROCESSED" else result,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                database.insert_data(rev_log,"sim_management_bulk_change_log") 
                                logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserting log for rev service creation: {rev_log}")
                                #inserting logs after updating inventory table
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors":False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK" ,
                                        "error_text": "",
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                                # Step 2:  Second API Call
                                logging.info(f"### telegence_bc_assign_customer and {tenant_name} Creating Rev.io Service Product for ICCID: {iccid} with ID: {id}")
                                if id:
                                    second_url = f"{alternative_api_url}"
                                    #constracting payload 
                                    product_api_payload["service_id"]=id
                                    logging.info(f"### telegence_bc_assign_customer and {tenant_name} Product API Payload: {product_api_payload}, URL: {second_url}")

                                    for attempt in range(1, MAX_RETRIES + 1):
                                        try:
                                            get_resp = requests.post(second_url,json=product_api_payload, headers=headers, timeout=60)
                                            api_success = 200 <= get_resp.status_code < 300
                                            api_result = get_resp.text
                                            logging.info(f"### telegence_bc_assign_customer and {tenant_name} Response Code: {get_resp.status_code}")
                                            logging.info(f"### telegence_bc_assign_customer and {tenant_name} Response Text: {api_result}")
                                            status = "PROCESSED" if api_success else "API_FAILED"
                                            if api_success:
                                                response_data = get_resp.json()
                                                productid = response_data.get("id")
                                                break
                                        except Exception as e:
                                            result = str(e)
                                            status = "API_EXCEPTION"
                                            time.sleep(RETRY_DELAY)
                                    if api_success:
                                        product_data.update({
                                               "service_product_id": productid,  
                                                "customer_id":rev_customer_id,  
                                                "service_id": id,  
                                                "description":description,  
                                                "activated_date": activated_date,     
                                                "status": "ACTIVE",  
                                                "created_by": created_by,  
                                                "created_date": now,  
                                                "is_active": True,  
                                                "is_deleted": False,  
                                                "integration_authentication_id": integration_authentication_id,
                                        })
                                        #inserting values into revservice product table 
                                        database.insert_data(product_data,"rev_service_product")
                                        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserting log for rev service product creation: {product_data}")
                                        rev_service_log=database.update_dict(
                                            "sim_management_inventory",update_fields,
                                            and_conditions={"tenant_id":tenant_id,"is_active": True},
                                            in_conditions={"iccid": [iccid]}
                                        )
                                    #constracting logs 
                                    log = {
                                            "bulk_change_id": bulk_change_id,
                                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                            "log_entry_description": "Create Rev.io Service Product: Rev.io API",
                                            "request_text": json.dumps(product_api_payload),
                                            "has_errors": status == "API_FAILED",
                                            "response_status": "PROCESSED" if api_success else "API_Failed",
                                            "response_text": api_result,
                                            "error_text": "" if status == "PROCESSED" else result,
                                            "processed_date": now,
                                            "processed_by": created_by,
                                            "created_by": created_by,
                                            "created_date": now,
                                            "is_deleted": False,
                                            "is_active": True
                                        }
                    
                                    if log:
                                        database.insert_data(log,"sim_management_bulk_change_log")
                                    logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserting log for product creation: {log}") 
                                    if rev_service_log:
                                        data_log = {
                                            "bulk_change_id": bulk_change_id,
                                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                            "log_entry_description": "Create Rev.io Service: Update AMOP",
                                            "request_text": json.dumps(product_api_payload),
                                            "has_errors":False,
                                            "response_status": "PROCESSED",
                                            "response_text": "OK" ,
                                            "error_text": "",
                                            "processed_date": now,
                                            "processed_by": created_by,
                                            "created_by": created_by,
                                            "created_date": now,
                                            "is_deleted": False,
                                            "is_active": True
                                        }
                                        database.insert_data(data_log,"sim_management_bulk_change_log")
                                        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                            else:
                                #if createrevservice flag false then directly updating values into table
                                rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                successful_iccids.append(iccid)
                                database.update_dict(
                                        "sim_management_bulk_change_request",
                                        {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK" },
                                        and_conditions={"bulk_change_id": bulk_change_id},
                                        in_conditions={"iccid": iccids},
                                    )

                                #constracting logs
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK",
                                        "error_text": "" ,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")

                        except Exception as e:
                            logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Unexpected error for ICCID {iccid}: {str(e)}")
                        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Completed processing ICCID: {iccid}, Success: {success}, ID: {id}, Product ID: {productid}")
                        return iccid
                    futures[executor.submit(task)] = iccid
                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.error(f"### telegence_bc_assign_customer and {tenant_name} Error processing iccid: {e}")
        if interval and i + batch_size < len(iccids):
            time.sleep(interval)
       
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        #logging.info("Processed %d iccids, %d remaining", len(iccids) - len(remaining), len(remaining))
        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Processed %d iccids, %d remaining", len(iccids) - len(remaining), len(remaining))
        # Check for any invalid ICCIDs
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": successful_iccids,
                                    "msisdns":[],
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        if effective_date:
            payload_history_table["data"]["effective_date"] = effective_date
        # Call the history table update API
        try:
            if successful_iccids:
                logging.info(f"### telegence_bc_assign_customer and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Exception in thread: {e}") 
        live_progress_percentage_tracker(database, bulk_change_id,70)
        if invalid_iccids:
            logging.info(f"### telegence_bc_assign_customer and {tenant_name} Invalid iccids found: {invalid_iccids}")
            # Log invalid IDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Assign customer ",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","is_processed":True,"has_errors":True,"processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids},
            )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserted %d log entries for bulk change request", len(log_entries))
        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Bulk Change Completed in %.1fs", time.time() - start_time)
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #below syncs url is used to sync the 1.0 inventory tables 
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### telegence_bc_assign_customer and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### telegence_bc_assign_customer and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        
        live_progress_percentage_tracker(database, bulk_change_id,95)
       
        # Attempt to audit the action
        try:
            audit_data_user_actions = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for Assign customer for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.warning(f"### telegence_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Error during bulk change processing: {e}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_msisdns": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Logging error to DB failed: {e}")
 
        return response
    
def telegence_bc_update_feature(data):
    """ Update Telegence update Features
    This function processes a bulk change request to update Telegence  features.
    It validates inputs, connects to the database, fetches carrier API details,
    processes each MSISDN in batches, and updates the database accordingly.
    """
    logging.info(f"###telegence_bc_update_feature Request Data Recieved is: {data}")
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    overwrite=data.get("overwrite",False)
    ## Extracting fields from changed_data
    log_entries = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # Basic validation
    if not bulk_change_id:
        logging.error("Missing required fields: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    live_progress_percentage_tracker(database, bulk_change_id,10)
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
    except Exception as e:
        logging.exception(f"### Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            logging.info(f"### Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        live_progress_percentage_tracker(database, bulk_change_id,20)
        logging.info(f'### carrier_api_url: {carrier_api_url}, carrier_limits: {carrier_limits}')
        # Fetch bulk change rows
        add_codes = []
        remove_codes=[]
        successful_ids = []
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
           if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_update_feature",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_update_feature and {tenant_name} Audit logging failed: {e}")
                return response
        logging.info(f'###telegence_bc_update_feature change_request_json is {change_request_json}')
        for item in change_request_json.get("serviceCharacteristic", []):
            if item.get("name") == "addOfferingCode":
                add_codes.extend(item.get("value", []))
            elif item.get("name") == "removeOfferingCode":
                remove_codes.extend(item.get("value", []))
        logging.info(f"###telegence_bc_update_feature offering codes added are {add_codes}")
        logging.info(f"###telegence_bc_update_feature offering codes removed are {remove_codes}")
        ## Prepare headers for API call
        headers = {
            "app-id": app_id,
            "app-secret": app_secret,
            "page-size": "100",
            "current-page": "0",
            "Content-Type": "application/json"
        }

        # Validate MSISDNs
        remaining = msisdns.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        ##adding validation to not add more parallel requests
        if parallel_requests>10:
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"###telegence_bc_update_feature Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of MSISDNs
                batch = msisdns[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each MSISDN in the batch
                logging.info(f"###telegence_bc_update_feature Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for msisdn in batch:
                    # Prepare the URL and payload for the API call
                    url = f"{carrier_api_url}/{msisdn}"
                    def task(msisdn=msisdn, url=url, add_codes=add_codes,remove_codes=remove_codes):  
                        success = False
                        result = ""
                        status = "API_FAILED"
                        ###overwrite function to fetch the offering codes and then removing them 
                        if overwrite:
                            logging.info(f"###telegence_bc_update_feature overwrite feature initiated for msisdn:{msisdn}")
                            overwrite_codes = []
                            get_response = requests.get(url, headers=headers, timeout=60)
                            logging.info(f"###telegence_bc_update_feature Get Response for overwrite {get_response.status_code} and {get_response.text}")
                            if get_response.status_code == 200:
                                data = get_response.json()
                                # Extract serviceCharacteristic list
                                svc_chars = data.get("serviceCharacteristic", [])
                                # Use regex to find names that match offeringCode followed by a digit
                                pattern = re.compile(r"^offeringCode\d+$")
                                for item in svc_chars:
                                    name = item.get("name", "")
                                    if pattern.match(name):
                                        value = item.get("value")
                                        if value:
                                            overwrite_codes.append(value)
                                logging.info(f"###telegence_bc_update_feature overwrite codes are {overwrite}")
                                ##removing the offering codes one by one
                                for offercode in overwrite_codes:
                                    payload = {
                                        "serviceCharacteristic": [
                                            {
                                                "name": "removeOfferingCode",
                                                "value": offercode
                                            }
                                        ]
                                    }
                                    for attempt in range(1, MAX_RETRIES + 1):
                                        try:
                                            logging.info(f"Attempt {attempt} - URL: {url}")
                                            resp = requests.patch(
                                                url, json=payload, headers=headers, timeout=60)
                                            logging.info(f"###telegence_bc_update_feature Response Code for remove API in overwrite feature for offercode{offercode}: {resp.status_code}")
                                            success = 200 <= resp.status_code < 300
                                            result = resp.text
                                            status = "PROCESSED" if success else "API_FAILED"
                                            if success:
                                                break
                                        except Exception as e:
                                            result = str(e)
                                            logging.warning(
                                                f"Attempt {attempt} failed: {result}")
                                            time.sleep(RETRY_DELAY)
                                    ##updating inventory block
                                    try:
                                        if success:
                                            successful_ids.append(msisdn)
                                            update_telegence_features(database, msisdn, offercode, "remove")
                                            logging.info("Successfully removed offering code %s for msisdn %s", offercode, msisdn)
                                    except Exception as e:
                                        logging.exception("Failed to  remove offering code %s for msisdn %s", offercode, msisdn)
                                    # Constructing the log entry
                                    remove_feature_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": f"Update Telegence Subscriber: Telegence API OverWrite Feature Code:{offercode}",
                                    "request_text": json.dumps(payload),
                                    "has_errors": status == "API_FAILED",
                                    "response_status": "PROCESSED" if success else "API_Failed",
                                    "response_text": result,
                                    "error_text": "" if status == "PROCESSED" else result,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                    }
                                    ##inserting the remove feature logs
                                    if remove_feature_log:
                                        database.insert_data(remove_feature_log,"sim_management_bulk_change_log")
                            else:
                                    logging.info("Sim Not Found or error response")
                                    # Constructing the log entry
                                    get_response_fail_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                        "log_entry_description": "Update Telegence Subscriber: OverWrite Feature fetch failed",
                                        "request_text": None,
                                        "has_errors": True,
                                        "response_status": f"GET_FAILED_{get_response.status_code}",
                                        "response_text": get_response.text,
                                        "error_text": get_response.text,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    ##inserting the remove feature logs
                                    if get_response_fail_log:
                                        database.insert_data(get_response_fail_log,"sim_management_bulk_change_log")
                        logging.info(f"###telegence_bc_update_feature feature code addition initiated")

                        ###add feature codes block
                        for offercode in add_codes:
                            ##payload construction for each offering code
                            payload = {
                                "serviceCharacteristic": [
                                    {
                                        "name": "addOfferingCode",
                                        "value": offercode
                                    }
                                ]
                            }
                            ###processing the API
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"Attempt {attempt} - URL: {url}")
                                    resp = requests.patch(
                                        url, json=payload, headers=headers, timeout=60)
                                    logging.info(f"###telegence_bc_update_feature Response Code for addition API for offercode{offercode}: {resp.status_code}")
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    status = "PROCESSED" if success else "API_FAILED"
                                    if success:
                                        break
                                except Exception as e:
                                    result = str(e)
                                    logging.warning(
                                        f"Attempt {attempt} failed: {result}")
                                    time.sleep(RETRY_DELAY)
                            ##updating inventory block
                            try:
                                if success:
                                    successful_ids.append(msisdn)
                                    update_telegence_features(database, msisdn, offercode, "add")
                                    logging.exception("Successfully added offering code %s for msisdn %s", offercode, msisdn)
                            except Exception as e:
                                logging.exception("Failed to add offering code %s for msisdn %s", offercode, msisdn)
                            # Constructing the log entry for
                            add_feature_code_log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                "log_entry_description": f"Update Telegence Subscriber: Telegence API Add Feature Code: {offercode}",
                                "request_text": json.dumps(payload),
                                "has_errors": status == "API_FAILED",
                                "response_status": "PROCESSED" if success else "API_Failed",
                                "response_text": result,
                                "error_text": "" if status == "PROCESSED" else result,
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                                }
                            ###add feature logs
                            if add_feature_code_log:
                                database.insert_data(add_feature_code_log,"sim_management_bulk_change_log")
                        logging.info(f"###telegence_bc_update_feature feature code remove initiated")
                        ##removing the codes
                        for offercode in remove_codes:
                            payload = {
                                "serviceCharacteristic": [
                                    {
                                        "name": "removeOfferingCode",
                                        "value": offercode
                                    }
                                ]
                            }
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"Attempt {attempt} - URL: {url}")
                                    resp = requests.patch(
                                        url, json=payload, headers=headers, timeout=60)
                                    logging.info(f"###telegence_bc_update_feature Response Code for remove API for offercode{offercode}: {resp.status_code}")
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    status = "PROCESSED" if success else "API_FAILED"
                                    if success:
                                        break
                                except Exception as e:
                                    result = str(e)
                                    logging.warning(
                                        f"Attempt {attempt} failed: {result}")
                                    time.sleep(RETRY_DELAY)
                            ##updating inventory block
                            try:
                                if success:
                                    update_telegence_features(database, msisdn, offercode, "remove")
                                    logging.info("Successfully removed offering code %s for msisdn %s", offercode, msisdn)
                            except Exception as e:
                                logging.exception("Failed to remove offering code %s for msisdn %s", offercode, msisdn)
                            # Constructing the log entry
                            remove_feature_log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                            "log_entry_description": f"Update Telegence Subscriber: Telegence API Remove Feature Code:{offercode}",
                            "request_text": json.dumps(payload),
                            "has_errors": status == "API_FAILED",
                            "response_status": "PROCESSED" if success else "API_Failed",
                            "response_text": result,
                            "error_text": "" if status == "PROCESSED" else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                            }
                            ##inserting the remove feature logs
                            if remove_feature_log:
                                database.insert_data(remove_feature_log,"sim_management_bulk_change_log") 
                        
                        update_data = {
                            "status": "PROCESSED",
                            "has_errors": False,
                            "is_processed": True,
                            "processed_date": now,
                            "status_details":result
                        }
                        #update the request status
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id},
                            )
                        return msisdn
                    
                    # Submit the task to the executor
                    logging.info(f"Submitting task for MSISDN: {msisdn}")
                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"Error processing MSISDN")     
        if interval and i + batch_size < len(msisdns):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Update the bulk change request status   
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": [],
                                    "msisdns":successful_ids,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        # Call the history table update API
        try:
            if successful_ids:
                logging.info(f"### telegence_bc_update_feature and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_update_feature and {tenant_name} Exception in thread: {e}") 
        logging.info("Processed %d MSISDNs, %d remaining", len(msisdns) - len(remaining), len(remaining))
        ## Handle invalid MSISDNs
        if invalid_ids:
            logging.info(f"### Invalid MSISDNs found: {invalid_ids}")
            # Log invalid ICCIDs
            for request_id in invalid_ids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Update feature codes",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid MSISDN",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_ids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","is_processed":True,"has_errors":True,
                        "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"id": invalid_ids},
            )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### Inserted %d log entries for bulk change request", len(log_entries))
        logging.info("Bulk Change Completed in %.1fs", time.time() - start_time)
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API call for 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info('sync call has started for telegence_bc_update_feature')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,60)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info('sync call has ended')
        except Exception as e:
            logging.exception(f"Exception in thread is {e}")
        # Return success
        logging.info("Bulk change request processed successfully.")
        logging.info("Total time taken for processing: %s seconds", time.time() - start_time)
        ##auditing the sync completion
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_update_feature",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing feature codes for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### Error during bulk change processing: %s", str(e))
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
 
        return response


def update_telegence_features(database, msisdn, offering_code, operation):
    """
    Update a single offering code in the telegence_features field.
    
    :param database: DB helper with get_data and update_dict methods
    :param msisdn: phone number identifier (string)
    :param offering_code: code to add or remove (string)
    :param operation: either 'add' or 'remove'
    """
    try:
        logging.info(f"##telegence_bc_update_feature update query check for offering code {offering_code} and msisdn {msisdn}")
        # Fetch current comma-separated feature string
        row = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "msisdn": msisdn},
            ["telegence_features"]
        )
        features_str = row["telegence_features"].to_list()[0]

        # Convert to list safely: split on commas & trim whitespace :contentReference[oaicite:1]{index=1}
        existing = [x.strip() for x in features_str.split(",")] if features_str else []

        # Modify list based on operation
        if operation == 'add':
            if offering_code not in existing:
                existing.append(offering_code)
        elif operation == 'remove':
            if offering_code in existing:
                existing.remove(offering_code)
        else:
            logging.info("Failed to do the add or remove operations")
        # Rebuild comma-separated string & update DB
        updated_features = ",".join(existing)
        database.update_dict(
            "sim_management_inventory",
            {"telegence_features": updated_features},
            and_conditions={"is_active": True, "msisdn": msisdn}
        )
        logging.info(f"##telegence_bc_update_feature updated offering codes are {updated_features} and msisdn {msisdn}")
        return updated_features
    except Exception as e:
        logging.exception(f"Failed to Add or Remove Feature codes")
        return []


##SYNC API call function
def call_sync_api(api_url, api_payload):
    '''
    Call the sync API with the provided URL and payload.
    This function is designed to be run in a separate thread after a delay.
    '''
    try:
        # Make the API call
        logging.info(f"### Calling sync API: {api_url} with payload: {api_payload}")
        response = requests.post(api_url, json=api_payload)
        if response.status_code == 200:
            logging.info("Bulk Change API call successful. Data sync call successfully done.")
        else:
            logging.error(f"API call failed with status code: {response.status_code}")
    except Exception as e:
        logging.error(f"Error making API call: {e}")

## Function to audit user actions in bulk change processing
def bulk_change_audit_action(data, common_utils_database,action):
    """
    Audits user actions by logging them into the bulk change auditing table.
 
    Args:
        data (dict): Data containing user action details.
        common_utils_database (DB): Database connection object.
 
    Returns:
        None
    """
    service_provider = data.get("service_provider", "")
    change_event_type = data.get("change_type", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
   
    request_received_at = data.get("request_received_at", "") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bulk_change_id = data.get("bulk_change_id", "")
    try:
        audit_data_user_actions = {
                "tenant_name": tenant_name,
                "bulk_change_id":bulk_change_id,
                "serviceprovider": service_provider,
                "change_event_type": change_event_type,
                "action": action,
                "created_date": request_received_at,
                "created_by": username,
               
        }
        common_utils_database.update_audit(audit_data_user_actions, "bulk_change_auditing")
        logging.info("User action audited successfully.")
    except Exception as e:
        logging.exception(f"### Error logging user actions: {e}")


def live_progress_percentage_tracker(database, bulk_change_id,progress_percent):
    """
    Updates the live_progress_percentage column in sim_management_bulk_change_request table.
    """
    try:
        update_fields={}
        #updating sync status when progress percentage reached 100
        if progress_percent==100:
            update_fields["live_progress_percentage"]=progress_percent
            update_fields["progress"]="Sync Completed"
        else:
            update_fields["live_progress_percentage"]=progress_percent

        database.update_dict(
            "sim_management_bulk_change",
            update_fields,
            and_conditions={"id": bulk_change_id}
        )
        return True
    except Exception as e:
        logging.error(f"Error updating live progress: {e}")
        return False



##Refresh API
def telegence_refresh_a_line(data):
    """
    Bulk Refresh using AMLC Telegence API using MSISDN to change_request mapping.

    This function performs the following steps:
        - Extracts necessary metadata and initializes DB connections.
        - Fetches carrier API credentials and limits.
        - Fetches and maps MSISDNs to their payloads and request IDs.
        - Sends PATCH requests to update PPU address using ThreadPoolExecutor with retry logic.
        - Logs responses, updates DB entries, and handles invalid MSISDNs/IDs.
        - Logs audit events before and after processing.

    Args:
        data (dict): Contains keys such as msisdns, bulk_change_id, created_by, service_provider, etc.

    Returns:
        dict: Summary response including processed count and any remaining MSISDNs.
    """
    logging.info(f"### Received data for telegence_refresh_a_line: %s",data)
    start_time = time.time()
    # Extract input metadata
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    invalid_ids = data.get("invalid_ids", [])
    now_dt = datetime.now()
    username= data.get("username", "")
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    integration_id=data.get("integration_id", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    device_status_id=None
    logging.info(f"###def telegence_refresh_a_line and {tenant_name} time is {now}")
    if not bulk_change_id:
        logging.error(f"### telegence_refresh_a_line and {tenant_name} Missing required fields") 
        return {"flag": False, "message": "bulk_change_id is required"}

    # DB Connections
    try:
        database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### telegence_refresh_a_line and{tenant_name} DB connection error:{e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,10)
    try:
        # Fetch carrier API details
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### telegence_refresh_a_line and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}
        
    except Exception as e:
        logging.exception(f"### telegence_refresh_a_line and{tenant_name} Audit logging failed after config fetch: {e}")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    ## Carrier limits
    BATCH_SIZE = carrier_limits.get("batch_size")
    PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
    if PARALLEL_REQUESTS>10:
        logging.info(f"###telegence_refresh_a_line and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
        PARALLEL_REQUESTS=10
    INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
    MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
    RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
    try:
        # Fetch change requests from DB
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        ).rename(columns={"subscriber_number": "msisdn"})
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_refresh_a_line",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_refresh_a_line and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,30)
        try:
            change_request = json.loads(change_request_json)
        except (TypeError, json.JSONDecodeError):
            # handle parsing error
            change_request = {}
        logging.info(f"### telegence_refresh_a_line and{tenant_name} change_request: {change_request}")
        ##fetching the change requests
        msisdn_to_changerequest = dict(zip(bulk_requests.msisdn, bulk_requests.change_request))
        msisdn_to_request_id = dict(zip(bulk_requests.msisdn, bulk_requests.id))

        logging.info(f"### telegence_refresh_a_line and {tenant_name} Fetched {len(bulk_requests)} bulk change requests from the database")
        logs = []
        successful_ids = []
        remaining = list(msisdns)
        rate_plan_data= pd.DataFrame()
        device_status_data = pd.DataFrame()
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        ##batch processing
        device_status_data=database.get_data("device_status",{"integration_id":integration_id},["id","display_name"])
        rate_plan_data = database.get_data(
        "carrier_rate_plan",
        {"is_active": True},
        ["rate_plan_code", "id", "friendly_name"]
        )
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            ## Process each batch of MSISDNs
            for i in range(0, len(msisdns), BATCH_SIZE):
                # Create a batch of MSISDNs
                logging.info(f"### telegence_refresh_a_line and {tenant_name} Processing batch {i // BATCH_SIZE + 1} with {min(BATCH_SIZE, len(msisdns) - i)} MSISDNs")
                batch = msisdns[i:i + BATCH_SIZE]
                futures = {}
                # Prepare payloads and URLs for each MSISDN in the batch
                logging.info(f"### telegence_refresh_a_line and {tenant_name} Batch size is {len(batch)}")
                for msisdn in batch:
                    url = f"{carrier_api_url}/{msisdn}"
                    try:
                        # Parse the change request JSON for the MSISDN
                        payload_str=msisdn_to_changerequest.get(msisdn)
                        request_payload = json.loads(payload_str)
                        payload = request_payload.get("RefreshLine")
                    except Exception as e:
                        logging.warning(f"### telegentelegence_refresh_a_linece_bc_update_ppu_address and {tenant_name} Invalid JSON for MSISDN {msisdn}: {e}")
                        payload = {}
                    ## Validate payload
                    request_id = msisdn_to_request_id.get(msisdn)
                    def task(msisdn=msisdn, url=url, payload=payload, request_id=request_id):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_refresh_a_line and {tenant_name} Attempt {attempt} - URL: {url}")
                                resp = requests.get(
                                    url,
                                    headers={"app-id": app_id, "app-secret": app_secret, "Content-Type": "application/json"},
                                    timeout=60
                                )
                                ## Prepare request payloads
                                logging.info(f"### telegence_refresh_a_line and {tenant_name} Response Code: {resp.status_code} for PPU address update")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                   response_data= resp.json()
                                   break
                            except Exception as e:
                                result = str(e)
                                logging.exception(f"### telegence_refresh_a_line and {tenant_name} Attempt {attempt} failed for {msisdn}:{e}")
                                time.sleep(RETRY_DELAY)
                        if success:
                            characteristics = {item["name"]: item["value"] for item in response_data.get("serviceCharacteristic", [])}
                            sim = characteristics.get("sim") 
                        if sim:
                            for characteristic in payload.get("serviceCharacteristic", []):
                                if characteristic.get("name") == "sim":
                                    characteristic["value"] = sim
                                    break
                            logging.info(f"### telegence_refresh_a_line and {tenant_name} Updated payload with SIM: {sim} for MSISDN: {msisdn}")
                            logging.info(f"### telegence_refresh_a_line and {tenant_name} Payload for MSISDN {msisdn}: {json.dumps(payload)}")
                            # Prepare the final payload for PATCH request
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### telegence_refresh_a_line and {tenant_name} Attempt {attempt} - URL: {url}")
                                    resp = requests.patch(
                                        url,
                                        json=payload,
                                        headers={"app-id": app_id, "app-secret": app_secret, "Content-Type": "application/json"},
                                        timeout=60
                                    )
                                    ## Prepare request payloads
                                    logging.info(f"### telegence_refresh_a_line and {tenant_name} Response Code: {resp.status_code} for PPU address update")
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    status = "PROCESSED" if success else "API_FAILED"
                                    if success:
                                        response_data= resp.json()
                                        successful_ids.append(msisdn)
                                        break
                                except Exception as e:
                                    result = str(e)
                                    logging.exception(f"### telegence_refresh_a_line and {tenant_name} Attempt {attempt} failed for {msisdn}:{e}")
                                    time.sleep(RETRY_DELAY)

                            # Update DB request row
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {"status": status, "has_errors": not success, "is_processed": True,
                                "processed_date": now,"status_details":result},
                                and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id}
                            )

                            # Update inventory
                            if success:
                                # Extract characteristics and update inventory
                                rate_plan_id = None
                                rate_plan_code = None
                               

                                logging.info(f"### telegence_refresh_a_line and {tenant_name} extracting characteristics for MSISDN: {msisdn}")
                                characteristics = {item["name"]: item["value"] for item in response_data.get("serviceCharacteristic", [])}
                                sim = characteristics.get("sim")
                                effective_date = characteristics.get("effectiveDate")
                                single_user_code = characteristics.get("singleUserCode")
                                service_zip_code = characteristics.get("serviceZipCode")
                                effective_date = characteristics.get("effectiveDate")
                                billing_account_number = characteristics.get("billingAccountNumber")
                                contact_name = characteristics.get("contactName")
                                nw_imei = characteristics.get("BLIMEI")
                                next_bill_cycle_date = characteristics.get("nextBillCycleDate")
                                status = response_data.get("status", "")
                                if status.lower() == "reserved":
                                    status = "Active"
                                offering_codes = [
                                        value for key, value in characteristics.items()
                                        if key.startswith("offeringCode") and value
                                    ]
                                offering_codes_str = ",".join(offering_codes) if offering_codes else ""
                                if "rate_plan_code" in rate_plan_data.columns and "id" in rate_plan_data.columns:
                                        matches = rate_plan_data.loc[
                                            (rate_plan_data["rate_plan_code"] == single_user_code),
                                            ["id", "rate_plan_code"]
                                        ]

                                        if not matches.empty:
                                            rate_plan_id = matches["id"].to_list()[0]
                                            rate_plan_code = matches["rate_plan_code"].to_list()[0]
                                        else:
                                            logging.warning(
                                                f"### telegence_refresh_a_line and {tenant_name}Rate plan not found for code: {single_user_code}"
                                            )
                                            rate_plan_id = None
                                            rate_plan_code = None
                                if "display_name" in device_status_data.columns and "id" in device_status_data.columns:
                                        matches = device_status_data.loc[
                                            device_status_data["display_name"] == status,
                                            "id"
                                        ]
                                        if not matches.empty:
                                            device_status_id = matches.iloc[0]
                                            device_status_id=int(device_status_id)
                                logging.info(f"###telegence_refresh_a_line and {tenant_name} All required data found; stopping polling and device_status_id {device_status_id}")
                                                 

                                #update the inventory
                                updated_data = {"effective_date": effective_date,"carrier_rate_plan_id": rate_plan_id,"carrier_rate_plan_name": rate_plan_code,
                                                "service_zip_code": service_zip_code,"billing_account_number": billing_account_number,
                                                "username": contact_name,"iccid": sim,"imei": nw_imei,"next_bill_cycle_date": next_bill_cycle_date,
                                                "telegence_features": offering_codes_str,"sim_status": status,"device_status_id": device_status_id,
                                                }       

                                logging.info(f"### telegence_refresh_a_line and {tenant_name} Updating inventory for MSISDN: {msisdn}")
                                database.update_dict("sim_management_inventory", updated_data, {
                                    "is_active": True,
                                    "msisdn": msisdn,"tenant_id": tenant_id,"service_provider_display_name":service_provider,
                                    })

                            # Prepare and insert log
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": request_id,
                                "log_entry_description": "Refresh A Line via Telegence API",
                                "request_text": json.dumps(payload),
                                "has_errors": not success,
                                "response_status": status,
                                "response_text": result,
                                "error_text": "" if success else result,
                                "processed_date": now_dt,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now_dt,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log,"sim_management_bulk_change_log")
                        return msisdn

                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_refresh_a_line and {tenant_name} Error processing MSISDN in thread: {e}")

        if INTERVAL and i + BATCH_SIZE < len(msisdns):
            time.sleep(INTERVAL)
        logging.info(f"carrier requests are processed successfully")
        live_progress_percentage_tracker(database, bulk_change_id,70)
        # Prepare history table update
        if successful_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": [],
                                        "msisdns":successful_ids,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the history table update API  
            try:
                logging.info(f"### telegence_refresh_a_line and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_refresh_a_line and {tenant_name} Exception in thread: {e}")  
            # Handle invalid MSISDNs
        if invalid_ids:
            logging.info(f"### telegence_refresh_a_line and {tenant_name} Invalid MSISDNs found: {invalid_ids}")
            # Log invalid IDS
            for request_id in invalid_ids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Invalid MSISDN during refresh",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid MSISDN - could not be processed",
                    "error_text": "Invalid MSISDN",
                    "processed_date": now_dt,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now_dt,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")

        if invalid_ids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now,"status_details":"Invalid MSISDN - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"id": invalid_ids}
            )

        database.update_dict(
            "sim_management_bulk_change",
            {"status": "PROCESSED", "processed_date": now_dt},
            {"id": bulk_change_id}
        )
        ##Future Upudates will be done here 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                    "data": {
                        "access_token": access_token,
                        "data": {
                            "bulk_change_id": bulk_change_id
                        },
                        "db_name": tenant_database,
                        "is_update": True,
                        "module_name": "Bulk Change",
                        "Partner": tenant_name,
                        "path": "/update_bulk_change_tables_10",
                        "request_received_at": now,
                        "role_name": role_name,
                        "tenant_name": tenant_name,
                        "username": username
                    }
                }
        #sync api call used to sync the inventory data to 1.0 tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### telegence_refresh_a_line and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f"### telegence_refresh_a_line and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_refresh_a_line and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        ##prepare response
        response = {
            "flag": True,
            "processed": len(msisdns) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk Refresh request processed successfully.",
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        # End time calculation
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_refresh_a_line",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed refresh a line update request for devices: {msisdns} with bulk_change_id: {bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
             logging.exception(f"### telegence_refresh_a_line and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        logging.exception(f"### telegence_refresh_a_line and {tenant_name} Audit logging failed: {e}")
        error_message = f"Error during refreshing line processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "telegence_refresh_a_line",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns} with bulk_change_id: {bulk_change_id}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
             logging.exception(f"### telegence_refresh_a_line and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
   


def telegence_bc_line_sync(data):
    """
    Sync SIM inventory and bulk change requests with the ciscojasper API.

    This function processes a list of ICCIDs for a given bulk change operation
    and updates their details by calling the carrier's ciscojasper API. It includes
    retry logic, database updates, inventory synchronization, error handling,
    and audit logging.

    Args:
        data (dict): Input dictionary containing the following keys:
            - iccids (list): List of ICCIDs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains request payload and UpdateStatus information.
            - service_provider (str): Name of the carrier/service provider.
            - change_type (str): Type of update (e.g., SIM/device status).
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant (for logs/audit).
            - db_name (str): Tenant-specific database name.
            - service_provider_id (str): Identifier for the service provider.
            - invalid_iccids (list): ICCIDs that failed validation before processing.

    Returns:
        dict: Response object summarizing the processing result:
            - flag (bool): True if operation completed without unhandled errors.
            - message (str): Summary of result (success or failure).
            - processed (int): Number of ICCIDs successfully processed.
            - remaining (int): Number of ICCIDs not processed.
            - iccids (list): List of ICCIDs attempted.
            - invalid_iccids (list): ICCIDs skipped due to invalid input.
            - bulk_change_id (str): Bulk change request ID.
            - error (str, optional): Error message if processing failed.
    """
    logging.info(f"### Received data for line sync: {data}")
    start_time = time.time()
    # Extract required fields
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    service_provider_id = data.get("service_provider_id", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    
    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### telegence_bc_line_sync and {tenant_name} time is {now}")
    successfull_ids = []
    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### telegence_bc_line_sync and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### telegence_bc_line_sync and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    
    try:
        # Get carrier API credentials and configuration
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### telegence_bc_line_sync and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### telegence_bc_line_sync and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number" ]
        ).rename(columns={"subscriber_number": "msisdn"})
        if  bulk_requests_df.empty:
            
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_line_sync",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### telegence_bc_line_sync and {tenant_name} Audit logging failed: {e}")
                return response

        ##fetching the requests ids
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        
        if PARALLEL_REQUESTS>10:
           logging.info(f"### telegence_bc_line_sync and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
        PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        remaining = list(msisdns)
        # Execute API calls in parallel using ThreadPoolExecutor
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(msisdns), BATCH_SIZE):
                batch = msisdns[i:i + BATCH_SIZE]
                futures = {}

                for msisdn in batch:
                    url = f"{carrier_api_url}/{msisdn}"                

                    def task(msisdn=msisdn, url=url):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        updated = None
                        inserted = None
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_line_sync and {tenant_name} Attempting {attempt} for ICCID: {msisdn} with URL: {url}")
                                resp = requests.get(url, 
                        headers={
                                    "app-id": app_id,
                                    "app-secret": app_secret,
                                    "Content-Type": "application/json"
                                }, timeout=60)
                                logging.info(f"### telegence_bc_line_sync and {tenant_name} Response Code: {resp.status_code} for ICCID: {msisdn}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successfull_ids.append(msisdn)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### telegence_bc_line_sync and {tenant_name} Attempt {attempt} failed for ICCID: {msisdn}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                           "processed_date": now,"status_details":resp.text},
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory if successful
                        if success:
                            api_data = resp.json()

                            # Extract serviceCharacteristic into a dict {name: value}
                            characteristics = {
                                item.get("name"): item.get("value")
                                for item in api_data.get("serviceCharacteristic", [])
                            }

                            # Map Telegence API → Inventory columns
                            to_update = {
                                "effective_date": characteristics.get("effectiveDate"),
                                "username": characteristics.get("contactName"),
                                "msisdn": characteristics.get("sim"),
                                "imei": characteristics.get("NWIMEI"),
                                "sim_status": api_data.get("status"),
                                "msisdn": api_data.get("subscriberNumber"),
                                "date_activated": characteristics.get("subscriberActivationDate"),
                                "rate_plan_soc": characteristics.get("singleUserCode"),
                                "rate_plan_soc_description": characteristics.get("singleUserCodeDescription"),
                                "billing_account_number": characteristics.get("billingAccountNumber"),
                            }

                            # First try update
                            updated = database.update_dict(
                                "sim_management_inventory",
                                values=to_update,
                                and_conditions={
                                    "msisdn": msisdn,
                                    "tenant_id": tenant_id,
                                    "service_provider_id": service_provider_id,
                                    "is_active": True,
                                },
                            )

                            # If no update happened (new ICCID not in inventory) → insert
                            if not updated:
                                to_insert = {
                                    "effective_date": characteristics.get("effectiveDate"),
                                    "username": characteristics.get("contactName"),
                                    "iccid": characteristics.get("sim"),
                                    "imei": characteristics.get("NWIMEI"),
                                    "sim_status": api_data.get("status"),
                                    "msisdn": api_data.get("subscriberNumber"),
                                    "tenant_id": str(tenant_id),
                                    "service_provider_id": str(service_provider_id),
                                    "is_active": True,
                                    "created_date": now,
                                }
                                inserted = database.insert_dict(to_insert, "sim_management_inventory")


                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                            "log_entry_description": "Update telegence Subscriber: telegence API",
                            "request_text": None,
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            
                        # Prepare log entry
                        # Determine inventory update success
                        inventory_success = inserted or updated  # True if either insert or update happened

                        # Prepare inventory log entry
                        inventory_log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                            "log_entry_description": "Update AMOP",
                            "request_text": None,
                            "has_errors": not inventory_success,
                            "response_status": "PROCESSED" if inventory_success else "ERROR",
                            "response_text": "inventory updated successfully" if inventory_success else "inventory update failed",
                            "error_text": "" if inventory_success else "Inventory update failed",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }

                        if inventory_log:
                            database.insert_data(inventory_log, "sim_management_bulk_change_log")   
                            
                        return msisdn

                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_line_sync and {tenant_name} Error processing ICCID: {e}")

            if INTERVAL and i + BATCH_SIZE < len(msisdns):
                time.sleep(INTERVAL)
        # Handle and log invalid MSISDNs
        #prepare the payload for history table
        if successfull_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": successfull_ids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### telegence_bc_line_sync and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_bc_line_sync and {tenant_name} Exception in thread: {e}")
        # Handle and log invalid ICCIDs
        if invalid_msisdns:
            for msisdn in invalid_msisdns:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                    "log_entry_description": "Update telegence Subscriber: Invalid MSISDN",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid MSISDN",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")

        # Mark invalid request IDs as processed
        if invalid_msisdns:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"subscriber_number": invalid_msisdns}
            )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        #  sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api to update the inventry tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### telegence_bc_line_sync and {tenant_name} sync call has started")
            
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### telegence_bc_line_sync and {tenant_name} sync call has ended")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### telegence_bc_line_sync and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_line_sync and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        # Prepare response
        response={
            "flag": True,
            "processed": len(msisdns) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "msisdns": msisdns,
            "invalid_iccids": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
       
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_line_sync",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for update device status for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
             ##auditing the auditing log
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### telegence_bc_line_sync and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### telegence_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### telegence_bc_line_sync and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR","status_details":"Processing Invalid Sim"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "telegence_bc_line_sync",
                "created_date": data.get("request_received_at") or now,
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for: {msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### telegence_bc_line_sync and {tenant_name} Exception in logging error data to DB: {log_e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_iccids": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        return response    
