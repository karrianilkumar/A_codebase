"""
@Author1 : Phaneendra.Y
Created Date: 21-06-24
"""

# Importing the necessary Libraries
import os
from common_utils.logging_utils import Logging
from common_utils.db_utils import DB
import requests
from requests.auth import HTTPBasicAuth
import base64
import json


logging = Logging(name="authentication_check")

db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}


def fetch_user_from_zitadel(user_id, access_token, zitadel_domain):

    # Define the endpoint
    url = f"https://{zitadel_domain}/management/v1/users/{user_id}"

    # Set headers
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    # Make the request
    response = requests.get(url, headers=headers)

    # Check the response status
    if response.status_code == 200:
        return response.json()  # Return the user details as JSON
    else:
        return ""


def get_client_id(token):
    ##helper function to get the client id 
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    client_data=common_utils_database.get_data('service_accounts', {"z_access_token": token}, ["client_id"]
        )
    if client_data.empty:
        access_token = os.getenv("AUTH_TOKEN", " ")
        zitadel_domain = os.getenv("zitadel_domain", "")
        # Decoding the JWT token
        user_id = None
        try:
            header, payload, _ = token.split(".")
            decoded_payload = base64.urlsafe_b64decode(f"{payload}==").decode("utf-8")
            # Signature verification disabled for demo
            user_id = json.loads(decoded_payload).get("sub", "")
            logging.info(f"Information Decoded")
        except Exception as e:
            logging.exception(f"Failed to decode token: {e}")

        client_id = ""
        if user_id:
            details = fetch_user_from_zitadel(user_id, access_token, zitadel_domain)
            if details:
                client_id = details["user"]["userName"]
    else:
        client_id=client_data['client_id'].to_list()[0]
    return client_id


def validate_token(token):

    client_id = os.getenv("CLIENT_ID", " ")
    client_secret = os.getenv("CLIENT_SECRET", " ")
    zitadel_domain = os.getenv("zitadel_domain", "")

    introspect_url = f"https://{zitadel_domain}/oauth/v2/introspect"
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    payload = {"token": token}

    response = requests.post(
        introspect_url,
        headers=headers,
        data=payload,
        auth=HTTPBasicAuth(client_id, client_secret),
    )

    if response.status_code == 200:
        token_info = response.json()
        return True
    else:
        logging.info("Failed to validate token:", response.status_code, response.text)
        return False


def Validate_Ui_token(username, token):
    logging.info(f"username is {username} and token is {token}")
    try:
        # Connect to the database
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        if not username or not token:
            raise ValueError("Username, and reset token must be provided.")

        # Fetch the reset token from the database
        db_reset_token = database.get_data(
            "users", {"username": username}, ["access_token"]
        )["access_token"].to_list()

        if not db_reset_token:
            raise ValueError("User not found or reset token is missing.")

        db_reset_token = db_reset_token[0]  # Assuming there's only one token per user
        logging.info(f"token is {token} and db_reset_token is {db_reset_token}")

        # Check if the provided reset token matches the one in the database
        if str(token) == str(db_reset_token):
            # Return success message
            return True
        else:
            # Return invalid token message
            return False

    except Exception as e:
        logging.error(f"exception has an error is {e}")
        # Handle any other exceptions
        return False
