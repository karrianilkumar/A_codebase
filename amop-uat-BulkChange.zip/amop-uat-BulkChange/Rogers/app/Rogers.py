"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24
"""
# Importing the necessary Libraries
from decimal import Decimal
import json
import logging
import os
import requests
import pandas as pd
from common_utils.db_utils import DB
from datetime import datetime
from dotenv import load_dotenv
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
from sqlalchemy import create_engine, text
import threading
from pytz import timezone
from openpyxl.utils import get_column_letter
import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# Database configuration
db_config = {
     "host": os.environ["HOST"],
     "port": os.environ["PORT"],
     "user": os.environ["USER"],
     "password": os.environ["PASSWORD"],

 }





##function caller where the functions begins
def funtion_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler
    if path == "/rogers_bc_archive_devices":
        result = rogers_bc_archive_devices(data)
    elif path == "/rogers_bc_change_customer_rate_plan":
        result = rogers_bc_change_customer_rate_plan(data)
    elif path == "/rogers_bc_change_carrier_rate_plan":
        result = rogers_bc_change_carrier_rate_plan(data)
    elif path== "/rogers_bc_update_device_status":
        result = rogers_bc_update_device_status(data)
    elif path== "/rogers_bc_edit_username_cost_center":
        result = rogers_bc_edit_username_cost_center(data)
    elif path== "/rogers_bc_assign_customer":
        result = rogers_bc_assign_customer(data)
    elif path== "/rogers_bc_line_sync":
        result = rogers_bc_line_sync(data)
    elif path== "/sync_usage_for_sims":
        result = sync_usage_for_sims(data)
    ##else condition to handle the invalid path method
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"### Invalid path or method requested: {path}")
    return result


## Function to get Carrier API details
def get_carrier_api_details(service_provider,change_type,common_utils_database):
    '''
    Function to get the Carrier API URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The Carreir API URL,app_id,app_secret if found, otherwise None.'''
    # Initialize variables
    carrier_api_url=None
    app_id=None
    app_secret=None
    carrier_limit=None
    alternative_api_url=None
    ##carrier api query and their limits query
    carrier_details= common_utils_database.get_data(
    "bulk_change_carrier_limits", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["carrier_api_url","app_id","app_secret","carrier_limit","alternative_api_url"]
    )
    logging.info(f"### carrier_details: {carrier_details}")
    if not carrier_details.empty:
        ##fetching the carrier API limits
        carrier_api_url=carrier_details.iloc[0]['carrier_api_url']
        app_id=carrier_details.iloc[0]['app_id']
        app_secret=carrier_details.iloc[0]['app_secret']
        carrier_limit=carrier_details.iloc[0]['carrier_limit']
        alternative_api_url=carrier_details.iloc[0].get('alternative_api_url', None)
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url
    else:
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url

##Archive devices function 
def rogers_bc_archive_devices(data):
    """
    Archives devices from the system based on the provided ICCIDs.

    This function is typically triggered during a bulk change operation, where a list of SIM cards
    (identified by their ICCIDs) needs to be marked as archived in the system. Archiving a device
    means it is no longer considered active or in use, and its status is updated accordingly
    in relevant tables (e.g., inventory, assignment logs, usage tracking).

    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs to be archived.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
            - other metadata as needed for auditing or tracking.

    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
    """
    logging.info(f"### Received data for archiving devices: %s", data)
    start_time = time.time()
    # Validate required fields
    iccids = data.get("iccids", [])
    invalid_iccids = data.get("invalid_iccids", [])
    tenant_id = data.get("tenant_id", [])
    bulk_change_id = data.get("bulk_change_id", "")
    created_by=data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    service_provider = data.get("service_provider", "")
    role_name= data.get("role", "")
    service_provider_id = data.get("service_provider_id", "")
    username= data.get("username", "")
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### Rogers_bc_archiving devices and {tenant_name} time is {now}")
    #database connection
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### rogers_bc_archive_devices and {tenant_name} DB connection error: %s", e)
        return {"flag":False,"message": "DB connection failed", "details": str(e)}
    # Audit - start
    bulk_change_audit_action(data, common_utils_database,
                 action=f"Bulk Change Process Initiated"
                )
    live_progress_percentage_tracker(database, bulk_change_id,25)
    try:
        bulk_change_requests = database.get_data(
                'sim_management_bulk_change_request',
                {"bulk_change_id": bulk_change_id},
                ['id', 'iccid']
        )
        if bulk_change_requests.empty:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "rogers_bc_archive_devices",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### rogers_bc_archive_devices rate plan and {tenant_name} Audit logging failed: {e}")
                return response
        ##main login to archive the devices
        # Map ICCID to request ID for fast access
        live_progress_percentage_tracker(database, bulk_change_id,40)
        iccid_to_request_id = dict(zip(bulk_change_requests["iccid"], bulk_change_requests["id"]))
        # Archive valid ICCIDs in inventory
        logs_data=[]
        if iccids:
            inventory_update = database.update_dict(
                "sim_management_inventory",
                {"is_active": False, "is_deleted": True},
                and_conditions={"tenant_id": tenant_id, "service_provider_id": service_provider_id},
                in_conditions={"iccid": iccids},
            )
            logging.info(f"### rogers_bc_archive_devices and {tenant_name} Inventory update status: {inventory_update}")
            if inventory_update:  # If update failed
                logging.info(f"### rogers_bc_archive_devices and {tenant_name} Archived {len(iccids)} devices in inventory")
            else:  
                logging.info(f"### rogers_bc_archive_devices and {tenant_name} Error updating inventory for ICCIDs: {iccids}")
                for iccid in iccids:
                    request_id = iccid_to_request_id.get(iccid)
                    if request_id:
                        logs_data.append({
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": request_id,
                            "log_entry_description": f"Archive Device Failed: {iccid}",
                            "request_text": "Update AMOP",
                            "has_errors": True,
                            "response_status": "ERROR",
                            "response_text": "Failed to archive device",
                            "error_text": "inventory update failed",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        })
                if logs_data:
                    database.insert_data(logs_data,"sim_management_bulk_change_log")
            
                database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR","errors": len(iccids),"is_processed": True,"has_errors": True,"processed_date": now,"status_details":"Failed to archive device"},
                    and_conditions={"bulk_change_id": bulk_change_id},in_conditions={"iccid": iccids},)
            
            # Also update main bulk change record
                database.update_dict(
                    "sim_management_bulk_change",
                    {"status": "ERROR","errors": len(iccids),"processed_date": now},and_conditions={"bulk_change_id": bulk_change_id},
                )
                return {"flag": False,"message": "Inventory update failed","bulk_change_id": bulk_change_id}

        # Prepare logs
        log_entries = []
        invalid_log_entries = []
        # Valid ICCIDs
        for iccid in iccids:
            request_id = iccid_to_request_id.get(iccid)
            if request_id:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Archive Device: {iccid}",
                    "request_text": "Update AMOP",
                    "has_errors": False,
                    "response_status": "PROCESSED",
                    "response_text": "Device archived successfully",
                    "error_text": "",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### rogers_bc_archive_devices and {tenant_name} inserted {len(log_entries)} log entries for bulk change request")
        #updating bulk change request tables     
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len([iccids]),
             "is_processed":True,"has_errors":False,
                    "processed_date": now,"status_details":"Device archived successfully"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": iccids},
        )
        # Prepare payload for history table update
        if iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids":iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### rogers_bc_archive_devices and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### rogers_bc_archive_devices and {tenant_name} Exception in thread: {e}")
        # Invalid SIMs
        live_progress_percentage_tracker(database, bulk_change_id,70)

        for iccid in invalid_iccids:
            request_id = iccid_to_request_id.get(iccid)
            invalid_log_entries.append({
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Archive Device Failed: {iccid}",
                "request_text": "Update AMOP",
                "has_errors": True,
                "response_status": "ERROR",
                "response_text": "Invalid SIM - could not be processed",
                "error_text": "Invalid ICCID",
                "processed_date": now,
                "processed_by": created_by,
                "created_by": created_by,
                "created_date": now,
                "is_deleted": False,
                "is_active": True
            })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        #  Bulk insert all logs
        if invalid_log_entries:
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_log")
        logging.info(f"### rogers_bc_archive_devices and {tenant_name} archived {len(iccids)} devices successfully")


        # Update the status of the bulk change request to PROCESSED
        database.update_dict(
                'sim_management_bulk_change',
                {
                    "status": "PROCESSED",
                    "success": len(iccids),
                    "processed_date": now
                },
                {'id': bulk_change_id}
            )
        ##Future Upudates will be done here 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #below sync url and payload used to sync the inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "rogers_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        
        live_progress_percentage_tracker(database, bulk_change_id,80)
        try:
            logging.info(f"### rogers_bc_archive_devices and {tenant_name} sync call has started")

            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### rogers_bc_archive_devices and {tenant_name} sync call has ended")
            bulk_change_audit_action(data, common_utils_database,
                 action=f"Sync To 1.0 Tables"
                )
        except Exception as e:
            logging.exception(f"### rogers_bc_archive_devices and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### rogers_bc_archive_devices and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### rogers_bc_archive_devices and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # Attempt to audit the actionn
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "rogers_bc_archive_devices",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for archive devices.{bulk_change_id}",
                "request_received_at": now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database,
                 action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### rogers_bc_archive_devices and {tenant_name} Audit logging failed: {e}")
        # Attempt to audit the actionn
        bulk_change_audit_action(data, common_utils_database,
                 action=f"Bulk Change Process Completed"
                )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### rogers_bc_archive_devices and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )

        return response
    except Exception as e:
        logging.exception(f"### rogers_bc_archive_devices and {tenant_name} Error during bulk change processing for archive status rogers_bc_archive_devices: {str(e)}")
        # Update the status of the bulk change request to ERROR
        # Log the error
        error_message = f"Error during bulk change processing for archive status: {str(e)}"
        # response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        logging.error(f"### rogers_bc_archive_devices and {tenant_name} Error during bulk change processing for archive status rogers_bc_archive_devices: {str(e)}")
        # Prepare error response
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(iccids),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log error to database
            error_data = {
                "service_name": "rogers_bc_archive_devices",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request :{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### rogers_bc_archive_devices and {tenant_name} Exception in logging error data to DB: {e}")
        return response


## Change customer rate plan function
def rogers_bc_change_customer_rate_plan(data):
    """
    Change the customer rate plan for the given devices as part of a bulk change operation.
   
    this function is typically triggered during a bulk change operation where a list of SIM cards needs to have their customer rate plans updated.
    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs used to identify devices.
            -changed_data (dict): Dictionary containing the rate plan changes.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
        dict: Result of the operation with flags, messages, and details.
        
    """
    logging.info(f"### Received data for changing customer rate plan: %s", data)
    # Start timing the function execution
    start_time = time.time()
    # Extract all required fields from input data
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id", "")
    created_by = data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    tenant_id= data.get("tenant_id", "")
    service_provider = data.get("service_provider", "")
    service_provider_id = data.get("service_provider_id", "")
    username = data.get("username", "")
    invalid_iccids = data.get("invalid_iccids", [])
    # Validate required fields
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### rogers_bc_change_customer_rate_plan and {tenant_name} time is {now}")
    try:
        # Connect to main and audit databases
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### DB connection error: %s", e)
        return {"flag": False, "message": "DB connection failed", "details": str(e)}
    try:
        # Audit - Start
        bulk_change_audit_action(
            data, common_utils_database,
            action="Bulk Change Process Initiated"
        )
        live_progress_percentage_tracker(database, bulk_change_id,20)
        
        # Fetch bulk change request entries for valid ICCIDs
        bulk_change_requests = database.get_data(
            'sim_management_bulk_change_request',
            {"bulk_change_id": bulk_change_id},
            ['id', 'iccid','change_request']
        )
        if not bulk_change_requests.empty:
            change_request_json = bulk_change_requests.iloc[0]["change_request"]
            if not change_request_json:
                message="Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "rogers_bc_change_customer_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                    live_progress_percentage_tracker(database, bulk_change_id,100)
                except Exception as e:
                    logging.warning(f"### rogers_bc_change_customer_rate_plan and tenant name : {tenant_name} Audit logging failed: {e}")
                return response
            
        live_progress_percentage_tracker(database, bulk_change_id,25)
        # Map iccids to request IDs
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        customer_rate_plan_update=change_request_json.get("CustomerRatePlanUpdate","")
        customer_rate_plan_id=customer_rate_plan_update.get("CustomerRatePlanId","")
        customer_rate_pool_id=customer_rate_plan_update.get("CustomerPoolId","")
        effective_date=customer_rate_plan_update.get("EffectiveDate","")
        rate_plan_db_name=None
        rate_pool_db_name=None
        plan_mb=None
        # Validate input data
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_name","plan_mb"]   
            )
            if not rate_plan_data.empty:
                rate_plan_db_name = rate_plan_data["rate_plan_name"].to_list()[0]
                plan_mb = rate_plan_data["plan_mb"].to_list()[0]
        if customer_rate_pool_id and str(customer_rate_pool_id)!="-1":
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                rate_pool_db_name = rate_pool_data["name"].to_list()[0]
        
        update_fields={}
        # Extract valid ICCIDs
        # Prepare an update dict dynamically
        if customer_rate_plan_id is None:
            update_fields["customer_rate_plan_id"] = None
            update_fields["customer_rate_plan_name"] = None
        elif str(customer_rate_plan_id).strip() != "-1":
            update_fields["customer_rate_plan_id"] = customer_rate_plan_id
            update_fields["customer_rate_plan_name"] = rate_plan_db_name
        if customer_rate_pool_id is None:
            update_fields["customer_rate_pool_id"] = None
            update_fields["customer_rate_pool_name"] = None
        elif str(customer_rate_pool_id) != "-1":
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id	
            update_fields["customer_rate_pool_name"] = rate_pool_db_name
  
        if effective_date:
            update_fields["effective_date"] = effective_date
        
        if plan_mb:
            update_fields["customer_data_allocation_mb"] = plan_mb
        else:
            update_fields["customer_data_allocation_mb"] = None
        update_fields["modified_by"] = username
        
        # Map ICCID to request ID for logging
        iccid_to_request_id = dict(zip(bulk_change_requests["iccid"], bulk_change_requests["id"]))
        log_entries = []
        invalid_log_entries=[]
        inventory_update = False # defulat 
        live_progress_percentage_tracker(database, bulk_change_id,40)
        
        # Update the SIM management inventory with the new rate plan
        if iccids:
            logging.info(f"### rogers_bc_change_customer_rate_plan and tenant name : {tenant_name} Updating SIM management inventory with updated fields: {update_fields}")
            inventory_update =  database.update_dict(
            "sim_management_inventory",update_fields,
            and_conditions={"tenant_id":tenant_id,"is_active": True, "service_provider_id": service_provider_id},
            in_conditions={"iccid": iccids},
            
            )   
            logging.info(f"### rogers_bc_change_customer_rate_plan and {tenant_name} Inventory update status: {inventory_update}")
            if inventory_update:  # success case
                logging.info(f"### rogers_bc_change_customer_rate_plan and {tenant_name} customer rate plan updated for {len(iccids)} devices in inventory")
            else:    # failure case 
                logging.info(f"### rogers_bc_change_customer_rate_plan and {tenant_name} Error updating inventory for ICCIDs: {iccids}")
                for iccid in iccids:
                    request_id = iccid_to_request_id.get(iccid)
                    if request_id:
                        log_entries.append({
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": request_id,
                        "log_entry_description": f"Change Customer Rate Plan for iccid : {iccid} failed",
                        "request_text": "Update AMOP",
                        "has_errors": not inventory_update,
                        "response_status": "ERROR",
                        "response_text":  "Customer Rate plan is not updated",
                        "error_text": "Rate plan not found or inactive",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                    })
                if log_entries:
                    database.insert_data(log_entries,"sim_management_bulk_change_log")
            
                database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR","errors": len(iccids),"is_processed": True,"has_errors": True,"processed_date": now,"status_details":"Customer Rate plan is not updated"},
                    and_conditions={"bulk_change_id": bulk_change_id},in_conditions={"iccid": iccids},)
            
            # Also update main bulk change record
                database.update_dict(
                    "sim_management_bulk_change",
                    {"status": "ERROR","errors": len(iccids),"processed_date": now},and_conditions={"bulk_change_id": bulk_change_id},
                )
                return {"flag": False,"message": "Inventory update failed","bulk_change_id": bulk_change_id}
                
            
        # Log valid ICCIDs
        for iccid in iccids:
            request_id = iccid_to_request_id.get(iccid)
            log_entries.append({
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Change Customer Rate Plan for iccid : {iccid} successful",
                "request_text": "Update AMOP",
                "has_errors": False,
                "response_status": "PROCESSED",
                "response_text": "Updated Customer Rate Plan Succesfully",
                "error_text": "",
                "processed_date": now,
                "processed_by": created_by,
                "created_by": created_by,
                "created_date": now,
                "is_deleted": False,
                "is_active": True
            })
        #update       
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len(iccids),"is_processed":True,"has_errors":False,
                    "processed_date": now , "status_details":"OK" },
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### rogers_bc_change_customer_rate_plan and {tenant_name} inserted {len(log_entries)} log entries for bulk change request")
        
        # Prepare payload for history table update
        if iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            #api call to update the history table
            try:
                logging.info(f"### rogers_bc_change_customer_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### rogers_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
            
        live_progress_percentage_tracker(database, bulk_change_id,70)    
            
        if invalid_iccids:
            logging.info(f"### rogers_bc_change_customer_rate_plan and {tenant_name} Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                invalid_log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Change Customer Rate Plan Failed",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid ICCID - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now , "status_details":"Invalid ICCID - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        if invalid_log_entries : 
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_log")
            
        # Update bulk change status to PROCESSED
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "success": len(iccids),
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api call to update the 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "rogers_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(
            data, common_utils_database,
            action="Sync To 1.0 Tables"
        )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        try:
            logging.info(f"### rogers_bc_change_customer_rate_plan and {tenant_name} sync call has started")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### rogers_bc_change_customer_rate_plan and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### rogers_bc_change_customer_rate_plan: Exception while scheduling sync call for tenant '{tenant_name}': {e}")

        # Return success
        logging.info(f"### rogers_bc_change_customer_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### rogers_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        # Prepare success response
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "msisdns": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "rogers_bc_change_customer_rate_plan",
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing customer rate plan for devices : {bulk_change_id}",
                "request_received_at":now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database, action=f"Auditing")
        except Exception as e:
            logging.exception(f"### rogers_bc_change_customer_rate_plan and {tenant_name} Audit logging failed: {e}")
        # audit the auditing log
        bulk_change_audit_action(data, common_utils_database, action=f"Bulk Change Process Completed")
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### rogers_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        return response
 
    except Exception as e:
        # Main exception block
        logging.exception(f"### rogers_bc_change_customer_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = "Error during bulk change processing"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(iccids),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "rogers_bc_change_customer_rate_plan",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": now,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### rogers_bc_change_customer_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response


##Update Device Status function
def rogers_bc_update_device_status(data):
    """
   Update the device status using the Rogers API.

    This function processes a list of ICCIDs and updates their device status in the Rogers system.
    It performs the following steps:
        - Retrieves API credentials and configuration limits based on the service provider and change type.
        - Fetches bulk change requests and maps ICCIDs to their respective request payloads.
        - Iteratively calls the Rogers API for each ICCID with retry logic.
        - Updates status in the request and inventory tables based on API responses.
        - Logs both success and failure results into the bulk change log table.
        - Handles any invalid ICCIDs or request IDs by logging them appropriately.
        - Marks the bulk change as processed.
        - Records an audit entry and error logs in case of exceptions.

    Args:
        data (dict): Input dictionary containing the following keys:
            - msisdns (list): List of ICCIDs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains the payload structure to send to the Rogers API.
            - created_by (str): Username of the user initiating the request.
            - service_provider (str): Name of the carrier or service provider.
            - change_type (str): Type of update being performed (e.g., SIM status or device status).
            - tenant_id (str): ID of the tenant initiating the request.
            - tenant_name (str): Name of the tenant for logging/auditing purposes.
            - db_name (str): Database name associated with the tenant.
            - username (str): Username to use in audit logs.
            - invalid_msisdns (list): ICCIDs that failed validation before processing.
            - invalid_ids (list): Request IDs associated with invalid rows.
            - request_received_at (str): Timestamp when the request was received (optional).

    Returns:
        dict: A response object indicating the result of the operation, containing:
            - flag (bool): True if processing completed without unhandled exceptions.
            - message (str): Summary message indicating the result.
            - processed (int): Number of ICCIDs processed.
            - msisdns (list): List of ICCIDs attempted.
            - invalid_msisdns (list): List of ICCIDs skipped due to invalid state.
            - bulk_change_id (str): ID of the bulk change request.
            - error (str, optional): Error message in case of failure.
    """
    logging.info(f"### Received data for updating device status: {data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    service_provider_id = data.get("service_provider_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    UpdateStatus= data.get("changed_data", {}).get("UpdateStatus", {})
   
    # Extract status values from changed_data
    device_status_id = data.get("device_status_id","")
    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### rogers_bc_update_device_status and {tenant_name} time is {now}")
    successfull_ids = []
    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### rogers_bc_update_device_status and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### rogers_bc_update_device_status and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    
    try:
        # Get carrier API credentials and configuration
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### rogers_bc_update_device_status and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### rogers_bc_update_device_status and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json=bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "rogers_bc_update_device_status",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                    live_progress_percentage_tracker(database, bulk_change_id,100)
                except Exception as e:
                    logging.warning(f"### rogers_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
                return response
        # Extract update status from change_request_json
         
        if isinstance(change_request_json, str):             
           change_request_json = json.loads(change_request_json)  
        UpdateStatus = change_request_json.get("UpdateStatus", "") 
        logging.info(f"### rogers_bc_update_device_status and {tenant_name} Update status: {UpdateStatus}")
        device_status_data=pd.DataFrame()
        device_status = None
        ##fetching the status of the device to get updated using id
        if device_status_id:
            device_status_data = database.get_data(
                "device_status",
                {"id": device_status_id, "is_active": True},
                ["id", "display_name"]
            )
        if not device_status_data.empty:
           device_status = device_status_data["display_name"].iloc[0]

        ##fetching the requests ids
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        if PARALLEL_REQUESTS>10:
           logging.info(f"### rogers_bc_update_device_status and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
        PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        remaining = list(iccids)
        # Execute API calls in parallel using ThreadPoolExecutor
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}

                for iccid in batch:
                    url = f"{carrier_api_url}/{iccid}"
                    
                    payload={"status": UpdateStatus}                 

                    def task(iccid=iccid, url=url, payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### rogers_bc_update_device_status and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                resp = requests.put(url, json=payload, 
                                    headers={
                                                "Authorization": app_id,
                                                "Content-Type": "application/json",
                                                "Accept": "application/json"
                                            }, timeout=60)
                                logging.info(f"### rogers_bc_update_device_status and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successfull_ids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### rogers_bc_update_device_status and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                           "processed_date": now,"status_details":resp.text},
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory if successful
                        if success:
                            database.update_dict(
                                "sim_management_inventory",
                                {   
                                    "sim_status": device_status,
                                    "modified_by": username,
                                    "device_status_id": device_status_id if device_status_id else None
                                },
                                and_conditions={"tenant_id": tenant_id,"service_provider_id": service_provider_id, "is_active": True},
                                in_conditions={"iccid": [iccid]}
                            )

                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update rogers Subscriber: rogers API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### rogers_bc_update_device_status and {tenant_name} Error processing ICCID: {e}")

        if INTERVAL and i + BATCH_SIZE < len(iccids):
                time.sleep(INTERVAL)
        #prepare the payload for history table
        if successfull_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": successfull_ids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### rogers_bc_update_device_status and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### rogers_bc_update_device_status and {tenant_name} Exception in thread: {e}")
        # Handle and log invalid ICCIDs
        if invalid_iccids:
            for iccid in invalid_iccids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": "Update rogers Subscriber: Invalid ICCID",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")

        # Mark invalid request IDs as processed
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        #  sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api to update the inventry tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "rogers_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### rogers_bc_update_device_status and {tenant_name} sync call has started")
            
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### rogers_bc_update_device_status and {tenant_name} sync call has ended")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### rogers_bc_update_device_status and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### rogers_bc_update_device_status and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### rogers_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        # Prepare response
        response={
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
       
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "rogers_bc_update_device_status",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for updating device status for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
             ##auditing the auditing log
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### rogers_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### rogers_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### rogers_bc_update_device_status and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "rogers_bc_update_device_status",
                "created_date": data.get("request_received_at") or now,
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for: {iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### rogers_bc_update_device_status and {tenant_name} Exception in logging error data to DB: {log_e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response
    

    
## Change Carrier Rate Plan function
def rogers_bc_change_carrier_rate_plan(data):
    """Change the carrier rate plan for the given devices.
    This function processes a list of iccids and updates their carrier rate plan in the pod19 system.
    It handles bulk requests, updates the database, and logs the results.   
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDS to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the pod19 API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Recevied data for change carrier rate plan :{data}")
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    service_provider_id = data.get("service_provider_id", "")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Initialize for log entries
    log_entries = []
    success_iccids = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR","status_details":"Processing Invalid Sim"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "rogers_bc_change_carrier_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
                return response
            live_progress_percentage_tracker(database, bulk_change_id,20)
                
        # Map iccids to request IDs
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        carrier_rate_plan_update=change_request_json.get("CarrierRatePlanUpdate","")
        carrie_rate_plan=carrier_rate_plan_update.get("CarrierRatePlan","")
        effective_date=carrier_rate_plan_update.get("EffectiveDate","")

        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        ## Prepare headers for API call
        rate_plan_id=None
        rate_plan_code=None
        # Validate input data for rateplan and optimization
        logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Validating input data for rate plan and optimization group")
        if carrie_rate_plan:
           rate_plan_data = database.get_data(
            "carrier_rate_plan",
            {"rate_plan_code": carrie_rate_plan, "is_active": True},
            ["id","rate_plan_code"]
            )
        if not rate_plan_data.empty:
            rate_plan_id = rate_plan_data["id"].to_list()[0]
            rate_plan_code=rate_plan_data["rate_plan_code"].to_list()[0]
        logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Rate plan ID: {rate_plan_id} Rate Plan Code: {rate_plan_code}")
        # Prepare an update dict
        
        if carrie_rate_plan:
           update_fields = {"carrier_rate_plan_id": rate_plan_id,"carrier_rate_plan_name": carrie_rate_plan}       
        if effective_date:
           update_fields["effective_date"] = effective_date
        update_fields["modified_by"] = username 

           
        # Validate iccids
        remaining = iccids.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        remaining = list(iccids) 

        #constracting header 
        headers = {
            "Authorization": app_id,
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)

        # Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each iccid in the batch
                logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} iccids")
                for iccid in batch:
                    # Prepare the URL and payload for the API call
                    url = f"{carrier_api_url}/{iccid}"
                    payload = {"ratePlan": carrie_rate_plan}
                      
                def task(iccid=iccid, url=url, payload=payload):  
                        success = False
                        result = ""
                        status = "API_FAILED"
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Attempting {attempt} for iccid: {iccid} with URL: {url}")
                                resp = requests.put(
                                    url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Response Code: {resp.status_code} for iccid: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    success_iccids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Attempt {attempt} failed for iccids: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)
                        if success:
                            update_data = {
                                "status": status,
                                "has_errors": False,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details":result 
                            }
                        else:
                            update_data = {
                                "status": status,
                                "has_errors": True,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details":result
                            }
                        #update the request status
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id},
                            )
                        # Only update inventory if API succeeded
                        if success:
                            database.update_dict(
                                "sim_management_inventory",update_fields,
                                and_conditions={"tenant_id":tenant_id,"service_provider_id": service_provider_id,"is_active": True},
                                in_conditions={"iccid": [iccid]}
                                )
                        # Constructing the log entry
                        log = {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                        "log_entry_description": "Update rogers Subscriber: rogers API",
                        "request_text": json.dumps(payload),
                        "has_errors": status == "API_FAILED",
                        "response_status": "PROCESSED" if success else "API_Failed",
                        "response_text": result,
                        "error_text": "" if status == "PROCESSED" else result,
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                        }
            
                        if log:
                            database.insert_data(log,"sim_management_bulk_change_log") 
                        return iccid
                    
                # Submit the task to the executor
                logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Submitting task for ICCID: {iccid}")
                futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Error processing ICCIDS: {e}")

              
        if interval and i + batch_size < len(iccids):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
         #preare the payload for history table
        if success_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": success_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
        
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            # Call the history table API
            try:
                logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")
        # Update the bulk change request status   
        logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Processed {len(iccids) - len(remaining)} iccids, {len(remaining)} remaining")
        ## Handle invalid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_iccids:
            logging.info(f"### Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread
        live_progress_percentage_tracker(database, bulk_change_id,80)
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "rogers_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info('### rogers_bc_change_carrier_rate_plan and {tenant_name} sync call has started')
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info('### rogers_bc_change_carrier_rate_plan and {tenant_name} sync call has ended')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
       
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "rogers_bc_change_carrier_rate_plan",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the sync completion
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
         
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "rogers_bc_change_carrier_rate_plan",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### rogers_bc_change_carrier_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response


def rogers_bc_edit_username_cost_center(data):
    """Edit the username or cost center associated with the device."""

    logging.info(f"### Recevied data for rogers_bc_edit_usename_cost_center :{data}")
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    service_provider_id = data.get("service_provider_id", "")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    #username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Validate required fields
    # Initialize for log entries
    log_entries = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request","subscriber_number"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "rogers_bc_edit_usename_cost_center",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,20)
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
           username=change_request_json.get("ContactName", "")
           cost_center=change_request_json.get("CostCenter1", "") 
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))

        msisdns = bulk_requests_df["msisdn"].tolist()
        ## Prepare headers for API call
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
            "Content-Type": "application/json-patch+json"
        }
        
        # Prepare an update dict 
        rev_data=pd.DataFrame()
        revid=None
        update_fields = {}
        successfull_iccids = []
        if username:
           update_fields["username"] = username
        if cost_center:
            update_fields["cost_center"]=cost_center

        update_fields["modified_by"] = username 
        # Validate MSISDNs
        rev_data = database.get_data(
                            "rev_service",
                            {"number": msisdns, "is_active": True},
                            ["number","rev_service_id"]
                          )
        # Align column name for merging
        rev_data = rev_data.rename(columns={"number": "msisdn"}).drop_duplicates(subset=["msisdn"], keep="last")
        #  Merge msisdns with rev_service
        df = bulk_requests_df[["msisdn"]].merge(rev_data, on="msisdn", how="left")
        with_revid = df[df["rev_service_id"].notnull()]
        without_revid = df[df["rev_service_id"].isnull()]
        rev_msisdns=with_revid["msisdn"].tolist()
        remaining = list(rev_msisdns)        
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        rev_map = dict(zip(with_revid["msisdn"], with_revid["rev_service_id"]))
        nonrev_msisdns = without_revid["msisdn"].tolist()
        if nonrev_msisdns:
            # 1. Bulk update sim_management_inventory (all missing msisdns in one query)
            rev_service_log = database.update_dict(
                "sim_management_inventory",
                update_fields,
                and_conditions={"tenant_id": tenant_id, "is_active": True, "service_provider_id": service_provider_id},
                in_conditions={"msisdn": nonrev_msisdns}  # bulk update
            )
            successfull_iccids.append(nonrev_msisdns)

            # 2. Bulk update sim_management_bulk_change_request
            database.update_dict(
                "sim_management_bulk_change_request",
                {
                    "status": "PROCESSED",
                    "is_processed": True,
                    "has_errors": False,
                    "processed_date": now,
                    "status_details":"OK",
                }, 
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"subscriber_number": nonrev_msisdns},
            )

            # 3. Loop only for logs
            data_log=[]
            if rev_service_log:
                for msisdn in nonrev_msisdns:
                    data_log.append( {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                        "log_entry_description": "Update AMOP",
                        "request_text": "Edit Username/Cost Center processed",
                        "has_errors": False,
                        "response_status": "PROCESSED",
                        "response_text": "OK",
                        "error_text": "",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True,
                    })
                database.insert_data(data_log, "sim_management_bulk_change_log")
            else:
                for msisdn in nonrev_msisdns:
                    data_log.append({
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                        "log_entry_description": "Update AMOP",
                        "request_text": "Edit Username/Cost Center processed",
                        "has_errors": True,
                        "response_status": "ERROR",
                        "response_text": "Failed to update inventory",
                        "error_text": "",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True,
                    })
                database.insert_data(data_log, "sim_management_bulk_change_log")
        
            logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")


        # Chunking ICCIDs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(rev_msisdns), batch_size):
                # Create a batch of ICCIDs
                batch = rev_msisdns[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each MSISDN in the batch
                logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")
                for msisdn in batch:
                    # Prepare the URL and payload for the API call
                    
                    revid = rev_map.get(msisdn)
                    url = f"{carrier_api_url}/{revid}"
                    payload = []
                    def task(msisdn=msisdn, url=url, payload=payload):  
                        success = False
                        result = ""
                        status = "API_FAILED"
                        username_index = None
                        costcenter_index = None
                        
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Attempting {attempt} for MSISDN: {msisdn} with URL: {url}")
                                resp = requests.get(
                                    url, headers=headers, timeout=60)
                                logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Response Text: {result}")
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    response_data = resp.json()
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Attempt {attempt} failed for MSISDN: {msisdn}: {result}")
                                time.sleep(RETRY_DELAY)
                        if success:
                            label_to_index = {f["label"]: i for i, f in enumerate(response_data["fields"])}
                            username_index = label_to_index.get("User Name")
                            costcenter_index = [
                                    index for label, index in label_to_index.items() if label.startswith("CostCenter")
                                ]
                            logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Username index: {username_index}, Cost Center index: {costcenter_index} for MSISDN: {msisdn}")
                                
                        #update the request status
                        if username_index  or costcenter_index:
                            if username_index:
                                payload.append({
                                    "op": "replace",
                                    "path": f"/fields/{username_index}/value",
                                    "value": username
                                })

                            if costcenter_index:
                                payload.append({
                                    "op": "replace",
                                    "path": f"/fields/{costcenter_index}/value",
                                    "value": cost_center
                                })

                            logging.info(f"### rogers_bc_edit_username_cost_center and {tenant_name} API Payload: {payload}, URL: {url}")

                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    get_resp = requests.patch(url,json=payload, headers=headers, timeout=60)
                                    api_success = 200 <= get_resp.status_code < 300
                                    api_result = get_resp.text
                                    logging.info(f"### rogers_bc_edit_username_cost_center and {tenant_name} Response Code: {get_resp.status_code}")
                                    logging.info(f"### rogers_bc_edit_username_cost_center and {tenant_name} Response Text: {api_result}")
                                    status = "PROCESSED" if api_success else "API_FAILED"
                                    if api_success:
                                        response_data = get_resp.json()
                                        successfull_iccids.append(msisdn)
                                        break
                                except Exception as e:
                                    result = str(e)
                                    status = "API_EXCEPTION"
                                    time.sleep(RETRY_DELAY)
                            if api_success:
                                update_data = {
                                    "status": status,
                                    "has_errors": False,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details":"OK" 
                                }
                            else:
                                update_data = {
                                    "status": status,
                                    "has_errors": True,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details":"Edit Username/Cost Center via rogers API"
                                }  
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                update_data,
                                and_conditions={"bulk_change_id": bulk_change_id},
                                in_conditions={"subscriber_number":[msisdn]},
                                )             
                                #inserting values into revservice product table 
                            rev_service_log=database.update_dict(
                                "sim_management_inventory",update_fields,
                                and_conditions={"tenant_id":tenant_id,"service_provider_id": service_provider_id,"is_active": True},
                                in_conditions={"msisdn": [msisdn]}
                            )
                            #constracting logs 
                            log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Edit Username/Cost Center via Rogers API",
                                    "request_text": json.dumps(payload),
                                    "has_errors": status == "API_FAILED",
                                    "response_status": "PROCESSED" if api_success else "API_Failed",
                                    "response_text": api_result,
                                    "error_text": "" if status == "PROCESSED" else result,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
            
                            if log:
                                database.insert_data(log,"sim_management_bulk_change_log")
                            logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Inserting log for Edit Username/Cost Center: {log}") 
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Update AMOP",
                                    "request_text": json.dumps(payload),
                                    "has_errors":False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK" ,
                                    "error_text": "",
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                        else:
                            rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"service_provider_id": service_provider_id,"is_active": True},
                                        in_conditions={"msisdn": [msisdn]}
                                    )
                            successfull_iccids.append(msisdn)
                                
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK"},
                                and_conditions={"bulk_change_id": bulk_change_id},
                                in_conditions={"subscriber_number":[msisdn]},
                                )

                                #constracting logs
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Edit Username/Cost Center via Rogers API",
                                    "request_text": "Upadte AMOP",
                                    "has_errors": False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK",
                                    "error_text": "" ,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                        return msisdn


                    # Submit the task to the executor
                    logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Submitting task for MSISDN: {msisdn}")
                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        iccid = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Error processing MSISDN: {e}")

              
        if interval and i + batch_size < len(rev_msisdns):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Update the bulk change request status   
        logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Processed {len(msisdns) - len(remaining)} MSISDNs, {len(remaining)} remaining")
        #api call to upadte the history tables
        if successfull_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": [],
                                        "msisdns":successfull_iccids,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the API to update device history tables
            try:
                logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Exception in thread: {e}")
        ## Handle invalid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_iccids:
            logging.info(f"### Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": f"Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #suny url to update inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "rogers_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'### rogers_bc_edit_usename_cost_center and {tenant_name} sync call has started')
            
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f'### rogers_bc_edit_usename_cost_center and {tenant_name} sync call has ended')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "rogers_bc_edit_usename_cost_center",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for edit username cost center for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the sync completion
            bulk_change_audit_action(
                    data, common_utils_database,
                    action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### rogers_bc_edit_usename_cost_center and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
    
 
    

## Assign customer function
def rogers_bc_assign_customer(data):
    """Assign a customer to the selected devices or services.
    This function processes a list of iccids and assign a customer account with the iccids in the Verizon system.
    It handles bulk requests, updates the database, and logs the results.
    Args:
        data (dict): Input data containing the following keys:
            - ICCIDs (list): List of ICCIDs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Verizon API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
        context (dict): Lambda context object containing execution details.
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    
    """
    logging.info(f"### Received data for assign customer: %s", data)
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    service_provider_id = data.get("service_provider_id", "")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Initialize for log entries
    log_entries = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### rogers_bc_assign_customer and {tenant_name} time is {now}")

    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### rogers_bc_assign_customer and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,20)
    except Exception as e:
        logging.exception(f"### rogers_bc_assign_customer and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
            logging.info(f"### rogers_bc_assign_customer and {tenant_name} Carrier API details fetched successfully")

        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}


        # Fetch bulk change rows
       
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},#iccid
            ["id", "iccid", "change_request"]
        )
        remaining = list(iccids)
        # Validate input data 
       
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "rogers_bc_assign_customer",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")

                except Exception as e:
                    logging.warning(f"### rogers_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
                return response
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        #Extract relevant fields from the change request 
        customer_rate_plan_id=change_request_json.get("CustomerRatePlan","")
        customer_rate_pool_id=change_request_json.get("CustomerRatePool","")
        rev_customer_id=change_request_json.get("RevCustomerId","")
        service_type_id=change_request_json.get("ServiceTypeId","")
        effective_date=change_request_json.get("EffectiveDate","")
        activated_date=change_request_json.get("ActivatedDate","")
        revproductidlist=change_request_json.get("RevProductIdList",[0])
        product_id = revproductidlist[0] if revproductidlist else None
        provider_id=change_request_json.get("ProviderId","")
        number=change_request_json.get("Number","")
        integration_authentication_id=change_request_json.get("IntegrationAuthenticationId","")
        device_id=change_request_json.get("DeviceId")
        description=change_request_json.get("Description","")
        rate= change_request_json.get("RateList", [0])
        revpackageid=change_request_json.get("RevPackageId", None)
        # Initialize variables for customer and rate plan details
        customer_rate_plan = None
        customer_rate_pool = None
        rev_customer = None
        provider_data=pd.DataFrame()
        rev_customer_uuid = None
        customer_id=None
        customer_name=None
       # Fetch customer and rate plan details from the database
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name"]
            )
            if not rate_plan_data.empty:
                rate_plan_id = rate_plan_data["rate_plan_code"].to_list()[0]
                customer_rate_plan=rate_plan_data["rate_plan_name"].to_list()[0]
        if customer_rate_pool_id:
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool = rate_pool_data["name"].to_list()[0]
        if rev_customer_id:
            rev_data = database.get_data(
                "revcustomer",
                {"rev_customer_id": rev_customer_id, "is_active": True},
                ["customer_name", "id"]
            )
            if not rev_data.empty:
                rev_customer = rev_data["customer_name"].to_list()[0]
                rev_customer_uuid = rev_data["id"].to_list()[0]
        # Initialize as empty DataFrame       
        customer_data = pd.DataFrame()  
        if rev_customer:
            customer_data = database.get_data(
                "customers", 
                {"customer_name": rev_customer, "is_active": True},
                ["id", "customer_name"]
                )
        if not customer_data.empty:
            customer_id = customer_data["id"].to_list()[0]
            customer_name = customer_data["customer_name"].to_list()[0]
        else:
            customer_id = None
            customer_name = None
        if provider_id:
            provider_data = database.get_data(
                "rev_provider",
                {"provider_id": provider_id, "is_active": True,"integration_authentication_id": integration_authentication_id},
                ["id"]
            )
            if not provider_data.empty:
                rev_provider_id = provider_data["id"].to_list()[0] 
       # Prepare update fields for the database
        update_fields = {"customer_rate_plan_id": customer_rate_plan_id,"customer_rate_plan_name": customer_rate_plan}
        update_fields["modified_by"] = username 
        if customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id
            update_fields["customer_rate_pool_name"] = customer_rate_pool
        if rev_customer_id:
            update_fields["rev_customer_id"] = rev_customer_id
            update_fields["rev_customer_name"] = rev_customer
        if effective_date:
            update_fields["effective_date"] = effective_date
        if integration_authentication_id:
            update_fields["account_number_integration_authentication_id"] = integration_authentication_id
        if device_id:
            update_fields["device_id"] = device_id
        update_fields["customer_id"] = customer_id if customer_id is not None else None
        update_fields["customer_name"] = customer_name if customer_name is not None else None
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        iccid_to_request_id = dict(zip(bulk_requests.iccid, bulk_requests.id))
        iccid_to_changerequest = dict(zip(bulk_requests.iccid, bulk_requests.change_request))
        ## Prepare headers for API call
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
        }
        # Prepare data for database insertion
        product_data={}
        if revpackageid:
            product_data["package_id"] = revpackageid
        if rate:
           product_data["rate"] = Decimal(str(rate[0]))
        if product_id:
            product_data["product_id"] = product_id
        # Validate iccids 
        successful_iccids = []
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"### rogers_bc_assign_customer and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"### rogers_bc_assign_customer and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        
        ## Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process each batch of ICCIDs
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # craete a dictionary to hold futures
                futures = {}
                logging.info(f"### rogers_bc_assign_customer and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")
                for iccid in batch:
                    url = f"{carrier_api_url}"
                    logging.info(f"### rogers_bc_assign_customer and {tenant_name} Processing ICCID: {iccid}")
                    payload_str = iccid_to_changerequest.get(iccid)
                    logging.info(f"### rogers_bc_assign_customer and {tenant_name} Payload for ICCID {iccid}: {payload_str}")
                    request_payload = json.loads(payload_str)
                    #extract the create rev service flag
                    rev_service = request_payload.get("CreateRevService", False)
                    # Build payloads for all APIs
                    rev_api_payload = {
                        "customer_id": rev_customer_id,
                        "provider_id": provider_id,
                        "service_type_id": service_type_id,
                        "number": number,
                        "activated_date": activated_date,
                    }
                    product_api_payload={
                        "CustomerId": rev_customer_id,
                        "service_type_id": service_type_id,
                        "number": number,
                        "effective_date": effective_date,
                        "activated_date": activated_date,
                        "product_id": product_id,
                        }
                    #task function
                    def task(iccid=iccid, rev_service=rev_service):
                        """ 1. If CreateRevService is True:
                            - Step 1: Call API to create RevService (POST with retries)
                            - Step 2: On success, extract RevService ID from response
                            - Step 3: Use RevService ID to create Service Product (POST)
                        
                           2. If CreateRevService is False:
                            - Skip RevService creation and directly insert into DB"""
                        success = False
                        result = ""
                        status = "API_FAILED"
                        id = None
                        productid = None
                        try:
                            if rev_service:
                                # Step 1:  First API Call to create the revservice
                                for attempt in range(1, MAX_RETRIES + 1):
                                    try:
                                        logging.info(f"### rogers_bc_assign_customer and {tenant_name} Attempt {attempt} - URL: {url}, Payload: {rev_api_payload}")
                                        
                                        resp = requests.post(url, json=rev_api_payload, headers=headers, timeout=60)
                                        success = 200 <= resp.status_code < 300
                                        result = resp.text
                                        logging.info(f"### rogers_bc_assign_customer and {tenant_name} Response Code: {resp.status_code}")
                                        logging.info(f"### rogers_bc_assign_customer and {tenant_name} Response Text: {result}")
                                        status = "PROCESSED" if success else "API_Failed"
                                        if success:
                                            try:
                                                response_data = resp.json()
                                                id = response_data.get("id")
                                                successful_iccids.append(iccid)
                                            except Exception:
                                                id = None
                                            break
                                    except Exception as e:
                                        result = str(e)
                                        status = "API_EXCEPTION"
                                        logging.exception(f"### rogers_bc_assign_customer and {tenant_name} Exception in API call: {e}")
                                        time.sleep(RETRY_DELAY) 
                                if success:
                                    update_data = {
                                        "status": status,
                                        "has_errors": False,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result   
                                    }
                                else:
                                    update_data = {
                                        "status": status,
                                        "has_errors": True,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result
                                    }  
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    update_data,
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"iccid": iccids},
                                    )             
                                if success:  
                                    #inserting values in rev service 
                                    rev_data={
                                    "rev_customer_id":rev_customer_uuid,
                                    "number":number,
                                    "rev_service_id":id,
                                    "activated_date":activated_date,
                                    "is_active":True,
                                    "integration_authentication_id":integration_authentication_id,
                                    "rev_provider_id":rev_provider_id,
                                    "rev_service_type_id":service_type_id
                                    }
                                    rev_insert_id=database.insert_data(rev_data,"rev_service")
                                    if rev_insert_id:
                                        update_fields["rev_service_id"]=rev_insert_id
                                    #updating inventory table
                                    rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"service_provider_id": service_provider_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                # Inserting logs based on api result
                                rev_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Rev.io API",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": status == "PROCESSED",
                                        "response_status": "PROCESSED" if success else "API_Failed",
                                        "response_text": result,
                                        "error_text": "" if status == "PROCESSED" else result,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                database.insert_data(rev_log,"sim_management_bulk_change_log") 
                                logging.info(f"### rogers_bc_assign_customer and {tenant_name} Inserting log for rev service creation: {rev_log}")
                                #inserting logs after updating inventory table
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors":False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK" ,
                                        "error_text": "",
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    logging.info(f"### rogers_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                                # Step 2:  Second API Call
                                logging.info(f"### rogers_bc_assign_customer and {tenant_name} Creating Rev.io Service Product for ICCID: {iccid} with ID: {id}")
                                if id:
                                    second_url = f"{alternative_api_url}"
                                    #constracting payload 
                                    product_api_payload["service_id"]=id
                                    logging.info(f"### rogers_bc_assign_customer and {tenant_name} Product API Payload: {product_api_payload}, URL: {second_url}")

                                    for attempt in range(1, MAX_RETRIES + 1):
                                        try:
                                            get_resp = requests.post(second_url,json=product_api_payload, headers=headers, timeout=60)
                                            api_success = 200 <= get_resp.status_code < 300
                                            api_result = get_resp.text
                                            logging.info(f"### rogers_bc_assign_customer and {tenant_name} Response Code: {get_resp.status_code}")
                                            logging.info(f"### rogers_bc_assign_customer and {tenant_name} Response Text: {api_result}")
                                            status = "PROCESSED" if api_success else "API_FAILED"
                                            if api_success:
                                                response_data = get_resp.json()
                                                productid = response_data.get("id")
                                                break
                                        except Exception as e:
                                            result = str(e)
                                            status = "API_EXCEPTION"
                                            time.sleep(RETRY_DELAY)
                                    if api_success:
                                        product_data.update({
                                               "service_product_id": productid,  
                                                "customer_id":rev_customer_id,  
                                                "service_id": id,  
                                                "description":description,  
                                                "activated_date": activated_date,     
                                                "status": "ACTIVE",  
                                                "created_by": created_by,  
                                                "created_date": now,  
                                                "is_active": True,  
                                                "is_deleted": False,  
                                                "integration_authentication_id": integration_authentication_id,
                                        })
                                        #inserting values into revservice product table 
                                        database.insert_data(product_data,"rev_service_product")
                                        logging.info(f"### rogers_bc_assign_customer and {tenant_name} Inserting log for rev service product creation: {product_data}")
                                        rev_service_log=database.update_dict(
                                            "sim_management_inventory",update_fields,
                                            and_conditions={"tenant_id":tenant_id,"service_provider_id": service_provider_id,"is_active": True},
                                            in_conditions={"iccid": [iccid]}
                                        )
                                    #constracting logs 
                                    log = {
                                            "bulk_change_id": bulk_change_id,
                                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                            "log_entry_description": "Create Rev.io Service Product: Rev.io API",
                                            "request_text": json.dumps(product_api_payload),
                                            "has_errors": status == "API_FAILED",
                                            "response_status": "PROCESSED" if api_success else "API_Failed",
                                            "response_text": api_result,
                                            "error_text": "" if status == "PROCESSED" else result,
                                            "processed_date": now,
                                            "processed_by": created_by,
                                            "created_by": created_by,
                                            "created_date": now,
                                            "is_deleted": False,
                                            "is_active": True
                                        }
                    
                                    if log:
                                        database.insert_data(log,"sim_management_bulk_change_log")
                                    logging.info(f"### rogers_bc_assign_customer and {tenant_name} Inserting log for product creation: {log}") 
                                    if rev_service_log:
                                        data_log = {
                                            "bulk_change_id": bulk_change_id,
                                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                            "log_entry_description": "Create Rev.io Service: Update AMOP",
                                            "request_text": json.dumps(product_api_payload),
                                            "has_errors":False,
                                            "response_status": "PROCESSED",
                                            "response_text": "OK" ,
                                            "error_text": "",
                                            "processed_date": now,
                                            "processed_by": created_by,
                                            "created_by": created_by,
                                            "created_date": now,
                                            "is_deleted": False,
                                            "is_active": True
                                        }
                                        database.insert_data(data_log,"sim_management_bulk_change_log")
                                        logging.info(f"### rogers_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                            else:
                                #if createrevservice flag false then directly updating values into table
                                rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"service_provider_id": service_provider_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                successful_iccids.append(iccid)
                                
                                database.update_dict(
                                        "sim_management_bulk_change_request",
                                        {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK"},
                                        and_conditions={"bulk_change_id": bulk_change_id},
                                        in_conditions={"iccid": iccids},
                                    )

                                #constracting logs
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK",
                                        "error_text": "" ,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    logging.info(f"### rogers_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")

                        except Exception as e:
                            logging.exception(f"### rogers_bc_assign_customer and {tenant_name} Unexpected error for ICCID {iccid}: {str(e)}")
                        logging.info(f"### rogers_bc_assign_customer and {tenant_name} Completed processing ICCID: {iccid}, Success: {success}, ID: {id}, Product ID: {productid}")
                        return iccid
                    futures[executor.submit(task)] = iccid
                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.error(f"### rogers_bc_assign_customer and {tenant_name} Error processing iccid: {e}")
        if interval and i + batch_size < len(iccids):
            time.sleep(interval)
       
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        logging.info(f"### rogers_bc_assign_customer and {tenant_name} Processed %d iccids, %d remaining", len(iccids) - len(remaining), len(remaining))
        # Check for any invalid ICCIDs
        if successful_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": successful_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            # Call the history table update API
            try:
                logging.info(f"### rogers_bc_assign_customer and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### rogers_bc_assign_customer and {tenant_name} Exception in thread: {e}")
        # Check for any invalid ICCIDs
        if invalid_iccids:
            logging.info(f"### rogers_bc_assign_customer and {tenant_name} Invalid iccids found: {invalid_iccids}")
            # Log invalid IDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Assign customer ",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,"status_details": "Invalid SIM - could not be processed","processed_date": now},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### rogers_bc_assign_customer and {tenant_name} Inserted %d log entries for bulk change request", len(log_entries))
        logging.info(f"### rogers_bc_assign_customer and {tenant_name} Bulk Change Completed in %.1fs", time.time() - start_time)
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API call for 1.0 tables to update the inventory
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "rogers_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### rogers_bc_assign_customer and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            ) 
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### rogers_bc_assign_customer and {tenant_name} sync call has ended")
           
        except Exception as e:
            logging.exception(f"### rogers_bc_assign_customer and {tenant_name} Exception in thread: {e}")
       
        live_progress_percentage_tracker(database, bulk_change_id,95)
       
        # Attempt to audit the action
        try:
            audit_data_user_actions = {
                "service_name": "rogers_bc_assign_customer",
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for Assign customer for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
             ##auditing the sync completion
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.warning(f"### rogers_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
       
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### rogers_bc_assign_customer and {tenant_name} Error during bulk change processing: {e}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "rogers_bc_assign_customer",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### rogers_bc_assign_customer and {tenant_name} Logging error to DB failed: {e}")
 
        return response
    


def rogers_bc_line_sync(data):
    """
    Sync SIM inventory and bulk change requests with the rogers API.

    This function processes a list of ICCIDs for a given bulk change operation
    and updates their details by calling the carrier's rogers API. It includes
    retry logic, database updates, inventory synchronization, error handling,
    and audit logging.

    Args:
        data (dict): Input dictionary containing the following keys:
            - iccids (list): List of ICCIDs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains request payload and UpdateStatus information.
            - service_provider (str): Name of the carrier/service provider.
            - change_type (str): Type of update (e.g., SIM/device status).
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant (for logs/audit).
            - db_name (str): Tenant-specific database name.
            - service_provider_id (str): Identifier for the service provider.
            - invalid_iccids (list): ICCIDs that failed validation before processing.

    Returns:
        dict: Response object summarizing the processing result:
            - flag (bool): True if operation completed without unhandled errors.
            - message (str): Summary of result (success or failure).
            - processed (int): Number of ICCIDs successfully processed.
            - remaining (int): Number of ICCIDs not processed.
            - iccids (list): List of ICCIDs attempted.
            - invalid_iccids (list): ICCIDs skipped due to invalid input.
            - bulk_change_id (str): Bulk change request ID.
            - error (str, optional): Error message if processing failed.
    """
    logging.info(f"### Received data for updating device status: {data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    service_provider_id = data.get("service_provider_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    
    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### rogers_bc_line_sync and {tenant_name} time is {now}")
    successfull_ids = []
    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### rogers_bc_line_sync and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### rogers_bc_line_sync and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    
    try:
        # Get carrier API credentials and configuration
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### rogers_bc_line_sync and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### rogers_bc_line_sync and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid"]
        ).rename(columns={"iccid": "iccid"})
        if  bulk_requests_df.empty:
            
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "rogers_bc_line_sync",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### rogers_bc_line_sync and {tenant_name} Audit logging failed: {e}")
                return response

        ##fetching the requests ids
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        
        if PARALLEL_REQUESTS>10:
           logging.info(f"### rogers_bc_line_sync and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
        PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        remaining = list(iccids)
        # Execute API calls in parallel using ThreadPoolExecutor
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}

                for iccid in batch:
                    url = f"{carrier_api_url}/{iccid}"                

                    def task(iccid=iccid, url=url):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        updated = None
                        inserted = None
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### rogers_bc_line_sync and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                resp = requests.get(url, 
                        headers={
                                    "Authorization": app_id,
                                    "Content-Type": "application/json"
                                }, timeout=60)
                                logging.info(f"### rogers_bc_line_sync and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successfull_ids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### rogers_bc_line_sync and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                           "processed_date": now,"status_details":resp.text},
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory if successful
                        if success:
                            api_data = resp.json()
    
                            to_update = {
                                "iccid": api_data.get("iccid"),
                                "imsi": api_data.get("imsi"),
                                "msisdn": api_data.get("msisdn"),
                                "imei": api_data.get("imei", ""),   # resp has `imei`
                                "sim_status": api_data.get("status"),
                                "carrier_rate_plan_name": api_data.get("ratePlan"),
                                "communication_plan": api_data.get("communicationPlan"),
                                "customer_name": api_data.get("customer"),
                                "date_activated": api_data.get("dateActivated"),
                                "account_number": api_data.get("accountId"),
                            }
                         
                            # First try update 
                            updated = database.update_dict(
                                "sim_management_inventory",
                                values=to_update,
                                and_conditions={
                                    "iccid": api_data.get("iccid"),
                                    "tenant_id": tenant_id,
                                    "service_provider_id": service_provider_id,
                                    "is_active": True,
                                },
                            )

                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update rogers Subscriber: rogers API",
                            "request_text": None,
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            
                        # Prepare log entry
                        # Determine inventory update success
                        inventory_success = updated 

                        # Prepare inventory log entry
                        inventory_log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update AMOP",
                            "request_text": None,
                            "has_errors": not inventory_success,
                            "response_status": "PROCESSED" if inventory_success else "ERROR",
                            "response_text": "inventory updated successfully" if inventory_success else "inventory update failed",
                            "error_text": "" if inventory_success else "Inventory update failed",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }

                        if inventory_log:
                            database.insert_data(inventory_log, "sim_management_bulk_change_log")   
                            
                         
                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### rogers_bc_line_sync and {tenant_name} Error processing ICCID: {e}")

            if INTERVAL and i + BATCH_SIZE < len(iccids):
                time.sleep(INTERVAL)
        # Handle and log invalid ICCIDs
        #prepare the payload for history table
        if successfull_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": successfull_ids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### rogers_bc_line_sync and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### rogers_bc_line_sync and {tenant_name} Exception in thread: {e}")
        # Handle and log invalid ICCIDs
        if invalid_iccids:
            for iccid in invalid_iccids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": "Update rogers Subscriber: Invalid ICCID",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")

        # Mark invalid request IDs as processed
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        #  sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api to update the inventry tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "rogers_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### rogers_bc_line_sync and {tenant_name} sync call has started")
            
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### rogers_bc_line_sync and {tenant_name} sync call has ended")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### rogers_bc_line_sync and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### rogers_bc_line_sync and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### rogers_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        # Prepare response
        response={
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
       
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "rogers_bc_line_sync",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for update device status for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
             ##auditing the auditing log
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### rogers_bc_line_sync and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### rogers_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### rogers_bc_line_sync and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR","status_details":"Processing Invalid Sim"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "rogers_bc_line_sync",
                "created_date": data.get("request_received_at") or now,
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for: {iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### rogers_bc_line_sync and {tenant_name} Exception in logging error data to DB: {log_e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response    


##SYNC API call function
def call_sync_api(api_url, api_payload):
    '''
    Call the sync API with the provided URL and payload.
    This function is designed to be run in a separate thread after a delay.
    '''
    try:
        # Make the API call
        logging.info(f"### Calling sync API: {api_url} with payload: {api_payload}")
        response = requests.post(api_url, json=api_payload)
        if response.status_code == 200:
            logging.info("Bulk Change API call successful. Data sync call successfully done.")
        else:
            logging.error(f"### API call failed with status code: {response.status_code}")
    except Exception as e:
        logging.error(f"### Error making API call: {e}")

## Function to audit user actions in bulk change processing
def bulk_change_audit_action(data, common_utils_database,action):
    """
    Audits user actions by logging them into the bulk change auditing table.
 
    Args:
        data (dict): Data containing user action details.
        common_utils_database (DB): Database connection object.
 
    Returns:
        None
    """
    service_provider = data.get("service_provider", "")
    change_event_type = data.get("change_type", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
   
    request_received_at = data.get("request_received_at", "") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bulk_change_id = data.get("bulk_change_id", "")
    try:
        audit_data_user_actions = {
                "tenant_name": tenant_name,
                "bulk_change_id":bulk_change_id,
                "serviceprovider": service_provider,
                "change_event_type": change_event_type,
                "action": action,
                "created_date": request_received_at,
                "created_by": username,
               
        }
        common_utils_database.update_audit(audit_data_user_actions, "bulk_change_auditing")
        logging.info("User action audited successfully.")
    except Exception as e:
        logging.exception(f"### Error logging user actions: {e}")


def live_progress_percentage_tracker(database, bulk_change_id,progress_percent):
    """
    Updates the live_progress_percentage column in sim_management_bulk_change_request table.
    """
    try:
        update_fields={}
        #updating sync status when progress percentage reached 100
        if progress_percent==100:
            update_fields["live_progress_percentage"]=progress_percent
            update_fields["progress"]="Sync Completed"
        else:
            update_fields["live_progress_percentage"]=progress_percent

        database.update_dict(
            "sim_management_bulk_change",
            update_fields,
            and_conditions={"id": bulk_change_id}
        )
        return True
    except Exception as e:
        logging.error(f"### Error updating live progress: {e}")
        return False




import requests
from datetime import datetime, timedelta
import psycopg2
def connect_to_db(dbname):
    """ Connect to the PostgreSQL database with dynamic dbname """
    try:
        connection = psycopg2.connect(
            host='amoppostgresdb.c3qae66ke1lg.us-east-1.rds.amazonaws.com',
            port="5432",
            user="root",
            password='AmopTeam123',
            dbname=dbname
        )
        return connection
    except Exception as e:
        print(f"Error in connecting the database: {e}")
        return None
def fetch_data_from_db(query, connection):
    """ Fetch data from the database using the provided query """
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        data = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]  # Get column names
        return [dict(zip(columns, row)) for row in data]  # Return data as a list of dictionaries
    except Exception as e:
        print(f"Error fetching data: {e}")
        return []
    finally:
        cursor.close()


def get_date_range(start_str: str, end_str: str, reverse: bool = True):
    """
    Returns a list of date strings (YYYY-MM-DD) between start_str and end_str inclusive.
    Date strings are in format "YYYY-MM-DD".
    If reverse=True, returns from start_str down to end_str.
    """
    start = datetime.strptime(start_str, "%Y-%m-%d")
    end   = datetime.strptime(end_str,   "%Y-%m-%d")
    delta = timedelta(days=1)
    
    dates = []
    if reverse:
        current = start
        while current >= end:
            dates.append(current.strftime("%Y-%m-%d"))
            current -= delta
    else:
        current = end
        while current <= start:
            dates.append(current.strftime("%Y-%m-%d"))
            current += delta
    return dates

def fetch_usage_for_date(subscription_id: str, date_str: str, token: str, api_key: str):
    """
    Call the usage_records API for one date for that subscription_id.
    Returns the JSON response (or None on error).
    """
    url = f"https://api.korewireless.com/connectivity/v1/accounts/cmp-k1-org-35764/subscriptions/{subscription_id}/usage-records"
    params = {
        'start-date': f"{date_str} 00:00:00",
        'end-date':   f"{date_str} 23:59:59",
        'source':     'cdr'
    }
    headers={
        'Authorization':'Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJLQVVDc0NQUDlBd0R6XzFFTmFHbGxNeFFPSVctS19LVVpLeW5JN2RJTjlNIn0.eyJleHAiOjE3NTc3NzI4NjEsImlhdCI6MTc1NzczNjg2MSwianRpIjoiZmRhZTk5NDYtODUwYy00YmViLTlmMWEtZjIwZTc0ZjIyYmNhIiwiaXNzIjoiaHR0cHM6Ly9zc28ua29yZXdpcmVsZXNzLmNvbS9yZWFsbXMvS09SRS1DSURQIiwiYXVkIjoiYXBpLWd3Iiwic3ViIjoiMmJkNWQ0ZDctYWRkMS00OTUyLWFkYTMtNjc4MWM5MGRhOTBiIiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiS29yZXdpcmVsZXNzLWNsaWVudC1Qcm9kdWN0aW9uLW01NThpMW1oMSIsInNjb3BlIjoiZW1haWwiLCJpcF9yYW5nZSI6W10sIm93bmVyIjoiY3phbWJyYW5vQHNwZWN0cm90ZWwuY29tIiwib3JnX3VybiI6IltdIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJjbGllbnRIb3N0IjoiNDQuMjEyLjE4MC4xODMiLCJvcmdhbml6YXRpb24iOiJzcGVjdHJvdGVsIGhvbGRpbmdzIGNvbXBhbnkiLCJzZXJ2aWNlcyI6W3sic2VydmljZU5hbWUiOiJDb25uZWN0aXZpdHkiLCJhY2NvdW50SWRzIjpbImNtcC1rMS1vcmctMzU3NjQiXX1dLCJjbGllbnRBZGRyZXNzIjoiNDQuMjEyLjE4MC4xODMiLCJjbGllbnRfaWQiOiJLb3Jld2lyZWxlc3MtY2xpZW50LVByb2R1Y3Rpb24tbTU1OGkxbWgxIn0.B9AOcqIyiaII-D7tWwljaJPSTTxc93l7Q43Iz6T-scEPpJPYelEkPreZF4quJma8KsaE986ywk1T_wUvaSjaR69OWAADPoLcCbVibc01w2EhyO3qO-6XOCojJV3IeWp5KPZWLyEs1P8A3RZdamTCenmxuEc3tx60YWCvOTaMq4hcWg5-q8GJcEIl2vJqe-7hOc1sFCxoMzczwehsUv0t8Bm62-AulRVQHFRRGfa4dmQzjRNEPDg4UKjah7VWs0Dpm4HSzrUaW4bgk8abxiihkgj3Hekcq4Y5XmYNqpbkQTqfRKxzjDUT66WNNFDHuGrird8Ki44d6dd6Wjq4gowocA'
         , 'Accept': 'application/json',
        'x-api-key': 'FwEO4B4Fqq28VPsaetYh59xZ75wsUpow98XCbUFC'
    }
    try:
        resp = requests.get(url, params=params, headers=headers, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"[Error] fetch_usage_for_date for {subscription_id} on {date_str}: {e}")
        return None


def insert_kore_device_usage_data(df, conn):
    cursor = conn.cursor()
    values = [
        cursor.mogrify("(%s,%s,%s,%s,%s,%s,%s,%s)", tuple(row))
        for row in df[['m2m_device_id','sim_management_inventory_id','device_status_id', 'data_usage', 'sms_usage', 'voice_usage', 'usage_date', 'created_by']].values
    ]
    sql = b"INSERT INTO device_usage (m2m_device_id,sim_management_inventory_id,device_status_id, data_usage, sms_usage, voice_usage, usage_date, created_by) VALUES " + b",".join(values)
    cursor.execute(sql)
    conn.commit()


def sync_usage_for_sims(data):
    """
    1. Fetch sim inventory
    2. Fetch subscription_id, iccid from kore_device_usage_stagging
    3. For each sim, for each date in date range (reverse order),
       fetch usage, then insert record(s) into device_usage table.
    """
    # 1. fetch sim inventory
    connection = connect_to_db('spectrotel')
    usage_start_date=data.get('usage_start_date')
    usage_end_date=data.get('usage_end_date')
    print('usage_start_date',usage_start_date)
    print('usage_end_date',usage_end_date)
    sim_inventory_query = """
    SELECT id AS sim_management_inventory_id, iccid, device_status_id, device_id AS m2m_device_id
    FROM sim_management_inventory
    WHERE service_provider_display_name = 'Kore' AND is_active = TRUE and service_provider_id=11 
    """
    sim_inventory_data = fetch_data_from_db(sim_inventory_query, connection)
    print('inventory',len(sim_inventory_data))
    # convert to dict by iccid for quick lookup
    sim_inventory_map = {row['iccid']: row for row in sim_inventory_data}
    # 2. fetch subscription_id & iccid from kore_device_usage_stagging
    staging_query = """
    SELECT distinct subscription_id, iccid
    FROM kore_device_usage_stagging 
    WHERE  iccid IS NOT NULL 
    """
    staging_data = fetch_data_from_db(staging_query, connection)
    print('staging_data',len(staging_data))
    # prepare dates
    date_list = get_date_range(usage_start_date, usage_end_date, reverse=True)
    print('date_list',date_list)
    # for insert, accumulate rows
    for date_str in date_list:
        print('processing date',date_str)
        rows_to_insert = []
        for entry in staging_data:
            subscription_id = entry.get('subscription_id')
            iccid = entry.get('iccid')
            #print('processing',subscription_id,iccid)
            if not subscription_id or not iccid:
                continue
            
            # check if sim_inventory has this iccid
            sim_info = sim_inventory_map.get(iccid)
            if not sim_info:
                print(f"[Skipping] iccid {iccid} not in sim inventory")
                continue
            
            sim_management_id = sim_info['sim_management_inventory_id']
            m2m_device_id = sim_info['m2m_device_id']
            device_status_id = sim_info.get('device_status_id')
            usage = fetch_usage_for_date(subscription_id, date_str, "token", "api_key")
            #print('usage',usage)
            if usage is None:
                # maybe no data or error; you can skip or use zeros
                voice_usage = 0
                data_usage  = 0
                sms_usage   = 0
            else:
                voice_usage = usage.get('voice', {}).get('total-usage', 0)
                data_usage  = usage.get('data', {}).get('total-usage', 0)
                sms_usage   = usage.get('sms', {}).get('total-usage', 0)
            
            # prepare a row to insert
            # Use same format / columns as insert_kore_device_usage_data expects:
            # e.g. (m2m_device_id, sim_management_id, device_status_id, data_usage, sms_usage, voice_usage, usage_date, created_by)
            usage_date = datetime.strptime(date_str, "%Y-%m-%d")
            # you can choose what created_by you want
            created_by = 'Kore_Container'
            print(f"ICCID {iccid}, Sub {subscription_id}, Data {data_usage}, SMS {sms_usage}, Voice {voice_usage}")
            rows_to_insert.append((
                m2m_device_id,
                sim_management_id,
                device_status_id,
                data_usage,
                sms_usage,
                voice_usage,
                usage_date,
                created_by
            ))
        print(f"After date {date_str}, total rows to insert: {len(rows_to_insert)}")
        # now insert into device_usage
        if rows_to_insert:
            print(len(rows_to_insert),'rows_to_insert')
        # build DataFrame if needed, or directly use insert function
        # Assuming you have a DataFrame based insert function; adapt as per your existing one
        import pandas as pd
        df_insert = pd.DataFrame(rows_to_insert, columns=[
            'm2m_device_id',
            'sim_management_inventory_id',
            'device_status_id',
            'data_usage',
            'sms_usage',
            'voice_usage',
            'usage_date',
            'created_by'
        ])
        print(f"length of the rows inserted",len(df_insert))
        insert_kore_device_usage_data(df_insert, connection)
    else:
        print("[Info] No rows to insert")
    return {"flag":True,"message":"Usage sync completed"}
