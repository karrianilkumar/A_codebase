"""
@author: Phaneendra
Created Date: 2025-06-30
"""
##Importing the packages and the common files
from flask import Flask, request, jsonify
import json
import os
import time
import logging
from Webbing import funtion_caller
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging

#logging initiation
logging = Logging(name="main")

##preparing the db config for the database configuration
db_config = {
     "host": os.environ["HOST"],
     "port": os.environ["PORT"],
     "user": os.environ["USER"],
     "password": os.environ["PASSWORD"],

 }
# Initialize the Flask application
app = Flask(__name__)


# Define an API route to handle bulk change requests
@app.route('/Webbing_BulkChange_Handler', methods=['POST'])
def Webbing_BulkChange_Handler():
    """
    Handles incoming bulk change requests for Telegence.

    This endpoint expects a JSON payload containing relevant request data.
    Optionally, the payload can include a 'path' key to provide additional context or
    processing instructions.

    Request:
        Method: POST
        Content-Type: application/json
        Body: {
            "path": "<optional_path_string>",
            ...other required keys...
        }

    Response:
        200 OK with a confirmation message in JSON format.

    Logs:
        - Logs the received 'path' value for traceability.
        - Passes request data and path to the core processing function (`funtion_caller`).

    Returns:
        JSON response indicating receipt of the request.
    """
    # Parse incoming JSON request
    data = request.get_json()
    # Extract optional 'path' parameter from request data
    path=data.get('path',None)
    logging.info(f"Received path: {path}")
    # Call the core processing logic
    result=funtion_caller(data,path)
    ##based on the result of the functions the message will be returned
    if result.get("flag") is True:
        message = result.get("message", "Processed successfully.")
        logging.info(f"Success: {message}")
        return jsonify({"flag":True,"message": message}), 200
    else:
        message = result.get("message", "Processing failed.")
        logging.error(f"Failure: {message}")
        return jsonify({"flag":False,"message": message}), 500

if __name__ == "__main__":
    logging.info(f'the main.py is calling')
    try:
        logging.info("Starting Flask app...")
        app.run(host='0.0.0.0', port=5000)
    except Exception as e:
        logging.info(f"Unhandled Exception: {e}")
        # Keep the container alive even on crash
        while True:
            logging.info("App crashed but container is alive...")
            time.sleep(300)

